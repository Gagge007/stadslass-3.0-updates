(() => {
  'use strict';

  const PACKAGE_VERSION = 138;
  const PROTOCOL = 'stadslass.mailbox.v1';
  const TEST_TEXTS = Object.freeze(['Testbrev från Stadslass Sync P136', 'Testbrev från Stadslass Sync P137']);
  const HISTORY_PROTOCOL = 'stadslass.mailbox.history.v1';
  const STATE_SCHEMA_VERSION = 1;
  const UNITS = Object.freeze(['189', 'mobile', 'dator']);
  const MAX_LOCAL_PROCESSED = 100;
  const MAX_LOCAL_OUTGOING = 50;
  const MAX_HISTORY = 10;
  const REQUEST_TIMEOUT_MS = 65000;

  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const plain = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const now = () => new Date().toISOString();
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function unitFromRole(role) {
    const value = text(role).toLowerCase();
    if (value === 'vehicle_189' || value === '189' || /(^|[_-])189($|[_-])/.test(value)) return '189';
    if (value === 'mobile' || value === 'mobil') return 'mobile';
    if (['computer', 'desktop', 'dator', 'web'].includes(value)) return 'dator';
    return '';
  }

  function labelForUnit(unit) {
    if (unit === '189') return '189';
    if (unit === 'mobile') return 'Mobil';
    if (unit === 'dator') return 'Dator';
    return 'Okänd';
  }

  function compactTimestamp(value) {
    const date = new Date(value);
    const safe = Number.isNaN(date.getTime()) ? new Date() : date;
    return safe.toISOString().replace(/[-:.]/g, '').replace('Z', 'Z');
  }

  function randomPart() {
    try {
      if (typeof crypto !== 'undefined' && crypto && typeof crypto.getRandomValues === 'function') {
        const values = new Uint32Array(2);
        crypto.getRandomValues(values);
        return `${values[0].toString(36)}${values[1].toString(36)}`;
      }
    } catch (_) {}
    return `${Math.random().toString(36).slice(2, 10)}${Math.random().toString(36).slice(2, 8)}`;
  }

  function uniqueId(prefix) {
    return `${prefix}-${Date.now().toString(36)}-${randomPart()}`;
  }

  function safeTechnicalText(value, max = 500) {
    let output = text(value).replace(/[\u0000-\u001f\u007f]/g, ' ');
    output = output
      .replace(/github_pat_[A-Za-z0-9_]+/gi, '[MASKERAT]')
      .replace(/gh[pousr]_[A-Za-z0-9]+/gi, '[MASKERAT]')
      .replace(/AIza[0-9A-Za-z_-]{20,100}/g, '[MASKERAT]')
      .replace(/Bearer\s+[A-Za-z0-9._~+\/-]+/gi, 'Bearer [MASKERAT]')
      .replace(/-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?-----END [^-]*PRIVATE KEY-----/gi, '[MASKERAT PRIVAT NYCKEL]');
    return output.slice(0, max);
  }

  function sanitize(value, key = '') {
    if (/token|authorization|password|secret|private|credential|cookie|sessionkey|api[-_]?key/i.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => sanitize(item));
    if (plain(value)) {
      const output = {};
      Object.entries(value).forEach(([name, item]) => { output[name] = sanitize(item, name); });
      return output;
    }
    if (typeof value === 'string') return safeTechnicalText(value, 1000);
    if (typeof value === 'number' || typeof value === 'boolean' || value === null) return value;
    return undefined;
  }

  function normalizeState(input = {}) {
    const source = plain(input) ? input : {};
    const counts = plain(source.counts) ? source.counts : {};
    const history = Array.isArray(source.letterHistory) ? source.letterHistory.slice(-MAX_HISTORY).map((item) => sanitize(item)).filter(Boolean) : [];
    const packageHistory = Array.isArray(source.packageHistory) ? source.packageHistory.slice(-MAX_HISTORY).map((item) => sanitize(item)).filter(Boolean) : [];
    const processed = Array.isArray(source.processedLetterIds) ? source.processedLetterIds.map(text).filter(Boolean).slice(-MAX_LOCAL_PROCESSED) : [];
    const outgoing = Array.isArray(source.outgoing) ? source.outgoing.filter(plain).map((item) => ({
      letterId: text(item.letterId),
      path: text(item.path),
      to: text(item.to),
      createdAt: text(item.createdAt),
      status: text(item.status, 'sent'),
      receiptId: text(item.receiptId),
      cleanupError: safeTechnicalText(item.cleanupError)
    })).filter((item) => item.letterId && item.path && UNITS.includes(item.to)).slice(-MAX_LOCAL_OUTGOING) : [];
    return {
      schemaVersion: STATE_SCHEMA_VERSION,
      processedLetterIds: processed,
      outgoing,
      letterHistory: history,
      packageHistory,
      counts: {
        manualFetchRuns: Math.max(0, Number(counts.manualFetchRuns) || 0),
        lettersCreated: Math.max(0, Number(counts.lettersCreated) || 0),
        lettersRead: Math.max(0, Number(counts.lettersRead) || 0),
        receiptsCreated: Math.max(0, Number(counts.receiptsCreated) || 0),
        receiptsReceived: Math.max(0, Number(counts.receiptsReceived) || 0),
        lettersDeleted: Math.max(0, Number(counts.lettersDeleted) || 0),
        receiptsDeleted: Math.max(0, Number(counts.receiptsDeleted) || 0),
        deletionErrors: Math.max(0, Number(counts.deletionErrors) || 0),
        duplicates: Math.max(0, Number(counts.duplicates) || 0),
        letterErrors: Math.max(0, Number(counts.letterErrors) || 0)
      },
      latestLetterId: text(source.latestLetterId),
      latestPath: text(source.latestPath),
      lastStatus: safeTechnicalText(source.lastStatus, 400),
      lastHistoryError: safeTechnicalText(source.lastHistoryError, 400)
    };
  }

  function normalizeMailboxUtf8String(value) {
    if (typeof value !== 'string' || value.length === 0) return value;
    if (typeof TextDecoder !== 'function' || typeof TextEncoder !== 'function') return value;
    const bytes = new Uint8Array(value.length);
    let hasHighByte = false;
    for (let index = 0; index < value.length; index += 1) {
      const code = value.charCodeAt(index);
      if (code > 255) return value;
      bytes[index] = code;
      if (code >= 128) hasHighByte = true;
    }
    if (!hasHighByte) return value;
    try {
      const decoded = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      if (decoded === value) return value;
      const encoded = new TextEncoder().encode(decoded);
      if (encoded.length !== bytes.length) return value;
      for (let index = 0; index < bytes.length; index += 1) {
        if (encoded[index] !== bytes[index]) return value;
      }
      return decoded;
    } catch (_) {
      return value;
    }
  }

  function normalizeMailboxResult(value) {
    if (Array.isArray(value)) return value.map((item) => normalizeMailboxResult(item));
    if (plain(value)) {
      const output = {};
      Object.entries(value).forEach(([name, item]) => { output[name] = normalizeMailboxResult(item); });
      return output;
    }
    if (typeof value === 'string') return normalizeMailboxUtf8String(value);
    return value;
  }

  function create(options = {}) {
    const host = options.host || null;
    const eventTarget = options.eventTarget || (typeof window !== 'undefined' ? window : null);
    const unitProvider = typeof options.unitProvider === 'function' ? options.unitProvider : () => '';
    const loadLocal = typeof options.loadLocal === 'function' ? options.loadLocal : () => ({});
    const persistLocal = typeof options.persistLocal === 'function' ? options.persistLocal : () => true;
    const onStateChange = typeof options.onStateChange === 'function' ? options.onStateChange : () => {};
    const onEvent = typeof options.onEvent === 'function' ? options.onEvent : () => {};
    const onAssignmentPackage = typeof options.onAssignmentPackage === 'function' ? options.onAssignmentPackage : async () => ({ status: 'validation-error', message: 'Uppdragsmottagaren saknas.' });
    const onAssignmentResult = typeof options.onAssignmentResult === 'function' ? options.onAssignmentResult : async () => {};
    let state = normalizeState(loadLocal());
    let fetchBusy = false;
    let sendChain = Promise.resolve();
    let disposed = false;
    const pending = new Map();

    function currentUnit() {
      const supplied = text(unitProvider());
      if (UNITS.includes(supplied)) return supplied;
      return unitFromRole(supplied);
    }

    function emitState() {
      try { onStateChange(snapshot()); } catch (_) {}
    }

    function saveLocal() {
      try {
        const ok = persistLocal(clone(state));
        if (ok === false) throw new Error('Lokalt Sync-läge kunde inte sparas.');
      } catch (error) {
        state.lastStatus = safeTechnicalText(error && error.message, 400) || 'Lokalt Sync-läge kunde inte sparas.';
      }
      emitState();
    }

    function snapshot() {
      return Object.freeze({
        ...clone(state),
        currentUnit: currentUnit(),
        currentUnitLabel: labelForUnit(currentUnit()),
        fetchBusy,
        automaticFetchEnabled: false,
        transportMode: 'manual',
        protocol: PROTOCOL,
        packageVersion: PACKAGE_VERSION
      });
    }

    function request(operation, path, extra = {}) {
      if (disposed) return Promise.reject(new Error('Sync-tjänsten är stängd.'));
      if (!host || typeof host.requestMailboxTransport !== 'function') return Promise.reject(new Error('Host22 mailboxtransport saknas.'));
      const requestId = uniqueId('mbx');
      const payload = { schemaVersion: 1, requestId, operation, path };
      if (operation === 'PUT') payload.contentUtf8 = String(extra.contentUtf8 || '');
      if (text(extra.expectedSha)) payload.expectedSha = text(extra.expectedSha);
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          pending.delete(requestId);
          reject(new Error('Mailbox-anropet nådde sin tidsgräns.'));
        }, REQUEST_TIMEOUT_MS);
        pending.set(requestId, { resolve, reject, timeout, operation, path });
        let immediate;
        try { immediate = JSON.parse(host.requestMailboxTransport(JSON.stringify(payload)) || '{}'); }
        catch (error) {
          clearTimeout(timeout); pending.delete(requestId); reject(error); return;
        }
        if (immediate.ok !== true || text(immediate.status) !== 'accepted') {
          clearTimeout(timeout); pending.delete(requestId);
          reject(Object.assign(new Error(safeTechnicalText(immediate.errorMessage || immediate.errorCode || immediate.status, 400) || 'Mailbox-anropet avvisades.'), { result: immediate }));
        }
      });
    }

    function handleMailboxResult(event) {
      const rawDetail = event && event.detail ? event.detail : event;
      const detail = normalizeMailboxResult(rawDetail || {});
      const requestId = text(detail && detail.requestId);
      if (!requestId || !pending.has(requestId)) return;
      const item = pending.get(requestId);
      pending.delete(requestId);
      clearTimeout(item.timeout);
      item.resolve(detail || {});
    }

    if (eventTarget && typeof eventTarget.addEventListener === 'function') {
      eventTarget.addEventListener('stadslass:mailbox-result', handleMailboxResult);
    }

    function requireOk(result, action) {
      if (result && result.ok === true) return result;
      const message = safeTechnicalText(result && (result.errorMessage || result.errorCode || result.status), 400) || `${action} misslyckades.`;
      throw Object.assign(new Error(message), { result });
    }

    function addProcessed(letterId) {
      const id = text(letterId);
      if (!id) return;
      state.processedLetterIds = state.processedLetterIds.filter((item) => item !== id);
      state.processedLetterIds.push(id);
      state.processedLetterIds = state.processedLetterIds.slice(-MAX_LOCAL_PROCESSED);
    }

    function outgoingRecord(letterId) {
      return state.outgoing.find((item) => item.letterId === text(letterId)) || null;
    }

    function upsertOutgoing(record) {
      const clean = normalizeState({ outgoing: [record] }).outgoing[0];
      if (!clean) return;
      state.outgoing = state.outgoing.filter((item) => item.letterId !== clean.letterId);
      state.outgoing.push(clean);
      state.outgoing = state.outgoing.slice(-MAX_LOCAL_OUTGOING);
    }

    function trimHistory(items) {
      return items.slice(-MAX_HISTORY);
    }

    function historyDocument(unit) {
      return {
        schemaVersion: 1,
        protocol: HISTORY_PROTOCOL,
        unit,
        updatedAt: now(),
        letterEvents: clone(trimHistory(state.letterHistory)),
        packageEvents: clone(trimHistory(state.packageHistory))
      };
    }

    async function persistRemoteHistory() {
      const unit = currentUnit();
      if (!unit) return;
      const path = `stadslass-sync/${unit}/posthistorik.json`;
      let sha = '';
      let remoteLetters = [];
      let remotePackages = [];
      const getResult = await request('GET', path).catch((error) => error && error.result ? error.result : ({ ok: false, status: 'network_error', errorMessage: error && error.message }));
      if (getResult.ok === true) {
        sha = text(getResult.sha);
        try {
          const remote = JSON.parse(String(getResult.contentUtf8 || '{}'));
          if (remote && remote.protocol === HISTORY_PROTOCOL && remote.unit === unit) {
            remoteLetters = Array.isArray(remote.letterEvents) ? remote.letterEvents : [];
            remotePackages = Array.isArray(remote.packageEvents) ? remote.packageEvents : [];
          }
        } catch (_) {}
      } else if (text(getResult.status) !== 'not_found') {
        throw new Error(safeTechnicalText(getResult.errorMessage || getResult.errorCode || getResult.status) || 'Posthistoriken kunde inte läsas.');
      }
      const merge = (remote, local) => {
        const byId = new Map();
        [...remote, ...local].forEach((item) => {
          if (!plain(item)) return;
          const key = text(item.eventId) || `${text(item.at)}:${text(item.type)}:${text(item.letterId)}:${text(item.path)}`;
          if (key) byId.set(key, sanitize(item));
        });
        return Array.from(byId.values()).sort((a, b) => text(a.at).localeCompare(text(b.at))).slice(-MAX_HISTORY);
      };
      state.letterHistory = merge(remoteLetters, state.letterHistory);
      state.packageHistory = merge(remotePackages, state.packageHistory);
      const content = JSON.stringify(historyDocument(unit), null, 2);
      const put = await request('PUT', path, { contentUtf8: content, expectedSha: sha });
      requireOk(put, 'Posthistoriken kunde inte sparas');
      state.lastHistoryError = '';
    }

    async function recordEvent(type, details = {}, options = {}) {
      const eventInput = {
        eventId: uniqueId('evt'),
        at: now(),
        unit: currentUnit(),
        type: text(type),
        letterId: text(details.letterId),
        packageId: text(details.packageId),
        from: text(details.from),
        to: text(details.to),
        status: text(details.status, 'ok'),
        path: text(details.path),
        error: safeTechnicalText(details.error, 500),
        payload: details.payload === undefined ? undefined : sanitize(details.payload)
      };
      if (Object.prototype.hasOwnProperty.call(details, 'transportStatus')) eventInput.transportStatus = text(details.transportStatus);
      if (Object.prototype.hasOwnProperty.call(details, 'httpStatus')) eventInput.httpStatus = Math.max(0, Number(details.httpStatus) || 0);
      if (Object.prototype.hasOwnProperty.call(details, 'errorCode')) eventInput.errorCode = safeTechnicalText(details.errorCode, 160);
      const event = sanitize(eventInput);
      state.letterHistory.push(event);
      state.letterHistory = trimHistory(state.letterHistory);
      if (text(details.letterId)) state.latestLetterId = text(details.letterId);
      if (text(details.path)) state.latestPath = text(details.path);
      state.lastStatus = safeTechnicalText(details.message || `${type}: ${event.status}`, 400);
      saveLocal();
      try { onEvent(clone(event)); } catch (_) {}
      if (options.remote !== false) {
        try { await persistRemoteHistory(); saveLocal(); }
        catch (error) { state.lastHistoryError = safeTechnicalText(error && error.message, 400); saveLocal(); }
      }
      return event;
    }

    function validateTestLetter(value, unit) {
      if (!plain(value)) throw new Error('Brevet är inte ett JSON-objekt.');
      if (value.protocol !== PROTOCOL) throw new Error('Brevet har fel protokoll.');
      if (value.kind !== 'test-letter') throw new Error('Brevet har okänd typ.');
      if (value.testOnly !== true) throw new Error('P137 tar endast emot syntetiska testbrev.');
      if (!text(value.letterId) || !UNITS.includes(text(value.from)) || text(value.to) !== unit) throw new Error('Brevet har fel avsändare, mottagare eller ID.');
      if (!Array.isArray(value.packageRefs) || value.packageRefs.length !== 0) throw new Error('P137 transporterar ännu inga paket.');
      if (!TEST_TEXTS.includes(safeTechnicalText(value.text, 200))) throw new Error('P137 accepterar endast fasta syntetiska P136/P137-testbrev.');
      return value;
    }

    function packagePath(letter, ref) {
      const path = text(ref && ref.path);
      const prefix = `stadslass-sync/${text(letter && letter.to)}/paket/`;
      if (!path || !path.startsWith(prefix) || !path.endsWith('.json') || path.includes('..')) throw new Error('Paketets sökväg är ogiltig.');
      return path;
    }
    function validatePackageLetter(value, unit) {
      if (!plain(value) || value.protocol !== PROTOCOL || value.kind !== 'package-letter') throw new Error('Paketbrevet har fel protokoll eller typ.');
      if (!text(value.letterId) || text(value.to) !== unit || !UNITS.includes(text(value.from))) throw new Error('Paketbrevet har fel avsändare, mottagare eller ID.');
      if (!Array.isArray(value.packageRefs) || value.packageRefs.length < 1 || value.packageRefs.length > 20) throw new Error('Paketbrevet saknar giltiga paketreferenser.');
      value.packageRefs.forEach((ref) => { if (!plain(ref) || text(ref.kind) !== 'assignment-package' || !text(ref.packageId)) throw new Error('Paketreferensen är ogiltig.'); packagePath(value, ref); });
      return value;
    }
    function validateAssignmentPackage(value, letter, ref) {
      if (!plain(value) || value.protocol !== PROTOCOL || value.packageProtocol !== 'stadslass.assignment.v1' || value.kind !== 'assignment-package') throw new Error('Uppdragspaketet har fel protokoll eller typ.');
      if (text(value.packageId) !== text(ref.packageId) || text(value.from) !== text(letter.from) || text(value.to) !== text(letter.to) || !plain(value.payload)) throw new Error('Uppdragspaketets identitet stämmer inte med brevet.');
      return value;
    }
    async function putJson(path, value, action) { const result = await request('PUT', path, { contentUtf8: JSON.stringify(value, null, 2) }); return requireOk(result, action); }
    async function sendAssignmentPackages(items, toUnit) {
      const from = currentUnit(), to = text(toUnit), createdAt = now();
      if (from !== 'mobile' || to !== '189' || !Array.isArray(items) || items.length < 1) throw new Error('Endast Mobil kan skicka minst ett uppdrag till 189.');
      const packageRefs = [];
      for (const item of items) {
        const packageId = uniqueId('package');
        const path = `stadslass-sync/189/paket/${compactTimestamp(createdAt)}_${packageId}.json`;
        const value = { protocol: PROTOCOL, packageProtocol: 'stadslass.assignment.v1', kind: 'assignment-package', packageId, from, to, createdAt: now(), sourcePlanningItemId: text(item && item.sourcePlanningItemId), payload: sanitize(item && item.payload) };
        if (!value.sourcePlanningItemId || !plain(value.payload)) throw new Error('Uppdraget saknar stabil planeringsidentitet eller payload.');
        try { await putJson(path, value, 'Uppdragspaketet kunde inte skickas'); packageRefs.push({ packageId, kind: 'assignment-package', path }); await recordEvent('package-created', { packageId, from, to, path, message: `Uppdragspaket ${packageId} skickat.` }); }
        catch (error) { await recordEvent('package-put-error', { packageId, from, to, path, status: 'error', error: error.message, message: `Uppdragspaket ${packageId} kunde inte skickas.` }); }
      }
      if (!packageRefs.length) throw new Error('Inget uppdragspaket kunde skickas; inget brev skapades.');
      const letterId = uniqueId('letter'); const letterPath = `stadslass-sync/189/brev/${compactTimestamp(createdAt)}_package_${letterId}.json`;
      const letter = { protocol: PROTOCOL, kind: 'package-letter', letterId, from, to, createdAt, packageRefs };
      await putJson(letterPath, letter, 'Paketbrevet kunde inte skickas');
      upsertOutgoing({ letterId, path: letterPath, to, createdAt, status: 'sent' }); state.counts.lettersCreated += 1; saveLocal();
      await recordEvent('package-letter-created', { letterId, from, to, path: letterPath, message: `${packageRefs.length} uppdragspaket skickades i ett brev.` });
      return { ok: true, letterId, packageRefs };
    }
    async function sendPackageReceipt(letter, ref, path) {
      const createdAt = now(), letterId = uniqueId('package-receipt'), receiptPathValue = `stadslass-sync/${text(letter.from)}/brev/${compactTimestamp(createdAt)}_package-receipt_${letterId}.json`;
      const receipt = { protocol: PROTOCOL, kind: 'package-receipt', letterId, receiptId: `package-receipt-${text(ref.packageId)}`, packageId: text(ref.packageId), from: text(letter.to), to: text(letter.from), originalFrom: text(letter.from), originalTo: text(letter.to), receivedBy: text(letter.to), receivedAt: createdAt, originalPath: path };
      await putJson(receiptPathValue, receipt, 'Paketkvittensen kunde inte skickas');
      upsertOutgoing({ letterId, path: receiptPathValue, to: text(letter.from), createdAt, status: 'sent' }); await recordEvent('package-receipt-created', { letterId, packageId: text(ref.packageId), from: receipt.from, to: receipt.to, path: receiptPathValue, message: 'Paketkvittens skapad.' });
    }
    async function processPackageReceipt(value, itemPath, sha) {
      if (!plain(value) || value.protocol !== PROTOCOL || value.kind !== 'package-receipt' || currentUnit() !== 'mobile' || text(value.to) !== 'mobile' || text(value.originalFrom) !== 'mobile' || text(value.originalTo) !== '189' || !text(value.packageId)) throw new Error('Paketkvittensen är ogiltig.');
      const path = text(value.originalPath), prefix = 'stadslass-sync/189/paket/'; if (!path.startsWith(prefix) || path.includes('..')) throw new Error('Paketkvittensen har ogiltig originalsökväg.');
      const original = await request('GET', path).catch((error) => error && error.result ? error.result : ({ ok: false, status: 'network_error' }));
      if (original.ok === true) { const parsed = JSON.parse(String(original.contentUtf8 || '{}')); if (text(parsed.packageId) !== text(value.packageId)) throw new Error('Paketkvittensen matchar inte originalpaketet.'); const expectedSha = text(original.sha); if (!expectedSha) throw new Error('Originalpaketet saknar SHA.'); requireOk(await request('DELETE', path, { expectedSha }), 'Originalpaketet kunde inte raderas'); await recordEvent('package-deleted', { packageId: text(value.packageId), path, message: 'Originalpaket raderat efter paketkvittens.' }); }
      else if (text(original.status) !== 'not_found') throw new Error('Originalpaketet kunde inte kontrolleras inför radering.');
      if (!text(sha)) throw new Error('Paketkvittensen saknar SHA.'); requireOk(await request('DELETE', itemPath, { expectedSha: text(sha) }), 'Paketkvittensen kunde inte raderas'); await recordEvent('package-receipt-received', { packageId: text(value.packageId), path: itemPath, message: 'Paketkvittens behandlad.' });
    }
    async function sendAssignmentResult(result) {
      const from = currentUnit(); if (from !== '189' || !plain(result) || !text(result.packageId)) throw new Error('Uppdragsresultatet är ogiltigt.');
      const createdAt = now(), letterId = uniqueId('result'), path = `stadslass-sync/mobile/brev/${compactTimestamp(createdAt)}_assignment-result_${letterId}.json`;
      const letter = { protocol: PROTOCOL, kind: 'assignment-result', letterId, from: '189', to: 'mobile', createdAt, ...sanitize(result) };
      await putJson(path, letter, 'Uppdragsresultatet kunde inte skickas'); upsertOutgoing({ letterId, path, to: 'mobile', createdAt, status: 'sent' });
      await recordEvent('assignment-result-created', { letterId, packageId: letter.packageId, from: '189', to: 'mobile', path, message: `Uppdragsresultat ${letter.status} skickat.` }); return { ok: true, letterId };
    }
    async function processPackageLetter(value, itemPath) {
      const letter = validatePackageLetter(value, currentUnit()); letter.__path = itemPath;
      if (!state.processedLetterIds.includes(letter.letterId)) { addProcessed(letter.letterId); state.counts.lettersRead += 1; saveLocal(); await recordEvent('package-letter-read', { letterId: letter.letterId, from: letter.from, to: letter.to, path: itemPath, message: 'Paketbrev läst.' }); }
      await ensureReceipt({ ...letter, testOnly: false });
      for (let index = 0; index < letter.packageRefs.length; index += 1) {
        const ref = letter.packageRefs[index], path = packagePath(letter, ref);
        try { const response = requireOk(await request('GET', path), 'Uppdragspaketet kunde inte hämtas'); const pkg = validateAssignmentPackage(JSON.parse(String(response.contentUtf8 || '')), letter, ref); const result = await onAssignmentPackage(clone(pkg), { letterId: letter.letterId, path, sha: text(response.sha) }); await sendPackageReceipt(letter, ref, path); await recordEvent('assignment-processed', { letterId: letter.letterId, packageId: pkg.packageId, path, status: text(result && result.status), message: text(result && result.message, 'Uppdragspaket behandlat.') }); if (currentUnit() === '189') await sendAssignmentResult({ packageId: pkg.packageId, sourcePlanningItemId: pkg.sourcePlanningItemId, status: text(result && result.status, 'validation-error'), reasonCode: text(result && result.reasonCode), message: text(result && result.message), plannedDate: text(pkg.payload.plannedDate), plannedTime: text(pkg.payload.plannedTime), packageReceivedAt: now() }); }
        catch (error) { await recordEvent('package-fetch-error', { letterId: letter.letterId, packageId: text(ref.packageId), path, status: 'error', error: error.message, message: 'Uppdragspaket kunde inte behandlas.' }); }
        if (index < letter.packageRefs.length - 1) await delay(1000);
      }
    }

    function validateReceipt(value, unit) {
      if (!plain(value)) throw new Error('Mottagningsbeviset är inte ett JSON-objekt.');
      if (value.protocol !== PROTOCOL || value.kind !== 'letter-receipt') throw new Error('Mottagningsbeviset har fel protokoll eller typ.');
      if (!text(value.receiptId) || !text(value.letterId)) throw new Error('Mottagningsbeviset saknar ID.');
      if (text(value.originalFrom) !== unit || text(value.to) !== unit) throw new Error('Mottagningsbeviset är inte adresserat till denna enhet.');
      if (!UNITS.includes(text(value.originalTo)) || text(value.receivedBy) !== text(value.originalTo)) throw new Error('Mottagningsbevisets mottagaruppgifter stämmer inte.');
      if (!text(value.originalPath).startsWith(`stadslass-sync/${text(value.originalTo)}/brev/`)) throw new Error('Mottagningsbevisets originalsökväg är ogiltig.');
      return value;
    }

    function receiptPath(letter) {
      return `stadslass-sync/${text(letter.from)}/brev/${compactTimestamp(letter.createdAt)}_receipt_${text(letter.letterId)}.json`;
    }

    async function ensureReceipt(letter) {
      const path = receiptPath(letter);
      const existing = await request('GET', path).catch((error) => error && error.result ? error.result : ({ ok: false, status: 'network_error', errorMessage: error && error.message }));
      if (existing.ok === true) {
        try {
          const value = JSON.parse(String(existing.contentUtf8 || '{}'));
          if (value.kind === 'letter-receipt' && value.letterId === letter.letterId && value.originalPath === letter.__path) return { created: false, path, receipt: value };
        } catch (_) {}
        throw new Error('En annan fil finns redan på mottagningsbevisets sökväg.');
      }
      if (text(existing.status) !== 'not_found') throw new Error(safeTechnicalText(existing.errorMessage || existing.errorCode || existing.status) || 'Mottagningsbevisets sökväg kunde inte kontrolleras.');
      const receipt = {
        protocol: PROTOCOL,
        kind: 'letter-receipt',
        testOnly: letter.kind === 'test-letter',
        receiptId: `receipt-${letter.letterId}`,
        letterId: letter.letterId,
        from: letter.to,
        to: letter.from,
        originalFrom: letter.from,
        originalTo: letter.to,
        receivedBy: letter.to,
        receivedAt: now(),
        originalPath: letter.__path,
        packageRefs: []
      };
      const put = await request('PUT', path, { contentUtf8: JSON.stringify(receipt, null, 2) });
      requireOk(put, 'Mottagningsbeviset kunde inte skapas');
      state.counts.receiptsCreated += 1;
      saveLocal();
      await recordEvent('receipt-created', { letterId: letter.letterId, from: letter.to, to: letter.from, path, payload: receipt, message: `Mottagningsbevis skapat för ${letter.letterId}` });
      return { created: true, path, receipt };
    }

    async function processTestLetter(value, itemPath) {
      const unit = currentUnit();
      const letter = validateTestLetter(value, unit);
      letter.__path = itemPath;
      if (state.processedLetterIds.includes(letter.letterId)) {
        state.counts.duplicates += 1;
        saveLocal();
        await recordEvent('duplicate-letter', { letterId: letter.letterId, from: letter.from, to: letter.to, path: itemPath, status: 'duplicate', message: `Dublettbrev ${letter.letterId} ignorerades.` });
        await ensureReceipt(letter);
        return;
      }
      addProcessed(letter.letterId);
      state.counts.lettersRead += 1;
      saveLocal();
      await recordEvent('letter-read', { letterId: letter.letterId, from: letter.from, to: letter.to, path: itemPath, payload: { ...letter, __path: undefined }, message: `Testbrev ${letter.letterId} mottaget och läst.` });
      await ensureReceipt(letter);
    }

    async function cleanupOriginalForReceipt(receipt, receiptPathValue, receiptSha) {
      const outgoing = outgoingRecord(receipt.letterId);
      if (!outgoing || outgoing.path !== receipt.originalPath || outgoing.to !== receipt.originalTo) throw new Error('Mottagningsbeviset matchar inget lokalt skickat brev.');
      state.counts.receiptsReceived += 1;
      outgoing.status = 'receipt-received';
      outgoing.receiptId = receipt.receiptId;
      upsertOutgoing(outgoing);
      saveLocal();
      await recordEvent('receipt-received', { letterId: receipt.letterId, from: receipt.from, to: receipt.to, path: receiptPathValue, payload: receipt, message: `Mottagningsbevis mottaget för ${receipt.letterId}.` });

      const original = await request('GET', receipt.originalPath).catch((error) => error && error.result ? error.result : ({ ok: false, status: 'network_error', errorMessage: error && error.message }));
      if (original.ok === true) {
        const sha = text(original.sha);
        if (!sha) throw new Error('Originalbrevet saknar verifierbar SHA.');
        const deleted = await request('DELETE', receipt.originalPath, { expectedSha: sha });
        requireOk(deleted, 'Originalbrevet kunde inte raderas');
        state.counts.lettersDeleted += 1;
        outgoing.status = 'completed';
        outgoing.cleanupError = '';
        upsertOutgoing(outgoing);
        saveLocal();
        await recordEvent('original-letter-deleted', { letterId: receipt.letterId, from: receipt.originalFrom, to: receipt.originalTo, path: receipt.originalPath, message: `Originalbrev ${receipt.letterId} raderat efter mottagningsbevis.` });
      } else if (text(original.status) === 'not_found') {
        outgoing.status = 'completed';
        outgoing.cleanupError = '';
        upsertOutgoing(outgoing);
        saveLocal();
        await recordEvent('original-letter-already-missing', { letterId: receipt.letterId, from: receipt.originalFrom, to: receipt.originalTo, path: receipt.originalPath, status: 'already_clean', message: `Originalbrev ${receipt.letterId} var redan raderat.` });
      } else {
        state.counts.deletionErrors += 1;
        outgoing.status = 'cleanup-pending';
        outgoing.cleanupError = safeTechnicalText(original.errorMessage || original.errorCode || original.status);
        upsertOutgoing(outgoing);
        saveLocal();
        throw new Error(outgoing.cleanupError || 'Originalbrevet kunde inte kontrolleras inför radering.');
      }

      const receiptShaSafe = text(receiptSha);
      if (!receiptShaSafe) throw new Error('Mottagningsbeviset saknar verifierbar SHA för städning.');
      const deletedReceipt = await request('DELETE', receiptPathValue, { expectedSha: receiptShaSafe });
      requireOk(deletedReceipt, 'Mottagningsbeviset kunde inte rensas');
      state.counts.receiptsDeleted += 1;
      saveLocal();
      await recordEvent('receipt-deleted', { letterId: receipt.letterId, from: receipt.from, to: receipt.to, path: receiptPathValue, message: `Mottagningsbevis för ${receipt.letterId} rensat.` });
    }

    async function processInboxItem(item) {
      const path = text(item && item.path);
      if (!path || path.endsWith('/.keep') || text(item && item.type) !== 'file') return;
      let getResult;
      try { getResult = requireOk(await request('GET', path), 'Brevet kunde inte hämtas'); }
      catch (error) {
        state.counts.letterErrors += 1; saveLocal();
        await recordEvent('letter-fetch-error', { path, status: 'error', error: error && error.message, message: `Kunde inte hämta ${path}.` });
        return;
      }
      let value;
      try { value = JSON.parse(String(getResult.contentUtf8 || '')); }
      catch (_) {
        state.counts.letterErrors += 1; saveLocal();
        await recordEvent('letter-json-error', { path, status: 'error', error: 'Skadad JSON', message: `Skadad JSON i ${path}.` });
        return;
      }
      try {
        if (value && value.kind === 'letter-receipt') {
          const receipt = validateReceipt(value, currentUnit());
          await cleanupOriginalForReceipt(receipt, path, text(getResult.sha));
        } else if (value && value.kind === 'package-letter') {
          await processPackageLetter(value, path);
        } else if (value && value.kind === 'package-receipt') {
          await processPackageReceipt(value, path, text(getResult.sha));
        } else if (value && value.kind === 'assignment-result') {
          if (text(value.to) !== currentUnit() || text(value.from) !== '189' || !text(value.packageId)) throw new Error('Uppdragsresultatet är ogiltigt.');
          await onAssignmentResult(clone(value)); addProcessed(text(value.letterId)); await ensureReceipt({ ...value, __path: path });
        } else {
          await processTestLetter(value, path);
        }
      } catch (error) {
        state.counts.letterErrors += 1;
        if (value && value.kind === 'letter-receipt') state.counts.deletionErrors += /rader|städ|originalbrev|SHA/i.test(text(error && error.message)) ? 1 : 0;
        saveLocal();
        await recordEvent('letter-processing-error', {
          letterId: text(value && value.letterId), from: text(value && value.from), to: text(value && value.to), path,
          status: 'error', error: error && error.message, payload: value && value.testOnly === true ? value : undefined,
          message: `Fel vid behandling av ${path}.`
        });
      }
    }

    async function fetchMail() {
      if (fetchBusy) return { ok: false, status: 'already_running' };
      const unit = currentUnit();
      if (!unit) return { ok: false, status: 'unknown_unit' };
      fetchBusy = true;
      state.counts.manualFetchRuns += 1;
      state.lastStatus = 'Hämtar post manuellt…';
      saveLocal();
      try {
        const path = `stadslass-sync/${unit}/brev`;
        let listing;
        try { listing = requireOk(await request('LIST', path), 'Brevlådan kunde inte listas'); }
        catch (error) {
          state.counts.letterErrors += 1; saveLocal();
          const transportResult = error && plain(error.result) ? error.result : {};
          await recordEvent('mailbox-list-error', {
            path, status: 'error',
            transportStatus: text(transportResult.status),
            httpStatus: Number(transportResult.httpStatus) || 0,
            errorCode: text(transportResult.errorCode),
            error: error && error.message,
            message: 'Brevlådan kunde inte listas.'
          });
          return { ok: false, status: 'list_failed' };
        }
        const items = (Array.isArray(listing.items) ? listing.items : [])
          .filter((item) => item && item.type === 'file' && text(item.name) !== '.keep' && text(item.name).endsWith('.json'))
          .sort((a, b) => text(a.name).localeCompare(text(b.name)));
        await recordEvent('mailbox-list-complete', { path, status: 'ok', message: `${items.length} brev hittades i ${labelForUnit(unit)}s brevlåda.` });
        for (let index = 0; index < items.length; index += 1) {
          await processInboxItem(items[index]);
          if (index < items.length - 1) await delay(1000);
        }
        state.lastStatus = items.length ? `Hämta post klar: ${items.length} brev behandlade.` : 'Hämta post klar: inga nya brev.';
        saveLocal();
        return { ok: true, status: 'completed', count: items.length };
      } finally {
        fetchBusy = false;
        saveLocal();
      }
    }

    function sendTestLetter(toUnit) {
      const unit = currentUnit();
      const to = text(toUnit);
      const createdAt = now();
      const letterId = uniqueId('letter');
      const letter = {
        protocol: PROTOCOL,
        kind: 'test-letter',
        testOnly: true,
        letterId,
        from: unit,
        to,
        createdAt,
        text: 'Testbrev från Stadslass Sync P137',
        packageRefs: []
      };
      const fileName = `${compactTimestamp(createdAt)}_test_${letterId}.json`;
      const path = UNITS.includes(to) ? `stadslass-sync/${to}/brev/${fileName}` : '';
      const task = async () => {
        if (!unit || !UNITS.includes(to)) throw new Error('Avsändare eller mottagare är ogiltig.');
        const put = await request('PUT', path, { contentUtf8: JSON.stringify(letter, null, 2) });
        requireOk(put, 'Testbrevet kunde inte skickas');
        state.counts.lettersCreated += 1;
        upsertOutgoing({ letterId, path, to, createdAt, status: 'sent' });
        saveLocal();
        await recordEvent('test-letter-created', { letterId, from: unit, to, path, payload: letter, message: `Testbrev ${letterId} skickat till ${labelForUnit(to)}.` });
        return { ok: true, letterId, path };
      };
      const result = sendChain.then(task, task);
      sendChain = result.catch(() => {});
      return result.catch(async (error) => {
        state.counts.letterErrors += 1; saveLocal();
        await recordEvent('test-letter-send-error', { letterId, from: unit, to, path, status: 'error', error: error && error.message, payload: letter, message: `Testbrev ${letterId} kunde inte skickas.` });
        throw error;
      });
    }

    function futureFunctionInterface() {
      return Object.freeze({
        requestData() { return { ok: false, status: 'not_connected_p137' }; },
        deliverData() { return { ok: false, status: 'not_connected_p137' }; }
      });
    }

    function dispose() {
      disposed = true;
      if (eventTarget && typeof eventTarget.removeEventListener === 'function') eventTarget.removeEventListener('stadslass:mailbox-result', handleMailboxResult);
      pending.forEach((item) => { clearTimeout(item.timeout); item.reject(new Error('Sync-tjänsten stängdes.')); });
      pending.clear();
    }

    return Object.freeze({
      PACKAGE_VERSION,
      PROTOCOL,
      UNITS,
      unitFromRole,
      labelForUnit,
      sendTestLetter,
      sendAssignmentPackages,
      sendAssignmentResult,
      fetchMail,
      state: snapshot,
      futureFunctionInterface,
      dispose
    });
  }

  window.StadslassMailboxSync = Object.freeze({ PACKAGE_VERSION, PROTOCOL, UNITS, unitFromRole, labelForUnit, create, sanitize });
})();
