(() => {
  'use strict';

  const SETTINGS_KEY = 'googleServiceV1';
  const SCHEMA_VERSION = 1;
  const SERVICE_VERSION = 1;
  const GEOCODING_ENDPOINT = 'https://maps.googleapis.com/maps/api/geocode/json';
  const DEFAULT_TIMEOUT_MS = 15000;
  const API_KEY_PATTERN = /^AIza[0-9A-Za-z_-]{20,100}$/;
  const PLUS_CODE_PATTERN = /^([23456789CFGHJMPQRVWX]{2,8}\+[23456789CFGHJMPQRVWX]{2,3})(?:\s+(.+))?$/i;
  const GEOCODING_STATUSES = Object.freeze([
    'not-requested',
    'pending',
    'resolved',
    'failed',
    'unavailable',
    'invalid-input'
  ]);

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedText(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    if (typeof value === 'string' && !value.trim()) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function validCoordinates(latitude, longitude) {
    const lat = optionalNumber(latitude);
    const lon = optionalNumber(longitude);
    return lat !== null && lon !== null && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
  }

  function normalizeSettings(value) {
    const source = isPlainObject(value) ? value : {};
    return {
      schemaVersion: SCHEMA_VERSION,
      apiKey: text(source.apiKey),
      updatedAt: text(source.updatedAt)
    };
  }

  function validateSettings(value) {
    const settings = normalizeSettings(value);
    if (settings.apiKey && !API_KEY_PATTERN.test(settings.apiKey)) {
      throw new Error('Google API-nyckeln har inte ett giltigt nyckelformat.');
    }
    return settings;
  }

  function maskApiKey(value) {
    const key = text(value);
    if (!key) return 'Ingen nyckel sparad';
    if (key.length <= 12) return `${key.slice(0, 4)}…`;
    return `${key.slice(0, 6)}…${key.slice(-4)}`;
  }

  function hasApiKey(value) {
    return API_KEY_PATTERN.test(text(value));
  }

  function inspectQuery(value) {
    const query = normalizedText(value);
    if (!query) {
      return { valid: false, query: '', code: 'EMPTY_QUERY', message: 'Adress / Plus Code saknas.' };
    }
    if (query.length > 300) {
      return { valid: false, query, code: 'QUERY_TOO_LONG', message: 'Adress / Plus Code får vara högst 300 tecken.' };
    }
    const plusCode = query.match(PLUS_CODE_PATTERN);
    if (plusCode) {
      const code = plusCode[1];
      const locality = normalizedText(plusCode[2]);
      const beforePlus = code.split('+')[0];
      if (beforePlus.length < 8 && !locality) {
        return {
          valid: false,
          query,
          code: 'SHORT_PLUS_CODE_NEEDS_LOCALITY',
          message: 'En kort Plus Code måste kompletteras med ort eller område.'
        };
      }
    }
    return { valid: true, query, code: '', message: '' };
  }

  function emptyGeocoding(source = {}) {
    const value = isPlainObject(source) ? source : {};
    return {
      schemaVersion: SCHEMA_VERSION,
      status: GEOCODING_STATUSES.includes(text(value.status)) ? text(value.status) : 'not-requested',
      query: normalizedText(value.query),
      formattedAddress: text(value.formattedAddress),
      latitude: optionalNumber(value.latitude),
      longitude: optionalNumber(value.longitude),
      lastAttemptAt: text(value.lastAttemptAt),
      resolvedAt: text(value.resolvedAt),
      errorCode: text(value.errorCode),
      errorMessage: text(value.errorMessage),
      source: text(value.source)
    };
  }

  function normalizeGeocoding(value, legacy = {}) {
    const source = emptyGeocoding(value);
    const legacyLatitude = optionalNumber(legacy.latitude);
    const legacyLongitude = optionalNumber(legacy.longitude);
    const latitude = source.latitude !== null ? source.latitude : legacyLatitude;
    const longitude = source.longitude !== null ? source.longitude : legacyLongitude;
    const hasCoordinates = validCoordinates(latitude, longitude);
    const query = source.query || normalizedText(legacy.query);
    let status = source.status;
    let resolvedAt = source.resolvedAt;
    let geocodingSource = source.source;

    if (hasCoordinates && status !== 'resolved') {
      status = 'resolved';
      resolvedAt = resolvedAt || text(legacy.resolvedAt) || text(legacy.timestamp);
      geocodingSource = geocodingSource || text(legacy.source) || 'legacy-existing';
    }
    if (!hasCoordinates && status === 'resolved') status = query ? 'pending' : 'not-requested';

    return {
      ...source,
      status,
      query,
      latitude: hasCoordinates ? latitude : null,
      longitude: hasCoordinates ? longitude : null,
      resolvedAt,
      source: geocodingSource
    };
  }

  function validateGeocoding(value) {
    const geocoding = normalizeGeocoding(value);
    if (geocoding.schemaVersion !== SCHEMA_VERSION) throw new Error('Geokodningsposten har en okänd schemaversion.');
    if (!GEOCODING_STATUSES.includes(geocoding.status)) throw new Error('Geokodningsposten har en ogiltig status.');
    if (geocoding.query.length > 300) throw new Error('Geokodningens söktext är för lång.');
    if ((geocoding.latitude !== null || geocoding.longitude !== null)
      && !validCoordinates(geocoding.latitude, geocoding.longitude)) {
      throw new Error('Geokodningens koordinater är ogiltiga.');
    }
    if (geocoding.status === 'resolved' && !validCoordinates(geocoding.latitude, geocoding.longitude)) {
      throw new Error('En löst geokodning måste ha giltiga koordinater.');
    }
    return geocoding;
  }

  function needsGeocoding(currentGeocoding, nextAddressOrPlusCode) {
    const nextQuery = normalizedText(nextAddressOrPlusCode);
    if (!nextQuery) return false;
    const current = normalizeGeocoding(currentGeocoding);
    if (current.query !== nextQuery) return true;
    return !validCoordinates(current.latitude, current.longitude);
  }

  function pendingGeocoding(currentGeocoding, nextAddressOrPlusCode, timestamp = new Date().toISOString()) {
    const current = normalizeGeocoding(currentGeocoding);
    const query = normalizedText(nextAddressOrPlusCode);
    if (!query) {
      return {
        ...current,
        status: 'not-requested',
        query: '',
        formattedAddress: '',
        latitude: null,
        longitude: null,
        lastAttemptAt: '',
        resolvedAt: '',
        errorCode: '',
        errorMessage: '',
        source: ''
      };
    }
    if (!needsGeocoding(current, query)) return current;
    return {
      ...current,
      status: 'pending',
      query,
      formattedAddress: '',
      latitude: null,
      longitude: null,
      lastAttemptAt: timestamp,
      resolvedAt: '',
      errorCode: '',
      errorMessage: '',
      source: 'google-geocoding'
    };
  }

  function failedGeocoding(currentGeocoding, queryValue, code, message, status = 'failed', timestamp = new Date().toISOString()) {
    const current = normalizeGeocoding(currentGeocoding);
    const normalizedStatus = GEOCODING_STATUSES.includes(status) ? status : 'failed';
    return {
      ...current,
      status: normalizedStatus,
      query: normalizedText(queryValue),
      formattedAddress: '',
      latitude: null,
      longitude: null,
      lastAttemptAt: timestamp,
      resolvedAt: '',
      errorCode: text(code) || 'GEOCODING_FAILED',
      errorMessage: text(message) || 'Koordinater kunde inte hämtas.',
      source: 'google-geocoding'
    };
  }

  function resolvedGeocoding(currentGeocoding, result, timestamp = new Date().toISOString()) {
    const current = normalizeGeocoding(currentGeocoding);
    const value = isPlainObject(result) ? result : {};
    if (!validCoordinates(value.latitude, value.longitude)) throw new Error('Google-resultatet saknar giltiga koordinater.');
    return {
      ...current,
      status: 'resolved',
      query: normalizedText(value.query) || current.query,
      formattedAddress: text(value.formattedAddress),
      latitude: Number(value.latitude),
      longitude: Number(value.longitude),
      lastAttemptAt: timestamp,
      resolvedAt: timestamp,
      errorCode: '',
      errorMessage: '',
      source: 'google-geocoding'
    };
  }

  function apiStatusMessage(status, fallbackMessage) {
    const fallback = text(fallbackMessage);
    if (status === 'ZERO_RESULTS') return 'Google hittade ingen plats för Adress / Plus Code.';
    if (status === 'REQUEST_DENIED') return 'Google nekade geokodningsanropet. Kontrollera den befintliga API-nyckelns begränsningar.';
    if (status === 'OVER_DAILY_LIMIT') return 'Google-kontots geokodningsgräns eller fakturering tillåter inte anropet.';
    if (status === 'OVER_QUERY_LIMIT') return 'Google Geocoding har tillfälligt nått sin anropsgräns.';
    if (status === 'INVALID_REQUEST') return 'Google bedömde Adress / Plus Code som ofullständig.';
    if (status === 'UNKNOWN_ERROR') return 'Google kunde inte slutföra geokodningen just nu.';
    return fallback || 'Koordinater kunde inte hämtas från Google.';
  }

  async function geocode(addressOrPlusCode, apiKey, options = {}) {
    const queryInspection = inspectQuery(addressOrPlusCode);
    if (!queryInspection.valid) {
      const error = new Error(queryInspection.message);
      error.code = queryInspection.code;
      error.kind = 'invalid-input';
      throw error;
    }
    const key = text(apiKey);
    if (!hasApiKey(key)) {
      const error = new Error('En aktiv Google API-nyckel måste sparas under Inställningar innan koordinater kan hämtas.');
      error.code = 'API_KEY_MISSING';
      error.kind = 'unavailable';
      throw error;
    }

    const timeoutMs = Number.isFinite(Number(options.timeoutMs)) && Number(options.timeoutMs) > 0
      ? Number(options.timeoutMs)
      : DEFAULT_TIMEOUT_MS;
    const fetchImpl = typeof options.fetchImpl === 'function' ? options.fetchImpl : window.fetch.bind(window);
    const abortController = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = abortController ? window.setTimeout(() => abortController.abort(), timeoutMs) : null;
    const url = new URL(GEOCODING_ENDPOINT);
    url.searchParams.set('address', queryInspection.query);
    url.searchParams.set('key', key);
    url.searchParams.set('language', 'sv');
    url.searchParams.set('region', 'se');

    try {
      const response = await fetchImpl(url.toString(), {
        method: 'GET',
        cache: 'no-store',
        credentials: 'omit',
        referrerPolicy: 'no-referrer',
        signal: abortController ? abortController.signal : undefined
      });
      if (!response || response.ok !== true) {
        const error = new Error(`Google Geocoding svarade med HTTP ${response ? response.status : 'okänd status'}.`);
        error.code = response ? `HTTP_${response.status}` : 'HTTP_ERROR';
        error.kind = 'failed';
        throw error;
      }
      const payload = await response.json();
      const status = text(payload && payload.status);
      if (status !== 'OK') {
        const error = new Error(apiStatusMessage(status, payload && payload.error_message));
        error.code = status || 'GOOGLE_STATUS_MISSING';
        error.kind = status === 'INVALID_REQUEST' ? 'invalid-input' : 'failed';
        throw error;
      }
      const results = Array.isArray(payload.results) ? payload.results : [];
      const selected = results.find((item) => isPlainObject(item)
        && isPlainObject(item.geometry)
        && isPlainObject(item.geometry.location)
        && validCoordinates(item.geometry.location.lat, item.geometry.location.lng));
      if (!selected) {
        const error = new Error('Google-resultatet saknade giltiga koordinater.');
        error.code = 'RESULT_COORDINATES_MISSING';
        error.kind = 'failed';
        throw error;
      }
      return {
        query: queryInspection.query,
        formattedAddress: text(selected.formatted_address),
        latitude: Number(selected.geometry.location.lat),
        longitude: Number(selected.geometry.location.lng)
      };
    } catch (error) {
      if (error && error.name === 'AbortError') {
        const timeoutError = new Error('Google-geokodningen tog för lång tid och avbröts. Platsen är sparad utan nya koordinater.');
        timeoutError.code = 'TIMEOUT';
        timeoutError.kind = 'unavailable';
        throw timeoutError;
      }
      if (error && (error.code || error.kind)) throw error;
      const networkError = new Error('Google-geokodningen kunde inte nå internet. Platsen är sparad utan nya koordinater.');
      networkError.code = 'NETWORK_ERROR';
      networkError.kind = 'unavailable';
      throw networkError;
    } finally {
      if (timer !== null) window.clearTimeout(timer);
    }
  }

  window.StadslassGoogleService = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    SERVICE_VERSION,
    GEOCODING_ENDPOINT,
    GEOCODING_STATUSES,
    normalizeSettings,
    validateSettings,
    maskApiKey,
    hasApiKey,
    inspectQuery,
    validCoordinates,
    normalizeGeocoding,
    validateGeocoding,
    needsGeocoding,
    pendingGeocoding,
    failedGeocoding,
    resolvedGeocoding,
    geocode
  });
})();
