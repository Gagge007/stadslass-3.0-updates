(() => {
  'use strict';

  const PACKAGE_VERSION = 3;
  const SETTINGS_STORE = 'settings';
  let pollTimer = null;

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function parseObject(raw, fallback) {
    try {
      const value = JSON.parse(raw);
      return value && typeof value === 'object' ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function loadSettings() {
    const raw = window.StadslassHost.readStore(SETTINGS_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Inställningslagret kunde inte läsas.');
    }
    const settings = parseObject(raw, {});
    const value = Number.isInteger(settings.moduleTestValue) && settings.moduleTestValue >= 0
      ? settings.moduleTestValue
      : 0;
    byId('module-test-value').textContent = String(value);
    byId('storage-status').textContent = 'Endast inställningslagret lästes vid start. Övriga fyra lager är orörda.';
    return settings;
  }

  function incrementTestValue() {
    const settings = loadSettings();
    const current = Number.isInteger(settings.moduleTestValue) ? settings.moduleTestValue : 0;
    settings.moduleTestValue = current + 1;
    settings.updatedByPackageVersion = PACKAGE_VERSION;
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(settings));
    if (!saved) {
      byId('storage-status').textContent = window.StadslassHost.getLastError() || 'Testvärdet kunde inte sparas.';
      return;
    }
    byId('module-test-value').textContent = String(settings.moduleTestValue);
    byId('storage-status').textContent = 'Testvärdet sparades atomiskt i det separata inställningslagret.';
  }

  function refreshUpdateStatus() {
    byId('update-status').textContent = window.StadslassHost.getUpdateStatus();
  }

  function requestUpdate() {
    window.StadslassHost.requestUpdateCheck();
    refreshUpdateStatus();
    if (pollTimer !== null) {
      window.clearInterval(pollTimer);
    }
    pollTimer = window.setInterval(refreshUpdateStatus, 1000);
    window.setTimeout(() => {
      if (pollTimer !== null) {
        window.clearInterval(pollTimer);
        pollTimer = null;
      }
      refreshUpdateStatus();
    }, 20000);
  }

  function start() {
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    const cssMarker = getComputedStyle(document.documentElement)
      .getPropertyValue('--module-style-ready').trim();
    if (cssMarker !== '1') {
      throw new Error('CSS-filen kunde inte verifieras.');
    }

    const info = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!info || info.hostVersionCode < 4 || info.packageVersion !== PACKAGE_VERSION) {
      throw new Error('Värd- eller paketversionen stämmer inte.');
    }

    byId('host-version').textContent = `${info.hostVersionName} (${info.hostVersionCode})`;
    byId('package-version').textContent = String(info.packageVersion);
    byId('role').textContent = info.roleLabel || info.role || 'Okänd';
    byId('device-id').textContent = info.deviceId || 'Saknas';
    byId('summary').textContent = 'HTML, CSS och JavaScript körs lokalt från ett SHA-256- och RSA-verifierat paket.';
    byId('runtime-status').textContent = 'HTML, CSS, JavaScript och den begränsade värdbryggan är verifierade.';

    loadSettings();
    refreshUpdateStatus();
    byId('increment-test').addEventListener('click', incrementTestValue);
    byId('check-update').addEventListener('click', requestUpdate);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());

    window.StadslassHost.markReady(PACKAGE_VERSION);
  }

  document.addEventListener('DOMContentLoaded', () => {
    try {
      start();
    } catch (error) {
      byId('summary').textContent = 'Verifieringspaketet kunde inte starta.';
      byId('runtime-status').textContent = error instanceof Error ? error.message : String(error);
    }
  });
})();
