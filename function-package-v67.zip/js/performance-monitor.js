(() => {
  'use strict';

  // A new automatic period must never resume a manually stopped v66 period.
  // Keep the old IndexedDB archive so historical reports remain available.
  const ACTIVE_KEY = 'stadslass.performance.v67.active';
  const CURRENT_KEY = 'stadslass.performance.v67.current';
  const DB_NAME = 'stadslass-performance-v66';
  const DB_VERSION = 1;
  const MAX_DURATION_MS = 8 * 60 * 60 * 1000;
  const MAX_EVENTS = 1200;
  const MAX_BYTES = 350 * 1024;
  const MAX_DETAIL_REPORTS = 40;
  const MAX_SUMMARIES = 500;
  const CHECKPOINT_INTERVAL_MS = 5000;
  const sensitive = /token|authorization|password|secret|apikey|googlekey|privatekey|credential|bearer|keystore|mail|address|comment|note/i;
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const now = () => new Date().toISOString();
  const monotonic = () => typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
  const bytes = (value) => new TextEncoder().encode(String(value || '')).length;
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const percentile = (values, percent) => {
    if (!values.length) return 0;
    const ordered = values.slice().sort((a, b) => a - b);
    return ordered[Math.min(ordered.length - 1, Math.ceil((percent / 100) * ordered.length) - 1)];
  };

  function sanitize(value, depth = 0) {
    if (depth > 8) return '[truncated]';
    if (Array.isArray(value)) return value.slice(0, 40).map((item) => sanitize(item, depth + 1));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).slice(0, 40).map(([key, item]) => [key, sensitive.test(key) ? '[redacted]' : sanitize(item, depth + 1)]));
    if (typeof value === 'string') return /(?:ghp_|github_pat_|Bearer\s+)/i.test(value) ? '[redacted]' : value.slice(0, 180);
    return value;
  }

  function readLocal(key, fallback) {
    try { const value = JSON.parse(localStorage.getItem(key) || ''); return value && typeof value === 'object' ? value : fallback; } catch (_) { return fallback; }
  }

  function writeLocal(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch (_) { return false; }
  }

  function removeLocal(key) { try { localStorage.removeItem(key); } catch (_) {} }

  function openDb() {
    if (!window.indexedDB) return Promise.resolve(null);
    return new Promise((resolve) => {
      try {
        const request = window.indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains('reports')) db.createObjectStore('reports', { keyPath: 'id' });
          if (!db.objectStoreNames.contains('summaries')) db.createObjectStore('summaries', { keyPath: 'id' });
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => resolve(null);
      } catch (_) { resolve(null); }
    });
  }

  async function dbAll(storeName) {
    const db = await openDb();
    if (!db) return [];
    return new Promise((resolve) => {
      try {
        const request = db.transaction(storeName, 'readonly').objectStore(storeName).getAll();
        request.onsuccess = () => { db.close(); resolve(Array.isArray(request.result) ? request.result : []); };
        request.onerror = () => { db.close(); resolve([]); };
      } catch (_) { try { db.close(); } catch (_) {} resolve([]); }
    });
  }

  async function dbPut(storeName, value) {
    const db = await openDb();
    if (!db) return false;
    return new Promise((resolve) => {
      try {
        const request = db.transaction(storeName, 'readwrite').objectStore(storeName).put(value);
        request.onsuccess = () => { db.close(); resolve(true); };
        request.onerror = () => { db.close(); resolve(false); };
      } catch (_) { try { db.close(); } catch (_) {} resolve(false); }
    });
  }

  async function dbDelete(storeName, ids) {
    const db = await openDb();
    if (!db || !ids.length) return false;
    return new Promise((resolve) => {
      try {
        const transaction = db.transaction(storeName, 'readwrite');
        ids.forEach((id) => transaction.objectStore(storeName).delete(id));
        transaction.oncomplete = () => { db.close(); resolve(true); };
        transaction.onerror = () => { db.close(); resolve(false); };
      } catch (_) { try { db.close(); } catch (_) {} resolve(false); }
    });
  }

  function create(context = {}) {
    let current = null;
    let saveTimer = null;
    let longTaskObserver = null;
    let loopTimer = null;
    const info = () => sanitize(typeof context.context === 'function' ? context.context() : {});
    const active = () => current && current.active === true;
    const eventIsCritical = (event) => event && (event.level === 'error' || event.level === 'critical' || event.durationMs >= 1000 || event.type === 'event-loop-delay');

    function state() {
      if (!current) return { status: 'Av', active: false };
      return { status: active() ? 'Övervakar' : 'Klar', active: active(), startedAt: current.startedAt, events: current.events.length, rotated: current.rotated === true, lastError: text(current.lastError), id: current.id };
    }

    function scheduleCheckpoint() {
      if (!active() || saveTimer !== null) return;
      saveTimer = window.setTimeout(() => { saveTimer = null; checkpoint(); }, CHECKPOINT_INTERVAL_MS);
    }

    function checkpoint() {
      if (!active()) return false;
      current.lastCheckpointAt = now();
      writeLocal(ACTIVE_KEY, { id: current.id, startedAt: current.startedAt, lastCheckpointAt: current.lastCheckpointAt, packageVersion: current.packageVersion, hostVersion: current.hostVersion });
      return writeLocal(CURRENT_KEY, current);
    }

    function rotateIfNeeded() {
      let total = Number(current.eventBytes) || 0;
      while (current.events.length > MAX_EVENTS || total > MAX_BYTES) {
        const index = current.events.findIndex((event) => !eventIsCritical(event));
        if (index < 0) break;
        total -= Number(current.events[index].bytes) || 0;
        current.events.splice(index, 1);
        current.rotated = true;
      }
      current.eventBytes = Math.max(0, total);
    }

    function record(type, details = {}, durationMs = 0, level = '') {
      if (!active()) return null;
      const event = { at: now(), type: text(type, 'event'), durationMs: Math.max(0, Math.round(Number(durationMs) || 0)), level: text(level), details: sanitize({ ...info(), ...details }) };
      if (!event.level && event.durationMs > 1000) event.level = 'slow';
      if (event.durationMs > 5000) event.level = 'critical';
      event.bytes = bytes(JSON.stringify(event));
      current.events.push(event);
      current.eventBytes = (Number(current.eventBytes) || 0) + event.bytes;
      if (event.level === 'error') current.lastError = text(details && details.errorCode, event.type);
      current.lastSuccess = event.level === 'error' ? current.lastSuccess : event.type;
      rotateIfNeeded();
      scheduleCheckpoint();
      return event;
    }

    function measure(type, details = {}) {
      const started = monotonic();
      return (more = {}, level = '') => record(type, { ...details, ...more }, monotonic() - started, level);
    }

    function summary(report) {
      const grouped = new Map();
      report.events.filter((event) => Number(event.durationMs) > 0).forEach((event) => {
        const values = grouped.get(event.type) || [];
        values.push(Number(event.durationMs)); grouped.set(event.type, values);
      });
      const metrics = Array.from(grouped.entries()).map(([type, values]) => ({ type, count: values.length, medianMs: Math.round(percentile(values, 50)), averageMs: Math.round(values.reduce((total, value) => total + value, 0) / values.length), p95Ms: Math.round(percentile(values, 95)), maxMs: Math.round(Math.max(...values)) }));
      return { id: report.id, startedAt: report.startedAt, endedAt: report.endedAt, durationMs: report.durationMs, endReason: report.endReason, device: report.device, roles: report.roles, packageVersion: report.packageVersion, hostVersion: report.hostVersion, eventCount: report.events.length, problemCount: report.events.filter(eventIsCritical).length, rotated: report.rotated === true, metrics };
    }

    async function rotateHistory() {
      const reports = (await dbAll('reports')).sort((a, b) => text(a.endedAt).localeCompare(text(b.endedAt)));
      const summaries = (await dbAll('summaries')).sort((a, b) => text(a.endedAt).localeCompare(text(b.endedAt)));
      await dbDelete('reports', reports.slice(0, Math.max(0, reports.length - MAX_DETAIL_REPORTS)).map((report) => report.id));
      await dbDelete('summaries', summaries.slice(0, Math.max(0, summaries.length - MAX_SUMMARIES)).map((item) => item.id));
    }

    async function archive(reason = 'manual-stop') {
      if (!current) return null;
      const endedAt = now();
      const report = { ...clone(current), active: false, endedAt, endReason: reason, durationMs: Math.max(0, Date.parse(endedAt) - Date.parse(current.startedAt)), lastCheckpointAt: endedAt };
      report.periodSummary = summary(report);
      current = null;
      if (saveTimer !== null) { window.clearTimeout(saveTimer); saveTimer = null; }
      stopObservers();
      removeLocal(ACTIVE_KEY); removeLocal(CURRENT_KEY);
      try { await dbPut('reports', report); await dbPut('summaries', report.periodSummary); await rotateHistory(); } catch (_) {}
      return report;
    }

    function stopObservers() {
      if (longTaskObserver) { try { longTaskObserver.disconnect(); } catch (_) {} longTaskObserver = null; }
      if (loopTimer !== null) { window.clearInterval(loopTimer); loopTimer = null; }
    }

    function startObservers() {
      stopObservers();
      if (typeof window.PerformanceObserver === 'function') {
        try {
          longTaskObserver = new window.PerformanceObserver((list) => list.getEntries().forEach((entry) => record('long-task', { name: text(entry.name, 'longtask') }, entry.duration, entry.duration >= 1000 ? 'critical' : 'slow')));
          longTaskObserver.observe({ entryTypes: ['longtask'] });
        } catch (_) { longTaskObserver = null; }
      }
      let expected = monotonic() + 1000;
      loopTimer = window.setInterval(() => {
        const actual = monotonic(); const delay = actual - expected; expected = actual + 1000;
        if (delay > 500) record('event-loop-delay', {}, delay, delay > 1000 ? 'critical' : 'slow');
      }, 1000);
    }

    function start() {
      if (active()) return state();
      const contextValue = info();
      current = { schemaVersion: 1, id: `performance-${Date.now().toString(36)}`, active: true, startedAt: now(), lastCheckpointAt: now(), packageVersion: Number(contextValue.packageVersion) || 67, hostVersion: text(contextValue.hostVersion), device: text(contextValue.device, 'local'), roles: [text(contextValue.role, 'unknown')], events: [], eventBytes: 0, rotated: false, lastSuccess: '', lastError: '' };
      record('monitor-started'); checkpoint(); startObservers(); return state();
    }

    async function resume() {
      const marker = readLocal(ACTIVE_KEY, null); const saved = readLocal(CURRENT_KEY, null);
      if (!marker || !saved || saved.active !== true || !text(saved.id)) return state();
      current = saved;
      const elapsed = Date.now() - Date.parse(current.startedAt);
      if (!Number.isFinite(elapsed) || elapsed >= MAX_DURATION_MS) return archive('eight-hour-limit-on-start');
      const gap = Math.max(0, Date.now() - Date.parse(text(current.lastCheckpointAt, current.startedAt)));
      record('app-resumed', { gapMs: gap }); checkpoint(); startObservers(); return state();
    }

    async function stop(reason = 'manual-stop') { return archive(reason); }
    async function history() { return (await dbAll('summaries')).sort((a, b) => text(b.endedAt).localeCompare(text(a.endedAt))); }
    async function report(id) { return (await dbAll('reports')).find((item) => text(item.id) === text(id)) || null; }
    async function clearHistory() { const reports = await dbAll('reports'); const summaries = await dbAll('summaries'); await dbDelete('reports', reports.map((item) => item.id)); await dbDelete('summaries', summaries.map((item) => item.id)); return true; }
    async function removeReport(id) { await dbDelete('reports', [id]); await dbDelete('summaries', [id]); return true; }
    function textReport(report) {
      const source = report || current; if (!source) throw new Error('Ingen prestandarapport finns.');
      const details = source.periodSummary || summary(source);
      const lines = ['STADSLASS PRESTANDARAPPORT', `Start: ${source.startedAt}`, `Slut: ${source.endedAt || now()}`, `Enhet: ${text(source.device)}`, `Roller: ${(source.roles || []).join(', ')}`, `Funktionspaket: ${source.packageVersion}`, `Värdapp: ${text(source.hostVersion)}`, `Orsak: ${text(source.endReason, source.active ? 'pågår' : 'okänd')}`, `Händelser: ${(source.events || []).length}`, `Rotation: ${source.rotated === true ? 'Ja' : 'Nej'}`, '', 'SAMMANSTÄLLNING'];
      (details.metrics || []).forEach((metric) => lines.push(`${metric.type}: antal ${metric.count}, median ${metric.medianMs} ms, medel ${metric.averageMs} ms, p95 ${metric.p95Ms} ms, långsammast ${metric.maxMs} ms`));
      lines.push('', 'HÄNDELSER');
      (source.events || []).forEach((event) => lines.push(`${event.at} | ${event.type} | ${event.durationMs} ms | ${event.level || '-'} | ${JSON.stringify(sanitize(event.details || {}))}`));
      return lines.join('\n') + '\n';
    }
    return Object.freeze({ start, resume, stop, state, record, measure, checkpoint, history, report, removeReport, clearHistory, textReport, constants: Object.freeze({ MAX_DURATION_MS, MAX_EVENTS, MAX_BYTES, MAX_DETAIL_REPORTS, MAX_SUMMARIES }) });
  }

  window.StadslassPerformanceMonitor = Object.freeze({ create, sanitize, constants: Object.freeze({ MAX_DURATION_MS, MAX_EVENTS, MAX_BYTES, MAX_DETAIL_REPORTS, MAX_SUMMARIES }) });
})();
