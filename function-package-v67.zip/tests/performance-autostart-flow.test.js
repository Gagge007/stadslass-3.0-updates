'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(root, 'js', 'app.js'), 'utf8');
const monitorScript = html.indexOf('js/performance-monitor.js');
assert(monitorScript >= 0);
assert(monitorScript < html.indexOf('js/watchdog.js'));
assert(monitorScript < html.indexOf('js/app.js'));

const startAt = app.indexOf('function start()');
const automaticStartAt = app.indexOf('earlyMonitor.start()', startAt);
const verifyAt = app.indexOf('verifyRuntime();', startAt);
const settingsAt = app.indexOf('readSettingsDocument()', startAt);
const syncAt = app.indexOf('syncV63SyncNow', startAt);
assert(startAt >= 0 && automaticStartAt > startAt);
assert(automaticStartAt < verifyAt, 'monitor must start before verification');
assert(automaticStartAt < settingsAt, 'monitor must start before role/settings restoration');
assert(automaticStartAt < syncAt, 'monitor must start before sync');
assert(app.includes("performanceEvent('function-package-bootstrap', { automatic: true, order: 'first-package-action' })"));
assert(!app.includes('performanceMonitor.resume()'));
console.log('PASS performance-autostart-flow.test.js (10 assertions)');
