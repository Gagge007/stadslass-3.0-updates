(() => {
  'use strict';
  const MAX_TEXT_ATTACHMENT_BYTES = 2 * 1024 * 1024;
  const MAX_EXCEL_ATTACHMENT_BYTES = 12 * 1024 * 1024;
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const bytes = (value) => new TextEncoder().encode(String(value || '')).length;
  const email = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(value));
  const safeFileName = (value, extension) => {
    const name = text(value);
    return name && name.length <= 120 && !name.includes('..') && !/[\\/\u0000-\u001f\u007f]/.test(name) && name.toLowerCase().endsWith(extension) ? name : '';
  };
  function validateAttachment(attachment) {
    if (!attachment || typeof attachment !== 'object') throw new Error('Rapportbilagan är ogiltig.');
    const mimeType = text(attachment.mimeType);
    const content = text(attachment.contentUtf8);
    if (!content) throw new Error('Rapportbilagan saknar innehåll.');
    if (mimeType === 'text/plain' && safeFileName(attachment.fileName, '.txt')) {
      if (bytes(content) > MAX_TEXT_ATTACHMENT_BYTES) throw new Error('Rapportfilen är för stor för mailutkastet.');
      return attachment;
    }
    if (mimeType === 'application/vnd.ms-excel' && safeFileName(attachment.fileName, '.xls')) {
      if (bytes(content) > MAX_EXCEL_ATTACHMENT_BYTES) throw new Error('Excel-filen är för stor för mailutkastet.');
      return attachment;
    }
    throw new Error('Rapportbilagan har fel filtyp. Endast rapportfil (.txt) och Excel (.xls) stöds.');
  }
  function validate(draft) {
    const value = draft && typeof draft === 'object' ? draft : {};
    if (!email(value.recipient) || !text(value.subject) || !text(value.body)) throw new Error('Mailunderlaget saknar giltig mottagare, ämne eller text.');
    const attachment = value.attachment === null || value.attachment === undefined ? null : value.attachment;
    if (attachment) validateAttachment(attachment);
    return { mailType: text(value.mailType, 'general'), recipient: text(value.recipient), subject: String(value.subject), body: String(value.body), attachment };
  }
  function open(draft, hostInfo) {
    const value = validate(draft);
    const host = window.StadslassHost;
    if (!host || typeof host.openEmailDraftWithAttachment !== 'function' || Number(hostInfo && hostInfo.emailDraftApiVersion) < 2) {
      if (value.attachment) throw new Error('Den här installationen saknar stöd för rapportfil och bilaga.');
      if (!host || typeof host.openEmailDraft !== 'function') throw new Error('Startappens mailbrygga saknas.');
      const legacy = JSON.parse(host.openEmailDraft(value.recipient, value.subject, value.body));
      if (!legacy || legacy.ok !== true || legacy.status !== 'opened') throw new Error('Mailutkast kunde inte öppnas.');
      return { ...legacy, status: 'opened_mail_app', legacy: true };
    }
    const request = { schemaVersion: 1, requestId: `mail-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`, ...value, preferGmail: true };
    const result = JSON.parse(host.openEmailDraftWithAttachment(JSON.stringify(request)));
    if (!result || result.ok !== true || !['opened_gmail', 'opened_mail_app'].includes(text(result.status))) {
      const status = text(result && result.status);
      if (status === 'no_mail_app') throw new Error('Ingen mailapp finns installerad. Du kan fortfarande kopiera underlaget.');
      if (status === 'invalid_request') throw new Error('Mailunderlaget kunde inte förberedas.');
      if (status === 'attachment_error') throw new Error(value.attachment && value.attachment.mimeType === 'application/vnd.ms-excel' ? 'Excel-filen kunde inte förberedas för mailutkastet.' : 'Rapportfilen kunde inte förberedas. Loggen är kvar.');
      throw new Error('Mailutkast kunde inte öppnas.');
    }
    return result;
  }
  window.StadslassMailService = Object.freeze({ validate, open, MAX_TEXT_ATTACHMENT_BYTES, MAX_EXCEL_ATTACHMENT_BYTES });
})();
