(() => {
  'use strict';

  const PACKAGE_VERSION = 188;
  const JOB_MODEL_VERSION = 4;
  const MINIMUM_HOST_VERSION = 27;
  const P144_NOTIFICATION_SOUND_URL = './audio/notis.mp3';
  const NOTIFICATION_SOUND_SETTINGS_KEY = 'notificationSoundV1';
  const P150_ACCEPTED_MOBILE_ASSIGNMENTS_KEY = 'acceptedMobileAssignmentsV1';
  const SETTINGS_STORE = 'settings';
  const QUEUE_STORE = 'queue';
  const ACTIVE_JOB_STORE = 'activeJob';
  const HISTORY_STORE = 'history';
  const SYNC_OUTBOX_STORE = 'syncOutbox';
  const UI_SETTINGS_KEY = 'uiPreferencesV1';
  const PHASE_COLOR_SETTINGS_KEY = 'phaseColorsV1';
  const PERFORMANCE_REPORT_SNAPSHOT_KEY = 'performanceReportSnapshotV1';
  const SYNC_REPORT_SNAPSHOT_KEY = 'syncReportSnapshotV1';
  const REPORT_SNAPSHOT_SCHEMA_VERSION = 1;
  const RUNTIME_VIEW_SESSION_KEY = 'stadslass.runtime-view.v1';
  const PAGE_TITLES = Object.freeze({ home: 'Start', queue: 'Kö', quickChoices: 'Snabbval', active: 'Aktivt jobb', today: 'Idag', history: 'Historik', trash: 'Papperskorg', statistics: 'Sammanställning', sync: 'Sync & GitHub', settings: 'Inställningar' });
  const ACTIVE_STATUSES = Object.freeze(['active', 'paused', 'completing']);
  const ACTIVE_PHASES = Object.freeze(['start_route', 'loading', 'transport', 'unloading', 'load_registered', 'return_transport', 'return_unloading', 'ready_to_complete', 'other_activity', 'returning']);
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const watchdog = window.StadslassWatchdog || null;
  const xlsxExport = window.StadslassXlsxExport || null;
  const mailService = window.StadslassMailService || null;
  const syncDiagnosticApi = window.StadslassSyncDiagnostic || null;
  const mailboxSyncApi = window.StadslassMailboxSync || null;
  const performanceMonitorApi = window.StadslassPerformanceMonitor || null;
  const editableJobTypeApi = window.StadslassJobTypeRegistry || null;
  const googleService = window.StadslassGoogleService || null;
  const routesService = window.StadslassRoutesService || null;
  const historyService = window.StadslassHistoryService || null;
  const historyArchiveApi = window.StadslassHistoryArchive || null;
  const editablePlaceApi = window.StadslassPlaceRegistry || null;
  const editableBeachApi = window.StadslassBeachRegistry || null;
  const gpsService = window.StadslassGpsService || null;
  const geofenceService = window.StadslassGeofenceService || null;
  const phaseService = window.StadslassPhaseService || null;
  const phaseActionService = window.StadslassPhaseActionService || null;
  const phaseVisualService = window.StadslassPhaseVisualService || null;
  const etaService = window.StadslassEtaService || null;
  const temporaryPlaceService = window.StadslassTemporaryPlaceService || null;
  const ataApi = window.StadslassAta || null;
  const ataBillingApi = window.StadslassAtaBilling || null;
  const ataNotificationApi = window.StadslassAtaNotificationSettings || null;
  const ataRouting = window.StadslassAtaRouting || null;
  const ataMailApi = window.StadslassAtaMailUnderlag || null;
  const registries = window.StadslassRegistries || null;
  const quickChoiceApi = window.StadslassQuickChoiceRegistry || null;
  const backupApi = window.StadslassBackupService || null;
  const receiptApi = window.StadslassReceiptImport || null;
  const historySyncApi = window.StadslassHistorySync || null;
  const nativeStorage = window.StadslassNativeStorage || null;
  const machineTransportApi = window.StadslassMachineTransport || null;
  const baselineJobTypeItems = registries && registries.jobTypes && Array.isArray(registries.jobTypes.items) ? registries.jobTypes.items : [];
  let jobTypeItems = [];
  let jobTypeModelInitialized = false;
  const basePlaceItems = registries && registries.places && Array.isArray(registries.places.items) ? registries.places.items : [];
  let placeItems = [];
  const materialConditionalRules = registries && registries.jobTypes && Array.isArray(registries.jobTypes.conditionalRules) ? registries.jobTypes.conditionalRules : [];

  let hostInfo = null;
  let settingsDocument = {};
  let placeModelInitialized = false;
  let googleSettings = null;
  let googleDiagnostics = null;
  let editableJobTypeRegistry = null;
  let editableJobTypeRegistryError = '';
  let editingEditableJobTypeId = '';
  let editablePlaceRegistry = null;
  let editablePlaceRegistryError = '';
  let editingEditablePlaceId = '';
  let editableBeachRegistry = null;
  let editableBeachRegistryError = '';
  let editableBeachRegistryReadOnly = false;
  let editingEditableBeachId = '';
  let quickChoiceRegistry = null;
  let quickChoiceRegistryError = '';
  let editingQuickChoiceId = '';
  let pendingQuickChoiceFallbackItem = null;
  let pendingQuickChoiceFallbackId = '';
  let quickChoiceActionInProgress = false;
  let quickChoiceActionLockedUntil = 0;
  let quickChoiceLastActionKey = '';
  let machineQuickFlowActive = false;
  let queueDocument = [];
  let queueLoaded = false;
  let pendingQueueDeleteId = '';
  let editingQueueId = '';
  let activeJobDocument = {};
  let activeJobLoaded = false;
  let p116LastGpsSnapshot = null;
  let p116PreviousGpsSnapshot = null;
  let p119RouteInFlightKey = '';
  let p119RouteGeneration = 0;
  let p119RoutesTrusted = false;
  const p121ForecastInFlight = new Set();
  let p122RouteScheduleTimer = null;
  let p116TimeTickTimer = null;
  let pendingActiveReset = false;
  let pendingActiveComplete = false;
  let pendingWeightlessCompletion = false;
  let completionCandidateAt = '';
  let ataBillingDialogOpen = false;
  let ataBillingDraft = null;
  let ataBillingActionInProgress = false;
  let ataBillingBackGuardActive = false;
  let ataBillingBackGuardClosing = false;
  let ataMailDialogContext = null;
  let ataMailActionInProgress = false;
  let ataNotificationPendingAction = null;
  let ataNotificationTemplateTimer = null;
  let loadRegisteredTimer = null;
  let loadRegisteredTimerJobId = '';
  let loadRegisteredTimerUntil = '';
  let historyDocument = [];
  let historyLoaded = false;
  let historyLoading = false;
  let historyArchiveLoaded = false;
  let historyArchiveLoading = false;
  let historyArchiveRecords = [];
  let pendingHistorySyncPackage = null;
  let pendingReceiptRows = [];
  let receiptImportRequestId = '';
  let receiptCommitInProgress = false;
  let pendingHistoryTrashId = '';
  let editingHistoryBillingId = '';
  let editingTodayHistoryId = '';
  let historyBillingOperationId = '';
  let pendingTrashPermanentDeleteId = '';
  let historySelectedMonth = '';
  let historySelectedDate = '';
  let syncDiagnostic = null;
  let mailboxSync = null;
  let p182MeaningfulIncomingThisFetch = false;
  let p141ManualFetchInProgress = false;
  let p141NotificationAudioContext = null;
  let p141NotificationBufferPromise = null;
  let p142NotificationAudioElement = null;
  let p142NotificationGesturePromise = null;
  let p144AutoFetchTimer = null;
  let p144AutoFetchScheduledAt = '';
  let p144LastFetchTrigger = '';
  let performanceMonitor = null;
  let performanceReportSnapshot = null;
  let syncReportSnapshot = null;
  let githubConnectionCheckRequestId = '';
  let githubSecureBridgeReady = false;
  const liveReportExports = new Map();
  let backupExportRequestId = '';
  let updatePollTimer = null;
  let runtimeDisposed = false;
  let runtimeFailed = false;
  let historyTrashOperationId = '';
  let bottomNavResizeObserver = null;
  let bottomNavLayoutFrame = null;
  let activeSettingsGroup = '';
  let activeSettingsFunction = '';
  let currentView = 'home';
  let unsubscribeGpsSnapshot = null;
  let unsubscribeGeofenceEvents = null;
  let handlingGeofenceEvent = false;
  let activeJobStartInProgress = false;
  let localQueueCreateInProgress = false;
  let gpsRuntimeReady = false;
  let geofenceRuntimeReady = false;
  let temporaryPlaceFormStates = null;
  const PRESS_DELAY_MS = 500;
  const pendingPressActions = new Map();

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function parseObject(raw, fallback = {}) {
    try {
      const value = JSON.parse(raw);
      return isPlainObject(value) ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }


  const jobModel = window.StadslassJobModel || null;
  const findJobTypeById = (...args) => jobModel.findJobTypeById(...args);
  const findPlaceById = (...args) => jobModel.findPlaceById(...args);
  const deriveMaterial = (...args) => jobModel.deriveMaterial(...args);
  const stableJobId = (...args) => jobModel.stableJobId(...args);
  const normalizeJobRecord = (...args) => jobModel.normalizeJobRecord(...args);
  const isOtherActivityJobType = (...args) => jobModel.isOtherActivityJobType(...args);
  const canonicalJobTypeId = (...args) => jobModel.canonicalJobTypeId(...args);
  const systemJobPolicy = window.StadslassSystemJobPolicy || null;

  function isOtherActivity(documentValue) {
    return isPlainObject(documentValue) && isOtherActivityJobType(text(documentValue.jobTypeId));
  }

  function isMachineTransportJobType(value) {
    const type = typeof value === 'string' ? findJobTypeById(value) : value;
    return (systemJobPolicy && systemJobPolicy.isMachineTransport(type)) || canonicalJobTypeId(type) === 'JT-1011';
  }

  function normalizedMachineItems() {
    const items = Array.isArray(settingsDocument && settingsDocument.machines) ? settingsDocument.machines : [];
    return items.filter(isPlainObject).map((item, index) => ({
      id: text(item.id, `machine-${index}`), name: text(item.name), workshopPlaceId: text(item.workshopPlaceId), weight: Number(item.weight)
    })).filter((item) => item.id && item.name);
  }

  function machineSnapshot(id) {
    const machine = normalizedMachineItems().find((item) => item.id === text(id));
    return machine ? { id: machine.id, name: machine.name, workshopPlaceId: machine.workshopPlaceId, weight: Number.isFinite(machine.weight) && machine.weight >= 0 ? machine.weight : null } : null;
  }

  function machineTransportNamedPlace(pattern) { return activeSortedPlaces().find((place) => pattern.test(text(place.name))); }
  function machineTransportBasePlace() { return machineTransportNamedPlace(/^Ringön\s*\(BAS\)$/i); }
  function machineTransportPickupPlace() { return machineTransportNamedPlace(/^Flaklager Skräppekärr$/i); }
  function machineTransportLinkedPlaces(jobType) {
    if (!jobType) return [];
    return activeSortedPlaces().filter((place) => placeSupportsJobTypeRole(place, jobType.id, 'from') || placeSupportsJobTypeRole(place, jobType.id, 'destination'));
  }
  function selectedMachineBedValue() { const input=document.querySelector('input[name="jobMachineBed"]:checked'); return input ? input.value : ''; }
  function selectedMachineDirection() { const input=document.querySelector('input[name="jobMachineDirection"]:checked'); return input ? input.value : ''; }
  function renderMachineQuickFlow() {
    const panel=byId('job-machine-panel'), bed=byId('job-machine-bed-step'), routeStep=byId('job-machine-route-step'), help=byId('job-machine-flow-help');
    if (!panel || !machineQuickFlowActive) return;
    const selected=byId('job-machine').value, machine=machineSnapshot(selected), hasSelection=Boolean(selected);
    bed.hidden=!hasSelection; const bedValue=selectedMachineBedValue();
    const fallback=selected==='__other__'||(machine&&!text(machine.workshopPlaceId));
    routeStep.hidden=!bedValue||fallback;
    byId('job-transport-fields').hidden=!bedValue||(!fallback&&!selectedMachineDirection());
    if (!hasSelection) { help.textContent='Välj maskin för att fortsätta.'; return; }
    if (!bedValue) { help.textContent='Svara om du har maskinflaket.'; return; }
    if (fallback) { help.textContent='Det vanliga Maskintransport-formuläret används. Maskinflakssvaret följer med uppdraget.'; return; }
    const jobType=findJobTypeById(byId('job-type').value), workshopSelect=byId('job-machine-workshop'), previous=workshopSelect.value||machine.workshopPlaceId;
    workshopSelect.replaceChildren(); machineTransportLinkedPlaces(jobType).forEach(place=>{const option=document.createElement('option');option.value=place.id;option.textContent=place.name;workshopSelect.appendChild(option);});
    if(selectContainsValue(workshopSelect,previous))workshopSelect.value=previous;
    const workshop=findPlaceById(workshopSelect.value); byId('job-machine-selected-workshop').textContent=`Vald plats: ${text(workshop&&workshop.name,'Saknas')}`;
    if (byId('job-machine-weight').value===''&&Number.isFinite(machine.weight)&&machine.weight>0) byId('job-machine-weight').value=String(machine.weight);
    applyMachineQuickRoute(); help.textContent=selectedMachineDirection()?'Kontrollera uppgifterna och välj Starta direkt eller Lägg i kö enligt normalt förfarande.':'Välj riktning.';
  }
  function applyMachineQuickRoute() {
    if (!machineQuickFlowActive) return;
    const base=machineTransportBasePlace(), workshop=findPlaceById(byId('job-machine-workshop').value), direction=selectedMachineDirection();
    if(!base||!workshop||!direction)return;
    const route=machineTransportApi.route({direction,workshopPlaceId:workshop.id,workshopPlaceName:workshop.name},base);
    if(selectContainsValue(byId('job-from'),route.from.id))byId('job-from').value=route.from.id;
    if(selectContainsValue(byId('job-destination'),route.to.id))byId('job-destination').value=route.to.id;
    byId('job-transport-fields').hidden=false; updateMaterialPanel('');
  }
  function machineTransportStateFromQueueForm(machine) {
    if (!machineQuickFlowActive) return null;
    const bed=selectedMachineBedValue(); if(!bed)return null;
    const workshop=findPlaceById(byId('job-machine-workshop').value); const pickup=machineTransportPickupPlace(); const rawWeight=text(byId('job-machine-weight').value); const effectiveWeight=rawWeight?Number(rawWeight.replace(',','.')):null;
    return machineTransportApi.create({machine,hasMachineBed:bed==='yes',pickupPlace:pickup,direction:selectedMachineDirection(),workshop,effectiveWeight,weightOverriddenForJob:Boolean(machine&&Number.isFinite(effectiveWeight)&&effectiveWeight!==machine.weight)});
  }

  let machineQuickWizard = null;
  function machineQuickWizardDialog() { return byId('machine-quick-dialog'); }
  function closeMachineQuickWizard(message = '') {
    machineQuickWizard = null;
    const dialog = machineQuickWizardDialog();
    if (dialog) { dialog.hidden = true; dialog.setAttribute('aria-hidden', 'true'); }
    document.body.classList.remove('modal-open');
    if (message) showStatus('quick-choice-status', message);
  }
  function machineQuickWizardMachineButtons() {
    const dialog = machineQuickWizardDialog(), actions = byId('machine-quick-actions');
    if (!dialog || !actions) return;
    const base = machineTransportBasePlace();
    byId('machine-quick-heading').textContent = 'Vilken maskin?';
    byId('machine-quick-description').textContent = 'Välj maskinen som ska transporteras.';
    actions.replaceChildren();
    normalizedMachineItems().forEach((machine) => {
      const workshop = findPlaceById(machine.workshopPlaceId);
      const button = document.createElement('button'); button.type = 'button'; button.className = 'billing-choice-button'; button.textContent = machine.name;
      if (!base || !workshop) { button.disabled = true; button.title = !base ? 'Ringön (BAS) saknas i Platsregistret.' : 'Maskinen saknar giltig standardverkstad.'; const note=document.createElement('small'); note.textContent=button.title; button.append(note); }
      else button.addEventListener('click', () => { machineQuickWizard.machine = machine; machineQuickWizardDirectionButtons(); });
      actions.append(button);
    });
    if (!normalizedMachineItems().length) actions.textContent = 'Inga maskiner är registrerade. Lägg till maskin i Maskinregistret.';
  }
  function machineQuickWizardDirectionButtons() {
    const actions=byId('machine-quick-actions'), machine=machineQuickWizard && machineQuickWizard.machine;
    if (!actions || !machine) return;
    byId('machine-quick-heading').textContent = machine.name;
    byId('machine-quick-description').textContent = 'Välj riktning för standardverkstaden.';
    actions.replaceChildren();
    [['to_workshop','Till verkstad'],['from_workshop','Från verkstad']].forEach(([direction,label]) => { const button=document.createElement('button'); button.type='button'; button.className='billing-choice-button'; button.textContent=label; button.addEventListener('click',()=>{machineQuickWizard.direction=direction; machineQuickWizardActionButtons();}); actions.append(button); });
  }
  function machineQuickWizardActionButtons() {
    const actions=byId('machine-quick-actions'); if (!actions || !machineQuickWizard) return;
    byId('machine-quick-heading').textContent = 'Skapa Maskintransport';
    byId('machine-quick-description').textContent = 'Uppdraget skapas som ett vanligt arbetskort och kan redigeras i kön.';
    actions.replaceChildren();
    const actionsForRole = isVehicleRole() ? [['queue','Lägg i kö'],['direct','Starta direkt']] : [['queue','Lägg i kö']];
    actionsForRole.forEach(([mode,label]) => { const button=document.createElement('button'); button.type='button'; button.className='billing-choice-button'; button.textContent=label; button.addEventListener('click',()=>void createMachineQuickWizardJob(mode)); actions.append(button); });
  }
  async function createMachineQuickWizardJob(mode) {
    const state=machineQuickWizard, jobType=state && state.jobType, machine=state && state.machine, base=machineTransportBasePlace(), workshop=machine && findPlaceById(machine.workshopPlaceId);
    if (!state || !jobType || !machine || !base || !workshop) { closeMachineQuickWizard('Maskintransporten kunde inte skapas eftersom maskinens standardrutt saknas.'); return; }
    if (mode === 'direct' && !isVehicleRole()) { showStatus('quick-choice-status', 'Starta direkt är endast tillgängligt på 189 / Surfplatta.'); return; }
    const route=machineTransportApi.route({direction:state.direction,workshopPlaceId:workshop.id,workshopPlaceName:workshop.name},base), now=new Date().toISOString(), jobId=createLocalId('job');
    const rawItem={schemaVersion:2,jobModelVersion:JOB_MODEL_VERSION,id:jobId,jobId,status:'queued',source:isVehicleRole()?'manual-vehicle-received':'manual-mobile-planning',jobTypeId:jobType.id,jobTypeName:jobType.name,fromPlaceId:text(route.from.id),fromPlaceName:text(route.from.name),destinationPlaceId:text(route.to.id),destinationPlaceName:text(route.to.name),returnPlaceId:'',returnPlaceName:'',returnRequired:false,multiLoad:false,machine:{...machine},machineLoads:[{loadNumber:1,machine:{...machine}}],material:deriveMaterialForSelections(jobType.id,route.from,route.to),plannedDate:p138Today(),plannedTime:'',note:text(state.comment),createdAt:now,createdByPackageVersion:PACKAGE_VERSION,updatedAt:now,updatedByPackageVersion:PACKAGE_VERSION,metadata:{createdRole:text(hostInfo.role),createdRoleLabel:text(hostInfo.roleLabel),createdDeviceId:text(hostInfo.deviceId),modelVersion:JOB_MODEL_VERSION}};
    const item=normalizeJobRecord(rawItem,'job');
    if (!appendQuickChoiceToQueue(item, 'Maskintransport är skapat som ett vanligt uppdrag och lagt i kön.')) return;
    closeMachineQuickWizard();
    if (mode !== 'direct') { activateView('queue'); return; }
    if (!refreshActiveJobForQuickChoice() || activeJobBlocksQuickChoice({ jobType })) { showStatus('quick-choice-status', 'Maskintransporten ligger i kön eftersom ett aktivt uppdrag pågår.'); return; }
    await startQueueItem(item.id);
    if (!(activeJobLoaded && activeJobExists() && text(activeJobDocument.jobId) === text(item.jobId))) showStatus('quick-choice-status', 'Maskintransporten kunde inte startas direkt och ligger kvar i kön.', true);
  }

  function refreshMachineSelect(scope) {
    const prefix = scope === 'active' ? 'active-job-' : 'job-';
    const select = byId(`${prefix}machine`); const panel = byId(`${prefix}machine-panel`);
    if (!select || !panel) return;
    const selectedType = findJobTypeById(byId(`${prefix}type`).value);
    const previous = select.value;
    panel.hidden = !isMachineTransportJobType(selectedType);
    select.replaceChildren();
    const none = document.createElement('option'); none.value = ''; none.textContent = 'Välj maskin'; select.appendChild(none);
    normalizedMachineItems().forEach((machine) => { const option = document.createElement('option'); option.value = machine.id; option.textContent = machine.name; select.appendChild(option); });
    if (scope === 'queue') { const other=document.createElement('option'); other.value='__other__'; other.textContent='Annan maskin'; select.appendChild(other); }
    if (Array.from(select.options).some((option) => option.value === previous)) select.value = previous;
  }

  function applyEffectiveJobTypeRegistry(items) {
    jobTypeItems = (Array.isArray(items) ? items : []).map((item) => systemJobPolicy && systemJobPolicy.apply ? systemJobPolicy.apply(item) : item).slice().sort((a, b) => text(a && a.name).localeCompare(text(b && b.name), 'sv-SE', { sensitivity: 'base' }));
    if (!jobTypeModelInitialized) {
      jobModel.initializeJobTypes(jobTypeItems);
      jobTypeModelInitialized = true;
    } else {
      jobModel.replaceJobTypes(jobTypeItems);
    }
  }

  function refreshRuntimeJobTypeSelects() {
    const ids = ['job-type', 'active-job-type'];
    const values = ids.map((id) => byId(id).value);
    populateSelect('job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('active-job-type', jobTypeItems, 'Välj jobbtyp');
    ids.forEach((id, index) => {
      if (Array.from(byId(id).options).some((option) => option.value === values[index])) byId(id).value = values[index];
    });
    refreshMachineSelect('queue');
    refreshMachineSelect('active');
  }

  function refreshQuickChoiceJobTypeSelect() {
    const select = byId('quick-choice-registry-job-type');
    if (!select) return;
    const previous = select.value;
    populateSelect('quick-choice-registry-job-type', jobTypeItems, 'Välj Jobbtyp');
    if (selectContainsValue(select, previous)) select.value = previous;
    populateQuickChoicePlaceOptions();
    syncQuickChoiceFormControls();
    renderQuickChoiceRegistry();
    renderQuickChoices();
  }

  function validateRegistries() {
    if (!jobModel
      || typeof jobModel.initializeJobTypes !== 'function'
      || typeof jobModel.replaceJobTypes !== 'function'
      || typeof jobModel.canonicalJobTypeId !== 'function'
      || typeof jobModel.initializePlaces !== 'function'
      || typeof jobModel.replacePlaces !== 'function'
      || typeof jobModel.getPlaceItems !== 'function'
      || typeof jobModel.validateRegistries !== 'function') {
      throw new Error('Uppdragsmodellens kodmodul saknas eller stöder inte den effektiva platslistan.');
    }
    const result = jobModel.validateRegistries();
    watchdog.step('runtime.registry.validated', `${result.jobTypeCount} jobbtyper och ${result.placeCount} platser verifierades.`);
  }

  function populateSelect(selectId, items, emptyLabel, role = '') {
    const select = byId(selectId);
    select.replaceChildren();
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = emptyLabel;
    select.appendChild(empty);
    items.filter((item) => item && item.active !== false && item.hidden !== true)
      .filter((item) => !role || !Array.isArray(item.roles) || item.roles.includes(role)).forEach((item) => {
      const option = document.createElement('option');
      option.value = text(item.id);
      option.textContent = text(item.name);
      select.appendChild(option);
    });
  }

  function activeSortedPlaces() {
    return placeItems
      .filter((item) => item && item.active !== false && item.hidden !== true)
      .slice()
      .sort((a, b) => text(a && a.name).localeCompare(text(b && b.name), 'sv-SE', { sensitivity: 'base' }));
  }

  function isBeachPlace(item) {
    const roles = item && Array.isArray(item.roles) ? item.roles : [];
    return Boolean(item && (item.category === 'badplats' || roles.includes('beach')));
  }

  function jobTypeIdentityIds(jobTypeId) {
    const identities = new Set();
    const rawId = text(jobTypeId);
    if (rawId) identities.add(rawId);
    const item = findJobTypeById(rawId);
    if (item) {
      identities.add(text(item.id));
      identities.add(text(item.canonicalTypeId));
    }
    identities.delete('');
    return identities;
  }

  function placeSupportsJobTypeRole(item, jobTypeId, role) {
    const jobType = findJobTypeById(jobTypeId);
    if (!item || !jobType || isOtherActivityJobType(jobType)) return false;
    const canonical = canonicalJobTypeId(jobType);
    if (isBeachPlace(item)) {
      const allowedIds = Array.isArray(item.allowedJobTypeIds) ? item.allowedJobTypeIds : [];
      const allowedForHavstang = allowedIds.length === 0 || allowedIds.includes('JT-1010') || allowedIds.includes(text(jobType.id));
      return canonical === 'JT-1010' && allowedForHavstang && (role === 'from' || role === 'destination');
    }
    const identities = jobTypeIdentityIds(jobType.id);
    const linkedIds = role === 'from'
      ? (Array.isArray(item.jobTypeFromIds) ? item.jobTypeFromIds : [])
      : (Array.isArray(item.jobTypeToIds) ? item.jobTypeToIds : []);
    return linkedIds.some((id) => identities.has(text(id)));
  }

  function placesForJobType(jobTypeId, role) {
    if (role !== 'from' && role !== 'destination') return [];
    return activeSortedPlaces().filter((item) => placeSupportsJobTypeRole(item, jobTypeId, role));
  }

  function machineTransportPlacesForMachine(jobType, role, machineId) {
    const places = placesForJobType(jobType.id, role);
    if (!isMachineTransportJobType(jobType)) return places;
    // P124: The editable place registry is the source of truth.  Earlier
    // packages compared fixed, pre-migration PL IDs here and could therefore
    // hide Ringön even though it was explicitly linked to Maskintransport.
    // A machine's workshop remains a normal configured choice, not an
    // exclusive route restriction.
    return places;
  }

  function returnPlaces() {
    return activeSortedPlaces().filter((item) => {
      const roles = Array.isArray(item.roles) ? item.roles : [];
      return item.canBeReturnPlace === true || roles.includes('return');
    });
  }

  function selectContainsValue(select, value) {
    return Boolean(value) && Array.from(select.options).some((option) => option.value === value);
  }

  function populateRegistryForms() {
    populateSelect('job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('job-from', [], 'Välj jobbtyp först');
    populateSelect('job-destination', [], 'Välj jobbtyp först');
    populateSelect('job-return', returnPlaces(), 'Ingen returplats', 'return');
    populateSelect('active-job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('active-job-from', [], 'Välj jobbtyp först');
    populateSelect('active-job-destination', [], 'Välj jobbtyp först');
    populateSelect('active-job-return', returnPlaces(), 'Ingen returplats', 'return');
  }

  function refreshPlaceFormsForJobType(prefix) {
    const jobTypeId = byId(`${prefix}job-type`).value;
    const jobType = findJobTypeById(jobTypeId);
    const routeEnabled = Boolean(jobType && !isOtherActivityJobType(jobType));
    const machineId = byId(`${prefix}job-machine`).value;
    const fromPlaces = routeEnabled ? machineTransportPlacesForMachine(jobType, 'from', machineId) : [];
    const destinationPlaces = routeEnabled ? machineTransportPlacesForMachine(jobType, 'destination', machineId) : [];
    const fromSelect = byId(`${prefix}job-from`);
    const destinationSelect = byId(`${prefix}job-destination`);
    const returnSelect = byId(`${prefix}job-return`);
    const previousFrom = fromSelect.value;
    const previousDestination = destinationSelect.value;
    const previousReturn = returnSelect.value;
    const fromLabel = !routeEnabled ? 'Välj jobbtyp först' : 'Välj Från';
    const destinationLabel = !routeEnabled ? 'Välj jobbtyp först' : 'Välj Till';
    populateSelect(fromSelect.id, fromPlaces, fromLabel, 'from');
    populateSelect(destinationSelect.id, destinationPlaces, destinationLabel, 'destination');
    if (routeEnabled) {
      appendTemporaryPlaceOption(fromSelect, 'from');
      appendTemporaryPlaceOption(destinationSelect, 'destination');
    }
    populateSelect(returnSelect.id, returnPlaces(), 'Ingen returplats', 'return');
    fromSelect.disabled = !routeEnabled;
    destinationSelect.disabled = !routeEnabled;
    if (selectContainsValue(fromSelect, previousFrom)) fromSelect.value = previousFrom;
    if (selectContainsValue(destinationSelect, previousDestination)) destinationSelect.value = previousDestination;
    if (selectContainsValue(returnSelect, previousReturn)) returnSelect.value = previousReturn;
    syncTemporaryPlacePanels(prefix === 'active-' ? 'active' : 'queue');
  }

  function applySuggestedDestination(prefix) {
    const jobTypeId = byId(`${prefix}job-type`).value;
    const fromPlaceId = byId(`${prefix}job-from`).value;
    const destination = byId(`${prefix}job-destination`);
    const suggested = jobModel.suggestedDestination(jobTypeId, fromPlaceId);
    if (suggested && !destination.value) destination.value = suggested;
  }

  function updateMaterialPanel(prefix) {
    const scope = prefix === 'active-' ? 'active' : 'queue';
    const fromPlace = resolveFormPlaceSelection(scope, 'from');
    const destinationPlace = resolveFormPlaceSelection(scope, 'destination');
    const material = deriveMaterialForSelections(byId(`${prefix}job-type`).value, fromPlace, destinationPlace);
    byId(`${prefix}job-material-code`).textContent = material.code || 'Ej aktuell';
    byId(`${prefix}job-material-facility`).textContent = material.facilityPlaceName || 'Ej fastställd';
  }


  function temporaryScope(scope) {
    return scope === 'active' ? 'active' : 'queue';
  }

  function temporaryPrefix(scope) {
    return temporaryScope(scope) === 'active' ? 'active-job' : 'job';
  }

  function ensureTemporaryPlaceFormStates() {
    if (temporaryPlaceFormStates) return temporaryPlaceFormStates;
    temporaryPlaceFormStates = {
      queue: {
        from: { place: temporaryPlaceService.emptyPlace('from'), checking: false, requestToken: 0 },
        destination: { place: temporaryPlaceService.emptyPlace('destination'), checking: false, requestToken: 0 }
      },
      active: {
        from: { place: temporaryPlaceService.emptyPlace('from'), checking: false, requestToken: 0 },
        destination: { place: temporaryPlaceService.emptyPlace('destination'), checking: false, requestToken: 0 }
      }
    };
    return temporaryPlaceFormStates;
  }

  function temporaryFormState(scope, role) {
    const states = ensureTemporaryPlaceFormStates();
    return states[temporaryScope(scope)][role === 'destination' ? 'destination' : 'from'];
  }

  function temporaryFormElements(scope, role) {
    const prefix = temporaryPrefix(scope);
    const roleKey = role === 'destination' ? 'destination' : 'from';
    return {
      select: byId(`${prefix}-${roleKey}`),
      panel: byId(`${prefix}-temporary-${roleKey}-panel`),
      name: byId(`${prefix}-temporary-${roleKey}-name`),
      address: byId(`${prefix}-temporary-${roleKey}-address`),
      status: byId(`${prefix}-temporary-${roleKey}-status`),
      check: byId(`${prefix}-temporary-${roleKey}-check`),
      clear: byId(`${prefix}-temporary-${roleKey}-clear`)
    };
  }

  function temporarySelectionActive(scope, role) {
    const elements = temporaryFormElements(scope, role);
    return Boolean(elements.select && temporaryPlaceService.isTemporarySelection(elements.select.value, role));
  }

  function renderTemporaryPlaceStatus(scope, role, message = '', isError = false) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (!elements.status || !elements.panel) return;
    const place = temporaryPlaceService.normalizePlace(state.place, role);
    let detail = text(message);
    let error = isError;
    if (!detail) {
      if (place.coordinateValid) {
        detail = `${place.normalizedAddress} · Tillfälligt geofence 80 meter är klart.`;
      } else if (place.errorMessage) {
        detail = place.errorMessage;
        error = true;
      } else if (place.addressOrPlusCode) {
        detail = 'Adressen är inte kontrollerad. Tryck Kontrollera adress/Plus Code för att aktivera geofence.';
      } else {
        detail = 'Ingen adresskontroll har gjorts.';
      }
    }
    elements.status.textContent = detail;
    elements.status.classList.toggle('is-error', error);
    elements.panel.classList.toggle('is-resolved', place.coordinateValid);
    elements.panel.classList.toggle('is-invalidated', !place.coordinateValid && Boolean(place.addressOrPlusCode));
  }

  function syncTemporaryPlaceStateFromInputs(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (!elements.name || !elements.address) return state.place;
    let place = temporaryPlaceService.withName(state.place, elements.name.value, new Date().toISOString());
    if (text(elements.address.value) !== text(place.addressOrPlusCode)) {
      state.requestToken += 1;
      state.checking = false;
      place = temporaryPlaceService.invalidatePlace(place, elements.address.value, new Date().toISOString());
    }
    state.place = place;
    return place;
  }

  function syncTemporaryPlacePanel(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (!elements.panel) return;
    const visible = temporarySelectionActive(scope, role);
    elements.panel.hidden = !visible;
    if (!visible) return;
    const place = temporaryPlaceService.normalizePlace(state.place, role);
    state.place = place;
    elements.name.value = place.temporaryPlaceName;
    elements.address.value = place.addressOrPlusCode;
    elements.check.disabled = state.checking;
    renderTemporaryPlaceStatus(scope, role);
  }

  function syncTemporaryPlacePanels(scope) {
    syncTemporaryPlacePanel(scope, 'from');
    syncTemporaryPlacePanel(scope, 'destination');
  }

  function resetTemporaryPlaceForm(scope) {
    const states = ensureTemporaryPlaceFormStates()[temporaryScope(scope)];
    for (const role of ['from', 'destination']) {
      states[role].requestToken += 1;
      states[role].checking = false;
      states[role].place = temporaryPlaceService.emptyPlace(role);
      const elements = temporaryFormElements(scope, role);
      if (elements.name) elements.name.value = '';
      if (elements.address) elements.address.value = '';
      if (elements.check) elements.check.disabled = false;
      if (elements.status) {
        elements.status.textContent = 'Ingen adresskontroll har gjorts.';
        elements.status.classList.remove('is-error');
      }
      if (elements.panel) {
        elements.panel.classList.remove('is-resolved', 'is-invalidated');
      }
    }
    syncTemporaryPlacePanels(scope);
  }

  function loadTemporaryPlaceForm(scope, documentValue) {
    const normalized = temporaryPlaceService.normalizeCollection(documentValue && documentValue.temporaryPlaces);
    const states = ensureTemporaryPlaceFormStates()[temporaryScope(scope)];
    for (const role of ['from', 'destination']) {
      states[role].requestToken += 1;
      states[role].checking = false;
      states[role].place = normalized[role]
        ? temporaryPlaceService.normalizePlace(normalized[role], role)
        : temporaryPlaceService.emptyPlace(role);
    }
    syncTemporaryPlacePanels(scope);
  }

  function appendTemporaryPlaceOption(select, role) {
    if (!select || selectContainsValue(select, temporaryPlaceService.selectionId(role))) return;
    const option = document.createElement('option');
    option.value = temporaryPlaceService.selectionId(role);
    option.textContent = temporaryPlaceService.selectionLabel(role);
    option.dataset.temporaryOtherPlace = 'true';
    select.appendChild(option);
  }

  function collectTemporaryPlaces(scope) {
    const result = {};
    for (const role of ['from', 'destination']) {
      if (!temporarySelectionActive(scope, role)) continue;
      const place = syncTemporaryPlaceStateFromInputs(scope, role);
      result[role] = temporaryPlaceService.normalizePlace(place, role);
    }
    return result;
  }

  function resolveFormPlaceSelection(scope, role) {
    const elements = temporaryFormElements(scope, role);
    if (!elements.select) return null;
    if (temporaryPlaceService.isTemporarySelection(elements.select.value, role)) {
      const place = syncTemporaryPlaceStateFromInputs(scope, role);
      return temporaryPlaceService.runtimePlace(place, role);
    }
    return findPlaceById(elements.select.value);
  }

  function resolveJobPlace(documentValue, role) {
    const temporaryPlace = temporaryPlaceService.placeForJobRole(documentValue, role);
    if (temporaryPlace) return temporaryPlace;
    if (role === 'from') return findPlaceById(documentValue && documentValue.fromPlaceId);
    if (role === 'destination') return findPlaceById(documentValue && documentValue.destinationPlaceId);
    if (role === 'return') return findPlaceById(text(documentValue && documentValue.returnPlaceId, text(documentValue && documentValue.fromPlaceId)));
    return null;
  }

  function deriveMaterialForSelections(jobTypeId, fromPlace, destinationPlace) {
    const fromId = fromPlace && fromPlace.temporaryOtherPlace === true ? '' : text(fromPlace && fromPlace.id);
    const destinationId = destinationPlace && destinationPlace.temporaryOtherPlace === true ? '' : text(destinationPlace && destinationPlace.id);
    const material = deriveMaterial(jobTypeId, fromId, destinationId);
    if (!destinationPlace || destinationPlace.temporaryOtherPlace !== true) return material;
    return {
      ...material,
      facilityPlaceId: '',
      facilityPlaceName: text(destinationPlace.name),
      ruleId: text(material.ruleId)
    };
  }

  function clearTemporaryPlace(scope, role) {
    const state = temporaryFormState(scope, role);
    state.requestToken += 1;
    state.checking = false;
    state.place = temporaryPlaceService.emptyPlace(role);
    const elements = temporaryFormElements(scope, role);
    elements.name.value = '';
    elements.address.value = '';
    elements.check.disabled = false;
    renderTemporaryPlaceStatus(scope, role, 'Den tillfälliga platsen är rensad.');
  }

  function temporaryPlaceAddressChanged(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    state.requestToken += 1;
    state.checking = false;
    state.place = temporaryPlaceService.invalidatePlace(state.place, elements.address.value, new Date().toISOString());
    elements.check.disabled = false;
    renderTemporaryPlaceStatus(scope, role, text(elements.address.value)
      ? 'Adressen har ändrats. Tidigare koordinat och geofence är ogiltiga tills adressen kontrolleras igen.'
      : 'Adressen är rensad. Uppdraget kan sparas utan geofence.');
  }

  function temporaryPlaceNameChanged(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    state.place = temporaryPlaceService.withName(state.place, elements.name.value, new Date().toISOString());
    renderTemporaryPlaceStatus(scope, role);
  }

  async function checkTemporaryPlace(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (state.checking) return;
    const reference = text(elements.address.value);
    state.place = temporaryPlaceService.withName(state.place, elements.name.value, new Date().toISOString());
    if (!reference) {
      state.place = temporaryPlaceService.failedPlace(state.place, '', { code: 'EMPTY_QUERY', message: 'Skriv en adress eller Plus Code för att kontrollera platsen.' }, 'invalid-input');
      renderTemporaryPlaceStatus(scope, role, state.place.errorMessage, true);
      return;
    }
    state.requestToken += 1;
    const requestToken = state.requestToken;
    state.checking = true;
    state.place = temporaryPlaceService.invalidatePlace(state.place, reference, new Date().toISOString());
    elements.check.disabled = true;
    renderTemporaryPlaceStatus(scope, role, 'Google kontrollerar adressen och söker närmaste gata…');
    try {
      const forward = await googleService.geocode(reference, googleSettings && googleSettings.apiKey);
      if (requestToken !== state.requestToken || text(elements.address.value) !== reference) return;
      const reverse = await googleService.reverseGeocode(forward.latitude, forward.longitude, googleSettings && googleSettings.apiKey);
      if (requestToken !== state.requestToken || text(elements.address.value) !== reference) return;
      state.place = temporaryPlaceService.resolvedPlace(state.place, {
        ...reverse,
        latitude: forward.latitude,
        longitude: forward.longitude
      }, reference, new Date().toISOString());
      elements.address.value = state.place.normalizedAddress;
      renderTemporaryPlaceStatus(scope, role, `${state.place.normalizedAddress} · Adressen är kontrollerad och tillfälligt geofence 80 meter är klart.`);
      watchdog.step('runtime.temporary-place.geocoding.resolved', `${temporaryPlaceService.selectionLabel(role)} kontrollerades med den gemensamma Google-tjänsten och fick ett uppdragsbundet 80-metersunderlag.`);
    } catch (error) {
      if (requestToken !== state.requestToken) return;
      const status = googleService.errorStatus(error);
      const userMessage = googleService.userMessageForError(error);
      state.place = temporaryPlaceService.failedPlace(state.place, reference, {
        code: error && error.code,
        message: userMessage
      }, status, new Date().toISOString());
      const diagnostic = googleService.diagnosticFromError(error, {
        flow: 'temporary-place',
        itemId: `${temporaryScope(scope)}-${role}`,
        apiKey: googleSettings && googleSettings.apiKey,
        query: reference,
        at: state.place.updatedAt
      });
      persistGoogleDiagnostic(diagnostic);
      renderTemporaryPlaceStatus(scope, role, `${userMessage} Uppdraget kan fortfarande sparas utan geofence.`, true);
      watchdog.step('runtime.temporary-place.geocoding.failed', `${diagnostic.errorCode || 'RUNTIME_ERROR'} vid ${temporaryPlaceService.selectionLabel(role)}.`, 'warning');
    } finally {
      if (requestToken === state.requestToken) {
        state.checking = false;
        elements.check.disabled = false;
      }
    }
  }

  let nativeStorageLastError = '';

  function nativeStorageErrorMessage(fallback = 'Native lagring misslyckades.') {
    return text(nativeStorageLastError, fallback);
  }

  function writeSettingsDocument(value) {
    try {
      if (!nativeStorage || !nativeStorage.isActive()) throw new Error('Native lagringsadaptern är inte redo.');
      nativeStorage.writeSettingsProjection(value);
      nativeStorageLastError = '';
      return true;
    } catch (error) {
      nativeStorageLastError = error && error.message ? error.message : 'Inställningslagret kunde inte sparas i native storage.';
      watchdog.step('runtime.native-storage.settings.write-failed', nativeStorageLastError, 'warning');
      return false;
    }
  }

  function writeHistoryDocument(value) {
    try {
      if (!nativeStorage || !nativeStorage.isActive()) throw new Error('Native lagringsadaptern är inte redo.');
      nativeStorage.writeHistoryProjection(value);
      nativeStorageLastError = '';
      return true;
    } catch (error) {
      nativeStorageLastError = error && error.message ? error.message : 'Historiken kunde inte sparas i native storage.';
      watchdog.step('runtime.native-storage.history.write-failed', nativeStorageLastError, 'warning');
      return false;
    }
  }

  function migrateArrayStore(storeName, value, detail) {
    const normalized = value.map((item, index) => normalizeJobRecord(item, `${storeName}-${index}`));
    if (JSON.stringify(normalized) === JSON.stringify(value)) return normalized;
    const saved = storeName === HISTORY_STORE
      ? writeHistoryDocument(normalized)
      : window.StadslassHost.writeStore(storeName, JSON.stringify(normalized));
    watchdog.step(saved ? `runtime.store.${storeName}.migrated` : `runtime.store.${storeName}.migration-pending`, saved ? detail : 'Migreringen kunde inte skrivas; ursprungsdata är orörd och används i minnet.', saved ? 'info' : 'warning');
    return normalized;
  }

  function migrateObjectStore(storeName, value, detail) {
    if (!isPlainObject(value) || Object.keys(value).length === 0) return value;
    const normalized = normalizeJobRecord(value, storeName);
    if (JSON.stringify(normalized) === JSON.stringify(value)) return normalized;
    const saved = window.StadslassHost.writeStore(storeName, JSON.stringify(normalized));
    watchdog.step(saved ? `runtime.store.${storeName}.migrated` : `runtime.store.${storeName}.migration-pending`, saved ? detail : 'Migreringen kunde inte skrivas; ursprungsdata är orörd och används i minnet.', saved ? 'info' : 'warning');
    return normalized;
  }

  function readSettingsDocument() {
    watchdog.step('runtime.store.settings.read', 'Native kategorilagring och tekniskt inställningsstate läses.');
    if (!nativeStorage || !nativeStorage.isActive()) throw new Error('P163 native lagringsadapter är inte aktiv.');
    const value = nativeStorage.settingsProjection();
    if (!isPlainObject(value)) throw new Error('Native settings-projektionen har fel format.');
    watchdog.step('runtime.store.settings.validated', 'Native settings-projektionen är användbar och saknar parallell verksamhetssanning i legacy settings.');
    return value;
  }

  function readQueueDocument() {
    watchdog.step('runtime.store.queue.read', 'Kölagret läses först när kövyn öppnas.');
    const raw = window.StadslassHost.readStore(QUEUE_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Kölagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Kölagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Kölagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.queue.validated', 'Kölagret är en JSON-lista.');
    return migrateArrayStore(QUEUE_STORE, value, 'Kölagret migrerades till uppdragsmodell v3 med bevarade pausade faser.');
  }

  function readActiveJobDocument() {
    watchdog.step('runtime.store.active.read', 'Aktivt-jobb-lagret läses från den gemensamma lagringen.');
    const raw = window.StadslassHost.readStore(ACTIVE_JOB_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Lagret för aktivt jobb kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Lagret för aktivt jobb innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!isPlainObject(value)) {
      throw new Error('Lagret för aktivt jobb har fel format och har inte ändrats.');
    }
    if (Object.keys(value).length === 0) {
      watchdog.step('runtime.store.active.validated', 'Aktivt-jobb-lagret är tomt och giltigt.');
      return value;
    }
    const id = text(value.id);
    const status = text(value.status);
    const phase = text(value.phase);
    if (!id || !ACTIVE_STATUSES.includes(status) || !phaseService.isKnownPhase(phase, true)) {
      throw new Error('Lagret för aktivt jobb har en okänd struktur och har inte ändrats.');
    }
    watchdog.step('runtime.store.active.validated', 'Aktivt-jobb-lagrets grundschema är giltigt.');
    return migrateObjectStore(ACTIVE_JOB_STORE, value, 'Aktivt jobb migrerades till uppdragsmodell v3 med bevarad fas utan fabricerade fastider.');
  }

  function readHistoryDocument() {
    watchdog.step('runtime.store.history.read', 'Native history/trash/learning läses först när historik behövs.');
    if (!nativeStorage || !nativeStorage.isActive()) throw new Error('P163 native lagringsadapter är inte aktiv.');
    const value = nativeStorage.historyDocument();
    if (!Array.isArray(value)) throw new Error('Native historikprojektionen har fel format.');
    watchdog.step('runtime.store.history.validated', 'Native historikprojektionen är en giltig lista med återkopplad learning och trash.');
    return migrateArrayStore(HISTORY_STORE, value, 'Native historik migrerades till aktuell uppdragsmodell med bevarade ID:n.');
  }

  // P135: den gamla synkmotorn är helt borttagen. Endast säker
  // GitHub-konfiguration samt fristående test/rapport/prestanda bevaras.
  function syncV63Configuration() {
    const current = isPlainObject(settingsDocument.syncV63) ? settingsDocument.syncV63 : {};
    return { owner: 'Gagge007', repository: 'Lastbils-app', branch: 'main', ...current };
  }

  function syncV63HostAvailable() {
    return Boolean(hostInfo && Number(hostInfo.syncCredentialApiVersion) === 1);
  }

  function syncV63UpdateSettings(patch) {
    const next = { ...settingsDocument, syncV63: { ...syncV63Configuration(), ...patch }, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) return false;
    settingsDocument = next;
    return true;
  }

  function syncV65SafeTechnicalText(value, maxLength = 240) { return text(value).replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, maxLength); }
  function syncV65HostLastError() { try { return syncV65SafeTechnicalText(window.StadslassHost.getLastError(), 500); } catch (_) { return ''; } }
  function syncV65NormalizeToken(value) { const raw = String(value || '').trim(); return raw && !/^\*+$/.test(raw) ? raw : ''; }
  function syncV65MaskedToken(value) { return /^\*+$/.test(String(value || '').trim()); }
  function syncV65Diagnostic(result = {}, hostError = '') { return { at: new Date().toISOString(), ok: result.ok === true, status: text(result.status), errorCode: text(result.errorCode), hostError: text(hostError) }; }
  function syncV65RememberDiagnostic(diagnostic) { return diagnostic; }
  function syncV65ConfigurationStatus() {
    if (!githubSecureBridgeReady) return { ok: false, configured: null, verificationState: 'pending', status: 'not_ready' };
    try {
      if (!bridgeAvailable() || typeof window.StadslassHost.getSyncConfigurationStatus !== 'function') {
        return { ok: false, configured: null, verificationState: 'unverified', status: 'capability_missing' };
      }
      const result = parseObject(window.StadslassHost.getSyncConfigurationStatus(), {}) || {};
      if (result.ok === true && result.configured === true) return { ...result, configured: true, verificationState: 'saved' };
      if (result.ok === true && result.configured === false) return { ...result, configured: false, verificationState: 'missing' };
      return { ...result, ok: result.ok === true, configured: null, verificationState: 'unverified' };
    } catch (_) {
      return { ok: false, configured: null, verificationState: 'unverified', status: 'bridge_exception' };
    }
  }
  function syncV65ConfigurationLabel(result = {}) {
    if (result.verificationState === 'pending') return 'Kontrolleras efter start…';
    if (result.ok === true && result.configured === true) return 'Sparad';
    if (result.ok === true && result.configured === false) return 'Saknas';
    return 'Kunde inte verifieras';
  }
  function syncV65ConfigurationErrorMessage(result = {}) { return text(result.message || result.error || result.errorCode, 'GitHub-inställningen kunde inte sparas.'); }

  function mailboxUnitFromRole() {
    if (!mailboxSyncApi || typeof mailboxSyncApi.unitFromRole !== 'function') return '';
    return mailboxSyncApi.unitFromRole(text(hostInfo && hostInfo.role));
  }

  function mailboxLoadLocalState() {
    return isPlainObject(settingsDocument.mailboxV1) ? settingsDocument.mailboxV1 : {};
  }

  function mailboxPersistLocalState(value) {
    const next = { ...settingsDocument, mailboxV1: value, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) return false;
    settingsDocument = next;
    return true;
  }

  function mailboxSyncEnsure() {
    if (mailboxSync || !mailboxSyncApi || !githubSecureBridgeReady) return mailboxSync;
    mailboxSync = mailboxSyncApi.create({
      host: window.StadslassHost,
      unitProvider: () => mailboxUnitFromRole(),
      loadLocal: mailboxLoadLocalState,
      persistLocal: mailboxPersistLocalState,
      onAssignmentPackage: handleIncomingAssignmentPackage,
      onAssignmentResult: handleIncomingAssignmentResult,
      onRegistryRequest: () => registryTransferSnapshot(),
      onRegistryPackage: (pkg) => receiveRegistryPackage(pkg),
      onHistoryRequest: () => historyTransferSnapshot(),
      onHistoryPackage: (pkg) => receiveHistoryPackage(pkg),
      onContactPackage: (pkg) => receiveContactPackage(pkg),
      onStateChange: () => renderMailboxSync(),
      onEvent: (item) => syncDiagnosticObserve('mailbox-event', item || {})
    });
    return mailboxSync;
  }

  function registryTransferSnapshot() {
    if (mailboxUnitFromRole() !== '189') return null;
    return { schemaVersion: 1, places: clone(editablePlaceRegistry), beaches: clone(editableBeachRegistry), jobTypes: clone(editableJobTypeRegistry), machines: clone(normalizedMachineItems()), quickChoices: clone(quickChoiceRegistry) };
  }

  function registryComparisonValue(value) {
    if (Array.isArray(value)) return value.map(registryComparisonValue);
    if (!isPlainObject(value)) return value;
    const next = {};
    Object.keys(value).sort().forEach((key) => {
      if (key === 'revision' || key === 'createdAt' || key === 'updatedAt') return;
      next[key] = registryComparisonValue(value[key]);
    });
    return next;
  }

  function registryComparisonEntries(items, idKey) {
    const entries = new Map();
    (Array.isArray(items) ? items : []).filter(isPlainObject).forEach((item, index) => {
      const id = text(item[idKey], `${idKey}-${index}`);
      if (id) entries.set(id, JSON.stringify(registryComparisonValue(item)));
    });
    return entries;
  }

  function registryComparisonLine(label, currentItems, incomingItems, idKey) {
    const current = registryComparisonEntries(currentItems, idKey);
    const incoming = registryComparisonEntries(incomingItems, idKey);
    let added = 0; let changed = 0; let removed = 0;
    incoming.forEach((value, id) => { if (!current.has(id)) added += 1; else if (current.get(id) !== value) changed += 1; });
    current.forEach((_, id) => { if (!incoming.has(id)) removed += 1; });
    if (!added && !changed && !removed) return `${label}: inga avvikelser`;
    return `${label}: ${changed} ${changed === 1 ? 'ändrad' : 'ändrade'}, ${added} ${added === 1 ? 'ny' : 'nya'}, ${removed} ${removed === 1 ? 'borttagen' : 'borttagna'}`;
  }

  function registryTransferComparison(payload) {
    return [
      registryComparisonLine('Platser', editablePlaceRegistry && editablePlaceRegistry.items, payload.places && payload.places.items, 'id'),
      registryComparisonLine('Jobbtyper', editableJobTypeRegistry && editableJobTypeRegistry.items, payload.jobTypes && payload.jobTypes.items, 'id'),
      registryComparisonLine('Badplatser', editableBeachRegistry && editableBeachRegistry.items, payload.beaches && payload.beaches.items, 'id'),
      registryComparisonLine('Maskiner', normalizedMachineItems(), payload.machines, 'id'),
      registryComparisonLine('Snabbval', quickChoiceRegistry && quickChoiceRegistry.items, payload.quickChoices && payload.quickChoices.items, 'quickChoiceId')
    ].join('\n');
  }

  function applyRegistryTransfer(payload) {
    if (mailboxUnitFromRole() !== 'mobile' || !isPlainObject(payload)) return { ok: false, message: 'Registersvar får endast tas emot av Mobil.' };
    try {
      editableJobTypeApi.validateRegistry(payload.jobTypes);
      editablePlaceApi.validateRegistry(payload.places, new Set(payload.jobTypes.items.map((item) => item.id)));
      editableBeachApi.validateRegistry(payload.beaches);
      quickChoiceApi.validateRegistry(payload.quickChoices);
      if (!Array.isArray(payload.machines)) throw new Error('Maskinregistret saknas eller är ogiltigt.');
      const comparison = registryTransferComparison(payload);
      if (!window.confirm(`Avvikelser mot Mobilens register:\n${comparison}\n\nRegister från 189 är mottaget. Vill du ersätta Mobilens befintliga register?`)) {
        const next = { ...settingsDocument, pendingRegistryPackage: null, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
        if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || 'Registerpaketet kunde inte kastas lokalt.');
        settingsDocument = next; showStatus('role-boundary-note', 'Registerpaketet kastades. Begär nytt register från 189 när du vill försöka igen.'); return { ok: true };
      }
      const next = { ...settingsDocument, pendingRegistryPackage: null, [editableJobTypeApi.SETTINGS_KEY]: clone(payload.jobTypes), [editablePlaceApi.SETTINGS_KEY]: clone(payload.places), [editableBeachApi.SETTINGS_KEY]: clone(payload.beaches), [quickChoiceApi.SETTINGS_KEY]: clone(payload.quickChoices), machines: clone(payload.machines), settingsUpdatedByPackageVersion: PACKAGE_VERSION };
      if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || 'Mobilens register kunde inte ersättas.');
      settingsDocument = next; editableJobTypeRegistry = next[editableJobTypeApi.SETTINGS_KEY]; editablePlaceRegistry = next[editablePlaceApi.SETTINGS_KEY]; editableBeachRegistry = next[editableBeachApi.SETTINGS_KEY]; quickChoiceRegistry = next[quickChoiceApi.SETTINGS_KEY];
      applyEffectiveJobTypeRegistry(editableJobTypeRegistry.items); buildEffectivePlaceRegistry(); populateRegistryForms(); renderMachineRegistry(); renderQuickChoiceRegistry(); renderQuickChoices();
      showStatus('role-boundary-note', 'Register från 189 är mottaget och ersatt.');
      return { ok: true };
    } catch (error) {
      const message = error && error.message ? error.message : 'Registersvar kunde inte valideras.';
      showStatus('role-boundary-note', `Registerpaketet kunde inte valideras: ${message}`, true);
      return { ok: false, message };
    }
  }

  function receiveRegistryPackage(pkg) {
    if (mailboxUnitFromRole() !== 'mobile' || !isPlainObject(pkg) || !isPlainObject(pkg.payload)) return { ok: false, message: 'Registerpaketet är ogiltigt.' };
    const pending = { packageId: String(pkg.packageId || ''), requestId: String(pkg.requestId || ''), receivedAt: new Date().toISOString(), receivedByPackageVersion: PACKAGE_VERSION, payload: clone(pkg.payload) };
    if (!pending.packageId || !pending.requestId) return { ok: false, message: 'Registerpaketet saknar identitet.' };
    const next = { ...settingsDocument, pendingRegistryPackage: pending, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) return { ok: false, message: window.StadslassHost.getLastError() || 'Registerpaketet kunde inte sparas säkert.' };
    settingsDocument = next;
    p182MeaningfulIncomingThisFetch = true;
    window.setTimeout(() => { applyRegistryTransfer(pending.payload); }, 0);
    return { ok: true };
  }

  function resumePendingRegistryPackage() {
    if (mailboxUnitFromRole() !== 'mobile') return;
    const pending = settingsDocument && settingsDocument.pendingRegistryPackage;
    if (!isPlainObject(pending) || !isPlainObject(pending.payload) || !text(pending.packageId) || !text(pending.requestId)) return;
    window.setTimeout(() => { applyRegistryTransfer(pending.payload); }, 0);
  }

  function discardPreP152PendingRegistryPackage() {
    const pending = settingsDocument && settingsDocument.pendingRegistryPackage;
    if (!isPlainObject(pending) || Object.prototype.hasOwnProperty.call(pending, 'receivedByPackageVersion')) return;
    const next = { ...settingsDocument, pendingRegistryPackage: null, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || 'Det äldre registerpaketet kunde inte kastas lokalt.');
    settingsDocument = next;
    showStatus('role-boundary-note', 'Ett äldre registerpaket har kastats efter P152-uppdateringen. Begär register från 189 på nytt.');
  }

  async function requestRegistryFrom189() {
    const service = mailboxSyncEnsure();
    if (!service || typeof service.sendRegistryRequest !== 'function') { showStatus('role-boundary-note', 'Syncmotorn är inte redo för registerbegäran.', true); return; }
    try { await service.sendRegistryRequest(); showStatus('role-boundary-note', 'Registerbegäran är skickad till 189.'); }
    catch (error) { showStatus('role-boundary-note', error.message || 'Registerbegäran kunde inte skickas.', true); }
  }

  function historySyncState() { return isPlainObject(settingsDocument.historySyncV1) ? settingsDocument.historySyncV1 : { schemaVersion: 1, conflicts: [] }; }
  function historySyncSave(patch = {}) {
    const next = { ...settingsDocument, historySyncV1: { ...historySyncState(), ...patch, schemaVersion: 1 }, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || 'Historiksynkens läge kunde inte sparas.');
    settingsDocument = next; pendingHistorySyncPackage = next.historySyncV1.pendingPackage || null; return next.historySyncV1;
  }
  function loadHistoryForSync() {
    if (historyLoaded) return true;
    try { historyDocument = readHistoryDocument(); historyLoaded = true; return true; }
    catch (error) { showStatus(isVehicleRole() ? 'history-sync-status' : 'role-boundary-note', error.message || 'Historiken kunde inte läsas för synk.', true); return false; }
  }
  async function ensureHistoryArchiveForSync() {
    if (!historyArchiveApi || !nativeStorage || !nativeStorage.isActive()) return [];
    try {
      historyArchiveRecords = Array.from(nativeStorage.archiveRecords());
      historyArchiveLoaded = true;
      return effectiveHistoryArchiveRecords(false);
    } catch (error) {
      throw new Error(error && error.message ? error.message : 'Native historikarkivet kunde inte läsas för synk.');
    }
  }
  function historySyncTransportItem(value) {
    if (historySyncApi && typeof historySyncApi.normalize === 'function') return historySyncApi.normalize(value);
    return isPlainObject(value) ? { syncKind: 'history', record: clone(value) } : null;
  }
  function historySyncRecord(value) {
    const item = historySyncTransportItem(value);
    return item && isPlainObject(item.record) ? item.record : null;
  }
  function historySyncKind(value) {
    const item = historySyncTransportItem(value);
    return text(item && item.syncKind, 'history');
  }
  async function historyTransferSnapshot() {
    if (!canUseQueue() || !loadHistoryForSync() || !historySyncApi) return null;
    const archiveRecords = await ensureHistoryArchiveForSync();
    const receipts = receiptRows();
    return historySyncApi.buildSnapshot({
      historyRecords: historyDocument.filter(isPlainObject),
      receiptRows: receipts,
      archiveRecords,
      sourceUnit: mailboxUnitFromRole(),
      exportedAt: new Date().toISOString(),
      receiptProjector: (rawRow) => {
        const row = resolvedReceiptRow(rawRow);
        const item = receiptApi.projection(row, receiptEstimateMinutes(row));
        item.receiptRegistryReferenceMissing = row.registryReferenceMissing === true;
        return item;
      }
    });
  }
  function historySyncComparable(value) {
    if (Array.isArray(value)) return value.map(historySyncComparable);
    if (!isPlainObject(value)) return value;
    const result = {};
    Object.keys(value).sort().forEach((key) => { if (!['updatedAt', 'updatedByPackageVersion', 'lastViewedAt'].includes(key)) result[key] = historySyncComparable(value[key]); });
    return result;
  }
  function historySyncRawId(record) { return text(record && record.id, text(record && record.jobId, text(record && record.sourceJobId))); }
  function historySyncId(value) {
    const item = historySyncTransportItem(value);
    if (!item) return '';
    if (historySyncApi && typeof historySyncApi.transportId === 'function') {
      return historySyncApi.transportId(item, { historyId: historySyncRawId, archiveSourceId: historyArchiveSourceId, receiptKey: receiptApi ? receiptApi.key : null });
    }
    return historySyncRawId(item.record);
  }
  function historySyncInterval(record) {
    const start = new Date(text(record && record.startedAt)).getTime(), end = new Date(text(record && record.completedAt)).getTime();
    return Number.isFinite(start) && Number.isFinite(end) && end >= start ? { start, end } : null;
  }
  function historySyncConflict(reason, incoming, local = null) { return { conflictId: `history-sync-conflict-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`, createdAt: new Date().toISOString(), reason, incoming: clone(incoming), local: local ? clone(local) : null }; }
  function historySyncComparison(records) {
    const existingHistory = historyDocument.filter(isPlainObject);
    const byId = new Map(existingHistory.map((item) => [historySyncRawId(item), item]).filter(([id]) => id));
    const localReceipts = receiptRows();
    const receiptById = new Map(localReceipts.map((row) => [text(row && row.id), row]).filter(([id]) => id));
    const receiptKeys = new Set(receiptApi ? localReceipts.map((row) => receiptApi.key(row)) : []);
    existingHistory.filter((item) => isReceiptImportedHistoryItem(item)).forEach((item) => { if (text(item.receiptRowId)) receiptById.set(text(item.receiptRowId), item); });
    const localArchive = effectiveHistoryArchiveRecords(false);
    const archiveById = new Map(localArchive.map((item) => [historyArchiveSourceId(item), item]).filter(([id]) => id));
    const localArchiveState = new Map();
    existingHistory.forEach((item) => { const sourceId = historyArchiveSourceId(item); if (sourceId) localArchiveState.set(sourceId, item); });
    const accepted = [], conflicts = []; let duplicates = 0;
    (Array.isArray(records) ? records : []).forEach((rawIncoming) => {
      const incomingItem = historySyncTransportItem(rawIncoming);
      const incoming = incomingItem && incomingItem.record;
      const kind = historySyncKind(incomingItem);
      if (!incomingItem || !isPlainObject(incoming)) { conflicts.push(historySyncConflict('Posten har ogiltigt format.', { value: rawIncoming })); return; }
      if (kind === 'receipt') {
        const row = incomingItem.receiptRow;
        if (!isPlainObject(row)) { conflicts.push(historySyncConflict('Kvittohistoriken saknar originalrad.', incomingItem)); return; }
        const rowId = text(row.id) || text(incoming.receiptRowId);
        const key = receiptApi ? receiptApi.key(row) : '';
        const local = rowId ? receiptById.get(rowId) : null;
        if (local) {
          if (local.receiptImported === true && text(local.receiptRowId) === rowId) { duplicates += 1; return; }
          const localComparable = receiptApi.store([local])[0];
          const incomingComparable = receiptApi.store([row])[0];
          if (JSON.stringify(historySyncComparable(localComparable)) === JSON.stringify(historySyncComparable(incomingComparable)) || (key && receiptKeys.has(key))) { duplicates += 1; return; }
          conflicts.push(historySyncConflict('Samma kvittorads-ID har olika innehåll.', incomingItem, local)); return;
        }
        if (key && receiptKeys.has(key)) { duplicates += 1; return; }
        accepted.push(incomingItem);
        if (rowId) receiptById.set(rowId, row);
        if (key) receiptKeys.add(key);
        return;
      }
      if (kind === 'archive') {
        const sourceId = historyArchiveSourceId(incoming);
        if (!sourceId) { conflicts.push(historySyncConflict('Arkivposten saknar stabil arkividentitet.', incomingItem)); return; }
        const localState = localArchiveState.get(sourceId);
        if (localState) { conflicts.push(historySyncConflict(isHistoryArchiveControl(localState) || isHistoryItemTrashed(localState) ? 'Lokal papperskorgs-/raderingsmarkering vinner över arkivoriginalet.' : 'Lokal redigerad arkivpost vinner över arkivoriginalet.', incomingItem, localState)); return; }
        const local = archiveById.get(sourceId);
        if (local && JSON.stringify(historySyncComparable(local)) === JSON.stringify(historySyncComparable(incoming))) { duplicates += 1; return; }
        if (local) { conflicts.push(historySyncConflict('Samma arkividentitet har olika innehåll.', incomingItem, local)); return; }
        conflicts.push(historySyncConflict('Inkommande arkivpost saknas i mottagarens inbyggda v419-arkiv och materialiseras inte automatiskt.', incomingItem));
        return;
      }
      const id = historySyncRawId(incoming), control = isHistoryArchiveControl(incoming);
      if (!id) { conflicts.push(historySyncConflict('Posten saknar stabil historikidentitet.', incomingItem)); return; }
      const local = byId.get(id);
      if (local) {
        if (JSON.stringify(historySyncComparable(local)) === JSON.stringify(historySyncComparable(incoming))) { duplicates += 1; return; }
        if (isHistoryItemTrashed(local) || isHistoryArchiveControl(local)) { conflicts.push(historySyncConflict('Huvudhistoriken har en papperskorgs-/raderingsmarkering som vinner.', incomingItem, local)); return; }
        conflicts.push(historySyncConflict('Samma stabila historikidentitet har olika innehåll.', incomingItem, local)); return;
      }
      if (control) { accepted.push(incomingItem); byId.set(id, incoming); return; }
      if (text(incoming.status, 'completed') !== 'completed') { conflicts.push(historySyncConflict('Posten är inte ett avslutat historikuppdrag.', incomingItem)); return; }
      const interval = historySyncInterval(incoming);
      if (!interval) { conflicts.push(historySyncConflict('Posten saknar giltig start- eller sluttid.', incomingItem)); return; }
      const sameSource = existingHistory.find((item) => text(item && item.sourceJobId) && text(item.sourceJobId) === text(incoming.sourceJobId));
      if (sameSource) { conflicts.push(historySyncConflict('Samma källreferens finns redan med annan historikidentitet.', incomingItem, sameSource)); return; }
      const overlap = existingHistory.find((item) => { const other = historySyncInterval(item); return other && interval.start < other.end && other.start < interval.end; });
      if (overlap) { conflicts.push(historySyncConflict('Tidskonflikt med befintligt historikuppdrag.', incomingItem, overlap)); return; }
      accepted.push(incomingItem); existingHistory.push(incoming); byId.set(id, incoming);
    });
    return { accepted, duplicates, conflicts };
  }
  async function receiveHistoryPackage(pkg) {
    if (!canUseQueue() || !isPlainObject(pkg) || !isPlainObject(pkg.payload) || !Array.isArray(pkg.payload.records)) return { ok: false, message: 'Historikpaketet är ogiltigt.' };
    if (!loadHistoryForSync()) return { ok: false, message: 'Historiken kunde inte läsas före mottagning.' };
    try { await ensureHistoryArchiveForSync(); }
    catch (error) { return { ok: false, message: error.message || 'Historikarkivet kunde inte läsas före mottagning.' }; }
    if (!nativeStorage || !nativeStorage.isActive() || typeof nativeStorage.stageHistoryPackage !== 'function') return { ok: false, message: 'Host24 staging är inte redo.' };
    try {
      const staged = await nativeStorage.stageHistoryPackage(pkg);
      if (typeof watchdog.setStorageDiagnostics === 'function') { try { watchdog.setStorageDiagnostics(nativeStorage.diagnostics()); } catch (_) {} }
      const transferMeta = {
        stagingTransferId: staged.transferId,
        transferId: staged.transferId,
        packageId: staged.complete ? staged.transferId : text(pkg.packageId),
        requestId: text(pkg.requestId),
        from: text(pkg.from),
        receivedAt: new Date().toISOString(),
        partCount: staged.partCount,
        totalRecordCount: staged.totalRecordCount,
        receivedPartIds: staged.receivedPartIds,
        totalBytes: staged.totalBytes,
        integrityStatus: staged.integrityStatus
      };
      if (!staged.complete) {
        historySyncSave({ pendingTransfer: transferMeta, pendingPackage: null });
        watchdog.step('runtime.history-sync.staging.pending', `${staged.receivedPartIds.length}/${staged.partCount} historikdelar verifierade i Host24 staging.`);
        return { ok: true, pending: true, duplicate: staged.duplicate === true };
      }
      const pending = { ...transferMeta, pendingTransfer: undefined };
      historySyncSave({ pendingTransfer: null, pendingPackage: pending });
      pendingHistorySyncPackage = { ...pending, payload: nativeStorage.readStagedHistoryPayload(pending) };
      if (staged.duplicate !== true) p182MeaningfulIncomingThisFetch = true;
      watchdog.step('runtime.history-sync.staging.complete', `${staged.partCount} historikdelar verifierades i staging (${staged.totalBytes} byte).`);
      // Paketet ligger kvar i staging för manuell granskning i Historik.
      // Ingen mottagen synk får ta över användarens aktuella vy.
      renderHistorySyncReview();
      return { ok: true, complete: true, duplicate: staged.duplicate === true };
    } catch (error) {
      watchdog.step('runtime.history-sync.staging.failed', error && error.message ? error.message : 'Historiköverföringen kunde inte lagras i staging.', 'warning');
      return { ok: false, message: error.message || 'Historiköverföringen kunde inte lagras säkert i Host24 staging.' };
    }
  }

  function resolvedPendingHistoryPackage() {
    const meta = historySyncState().pendingPackage;
    if (!isPlainObject(meta)) return null;
    if (isPlainObject(pendingHistorySyncPackage) && text(pendingHistorySyncPackage.stagingTransferId) === text(meta.stagingTransferId) && isPlainObject(pendingHistorySyncPackage.payload)) return pendingHistorySyncPackage;
    if (isPlainObject(meta.payload) && Array.isArray(meta.payload.records)) return { ...clone(meta), payload: clone(meta.payload) };
    if (!nativeStorage || !nativeStorage.isActive() || !text(meta.stagingTransferId)) return null;
    try {
      const resolved = { ...clone(meta), payload: nativeStorage.readStagedHistoryPayload(meta) };
      pendingHistorySyncPackage = resolved;
      return resolved;
    } catch (error) {
      watchdog.step('runtime.history-sync.staging.read-failed', error && error.message ? error.message : 'Väntande historiktransfer kunde inte läsas.', 'warning');
      return null;
    }
  }

  function historySyncPreviewDetails(value, index) {
    const record = historySyncRecord(value) || {};
    const shown = historyItemDisplay(record, index);
    const rawWeight = Number(record && record.totalWeight);
    const hasWeight = Number.isFinite(rawWeight) && rawWeight >= 0 && Object.prototype.hasOwnProperty.call(record || {}, 'totalWeight');
    const completed = new Date(shown.completedAt).getTime();
    const started = new Date(shown.startedAt).getTime();
    const stamp = Number.isFinite(completed) ? shown.completedAt : shown.startedAt;
    const date = localDateFromTimestamp(stamp);
    const time = (value) => {
      const parsed = new Date(value);
      return Number.isNaN(parsed.getTime()) ? 'Saknas' : new Intl.DateTimeFormat('sv-SE', { hour: '2-digit', minute: '2-digit' }).format(parsed);
    };
    return {
      id: historySyncId(value), date: formatDate(date), jobType: shown.jobType,
      route: `${shown.from} → ${shown.destination}`, time: `${time(shown.startedAt)}–${time(shown.completedAt)}`,
      ata: isAtaHistoryItem(record) ? 'Ja' : 'Nej',
      weight: hasWeight ? `${rawWeight.toLocaleString('sv-SE', { minimumFractionDigits: 0, maximumFractionDigits: 3 })} ton` : 'Saknas',
      valid: Number.isFinite(started) && Number.isFinite(completed)
    };
  }
  function openHistorySyncReview() {
    showView('settings'); activeSettingsGroup = 'common-actions'; activeSettingsFunction = 'history';
    prepareSettingsFunction('history'); renderSettingsWorkspace(true); renderHistorySyncReview();
  }
  function reviewPendingHistoryPackage() {
    const pending = resolvedPendingHistoryPackage();
    if (!isPlainObject(pending) || !isPlainObject(pending.payload) || !Array.isArray(pending.payload.records) || !loadHistoryForSync()) return;
    openHistorySyncReview(); showStatus('history-sync-status', 'Historikpaketet väntar på din granskning.');
  }
  function renderHistorySyncReview() {
    const card = byId('history-sync-review-card'), panel = byId('history-sync-review');
    if (!card || !panel) return;
    panel.replaceChildren();
    const pending = resolvedPendingHistoryPackage();
    if (!isPlainObject(pending) || !isPlainObject(pending.payload) || !Array.isArray(pending.payload.records) || !loadHistoryForSync()) { card.hidden = true; return; }
    const compared = historySyncComparison(pending.payload.records);
    card.hidden = false;
    const summary = document.createElement('p'); summary.className = 'section-intro'; summary.textContent = `${compared.accepted.length} kan sammanfogas · ${compared.duplicates} dubbletter · ${compared.conflicts.length} synkkonflikter.`; panel.appendChild(summary);
    if (compared.accepted.length) {
      const list = document.createElement('div'); list.className = 'history-sync-preview-list';
      compared.accepted.forEach((record, index) => {
        const details = historySyncPreviewDetails(record, index); const row = document.createElement('label'); row.className = 'history-sync-preview-row';
        const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = true; checkbox.dataset.historySyncSelect = details.id; checkbox.setAttribute('aria-label', `Sammanfoga ${details.jobType}, ${details.date}`);
        const body = document.createElement('span'); body.className = 'history-sync-preview-body';
        const title = document.createElement('strong'); title.textContent = `${details.date} · ${details.jobType}`;
        const route = document.createElement('span'); route.textContent = details.route;
        const meta = document.createElement('span'); meta.className = 'field-help'; meta.textContent = `Start/slut: ${details.time} · ÄTA: ${details.ata} · Vikt: ${details.weight}`;
        body.append(title, route, meta); row.append(checkbox, body); list.appendChild(row);
      });
      panel.appendChild(list);
    } else { const none = document.createElement('p'); none.className = 'field-help'; none.textContent = 'Inga säkra poster kan sammanfogas från detta paket.'; panel.appendChild(none); }
    const duplicates = document.createElement('p'); duplicates.className = 'field-help'; duplicates.textContent = `Dubbletter: ${compared.duplicates}. De finns redan i historiken och skrivs inte igen.`; panel.appendChild(duplicates);
    if (compared.conflicts.length) {
      const conflictTitle = document.createElement('strong'); conflictTitle.textContent = 'Synkkonflikter – läggs åt sidan'; panel.appendChild(conflictTitle);
      const conflictList = document.createElement('ul'); conflictList.className = 'history-sync-conflict-preview';
      compared.conflicts.forEach((conflict) => { const row = document.createElement('li'); row.textContent = conflict.reason || 'Okänd konflikt.'; conflictList.appendChild(row); });
      panel.appendChild(conflictList);
    }
    const note = document.createElement('p'); note.className = 'field-help'; note.textContent = 'Avmarkerade uppdrag hoppas över endast i detta paket. Dubbletter och konflikter är inte valbara.';
    const actions = document.createElement('div'); actions.className = 'registry-actions';
    const merge = document.createElement('button'); merge.type = 'button'; merge.className = 'primary-button'; merge.dataset.historySyncMerge = 'true'; merge.textContent = 'Sammanfoga valda';
    const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'secondary-button'; cancel.dataset.historySyncCancel = 'true'; cancel.textContent = 'Avbryt';
    actions.append(merge, cancel); panel.append(note, actions);
  }
  function finishPendingHistoryPackage(selectedIds) {
    const pending = resolvedPendingHistoryPackage();
    if (!isPlainObject(pending) || !isPlainObject(pending.payload) || !Array.isArray(pending.payload.records) || !loadHistoryForSync()) return;
    const compared = historySyncComparison(pending.payload.records);
    const selected = historySyncApi ? historySyncApi.selectedByIds(compared.accepted, selectedIds, { historyId: historySyncRawId, archiveSourceId: historyArchiveSourceId, receiptKey: receiptApi ? receiptApi.key : null }) : compared.accepted.filter((record) => new Set((selectedIds || []).map(text)).has(historySyncId(record)));
    const parts = historySyncApi ? historySyncApi.splitAccepted(selected) : { history: selected.map(historySyncRecord).filter(isPlainObject), receipts: [], archive: [] };
    const originalHistory = clone(historyDocument);
    const originalReceipts = clone(receiptRows());
    const nextHistory = historyDocument.concat(parts.history.map(clone));
    let historyChanged = false;
    if (parts.history.length) {
      if (!persistHistory(nextHistory, 'Valda säkra historikposter sammanfogades.', 'history-sync-status')) return;
      historyChanged = true;
    }
    if (parts.receipts.length) {
      const nextReceipts = originalReceipts.concat(parts.receipts.map(clone));
      if (!saveReceiptRows(nextReceipts)) {
        if (historyChanged) {
          const rolledBack = writeHistoryDocument(originalHistory);
          if (rolledBack) { historyDocument = originalHistory; historyLoaded = true; renderHistoryViews(); }
        }
        showStatus('history-sync-status', 'Kvittohistoriken kunde inte sparas. Historiksammanfogningen slutfördes inte.', true);
        return;
      }
      renderHistoryViews();
    }
    try {
      const previous = Array.isArray(historySyncState().conflicts) ? historySyncState().conflicts : [];
      historySyncSave({ pendingTransfer: null, pendingPackage: null, conflicts: previous.concat(compared.conflicts) });
      if (nativeStorage && nativeStorage.isActive() && text(pending.stagingTransferId)) {
        try { nativeStorage.deleteStagedTransfer(pending.stagingTransferId); if (typeof watchdog.setStorageDiagnostics === 'function') watchdog.setStorageDiagnostics(nativeStorage.diagnostics()); watchdog.step('runtime.history-sync.staging.cleaned', `Stagingtransfer ${pending.stagingTransferId} rensades efter säker sammanfogning.`); }
        catch (cleanupError) { watchdog.step('runtime.history-sync.staging.cleanup-failed', cleanupError && cleanupError.message ? cleanupError.message : 'Stagingtransfer kunde inte rensas.', 'warning'); }
      }
      pendingHistorySyncPackage = null;
      renderHistorySyncConflicts();
      renderHistorySyncReview();
      showStatus('history-sync-status', `${selected.length} säkra poster sammanfogades. ${compared.accepted.length - selected.length} hoppades över. ${compared.conflicts.length} konflikter lades åt sidan.`);
    } catch (error) { showStatus('history-sync-status', `Historiken är sparad men synkkontrollen måste öppnas igen: ${error.message}`, true); }
  }
  async function requestHistoryFromOtherUnit() {
    const service = mailboxSyncEnsure();
    if (!service || typeof service.sendHistoryRequest !== 'function') { showStatus('role-boundary-note', 'Syncmotorn är inte redo för historikbegäran.', true); return; }
    try { await service.sendHistoryRequest(); const status = isVehicleRole() ? 'history-sync-status' : 'role-boundary-note'; showStatus(status, `Historikbegäran är skickad till ${isVehicleRole() ? 'Mobil' : '189'}.`); }
    catch (error) { showStatus(isVehicleRole() ? 'history-sync-status' : 'role-boundary-note', error.message || 'Historikbegäran kunde inte skickas.', true); }
  }
  function renderHistorySyncConflicts() {
    const panel = byId('history-sync-conflicts'); if (!panel) return;
    panel.replaceChildren(); const conflicts = Array.isArray(historySyncState().conflicts) ? historySyncState().conflicts : [];
    if (!conflicts.length) { const empty = document.createElement('p'); empty.className = 'field-help'; empty.textContent = 'Inga olösta synkkonflikter.'; panel.appendChild(empty); return; }
    conflicts.forEach((item) => { const card = document.createElement('article'); card.className = 'queue-card'; const title = document.createElement('strong'); title.textContent = item.reason || 'Synkkonflikt'; const meta = document.createElement('p'); meta.className = 'field-help'; meta.textContent = `Inkommande: ${historySyncId(item.incoming) || 'okänd'} · Lokal: ${historySyncId(item.local) || 'saknas'}`; const keep = document.createElement('button'); keep.className = 'secondary-button'; keep.type = 'button'; keep.dataset.historySyncKeep = item.conflictId; keep.textContent = 'Behåll huvudregistret'; const add = document.createElement('button'); add.className = 'primary-button'; add.type = 'button'; add.dataset.historySyncAdd = item.conflictId; add.textContent = 'Lägg inkommande för redigering'; card.append(title, meta, keep, add); panel.appendChild(card); });
  }
  function resolveHistorySyncConflict(id, addIncoming) {
    const conflicts = Array.isArray(historySyncState().conflicts) ? historySyncState().conflicts : []; const conflict = conflicts.find((item) => text(item.conflictId) === text(id)); if (!conflict) return;
    if (addIncoming) {
      if (historySyncKind(conflict.incoming) !== 'history') { showStatus('history-sync-status', 'Denna konflikt gäller kvitto-/arkivhistorik och kan inte göras om till vanlig körhistorik automatiskt. Behåll huvudregistret eller importera källan på nytt.', true); return; }
      const base = clone(historySyncRecord(conflict.incoming)); const unique = `${historySyncId(conflict.incoming) || 'history'}-manual-${Date.now().toString(36)}`;
      if (!isPlainObject(base) || text(base.status, 'completed') !== 'completed' || !historySyncInterval(base)) { showStatus('history-sync-status', 'Den inkommande posten saknar giltig historikform och kan inte läggas in automatiskt. Den ligger kvar som konflikt.', true); return; }
      const record = { ...base, id: unique, jobId: unique, sourceJobId: unique, syncConflictSourceId: historySyncId(base), syncConflictResolvedAt: new Date().toISOString(), excludeFromEstimateLearning: true, learningExcludedReason: 'history_sync_conflict_manual_review', updatedByPackageVersion: PACKAGE_VERSION };
      if (!loadHistoryForSync() || !persistHistory(historyDocument.concat(record), 'Konfliktposten lades i Historik för redigering och undantas från tidsinlärning.', 'history-sync-status')) return;
    }
    try { historySyncSave({ conflicts: conflicts.filter((item) => text(item.conflictId) !== text(id)) }); renderHistorySyncConflicts(); showStatus('history-sync-status', addIncoming ? 'Konflikten lades in för manuell redigering.' : 'Huvudregistrets post behölls.'); } catch (error) { showStatus('history-sync-status', error.message || 'Konflikten kunde inte avslutas.', true); }
  }

  function mailboxState() {
    const service = mailboxSyncEnsure();
    return service && typeof service.state === 'function' ? service.state() : {
      currentUnit: mailboxUnitFromRole(), currentUnitLabel: mailboxSyncApi ? mailboxSyncApi.labelForUnit(mailboxUnitFromRole()) : 'Okänd',
      automaticFetchEnabled: false, fetchBusy: false, letterHistory: [], packageHistory: [], counts: {}, lastStatus: ''
    };
  }

  function renderMailboxSync() {
    const value = mailboxState();
    const unit = byId('mailbox-current-unit'); if (unit) unit.textContent = text(value.currentUnitLabel, 'Okänd');
    const mode = byId('mailbox-mode'); if (mode) mode.textContent = 'Manuell eller automatisk';
    const auto = byId('mailbox-auto-mode'); if (auto) auto.textContent = document.visibilityState === 'visible' ? 'På · 5 minuter · endast aktiv app' : 'Pausad · appen är inte aktiv';
    const status = byId('mailbox-status'); if (status) status.textContent = text(value.lastStatus, 'Ingen poståtgärd har körts ännu.');
    const history = byId('mailbox-history-list');
    if (history) {
      history.replaceChildren();
      const items = Array.isArray(value.letterHistory) ? value.letterHistory.slice().reverse() : [];
      if (!items.length) {
        const empty = document.createElement('p'); empty.className = 'empty-state'; empty.textContent = 'Ingen posthistorik ännu.'; history.appendChild(empty);
      } else items.forEach((item) => {
        const card = document.createElement('article'); card.className = 'queue-card';
        const heading = document.createElement('strong'); heading.textContent = `${text(item.type, 'Händelse')} · ${text(item.status, 'ok')}`;
        const meta = document.createElement('p'); meta.className = 'field-help'; meta.textContent = `${text(item.at)} · ${text(item.from, '–')} → ${text(item.to, '–')}`;
        const ids = document.createElement('p'); ids.className = 'field-help'; ids.textContent = `Brev-ID: ${text(item.letterId, '–')} · Sökväg: ${text(item.path, '–')}`;
        card.append(heading, meta, ids); history.appendChild(card);
      });
    }
    const send = byId('mailbox-send-test'); if (send) send.disabled = !githubSecureBridgeReady || !value.currentUnit;
    const fetch = byId('mailbox-fetch'); if (fetch) fetch.disabled = !githubSecureBridgeReady || !value.currentUnit || value.fetchBusy === true;
    const count = byId('sync-count'); if (count) count.textContent = String(Array.isArray(value.letterHistory) ? value.letterHistory.length : 0);
  }

  async function sendMailboxTestLetter() {
    const service = mailboxSyncEnsure();
    const target = text(byId('mailbox-test-target') && byId('mailbox-test-target').value);
    if (!service) { showStatus('mailbox-action-status', 'Host22 mailboxtransport är inte redo.', true); return; }
    try {
      showStatus('mailbox-action-status', 'Skickar syntetiskt testbrev…');
      const result = await service.sendTestLetter(target);
      showStatus('mailbox-action-status', `Testbrevet är skickat. Brev-ID: ${text(result.letterId)}`);
    } catch (error) { showStatus('mailbox-action-status', error.message || 'Testbrevet kunde inte skickas.', true); }
    renderMailboxSync(); renderSyncDiagnostic();
  }

  function p141NotificationError(error, stage = 'play') {
    try {
      syncDiagnosticObserve('notification-audio-error', {
        stage,
        role: text(hostInfo && hostInfo.role),
        packageVersion: PACKAGE_VERSION,
        error: syncV65SafeTechnicalText(error && error.message ? error.message : error, 180)
      });
    } catch (_) {}
  }

  function p141NotificationContext() {
    if (p141NotificationAudioContext) return p141NotificationAudioContext;
    const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
    if (typeof AudioContextCtor !== 'function') return null;
    try {
      p141NotificationAudioContext = new AudioContextCtor();
      return p141NotificationAudioContext;
    } catch (error) {
      p141NotificationError(error, 'context');
      return null;
    }
  }

  function p141PrepareNotificationAudio(force = false) {
    if (!(isVehicleRole() || isMobileRole()) || (!force && !p142NotificationEnabled())) return;
    const context = p141NotificationContext();
    if (!context) return;
    try {
      if (context.state === 'suspended' && typeof context.resume === 'function') {
        const resumed = context.resume();
        if (resumed && typeof resumed.catch === 'function') resumed.catch((error) => p141NotificationError(error, 'resume'));
      }
    } catch (error) { p141NotificationError(error, 'resume'); }
    if (p141NotificationBufferPromise || typeof window.fetch !== 'function') return;
    p141NotificationBufferPromise = window.fetch(P144_NOTIFICATION_SOUND_URL, { cache: 'force-cache' })
      .then((response) => {
        if (!response || response.ok !== true) throw new Error(`notis.mp3 HTTP ${Number(response && response.status) || 0}`);
        return response.arrayBuffer();
      })
      .then((bytes) => context.decodeAudioData(bytes.slice(0)))
      .catch((error) => {
        p141NotificationError(error, 'load');
        p141NotificationBufferPromise = null;
        return null;
      });
  }

  async function p141PlayNotificationAudio(force = false) {
    if (!(isVehicleRole() || isMobileRole()) || (!force && !p142NotificationEnabled())) return false;
    const context = p141NotificationContext();
    if (!context) { p141NotificationError('AudioContext saknas.', 'context'); return false; }
    try {
      const selected = p142NotificationSettings().selectedSound;
      if (selected !== 'custom-notis') {
        const profiles = {
          'single-chime': [[860,0,.24,'sine']],
          'double-chime': [[820,0,.18,'sine'],[1000,.28,.18,'sine']],
          'soft-bell': [[660,0,.7,'triangle'],[1320,0,.42,'sine']],
          'rising-chime': [[620,0,.16,'sine'],[780,.22,.16,'sine'],[980,.44,.16,'sine']],
          'warning-beep': [[980,0,.16,'square'],[980,.26,.16,'square']]
        };
        const notes = profiles[selected];
        if (!notes) return false;
        if (context.state === 'suspended' && typeof context.resume === 'function') await context.resume();
        notes.forEach(([frequency, offset, duration, wave]) => {
          const gain = context.createGain(), oscillator = context.createOscillator(), at = context.currentTime + offset;
          oscillator.type = wave; oscillator.frequency.setValueAtTime(frequency, at);
          gain.gain.setValueAtTime(0.0001, at); gain.gain.exponentialRampToValueAtTime(selected === 'warning-beep' ? 0.16 : 0.11, at + 0.015); gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
          oscillator.connect(gain); gain.connect(context.destination); oscillator.start(at); oscillator.stop(at + duration + 0.02);
        });
        syncDiagnosticObserve('notification-audio-played', { role: mailboxUnitFromRole(), packageVersion: PACKAGE_VERSION, sound: selected, engine: 'webaudio' });
        return true;
      }
      if (!p141NotificationBufferPromise) p141PrepareNotificationAudio(force);
      if (context.state === 'suspended' && typeof context.resume === 'function') await context.resume();
      const buffer = p141NotificationBufferPromise ? await p141NotificationBufferPromise : null;
      if (!buffer) throw new Error('notis.mp3 kunde inte förberedas.');
      const source = context.createBufferSource();
      source.buffer = buffer;
      source.connect(context.destination);
      source.start(0);
      syncDiagnosticObserve('notification-audio-played', { role: mailboxUnitFromRole(), packageVersion: PACKAGE_VERSION, file: 'notis.mp3', engine: 'webaudio' });
      return true;
    } catch (error) {
      p141NotificationError(error, 'play-webaudio');
      return false;
    }
  }

  function p142NotificationElement() {
    if (p142NotificationAudioElement) return p142NotificationAudioElement;
    try {
      const audio = new Audio(P144_NOTIFICATION_SOUND_URL);
      audio.preload = 'auto';
      audio.setAttribute('playsinline', '');
      p142NotificationAudioElement = audio;
      return audio;
    } catch (error) {
      p141NotificationError(error, 'html-audio-create');
      return null;
    }
  }

  function p142StopPrimedNotificationAudio() {
    const audio = p142NotificationAudioElement;
    p142NotificationGesturePromise = null;
    if (!audio) return;
    try {
      audio.loop = false;
      audio.volume = 0;
      audio.pause();
      audio.currentTime = 0;
    } catch (_) {}
  }

  function p142PrimeNotificationAudioFromGesture() {
    if (!(isVehicleRole() || isMobileRole()) || !p142NotificationEnabled()) return;
    p141PrepareNotificationAudio();
    const audio = p142NotificationElement();
    if (!audio) return;
    try {
      audio.pause();
      audio.currentTime = 0;
      audio.loop = true;
      audio.volume = 0;
      const result = audio.play();
      p142NotificationGesturePromise = result && typeof result.then === 'function'
        ? result.then(() => true).catch((error) => { p141NotificationError(error, 'prime-html-audio'); return false; })
        : Promise.resolve(true);
    } catch (error) {
      p141NotificationError(error, 'prime-html-audio');
      p142NotificationGesturePromise = Promise.resolve(false);
    }
  }

  function p144UnlockAudio() {
    if (!(isVehicleRole() || isMobileRole())) return;
    p141PrepareNotificationAudio(true);
    const context = p141NotificationContext();
    try { if (context && context.state === 'suspended' && typeof context.resume === 'function') void context.resume(); } catch (_) {}
    if (p142NotificationSettings().selectedSound === 'custom-notis') p142PrimeNotificationAudioFromGesture();
  }

  async function p142PlayNotificationAudio() {
    if (!(isVehicleRole() || isMobileRole()) || !p142NotificationEnabled()) { p142StopPrimedNotificationAudio(); return false; }
    if (p142NotificationSettings().selectedSound !== 'custom-notis') return p141PlayNotificationAudio();
    const audio = p142NotificationElement();
    try {
      const primed = p142NotificationGesturePromise ? await p142NotificationGesturePromise : false;
      if (audio && primed && !audio.paused) {
        audio.loop = false;
        audio.currentTime = 0;
        audio.volume = 1;
        audio.onended = () => { try { audio.volume = 0; audio.currentTime = 0; } catch (_) {} };
        syncDiagnosticObserve('notification-audio-played', { role: 'vehicle_189', packageVersion: PACKAGE_VERSION, file: 'notis.mp3', engine: 'html-audio-primed' });
        p142NotificationGesturePromise = null;
        return true;
      }
    } catch (error) { p141NotificationError(error, 'play-html-audio'); }
    p142StopPrimedNotificationAudio();
    return p141PlayNotificationAudio();
  }

  async function p142TestNotificationAudio() {
    if (!(isVehicleRole() || isMobileRole())) { showStatus('notification-sound-status', 'Notisljudet används endast på 189 och Mobil.', true); return; }
    const selected = p142NotificationSettings().selectedSound;
    if (selected === 'none') { showStatus('notification-sound-status', 'Ingen signal är vald.'); return; }
    if (selected !== 'custom-notis') {
      const played = await p141PlayNotificationAudio(true);
      showStatus('notification-sound-status', played ? 'Testljudet spelas.' : 'Testljudet kunde inte spelas.', !played);
      return;
    }
    const audio = p142NotificationElement();
    let htmlError = null;
    if (audio) {
      try {
        audio.pause();
        audio.currentTime = 0;
        audio.loop = false;
        audio.volume = 1;
        const result = audio.play();
        if (result && typeof result.then === 'function') await result;
        showStatus('notification-sound-status', 'Testljudet spelas. Kontrollera enhetens mediavolym om du inte hör det.');
        syncDiagnosticObserve('notification-audio-test', { role: 'vehicle_189', packageVersion: PACKAGE_VERSION, file: 'notis.mp3', status: 'played', engine: 'html-audio' });
        return;
      } catch (error) {
        htmlError = error;
        p141NotificationError(error, 'test-html-audio');
      }
    }
    const webAudioPlayed = await p141PlayNotificationAudio(true);
    if (webAudioPlayed) {
      showStatus('notification-sound-status', 'Testljudet spelas via reservvägen WebAudio. Kontrollera enhetens mediavolym om du inte hör det.');
      syncDiagnosticObserve('notification-audio-test', { role: 'vehicle_189', packageVersion: PACKAGE_VERSION, file: 'notis.mp3', status: 'played', engine: 'webaudio-fallback' });
      return;
    }
    const message = htmlError && htmlError.message ? htmlError.message : 'HTMLAudio och WebAudio kunde inte spela notis.mp3.';
    showStatus('notification-sound-status', `Testljudet kunde inte spelas: ${syncV65SafeTechnicalText(message, 120)}`, true);
  }

  function p144StopAutoFetch() { if (p144AutoFetchTimer !== null) { window.clearTimeout(p144AutoFetchTimer); p144AutoFetchTimer = null; } p144AutoFetchScheduledAt = ''; }
  function p144ScheduleAutoFetch() {
    p144StopAutoFetch();
    const unit = mailboxUnitFromRole();
    if (document.visibilityState !== 'visible' || !['189', 'mobile'].includes(unit) || !githubSecureBridgeReady) return;
    const offset = unit === 'mobile' ? 1 : 0, current = new Date(), target = new Date(current);
    target.setSeconds(0, 0);
    let minute = target.getMinutes();
    const remainder = ((minute - offset) % 5 + 5) % 5;
    target.setMinutes(minute + (remainder === 0 && current.getSeconds() === 0 && current.getMilliseconds() === 0 ? 5 : (5 - remainder)));
    const delay = Math.max(250, target.getTime() - Date.now());
    p144AutoFetchScheduledAt = target.toISOString();
    p144AutoFetchTimer = window.setTimeout(() => { p144AutoFetchTimer = null; p144AutoFetchScheduledAt = ''; if (document.visibilityState === 'visible') void runMailboxFetch('auto'); }, delay);
  }
  function p144HandleAutoFetchVisibility() { if (document.visibilityState === 'visible') p144ScheduleAutoFetch(); else p144StopAutoFetch(); }
  async function runMailboxFetch(trigger = 'manual') {
    const service = mailboxSyncEnsure();
    if (!service) { showStatus('mailbox-action-status', 'Host22 mailboxtransport är inte redo.', true); return; }
    if (p141ManualFetchInProgress) { showStatus('mailbox-action-status', 'Hämta post kör redan.'); if (trigger === 'auto') p144ScheduleAutoFetch(); return; }
    p141ManualFetchInProgress = true;
    p182MeaningfulIncomingThisFetch = false;
    p144LastFetchTrigger = trigger;
    if (trigger === 'manual') p142PrimeNotificationAudioFromGesture();
    try {
      showStatus('mailbox-action-status', trigger === 'auto' ? 'Hämtar post automatiskt…' : 'Hämtar post manuellt…');
      const result = await service.fetchMail(trigger);
      if (result.status === 'already_running') showStatus('mailbox-action-status', 'Hämta post kör redan.');
      else if (result.ok) showStatus('mailbox-action-status', `${trigger === 'auto' ? 'Automatisk hämtning' : 'Hämta post'} klar. ${Number(result.count) || 0} brev behandlades.`);
      else showStatus('mailbox-action-status', 'Hämta post kunde inte slutföras.', true);
    } catch (error) {
      showStatus('mailbox-action-status', error.message || 'Hämta post kunde inte slutföras.', true);
    } finally {
      const shouldNotify = p182MeaningfulIncomingThisFetch;
      p182MeaningfulIncomingThisFetch = false;
      p141ManualFetchInProgress = false;
      if (shouldNotify && p142NotificationEnabled()) void p142PlayNotificationAudio();
      else p142StopPrimedNotificationAudio();
      renderMailboxSync(); renderSyncDiagnostic();
      p144ScheduleAutoFetch();
    }
  }
  function fetchMailboxPost() { return runMailboxFetch('manual'); }

  function p138Today() { return localDateKey(new Date()); }
  function p138Date(value) { return /^\d{4}-\d{2}-\d{2}$/.test(text(value)) ? text(value) : p138Today(); }
  function p138Time(value) { return /^([01]\d|2[0-3]):[0-5]\d$/.test(text(value)) ? text(value) : ''; }
  function p138Sort(items) { return items.map((raw, index) => ({ raw, index, value: displayQueueItem(raw, index) })).sort((a,b)=>{const ad=p138Date(a.value.plannedDate),bd=p138Date(b.value.plannedDate);if(ad!==bd)return ad.localeCompare(bd);const at=p138Time(a.value.plannedTime),bt=p138Time(b.value.plannedTime);if(Boolean(at)!==Boolean(bt))return at?-1:1;if(at!==bt)return at.localeCompare(bt);if(!at&&a.value.source!==b.value.source)return a.value.source==='manual-vehicle-received'?-1:1;return a.index-b.index;}).map(x=>x.raw); }
  function p138Conflict(candidate, skipId = '') { const date=p138Date(candidate.plannedDate), time=p138Time(candidate.plannedTime); return time ? queueDocument.map((raw,index)=>displayQueueItem(raw,index)).find(item=>item.id!==skipId&&p138Date(item.plannedDate)===date&&p138Time(item.plannedTime)===time) : null; }
  function p138Payload(raw) { const item=normalizeJobRecord(raw,'p138-package'); return {...item,id:'',jobId:'',status:'queued',source:'mobile-assignment-package',plannedDate:p138Date(item.plannedDate),plannedTime:p138Time(item.plannedTime),temporaryPlaces:temporaryPlaceService.normalizeCollection(item.temporaryPlaces)}; }

  // P150: sourcePlanningItemId är den permanenta idempotensnyckeln för Mobil -> 189.
  function p150NormalizeAcceptedMobileAssignments(documentValue = settingsDocument) {
    const raw = documentValue && documentValue[P150_ACCEPTED_MOBILE_ASSIGNMENTS_KEY];
    const source = Array.isArray(raw) ? raw : (isPlainObject(raw) && Array.isArray(raw.items) ? raw.items : []);
    const byId = new Map();
    source.forEach((entry) => {
      const sourcePlanningItemId = text(entry && (entry.sourcePlanningItemId || entry.id));
      if (!sourcePlanningItemId) return;
      const normalized = {
        sourcePlanningItemId,
        acceptedAt: text(entry && entry.acceptedAt),
        localJobId: text(entry && entry.localJobId),
        lastPackageId: text(entry && (entry.lastPackageId || entry.packageId))
      };
      const current = byId.get(sourcePlanningItemId);
      if (!current || text(normalized.acceptedAt) >= text(current.acceptedAt)) byId.set(sourcePlanningItemId, normalized);
    });
    return { schemaVersion: 1, items: Array.from(byId.values()) };
  }

  function p150ReadStoreJson(storeName, fallback) {
    try {
      const raw = window.StadslassHost.readStore(storeName);
      return raw ? JSON.parse(raw) : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function p150DiscoveredAcceptedMobileAssignments() {
    const discovered = new Map();
    const add = (record) => {
      if (!record || typeof record !== 'object') return;
      const sourcePlanningItemId = text(record.p138SourcePlanningItemId);
      if (!sourcePlanningItemId || discovered.has(sourcePlanningItemId)) return;
      discovered.set(sourcePlanningItemId, {
        sourcePlanningItemId,
        acceptedAt: text(record.createdAt || record.startedAt || record.completedAt || record.updatedAt),
        localJobId: text(record.jobId || record.id),
        lastPackageId: text(record.p138PackageId)
      });
    };
    const queueRecords = queueLoaded ? queueDocument : p150ReadStoreJson(QUEUE_STORE, []);
    (Array.isArray(queueRecords) ? queueRecords : []).forEach(add);
    const activeRecord = p150ReadStoreJson(ACTIVE_JOB_STORE, {});
    add(activeRecord);
    const historyRecords = historyLoaded ? historyDocument : (() => {
      try { return readHistoryDocument(); } catch (_) { return []; }
    })();
    (Array.isArray(historyRecords) ? historyRecords : []).forEach(add);
    return discovered;
  }

  function p150PersistAcceptedMobileAssignments(registry) {
    const next = { ...settingsDocument, [P150_ACCEPTED_MOBILE_ASSIGNMENTS_KEY]: registry, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) return false;
    settingsDocument = next;
    return true;
  }

  function p150AcceptedMobileAssignmentIds() {
    const registry = p150NormalizeAcceptedMobileAssignments();
    const merged = new Map(registry.items.map((entry) => [entry.sourcePlanningItemId, entry]));
    let changed = false;
    p150DiscoveredAcceptedMobileAssignments().forEach((entry, sourcePlanningItemId) => {
      if (merged.has(sourcePlanningItemId)) return;
      merged.set(sourcePlanningItemId, entry);
      changed = true;
    });
    if (changed && !p150PersistAcceptedMobileAssignments({ schemaVersion: 1, items: Array.from(merged.values()) }) && watchdog) {
      watchdog.step('runtime.assignment-idempotency.persist-failed', 'Accepterade Mobiluppdrag kunde läsas från arbetslagren men dubblettregistret kunde inte backfyllas.', 'warning');
    }
    return new Set(merged.keys());
  }

  function p150RecordAcceptedMobileAssignment(sourcePlanningItemId, localJobId, packageId, acceptedAt) {
    const sourceId = text(sourcePlanningItemId);
    if (!sourceId) return false;
    const registry = p150NormalizeAcceptedMobileAssignments();
    const byId = new Map(registry.items.map((entry) => [entry.sourcePlanningItemId, entry]));
    byId.set(sourceId, { sourcePlanningItemId: sourceId, acceptedAt: text(acceptedAt), localJobId: text(localJobId), lastPackageId: text(packageId) });
    return p150PersistAcceptedMobileAssignments({ schemaVersion: 1, items: Array.from(byId.values()) });
  }

  function p150MobileAssignmentCanBeSent(rawItem) {
    const status = text(rawItem && rawItem.p138Transfer && rawItem.p138Transfer.status);
    return !['sent-waiting', 'accepted', 'already-accepted', 'conflict-pending'].includes(status);
  }

  async function handleIncomingAssignmentPackage(pkg) {
    if (!isVehicleRole()) return {status:'validation-error',reasonCode:'wrong-recipient',message:'Endast 189 kan ta emot uppdrag.'};
    if (!queueLoaded) loadQueueIfNeeded(); const payload=p138Payload(pkg.payload), sourcePlanningItemId=text(pkg.sourcePlanningItemId);
    if (p150AcceptedMobileAssignmentIds().has(sourcePlanningItemId)) return {status:'already-accepted',message:'Uppdraget har redan tagits emot av 189.'};
    if (!findJobTypeById(payload.jobTypeId)) return {status:'validation-error',reasonCode:'unknown-job-type',message:'Jobbtypen saknas i 189:s register.'};
    for (const pair of [['from',payload.fromPlaceId],['destination',payload.destinationPlaceId]]) if (pair[1]&&!payload.temporaryPlaces[pair[0]]&&!findPlaceById(pair[1])) return {status:'validation-error',reasonCode:'unknown-registered-place',message:`${pair[0]==='from'?'Från':'Till'} saknas i 189:s register.`};
    const conflict=p138Conflict(payload); if(conflict&&!window.confirm(`Tidskonflikt med ${conflict.jobType}, ${p138Date(payload.plannedDate)} kl. ${payload.plannedTime}. Lägg nya uppdraget direkt under?`)) return {status:'rejected-conflict',reasonCode:'same-planned-time',message:'Tidskonflikten avvisades på 189.'};
    const now=new Date().toISOString(),id=createLocalId('job'),item=normalizeJobRecord({...payload,id,jobId:id,p138SourcePlanningItemId:sourcePlanningItemId,p138PackageId:text(pkg.packageId),p141NewFromMobile:true,createdAt:now,updatedAt:now,createdByPackageVersion:PACKAGE_VERSION,updatedByPackageVersion:PACKAGE_VERSION},'p138-received');
    if (!persistQueue(p138Sort([...queueDocument,item]),'Uppdrag från Mobil lades i 189:s kö.')) return {status:'validation-error',reasonCode:'queue-write-failed',message:'189:s kö kunde inte sparas.'};
    if (!p150RecordAcceptedMobileAssignment(sourcePlanningItemId, id, pkg.packageId, now) && watchdog) watchdog.step('runtime.assignment-idempotency.persist-failed', 'Uppdraget ligger säkert i kön men det permanenta dubblettregistret kunde inte sparas. Kö/Aktivt/Historik används fortsatt som dubblettskydd.', 'warning');
    p182MeaningfulIncomingThisFetch = true;
    syncQueueIncomingMarker();
    return {status:'accepted',message:'Uppdraget ligger i 189:s kö.'};
  }
  async function handleIncomingAssignmentResult(result) { if(!isMobileRole()||!queueLoaded)return; const status=text(result.status),received=['accepted','already-accepted'].includes(status),next=queueDocument.map(raw=>text(raw&&raw.id)===text(result.sourcePlanningItemId)?{...raw,p138Transfer:{...(raw.p138Transfer||{}),status,packageId:text(result.packageId),packageReceivedAt:text(result.packageReceivedAt),acceptedAt:received?text(raw&&raw.p138Transfer&&raw.p138Transfer.acceptedAt,new Date().toISOString()):''}}:raw); persistQueue(next,'Uppdragsstatus från 189 har uppdaterats.'); }
  async function sendSelectedAssignments() { if(!isMobileRole())return; if(!queueLoaded)loadQueueIfNeeded(); const ids=Array.from(document.querySelectorAll('input[data-p138-send]:checked')).map(node=>node.dataset.p138Send),selected=ids.map(id=>queueItemById(id)).filter(Boolean),blocked=selected.filter(entry=>!p150MobileAssignmentCanBeSent(entry.raw)),items=selected.filter(entry=>p150MobileAssignmentCanBeSent(entry.raw)); if(blocked.length){showStatus('queue-load-status','Ett redan skickat eller mottaget uppdrag kan inte skickas igen. Skapa ett nytt uppdrag om uppgifterna ska ändras.',true);return;} if(!items.length){showStatus('queue-load-status','Välj minst ett uppdrag att skicka till 189.',true);return;} const service=mailboxSyncEnsure(); try{const result=await service.sendAssignmentPackages(items.map(entry=>{const payload=p138Payload(entry.raw),recipient=payload&&payload.ata&&payload.ata.recipient,contact=recipient&&ataNotificationApi&&ataNotificationApi.validEmail(recipient.email)?{name:text(recipient.name)||text(recipient.email),email:text(recipient.email).toLowerCase()}:null;return {sourcePlanningItemId:entry.display.id,payload,contact};}),'189'); const packageIds=result.packageRefs.map(ref=>ref.packageId),next=queueDocument.map((raw,index)=>items.some(entry=>entry.index===index)?{...raw,p138Transfer:{status:'sent-waiting',packageIds,sentAt:new Date().toISOString()}}:raw);persistQueue(next,`${result.packageRefs.length} paket skickades till 189.`);}catch(error){showStatus('queue-load-status',error.message||'Uppdragen kunde inte skickas.',true);}}

  function performanceContext() {
    return {
      packageVersion: PACKAGE_VERSION,
      hostVersion: text(hostInfo && hostInfo.hostVersionName),
      role: text(hostInfo && hostInfo.role, 'unknown'),
      device: text(hostInfo && hostInfo.deviceId, 'local').slice(0, 24),
      queueCount: queueLoaded ? queueDocument.length : 0,
      activeRequests: 0,
      waitingWork: 0,
    };
  }

  function performanceEnsure() {
    if (performanceMonitor || !performanceMonitorApi) return performanceMonitor;
    performanceMonitor = performanceMonitorApi.create({ context: performanceContext });
    return performanceMonitor;
  }

  function performanceObserve(kind, details = {}) {
    const monitor = performanceEnsure();
    if (monitor) monitor.observe(kind, details);
  }

  function syncDiagnosticEnsure() {
    if (syncDiagnostic || !syncDiagnosticApi) return syncDiagnostic;
    syncDiagnostic = syncDiagnosticApi.create({ context: syncDiagnosticContext, mailboxState });
    return syncDiagnostic;
  }

  function syncDiagnosticObserve(kind, details = {}) {
    const diagnostic = syncDiagnosticEnsure();
    if (diagnostic) diagnostic.observe(kind, details);
  }

  function renderSyncV63() {
    const status = syncV65ConfigurationStatus();
    const configuration = syncV63Configuration();
    const intro = byId('sync-v63-intro');
    if (intro) intro.textContent = 'Säker GitHub-konfiguration används av den nya beställningsstyrda Sync-funktionen. P141 transporterar valda uppdrag manuellt till 189; nya mottagna Mobil-uppdrag markeras lokalt i Kö.';
    renderMailboxSync();
    const token = byId('sync-v85-token-status'); if (token) token.textContent = syncV65ConfigurationLabel(status);
    const owner = byId('sync-v63-owner'); if (owner && document.activeElement !== owner) owner.value = text(configuration.owner);
    const repository = byId('sync-v63-repository'); if (repository && document.activeElement !== repository) repository.value = text(configuration.repository);
    const branch = byId('sync-v63-branch'); if (branch && document.activeElement !== branch) branch.value = text(configuration.branch, 'main');
    ['sync-v63-save', 'sync-v63-check', 'sync-v63-clear'].forEach((id) => { const button = byId(id); if (button) button.disabled = !githubSecureBridgeReady; });
  }

  function renderSyncRoleView() { renderSyncV63(); }

    function liveReportStamp(value = new Date().toISOString()) {
    return text(value).replace(/[-:]/g, '').replace('T', '_').replace('Z', '').replace('.', '_');
  }

  function reportFileStamp(value = new Date().toISOString()) {
    const date = new Date(value);
    const safe = Number.isNaN(date.getTime()) ? new Date() : date;
    const part = (number) => String(number).padStart(2, '0');
    return `${safe.getFullYear()}-${part(safe.getMonth() + 1)}-${part(safe.getDate())}_${part(safe.getHours())}${part(safe.getMinutes())}${part(safe.getSeconds())}`;
  }

  function reportTypeConfig(type) {
    return type === 'performance'
      ? { key: PERFORMANCE_REPORT_SNAPSHOT_KEY, label: 'Prestandarapport', expectedType: 'performance', header: 'STADSLASS PRESTANDARAPPORT', textId: 'performance-report-text', summaryId: 'performance-report-summary', statusId: 'performance-report-status', filePrefix: 'prestandarapport' }
      : { key: SYNC_REPORT_SNAPSHOT_KEY, label: 'Sync-/postrapport', expectedType: 'sync-verification', header: 'STADSLASS SYNK-/POSTRAPPORT', textId: 'sync-report-textarea', summaryId: 'sync-report-summary', statusId: 'sync-diagnostic-status', filePrefix: 'synkpostrapport' };
  }

  function currentReportSnapshot(type) {
    return type === 'performance' ? performanceReportSnapshot : syncReportSnapshot;
  }

  function setCurrentReportSnapshot(type, snapshot) {
    if (type === 'performance') performanceReportSnapshot = snapshot;
    else syncReportSnapshot = snapshot;
  }

  function normalizeReportSnapshot(type, raw) {
    const config = reportTypeConfig(type);
    if (!isPlainObject(raw)) return null;
    const content = text(raw.content);
    const reportId = text(raw.reportId);
    const generatedAt = text(raw.generatedAt);
    if (Number(raw.schemaVersion) !== REPORT_SNAPSHOT_SCHEMA_VERSION || text(raw.reportType) !== config.expectedType || !content.startsWith(config.header) || !reportId || !generatedAt) return null;
    const fileName = `${config.filePrefix}_v${PACKAGE_VERSION}_${reportFileStamp(generatedAt)}.txt`;
    return { schemaVersion: REPORT_SNAPSHOT_SCHEMA_VERSION, reportType: config.expectedType, reportId, generatedAt, packageVersion: Number(raw.packageVersion) || PACKAGE_VERSION, fileName, summary: text(raw.summary), content, eventCount: Math.max(0, Number(raw.eventCount) || 0), counts: isPlainObject(raw.counts) ? { ...raw.counts } : {} };
  }

  function loadStoredReportSnapshots() {
    performanceReportSnapshot = normalizeReportSnapshot('performance', settingsDocument[PERFORMANCE_REPORT_SNAPSHOT_KEY]);
    syncReportSnapshot = normalizeReportSnapshot('sync', settingsDocument[SYNC_REPORT_SNAPSHOT_KEY]);
  }

  function persistReportSnapshot(type, raw) {
    const config = reportTypeConfig(type);
    const snapshot = normalizeReportSnapshot(type, raw);
    if (!snapshot) throw new Error(`${config.label}en kunde inte verifieras och sparades inte.`);
    setCurrentReportSnapshot(type, snapshot);
    const next = { ...settingsDocument, [config.key]: snapshot, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || `${config.label}en skapades och visas, men kunde inte sparas lokalt.`);
    settingsDocument = next;
    return snapshot;
  }

  function clearStoredReportSnapshot(type) {
    const config = reportTypeConfig(type);
    const next = { ...settingsDocument, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    delete next[config.key];
    if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || 'Rapportvyn kunde inte rensas.');
    settingsDocument = next;
    setCurrentReportSnapshot(type, null);
  }

  function reportSnapshotSummary(type, snapshot) {
    if (!snapshot) return type === 'performance' ? 'Ingen färdig prestandarapport finns.' : 'Ingen färdig verifieringsrapport finns.';
    const created = formatTimestamp(snapshot.generatedAt);
    if (type === 'performance') return `${snapshot.eventCount} händelser · skapad ${created} · ligger kvar efter omstart.`;
    return `${snapshot.eventCount} testhändelser · ingen synkfunktion installerad · skapad ${created} · ligger kvar efter omstart.`;
  }

  function renderReportSnapshot(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    const textarea = byId(config.textId);
    const summary = byId(config.summaryId);
    if (textarea) textarea.value = snapshot ? snapshot.content : '';
    if (summary) summary.textContent = reportSnapshotSummary(type, snapshot);
    const prefix = type === 'performance' ? 'performance-report' : 'sync-report';
    ['copy', 'download', 'mail', 'clear'].forEach((action) => { const button = byId(`${prefix}-${action}`); if (button) button.disabled = !snapshot; });
  }

  function renderReportViews() {
    renderReportSnapshot('performance');
    renderReportSnapshot('sync');
  }

  function renderReportMailProfile() {
    const input = byId('report-mail-email');
    const profile = syncReportProfile();
    if (input && document.activeElement !== input) input.value = text(profile.email);
  }

  function saveReportMailRecipient() {
    const email = text(byId('report-mail-email') && byId('report-mail-email').value);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showStatus('report-mail-status', 'Skriv en giltig mailadress.', true); return; }
    const current = syncReportProfile();
    const profile = { ...current, email };
    const next = { ...settingsDocument, syncReportMail: profile, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(next)) { showStatus('report-mail-status', window.StadslassHost.getLastError() || 'Rapportmottagaren kunde inte sparas.', true); return; }
    settingsDocument = next;
    showStatus('report-mail-status', 'Rapportmottagaren är sparad lokalt.');
  }

  function liveReportExportBusy() {
    return liveReportExports.size > 0;
  }

  function renderLiveReportExportState() {
    const busy = liveReportExportBusy();
    ['performance-report-download', 'sync-report-download'].forEach((id) => {
      const button = byId(id);
      if (button) button.disabled = busy || !currentReportSnapshot(id.startsWith('performance') ? 'performance' : 'sync');
    });
  }

  function validateLiveReportSnapshot(type, snapshot, expectedReportId) {
    const config = reportTypeConfig(type);
    const content = text(snapshot && snapshot.content);
    const reportType = text(snapshot && snapshot.reportType);
    const forbiddenHeader = type === 'performance' ? reportTypeConfig('sync').header : reportTypeConfig('performance').header;
    if (reportType !== config.expectedType || !content.startsWith(config.header) || content.startsWith(forbiddenHeader)) throw new Error('Rapporttypen kunde inte verifieras. Ingen fil skickades till spardialogen.');
    if (!content.includes(`Rapport-ID: ${expectedReportId}`) || !content.includes(`Funktionspaket: ${PACKAGE_VERSION}`)) throw new Error('Rapportens identitet kunde inte verifieras. Ingen fil skickades till spardialogen.');
    return content;
  }

  function beginLiveReportExport(type, snapshot, fileName) {
    if (liveReportExportBusy()) throw new Error('En rapportexport pågår redan. Slutför eller avbryt den först.');
    const reportId = text(snapshot && snapshot.reportId);
    const contentUtf8 = validateLiveReportSnapshot(type, snapshot, reportId);
    const requestId = `${type === 'performance' ? 'performance-report' : 'sync-report'}-export-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    liveReportExports.set(requestId, { type, fileName, reportId });
    renderLiveReportExportState();
    try {
      const result = parseObject(window.StadslassHost.requestTextFileExport(JSON.stringify({ schemaVersion: 1, requestId, fileName, mimeType: 'text/plain', contentUtf8 })), {});
      if (result.ok !== true) throw new Error('Rapporten finns kvar, men spardialogen kunde inte öppnas.');
      return requestId;
    } catch (error) {
      liveReportExports.delete(requestId);
      renderLiveReportExportState();
      throw error;
    }
  }

  function renderPerformanceDiagnostic() {
    const monitor = performanceEnsure();
    const summary = byId('performance-diagnostic-summary');
    if (!monitor || !summary || typeof monitor.state !== 'function') return;
    const value = monitor.state();
    const eventCount = Array.isArray(value.events) ? value.events.length : 0;
    const oldReport = Boolean(performanceReportSnapshot);
    summary.textContent = value.active
      ? `Prestandatest pågår · ${eventCount} händelser registrerade.${oldReport ? ' Rapportfältet visar senaste färdiga rapport.' : ''}`
      : `Prestandatest stoppat · ${eventCount} händelser registrerade.`;
    const stopButton = byId('performance-monitor-stop');
    const startButton = byId('performance-monitor-start-new');
    if (stopButton) stopButton.disabled = !value.active;
    if (startButton) startButton.disabled = value.active;
    renderReportSnapshot('performance');
  }

  function createPerformanceReportSnapshot() {
    const monitor = performanceEnsure();
    if (!monitor) throw new Error('Prestandaövervakningen saknas.');
    const reportId = `performance-v135-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const raw = monitor.snapshotReport({ reportId });
    return persistReportSnapshot('performance', { ...raw, schemaVersion: REPORT_SNAPSHOT_SCHEMA_VERSION, packageVersion: PACKAGE_VERSION, summary: `${raw.eventCount} prestandahändelser` });
  }

  function startNewPerformanceTest() {
    try {
      const monitor = performanceEnsure();
      if (!monitor) throw new Error('Prestandaövervakningen saknas.');
      if (monitor.state().active) throw new Error('Ett prestandatest pågår redan.');
      monitor.start({ reset: true });
      renderPerformanceDiagnostic();
      showStatus('performance-report-status', 'Nytt prestandatest startat. Den senaste färdiga rapporten ligger kvar tills en ny rapport skapas eller rapportvyn rensas.');
    } catch (error) { showStatus('performance-report-status', error.message || 'Prestandatestet kunde inte startas.', true); }
  }

  function stopPerformanceMonitor() {
    try {
      const monitor = performanceEnsure();
      if (!monitor || !monitor.state().active) throw new Error('Inget prestandatest pågår.');
      monitor.stop('manual-stop-and-create-report');
      const snapshot = createPerformanceReportSnapshot();
      renderPerformanceDiagnostic();
      showStatus('performance-report-status', `Prestandatestet är klart. ${snapshot.eventCount} händelser finns i rapportfältet och rapporten är sparad lokalt.`);
    } catch (error) { renderPerformanceDiagnostic(); showStatus('performance-report-status', error.message || 'Prestandarapporten kunde inte skapas.', true); }
  }

  function syncDiagnosticContext() {
    const configuration = syncV63Configuration();
    const secureStatus = syncV65ConfigurationStatus();
    const mailbox = mailboxState();
    return {
      packageVersion: PACKAGE_VERSION,
      hostVersion: text(hostInfo && hostInfo.hostVersionName),
      role: text(hostInfo && hostInfo.role),
      deviceId: text(hostInfo && hostInfo.deviceId),
      syncInstalled: true,
      mailboxTransportApiVersion: Number(hostInfo && hostInfo.mailboxTransportApiVersion) || 0,
      mailboxUnit: text(mailbox.currentUnit),
      githubConfiguration: {
        configured: secureStatus.ok === true ? secureStatus.configured === true : null,
        verificationState: text(secureStatus.verificationState, 'unverified'),
        owner: text(configuration.owner), repository: text(configuration.repository), branch: text(configuration.branch)
      }
    };
  }

  function renderSyncDiagnostic() {
    const diagnostic = syncDiagnosticEnsure();
    const summary = byId('sync-diagnostic-summary');
    if (!diagnostic || !summary || typeof diagnostic.state !== 'function') return;
    const value = diagnostic.state();
    const counts = value.counts || {};
    const mailbox = mailboxState();
    summary.textContent = value.inventoryFinishedAt
      ? `Senaste Sync-rapport skapad · ${Number(counts.manualFetchRuns) || 0} manuella hämtningar · ${Number(counts.lettersCreated) || 0} testbrev skapade.`
      : 'Skapa en Sync-/postrapport från den nya beställningsstyrda testfunktionen. Ingen automatisk hämtning körs.';
    const events = byId('sync-diagnostic-events'); if (events) events.textContent = String(Array.isArray(mailbox.letterHistory) ? mailbox.letterHistory.length : 0);
    const registers = byId('sync-diagnostic-registers'); if (registers) registers.textContent = String(Number(counts.lettersRead) || 0);
    const posts = byId('sync-diagnostic-posts'); if (posts) posts.textContent = String(Number(counts.receiptsReceived) || 0);
    const active = byId('sync-diagnostic-active-requests'); if (active) active.textContent = mailbox.fetchBusy ? '1' : '0';
    const oldest = byId('sync-diagnostic-oldest-active'); if (oldest) oldest.textContent = 'Beställningsstyrd';
    const rerun = byId('sync-diagnostic-rerun'); if (rerun) rerun.disabled = false;
    renderReportSnapshot('sync'); renderPerformanceDiagnostic(); renderLiveReportExportState();
  }

  function createSyncReportSnapshot() {
    const diagnostic = syncDiagnosticEnsure();
    if (!diagnostic) throw new Error('Sync-rapporttjänsten saknas.');
    const reportId = `sync-mailbox-p140-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const monitor = performanceEnsure();
    const performanceState = monitor && typeof monitor.state === 'function' ? monitor.state() : {};
    const raw = diagnostic.snapshotReport({ reportId, performanceState });
    return persistReportSnapshot('sync', { ...raw, schemaVersion: REPORT_SNAPSHOT_SCHEMA_VERSION, packageVersion: PACKAGE_VERSION, summary: `${Number(raw.counts && raw.counts.manualFetchRuns) || 0} manuella hämtningar · ${Number(raw.counts && raw.counts.lettersCreated) || 0} testbrev` });
  }

  function runSyncDiagnosticInventory() {
    try {
      const diagnostic = syncDiagnosticEnsure();
      if (!diagnostic) throw new Error('Sync-rapporttjänsten saknas.');
      const result = diagnostic.inventory({ reason: 'manual-mailbox-report' });
      if (!result.ok) throw new Error('Sync-rapporten kunde inte skapas.');
      const snapshot = createSyncReportSnapshot();
      renderSyncDiagnostic();
      showStatus('sync-diagnostic-status', `Sync-/postrapport skapad. ${Number(snapshot.counts.manualFetchRuns) || 0} manuella Hämta post-körningar finns registrerade.`);
    } catch (error) { renderSyncDiagnostic(); showStatus('sync-diagnostic-status', error.message || 'Sync-/postrapporten kunde inte skapas.', true); }
  }

  function copyStoredReport(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    if (!snapshot) { showStatus(config.statusId, 'Ingen färdig rapport finns att kopiera.', true); return; }
    try {
      hostCopyText(config.label, snapshot.content);
      showStatus(config.statusId, `${config.label}en är kopierad. Fil och mail är säkrare för mycket långa rapporter.`);
    } catch (error) { showStatus(config.statusId, error.message || 'Rapporten kunde inte kopieras.', true); }
  }

  function downloadStoredReport(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    if (!snapshot) { showStatus(config.statusId, 'Ingen färdig rapport finns att ladda ner.', true); return; }
    try {
      if (!hostInfo || Number(hostInfo.textFileExportApiVersion) < 1 || typeof window.StadslassHost.requestTextFileExport !== 'function') throw new Error('Den här installationen saknar stöd för rapportfil.');
      beginLiveReportExport(type, snapshot, snapshot.fileName);
      showStatus(config.statusId, 'Välj var den redan färdiga rapporten ska sparas. Rapporten ligger kvar efter avbruten eller misslyckad sparning.');
    } catch (error) { showStatus(config.statusId, error.message || 'Spardialogen kunde inte öppnas. Rapporten ligger kvar.', true); }
  }

  function mailStoredReport(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    try {
      if (!snapshot) throw new Error('Ingen färdig rapport finns att skicka.');
      const profile = syncReportProfile();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(profile.email))) throw new Error('Spara en giltig rapportmottagare först.');
      if (!mailService) throw new Error('Appens inbyggda mailtjänst saknas.');
      mailService.open({
        mailType: type === 'performance' ? 'performance-report' : 'sync-report',
        recipient: profile.email,
        subject: type === 'performance' ? `Prestandarapport v${PACKAGE_VERSION}` : `Sync-/postrapport v${PACKAGE_VERSION}`,
        body: type === 'performance' ? 'Prestandarapporten finns bifogad som textfil.' : 'Sync-/postrapporten finns bifogad som textfil.',
        attachment: { fileName: snapshot.fileName, mimeType: 'text/plain', contentUtf8: snapshot.content }
      }, hostInfo);
      showStatus(config.statusId, `${config.label}en har öppnats i mailappen med hela textfilen bifogad. Rapporten ligger kvar i Stadslass.`);
    } catch (error) { showStatus(config.statusId, error.message || 'Mailutkastet kunde inte öppnas. Rapporten ligger kvar.', true); }
  }

  function clearReportView(type) {
    const config = reportTypeConfig(type);
    try {
      clearStoredReportSnapshot(type);
      renderReportSnapshot(type);
      showStatus(config.statusId, 'Rapportvyn är rensad. Testhändelser och arbetsdata är oförändrade.');
    } catch (error) { showStatus(config.statusId, error.message || 'Rapportvyn kunde inte rensas.', true); }
  }

  function syncReportProfile() {
    return isPlainObject(settingsDocument.syncReportMail) ? settingsDocument.syncReportMail : { name: '', email: '', subjectPrefix: 'Stadslass verifieringsrapport', body: '' };
  }

  function saveSyncV63Configuration(event) {
    event.preventDefault();
    if (!githubSecureBridgeReady) {
      showStatus('sync-v63-status', 'GitHub-inställningarna kan användas först när funktionspaketet är redo.', true);
      return;
    }
    if (!syncV63HostAvailable() || typeof window.StadslassHost.setSyncConfiguration !== 'function') {
      const diagnostic = syncV65Diagnostic({ status: 'host_capability_missing', errorCode: 'sync_credential_api_missing' }, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Säker lagring av GitHub-inställningar stöds inte av den här installationen.', true); renderSyncV63(); return;
    }
    const rawToken = byId('sync-v63-token').value;
    if (syncV65MaskedToken(rawToken)) {
      const diagnostic = syncV65Diagnostic({ status: 'invalid_request', errorCode: 'masked_token' });
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Klistra in den verkliga GitHub-token. Maskerade punkter kan inte användas.', true); renderSyncV63(); return;
    }
    const config = { owner: text(byId('sync-v63-owner').value), repository: text(byId('sync-v63-repository').value), branch: text(byId('sync-v63-branch').value), token: syncV65NormalizeToken(rawToken) };
    if (!config.owner || !config.repository || !config.branch || !config.token) {
      const diagnostic = syncV65Diagnostic({ status: 'invalid_request', errorCode: 'missing_field' });
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Fyll i ägare, repository, gren och GitHub-token.', true); renderSyncV63(); return;
    }
    let result = {};
    try { result = parseObject(window.StadslassHost.setSyncConfiguration(JSON.stringify(config)), {}); }
    catch (_) { result = { ok: false, status: 'host_error', errorCode: 'bridge_exception' }; }
    const hostError = syncV65HostLastError();
    if (result.ok !== true) {
      const diagnostic = syncV65Diagnostic(result, hostError);
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', syncV65ConfigurationErrorMessage(result), true); renderSyncV63(); return;
    }
    const confirmed = syncV65ConfigurationStatus();
    if (confirmed.ok !== true || confirmed.configured !== true) {
      const failed = { ...confirmed, ok: false, status: text(confirmed.status, 'configuration_missing'), errorCode: text(confirmed.errorCode, 'configuration_not_confirmed') };
      const diagnostic = syncV65Diagnostic(failed, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', syncV65ConfigurationErrorMessage(failed), true); renderSyncV63(); return;
    }
    const diagnostic = syncV65Diagnostic({ ...confirmed, status: 'configured', errorCode: '' }, '');
    // Token lämnar endast formuläret till den säkra hostbryggan och sparas aldrig i settings eller syncOutbox.
    byId('sync-v63-token').value = '';
    if (!syncV63UpdateSettings({ enabled: true, owner: config.owner, repository: config.repository, branch: config.branch, syncRoot: text(syncV63Configuration().syncRoot, 'stadslass-3-sync'), lastConfigurationAttempt: diagnostic })) {
      showStatus('sync-v63-status', 'GitHub-inställningarnas metadata kunde inte sparas lokalt.', true); renderSyncV63(); return;
    }
    showStatus('sync-v63-status', 'GitHub-inställningarna är sparade säkert. Kontrollera anslutningen.');
    renderSyncV63();
  }

  function checkSyncV63Connection() {
    if (!githubSecureBridgeReady) {
      showStatus('sync-v63-status', 'GitHub-anslutningen kan kontrolleras först när funktionspaketet är redo.', true);
      return;
    }
    const status = syncV65ConfigurationStatus();
    if (status.ok !== true || status.configured !== true) {
      const label = syncV65ConfigurationLabel(status);
      showStatus('sync-v63-status', label === 'Kunde inte verifieras'
        ? 'Den säkra GitHub-konfigurationen kunde inte verifieras på enheten.'
        : 'Ingen komplett säker GitHub-konfiguration finns på enheten.', true);
      return;
    }
    if (!hostInfo || Number(hostInfo.syncTransportApiVersion) < 1 || typeof window.StadslassHost.enqueueSyncRequest !== 'function') {
      showStatus('sync-v63-status', 'Host21 saknar den read-only transport som krävs för anslutningskontrollen.', true);
      return;
    }
    if (githubConnectionCheckRequestId) {
      showStatus('sync-v63-status', 'En GitHub-anslutningskontroll pågår redan.');
      return;
    }
    const requestId = `github-check-p135-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const request = {
      requestId,
      operation: 'GET',
      path: 'index.html',
      priority: 'on_demand',
      channel: 'p135/github-connection-check',
      createdAt: new Date().toISOString(),
      body: '',
      expectedSha: '',
      coalesceKey: ''
    };
    let accepted = {};
    try { accepted = parseObject(window.StadslassHost.enqueueSyncRequest(JSON.stringify(request)), {}); }
    catch (_) { accepted = { ok: false, status: 'bridge_exception' }; }
    const acceptedOk = accepted.ok === true || ['accepted', 'pending', 'running'].includes(text(accepted.status));
    if (!acceptedOk) {
      syncDiagnosticObserve('github-connection-check-rejected', { requestId, status: text(accepted.status), errorCode: text(accepted.errorCode), automatic: false });
      showStatus('sync-v63-status', 'GitHub-anslutningskontrollen kunde inte startas.', true);
      return;
    }
    githubConnectionCheckRequestId = requestId;
    syncDiagnosticObserve('github-connection-check-started', { requestId, operation: 'GET', path: 'index.html', automatic: false });
    showStatus('sync-v63-status', 'Kontrollerar GitHub-anslutningen med en enda läsande begäran. Ingen arbets- eller synkdata skickas.');
  }

  function handleGithubConnectionCheckResult(event) {
    const detail = event && event.detail ? event.detail : {};
    const requestId = text(detail.requestId);
    if (!githubConnectionCheckRequestId || requestId !== githubConnectionCheckRequestId) return;
    githubConnectionCheckRequestId = '';
    const status = text(detail.status);
    const httpStatus = Number(detail.httpStatus || detail.http || 0) || 0;
    const errorCode = text(detail.errorCode);
    syncDiagnosticObserve('github-connection-check-result', { requestId, status, httpStatus, errorCode, automatic: false });
    if (status === 'succeeded' || (httpStatus >= 200 && httpStatus < 300)) {
      showStatus('sync-v63-status', 'GitHub-anslutningen fungerar. Kontrollen var endast läsande och ändrade ingen arbets- eller synkdata.');
      return;
    }
    if (httpStatus === 401 || httpStatus === 403) {
      showStatus('sync-v63-status', `GitHub svarade med HTTP ${httpStatus}. Autentisering eller behörighet kunde inte verifieras. Ingen arbets- eller synkdata ändrades.`, true);
      return;
    }
    if (httpStatus === 404) {
      showStatus('sync-v63-status', 'GitHub svarade med HTTP 404. Kontrollera ägare, repository och gren. Ingen arbets- eller synkdata ändrades.', true);
      return;
    }
    showStatus('sync-v63-status', `GitHub-anslutningen kunde inte verifieras${httpStatus ? ` (HTTP ${httpStatus})` : ''}${errorCode ? ` · ${errorCode}` : ''}.`, true);
  }

  function clearSyncV63Configuration() {
    if (!githubSecureBridgeReady) {
      showStatus('sync-v63-status', 'GitHub-inställningarna kan användas först när funktionspaketet är redo.', true);
      return;
    }
    if (!syncV63HostAvailable() || typeof window.StadslassHost.clearSyncConfiguration !== 'function') {
      showStatus('sync-v63-status', 'Säker radering av GitHub-inställningar stöds inte av den här installationen.', true); return;
    }
    if (!window.confirm('Radera de säkra GitHub-inställningarna från denna enhet? Lokala uppdrag påverkas inte.')) return;
    const result = parseObject(window.StadslassHost.clearSyncConfiguration(), {});
    if (result.ok !== true) {
      const diagnostic = syncV65Diagnostic(result, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'GitHub-inställningarna kunde inte raderas. Teknisk information visar felorsaken.', true); renderSyncV63(); return;
    }
    const diagnostic = syncV65Diagnostic({ status: 'cleared', errorCode: '', configured: false }, '');
    syncV63UpdateSettings({ enabled: false, owner: '', repository: '', branch: '', lastSyncStatus: 'configuration_cleared', lastConfigurationAttempt: diagnostic });
    showStatus('sync-v63-status', 'GitHub-inställningarna är raderade. Lokala uppdrag är oförändrade.');
    renderSyncV63();
  }

  function p142NotificationSettings(documentValue = settingsDocument) {
    const raw = isPlainObject(documentValue) ? parseObject(JSON.stringify(documentValue[NOTIFICATION_SOUND_SETTINGS_KEY] || {}), {}) : {};
    const selectedSound = ['none','single-chime','double-chime','soft-bell','rising-chime','warning-beep','custom-notis'].includes(text(raw.selectedSound)) ? text(raw.selectedSound) : (raw.enabled === false ? 'none' : 'custom-notis');
    return { selectedSound, enabled: selectedSound !== 'none' };
  }

  function p142NotificationEnabled() {
    return p142NotificationSettings().enabled === true;
  }

  function p142RenderNotificationSettings() {
    const input = byId('notification-sound-select');
    if (input) input.value = p142NotificationSettings().selectedSound;
  }

  function normalizedUiPreferences(documentValue) {
    const value = parseObject(JSON.stringify(documentValue[UI_SETTINGS_KEY] || {}), {});
    return {
      largeText: value.largeText === true,
      showTechnicalInfo: value.showTechnicalInfo === true
    };
  }

  function updateBottomNavReservedSpace() {
    if (bottomNavLayoutFrame !== null) {
      window.cancelAnimationFrame(bottomNavLayoutFrame);
    }
    bottomNavLayoutFrame = window.requestAnimationFrame(() => {
      bottomNavLayoutFrame = null;
      const nav = document.querySelector('.bottom-nav');
      const renderedHeight = nav ? Math.ceil(nav.getBoundingClientRect().height) : 0;
      const reservedHeight = Math.max(96, renderedHeight + 16);
      document.documentElement.style.setProperty('--bottom-nav-reserved-space', `${reservedHeight}px`);
    });
  }

  function installBottomNavLayoutGuard() {
    const nav = document.querySelector('.bottom-nav');
    updateBottomNavReservedSpace();
    window.addEventListener('resize', updateBottomNavReservedSpace);
    window.addEventListener('orientationchange', updateBottomNavReservedSpace);
    if (nav && typeof window.ResizeObserver === 'function') {
      bottomNavResizeObserver = new window.ResizeObserver(updateBottomNavReservedSpace);
      bottomNavResizeObserver.observe(nav);
    }
  }

  function phaseColorSettings(documentValue = settingsDocument) {
    return phaseVisualService.normalizeColors(isPlainObject(documentValue) ? documentValue[PHASE_COLOR_SETTINGS_KEY] : {});
  }

  function renderPhaseColorSettings() {
    const colors = phaseColorSettings();
    const controls = {
      start_route: 'phase-color-start-route',
      loading: 'phase-color-loading',
      transport: 'phase-color-transport',
      unloading: 'phase-color-unloading',
      load_registered: 'phase-color-load-registered',
      return_unloading: 'phase-color-return-unloading',
      ready_to_complete: 'phase-color-ready'
    };
    Object.entries(controls).forEach(([phase, id]) => {
      const control = byId(id);
      if (control) control.value = colors[phase];
    });
  }

  function readPhaseColorForm() {
    return phaseVisualService.normalizeColors({
      start_route: byId('phase-color-start-route').value,
      loading: byId('phase-color-loading').value,
      transport: byId('phase-color-transport').value,
      unloading: byId('phase-color-unloading').value,
      load_registered: byId('phase-color-load-registered').value,
      return_unloading: byId('phase-color-return-unloading').value,
      ready_to_complete: byId('phase-color-ready').value
    });
  }

  function syncActivePhaseBackdropVisibility() {
    const visible = currentView === 'active'
      && activeJobExists()
      && !isOtherActivity(activeJobDocument);
    document.documentElement.classList.toggle('phase-active-view', visible);
  }

  function clearActivePhaseVisuals() {
    const phaseBottom = byId('active-phase-bottom');
    const phaseAction = byId('active-phase-action');
    const rootStyle = document.documentElement.style;
    document.documentElement.classList.remove('phase-active-view');
    [
      '--active-phase-color',
      '--active-phase-button-color',
      '--active-phase-button-light',
      '--active-phase-text-color',
      '--active-phase-border-color',
      '--active-phase-backdrop-top',
      '--active-phase-backdrop-middle',
      '--active-phase-backdrop-bottom'
    ].forEach((property) => rootStyle.removeProperty(property));
    if (phaseBottom) {
      phaseBottom.classList.remove('has-phase-background');
      phaseBottom.style.removeProperty('--active-phase-color');
      phaseBottom.style.removeProperty('--active-phase-text-color');
    }
    if (phaseAction) {
      phaseAction.style.removeProperty('--active-phase-color');
      phaseAction.style.removeProperty('--active-phase-button-color');
      phaseAction.style.removeProperty('--active-phase-button-light');
      phaseAction.style.removeProperty('--active-phase-text-color');
      phaseAction.style.removeProperty('--active-phase-border-color');
    }
  }

  function applyActivePhaseVisuals(phase, otherActivity) {
    const phaseBottom = byId('active-phase-bottom');
    const phaseAction = byId('active-phase-action');
    if (!phaseBottom || !phaseAction || otherActivity) {
      clearActivePhaseVisuals();
      return;
    }
    const color = phaseVisualService.resolveColor(phase, settingsDocument[PHASE_COLOR_SETTINGS_KEY], phaseService);
    const palette = phaseVisualService.softPalette(color);
    const rootStyle = document.documentElement.style;
    rootStyle.setProperty('--active-phase-color', palette.base);
    rootStyle.setProperty('--active-phase-button-color', palette.button);
    rootStyle.setProperty('--active-phase-button-light', palette.buttonLight);
    rootStyle.setProperty('--active-phase-text-color', palette.text);
    rootStyle.setProperty('--active-phase-border-color', palette.border);
    rootStyle.setProperty('--active-phase-backdrop-top', palette.backdropTop);
    rootStyle.setProperty('--active-phase-backdrop-middle', palette.backdropMiddle);
    rootStyle.setProperty('--active-phase-backdrop-bottom', palette.backdropBottom);
    phaseBottom.classList.add('has-phase-background');
    phaseBottom.style.setProperty('--active-phase-color', palette.base);
    phaseBottom.style.setProperty('--active-phase-text-color', palette.text);
    phaseAction.style.setProperty('--active-phase-color', palette.base);
    phaseAction.style.setProperty('--active-phase-button-color', palette.button);
    phaseAction.style.setProperty('--active-phase-button-light', palette.buttonLight);
    phaseAction.style.setProperty('--active-phase-text-color', palette.text);
    phaseAction.style.setProperty('--active-phase-border-color', palette.border);
    syncActivePhaseBackdropVisibility();
  }

  function applyUiPreferences(preferences) {
    document.documentElement.classList.toggle('large-text', preferences.largeText);
    byId('large-text').checked = preferences.largeText;
    byId('show-technical').checked = preferences.showTechnicalInfo;
    p142RenderNotificationSettings();
    renderPhaseColorSettings();
    renderSettingsWorkspace(false);
    if (activeJobLoaded && activeJobExists()) renderActiveJob();
    updateBottomNavReservedSpace();
  }

  function settingsTechnicalInfoEnabled() {
    return normalizedUiPreferences(settingsDocument).showTechnicalInfo;
  }

  function scrollSettingsContentIntoView(element) {
    if (!element || element.hidden) return;
    window.requestAnimationFrame(() => {
      const topbar = document.querySelector('.topbar');
      const topbarHeight = topbar ? Math.ceil(topbar.getBoundingClientRect().height) : 0;
      const targetTop = currentScrollY() + element.getBoundingClientRect().top - topbarHeight - 12;
      window.scrollTo({ top: Math.max(0, targetTop), behavior: 'auto' });
    });
  }

  function ataNotificationSettings() {
    return ataNotificationApi.settingsFromDocument(settingsDocument);
  }

  function persistAtaNotificationSettings(nextSettings, statusId, successMessage) {
    const nextDocument = ataNotificationApi.documentWithSettings(settingsDocument, nextSettings);
    nextDocument.settingsSchemaVersion = 1;
    nextDocument.settingsUpdatedByPackageVersion = PACKAGE_VERSION;
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus(statusId, window.StadslassHost.getLastError() || 'Uppgifterna kunde inte sparas lokalt.', true);
      return false;
    }
    settingsDocument = nextDocument;
    if (successMessage) showStatus(statusId, successMessage);
    return true;
  }

  async function receiveContactPackage(pkg) {
    if (!ataNotificationApi || !pkg || !pkg.payload || !Array.isArray(pkg.payload.contacts)) return { ok: false, message: 'Kontaktpaketet saknar kontaktlista.' };
    try {
      let next = ataNotificationSettings(); let created = 0;
      pkg.payload.contacts.forEach((contact) => { const result = ataNotificationApi.applyIncoming(next, contact, pkg.createdAt); next = result.settings; if (result.created) created += 1; });
      if (!persistAtaNotificationSettings(next, 'ata-notification-contact-status', created ? `${created} nya kontakter sparades i Adressbok.` : 'Kontakterna fanns redan i Adressbok.')) return { ok: false, message: 'Kontakterna kunde inte sparas lokalt.' };
      if (created > 0) p182MeaningfulIncomingThisFetch = true;
      renderAtaNotificationSettings();
      return { ok: true, created };
    } catch (error) { return { ok: false, message: error.message || 'Kontaktpaketet kunde inte tas emot.' }; }
  }

  async function syncAddressBookContacts() {
    const service = mailboxSyncEnsure(); const from = mailboxUnitFromRole(); const to = from === '189' ? 'mobile' : from === 'mobile' ? '189' : '';
    const contacts = (ataNotificationSettings().contacts || []).map((contact) => ({ name: text(contact.name), email: text(contact.email).toLowerCase() })).filter((contact) => contact.name && ataNotificationApi.validEmail(contact.email));
    if (!to) return showStatus('ata-notification-contact-status', 'Adressbok kan endast synkas mellan 189 och Mobil.', true);
    if (!contacts.length) return showStatus('ata-notification-contact-status', 'Det finns inga giltiga kontakter att skicka.');
    try { await service.sendContactPackage(contacts, to); showStatus('ata-notification-contact-status', `Adressbok skickad till ${to === '189' ? '189' : 'Mobil'}.`); }
    catch (error) { showStatus('ata-notification-contact-status', error.message || 'Adressboken kunde inte synkas.', true); }
  }

  function ataRecipientIds(scope) {
    const prefix = scope === 'quick' ? 'quick-choice-registry' : (scope === 'jobtype' ? 'job-type-registry' : (scope === 'active' ? 'active-job' : 'job'));
    return { prefix, panel: `${prefix}-ata-recipient-panel`, contact: `${prefix}-ata-contact`, name: `${prefix}-ata-recipient-name`, email: `${prefix}-ata-recipient-email`, clear: `${prefix}-ata-recipient-clear`, toggle: scope === 'quick' ? 'quick-choice-registry-ata-default' : (scope === 'jobtype' ? 'job-type-registry-ata-enabled' : `${prefix}-ata`) };
  }

  function ataRecipientInput(scope) {
    const ids = ataRecipientIds(scope);
    return { name: text(byId(ids.name) && byId(ids.name).value), email: text(byId(ids.email) && byId(ids.email).value), contactId: text(byId(ids.contact) && byId(ids.contact).value) || null };
  }

  function writeAtaRecipientInput(scope, recipient) {
    const ids = ataRecipientIds(scope);
    const value = recipient || {};
    if (byId(ids.name)) byId(ids.name).value = text(value.name);
    if (byId(ids.email)) byId(ids.email).value = text(value.email);
    if (byId(ids.contact)) byId(ids.contact).value = text(value.contactId);
  }

  function renderAtaRecipientContacts(scope, selected = null) {
    const ids = ataRecipientIds(scope);
    const select = byId(ids.contact);
    if (!select || !ataNotificationApi) return;
    const previous = text(selected && selected.contactId, select.value);
    select.replaceChildren();
    const empty = document.createElement('option'); empty.value = ''; empty.textContent = 'Ingen sparad mottagare'; select.appendChild(empty);
    ataNotificationApi.contactsForDisplay(ataNotificationSettings()).forEach((contact) => {
      const option = document.createElement('option'); option.value = contact.id; option.textContent = ataNotificationApi.recipientListLabel(contact); select.appendChild(option);
    });
    if (selectContainsValue(select, previous)) select.value = previous;
  }

  function selectAtaRecipientContact(scope) {
    const ids = ataRecipientIds(scope);
    const contact = ataNotificationApi && ataNotificationApi.contactsForDisplay(ataNotificationSettings()).find((item) => item.id === text(byId(ids.contact).value));
    if (contact) writeAtaRecipientInput(scope, { contactId: contact.id, name: contact.name, email: contact.email });
  }

  function clearAtaRecipient(scope) {
    writeAtaRecipientInput(scope, null);
    renderAtaRecipientContacts(scope, null);
  }

  function ensureAtaRecipientContact(rawRecipient, source, statusId) {
    const result = ataRouting.recipientForSave(rawRecipient, ataNotificationSettings().contacts, source, new Date().toISOString());
    if (!result.recipient) return null;
    if (result.contact) {
      const proposal = ataNotificationApi.saveContact(ataNotificationSettings(), result.contact);
      const next = ataNotificationApi.commitContact(proposal.settings, proposal.contact);
      if (!persistAtaNotificationSettings(next, statusId, 'Mottagaren är sparad i Adressbok.')) throw new Error('Mottagaren kunde inte sparas i Adressbok.');
      return { ...result.recipient, contactId: proposal.contact.id };
    }
    return result.recipient;
  }

  function syncAtaForm(scope, resetForJobType = false) {
    const ids = ataRecipientIds(scope);
    const typeId = scope === 'quick' ? byId('quick-choice-registry-job-type').value : (scope === 'jobtype' ? editingEditableJobTypeId : byId(scope === 'active' ? 'active-job-type' : 'job-type').value);
    const jobType = findJobTypeById(typeId);
    const toggle = byId(ids.toggle);
    const choice = toggle && toggle.closest('.choice-row');
    if (!toggle || !ataRouting) return;
    const isManual = ataRouting.isManualJobType(jobType);
    const isFixedAta = ataRouting.jobTypeEnabled(jobType);
    if (scope === 'jobtype') {
      const manualNote = byId('job-type-registry-ata-manual-note');
      if (choice) choice.hidden = isManual;
      if (manualNote) manualNote.hidden = !isManual;
      toggle.disabled = isManual;
      if (resetForJobType) toggle.checked = isManual ? false : isFixedAta;
      byId(ids.panel).hidden = !(isManual || toggle.checked);
      renderAtaRecipientContacts(scope, ataRecipientInput(scope));
      return;
    }
    const showToggle = isManual || isFixedAta;
    if (choice) choice.hidden = !showToggle;
    toggle.disabled = false;
    if (resetForJobType) toggle.checked = isFixedAta;
    // A historic queue job keeps its own saved ÄTA truth even if its current
    // Jobbtyp would not expose a manual checkbox in package 59.
    const enabled = toggle.checked === true;
    byId(ids.panel).hidden = !enabled;
    if (enabled && resetForJobType && !ataRecipientInput(scope).email) writeAtaRecipientInput(scope, ataRouting.defaultRecipient(jobType));
    renderAtaRecipientContacts(scope, ataRecipientInput(scope));
  }

  function ataNotificationTemplateInput() {
    const fields = {};
    ataNotificationApi.TEMPLATE_FIELDS.forEach((field) => {
      const input = byId(`ata-notification-template-${field}`);
      fields[field] = !input || input.checked;
    });
    return { fields, closingText: byId('ata-notification-template-closing').value };
  }

  function flushAtaNotificationTemplate() {
    if (ataNotificationTemplateTimer !== null) {
      window.clearTimeout(ataNotificationTemplateTimer);
      ataNotificationTemplateTimer = null;
    }
    const panel = byId('ata-notification-settings-card');
    if (!panel || panel.hidden || !ataNotificationApi) return;
    const next = ataNotificationApi.updateTemplate(ataNotificationSettings(), ataNotificationTemplateInput());
    const active = Object.values(next.template.fields).filter(Boolean).length;
    persistAtaNotificationSettings(next, 'ata-notification-template-status', `Mailmall sparad lokalt. ${active} av 12 standardfält är aktiva.`);
  }

  function scheduleAtaNotificationTemplateSave() {
    if (ataNotificationTemplateTimer !== null) window.clearTimeout(ataNotificationTemplateTimer);
    ataNotificationTemplateTimer = window.setTimeout(flushAtaNotificationTemplate, 350);
  }

  function renderAtaNotificationSettings() {
    if (!ataNotificationApi) return;
    const settings = ataNotificationSettings();
    const supervisor = settings.supervisor || {};
    const supervisorName = byId('ata-notification-supervisor-name');
    const supervisorEmail = byId('ata-notification-supervisor-email');
    if (supervisorName && document.activeElement !== supervisorName) supervisorName.value = supervisor.name || '';
    if (supervisorEmail && document.activeElement !== supervisorEmail) supervisorEmail.value = supervisor.email || '';
    const templateLabels = { jobType: 'Jobbtyp', fromPlace: 'Från-plats', toPlace: 'Till-plats', returnPlace: 'Returplats', date: 'Datum', startedAt: 'Starttid', completedAt: 'Sluttid', billableTime: 'Debiterbar tid', loadCount: 'Antal lass', totalWeight: 'Total vikt', note: 'Kommentar', truck189: 'Lastbil 189' };
    const fields = byId('ata-notification-template-fields');
    if (fields && !fields.childElementCount) {
      ataNotificationApi.TEMPLATE_FIELDS.forEach((field) => {
        const label = document.createElement('label'); label.className = 'choice-row compact-choice-row'; label.htmlFor = `ata-notification-template-${field}`;
        const input = document.createElement('input'); input.id = `ata-notification-template-${field}`; input.type = 'checkbox';
        const span = document.createElement('span'); const strong = document.createElement('strong'); strong.textContent = templateLabels[field]; span.append(strong);
        label.append(input, span); fields.append(label);
      });
    }
    ataNotificationApi.TEMPLATE_FIELDS.forEach((field) => { const input = byId(`ata-notification-template-${field}`); if (input && document.activeElement !== input) input.checked = settings.template.fields[field] !== false; });
    const closing = byId('ata-notification-template-closing');
    if (closing && document.activeElement !== closing) closing.value = settings.template.closingText || '';
    const list = byId('ata-notification-contact-list');
    if (!list) return;
    list.replaceChildren();
    const contacts = ataNotificationApi.contactsForDisplay(settings);
    if (!contacts.length) { const empty = document.createElement('p'); empty.className = 'empty-state'; empty.textContent = 'Inga mottagare är sparade.'; list.append(empty); return; }
    contacts.forEach((contact) => {
      const card = document.createElement('article'); card.className = 'registry-card';
      const header = document.createElement('div'); header.className = 'registry-card-header';
      const title = document.createElement('h4'); title.textContent = ataNotificationApi.recipientListLabel(contact);
      header.append(title);
      const email = document.createElement('p'); email.className = 'queue-meta'; email.textContent = contact.email;
      const actions = document.createElement('div'); actions.className = 'registry-actions';
      const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'secondary-button'; edit.dataset.ataNotificationEdit = contact.id; edit.textContent = 'Redigera';
      const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger-button'; remove.dataset.ataNotificationRemove = contact.id; remove.textContent = 'Ta bort';
      actions.append(edit, remove); card.append(header, email, actions); list.append(card);
    });
  }

  function resetAtaNotificationContactForm(message = '') {
    byId('ata-notification-contact-id').value = '';
    byId('ata-notification-contact-name').value = '';
    byId('ata-notification-contact-email').value = '';
    byId('ata-notification-contact-submit').textContent = 'Spara mottagare';
    if (message) showStatus('ata-notification-contact-status', message);
  }

  function setAtaNotificationConfirmation(message, acceptLabel, action, anchorId = '') {
    ataNotificationPendingAction = action;
    const confirmation = byId('ata-notification-confirm');
    const anchor = anchorId ? byId(anchorId) : null;
    if (!confirmation) return;
    if (anchor && anchor.parentNode) anchor.insertAdjacentElement('afterend', confirmation);
    byId('ata-notification-confirm-text').textContent = message;
    byId('ata-notification-confirm-accept').textContent = acceptLabel;
    confirmation.hidden = false;
    scrollSettingsContentIntoView(confirmation);
  }

  function clearAtaNotificationConfirmation() {
    ataNotificationPendingAction = null;
    byId('ata-notification-confirm').hidden = true;
  }

  function editAtaNotificationContact(id) {
    const contact = ataNotificationSettings().contacts.find((item) => item.id === id);
    if (!contact) return showStatus('ata-notification-contact-status', 'Mottagaren saknas.', true);
    byId('ata-notification-contact-id').value = contact.id;
    byId('ata-notification-contact-name').value = contact.name;
    byId('ata-notification-contact-email').value = contact.email;
    byId('ata-notification-contact-submit').textContent = 'Spara ändringar';
    showStatus('ata-notification-contact-status', `Redigerar ${contact.name}.`);
    scrollSettingsContentIntoView(byId('ata-notification-contact-form'));
    window.setTimeout(() => { const input = byId('ata-notification-contact-name'); if (input) input.focus({ preventScroll: true }); }, 0);
  }

  function saveAtaNotificationContact(event) {
    event.preventDefault();
    try {
      const input = { id: byId('ata-notification-contact-id').value, name: byId('ata-notification-contact-name').value, email: byId('ata-notification-contact-email').value };
      const result = ataNotificationApi.saveContact(ataNotificationSettings(), input);
      const previous = result.isEdit ? ataNotificationSettings().contacts.find((contact) => contact.id === result.contact.id) : null;
      const commit = () => {
        if (!persistAtaNotificationSettings(ataNotificationApi.commitContact(result.settings, result.contact), 'ata-notification-contact-status', 'Mottagare sparad lokalt.')) return;
        if (previous) propagateAtaContactToPlanningData(previous, result.contact);
        resetAtaNotificationContactForm(); renderAtaNotificationSettings(); clearAtaNotificationConfirmation();
      };
      if (result.requiresConfirmation) {
        const existing = result.duplicates[0];
        setAtaNotificationConfirmation(`${existing.name} använder redan ${existing.email}. Spara ändå?`, 'Spara ändå', commit, 'ata-notification-contact-status');
        return;
      }
      commit();
    } catch (error) { showStatus('ata-notification-contact-status', error.message || 'Mottagaren kunde inte sparas.', true); }
  }

  function propagateAtaContactToPlanningData(previous, contact) {
    const updatedContact = { ...contact, previousEmail: previous.email };
    let changedSettings = false;
    let nextJobTypes = editableJobTypeRegistry;
    let nextQuickChoices = quickChoiceRegistry;
    if (editableJobTypeRegistry) {
      const items = editableJobTypeRegistry.items.map((item) => {
        const recipient = item.ataRecipient;
        const matches = recipient && (recipient.contactId === contact.id || ataRouting.emailKey(recipient.email) === ataRouting.emailKey(previous.email));
        if (!matches) return item;
        changedSettings = true;
        return { ...item, ataRecipient: { ...recipient, contactId: contact.id, name: contact.name, email: contact.email, emailKey: ataRouting.emailKey(contact.email) } };
      });
      if (changedSettings) nextJobTypes = editableJobTypeApi.withItems(editableJobTypeRegistry, items, new Date().toISOString());
    }
    if (quickChoiceRegistry) {
      const items = ataRouting.propagateRecipient(quickChoiceRegistry.items.map((item) => item.ataRecipient ? { ...item, ata: { recipient: item.ataRecipient } } : item), updatedContact)
        .map((item) => item.ata ? { ...item, ataRecipient: item.ata.recipient, ata: undefined } : item);
      if (JSON.stringify(items) !== JSON.stringify(quickChoiceRegistry.items)) { nextQuickChoices = quickChoiceApi.withItems(quickChoiceRegistry, items, new Date().toISOString()); changedSettings = true; }
    }
    if (changedSettings) {
      const nextDocument = { ...settingsDocument, [editableJobTypeApi.SETTINGS_KEY]: nextJobTypes, [quickChoiceApi.SETTINGS_KEY]: nextQuickChoices, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
      if (writeSettingsDocument(nextDocument)) { settingsDocument = nextDocument; editableJobTypeRegistry = nextJobTypes; quickChoiceRegistry = nextQuickChoices; applyEffectiveJobTypeRegistry(nextJobTypes.items); }
    }
    if (queueLoaded) {
      const nextQueue = ataRouting.propagateRecipient(queueDocument, updatedContact, (job) => text(job.status) === 'queued' && job.pausedFromActive !== true);
      if (JSON.stringify(nextQueue) !== JSON.stringify(queueDocument) && window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextQueue))) { queueDocument = nextQueue; renderQueue(); }
    }
  }

  function handleAtaNotificationContactList(event) {
    const edit = event.target.closest('button[data-ata-notification-edit]');
    const remove = event.target.closest('button[data-ata-notification-remove]');
    if (edit) return editAtaNotificationContact(edit.dataset.ataNotificationEdit || '');
    if (remove) {
      const contact = ataNotificationSettings().contacts.find((item) => item.id === remove.dataset.ataNotificationRemove);
      if (!contact) return;
      setAtaNotificationConfirmation(`Ta bort ${contact.name}, ${contact.email} från Adressbok?`, 'Bekräfta borttagning', () => { try { const result = ataNotificationApi.removeContact(ataNotificationSettings(), contact.id); if (persistAtaNotificationSettings(result.settings, 'ata-notification-contact-status', 'Mottagaren har tagits bort.')) { if (byId('ata-notification-contact-id').value === contact.id) resetAtaNotificationContactForm(); renderAtaNotificationSettings(); clearAtaNotificationConfirmation(); } } catch (error) { showStatus('ata-notification-contact-status', error.message, true); clearAtaNotificationConfirmation(); } }, 'ata-notification-contact-status');
    }
  }

  function renderSettingsWorkspace(shouldScroll = false) {
    if (activeSettingsFunction !== 'ata-notification') flushAtaNotificationTemplate();
    const workspace = byId('settings-workspace');
    if (!workspace) return;

    document.querySelectorAll('.settings-group-button[data-settings-group]').forEach((button) => {
      const active = button.dataset.settingsGroup === activeSettingsGroup;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-expanded', active ? 'true' : 'false');
    });

    document.querySelectorAll('[data-settings-group-view]').forEach((view) => {
      view.hidden = view.dataset.settingsGroupView !== activeSettingsGroup;
    });

    const hasOpenGroup = Boolean(activeSettingsGroup);
    workspace.hidden = !hasOpenGroup;

    let activePanel = null;
    document.querySelectorAll('.settings-function-button[data-settings-function]').forEach((button) => {
      const active = button.dataset.settingsGroupOwner === activeSettingsGroup
        && button.dataset.settingsFunction === activeSettingsFunction;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-expanded', active ? 'true' : 'false');
    });

    document.querySelectorAll('[data-settings-function-panel]').forEach((panel) => {
      const active = panel.dataset.settingsGroupOwner === activeSettingsGroup
        && panel.dataset.settingsFunctionPanel === activeSettingsFunction;
      panel.hidden = !active;
      if (active) activePanel = panel;
    });

    document.querySelectorAll('[data-settings-function-workspace]').forEach((functionWorkspace) => {
      functionWorkspace.hidden = functionWorkspace.dataset.settingsFunctionWorkspace !== activeSettingsGroup
        || !activeSettingsFunction;
    });

    const technicalPanel = byId('technical-panel');
    const technicalDisabledNote = byId('technical-disabled-note');
    const technicalGroupOpen = activeSettingsGroup === 'control-troubleshooting';
    const technicalEnabled = settingsTechnicalInfoEnabled();
    if (technicalPanel) technicalPanel.hidden = !(technicalGroupOpen && technicalEnabled);
    if (technicalDisabledNote) technicalDisabledNote.hidden = !(technicalGroupOpen && !technicalEnabled);

    if (!shouldScroll || !hasOpenGroup) return;
    const groupView = Array.from(document.querySelectorAll('[data-settings-group-view]'))
      .find((view) => view.dataset.settingsGroupView === activeSettingsGroup) || null;
    scrollSettingsContentIntoView(activePanel || groupView || workspace);
    if (activePanel && activeSettingsFunction === 'ata-notification') renderAtaNotificationSettings();
  }

  function formatGpsCoordinate(value) {
    return Number.isFinite(value) ? value.toFixed(6) : '–';
  }

  function formatGpsAge(age) {
    if (!Number.isFinite(age)) return '–';
    const seconds = Math.max(0, Math.floor(age / 1000));
    if (seconds < 60) return `${seconds} s`;
    const minutes = Math.floor(seconds / 60);
    const remainder = seconds % 60;
    return `${minutes} min ${remainder} s`;
  }

  function formatGpsTimestamp(value) {
    if (!Number.isFinite(value)) return '–';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '–' : date.toLocaleString('sv-SE');
  }

  function renderGpsSnapshot(snapshot) {
    if (runtimeDisposed || runtimeFailed || !snapshot || !byId('gps-current-status')) return;
    p116PreviousGpsSnapshot = p116LastGpsSnapshot;
    p116LastGpsSnapshot = snapshot;
    byId('gps-current-status').textContent = snapshot.status;
    byId('gps-latitude').textContent = formatGpsCoordinate(snapshot.latitude);
    byId('gps-longitude').textContent = formatGpsCoordinate(snapshot.longitude);
    byId('gps-accuracy').textContent = Number.isFinite(snapshot.accuracy)
      ? `${Math.round(snapshot.accuracy)} m`
      : '–';
    byId('gps-timestamp').textContent = formatGpsTimestamp(snapshot.timestamp);
    byId('gps-age').textContent = formatGpsAge(snapshot.age);
    byId('gps-fresh').textContent = snapshot.isFresh ? 'Ja' : 'Nej';
    byId('gps-low-accuracy').textContent = snapshot.hasLowAccuracy ? 'Ja' : 'Nej';
    byId('gps-usable').textContent = snapshot.isUsable ? 'Ja' : 'Nej';
    byId('gps-watching').textContent = snapshot.isWatching ? 'Körs' : 'Stoppad';
    byId('gps-reasons').textContent = snapshot.activeReasons.length > 0
      ? snapshot.activeReasons.join(', ')
      : 'Ingen behovskälla';
    byId('gps-app-state').textContent = snapshot.appState === 'bakgrund' ? 'Bakgrund' : 'Förgrund';
    byId('gps-error-code').textContent = snapshot.errorCode === null ? '–' : String(snapshot.errorCode);
    byId('gps-latest-error').textContent = snapshot.latestError || '–';
    byId('gps-consumer-count').textContent = String(snapshot.activeConsumers.length);

    const permanentDenied = snapshot.status === 'Behörighet permanent nekad';
    byId('gps-permission-guidance').hidden = !permanentDenied;
    const retryStatuses = new Set([
      'Behörighet nekad',
      'Behörighet permanent nekad',
      'Behörighet återkallad',
      'Positionstjänst avstängd eller otillgänglig',
      'Position kunde inte hämtas',
      'GPS-fel'
    ]);
    byId('gps-retry').hidden = !(snapshot.activeConsumers.length > 0 && retryStatuses.has(snapshot.status));
    // All Routes work must pass the P124 phase-transition gate.  Calling the
    // lower-level scheduler here previously bypassed the safety checks when a
    // GPS snapshot arrived immediately after Lass registrerat.
    p122ScheduleDrivingRoutes('periodic');
  }

  function gpsDiagnosticsIsOpen() {
    return currentView === 'settings'
      && activeSettingsGroup === 'control-troubleshooting'
      && activeSettingsFunction === 'gps-status';
  }

  function syncGpsDiagnosticsConsumer() {
    if (!gpsService || !gpsRuntimeReady) return;
    gpsService.setConsumer('gpsDiagnostics', gpsDiagnosticsIsOpen(), 'GPS-status');
  }

  function activeJobNeedsGps(documentValue = activeJobDocument) {
    return activeJobLoaded
      && activeJobExists()
      && !isOtherActivity(documentValue)
      && ['active', 'completing'].includes(text(documentValue.status));
  }

  function syncActiveJobGpsConsumer() {
    if (!gpsService || !gpsRuntimeReady) return;
    gpsService.setConsumer('activeJob', activeJobNeedsGps(), 'Aktivt jobb');
  }

  function activeGeofenceContext(documentValue = activeJobDocument) {
    if (!activeJobLoaded || !activeJobExists() || isOtherActivity(documentValue) || text(documentValue.status) !== 'active') return null;
    const phase = phaseService.normalizePhase(text(documentValue.phase));
    let placeRole = '';
    let placeId = '';
    if (machineTransportApi && machineTransportApi.preStageActive(documentValue)) {
      const target=machineTransportApi.routeTarget(documentValue), pickup=target&&findPlaceById(target.id);
      if (!pickup || !pickup.geofence || pickup.geofence.enabled !== true) return null;
      return { active:true, jobId:stableJobId(documentValue,'active'), placeId:pickup.id, placeRole:'from', geofence:pickup.geofence, dynamicCurrentLocation:false };
    }
    if (phase === phaseService.PHASES.START_ROUTE || phase === phaseService.PHASES.LOADING) {
      placeRole = 'from';
      placeId = text(documentValue.fromPlaceId);
    } else if (phase === phaseService.PHASES.TRANSPORT || phase === phaseService.PHASES.UNLOADING) {
      placeRole = 'destination';
      placeId = text(documentValue.destinationPlaceId);
    } else if (phase === phaseService.PHASES.RETURN_TRANSPORT || phase === phaseService.PHASES.RETURN_UNLOADING) {
      placeRole = 'return';
      placeId = text(documentValue.returnPlaceId, text(documentValue.fromPlaceId));
    }
    if (!placeId) return null;
    const place = resolveJobPlace(documentValue, placeRole);
    if (!place || text(place.id) !== placeId || !place.geofence || place.geofence.enabled !== true) return null;
    return { active: true, jobId: stableJobId(documentValue, 'active'), placeId, placeRole, geofence: place.geofence, dynamicCurrentLocation: false };
  }

  function syncActiveGeofenceContext() {
    if (!geofenceService || !geofenceRuntimeReady) return;
    geofenceService.setActiveContext(activeGeofenceContext());
  }

  function currentGpsSnapshot() {
    return gpsService && typeof gpsService.getSnapshot === 'function' ? gpsService.getSnapshot() : null;
  }

  function p116RouteDestination(documentValue) {
    const phase = phaseService.normalizePhase(text(documentValue && documentValue.phase));
    const preStageTarget = machineTransportApi && machineTransportApi.routeTarget(documentValue);
    if (preStageTarget) {
      const pickup=findPlaceById(preStageTarget.id), geocoding=pickup&&isPlainObject(pickup.geocoding)?pickup.geocoding:{};
      return { id:text(pickup&&pickup.id), latitude:Number(pickup&&(pickup.latitude!==undefined?pickup.latitude:geocoding.latitude)), longitude:Number(pickup&&(pickup.longitude!==undefined?pickup.longitude:geocoding.longitude)), address:text(pickup&&(pickup.addressOrPlusCode||pickup.address||geocoding.formattedAddress)) };
    }
    const role = phase === 'start_route' ? 'from' : (phase === 'transport' ? 'destination' : 'return');
    const place = resolveJobPlace(documentValue, role);
    const geocoding = place && isPlainObject(place.geocoding) ? place.geocoding : {};
    const latitude = Number(place && (place.latitude !== undefined ? place.latitude : geocoding.latitude));
    const longitude = Number(place && (place.longitude !== undefined ? place.longitude : geocoding.longitude));
    return { id: text(place && place.id), latitude, longitude, address: text(place && (place.addressOrPlusCode || place.address || geocoding.formattedAddress)) };
  }

  function p116RouteState(documentValue) {
    return isPlainObject(documentValue && documentValue.routeDistance) ? documentValue.routeDistance : {};
  }

  function p118IsDrivingPhase(phase) {
    return Boolean(routesService && Array.isArray(routesService.DRIVE_PHASES) && routesService.DRIVE_PHASES.includes(phaseService.normalizePhase(phase)));
  }

  // P122: A manual work phase must never wait for, start, or reuse a Routes call.
  // The UI and the saved phase are therefore always completed before driving-only
  // route work is allowed to be scheduled on a later event-loop turn.
  function p122RoutesAllowedForActiveJob(documentValue = activeJobDocument) {
    if (!(activeJobLoaded
      && activeJobExists()
      && text(documentValue && documentValue.status) === 'active'
      && p118IsDrivingPhase(phaseService.normalizePhase(text(documentValue && documentValue.phase))))) return false;
    const transitionGate = isPlainObject(documentValue && documentValue.p124RoutesAwaitingMotion)
      ? documentValue.p124RoutesAwaitingMotion
      : null;
    if (!transitionGate) return true;
    const phase = phaseService.normalizePhase(text(documentValue && documentValue.phase));
    if (text(transitionGate.phase) !== phase) return true;
    const baseline = {
      latitude: Number(transitionGate.latitude),
      longitude: Number(transitionGate.longitude),
      timestamp: Number(transitionGate.timestamp),
      accuracy: Number(transitionGate.accuracy)
    };
    const current = p116LastGpsSnapshot || currentGpsSnapshot();
    return Boolean(routesService && routesService.motionProven(baseline, current));
  }

  function p122ScheduleDrivingRoutes(reason = 'render', forceInitial = false) {
    if (!p122RoutesAllowedForActiveJob()) return;
    if (p122RouteScheduleTimer !== null) return;
    p122RouteScheduleTimer = window.setTimeout(() => {
      p122RouteScheduleTimer = null;
      if (!p122RoutesAllowedForActiveJob()) return;
      p119ScheduleRoute(reason, forceInitial);
      p121ScheduleForecasts();
    }, 0);
  }

  function p118RouteTargetKey(destination) {
    if (!destination) return '';
    if (text(destination.id)) return `place:${text(destination.id)}`;
    if (routesService && routesService.valid(destination)) return `coordinates:${Number(destination.latitude).toFixed(6)},${Number(destination.longitude).toFixed(6)}`;
    return text(destination.address) ? `address:${text(destination.address)}` : '';
  }

  function p119RouteDiagnostic(phase, detail, severity = 'info') {
    if (watchdog) watchdog.step(phase, detail, severity);
  }

  function p119RouteContext() {
    const documentValue = activeJobDocument;
    if (!activeJobLoaded || !activeJobExists() || isOtherActivity(documentValue) || text(documentValue.status) !== 'active') return null;
    const phase = phaseService.normalizePhase(text(documentValue.phase));
    const destination = p116RouteDestination(documentValue);
    const targetKey = p118RouteTargetKey(destination);
    const jobId = stableJobId(documentValue, 'active');
    if (!jobId || !phase || !targetKey) return null;
    return Object.freeze({ jobId, phase, destination, targetKey, key: `${jobId}|${phase}|${targetKey}`, generation: p119RouteGeneration, routeState: p116RouteState(documentValue) });
  }

  function p118DisplayedRouteMeters(documentValue) {
    const phase = phaseService.normalizePhase(text(documentValue && documentValue.phase));
    if (!p118IsDrivingPhase(phase)) return 0;
    const state = p116RouteState(documentValue);
    return text(state.phase) === phase && text(state.routeTargetKey) === p118RouteTargetKey(p116RouteDestination(documentValue)) ? state.meters : null;
  }

  function p116RenderLiveTime() {
    const node = byId('active-display-time');
    if (!node || !activeJobLoaded || !activeJobExists() || !historyService) return;
    node.textContent = historyService.formatMinutes(historyService.workMinutes(activeJobDocument));
  }

  function p116StartTimeTicker() {
    if (p116TimeTickTimer !== null) return;
    p116TimeTickTimer = window.setInterval(() => {
      if (activeJobLoaded && activeJobExists()) p116RenderLiveTime();
    }, 1000);
  }

  function p119RouteIsStillCurrent(context) {
    const current = p119RouteContext();
    return Boolean(current && current.key === context.key && current.generation === context.generation);
  }

  function p119RouteBlocked(reason, category) {
    p119RouteDiagnostic('runtime.routes.blocked', `Routes spärrad: kategori=${category}, orsak=${reason}.`);
  }

  function p119RouteFailureCategory(error) {
    if (text(error && error.category)) return text(error.category);
    if (text(error && error.message).startsWith('ROUTES_HTTP_')) return 'http_error';
    if (text(error && error.message).startsWith('GEOCODE_')) return 'geocode_failed';
    return error && error.name === 'TypeError' ? 'fetch_rejected' : 'fetch_rejected';
  }

  function p121AuthorizeRoute(reason) {
    if (!etaService) return false;
    const decision = etaService.authorizeBudget(settingsDocument.googleRoutesBudgetV1, text(hostInfo && hostInfo.role), Date.now());
    if (!decision.allowed) { p119RouteDiagnostic('runtime.routes.budget.blocked', `Routes blockerades före host-fetch: ${decision.reason}, orsak=${reason}.`, 'warning'); return false; }
    const nextSettings = { ...settingsDocument, googleRoutesBudgetV1: decision.state, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!writeSettingsDocument(nextSettings)) { p119RouteDiagnostic('runtime.routes.budget.write-failed', 'Routes blockerades eftersom budgeträknaren inte kunde sparas.', 'warning'); return false; }
    settingsDocument = nextSettings;
    return true;
  }

  function renderP121Budget() {
    const node = byId('p121-routes-budget-status'); const button = byId('p121-routes-budget-correct');
    if (!node || !etaService || !hostInfo) return;
    const state = etaService.normalizeBudget(settingsDocument.googleRoutesBudgetV1, text(hostInfo.role));
    node.textContent = state.monthlyLimit ? `${hostInfo.roleLabel || hostInfo.role}: ${state.attempts.length}/${state.monthlyLimit} månad · ${state.dailyAttempts}/${state.dailyLimit} idag · ${state.minuteAttempts}/10 minut` : `${hostInfo.roleLabel || hostInfo.role}: Google Routes är avstängt på denna roll.`;
    if (button) button.hidden = !state.monthlyLimit;
  }

  function correctP121Budget() {
    if (!etaService || !hostInfo) return;
    const state = etaService.normalizeBudget(settingsDocument.googleRoutesBudgetV1, text(hostInfo.role));
    const reason = window.prompt('Ange orsak till budgetkorrigeringen.'); if (!text(reason)) return;
    const value = Number(window.prompt(`Ange faktiskt antal Routes-anrop denna månad (0–${state.monthlyLimit}).`, String(state.attempts.length)));
    if (!Number.isInteger(value) || value < 0 || value > state.monthlyLimit || !window.confirm(`Spara korrigeringen till ${value} anrop?`)) return;
    const now = Date.now(), nextState = { ...state, attempts: Array.from({ length: value }, () => now), correctedAt: new Date(now).toISOString(), correctedByRole: text(hostInfo.role), correctionReason: text(reason) }, next = { ...settingsDocument, googleRoutesBudgetV1: nextState, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (writeSettingsDocument(next)) { settingsDocument = next; renderP121Budget(); watchdog.step('runtime.routes.budget.corrected', 'Google Routes-budgeten korrigerades med bekräftad orsak.'); }
  }

  function p121PointForRole(documentValue, role) {
    const place = resolveJobPlace(documentValue, role); const geocoding = place && isPlainObject(place.geocoding) ? place.geocoding : {};
    return { id: text(place && place.id), latitude: Number(place && (place.latitude !== undefined ? place.latitude : geocoding.latitude)), longitude: Number(place && (place.longitude !== undefined ? place.longitude : geocoding.longitude)), address: text(place && (place.addressOrPlusCode || place.address || geocoding.formattedAddress)) };
  }

  function p121ForecastKey(phase, origin, destination) { const coordinate = (point) => `${Number(point && point.latitude).toFixed(6)},${Number(point && point.longitude).toFixed(6)}`; return `${phase}|${coordinate(origin)}>${coordinate(destination)}`; }

  function p121ForecastLegs(documentValue) {
    const snapshot = currentGpsSnapshot(); const current = snapshot && { latitude: Number(snapshot.latitude), longitude: Number(snapshot.longitude) };
    const from = p121PointForRole(documentValue, 'from'), destination = p121PointForRole(documentValue, 'destination'), returned = documentValue.returnRequired === true ? p121PointForRole(documentValue, 'return') : null, legs = [];
    const pickupTarget=machineTransportApi&&machineTransportApi.routeTarget(documentValue), pickupPlace=pickupTarget&&findPlaceById(pickupTarget.id), pickupGeocoding=pickupPlace&&isPlainObject(pickupPlace.geocoding)?pickupPlace.geocoding:{}, pickup=pickupPlace?{latitude:Number(pickupPlace.latitude!==undefined?pickupPlace.latitude:pickupGeocoding.latitude),longitude:Number(pickupPlace.longitude!==undefined?pickupPlace.longitude:pickupGeocoding.longitude)}:null;
    if (pickup && routesService && routesService.valid(pickup) && routesService.valid(from)) legs.push({ phase: 'machine_bed_to_from', origin: pickup, destination: from });
    if (!pickup && routesService && routesService.valid(current) && routesService.valid(from)) legs.push({ phase: 'start_route', origin: current, destination: from });
    if (routesService && routesService.valid(from) && routesService.valid(destination)) legs.push({ phase: 'transport', origin: from, destination });
    if (returned && routesService && routesService.valid(destination) && routesService.valid(returned)) legs.push({ phase: 'return_transport', origin: destination, destination: returned });
    return legs;
  }

  async function p121ScheduleForecasts() {
    if (!p119RoutesTrusted || !routesService || !p122RoutesAllowedForActiveJob() || isOtherActivity(activeJobDocument) || activeJobDocument.multiLoad === true) return;
    const currentId = stableJobId(activeJobDocument, 'active'), previous = isPlainObject(activeJobDocument.routeForecasts) ? activeJobDocument.routeForecasts : {};
    const currentPhase = phaseService.normalizePhase(text(activeJobDocument.phase));
    const phaseFlow = phaseService.flow(activeJobDocument.returnRequired === true);
    const currentIndex = phaseFlow.indexOf(currentPhase);
    for (const leg of p121ForecastLegs(activeJobDocument).filter((candidate) => candidate.phase === 'machine_bed_to_from' || phaseFlow.indexOf(candidate.phase) > currentIndex)) {
      const key = p121ForecastKey(leg.phase, leg.origin, leg.destination), cached = previous[key];
      if (cached && etaService && etaService.durationSeconds(cached.duration) !== null) continue;
      if (routesService.distance(leg.origin, leg.destination) < 1) continue;
      if (p121ForecastInFlight.has(key) || !p121AuthorizeRoute(`prefetch_${leg.phase}`)) continue;
      p121ForecastInFlight.add(key);
      routesService.fetchDistance(leg.origin, leg.destination).then((route) => {
        if (!p122RoutesAllowedForActiveJob() || stableJobId(activeJobDocument, 'active') !== currentId) return;
        const all = isPlainObject(activeJobDocument.routeForecasts) ? activeJobDocument.routeForecasts : {};
        persistActiveJob({ ...activeJobDocument, routeForecasts: { ...all, [key]: { schemaVersion: 1, phase: leg.phase, meters: route.meters, duration: route.duration, origin: leg.origin, destination: leg.destination, fetchedAt: new Date().toISOString() } }, updatedAt: new Date().toISOString(), updatedByPackageVersion: PACKAGE_VERSION }, '', { silent: true, p121Forecast: true, p119Route: true });
      }).catch((error) => p119RouteDiagnostic('runtime.routes.prefetch.failed', `Routes-prognos misslyckades: ${text(error && error.message, 'ROUTES_ERROR')}.`, 'warning')).finally(() => p121ForecastInFlight.delete(key));
    }
  }

  async function p121ScheduleMultiNextLoadForecast() {
    // A destination EXIT happens while the driver is still in Lossning. Do not
    // make a background Routes request from that manual phase.
    if (!p119RoutesTrusted || !routesService || !p122RoutesAllowedForActiveJob() || activeJobDocument.multiLoad !== true) return;
    const load = currentLoadNumber(activeJobDocument), marker = isPlainObject(activeJobDocument.p121MultiLoadForecast) ? activeJobDocument.p121MultiLoadForecast : {};
    if (Number(marker.loadNumber) === load && marker.createdAfterExit === true) return;
    const snapshot = currentGpsSnapshot(), origin = snapshot && { latitude: Number(snapshot.latitude), longitude: Number(snapshot.longitude) }, from = p121PointForRole(activeJobDocument, 'from'), destination = p121PointForRole(activeJobDocument, 'destination');
    if (!routesService.valid(origin) || !routesService.valid(from) || !routesService.valid(destination)) return;
    const jobId = stableJobId(activeJobDocument, 'active'); const legs = [{ phase: 'multi_next_start', origin, destination: from }, { phase: 'multi_next_transport', origin: from, destination }];
    for (const leg of legs) {
      const key = p121ForecastKey(leg.phase, leg.origin, leg.destination);
      if (p121ForecastInFlight.has(key) || routesService.distance(leg.origin, leg.destination) < 1 || !p121AuthorizeRoute(`multi_next_${leg.phase}`)) continue;
      p121ForecastInFlight.add(key);
      routesService.fetchDistance(leg.origin, leg.destination).then((route) => {
        if (!p122RoutesAllowedForActiveJob() || stableJobId(activeJobDocument, 'active') !== jobId) return;
        const all = isPlainObject(activeJobDocument.routeForecasts) ? activeJobDocument.routeForecasts : {};
        persistActiveJob({ ...activeJobDocument, routeForecasts: { ...all, [key]: { schemaVersion: 1, phase: leg.phase, meters: route.meters, duration: route.duration, origin: leg.origin, destination: leg.destination, fetchedAt: new Date().toISOString() } }, p121MultiLoadForecast: { loadNumber: load, createdAfterExit: true, createdAt: new Date().toISOString() }, updatedAt: new Date().toISOString(), updatedByPackageVersion: PACKAGE_VERSION }, '', { silent: true, p121Forecast: true, p119Route: true });
      }).catch((error) => p119RouteDiagnostic('runtime.routes.multiload-prefetch.failed', `Nästa-lass-prognos misslyckades: ${text(error && error.message, 'ROUTES_ERROR')}.`, 'warning')).finally(() => p121ForecastInFlight.delete(key));
    }
  }

  function p121DurationForPhase(documentValue, phase) {
    const route = p116RouteState(documentValue);
    if (text(route.phase) === phase && etaService && etaService.durationSeconds(route.duration) !== null) return { minutes: etaService.durationMinutes(route.duration), source: 'google_duration' };
    const forecast = isPlainObject(documentValue.routeForecasts) ? Object.values(documentValue.routeForecasts).find((item) => item && text(item.phase) === phase && etaService && etaService.durationSeconds(item.duration) !== null) : null;
    return forecast ? { minutes: etaService.durationMinutes(forecast.duration), source: 'google_cached_duration' } : null;
  }

  function p121LearningRecords() {
    const local = historyDocument.filter((item) => !isHistoryArchiveControl(item));
    return historyArchiveApi ? local.concat(effectiveHistoryArchiveRecords(true)) : local;
  }
  function p121OwnedEstimate(documentValue, phase) { const role = phase === 'loading' ? 'from' : (phase === 'unloading' ? 'destination' : 'return'); const place = p121PointForRole(documentValue, role); return etaService ? etaService.estimate(p121LearningRecords(), text(documentValue.jobTypeId), text(place.id), phase) : { minutes: 15, source: 'fallback_15' }; }

  function p121RenderEta() {
    const timeNode = byId('active-display-time-to'), clearNode = byId('active-display-clear-ca');
    if (!timeNode || !clearNode || !activeJobLoaded || !activeJobExists() || !etaService || isOtherActivity(activeJobDocument)) return;
    if (!historyLoaded) { try { historyDocument = readHistoryDocument(); historyLoaded = true; } catch (_) { watchdog.step('runtime.learning.history-unavailable', 'Historik kunde inte läsas för tidsprognos; reservtid används.', 'warning'); } }
    loadHistoryArchiveIfNeeded('history');
    const phase = phaseService.normalizePhase(text(activeJobDocument.phase)), driving = etaService.DRIVE.includes(phase), currentDuration = driving ? p121DurationForPhase(activeJobDocument, phase) : null;
    timeNode.textContent = driving ? (currentDuration ? `${currentDuration.minutes} min` : '–') : '0 min';
    if (activeJobDocument.multiLoad === true && phase === phaseService.PHASES.READY_TO_COMPLETE) {
      const forecast = isPlainObject(activeJobDocument.routeForecasts) ? Object.values(activeJobDocument.routeForecasts) : [];
      const nextStart = forecast.find((item) => item && text(item.phase) === 'multi_next_start' && etaService.durationSeconds(item.duration) !== null);
      const nextTransport = forecast.find((item) => item && text(item.phase) === 'multi_next_transport' && etaService.durationSeconds(item.duration) !== null);
      if (!nextStart || !nextTransport) { clearNode.textContent = '–'; return; }
      const load = p121OwnedEstimate(activeJobDocument, 'loading'), unload = p121OwnedEstimate(activeJobDocument, 'unloading');
      const minutes = etaService.durationMinutes(nextStart.duration) + load.minutes + etaService.durationMinutes(nextTransport.duration) + unload.minutes;
      const clearAt = new Date(Date.now() + minutes * 60000); clearNode.textContent = `Klar ca ${clearAt.toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' })}`; return;
    }
    const flow = phaseService.flow(activeJobDocument.returnRequired === true), at = flow.indexOf(phase), remaining = flow.slice(Math.max(0, at)).filter((item) => etaService.DRIVE.includes(item) || etaService.OWNED.includes(item)); let total = 0;
    if (machineTransportApi && machineTransportApi.preStageActive(activeJobDocument)) {
      const extra=p121DurationForPhase(activeJobDocument,'machine_bed_to_from'); if(!extra){clearNode.textContent='–';return;} total+=extra.minutes;
    }
    for (const item of remaining) {
      if (etaService.DRIVE.includes(item)) { const duration = p121DurationForPhase(activeJobDocument, item); if (!duration) { clearNode.textContent = '–'; return; } total += duration.minutes; continue; }
      const estimate = p121OwnedEstimate(activeJobDocument, item), elapsed = item === phase ? etaService.activePhaseMinutes(activeJobDocument, item) : 0; total += Math.max(0, estimate.minutes - (Number.isFinite(elapsed) ? elapsed : 0));
    }
    const clearAt = new Date(Date.now() + total * 60000); clearNode.textContent = `Klar ca ${clearAt.toLocaleTimeString('sv-SE', { hour: '2-digit', minute: '2-digit' })}`;
  }

  async function p119ScheduleRoute(reason = 'render', forceInitial = false) {
    if (!p122RoutesAllowedForActiveJob()) return;
    if (!p119RoutesTrusted) { p119RouteBlocked(reason, 'ready_missing'); return; }
    if (!routesService) { p119RouteBlocked(reason, 'destination_missing'); return; }
    const context = p119RouteContext();
    if (!context) { p119RouteBlocked(reason, 'no_active_job'); return; }
    if (!p118IsDrivingPhase(context.phase)) { p119RouteBlocked(reason, 'non_driving_phase'); return; }
    let destination = context.destination;
    if (!routesService.valid(destination) && !destination.address) { p119RouteBlocked(reason, 'destination_missing'); return; }
    const snapshot = p116LastGpsSnapshot || currentGpsSnapshot();
    if (!routesService.valid(snapshot)) { p119RouteBlocked(reason, 'gps_missing'); return; }
    const forecast = isPlainObject(activeJobDocument.routeForecasts)
      ? Object.values(activeJobDocument.routeForecasts).find((item) => item && text(item.phase) === context.phase && etaService && etaService.durationSeconds(item.duration) !== null && routesService.valid(item.origin) && routesService.distance(snapshot, item.origin) < 50)
      : null;
    if (forecast) {
      persistActiveJob({ ...activeJobDocument, routeDistance: { schemaVersion: 1, phase: context.phase, meters: forecast.meters, duration: forecast.duration, routeTargetId: text(context.destination.id), routeTargetKey: context.targetKey, destinationCoordinates: { latitude: context.destination.latitude, longitude: context.destination.longitude }, updatedAt: new Date().toISOString(), lastAttemptAtEpochMs: Date.now(), errorCode: '', source: 'prefetch' }, updatedAt: new Date().toISOString(), updatedByPackageVersion: PACKAGE_VERSION }, '', { silent: true, p119Route: true });
      p119RouteDiagnostic('runtime.routes.prefetch.reused', `Förberäknad Routes-prognos återanvändes för ${context.phase}.`);
      return;
    }
    if (p119RouteInFlightKey === context.key) { p119RouteBlocked(reason, 'request_in_flight'); return; }
    const stateMatchesContext = text(context.routeState.phase) === context.phase && text(context.routeState.routeTargetKey) === context.targetKey;
    const initial = !stateMatchesContext || !Number.isFinite(Number(context.routeState.lastAttemptAtEpochMs));
    const immediate = forceInitial || initial;
    if (!routesService.shouldRefresh(context.routeState, context.phase, p116PreviousGpsSnapshot, snapshot, Date.now(), immediate)) { p119RouteBlocked(reason, 'interval_not_elapsed'); return; }
    p119RouteInFlightKey = context.key;
    const attemptedAt = new Date().toISOString();
    try {
      if (!routesService.valid(destination)) destination = { ...destination, ...await routesService.geocode(destination.address) };
      p119RouteDiagnostic('runtime.routes.request', `Routes begärdes: fas=${context.phase}, orsak=${reason}, initial=${initial ? 'true' : 'false'}, hostTransport=true.`);
      if (routesService.distance(snapshot, destination) >= 1 && !p121AuthorizeRoute(reason)) return;
      const route = await routesService.fetchDistance(snapshot, destination);
      p119RouteDiagnostic('runtime.routes.http', 'Routes lokala hostsvar: http=200.');
      if (!p119RouteIsStillCurrent(context)) { p119RouteDiagnostic('runtime.routes.failed', 'Routes-svar ignorerades: kategori=stale_response.', 'warning'); return; }
      const next = { ...activeJobDocument, routeDistance: { schemaVersion: 1, phase: context.phase, meters: route.meters, duration: route.duration, routeTargetId: text(destination.id), routeTargetKey: context.targetKey, destinationCoordinates: { latitude: destination.latitude, longitude: destination.longitude }, updatedAt: attemptedAt, lastAttemptAtEpochMs: Date.now(), errorCode: '' }, updatedAt: attemptedAt, updatedByPackageVersion: PACKAGE_VERSION };
      persistActiveJob(next, '', { silent: true, p119Route: true });
      p119RouteDiagnostic('runtime.routes.success', `Routes-svar sparades: fas=${context.phase}, distanceMeters=${route.meters}, orsak=${reason}.`);
    } catch (error) {
      if (Number.isFinite(Number(error && error.httpStatus)) && Number(error.httpStatus) > 0) p119RouteDiagnostic('runtime.routes.http', `Routes lokala hostsvar: http=${Number(error.httpStatus)}.`, 'warning');
      if (!p119RouteIsStillCurrent(context)) { p119RouteDiagnostic('runtime.routes.failed', 'Routes-fel ignorerades: kategori=stale_response.', 'warning'); return; }
      const previous = p116RouteState(activeJobDocument);
      const category = p119RouteFailureCategory(error);
      const next = { ...activeJobDocument, routeDistance: { ...previous, schemaVersion: 1, phase: context.phase, routeTargetKey: context.targetKey, lastAttemptAtEpochMs: Date.now(), errorCode: category }, updatedAt: attemptedAt, updatedByPackageVersion: PACKAGE_VERSION };
      persistActiveJob(next, '', { silent: true, p119Route: true });
      p119RouteDiagnostic('runtime.routes.failed', `Routes misslyckades: kategori=${category}, fel=${text(error && error.message, 'ROUTES_ERROR')}.`, 'warning');
    } finally { if (p119RouteInFlightKey === context.key) p119RouteInFlightKey = ''; }
  }

  function determineInitialPhaseFromSnapshot(place, snapshot) {
    if (!phaseService || !geofenceService) {
      return { phase: 'loading', source: 'safe-fallback', reason: 'phase_service_missing' };
    }
    return phaseService.determineInitialPhase(
      snapshot,
      place && place.geofence,
      geofenceService.classifyPosition
    );
  }

  function initialPhaseNeedsGps(place) {
    return Boolean(place && place.geofence && place.geofence.enabled === true);
  }

  function waitForInitialGpsSnapshot(timeoutMs = 10000) {
    if (!gpsService || typeof gpsService.subscribe !== 'function' || typeof gpsService.setConsumer !== 'function') {
      return Promise.resolve(currentGpsSnapshot());
    }
    const immediate = currentGpsSnapshot();
    if (immediate && immediate.isUsable === true) return Promise.resolve(immediate);

    gpsService.setConsumer('phaseStart', true, 'Startposition');
    return new Promise((resolve) => {
      let finished = false;
      let unsubscribe = null;
      let timer = null;
      const finish = (snapshot) => {
        if (finished) return;
        finished = true;
        if (timer !== null) window.clearTimeout(timer);
        if (unsubscribe) unsubscribe();
        if (!runtimeDisposed && !runtimeFailed) gpsService.setConsumer('phaseStart', false, 'Startposition');
        resolve(snapshot || currentGpsSnapshot());
      };
      timer = window.setTimeout(() => finish(currentGpsSnapshot()), timeoutMs);
      unsubscribe = gpsService.subscribe((snapshot) => {
        if (snapshot && snapshot.isUsable === true) finish(snapshot);
      });
      if (finished && unsubscribe) unsubscribe();
    });
  }

  async function determineInitialPhaseForPlace(place) {
    const immediate = currentGpsSnapshot();
    if (!initialPhaseNeedsGps(place) || (immediate && immediate.isUsable === true)) {
      return determineInitialPhaseFromSnapshot(place, immediate);
    }
    const snapshot = await waitForInitialGpsSnapshot();
    return determineInitialPhaseFromSnapshot(place, snapshot);
  }

  function phaseEventType(nextPhase) {
    const phase = phaseService.normalizePhase(nextPhase);
    if (phase === phaseService.PHASES.START_ROUTE) return 'start_route_started';
    if (phase === phaseService.PHASES.LOADING) return 'loading_started';
    if (phase === phaseService.PHASES.TRANSPORT) return 'transport_started';
    if (phase === phaseService.PHASES.UNLOADING) return 'unloading_started';
    if (phase === phaseService.PHASES.LOAD_REGISTERED) return 'load_registered';
    if (phase === phaseService.PHASES.RETURN_TRANSPORT) return 'return_transport_started';
    if (phase === phaseService.PHASES.RETURN_UNLOADING) return 'return_unloading_started';
    if (phase === phaseService.PHASES.READY_TO_COMPLETE) return 'ready_to_complete';
    return 'phase_changed';
  }

  function buildPhaseTransitionDocument(documentValue, nextPhase, at, reason, source, extra = {}) {
    const previousPhase = phaseService.normalizePhase(text(documentValue.phase));
    const targetPhase = phaseService.normalizePhase(nextPhase);
    let nextDocument = phaseService.transitionRecord(documentValue, targetPhase, at, reason, source, extra);
    if (previousPhase === targetPhase) return nextDocument;

    if (targetPhase === phaseService.PHASES.LOADING) {
      nextDocument = {
        ...nextDocument,
        loadingStartedAt: text(nextDocument.loadingStartedAt, at),
        loadCycles: updateCurrentLoadCycle(nextDocument, { loadingStartedAt: at })
      };
    } else if (targetPhase === phaseService.PHASES.TRANSPORT) {
      nextDocument = {
        ...nextDocument,
        transportStartedAt: at,
        loadCycles: updateCurrentLoadCycle(nextDocument, { transportStartedAt: at })
      };
    } else if (targetPhase === phaseService.PHASES.UNLOADING) {
      nextDocument = {
        ...nextDocument,
        unloadingStartedAt: at,
        loadCycles: updateCurrentLoadCycle(nextDocument, { unloadingStartedAt: at })
      };
    } else if (targetPhase === phaseService.PHASES.RETURN_TRANSPORT) {
      const returnPlaceName = text(nextDocument.returnPlaceName, text(nextDocument.from, 'Från-plats'));
      nextDocument = {
        ...nextDocument,
        returnStartedAt: at,
        returnLeg: {
          ...(isPlainObject(nextDocument.returnLeg) ? nextDocument.returnLeg : {}),
          fromPlaceId: text(nextDocument.destinationPlaceId),
          fromPlaceName: text(nextDocument.destinationPlaceName),
          destinationPlaceId: text(nextDocument.returnPlaceId, text(nextDocument.fromPlaceId)),
          destinationPlaceName: returnPlaceName,
          startedAt: at,
          status: 'returning'
        }
      };
    } else if (targetPhase === phaseService.PHASES.RETURN_UNLOADING) {
      nextDocument = {
        ...nextDocument,
        returnArrivedAt: at,
        returnLeg: {
          ...(isPlainObject(nextDocument.returnLeg) ? nextDocument.returnLeg : {}),
          arrivedAt: at,
          status: 'arrived'
        }
      };
    } else if (targetPhase === phaseService.PHASES.READY_TO_COMPLETE) {
      nextDocument = { ...nextDocument, readyToCompleteAt: at };
    }

    if (previousPhase === phaseService.PHASES.LOAD_REGISTERED && targetPhase !== phaseService.PHASES.LOAD_REGISTERED) {
      nextDocument = phaseVisualService.clearLoadRegistered(nextDocument);
    }

    const existingLearning = isPlainObject(nextDocument.p116Learning) ? nextDocument.p116Learning : { schemaVersion: 1, anchors: {}, samples: [] };
    const anchors = isPlainObject(existingLearning.anchors) ? { ...existingLearning.anchors } : {};
    const samples = Array.isArray(existingLearning.samples) ? [...existingLearning.samples] : [];
    const addLearningSample = (anchorName, placeId, samplePhase) => {
      const started = new Date(text(anchors[anchorName])).getTime();
      const ended = new Date(at).getTime();
      if (source === 'manual' && Number.isFinite(started) && Number.isFinite(ended) && ended >= started) {
        samples.push({ placeId: text(placeId), phase: samplePhase, minutes: Math.round((ended - started) / 60000), capturedAt: at, source: 'manual-after-geofence' });
      }
    };
    if (targetPhase === phaseService.PHASES.LOADING && source === 'gps-geofence') anchors.loadingArrival = at;
    if (targetPhase === phaseService.PHASES.UNLOADING && source === 'gps-geofence') anchors.unloadingArrival = at;
    if (targetPhase === phaseService.PHASES.RETURN_UNLOADING && source === 'gps-geofence') anchors.returnArrival = at;
    if (targetPhase === phaseService.PHASES.TRANSPORT) addLearningSample('loadingArrival', nextDocument.fromPlaceId, 'loading');
    if (targetPhase === phaseService.PHASES.LOAD_REGISTERED) addLearningSample('unloadingArrival', nextDocument.destinationPlaceId, 'unloading');
    if (targetPhase === phaseService.PHASES.READY_TO_COMPLETE && previousPhase === phaseService.PHASES.RETURN_UNLOADING) addLearningSample('returnArrival', nextDocument.returnPlaceId || nextDocument.fromPlaceId, 'return_unloading');
    const existingP121 = isPlainObject(nextDocument.p121Learning) ? nextDocument.p121Learning : { schemaVersion: 1, samples: [] };
    const p121Samples = Array.isArray(existingP121.samples) ? [...existingP121.samples] : [];
    const p121PlaceId = previousPhase === phaseService.PHASES.LOADING
      ? text(nextDocument.fromPlaceId)
      : (previousPhase === phaseService.PHASES.UNLOADING ? text(nextDocument.destinationPlaceId)
        : (previousPhase === phaseService.PHASES.RETURN_UNLOADING ? text(nextDocument.returnPlaceId, text(nextDocument.fromPlaceId)) : ''));
    if (etaService && etaService.OWNED.includes(previousPhase) && p121PlaceId) {
      const minutes = etaService.activePhaseMinutes(nextDocument, previousPhase, new Date(at).getTime());
      const sample = { placeId: p121PlaceId, phase: previousPhase, minutes, startedAt: text(nextDocument.phaseEnteredAt), endedAt: at, capturedAt: at, source: text(source) };
      if (etaService.validSample(sample, historyService && historyService.workMinutes ? historyService.workMinutes(nextDocument, new Date(at).getTime()) : null)
        && !p121Samples.some((item) => text(item.phase) === sample.phase && text(item.placeId) === sample.placeId && text(item.endedAt) === sample.endedAt)) p121Samples.push(sample);
    }
    return {
      ...nextDocument,
      p116Learning: { schemaVersion: 1, anchors, samples },
      p121Learning: { schemaVersion: 1, samples: p121Samples },
      updatedAt: at,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(nextDocument, phaseEventType(targetPhase), at, source, {
        fromPhase: previousPhase,
        toPhase: targetPhase,
        transitionReason: reason,
        ...extra
      })
    };
  }

  function renderActivePhaseTrack(documentValue) {
    const track = byId('active-phase-track');
    if (!track) return;
    const otherActivity = isOtherActivity(documentValue);
    track.hidden = otherActivity;
    track.replaceChildren();
    if (otherActivity) return;
    const currentPhase = phaseService.normalizePhase(text(documentValue.phase));
    const phases = phaseService.flow(documentValue.returnRequired === true);
    const currentIndex = phases.indexOf(currentPhase);
    phases.forEach((phase, index) => {
      const item = document.createElement('li');
      item.className = 'phase-track-item';
      if (index < currentIndex) item.classList.add('is-complete');
      if (phase === currentPhase) {
        item.classList.add('is-current');
        item.setAttribute('aria-current', 'step');
      }
      item.textContent = phaseService.label(phase);
      track.appendChild(item);
    });
  }

  function geofencePlaceForEvent(event) {
    const placeId = text(event && event.placeId);
    const role = text(event && event.placeRoleCode);
    if (!placeId) return null;
    const place = role ? resolveJobPlace(activeJobDocument, role) : findPlaceById(placeId);
    return place && text(place.id) === placeId ? place : null;
  }

  function handleGeofenceEvent(event) {
    if (runtimeDisposed || runtimeFailed) return;
    if (handlingGeofenceEvent || !activeJobLoaded || !activeJobExists() || text(activeJobDocument.status) !== 'active') return;
    const activeJobId = stableJobId(activeJobDocument, 'active');
    if (!event || text(event.jobId) !== activeJobId) return;

    const phase = phaseService.normalizePhase(text(activeJobDocument.phase));
    const direction = text(event.direction);
    const machineState=isPlainObject(activeJobDocument.machineTransport)?activeJobDocument.machineTransport:null;
    if (phase===phaseService.PHASES.START_ROUTE && machineState && machineState.machineBedPickupRequired===true && text(event.placeId)===text(machineState.machineBedPickupPlaceId)) {
      const next=machineTransportApi.observePickup(activeJobDocument,direction,text(event.timestamp,new Date().toISOString()));
      persistActiveJob({...next,updatedAt:new Date().toISOString(),updatedByPackageVersion:PACKAGE_VERSION},'',{silent:true});
      watchdog.step('runtime.machine-transport.machine-bed',direction==='ENTER'?'Flaklager registrerades inom Startsträcka.':'Startsträcka fortsätter mot ordinarie Från-plats.');
      return;
    }
    const place = geofencePlaceForEvent(event);
    if (!place) return;
    const at = text(event.timestamp, new Date().toISOString());
    let targetPhase = '';
    let reason = '';

    if (phase === phaseService.PHASES.START_ROUTE
      && direction === 'ENTER'
      && text(event.placeId) === text(activeJobDocument.fromPlaceId)) {
      targetPhase = phaseService.PHASES.LOADING;
      reason = 'entered_from_geofence';
    } else if (phase === phaseService.PHASES.LOADING
      && direction === 'EXIT'
      && text(event.placeId) === text(activeJobDocument.fromPlaceId)
      && !(place.geofence && place.geofence.visualLoadingLock === true)) {
      targetPhase = phaseService.PHASES.TRANSPORT;
      reason = 'left_from_geofence_without_loading_lock';
    } else if (phase === phaseService.PHASES.TRANSPORT
      && direction === 'ENTER'
      && text(event.placeId) === text(activeJobDocument.destinationPlaceId)) {
      targetPhase = phaseService.PHASES.UNLOADING;
      reason = 'entered_destination_geofence';
    } else if (phase === phaseService.PHASES.UNLOADING
      && direction === 'EXIT'
      && text(event.placeId) === text(activeJobDocument.destinationPlaceId)
      && !(place.geofence && place.geofence.visualUnloadingLock === true)) {
      targetPhase = activeJobDocument.returnRequired === true
        ? phaseService.PHASES.RETURN_TRANSPORT
        : phaseService.PHASES.READY_TO_COMPLETE;
      reason = 'left_destination_geofence_without_unloading_lock';
    } else if (phase === phaseService.PHASES.RETURN_TRANSPORT
      && direction === 'ENTER'
      && text(event.placeId) === text(activeJobDocument.returnPlaceId, text(activeJobDocument.fromPlaceId))) {
      targetPhase = phaseService.PHASES.RETURN_UNLOADING;
      reason = 'entered_return_geofence';
    } else if (phase === phaseService.PHASES.RETURN_UNLOADING
      && direction === 'EXIT'
      && text(event.placeId) === text(activeJobDocument.returnPlaceId, text(activeJobDocument.fromPlaceId))
      && !(place.geofence && place.geofence.visualUnloadingLock === true)) {
      targetPhase = phaseService.PHASES.READY_TO_COMPLETE;
      reason = 'left_return_geofence_without_unloading_lock';
    }

    if (!targetPhase) return;
    handlingGeofenceEvent = true;
    try {
      const nextDocument = buildPhaseTransitionDocument(activeJobDocument, targetPhase, at, reason, 'gps-geofence', {
        placeId: text(event.placeId),
        direction
      });
      persistActiveJob(nextDocument, '', { silent: true });
      watchdog.step('runtime.phase.geofence-transition', `${phaseService.label(phase)} → ${phaseService.label(targetPhase)}.`);
      if (direction === 'EXIT' && phase === phaseService.PHASES.UNLOADING && activeJobDocument.multiLoad === true && text(event.placeId) === text(activeJobDocument.destinationPlaceId)) p121ScheduleMultiNextLoadForecast();
    } finally {
      handlingGeofenceEvent = false;
    }
  }

  function handleVisibilityChange() {
    if (runtimeDisposed || runtimeFailed) return;
    if (gpsService && gpsRuntimeReady) gpsService.setForeground(document.visibilityState !== 'hidden');
    if (document.visibilityState !== 'hidden') {
      if (gpsService && gpsRuntimeReady) {
        syncGpsDiagnosticsConsumer();
        syncActiveJobGpsConsumer();
        syncActiveGeofenceContext();
      }
      if (activeJobLoaded && activeJobExists()) renderActiveJob();
    }
  }

  function toggleSettingsGroup(groupId) {
    const requested = text(groupId);
    if (!requested) return;
    if (activeSettingsGroup === requested) {
      activeSettingsGroup = '';
      activeSettingsFunction = '';
      renderSettingsWorkspace(false);
      syncGpsDiagnosticsConsumer();
      return;
    }
    activeSettingsGroup = requested;
    activeSettingsFunction = '';
    renderSettingsWorkspace(true);
    syncGpsDiagnosticsConsumer();
  }

  function prepareSettingsFunction(functionId) {
    if (functionId === 'quick-choices') {
      renderQuickChoiceRegistry();
      return true;
    }
    if (functionId === 'history') {
      const loaded = loadHistoryIfNeeded(functionId);
      renderHistorySyncReview();
      renderHistorySyncConflicts();
      return loaded;
    }
    if (functionId === 'trash') return loadHistoryIfNeeded(functionId);
    if (functionId === 'statistics' || functionId === 'quick-choice-times') return loadNativeHistoryForReadOnly(functionId);
    if (functionId === 'excel-mail') { const result=loadNativeHistoryForReadOnly(functionId); renderExcelMailProfile(); return result; }
    if (functionId === 'receipt-import') {
      loadHistoryIfNeeded('receipt-import');
      renderReceiptHistory();
      return true;
    }
    if (functionId === 'sync') {
      renderSyncRoleView();
      renderSyncDiagnostic();
      return true;
    }
    return true;
  }

  function receiptRows() {
    return receiptApi ? receiptApi.store(settingsDocument[receiptApi.STORE_KEY]) : [];
  }

  function receiptRegistry() {
    return { findJobTypeById, findPlaceById, placeSupportsJobTypeRole };
  }

  function resolvedReceiptRow(row) {
    const jobType = text(row.jobTypeId) ? findJobTypeById(row.jobTypeId) : null;
    const from = text(row.fromPlaceId) ? findPlaceById(row.fromPlaceId) : null;
    const to = text(row.toPlaceId) ? findPlaceById(row.toPlaceId) : null;
    const linked = Boolean(text(row.jobTypeId) && text(row.fromPlaceId) && text(row.toPlaceId));
    return { ...row, jobType: jobType ? text(jobType.name, row.jobType) : row.jobType, from: from ? text(from.name, row.from) : row.from, to: to ? text(to.name, row.to) : row.to, registryLinked: linked, registryReferenceMissing: linked && (!jobType || !from || !to) };
  }

  function receiptEstimateMinutes(row) {
    if (Number(row && row.estimatedMinutes) > 0) return Number(row.estimatedMinutes);
    const name = text(row && row.jobType).toLocaleLowerCase('sv-SE');
    const from = text(row && row.from).toLocaleLowerCase('sv-SE');
    const to = text(row && row.to).toLocaleLowerCase('sv-SE');
    const values = historyDocument.filter((item) => !isHistoryItemTrashed(item) && !isReceiptImportedHistoryItem(item)).filter((item, index) => {
      const view = historyItemDisplay(item, index);
      if (text(row && row.jobTypeId) && text(row && row.fromPlaceId) && text(row && row.toPlaceId)) return view.jobTypeId === row.jobTypeId && view.fromPlaceId === row.fromPlaceId && view.destinationPlaceId === row.toPlaceId;
      return view.jobType.toLocaleLowerCase('sv-SE') === name && view.from.toLocaleLowerCase('sv-SE') === from && view.destination.toLocaleLowerCase('sv-SE') === to;
    }).map((item) => historyService ? historyService.workMinutes(item) : 0).filter((value) => Number(value) > 0).sort((a, b) => a - b);
    if (!values.length) return 0;
    const middle = Math.floor(values.length / 2);
    return values.length % 2 ? values[middle] : Math.round((values[middle - 1] + values[middle]) / 2);
  }

  function saveReceiptRows(rows) {
    try {
      const normalized = receiptApi.store(rows);
      if (!nativeStorage || !nativeStorage.isActive()) throw new Error('Native lagringsadaptern är inte redo.');
      nativeStorage.writeReceiptRows(normalized);
      settingsDocument = { ...settingsDocument, [receiptApi.STORE_KEY]: normalized, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
      nativeStorageLastError = '';
      return JSON.stringify(receiptRows()) === JSON.stringify(normalized);
    } catch (error) {
      nativeStorageLastError = error && error.message ? error.message : 'Kvittohistoriken kunde inte sparas i native history.';
      watchdog.step('runtime.native-storage.receipts.write-failed', nativeStorageLastError, 'warning');
      return false;
    }
  }

  function receiptMetaText(row) {
    const estimate = receiptApi.windowFor(row, receiptEstimateMinutes(row));
    const parts = [row.date || 'Datum saknas', row.receiptTime ? `Kvittotid ${row.receiptTime}` : 'Kvittotid saknas', `${Number(row.weight || 0).toLocaleString('sv-SE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ton`];
    if (estimate) parts.push(`Uppskattad tid ${estimate.minutes} min`, `${formatTimestamp(estimate.start)}–${formatTimestamp(estimate.end)}`);
    else if (row.receiptTime) parts.push('Snittid saknas');
    return parts.join(' · ');
  }

  function renderReceiptPreview() {
    const card = byId('receipt-preview-card'); const list = byId('receipt-preview-list');
    card.hidden = pendingReceiptRows.length === 0; list.replaceChildren();
    pendingReceiptRows.forEach((row, index) => {
      const article = document.createElement('article'); article.className = 'queue-card';
      const label = document.createElement('label'); const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = row.selected === true; checkbox.disabled = Array.isArray(row.blockingErrors) && row.blockingErrors.length > 0; checkbox.dataset.receiptPendingIndex = String(index);
      const title = document.createElement('strong'); title.textContent = row.jobType || 'Jobbtyp saknas'; label.append(checkbox, document.createTextNode(' '), title);
      const route = document.createElement('p'); route.className = 'queue-route'; route.textContent = `${row.from || 'Okänd'} → ${row.to || 'Till saknas'}`;
      const meta = document.createElement('p'); meta.className = 'field-help'; meta.textContent = receiptMetaText(row);
      const extra = document.createElement('p'); extra.className = 'field-help'; extra.textContent = [row.facility, row.materialCode, row.likelyAta ? `Trolig ÄTA: ${row.likelyAta}` : '', row.sourceBatchId ? `Batch: ${row.sourceBatchId}` : ''].filter(Boolean).join(' · ');
      article.append(label, route, meta, extra);
      const linkStatus = document.createElement('p'); linkStatus.className = 'field-help'; linkStatus.textContent = row.registryLinked ? 'Registerkoppling verifierad' : 'Saknar register-ID. Skapa en ID-säker importfil innan import.'; article.appendChild(linkStatus);
      const warnings = row.warnings.slice(); if (row.possibleDuplicate) warnings.unshift('Möjlig dubblett');
      if (warnings.length) { const warning = document.createElement('p'); warning.className = 'form-status is-error'; warning.textContent = warnings.join(' · '); article.appendChild(warning); }
      if (Array.isArray(row.blockingErrors) && row.blockingErrors.length) { const blocked = document.createElement('p'); blocked.className = 'form-status is-error'; blocked.textContent = `Import blockerad: ${row.blockingErrors.join(' · ')}`; article.appendChild(blocked); }
      list.appendChild(article);
    });
  }

  function prepareReceiptImport(raw, context = {}) {
    try {
      if (!receiptApi) throw new Error('Kvittoimporten kunde inte laddas.');
      if (!historyLoaded) loadHistoryIfNeeded('receipt-import');
      const parsed = receiptApi.read(raw, context);
      if (!parsed.length) throw new Error('Inga giltiga kvittorader hittades. Kontrollera filformatet.');
      pendingReceiptRows = receiptApi.prepare(parsed, receiptRows(), historyDocument, receiptRegistry());
      renderReceiptPreview();
      showStatus('receipt-status', `Kvittoimport redo. ${pendingReceiptRows.length} rader har analyserats. Kontrollera importlistan.`);
      watchdog.step('runtime.receipt.import-preview', `${pendingReceiptRows.length} rader, ${pendingReceiptRows.filter((row) => row.possibleDuplicate).length} dubblettvarningar.`);
    } catch (error) { pendingReceiptRows = []; renderReceiptPreview(); showStatus('receipt-status', error.message || 'Kunde inte läsa importfilen.', true); }
  }

  function pickReceiptFile() {
    try {
      receiptImportRequestId = `receipt-import-${Date.now().toString(36)}`;
      if (!window.StadslassHost || typeof window.StadslassHost.requestTextFileImport !== 'function') {
        throw new Error('Textimport stöds inte av den installerade startappen.');
      }
      window.StadslassHost.requestTextFileImport(JSON.stringify({ schemaVersion: 1, requestId: receiptImportRequestId, mimeTypes: ['application/json','text/plain','text/csv'], extensions: ['.json','.txt','.csv'] }));
      showStatus('receipt-status', 'Välj en textbaserad kvittofil. Ingen data har ändrats.');
    } catch (error) { receiptImportRequestId = ''; showStatus('receipt-status', error.message || 'Filväljaren kunde inte öppnas.', true); }
  }

  function cancelReceiptImport() {
    pendingReceiptRows = []; renderReceiptPreview(); showStatus('receipt-status', 'Import avbruten. Ingen data har ändrats.');
    watchdog.step('runtime.receipt.import-cancelled', 'Kvittoimporten avbröts före lagring.');
  }

  function confirmReceiptImport() {
    if (receiptCommitInProgress) return;
    const chosen = pendingReceiptRows.filter((row, index) => { const checkbox = byId('receipt-preview-list').querySelector(`input[data-receipt-pending-index="${index}"]`); return checkbox && !checkbox.disabled && checkbox.checked && (!row.blockingErrors || row.blockingErrors.length === 0); });
    if (!chosen.length) { showStatus('receipt-status', 'Inga rader valda för import.', true); return; }
    const revalidated = chosen.map((row) => receiptApi.validateRegistry(row, receiptRegistry()));
    if (revalidated.some((row) => row.blockingErrors.length > 0)) { pendingReceiptRows = pendingReceiptRows.map((row) => chosen.includes(row) ? receiptApi.validateRegistry(row, receiptRegistry()) : row); renderReceiptPreview(); showStatus('receipt-status', 'Importen stoppades eftersom ett register-ID inte längre är giltigt. Ingen kvittorad sparades.', true); return; }
    receiptCommitInProgress = true; byId('receipt-confirm').disabled = true;
    try {
      const current = receiptRows(); const committed = receiptApi.commit(revalidated); const next = current.concat(committed);
      if (!saveReceiptRows(next)) throw new Error('Kvittoraderna kunde inte sparas säkert.');
      pendingReceiptRows = []; renderReceiptPreview(); renderReceiptHistory(); if (historyLoaded) renderHistoryViews();
      showStatus('receipt-status', `Importerade ${committed.length} kvittorader.`);
      watchdog.step('runtime.receipt.import-confirmed', `${committed.length} kvittorader importerades.`);
    } catch (error) { showStatus('receipt-status', error.message || 'Importen kunde inte sparas.', true); }
    finally { receiptCommitInProgress = false; byId('receipt-confirm').disabled = false; }
  }

  function deleteReceiptRow(id) {
    const row = receiptRows().find((item) => item.id === text(id)); if (!row) return;
    if (!window.confirm(`Ta bort kvittoraden ${row.jobType || 'Kvitto'} ${row.date || ''}?`)) return;
    const next = receiptRows().filter((item) => item.id !== row.id);
    if (!saveReceiptRows(next)) { showStatus('receipt-status', 'Kvittoraden kunde inte tas bort.', true); return; }
    renderReceiptHistory(); if (historyLoaded) renderHistoryViews(); showStatus('receipt-status', 'Kvittoraden togs bort. Vanliga jobb är oförändrade.'); watchdog.step('runtime.receipt.deleted', 'En kvittorad togs bort.');
  }

  function renderReceiptHistory() {
    const list = byId('receipt-history-list'); if (!list) return; list.replaceChildren();
    const rows = receiptRows().slice().sort((a, b) => `${a.date}T${a.receiptTime || '00:00'}|${a.createdAt}`.localeCompare(`${b.date}T${b.receiptTime || '00:00'}|${b.createdAt}`, 'sv-SE'));
    byId('receipt-history-count').textContent = String(rows.length);
    if (!rows.length) { const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'Kvittohistoriken är tom.'; list.appendChild(empty); return; }
    rows.forEach((storedRow) => { const row=resolvedReceiptRow(storedRow); const card = document.createElement('article'); card.className = 'queue-card'; const title = document.createElement('h3'); title.textContent = row.jobType || 'Kvitto'; const route = document.createElement('p'); route.className = 'queue-route'; route.textContent = `${row.from || 'Okänd'} → ${row.to || 'Till saknas'}`; const meta = document.createElement('p'); meta.className = 'field-help'; meta.textContent = receiptMetaText(row); const extra = document.createElement('p'); extra.className = 'field-help'; extra.textContent = [row.facility,row.materialCode,row.likelyAta ? `Trolig ÄTA: ${row.likelyAta}` : '',row.sourceBatchId ? `Batch: ${row.sourceBatchId}` : ''].filter(Boolean).join(' · '); const link = document.createElement('p'); link.className='field-help'; link.textContent = !row.registryLinked ? 'Äldre kvitto – saknar registerkoppling' : (row.registryReferenceMissing ? 'Registerreferensen saknas – lagrat namn visas' : 'Registerkoppling verifierad'); const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger-button'; remove.textContent = 'Ta bort'; remove.dataset.deleteReceiptRow = row.id; card.append(title, route, meta, extra, link, remove); list.appendChild(card); });
  }

  function openSyncStatus() {
    showView('settings');
    activeSettingsGroup = 'import-extra';
    activeSettingsFunction = 'sync';
    prepareSettingsFunction('sync');
    renderSettingsWorkspace(true);
    syncDiagnosticObserve('sync-status-opened', { role: text(hostInfo && hostInfo.role) });
  }

  function backupStoreJson(name, fallback) {
    try { const raw = window.StadslassHost.readStore(name); return raw ? JSON.parse(raw) : fallback; } catch (_) { return fallback; }
  }
  function backupState() {
    return { packageVersion: PACKAGE_VERSION, settings: settingsDocument, receipts: receiptRows(), jobTypes: editableJobTypeRegistry ? editableJobTypeRegistry.items : [], places: editablePlaceRegistry ? editablePlaceRegistry.items : [], beaches: editableBeachRegistry ? editableBeachRegistry.items : [], quickChoices: quickChoiceRegistry ? quickChoiceRegistry.items : [], ataContacts: ataNotificationSettings().contacts || [], machines: settingsDocument.machines || [], queue: [], activeJob: {}, history: readHistoryDocument(), syncOutbox: nativeStorage && typeof nativeStorage.syncOutboxRows === 'function' ? nativeStorage.syncOutboxRows() : [] };
  }
  async function backupExport() {
    try {
      if (!nativeStorage || !nativeStorage.isActive()) throw new Error('Native lagring är inte redo för fullbackup.');
      const backup = await nativeStorage.createBackup(); const content = JSON.stringify(backup, null, 2); const now=new Date(); const stamp=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-')+'_'+[String(now.getHours()).padStart(2,'0'),String(now.getMinutes()).padStart(2,'0'),String(now.getSeconds()).padStart(2,'0')].join('-'); const requestId = `backup-${Date.now().toString(36)}`;
      const response = JSON.parse(window.StadslassHost.requestTextFileExport(JSON.stringify({schemaVersion:1,requestId,fileName:`stadslass-3.0-backup-${stamp}.json`,mimeType:'application/json',contentUtf8:content})));
      backupExportRequestId = response && response.ok ? requestId : '';
      showStatus('backup-status', response && response.ok ? 'Välj var backupfilen ska sparas.' : 'Backupfilen kunde inte öppnas för sparning.', !response || !response.ok);
    } catch (error) { backupExportRequestId = ''; showStatus('backup-status', error.message || 'Backup kunde inte skapas.', true); }
  }
  function renderBackupPreview(preview) {
    byId('backup-preview').hidden = false;
    byId('backup-preview-summary').textContent = `${preview.kind}-backup analyserad. ${Object.values(preview.counts).reduce((sum,value)=>sum+value.add,0)} poster importeras, ${Object.values(preview.counts).reduce((sum,value)=>sum+value.same,0)} exakta dubbletter hoppas över och ${preview.conflicts.length} poster kräver ett importval.`;
    const inventory=byId('backup-inventory'); inventory.replaceChildren();
    const statusLabel={import:'Importeras',skip:'Hoppas över – exakt dubblett',conflict:'Kräver importval',empty:'Ingen post'};
    preview.details.forEach((section)=>{ const card=document.createElement('article'); card.className='queue-card'; const title=document.createElement('strong'); title.textContent=`${section.label} (${section.entries.length})`; const entries=document.createElement('ul'); entries.className='compact-list'; if(section.entries.length) section.entries.forEach((entry)=>{const row=document.createElement('li'); row.textContent=`${entry.name}: ${statusLabel[entry.status]||entry.status}`; entries.appendChild(row);}); else { const row=document.createElement('li'); row.textContent='Inga poster i backupen.'; entries.appendChild(row); } card.append(title,entries); inventory.appendChild(card); });
    const manualItems=byId('backup-manual-items'); const manualHeading=byId('backup-manual-heading'); manualItems.replaceChildren(); const notes=Array.isArray(preview.importNotes)?preview.importNotes:[]; manualHeading.hidden=!notes.length;
    notes.forEach((note)=>{const card=document.createElement('article'); card.className='queue-card'; card.textContent=note; manualItems.appendChild(card);});
    const list = byId('backup-conflicts'); list.replaceChildren();
    preview.conflicts.forEach((conflict) => { const card=document.createElement('article'); card.className='queue-card'; const title=document.createElement('strong'); title.textContent=`${conflict.label}: ${conflict.name}`; const select=document.createElement('select'); select.dataset.backupConflict=`${conflict.key}:${conflict.id}`; (conflict.key==='activeJob'?['keep','replace']:['keep','replace','new']).forEach((value)=>{const option=document.createElement('option');option.value=value;option.textContent=value==='keep'?'Behåll befintlig':value==='replace'?'Ersätt befintlig':'Importera som ny'; if(value==='keep')option.selected=true;select.appendChild(option);}); card.append(title,select); list.appendChild(card); });
    if (!preview.conflicts.length) list.textContent='Inga konfliktval behövs.';
  }
  function backupPickImport() {
    try { const requestId=`backup-import-${Date.now().toString(36)}`; window.StadslassHost.requestTextFileImport(JSON.stringify({schemaVersion:1,requestId})); showStatus('backup-status','Välj en backupfil. Inget har ändrats.'); } catch (error) { showStatus('backup-status','Filväljaren kunde inte öppnas.',true); }
  }
  function backupNameKey(value) { return text(value).replace(/\s+/g,' ').toLocaleLowerCase('sv-SE'); }
  function backupLegacyArray(value) { if (Array.isArray(value)) return value; if (value && Array.isArray(value.items)) return value.items; if (value && Array.isArray(value.history)) return value.history; if (value && Array.isArray(value.jobs)) return value.jobs; return []; }
  function backupLegacyGeofence(value) {
    if (!value || typeof value !== 'object') return { enabled:false,type:'circle',visualLoadingLock:false,visualUnloadingLock:false,latitude:null,longitude:null,radiusMeters:null,toleranceMeters:null,polygonPoints:[] };
    const polygon=value.type==='polygon'; const center=value.center||{};
    return { enabled:true,type:polygon?'polygon':'circle',visualLoadingLock:false,visualUnloadingLock:value.unloadingLock===true||value.unloadingLockUntilWeight===true,latitude:polygon?null:Number(center.lat),longitude:polygon?null:Number(center.lon),radiusMeters:polygon?null:Number(value.radiusMeters),toleranceMeters:Number.isFinite(Number(value.toleranceMeters))?Number(value.toleranceMeters):0,polygonPoints:polygon?(value.points||[]).map((point)=>({latitude:Number(point.lat??point.latitude),longitude:Number(point.lon??point.longitude)})):[] };
  }
  function backupLegacyToCurrent(parsed) {
    const legacy=parsed.value.legacyParts||{}; const placesPart=legacy.places||{}; const geofencePart=legacy.geofences||{}; const jobPart=legacy.jobTypes||{}; const quickPart=legacy.quickItems||{}; const machinePart=legacy.machines||{}; const timestamp=new Date().toISOString(); const notes=[];
    let jobItems=editableJobTypeRegistry.items.slice(); const byJobName=()=>new Map(jobItems.map((item)=>[backupNameKey(item.name),item])); const meta=jobPart.jobTypeMeta||{};
    (jobPart.jobTypes||[]).forEach((name)=>{ const key=backupNameKey(name); if (!key||byJobName().has(key)) return; const legacyMeta=meta[name]||{}; const role=/havstång/i.test(name)?'havstang':(/maskintransport/i.test(name)?'machine-transport':'none'); let created;
      try { created=editableJobTypeApi.createItem({name,specialRole:role},jobItems,timestamp); } catch (_) { created=editableJobTypeApi.createItem({name,specialRole:'none'},jobItems,timestamp); notes.push(`Jobbtypen ${name} importerades utan skyddad specialroll eftersom den redan används.`); }
      jobItems.push({...created,ataEnabled:legacyMeta.ataJob===true||/\(ÄTA\)/i.test(name),materialCode:text(legacyMeta.materialCode),supportsReturn:legacyMeta.returnRequired===true,supportsMultiLoad:legacyMeta.multiLoad===true});
    });
    const jobByName=byJobName(); const mapJobIds=(names)=>Array.from(new Set((Array.isArray(names)?names:[]).map((name)=>jobByName.get(backupNameKey(name))).filter(Boolean).map((item)=>item.id)));
    let placeItems=editablePlaceRegistry.items.slice(); let beachItems=editableBeachRegistry.items.slice(); const labels=placesPart.placeLabels||{}; const addresses=placesPart.placeAddresses||{}; const configs=placesPart.placeConfigs||{}; const coordinates=placesPart.placeCoordinates||{}; const custom=Array.isArray(placesPart.customPlaces)?placesPart.customPlaces:[];
    const customByKey=new Map(custom.map((item)=>[text(item.key),item])); const keys=Array.from(new Set(Object.keys(addresses).concat(custom.map((item)=>text(item.key))).filter(Boolean)));
    const placeByName=()=>new Map(placeItems.map((item)=>[backupNameKey(item.name),item])); const beachByName=()=>new Map(beachItems.filter((item)=>!item.hidden).map((item)=>[backupNameKey(item.name),item]));
    keys.forEach((key)=>{ const customItem=customByKey.get(key)||{}; const name=text(labels[key])||text(customItem.label)||key; const config=configs[key]||configs[name]||{}; const coordinate=coordinates[key]||coordinates[name]||{}; const legacyFence=(geofencePart.placeGeofences||{})[key]||(geofencePart.placeGeofences||{})[name]||(geofencePart.disabledPlaceGeofences||{})[key]||(geofencePart.disabledPlaceGeofences||{})[name]; const geofence=backupLegacyGeofence(legacyFence); const input={name,addressOrPlusCode:text(addresses[key])||text(addresses[name]),placeRequirements:text((placesPart.placeRequirements||{})[key]??(placesPart.placeRequirements||{})[name]),openingHours:text((placesPart.placeOpeningHours||{})[key]??(placesPart.placeOpeningHours||{})[name]),canBeReturnPlace:(placesPart.placeReturnEligibility||{})[key]===true||(placesPart.placeReturnEligibility||{})[name]===true,jobTypeFromIds:mapJobIds(config.fromJobTypes),jobTypeToIds:mapJobIds(config.toJobTypes),geofence,latitude:Number(coordinate.lat),longitude:Number(coordinate.lon)};
      if (customItem.category==='badplats'||key.startsWith('beach_')) { const current=beachByName().get(backupNameKey(name)); if (current) beachItems=beachItems.map((item)=>item.id===current.id?editableBeachApi.updateItem(current,input,beachItems,timestamp):item); else beachItems.push(editableBeachApi.createItem(input,beachItems,timestamp)); }
      else { const current=placeByName().get(backupNameKey(name)); if (current) placeItems=placeItems.map((item)=>item.id===current.id?editablePlaceApi.updateItem(current,input,placeItems,new Set(jobItems.map((item)=>item.id)),timestamp):item); else placeItems.push(editablePlaceApi.createItem(input,placeItems,new Set(jobItems.map((item)=>item.id)),timestamp)); }
    });
    const placeIdByName=new Map(placeItems.concat(beachItems.filter((item)=>!item.hidden)).map((item)=>[backupNameKey(item.name),item.id])); let quickItems=quickChoiceRegistry.items.slice();
    (quickPart.quickItems||[]).forEach((legacyQuick)=>{ const job=jobByName.get(backupNameKey(legacyQuick.type))||jobItems.find((item)=>item.id===text(legacyQuick.jobTypeId)); const from=placeIdByName.get(backupNameKey(legacyQuick.place||legacyQuick.group)); const to=placeIdByName.get(backupNameKey(legacyQuick.dest)); if (!job||!from) { notes.push(`Snabbvalet ${text(legacyQuick.label)||text(legacyQuick.id)} hoppades över eftersom jobbtyp eller Från-plats saknas.`); return; } const rawItem={quickChoiceId:text(legacyQuick.id),buttonName:text(legacyQuick.label)||job.name,jobTypeId:job.id,jobTypeName:job.name,fromPlaceId:from,toPlaceId:to||'',returnRequired:false,multiLoad:false,comment:text(legacyQuick.comment),ataManual:false}; const same=quickItems.some((item)=>item.quickChoiceId===rawItem.quickChoiceId); if (!same) quickItems.push(quickChoiceApi.createItem(rawItem,quickItems,timestamp)); });
    const machineItems=Array.isArray(machinePart.machines)?machinePart.machines:backupLegacyArray(machinePart); const history=backupLegacyArray(legacy.history); const contacts=backupLegacyArray(legacy.ataContacts); if (!history.length && legacy.history && typeof legacy.history==='object') notes.push('Historikdelen saknar ett känt listformat och ändrades inte.');
    return {schemaVersion:1,format:'stadslass-backup',source:{app:'Stadslass 2.0',exportedAt:parsed.value.source.exportedAt},data:{settings:{},jobTypes:jobItems,places:placeItems,beaches:beachItems,quickChoices:quickItems,ataContacts:contacts,machines:machineItems,queue:[],activeJob:{},history,syncOutbox:[]},importNotes:notes};
  }
  function backupPrepareImport(raw) {
    try {
      const direct = JSON.parse(raw);
      if (direct && direct.format === 'stadslass-backup' && Number(direct.schemaVersion) === 2) {
        const categories = nativeStorage.validateBackupV2(direct);
        const labels = {history:'Historik',registries:'Register',learning:'Inlärning','sync-history':'Synkhistorik',trash:'Papperskorg','persistent-user-data':'Övrig beständig data'};
        const details = nativeStorage.CATEGORIES.map((category) => ({ key:category, label:labels[category]||category, entries:categories[category].map((row)=>({id:row.id,name:row.id,status:'import'})) }));
        const counts = Object.fromEntries(nativeStorage.CATEGORIES.map((category)=>[category,{incoming:categories[category].length,add:categories[category].length,same:0,conflict:0}]));
        pendingBackupPreview = {kind:'3.0 native', nativeBackup:direct, backup:direct, counts, details, conflicts:[], importNotes:['Kö, Aktivt jobb, roll, secrets och staging återställs inte från fullbackup.']};
      } else {
        const parsed=backupApi.parse(direct); const normalized=parsed.legacy?backupLegacyToCurrent(parsed):parsed.value;
        normalized.data.queue=[]; normalized.data.activeJob={};
        pendingBackupPreview=backupApi.preview(normalized,backupState()); pendingBackupPreview.importNotes=(normalized.importNotes||[]).concat(['Kö och Aktivt jobb återställs inte i P158.']);
      }
      renderBackupPreview(pendingBackupPreview);
      showStatus('backup-status','Importen är kontrollerad. Läs innehåll och eventuella importval innan du bekräftar.');
    } catch(error) { pendingBackupPreview=null; showStatus('backup-status',error.message||'Backupfilen kunde inte läsas.',true); }
  }
  async function backupConfirmImport() {
    if (!pendingBackupPreview) return;
    try {
      if (pendingBackupPreview.nativeBackup) {
        await nativeStorage.restoreBackupV2(pendingBackupPreview.nativeBackup);
        settingsDocument=readSettingsDocument();
        loadEditableJobTypeRegistry(); loadEditablePlaceRegistry(); loadEditableBeachRegistry(); buildEffectivePlaceRegistry(); validateRegistries(); loadQuickChoiceRegistry();
        populateRegistryForms(); renderEditableJobTypeRegistry(); renderEditablePlaceRegistry(); renderEditableBeachRegistry(); renderMachineRegistry(); renderQuickChoiceRegistry(); renderAtaNotificationSettings(); renderQuickChoices(); renderReceiptHistory();
        historyDocument=readHistoryDocument(); historyLoaded=true; historyArchiveLoaded=false; historyArchiveRecords=[]; loadHistoryArchiveIfNeeded(); renderHistoryViews();
        pendingBackupPreview=null; byId('backup-preview').hidden=true; showStatus('backup-status','Fullbackupen är återställd till native lagring. Roll och secrets är oförändrade och Kö/Aktivt jobb har inte återställts.');
        watchdog.step('runtime.backup.native-restored','P158-fullbackup återställdes kategori för kategori.');
        return;
      }
      const incoming=pendingBackupPreview.backup.data; const actions={}; document.querySelectorAll('select[data-backup-conflict]').forEach((select)=>{actions[select.dataset.backupConflict]=select.value;});
      const timestamp=new Date().toISOString();
      const nextJobTypes=editableJobTypeApi.withItems(editableJobTypeRegistry, backupApi.mergeList(editableJobTypeRegistry.items,incoming.jobTypes,'jobTypes',actions),timestamp);
      const nextJobTypeIds=new Set(nextJobTypes.items.map((item)=>item.id));
      const nextPlaces=editablePlaceApi.withItems(editablePlaceRegistry, backupApi.mergeList(editablePlaceRegistry.items,incoming.places,'places',actions),nextJobTypeIds,timestamp);
      const nextBeaches=editableBeachApi.withItems(editableBeachRegistry, backupApi.mergeList(editableBeachRegistry.items,incoming.beaches,'beaches',actions),timestamp);
      const nextQuick=quickChoiceApi.withItems(quickChoiceRegistry, backupApi.mergeList(quickChoiceRegistry.items,incoming.quickChoices,'quickChoices',actions),timestamp);
      let nextSettings={...settingsDocument,[receiptApi.STORE_KEY]:receiptApi.store(backupApi.mergeList(receiptRows(),incoming.receipts||[],'receipts',actions)),[editableJobTypeApi.SETTINGS_KEY]:nextJobTypes,[editablePlaceApi.SETTINGS_KEY]:nextPlaces,[editableBeachApi.SETTINGS_KEY]:nextBeaches,[quickChoiceApi.SETTINGS_KEY]:nextQuick,machines:backupApi.mergeList(settingsDocument.machines||[],incoming.machines,'machines',actions),settingsUpdatedByPackageVersion:PACKAGE_VERSION};
      const contacts=backupApi.mergeList(ataNotificationSettings().contacts||[],incoming.ataContacts,'ataContacts',actions); nextSettings=ataNotificationApi.documentWithSettings(nextSettings,{...ataNotificationSettings(),contacts});
      if (!writeSettingsDocument(nextSettings)) throw new Error(nativeStorageErrorMessage('Inställningslagret kunde inte sparas.'));
      if (!saveReceiptRows(nextSettings[receiptApi.STORE_KEY] || [])) throw new Error(nativeStorageErrorMessage('Kvittohistoriken kunde inte återställas.'));
      nextSettings = { ...nextSettings, [receiptApi.STORE_KEY]: receiptRows() };
      const historyNext=backupApi.mergeList(readHistoryDocument(),incoming.history,'history',actions);
      if (!writeHistoryDocument(historyNext)) throw new Error('Historiken kunde inte sparas till native lagring.');
      if (nativeStorage && typeof nativeStorage.mergeLegacySyncOutbox === 'function') nativeStorage.mergeLegacySyncOutbox(incoming.syncOutbox||[]);
      settingsDocument=nextSettings; editableJobTypeRegistry=nextJobTypes; editablePlaceRegistry=nextPlaces; editableBeachRegistry=nextBeaches; quickChoiceRegistry=nextQuick; applyEffectiveJobTypeRegistry(nextJobTypes.items); buildEffectivePlaceRegistry(); renderReceiptHistory(); historyDocument=readHistoryDocument(); historyLoaded=true; historyArchiveLoaded=false; historyArchiveRecords=[]; loadHistoryArchiveIfNeeded(); renderHistoryViews(); pendingBackupPreview=null; byId('backup-preview').hidden=true; showStatus('backup-status','Backupimporten är klar i native lagring. Kö och Aktivt jobb har inte återställts.');
    } catch(error) { showStatus('backup-status',error.message||'Importen kunde inte sparas.',true); }
  }

  function toggleSettingsFunction(groupId, functionId) {
    const requestedGroup = text(groupId);
    const requestedFunction = text(functionId);
    if (!requestedGroup || !requestedFunction || activeSettingsGroup !== requestedGroup) return;
    if (requestedFunction === 'trash' && !canUseActiveJob()) {
      return;
    }
    const opening = activeSettingsFunction !== requestedFunction;
    activeSettingsFunction = opening ? requestedFunction : '';
    if (opening) prepareSettingsFunction(requestedFunction);
    renderSettingsWorkspace(opening);
    syncGpsDiagnosticsConsumer();
  }

  function showStatus(elementId, message, isError = false) {
    const element = byId(elementId);
    if (!element || runtimeDisposed) return false;
    element.textContent = message;
    element.classList.toggle('is-error', isError);
    if (element.dataset.hideWhenEmpty === 'true') element.hidden = !text(message);
    return true;
  }

  function ataMailSettings() {
    return ataNotificationApi ? ataNotificationApi.settingsFromDocument(settingsDocument) : { supervisor: null, template: { fields: {}, closingText: '' } };
  }

  function ataMailWatchdog(step, detail) {
    if (watchdog && typeof watchdog.step === 'function') watchdog.step(step, detail, 'warning');
  }

  function updateAtaMailStatus(id, action, hostResult = '') {
    const index = historyItemIndexById(id);
    if (index < 0 || !ataMailApi || !ataMailApi.isEligible(historyDocument[index])) return false;
    const nextDocument = historyDocument.map((job, itemIndex) => itemIndex === index
      ? ataMailApi.withStatus(job, action, hostResult) : job);
    return persistHistory(nextDocument, '', currentView === 'today' ? 'today-load-status' : 'history-load-status');
  }

  function hostEmailDraft(recipient, subject, body) {
    if (!mailService) throw new Error('Den gemensamma mailtjänsten saknas.');
    return mailService.open({ mailType: 'ata', recipient, subject, body, attachment: null }, hostInfo);
  }

  function hostCopyText(label, value) {
    if (!bridgeAvailable() || typeof window.StadslassHost.copyText !== 'function') throw new Error('Kopiering stöds inte av den här installationen.');
    if (window.StadslassHost.copyText(label, value) !== true) throw new Error('Underlaget kunde inte kopieras.');
    return true;
  }

  function closeAtaMailDialog() {
    const dialog = byId('ata-mail-dialog');
    if (dialog) { dialog.hidden = true; dialog.setAttribute('aria-hidden', 'true'); }
    document.body.classList.remove('ata-mail-dialog-open');
    ataMailDialogContext = null;
    ataMailActionInProgress = false;
  }

  function finishAtaMailDialog() {
    const context = ataMailDialogContext;
    if (!context || ataMailActionInProgress) return;
    const returnToToday = context.mode === 'completion';
    closeAtaMailDialog();
    if (returnToToday) activateView('today');
  }

  function renderAtaMailDialogActions() {
    const context = ataMailDialogContext;
    if (!context) return;
    const historical = context.mode === 'history';
    const daily = context.mode === 'daily';
    const opened = context.draftOpened === true;
    const openButton = byId('ata-mail-open');
    const skipButton = byId('ata-mail-skip');
    openButton.hidden = historical;
    openButton.textContent = opened ? 'Klar – fortsätt i Stadslass' : 'Öppna mailutkast';
    openButton.disabled = !opened && daily && !context.underlag.recipient.valid;
    skipButton.hidden = historical || daily || opened;
    byId('ata-mail-copy').textContent = daily ? 'Kopiera dagsunderlag' : 'Kopiera underlag';
  }

  function openAtaMailDialog(context) {
    if (!context || !context.underlag) return;
    const dialog = byId('ata-mail-dialog');
    if (!dialog) return;
    ataMailDialogContext = { ...context, draftOpened: false };
    ataMailActionInProgress = false;
    const historical = context.mode === 'history';
    const daily = context.mode === 'daily';
    byId('ata-mail-heading').textContent = daily ? 'ÄTA-dagsmail' : 'ÄTA-underlag';
    byId('ata-mail-description').textContent = historical
      ? 'Färdigt underlag för historiskt ÄTA-uppdrag. Mailutkast öppnas inte här.'
      : (daily ? 'Samlat dagsunderlag till arbetsledaren.' : 'Färdigt ÄTA-underlag. Stadslass öppnar bara ett mailutkast – kontrollera och skicka själv.');
    byId('ata-mail-recipient').textContent = `Till: ${ataMailApi.recipientText(context.underlag.recipient)}`;
    byId('ata-mail-subject').textContent = `Ämne: ${context.underlag.subject}`;
    byId('ata-mail-preview').textContent = context.underlag.body;
    renderAtaMailDialogActions();
    showStatus('ata-mail-status', daily && !context.underlag.recipient.valid ? 'Arbetsledare saknas eller har ogiltig mailadress. Du kan fortfarande kopiera dagsunderlaget.' : '');
    dialog.hidden = false; dialog.setAttribute('aria-hidden', 'false'); document.body.classList.add('ata-mail-dialog-open');
    window.setTimeout(() => byId('ata-mail-close').focus({ preventScroll: true }), 0);
  }

  function openIndividualUnderlag(id, mode = 'today') {
    const index = historyItemIndexById(id); if (index < 0 || !ataMailApi || !ataMailApi.isEligible(historyDocument[index])) return;
    openAtaMailDialog({ mode, jobId: historyDocument[index].id, underlag: ataMailApi.individual(historyDocument[index], ataMailSettings().template) });
  }

  function openDailyUnderlag(day) {
    if (!ataMailApi) return;
    const underlag = ataMailApi.daily(activeHistoryEntries().map(({ item }) => item), day, ataMailSettings().supervisor);
    if (!underlag.jobs.length) return;
    openAtaMailDialog({ mode: 'daily', day, underlag });
  }

  function handleAtaMailOpen() {
    const context = ataMailDialogContext; if (!context || context.mode === 'history' || ataMailActionInProgress) return;
    if (context.draftOpened === true) { finishAtaMailDialog(); return; }
    if (context.mode === 'daily' && !context.underlag.recipient.valid) { showStatus('ata-mail-status', 'Spara en giltig arbetsledare i ÄTA avisering innan dagsmailet öppnas.', true); return; }
    ataMailActionInProgress = true;
    try {
      // V419 copies the prepared body as a reserve before the mail client opens. A successful
      // draft still records only the action that Stadslass actually knows: draft opened.
      try { hostCopyText('ÄTA-underlag', context.underlag.body); } catch (copyError) { ataMailWatchdog('runtime.ata.mail.reserve-copy-failed', 'Reservkopiering inför mailutkast misslyckades.'); }
      hostEmailDraft(context.underlag.recipient.valid ? context.underlag.recipient.email : '', context.underlag.subject, context.underlag.body);
      if (context.mode === 'daily' && /^\d{4}-\d{2}-\d{2}$/.test(text(context.day))) {
        const dates = Array.from(new Set([...(Array.isArray(settingsDocument.ataDailyMailDraftDates) ? settingsDocument.ataDailyMailDraftDates : []), context.day])).slice(-366);
        const next = { ...settingsDocument, ataDailyMailDraftDates: dates, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
        if (writeSettingsDocument(next)) settingsDocument = next;
      }
      context.draftOpened = true;
      renderAtaMailDialogActions();
      if (context.mode !== 'daily' && !updateAtaMailStatus(context.jobId, ataMailApi.ACTIONS.OPENED, 'opened')) throw new Error('Mailutkastet öppnades men statusen kunde inte sparas.');
      showStatus('ata-mail-status', 'Mailutkast öppnat. Stadslass kan inte se om mailet skickas.');
    } catch (error) { ataMailWatchdog('runtime.ata.mail.open-failed', 'Mailutkast kunde inte öppnas.'); showStatus('ata-mail-status', error.message || 'Mailutkast kunde inte öppnas.', true); }
    finally { ataMailActionInProgress = false; }
  }

  function handleAtaMailCopy() {
    const context = ataMailDialogContext; if (!context || ataMailActionInProgress) return;
    ataMailActionInProgress = true;
    try {
      hostCopyText(context.mode === 'daily' ? 'ÄTA-dagsunderlag' : 'ÄTA-underlag', context.underlag.body);
      // Kopiering är en reservåtgärd och får inte ändra uppdragets mailstatus eller tidsstämplar.
      showStatus('ata-mail-status', 'Underlaget är kopierat.');
    } catch (error) { ataMailWatchdog('runtime.ata.mail.copy-failed', 'Underlaget kunde inte kopieras.'); showStatus('ata-mail-status', error.message || 'Underlaget kunde inte kopieras.', true); }
    finally { ataMailActionInProgress = false; }
  }

  function handleAtaMailSkip() {
    const context = ataMailDialogContext; if (!context || context.draftOpened === true || context.mode !== 'today' && context.mode !== 'completion' || ataMailActionInProgress) return;
    ataMailActionInProgress = true;
    if (updateAtaMailStatus(context.jobId, ataMailApi.ACTIONS.SKIPPED, 'skipped')) closeAtaMailDialog();
    else showStatus('ata-mail-status', 'Valet kunde inte sparas.', true);
    ataMailActionInProgress = false;
  }

  function currentScrollY() {
    return Math.max(0, Number(window.scrollY) || Number(document.documentElement.scrollTop) || 0);
  }

  function preserveScrollAfterRender(previousScrollY) {
    const safeScrollY = Math.max(0, Number(previousScrollY) || 0);
    window.requestAnimationFrame(() => {
      window.scrollTo(0, safeScrollY);
      window.requestAnimationFrame(() => window.scrollTo(0, safeScrollY));
    });
  }

  function revealInlineControl(selector, previousScrollY) {
    const safeScrollY = Math.max(0, Number(previousScrollY) || 0);
    window.requestAnimationFrame(() => {
      window.scrollTo(0, safeScrollY);
      window.requestAnimationFrame(() => {
        const element = document.querySelector(selector);
        if (!element || element.hidden) return;
        const nav = document.querySelector('.bottom-nav');
        const navRect = nav ? nav.getBoundingClientRect() : { height: 0 };
        const visibleBottom = Math.max(0, window.innerHeight - Math.max(0, Number(navRect.height) || 0) - 12);
        const rect = element.getBoundingClientRect();
        const currentY = currentScrollY();
        const requiredDown = Math.max(0, rect.bottom - visibleBottom);
        window.scrollTo(0, Math.max(safeScrollY, currentY + requiredDown));
      });
    });
  }

  function isPressFeedbackExcluded(element) {
    return Boolean(element && element.closest([
      '#view-quick-choices',
      '#quick-choice-registry-card',
      '[data-target="quickChoices"]',
      '[data-settings-function="quick-choices"]'
    ].join(',')));
  }

  function clearPressFeedback(element) {
    if (!element) return;
    element.classList.remove('is-press-feedback');
    element.removeAttribute('aria-busy');
  }

  function cancelPendingPressActions() {
    pendingPressActions.forEach((timer, element) => {
      window.clearTimeout(timer);
      clearPressFeedback(element);
    });
    pendingPressActions.clear();
  }

  function pressTarget(event) {
    const target = event.target && event.target.closest
      ? event.target.closest('button, a[href], [role="button"], input[type="button"], input[type="submit"], input[type="reset"]')
      : null;
    if (!target || isPressFeedbackExcluded(target)) return null;
    if (target.disabled || target.getAttribute('aria-disabled') === 'true') return null;
    return target;
  }

  function installPressFeedback() {
    document.addEventListener('pointerdown', (event) => {
      if (runtimeDisposed || runtimeFailed || event.button !== 0) return;
      const element = pressTarget(event);
      if (element) element.classList.add('is-press-feedback');
    }, true);
    document.addEventListener('pointercancel', (event) => {
      if (runtimeDisposed || runtimeFailed) return;
      const element = pressTarget(event);
      if (element && !pendingPressActions.has(element)) clearPressFeedback(element);
    }, true);
    document.addEventListener('pointerout', (event) => {
      if (runtimeDisposed || runtimeFailed) return;
      const element = pressTarget(event);
      if (!element || pendingPressActions.has(element)) return;
      if (event.relatedTarget && element.contains(event.relatedTarget)) return;
      clearPressFeedback(element);
    }, true);
    document.addEventListener('click', (event) => {
      if (runtimeDisposed || runtimeFailed) return;
      const element = pressTarget(event);
      if (!element) return;
      if (element.dataset.pressFeedbackReplay === '1') {
        delete element.dataset.pressFeedbackReplay;
        return;
      }
      if (pendingPressActions.has(element)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
      element.classList.add('is-press-feedback');
      element.setAttribute('aria-busy', 'true');
      const timer = window.setTimeout(() => {
        pendingPressActions.delete(element);
        if (!element.isConnected || element.disabled || element.getAttribute('aria-disabled') === 'true') {
          clearPressFeedback(element);
          return;
        }
        clearPressFeedback(element);
        element.dataset.pressFeedbackReplay = '1';
        element.click();
      }, PRESS_DELAY_MS);
      pendingPressActions.set(element, timer);
    }, true);
  }

  function showView(target) {
    if (!Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) {
      return;
    }
    cancelPendingPressActions();
    if (currentView === 'settings' && ['home', 'queue', 'quickChoices'].includes(target)) { activeSettingsGroup = ''; activeSettingsFunction = ''; renderSettingsWorkspace(false); }
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.hidden = view.dataset.view !== target;
    });
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      const active = button.dataset.target === target;
      button.classList.toggle('is-active', active);
      if (active) {
        button.setAttribute('aria-current', 'page');
      } else {
        button.removeAttribute('aria-current');
      }
    });
    syncActiveJobNavigationMarker();
    syncQueueIncomingMarker();
    byId('page-title').textContent = PAGE_TITLES[target];
    currentView = target;
    try { window.sessionStorage.setItem(RUNTIME_VIEW_SESSION_KEY, target); } catch (_) {}
    syncActivePhaseBackdropVisibility();
    syncGpsDiagnosticsConsumer();
    byId('main-content').focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function syncActiveJobNavigationMarker() {
    const button = document.querySelector('.nav-button[data-target="active"]');
    if (!button) return;
    const hasJob = activeJobLoaded && activeJobExists();
    button.classList.toggle('has-active-job', hasJob);
    button.setAttribute('aria-label', hasJob ? 'Aktivt jobb pågår' : 'Aktivt jobb');
  }

  function syncQueueIncomingMarker() {
    const button = document.querySelector('.nav-button[data-target="queue"]');
    if (!button) return;
    const hasNew = isVehicleRole() && queueLoaded && queueDocument.some((raw) => raw && raw.p141NewFromMobile === true);
    button.classList.toggle('has-new-mobile-assignment', hasNew);
    if (hasNew) button.setAttribute('aria-label', 'Kö – nytt uppdrag från Mobil');
    else button.removeAttribute('aria-label');
  }

  function p143ClearIncomingQueueMarkerOnOpen() {
    if (!isVehicleRole() || !queueLoaded) return true;
    let changed = false;
    const nextDocument = queueDocument.map((raw) => {
      if (!raw || raw.p141NewFromMobile !== true) return raw;
      changed = true;
      return { ...raw, p141NewFromMobile: false };
    });
    if (!changed) { syncQueueIncomingMarker(); return true; }
    const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      try {
        syncDiagnosticObserve('queue-new-marker-clear-failed', {
          role: 'vehicle_189',
          packageVersion: PACKAGE_VERSION,
          error: syncV65SafeTechnicalText(window.StadslassHost.getLastError() || 'Kömarkeringen kunde inte sparas.', 160)
        });
      } catch (_) {}
      syncQueueIncomingMarker();
      return false;
    }
    queueDocument = nextDocument;
    renderQueue();
    return true;
  }

  function isMobileRole() {
    return hostInfo && hostInfo.role === 'mobile';
  }

  function isVehicleRole() {
    return hostInfo && hostInfo.role === 'vehicle_189';
  }

  function canUseQueue() {
    return isMobileRole() || isVehicleRole();
  }

  function canUseActiveJob() {
    return isVehicleRole();
  }

  function canReadHistory() {
    return isMobileRole() || isVehicleRole();
  }

  function restoreRuntimeView() {
    let target = 'home';
    try { target = text(window.sessionStorage.getItem(RUNTIME_VIEW_SESSION_KEY), 'home'); } catch (_) {}
    // Inställningar återställs aldrig automatiskt: en tidigare historikpanel får
    // inte öppnas igen vid start eller av en bakgrundsladdning.
    if (target !== 'home' && target !== 'settings' && Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) activateView(target);
  }

  function relocateLocalJobFormToQueue() {
    const card = byId('active-empty-card');
    const queueView = byId('view-queue');
    const queueListSection = byId('queue-list-heading').closest('section');
    if (!card || !queueView || !queueListSection) return;
    if (card.parentElement !== queueView) queueView.insertBefore(card, queueListSection);
    byId('active-form-heading').textContent = 'Nytt uppdrag';
    byId('active-form-intro').textContent = 'Skapa ett uppdrag och välj om det ska startas direkt eller läggas i kön.';
    byId('active-form-submit').textContent = 'Starta direkt';
    card.hidden = !isVehicleRole();
  }

  function syncLocalJobActions() {
    const startButton = byId('active-form-submit');
    const queueButton = byId('active-form-queue-submit');
    if (!startButton || !queueButton) return;
    const blocked = !isVehicleRole() || (activeJobLoaded && activeJobExists()) || activeJobStartInProgress || localQueueCreateInProgress;
    startButton.disabled = blocked;
    queueButton.disabled = !isVehicleRole() || localQueueCreateInProgress;
  }

  function syncQueueFormVisibility() {
    const formCard = byId('queue-form').closest('.section-card');
    if (!formCard) return;
    formCard.hidden = isVehicleRole() && !editingQueueId;
  }

  function renderQueueRoleCopy() {
    if (isMobileRole()) {
      byId('queue-heading').textContent = 'Mobilens planeringskö';
      byId('queue-summary-text').textContent = 'Här visas uppdragen du har planerat på mobilen.';
      byId('queue-form-heading').textContent = 'Lägg till planerat uppdrag';
      byId('queue-form-intro').textContent = 'Lägg till och hantera uppdrag i Mobilens lokala planeringskö. Uppdrag kan skickas till 189 via postlådan.';
      byId('queue-submit-button').textContent = 'Lägg i planeringskö';
      byId('queue-list-heading').textContent = 'Planerad kö';
    } else if (isVehicleRole()) {
      byId('queue-heading').textContent = '189:s operativa kö';
      byId('queue-summary-text').textContent = 'Här visas uppdragen som finns på 189.';
      byId('queue-list-heading').textContent = 'Operativ kö';
    }
    syncQueueFormVisibility();
  }

  function applyRoleBoundaries() {
    const queueAllowed = canUseQueue();
    const activeAllowed = canUseActiveJob();
    byId('open-queue').hidden = !queueAllowed;
    byId('open-active-job').hidden = !activeAllowed;
    byId('open-today').hidden = !activeAllowed;
    byId('open-history-from-home').hidden = false;
    byId('open-statistics-from-home').hidden = false;
    document.querySelector('.nav-button[data-target="queue"]').hidden = !queueAllowed;
    document.querySelector('.nav-button[data-target="quickChoices"]').hidden = !queueAllowed;
    document.querySelector('.nav-button[data-target="active"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="today"]').hidden = !activeAllowed;
    document.querySelectorAll('.settings-function-button[data-requires-vehicle="true"]').forEach((button) => {
      button.hidden = !activeAllowed;
    });
    renderSettingsWorkspace(false);
    renderQueueRoleCopy();
    relocateLocalJobFormToQueue();
    syncLocalJobActions();
    byId('quick-choice-mode-direct').disabled = !activeAllowed;
    if (!activeAllowed) byId('quick-choice-mode-queue').checked = true;
    byId('quick-choice-role-note').textContent = activeAllowed
      ? 'Lägg i kö är förvalt. Starta direkt är tillgängligt när inget annat vanligt uppdrag är aktivt; Övrig verksamhet följer sin befintliga parallella modell.'
      : 'På Mobil skapar Snabbval vanliga uppdrag i planeringskön. Starta direkt är endast tillgängligt på 189 / Surfplatta.';
    document.documentElement.classList.toggle('vehicle-role', isVehicleRole());
    syncQueueIncomingMarker();
    updateBottomNavReservedSpace();

    if (isMobileRole()) {
      byId('role-boundary-note').textContent = 'Här visas mobilens planeringsfunktioner.';
      byId('active-role-note').textContent = 'Aktivt jobb används på 189.';
    } else if (isVehicleRole()) {
      byId('role-boundary-note').textContent = 'Här visas uppdragen som finns lokalt på 189. Synk sköts via postlådan när appen är aktiv.';
      byId('active-role-note').textContent = '';
      byId('active-role-note').hidden = true;
    }
    const diagnostic = syncDiagnosticEnsure();
    if (diagnostic) diagnostic.firstRoleView(syncDiagnosticContext());
    performanceObserve('role-view-ready', { role: text(hostInfo && hostInfo.role), usable: true });
  }

  function p150ScrollToOperationalQueueOnOpen() {
    if (!isVehicleRole() || !queueLoaded || queueDocument.length === 0 || editingQueueId || machineQuickFlowActive) return;
    const run = () => {
      if (currentView !== 'queue' || !isVehicleRole() || !queueLoaded || queueDocument.length === 0 || editingQueueId || machineQuickFlowActive) return;
      const heading = byId('queue-list-heading');
      if (!heading) return;
      const topbar = document.querySelector('.topbar');
      const offset = (topbar ? topbar.getBoundingClientRect().height : 0) + 12;
      const targetTop = Math.max(0, currentScrollY() + heading.getBoundingClientRect().top - offset);
      window.scrollTo(0, targetTop);
    };
    if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(() => window.requestAnimationFrame(run));
    else window.setTimeout(run, 0);
  }

  function activateView(target) {
    if (currentView === 'quickChoices' && target !== 'quickChoices') {
      clearQuickChoiceFallbackState({ clearStatus: true });
    }
    if ((target === 'queue' || target === 'quickChoices') && !canUseQueue()) {
      showView('home');
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if ((target === 'active' || target === 'today' || target === 'trash' || target === 'statistics') && !canUseActiveJob()) {
      showView('home');
      showStatus('role-boundary-note', 'Driftvyn är blockerad på denna enhetsroll.', true);
      return;
    }
    showView(target);
    if (target === 'queue') {
      loadQueueIfNeeded();
      p143ClearIncomingQueueMarkerOnOpen();
      p150ScrollToOperationalQueueOnOpen();
    } else if (target === 'quickChoices') {
      byId('quick-choice-mode-queue').checked = true;
      byId('quick-choice-mode-direct').checked = false;
      clearQuickChoiceFallbackState({ clearStatus: true });
      const activeReadable = refreshActiveJobForQuickChoice({ showError: false });
      renderQuickChoices();
      if (!activeReadable && isVehicleRole()) {
        showStatus('quick-choice-status', 'Aktivt jobb kunde inte kontrolleras. Lägg i kö kan användas säkert.', true);
      }
    } else if (target === 'active') {
      loadActiveJobIfNeeded();
    } else if (target === 'today' || target === 'history' || target === 'trash' || target === 'statistics') {
      if (target === 'today' || target === 'history') void loadHistoryForView(target);
      else loadHistoryIfNeeded(target);
    } else if (target === 'sync') {
      renderSyncRoleView();
    }
  }

  function renderHostInfo() {
    const role = hostInfo.roleLabel || hostInfo.role || 'Okänd roll';
    byId('role-chip').textContent = role;
    byId('host-version').textContent = `${hostInfo.hostVersionName} (${hostInfo.hostVersionCode})`;
    byId('package-version').textContent = String(hostInfo.packageVersion);
    byId('technical-role').textContent = role;
    byId('device-id').textContent = hostInfo.deviceId || 'Saknas';
    renderP121Budget();
    byId('watchdog-state').textContent = watchdog.getStatus();
    byId('watchdog-phase').textContent = watchdog.getLastPhase();
  }

  function saveSettings(event) {
    event.preventDefault();
    const nextPreferences = {
      largeText: byId('large-text').checked,
      showTechnicalInfo: byId('show-technical').checked
    };
    const nextDocument = {
      ...settingsDocument,
      [UI_SETTINGS_KEY]: nextPreferences,
      [NOTIFICATION_SOUND_SETTINGS_KEY]: { selectedSound: byId('notification-sound-select').value },
      [PHASE_COLOR_SETTINGS_KEY]: readPhaseColorForm(),
      settingsSchemaVersion: 2,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus('save-status', window.StadslassHost.getLastError() || 'Inställningarna kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    applyUiPreferences(nextPreferences);
    showStatus('save-status', 'Inställningarna är sparade.');
    showStatus('notification-sound-status', p142NotificationEnabled() ? 'Ljudvalet är sparat.' : 'Ingen signal är vald.');
  }

  function loadGoogleSettings() {
    const stored = settingsDocument[googleService.SETTINGS_KEY];
    googleDiagnostics = googleService.normalizeDiagnostics(settingsDocument[googleService.DIAGNOSTICS_KEY]);
    try {
      googleSettings = googleService.validateSettings(stored);
      watchdog.step('runtime.google.settings.validated', googleService.hasApiKey(googleSettings.apiKey)
        ? 'En maskerad lokal Google API-nyckel är tillgänglig för den gemensamma Google-tjänsten.'
        : 'Ingen Google API-nyckel är ännu sparad lokalt. Geokodning kommer inte att blockera platslagring.');
    } catch (error) {
      googleSettings = googleService.normalizeSettings({});
      watchdog.step('runtime.google.settings.invalid', `${error && error.message ? error.message : 'Google-inställningen kunde inte verifieras.'} Den ogiltiga nyckeln används inte och övriga inställningar är orörda.`, 'warning');
    }
  }

  function renderGoogleDiagnostics() {
    const element = byId('google-diagnostic-summary');
    if (!element) return;
    const entries = googleDiagnostics && Array.isArray(googleDiagnostics.entries) ? googleDiagnostics.entries : [];
    const latest = entries.length ? entries[entries.length - 1] : null;
    if (!latest) {
      element.textContent = 'Ingen geokodningsfelrapport är sparad.';
      element.classList.remove('is-error');
      return;
    }
    const flowLabel = latest.registerFlow || (latest.flow === 'beach' ? 'Badplatser' : (latest.flow === 'place' ? 'Platser' : 'Okänt register'));
    const googleStatus = latest.googleStatus || 'ingen Google-status';
    const errorName = latest.errorName || 'okänt JavaScript-fel';
    const pageContext = latest.pageOrigin || latest.pageProtocol || 'okänd origin';
    const onlineLabel = latest.navigatorOnline === true ? 'online' : (latest.navigatorOnline === false ? 'offline' : 'okänd nätstatus');
    element.textContent = `${flowLabel} · ${latest.errorCode || 'RUNTIME_ERROR'} · ${googleStatus} · ${errorName} · ${pageContext} · ${onlineLabel} · ${latest.at || 'okänd tid'}`;
    element.classList.add('is-error');
  }

  function renderGoogleSettings() {
    byId('google-api-key').value = '';
    byId('google-key-mask').textContent = googleService.maskApiKey(googleSettings && googleSettings.apiKey);
    byId('google-service-clear').disabled = !googleSettings || !googleService.hasApiKey(googleSettings.apiKey);
    renderGoogleDiagnostics();
  }

  function persistGoogleDiagnostic(diagnostic) {
    const nextDiagnostics = googleService.appendDiagnostic(googleDiagnostics, diagnostic, new Date().toISOString());
    const nextDocument = {
      ...settingsDocument,
      [googleService.DIAGNOSTICS_KEY]: nextDiagnostics,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      watchdog.step('runtime.google.diagnostic.write-failed', window.StadslassHost.getLastError() || 'Den maskerade Google-diagnostiken kunde inte sparas.', 'warning');
      return false;
    }
    settingsDocument = nextDocument;
    googleDiagnostics = nextDiagnostics;
    renderGoogleDiagnostics();
    watchdog.step('runtime.google.diagnostic.saved', `${diagnostic.flow || 'unknown'}: ${diagnostic.errorCode || 'RUNTIME_ERROR'} / ${diagnostic.googleStatus || 'NO_GOOGLE_STATUS'} / ${diagnostic.stage || 'unknown'}.`, 'warning');
    return true;
  }

  async function requestSharedRegistryGeocoding(current, flow) {
    try {
      const result = await googleService.geocode(current.addressOrPlusCode, googleSettings && googleSettings.apiKey);
      const geocoding = googleService.resolvedGeocoding(current.geocoding, result, new Date().toISOString());
      watchdog.step(`runtime.google.geocoding.${flow}.resolved`, `Google Geocoding löste ${flow === 'beach' ? 'badplats' : 'plats'}-ID ${current.id} genom den gemensamma tjänsten.`);
      return {
        geocoding,
        isError: false,
        detail: `Koordinater hämtades. Identifierad plats: ${geocoding.formattedAddress || current.addressOrPlusCode}.`
      };
    } catch (error) {
      const status = googleService.errorStatus(error);
      const userMessage = googleService.userMessageForError(error);
      const geocoding = googleService.failedGeocoding(
        current.geocoding,
        current.addressOrPlusCode,
        error && error.code,
        userMessage,
        status,
        new Date().toISOString()
      );
      const diagnostic = googleService.diagnosticFromError(error, {
        flow,
        itemId: current.id,
        apiKey: googleSettings && googleSettings.apiKey,
        query: current.addressOrPlusCode,
        at: geocoding.lastAttemptAt
      });
      persistGoogleDiagnostic(diagnostic);
      watchdog.step(
        `runtime.google.geocoding.${flow}.failed`,
        `${current.id}: ${diagnostic.errorCode} / ${diagnostic.googleStatus || 'NO_GOOGLE_STATUS'} / ${diagnostic.errorName || 'NO_ERROR_NAME'} / ${diagnostic.pageProtocol || 'NO_PROTOCOL'} / ${diagnostic.navigatorOnline === true ? 'ONLINE' : (diagnostic.navigatorOnline === false ? 'OFFLINE' : 'ONLINE_UNKNOWN')} / ${diagnostic.category} / ${diagnostic.stage}.`,
        'warning'
      );
      return { geocoding, isError: true, detail: userMessage };
    }
  }

  function persistGoogleSettings(nextSettings) {
    const validated = googleService.validateSettings(nextSettings);
    const nextDocument = {
      ...settingsDocument,
      [googleService.SETTINGS_KEY]: validated,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus('google-service-status', window.StadslassHost.getLastError() || 'Google API-nyckeln kunde inte sparas lokalt.', true);
      return false;
    }
    settingsDocument = nextDocument;
    googleSettings = validated;
    renderGoogleSettings();
    watchdog.step('runtime.google.settings.saved', googleService.hasApiKey(validated.apiKey)
      ? 'Google API-nyckeln sparades maskerad i det lokala inställningslagret.'
      : 'Den lokalt sparade Google API-nyckeln togs bort.');
    return true;
  }

  function saveGoogleSettings(event) {
    event.preventDefault();
    try {
      const apiKey = text(byId('google-api-key').value);
      if (!apiKey) throw new Error('Skriv in den befintliga Google API-nyckeln från Stadslass 2.0.');
      const nextSettings = {
        schemaVersion: googleService.SCHEMA_VERSION,
        apiKey,
        updatedAt: new Date().toISOString()
      };
      if (!persistGoogleSettings(nextSettings)) return;
      showStatus('google-service-status', 'Google API-nyckeln är sparad lokalt och visas nu maskerad. Inget Google-anrop gjordes.');
    } catch (error) {
      showStatus('google-service-status', error && error.message ? error.message : 'Google API-nyckeln kunde inte sparas.', true);
    }
  }

  function clearGoogleSettings() {
    const nextSettings = {
      schemaVersion: googleService.SCHEMA_VERSION,
      apiKey: '',
      updatedAt: new Date().toISOString()
    };
    if (!persistGoogleSettings(nextSettings)) return;
    showStatus('google-service-status', 'Den lokalt sparade Google API-nyckeln är borttagen. Platser kan fortfarande sparas utan geokodning.');
  }

  function loadEditableJobTypeRegistry() {
    const stored = settingsDocument[editableJobTypeApi.SETTINGS_KEY];
    const timestamp = new Date().toISOString();
    try {
      const migration = editableJobTypeApi.migrateAndMergeRegistry(stored, baselineJobTypeItems, timestamp);
      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [editableJobTypeApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = writeSettingsDocument(nextDocument);
        if (!saved) throw new Error(window.StadslassHost.getLastError() || 'Det gemensamma Jobbtypsregistret kunde inte migreras atomiskt.');
        settingsDocument = nextDocument;
        watchdog.step('runtime.registry.editable-job-types.migrated', `${migration.registry.items.length} jobbtyper migrerades och förenades med standarddefinitionerna utan dubbletter.`);
      }
      editableJobTypeApi.validateRegistry(migration.registry);
      editableJobTypeRegistry = migration.registry;
      editableJobTypeRegistryError = '';
      applyEffectiveJobTypeRegistry(migration.registry.items);
      watchdog.step('runtime.registry.editable-job-types.validated', `${migration.registry.items.length} jobbtyper verifierades som appens gemensamma jobbtypskälla.`);
    } catch (error) {
      editableJobTypeRegistry = null;
      editableJobTypeRegistryError = error && error.message ? error.message : 'Jobbtypsregistret kunde inte verifieras.';
      const fallback = editableJobTypeApi.migrateAndMergeRegistry(undefined, baselineJobTypeItems, timestamp).registry;
      applyEffectiveJobTypeRegistry(fallback.items);
      watchdog.step('runtime.registry.editable-job-types.invalid', `${editableJobTypeRegistryError} Sparad registerdata är orörd; standarddefinitionerna används endast som skrivskyddad reserv i minnet.`, 'warning');
    }
  }

  function editableSpecialRoleLabel(role) {
    if (role === 'other-activity') return 'Övrig verksamhet';
    if (role === 'havstang') return 'Havstång';
    if (role === 'machine-transport') return 'Maskintransport';
    return '';
  }

  function resetEditableJobTypeEditor() {
    editingEditableJobTypeId = '';
    byId('job-type-registry-edit-id').value = '';
    byId('job-type-registry-name').value = '';
    byId('job-type-registry-material-code').value = '';
    byId('job-type-registry-special-role').disabled = false;
    byId('job-type-registry-special-role').value = 'none';
    byId('job-type-registry-submit').textContent = 'Lägg till jobbtyp';
    byId('job-type-registry-cancel').hidden = true;
    clearAtaRecipient('jobtype');
    syncAtaForm('jobtype', true);
  }

  function renderEditableJobTypeRegistry() {
    const list = byId('job-type-registry-list');
    list.replaceChildren();
    const disabled = !editableJobTypeRegistry;
    byId('job-type-registry-form').querySelectorAll('input, select, button').forEach((element) => {
      element.disabled = disabled;
    });

    if (disabled) {
      byId('job-type-registry-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editableJobTypeRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('job-type-registry-status', 'Jobbtypsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const items = editableJobTypeRegistry.items.filter((item) => !(systemJobPolicy && systemJobPolicy.isSystem && systemJobPolicy.isSystem(item))).slice().sort((a, b) => a.name.localeCompare(b.name, 'sv-SE'));
    byId('job-type-registry-count').textContent = String(items.length);

    if (items.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Jobbtypsregistret saknar valbara poster.';
      list.appendChild(empty);
      return;
    }

    items.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'registry-card';
      card.dataset.jobTypeRegistryId = item.id;

      const header = document.createElement('div');
      header.className = 'registry-card-header';
      const heading = document.createElement('h4');
      heading.textContent = item.name;
      header.append(heading);

      const metadata = document.createElement('div');
      metadata.className = 'queue-meta';
      const labels = [];
      const special = editableSpecialRoleLabel(item.specialRole);
      if (special) labels.push(`Specialtyp: ${special}`);
      if (item.ataEnabled === true) labels.push('ÄTA-jobb');
      if (item.ataRecipient && item.ataRecipient.email) labels.push(`ÄTA-mottagare: ${item.ataRecipient.name} · ${item.ataRecipient.email}`);
      labels.forEach((label) => {
        const chip = document.createElement('span');
        chip.className = 'meta-chip';
        chip.textContent = label;
        metadata.appendChild(chip);
      });

      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.className = 'secondary-button';
      edit.type = 'button';
      edit.dataset.editJobTypeRegistry = item.id;
      edit.textContent = 'Redigera';
      const remove = document.createElement('button');
      remove.className = 'danger-button';
      remove.type = 'button';
      remove.dataset.removeJobTypeRegistry = item.id;
      remove.textContent = 'Ta bort';
      remove.hidden = /^PL-[0-9]{4}$/.test(item.id);
      actions.append(edit, remove);

      card.appendChild(header);
      if (labels.length > 0) card.appendChild(metadata);
      card.appendChild(actions);
      list.appendChild(card);
    });
  }

  function editableJobTypeFormValue() {
    return {
      name: byId('job-type-registry-name').value,
      materialCode: byId('job-type-registry-material-code').value,
      specialRole: byId('job-type-registry-special-role').value,
      ataEnabled: byId('job-type-registry-ata-enabled').checked,
      ataRecipient: ataRecipientInput('jobtype')
    };
  }

  function persistEditableJobTypeRegistry(nextRegistry) {
    editableJobTypeApi.validateRegistry(nextRegistry);
    const nextDocument = {
      ...settingsDocument,
      [editableJobTypeApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus('job-type-registry-status', window.StadslassHost.getLastError() || 'Jobbtypsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    editableJobTypeRegistry = nextRegistry;
    editableJobTypeRegistryError = '';
    applyEffectiveJobTypeRegistry(nextRegistry.items);
    refreshRuntimeJobTypeSelects();
    refreshQuickChoiceJobTypeSelect();
    refreshPlaceFormsForJobType('');
    refreshPlaceFormsForJobType('active-');
    updateMaterialPanel('');
    updateMaterialPanel('active-');
    watchdog.step('runtime.registry.editable-job-types.saved', `Jobbtypsregistrets revision ${nextRegistry.revision} sparades atomiskt och blev omedelbart appens gemensamma jobbtypskälla.`);
    return true;
  }

  function resolveQuickChoiceAtaConflict(jobTypeId) {
    if (!quickChoiceRegistry) return;
    const affected = quickChoiceRegistry.items.filter((item) => item.jobTypeId === jobTypeId && item.ataNeedsCorrection === true);
    if (affected.length === 0) return;
    const nextItems = quickChoiceRegistry.items.map((item) => item.jobTypeId === jobTypeId
      ? { ...item, ataNeedsCorrection: false, ataLegacyDefault: false, ataDefault: false, ataMigrationV59: true }
      : item);
    const nextRegistry = quickChoiceApi.withItems(quickChoiceRegistry, nextItems, new Date().toISOString());
    persistQuickChoiceRegistry(nextRegistry);
  }

  function saveEditableJobType(event) {
    event.preventDefault();
    if (!editableJobTypeRegistry) {
      showStatus('job-type-registry-status', 'Jobbtypsregistret är skrivskyddat eftersom det inte kunde verifieras.', true);
      return;
    }
    try {
      const timestamp = new Date().toISOString();
      const items = editableJobTypeRegistry.items.slice();
      let nextItems;
      let message;
      if (editingEditableJobTypeId) {
        const current = items.find((item) => item.id === editingEditableJobTypeId);
        if (!current) throw new Error('Jobbtypen som skulle redigeras finns inte längre.');
        const formValue = editableJobTypeFormValue();
        formValue.ataRecipient = ensureAtaRecipientContact(formValue.ataRecipient, 'job-type', 'job-type-registry-status');
        const updated = editableJobTypeApi.updateItem(current, formValue, items, timestamp);
        nextItems = items.map((item) => item.id === current.id ? updated : item);
        message = `${updated.name} har uppdaterats. Det stabila ID:t är oförändrat.`;
      } else {
        const formValue = editableJobTypeFormValue();
        formValue.ataRecipient = ensureAtaRecipientContact(formValue.ataRecipient, 'job-type', 'job-type-registry-status');
        const created = editableJobTypeApi.createItem(formValue, items, timestamp);
        nextItems = items.concat(created);
        message = `${created.name} har lagts till.`;
      }
      const nextRegistry = editableJobTypeApi.withItems(editableJobTypeRegistry, nextItems, timestamp);
      if (!persistEditableJobTypeRegistry(nextRegistry)) return;
      if (editingEditableJobTypeId) resolveQuickChoiceAtaConflict(editingEditableJobTypeId);
      resetEditableJobTypeEditor();
      renderEditableJobTypeRegistry();
      renderEditablePlaceJobTypeChoices();
      showStatus('job-type-registry-status', message);
    } catch (error) {
      showStatus('job-type-registry-status', error && error.message ? error.message : 'Jobbtypen kunde inte sparas.', true);
    }
  }

  function editEditableJobType(id) {
    if (!editableJobTypeRegistry) return;
    const item = editableJobTypeRegistry.items.find((candidate) => candidate.id === id);
    if (!item) {
      showStatus('job-type-registry-status', 'Jobbtypen som skulle redigeras saknas.', true);
      return;
    }
    editingEditableJobTypeId = item.id;
    byId('job-type-registry-edit-id').value = item.id;
    byId('job-type-registry-name').value = item.name;
    byId('job-type-registry-material-code').value = text(item.materialCode);
    byId('job-type-registry-special-role').value = item.specialRole;
    byId('job-type-registry-special-role').disabled = item.defaultDefinition === true;
    byId('job-type-registry-ata-enabled').checked = item.ataEnabled === true;
    writeAtaRecipientInput('jobtype', item.ataRecipient || null);
    renderAtaRecipientContacts('jobtype', item.ataRecipient || null);
    syncAtaForm('jobtype', false);
    byId('job-type-registry-submit').textContent = 'Spara ändringar';
    byId('job-type-registry-cancel').hidden = false;
    showStatus('job-type-registry-status', `Redigerar ${item.name}.`);
    scrollSettingsContentIntoView(byId('job-type-registry-form'));
  }

  function removeEditableJobType(id) {
    if (!editableJobTypeRegistry) return;
    try {
      const items = editableJobTypeRegistry.items.slice();
      const current = items.find((item) => item.id === id);
      if (!current) throw new Error('Jobbtypen som skulle tas bort saknas.');
      const timestamp = new Date().toISOString();
      if (!window.confirm('Ta bort ' + current.name + '? Jobbtypen tas bort och dess kopplingar till Platser, Badplatser och Snabbval rensas. Andra registerposter samt sparade uppdrag och historik behålls.')) return;
      const nextRegistry = editableJobTypeApi.removeFromRegistry(editableJobTypeRegistry, current, timestamp);
      const nextValidJobTypeIds = new Set(Array.from(editableJobTypeIds()).filter((value) => value !== current.id));
      const nextPlaces = editablePlaceRegistry ? editablePlaceApi.withItems(editablePlaceRegistry, editablePlaceRegistry.items.map((item) => ({ ...item, jobTypeFromIds: item.jobTypeFromIds.filter((value) => value !== current.id), jobTypeToIds: item.jobTypeToIds.filter((value) => value !== current.id) })), nextValidJobTypeIds, timestamp) : null;
      const nextBeaches = editableBeachRegistry ? editableBeachApi.withItems(editableBeachRegistry, editableBeachRegistry.items.map((item) => ({ ...item, allowedJobTypeIds: item.allowedJobTypeIds.filter((value) => value !== current.id) })), timestamp) : null;
      const nextQuickChoices = quickChoiceRegistry ? quickChoiceApi.withItems(quickChoiceRegistry, clearQuickChoiceReferences(quickChoiceRegistry.items, '', current.id), timestamp) : null;
      saveRegistryRemoval(nextRegistry, nextPlaces, nextBeaches, nextQuickChoices);
      if (editingEditableJobTypeId === current.id) resetEditableJobTypeEditor();
      renderEditableJobTypeRegistry();
      renderEditablePlaceJobTypeChoices();
      showStatus('job-type-registry-status', current.name + ' och dess kopplingar har tagits bort. Redan sparade uppdrag och historik är oförändrade.');
    } catch (error) {
      showStatus('job-type-registry-status', error && error.message ? error.message : 'Jobbtypen kunde inte tas bort.', true);
    }
  }

  function editableJobTypeIds() {
    return new Set(editableJobTypeRegistry ? editableJobTypeRegistry.items.map((item) => item.id) : []);
  }

  function editableJobTypeName(id) {
    const item = editableJobTypeRegistry && editableJobTypeRegistry.items.find((candidate) => candidate.id === id);
    return item ? item.name : id;
  }

  function loadEditablePlaceRegistry() {
    const stored = settingsDocument[editablePlaceApi.SETTINGS_KEY];
    try {
      const baseNormalPlaces = basePlaceItems.filter((place) => !editableBeachApi.isBeachPlace(place));
      const migration = editablePlaceApi.migrateRegistry(stored, baseNormalPlaces, editableJobTypeIds(), new Date().toISOString());
      editablePlaceApi.validateRegistry(migration.registry, editableJobTypeIds());
      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [editablePlaceApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = writeSettingsDocument(nextDocument);
        if (!saved) throw new Error(window.StadslassHost.getLastError() || 'Platsregistret kunde inte migreras atomiskt.');
        settingsDocument = nextDocument;
        watchdog.step('runtime.registry.editable-places.migrated', `Platsregister schema ${migration.sourceSchemaVersion} migrerades atomiskt till schema ${editablePlaceApi.SCHEMA_VERSION} med integrerad geofence och ${migration.seededCount || 0} fasta platsseedningar.`);
      } else if (!migration.sourceExisted) {
        watchdog.step('runtime.registry.editable-places.validated', 'Platsregistret är giltigt och geofence ligger direkt i platsdata.');
      }
      editablePlaceRegistry = migration.registry;
      editablePlaceRegistryError = '';
      watchdog.step('runtime.registry.editable-places.validated', `${migration.registry.items.length} redigerbara platser verifierades med dold geokodnings- och geofencedata.`);
    } catch (error) {
      editablePlaceRegistry = null;
      editablePlaceRegistryError = error && error.message ? error.message : 'Platsregistret kunde inte verifieras.';
      watchdog.step('runtime.registry.editable-places.invalid', `${editablePlaceRegistryError} Ingen registerdata har ändrats.`, 'warning');
    }
  }

  function checkedRegistryIds(containerId) {
    return Array.from(byId(containerId).querySelectorAll('input[type="checkbox"]:checked'), (input) => input.value);
  }

  function renderEditablePlaceJobTypeChoices(selection = null) {
    const currentSelection = selection || {
      from: checkedRegistryIds('place-registry-job-types-from'),
      to: checkedRegistryIds('place-registry-job-types-to')
    };
    const selectedFrom = new Set(currentSelection.from || []);
    const selectedTo = new Set(currentSelection.to || []);
    const items = editableJobTypeRegistry
      ? editableJobTypeRegistry.items.slice().sort((a, b) => a.name.localeCompare(b.name, 'sv-SE'))
      : [];

    for (const definition of [
      { containerId: 'place-registry-job-types-from', selected: selectedFrom, prefix: 'place-from-' },
      { containerId: 'place-registry-job-types-to', selected: selectedTo, prefix: 'place-to-' }
    ]) {
      const container = byId(definition.containerId);
      container.replaceChildren();
      if (items.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.textContent = editableJobTypeRegistry
          ? 'Inga jobbtyper finns ännu. Tom koppling är tillåten.'
          : 'Jobbtypsregistret kunde inte läsas.';
        container.appendChild(empty);
        continue;
      }
      items.forEach((item) => {
        const label = document.createElement('label');
        label.className = 'choice-row';
        label.htmlFor = `${definition.prefix}${item.id}`;
        const input = document.createElement('input');
        input.id = `${definition.prefix}${item.id}`;
        input.type = 'checkbox';
        input.value = item.id;
        input.checked = definition.selected.has(item.id);
        input.disabled = !editablePlaceRegistry;
        const content = document.createElement('span');
        const name = document.createElement('strong');
        name.textContent = item.name;
        content.appendChild(name);
        label.append(input, content);
        container.appendChild(label);
      });
    }
  }

  function geocodingDisplay(value) {
    const geocoding = googleService.normalizeGeocoding(value);
    if (geocoding.status === 'resolved') {
      return {
        label: 'Koordinater hämtade',
        detail: geocoding.formattedAddress ? `Identifierad plats: ${geocoding.formattedAddress}` : 'Google returnerade giltiga dolda koordinater.',
        isError: false
      };
    }
    if (geocoding.status === 'pending') return { label: 'Väntar på geokodning', detail: 'Koordinater hämtas automatiskt vid Spara.', isError: false };
    if (geocoding.status === 'invalid-input') return { label: 'Adress behöver rättas', detail: geocoding.errorMessage || 'Adress / Plus Code kunde inte användas.', isError: true };
    if (geocoding.status === 'unavailable') return { label: 'Koordinater saknas', detail: geocoding.errorMessage || 'Google eller internet var inte tillgängligt.', isError: true };
    if (geocoding.status === 'failed') return { label: 'Koordinater kunde inte hämtas', detail: geocoding.errorMessage || 'Google kunde inte identifiera platsen.', isError: true };
    return { label: 'Ingen geokodning', detail: 'Spara en Adress / Plus Code för att hämta koordinater automatiskt.', isError: false };
  }

  function renderGeocodingNote(elementId, value) {
    const element = byId(elementId);
    const display = geocodingDisplay(value);
    element.textContent = `${display.label}. ${display.detail}`;
    element.classList.toggle('is-error', display.isError);
  }

  function updateEditablePlaceGeofenceVisibility() {
    const enabled = byId('place-registry-geofence-enabled').checked;
    const type = byId('place-registry-geofence-type').value === 'polygon' ? 'polygon' : 'circle';
    byId('place-registry-geofence-fields').hidden = !enabled;
    byId('place-registry-geofence-enabled').setAttribute('aria-expanded', String(enabled));
    byId('place-registry-circle-fields').hidden = type !== 'circle';
    byId('place-registry-polygon-fields').hidden = type !== 'polygon';
    byId('place-registry-radius').required = enabled && type === 'circle';
    byId('place-registry-polygon-points').required = enabled && type === 'polygon';
    byId('place-registry-tolerance').required = enabled;
  }

  function geofenceFormValue(prefix) {
    const type = byId(`${prefix}-geofence-type`).value === 'polygon' ? 'polygon' : 'circle';
    return {
      enabled: byId(`${prefix}-geofence-enabled`).checked,
      type,
      visualLoadingLock: byId(`${prefix}-loading-lock`).checked,
      visualUnloadingLock: byId(`${prefix}-unloading-lock`).checked,
      radiusMeters: type === 'circle' ? byId(`${prefix}-radius`).value : null,
      polygonPoints: type === 'polygon' ? geofenceService.parsePolygonPoints(byId(`${prefix}-polygon-points`).value) : [],
      toleranceMeters: byId(`${prefix}-tolerance`).value
    };
  }

  function setGeofenceForm(prefix, definition) {
    const value = geofenceService.normalizeDefinition(definition);
    byId(`${prefix}-geofence-enabled`).checked = value.enabled;
    byId(`${prefix}-geofence-type`).value = value.type;
    byId(`${prefix}-loading-lock`).checked = value.visualLoadingLock;
    byId(`${prefix}-unloading-lock`).checked = value.visualUnloadingLock;
    byId(`${prefix}-radius`).value = editablePlaceNumber(value.radiusMeters);
    byId(`${prefix}-polygon-points`).value = geofenceService.formatPolygonPoints(value.polygonPoints);
    byId(`${prefix}-tolerance`).value = value.toleranceMeters === null ? '0' : String(value.toleranceMeters);
  }

  function resetPlaceGeofenceForm() {
    setGeofenceForm('place-registry', { enabled: false, type: 'circle', toleranceMeters: 0 });
  }

  function resetEditablePlaceEditor() {
    editingEditablePlaceId = '';
    byId('place-registry-edit-id').value = '';
    byId('place-registry-name').value = '';
    byId('place-registry-address').value = '';
    renderGeocodingNote('place-registry-geocoding-note', null);
    byId('place-registry-requirements').value = '';
    byId('place-registry-opening-hours').value = '';
    byId('place-registry-return-place').checked = false;
    resetPlaceGeofenceForm();
    byId('place-registry-submit').textContent = 'Lägg till plats';
    byId('place-registry-cancel').hidden = true;
    renderEditablePlaceJobTypeChoices({ from: [], to: [] });
    updateEditablePlaceGeofenceVisibility();
  }

  function editablePlaceLabels(item) {
    const labels = [];
    if (item.canBeReturnPlace) labels.push('Returplats');
    if (item.jobTypeFromIds.length) labels.push(`Från: ${item.jobTypeFromIds.map(editableJobTypeName).join(', ')}`);
    if (item.jobTypeToIds.length) labels.push(`Till: ${item.jobTypeToIds.map(editableJobTypeName).join(', ')}`);
    if (item.geofence.enabled) labels.push(item.geofence.type === 'circle' ? `Geofence: Cirkel ${item.geofence.radiusMeters} m` : `Geofence: Polygon ${item.geofence.polygonPoints.length} punkter`);
    if (item.geofence.visualLoadingLock) labels.push('Lastningslås');
    if (item.geofence.visualUnloadingLock) labels.push('Lossningslås');
    labels.push(geocodingDisplay(item.geocoding).label);
    return labels;
  }

  function renderEditablePlaceRegistry() {
    const list = byId('place-registry-list');
    list.replaceChildren();
    const disabled = !editablePlaceRegistry;
    byId('place-registry-form').querySelectorAll('input, select, textarea, button').forEach((element) => {
      element.disabled = disabled;
    });
    renderEditablePlaceJobTypeChoices();

    if (disabled) {
      byId('place-registry-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editablePlaceRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('place-registry-status', 'Platsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const items = editablePlaceRegistry.items.slice().sort((a, b) => a.name.localeCompare(b.name, 'sv-SE'));
    byId('place-registry-count').textContent = String(items.length);
    if (items.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Platsregistret är tomt. Det är ett giltigt startläge.';
      list.appendChild(empty);
      return;
    }

    items.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'registry-card';
      card.dataset.placeRegistryId = item.id;

      const header = document.createElement('div');
      header.className = 'registry-card-header';
      const heading = document.createElement('h4');
      heading.textContent = item.name;
      header.appendChild(heading);

      if (item.addressOrPlusCode) {
        const address = document.createElement('p');
        address.className = 'queue-route';
        address.textContent = item.addressOrPlusCode;
        card.append(header, address);
      } else {
        card.appendChild(header);
      }
      if (item.geocoding && item.geocoding.status === 'resolved' && item.geocoding.formattedAddress) {
        const identified = document.createElement('p');
        identified.className = 'geocoding-card-detail';
        identified.textContent = `Identifierad plats: ${item.geocoding.formattedAddress}`;
        card.appendChild(identified);
      }

      const metadata = document.createElement('div');
      metadata.className = 'queue-meta';
      const labels = editablePlaceLabels(item);
      if (labels.length === 0) labels.push('Inga listkopplingar');
      labels.forEach((label) => {
        const chip = document.createElement('span');
        chip.className = 'meta-chip';
        chip.textContent = label;
        metadata.appendChild(chip);
      });

      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.className = 'secondary-button';
      edit.type = 'button';
      edit.dataset.editPlaceRegistry = item.id;
      edit.textContent = 'Redigera';
      const remove = document.createElement('button');
      remove.className = 'danger-button';
      remove.type = 'button';
      remove.dataset.removePlaceRegistry = item.id;
      remove.textContent = 'Ta bort';
      actions.append(edit, remove);

      card.append(metadata, actions);
      list.appendChild(card);
    });
  }

  function editablePlaceFormValue() {
    return {
      name: byId('place-registry-name').value,
      addressOrPlusCode: byId('place-registry-address').value,
      placeRequirements: byId('place-registry-requirements').value,
      openingHours: byId('place-registry-opening-hours').value,
      canBeReturnPlace: byId('place-registry-return-place').checked,
      jobTypeFromIds: checkedRegistryIds('place-registry-job-types-from'),
      jobTypeToIds: checkedRegistryIds('place-registry-job-types-to'),
      geofence: geofenceFormValue('place-registry')
    };
  }

  function persistEditablePlaceRegistry(nextRegistry) {
    editablePlaceApi.validateRegistry(nextRegistry, editableJobTypeIds());
    const nextDocument = {
      ...settingsDocument,
      [editablePlaceApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus('place-registry-status', window.StadslassHost.getLastError() || 'Platsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    editablePlaceRegistry = nextRegistry;
    editablePlaceRegistryError = '';
    buildEffectivePlaceRegistry();
    validateRegistries();
    refreshPlaceFormsForJobType('');
    refreshPlaceFormsForJobType('active-');
    populateQuickChoicePlaceOptions();
    renderQuickChoiceRegistry();
    renderQuickChoices();
    updateMaterialPanel('');
    updateMaterialPanel('active-');
    watchdog.step('runtime.registry.editable-places.saved', `Platsregistrets revision ${nextRegistry.revision} sparades atomiskt och platsfiltren uppdaterades utan appomstart.`);
    return true;
  }

  async function applyPlaceGeocodingResult(itemId, baseMessage) {
    const current = editablePlaceRegistry && editablePlaceRegistry.items.find((item) => item.id === itemId);
    if (!current || !current.addressOrPlusCode || current.geocoding.status !== 'pending') {
      showStatus('place-registry-status', baseMessage);
      return;
    }
    watchdog.step('runtime.google.geocoding.place.started', `Geokodning startades för plats-ID ${current.id} genom den gemensamma registermetoden utan ny GPS-bevakning.`);
    const outcome = await requestSharedRegistryGeocoding(current, 'place');
    const geocoding = outcome.geocoding;
    const resultMessage = outcome.isError
      ? `${baseMessage} ${outcome.detail} Platsen är sparad och kan rättas eller sparas igen senare.`
      : `${baseMessage} ${outcome.detail}`;
    const isError = outcome.isError;
    const timestamp = new Date().toISOString();
    const items = editablePlaceRegistry.items.slice();
    const latest = items.find((item) => item.id === itemId);
    if (!latest) {
      showStatus('place-registry-status', `${baseMessage} Geokodningsresultatet kunde inte kopplas till platsen.`, true);
      return;
    }
    if (latest.geocoding.status !== 'pending' || latest.geocoding.query !== current.geocoding.query || latest.addressOrPlusCode !== current.addressOrPlusCode) {
      watchdog.step('runtime.google.geocoding.place.stale-result', `${current.id}: ett äldre geokodningsresultat ignorerades eftersom platsen ändrades under anropet.`, 'warning');
      showStatus('place-registry-status', `${baseMessage} Ett äldre geokodningsresultat ignorerades eftersom platsen hade ändrats.`);
      return;
    }
    const validJobTypeIds = editableJobTypeIds();
    const updated = editablePlaceApi.applyGeocoding(latest, geocoding, items, validJobTypeIds, timestamp);
    const nextItems = items.map((item) => item.id === itemId ? updated : item);
    const nextRegistry = editablePlaceApi.withItems(editablePlaceRegistry, nextItems, validJobTypeIds, timestamp);
    if (!persistEditablePlaceRegistry(nextRegistry)) {
      showStatus('place-registry-status', `${baseMessage} Platsen är sparad, men koordinaterna kunde inte sparas. Spara platsen igen senare.`, true);
      return;
    }
    renderEditablePlaceRegistry();
    showStatus('place-registry-status', resultMessage, isError);
  }

  async function saveEditablePlace(event) {
    event.preventDefault();
    if (!editablePlaceRegistry) {
      showStatus('place-registry-status', 'Platsregistret är skrivskyddat eftersom det inte kunde verifieras.', true);
      return;
    }
    const submitButton = byId('place-registry-submit');
    submitButton.disabled = true;
    try {
      const timestamp = new Date().toISOString();
      const items = editablePlaceRegistry.items.slice();
      const validJobTypeIds = editableJobTypeIds();
      let nextItems;
      let savedItem;
      let message;
      if (editingEditablePlaceId) {
        const current = items.find((item) => item.id === editingEditablePlaceId);
        if (!current) throw new Error('Platsen som skulle redigeras finns inte längre.');
        savedItem = editablePlaceApi.updateItem(current, editablePlaceFormValue(), items, validJobTypeIds, timestamp);
        nextItems = items.map((item) => item.id === current.id ? savedItem : item);
        message = `${savedItem.name} har uppdaterats. Det stabila ID:t är oförändrat.`;
      } else {
        savedItem = editablePlaceApi.createItem(editablePlaceFormValue(), items, validJobTypeIds, timestamp);
        nextItems = items.concat(savedItem);
        message = `${savedItem.name} har lagts till.`;
      }
      const nextRegistry = editablePlaceApi.withItems(editablePlaceRegistry, nextItems, validJobTypeIds, timestamp);
      if (!persistEditablePlaceRegistry(nextRegistry)) return;
      const savedItemId = savedItem.id;
      resetEditablePlaceEditor();
      renderEditablePlaceRegistry();
      if (savedItem.geocoding.status === 'pending' && savedItem.addressOrPlusCode) {
        showStatus('place-registry-status', `${message} Koordinater hämtas från Google…`);
        await applyPlaceGeocodingResult(savedItemId, message);
      } else {
        showStatus('place-registry-status', message);
      }
    } catch (error) {
      showStatus('place-registry-status', error && error.message ? error.message : 'Platsen kunde inte sparas.', true);
    } finally {
      submitButton.disabled = !editablePlaceRegistry;
    }
  }

  function editablePlaceNumber(value) {
    return value === null || typeof value === 'undefined' ? '' : String(value);
  }

  function editEditablePlace(id) {
    if (!editablePlaceRegistry) return;
    const item = editablePlaceRegistry.items.find((candidate) => candidate.id === id);
    if (!item) {
      showStatus('place-registry-status', 'Platsen som skulle redigeras saknas.', true);
      return;
    }
    editingEditablePlaceId = item.id;
    byId('place-registry-edit-id').value = item.id;
    byId('place-registry-name').value = item.name;
    byId('place-registry-address').value = item.addressOrPlusCode;
    renderGeocodingNote('place-registry-geocoding-note', item.geocoding);
    byId('place-registry-requirements').value = item.placeRequirements;
    byId('place-registry-opening-hours').value = item.openingHours;
    byId('place-registry-return-place').checked = item.canBeReturnPlace;
    setGeofenceForm('place-registry', item.geofence);
    renderEditablePlaceJobTypeChoices({ from: item.jobTypeFromIds, to: item.jobTypeToIds });
    updateEditablePlaceGeofenceVisibility();
    byId('place-registry-submit').textContent = 'Spara ändringar';
    byId('place-registry-cancel').hidden = false;
    showStatus('place-registry-status', `Redigerar ${item.name}.`);
    scrollSettingsContentIntoView(byId('place-registry-form'));
  }


  function saveRegistryRemoval(nextJobTypes, nextPlaces, nextBeaches, nextQuickChoices) {
    const nextDocument = {
      ...settingsDocument,
      ...(nextJobTypes ? { [editableJobTypeApi.SETTINGS_KEY]: nextJobTypes } : {}),
      ...(nextPlaces ? { [editablePlaceApi.SETTINGS_KEY]: nextPlaces } : {}),
      ...(nextBeaches ? { [editableBeachApi.SETTINGS_KEY]: nextBeaches } : {}),
      ...(nextQuickChoices ? { [quickChoiceApi.SETTINGS_KEY]: nextQuickChoices } : {}),
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    if (!writeSettingsDocument(nextDocument)) throw new Error(window.StadslassHost.getLastError() || 'Registerändringen kunde inte sparas.');
    settingsDocument = nextDocument;
    if (nextJobTypes) editableJobTypeRegistry = nextJobTypes;
    if (nextPlaces) editablePlaceRegistry = nextPlaces;
    if (nextBeaches) editableBeachRegistry = nextBeaches;
    if (nextQuickChoices) quickChoiceRegistry = nextQuickChoices;
    buildEffectivePlaceRegistry(); validateRegistries(); refreshPlaceFormsForJobType(''); refreshPlaceFormsForJobType('active-');
  }
  function clearQuickChoiceReferences(items, placeId = '', jobTypeId = '') {
    return items.map((item) => {
      const next = { ...item };
      if (placeId && next.fromPlaceId === placeId) next.fromPlaceId = '';
      if (placeId && next.toPlaceId === placeId) next.toPlaceId = '';
      if (placeId && next.returnPlaceId === placeId) next.returnPlaceId = '';
      if (jobTypeId && next.jobTypeId === jobTypeId) { next.jobTypeId = ''; next.jobTypeName = ''; }
      return next;
    });
  }
  function removeEditablePlace(id) {
    if (!editablePlaceRegistry) return;
    try {
      const items = editablePlaceRegistry.items.slice();
      const current = items.find((item) => item.id === id);
      if (!current) throw new Error('Platsen som skulle tas bort saknas.');
      if (!window.confirm('Ta bort ' + current.name + '? Platsen och dess geofence tas bort. Kopplingar från Jobbtyper och Snabbval rensas. Andra registerposter samt sparade uppdrag och historik behålls.')) return;
      const timestamp = new Date().toISOString();
      const validJobTypeIds = editableJobTypeIds();
      const nextRegistry = editablePlaceApi.removeFromRegistry(editablePlaceRegistry, current, validJobTypeIds, timestamp);
      const nextJobTypes = editableJobTypeRegistry ? editableJobTypeApi.withItems(editableJobTypeRegistry, editableJobTypeRegistry.items.map((item) => ({ ...item, ...(item.defaultDestinationPlaceId === current.id ? { defaultDestinationPlaceId: '' } : {}) })), timestamp) : null;
      const nextQuickChoices = quickChoiceRegistry ? quickChoiceApi.withItems(quickChoiceRegistry, clearQuickChoiceReferences(quickChoiceRegistry.items, current.id), timestamp) : null;
      saveRegistryRemoval(nextJobTypes, nextRegistry, null, nextQuickChoices);
      if (editingEditablePlaceId === current.id) resetEditablePlaceEditor();
      renderEditablePlaceRegistry();
      showStatus('place-registry-status', current.name + ' och dess kopplingar har tagits bort. Redan sparade uppdrag och historik är oförändrade.');
    } catch (error) {
      showStatus('place-registry-status', error && error.message ? error.message : 'Platsen kunde inte tas bort.', true);
    }
  }

  function loadEditableBeachRegistry() {
    const stored = settingsDocument[editableBeachApi.SETTINGS_KEY];
    const baseBeaches = basePlaceItems.filter((place) => editableBeachApi.isBeachPlace(place));
    editableBeachRegistryReadOnly = false;
    try {
      if (stored && Number(stored.schemaVersion) === 1) {
        watchdog.step('runtime.registry.editable-beaches.legacy-detected', 'Badplatsregister schema 1 upptäcktes och förbereds för atomisk migrering.');
      }
      const migration = editableBeachApi.migrateRegistry(stored, baseBeaches, new Date().toISOString());
      watchdog.step('runtime.registry.editable-beaches.migration-candidate', `Migreringskandidat skapades med ${migration.registry.items.length} poster.`);
      editableBeachApi.validateRegistry(migration.registry);
      watchdog.step('runtime.registry.editable-beaches.migration-validated', 'Migreringskandidaten verifierades utan skrivning.');

      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [editableBeachApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = writeSettingsDocument(nextDocument);
        if (saved) {
          settingsDocument = nextDocument;
          watchdog.step('runtime.registry.editable-beaches.migrated', `Badplatsregister schema ${migration.sourceSchemaVersion} migrerades atomiskt till schema ${editableBeachApi.SCHEMA_VERSION}.`);
        } else {
          editableBeachRegistryReadOnly = true;
          editableBeachRegistryError = window.StadslassHost.getLastError() || 'Migreringen kunde inte sparas atomiskt.';
          watchdog.step('runtime.registry.editable-beaches.migration-pending', `${editableBeachRegistryError} Äldre data är orörd; verifierad kandidat används skrivskyddat i minnet.`, 'warning');
        }
      } else {
        watchdog.step('runtime.registry.editable-beaches.migration-not-needed', 'Badplatsregistret använder redan aktuellt schema och behöver inte skrivas om.');
      }

      migration.conflicts.forEach((conflict) => {
        watchdog.step('runtime.registry.editable-beaches.conflict', `${conflict.name}: äldre ID ${conflict.legacyId} bevaras dolt och pekar mot ${conflict.canonicalId}.`, 'warning');
      });
      if (migration.seededCount > 0) {
        watchdog.step('runtime.registry.editable-beaches.seeded', `${migration.seededCount} fasta badplatser infördes i det redigerbara registerlagret.`);
      }
      editableBeachRegistry = migration.registry;
      if (!editableBeachRegistryReadOnly) editableBeachRegistryError = '';
      const visible = migration.registry.items.filter((item) => item.hidden !== true);
      watchdog.step('runtime.registry.editable-beaches.validated', `${visible.length} synliga badplatser verifierades i registerschema ${editableBeachApi.SCHEMA_VERSION}.`);
    } catch (error) {
      editableBeachRegistry = null;
      editableBeachRegistryReadOnly = true;
      editableBeachRegistryError = error && error.message ? error.message : 'Badplatsregistret kunde inte verifieras.';
      watchdog.step('runtime.registry.editable-beaches.invalid', `${editableBeachRegistryError} Ingen registerdata har ändrats.`, 'warning');
    }
  }

  function buildEffectivePlaceRegistry() {
    if (!editablePlaceRegistry || !editableBeachRegistry) throw new Error('Den effektiva platslistan kan inte skapas utan verifierade platsregister.');
    const normalPlaces = editablePlaceApi.buildEffectivePlaces(editablePlaceRegistry);
    const effective = editableBeachApi.buildEffectivePlaces(normalPlaces, editableBeachRegistry);
    const fixedCount = effective.filter((item) => item.category !== 'badplats').length;
    const activeBeachCount = effective.filter((item) => item.category === 'badplats' && item.active !== false && item.hidden !== true).length;
    const inactiveBeachCount = effective.filter((item) => item.category === 'badplats' && item.active === false && item.hidden !== true).length;
    const hiddenBeachCount = effective.filter((item) => item.category === 'badplats' && item.hidden === true).length;
    watchdog.step('runtime.registry.effective-places.created', `${fixedCount} vanliga platser och ${activeBeachCount} aktiva badplatser skapades med integrerad geofencedata.`);
    if (hiddenBeachCount > 0) watchdog.step('runtime.registry.effective-places.legacy-aliases', `${hiddenBeachCount} äldre badplats-ID:n bevaras dolt för bakåtkompatibilitet.`);
    if (!placeModelInitialized) {
      jobModel.initializePlaces(effective);
      placeModelInitialized = true;
    } else {
      jobModel.replacePlaces(effective);
    }
    placeItems = jobModel.getPlaceItems();
    watchdog.step('runtime.registry.job-model.initialized', `${placeItems.length} effektiva platser kopplades till uppdragsmodellen; senare registerändringar kan ersätta samma runtime-lista utan omstart.`);
    if (new Set(placeItems.map((item) => item.id)).size !== placeItems.length) throw new Error('Den effektiva platslistan innehåller dubbla stabila ID:n.');
    watchdog.step('runtime.registry.seaweed-truth.validated', 'Havstångsregelsanningen verifierades mot kategori badplats, beach-roll och stabila plats-ID:n.');
  }

  function editableBeachNumber(value) {
    if (value === null || typeof value === 'undefined' || (typeof value === 'string' && !value.trim())) return '';
    return Number.isFinite(Number(value)) ? String(Number(value)) : '';
  }

  function updateEditableBeachGeofenceVisibility() {
    const enabled = byId('beach-registry-geofence-enabled').checked;
    const type = byId('beach-registry-geofence-type').value === 'polygon' ? 'polygon' : 'circle';
    byId('beach-registry-geofence-fields').hidden = !enabled;
    byId('beach-registry-geofence-enabled').setAttribute('aria-expanded', String(enabled));
    byId('beach-registry-circle-fields').hidden = type !== 'circle';
    byId('beach-registry-polygon-fields').hidden = type !== 'polygon';
    byId('beach-registry-radius').required = enabled && type === 'circle';
    byId('beach-registry-polygon-points').required = enabled && type === 'polygon';
    byId('beach-registry-tolerance').required = enabled;
    byId('beach-registry-save-geofence').disabled = !editableBeachRegistry || !editingEditableBeachId;
  }

  function resetBeachGeofenceForm() {
    setGeofenceForm('beach-registry', { enabled: false, type: 'circle', toleranceMeters: 0 });
  }

  function resetEditableBeachEditor() {
    editingEditableBeachId = '';
    byId('beach-registry-edit-id').value = '';
    byId('beach-registry-name').value = '';
    byId('beach-registry-address').value = '';
    renderGeocodingNote('beach-registry-geocoding-note', null);
    resetBeachGeofenceForm();
    byId('beach-registry-submit').textContent = 'Lägg till badplats';
    byId('beach-registry-cancel').hidden = true;
    updateEditableBeachGeofenceVisibility();
  }

  function renderEditableBeachRegistry() {
    const list = byId('beach-registry-list');
    list.replaceChildren();
    const disabled = !editableBeachRegistry || editableBeachRegistryReadOnly;
    byId('beach-registry-form').querySelectorAll('input, select, textarea, button').forEach((element) => {
      element.disabled = disabled;
    });
    if (!editableBeachRegistry) {
      byId('beach-registry-active-count').textContent = '–';
      byId('beach-registry-inactive-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editableBeachRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('beach-registry-status', 'Badplatsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const items = editableBeachRegistry.items
      .filter((item) => item.hidden !== true)
      .slice()
      .sort((a, b) => {
        if (a.active !== b.active) return a.active ? -1 : 1;
        return a.name.localeCompare(b.name, 'sv-SE');
      });
    const activeCount = items.filter((item) => item.active !== false).length;
    const inactiveCount = items.length - activeCount;
    byId('beach-registry-active-count').textContent = String(activeCount);
    byId('beach-registry-inactive-count').textContent = String(inactiveCount);

    if (editableBeachRegistryReadOnly) {
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editableBeachRegistryError} Badplatserna visas, men kan inte ändras just nu.`;
      list.appendChild(error);
    }

    items.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'registry-card';
      if (item.active === false) card.classList.add('is-inactive');
      card.dataset.beachRegistryId = item.id;

      const header = document.createElement('div');
      header.className = 'registry-card-header';
      const heading = document.createElement('h4');
      heading.textContent = item.name;
      const stateChip = document.createElement('span');
      stateChip.className = `meta-chip${item.active === false ? ' future' : ''}`;
      stateChip.textContent = item.active === false ? 'Inaktiv' : 'Aktiv';
      header.append(heading, stateChip);

      const details = document.createElement('dl');
      details.className = 'registry-detail-list';
      const beachGeocoding = geocodingDisplay(item.geocoding);
      const detailRows = [
        ['Adress / Plus Code', item.addressOrPlusCode || 'Saknas'],
        ['Geokodning', beachGeocoding.label],
        ...(item.geocoding && item.geocoding.status === 'resolved' && item.geocoding.formattedAddress
          ? [['Identifierad plats', item.geocoding.formattedAddress]]
          : []),
        ['Geofence', item.geofence.enabled ? (item.geofence.type === 'circle' ? `Cirkel ${item.geofence.radiusMeters} m` : `Polygon ${item.geofence.polygonPoints.length} punkter`) : 'Avstängd'],
        ['Tolerans', item.geofence.toleranceMeters === null ? 'Ej angiven' : `${item.geofence.toleranceMeters} m`],
        ...(item.geofence.visualLoadingLock ? [['Lastningslås', 'Ja']] : []),
        ...(item.geofence.visualUnloadingLock ? [['Lossningslås', 'Ja']] : []),
        ['Tekniskt ID', item.id]
      ];
      detailRows.forEach(([label, value]) => {
        const wrapper = document.createElement('div');
        const term = document.createElement('dt');
        term.textContent = label;
        const description = document.createElement('dd');
        description.textContent = value;
        wrapper.append(term, description);
        details.appendChild(wrapper);
      });

      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.className = 'secondary-button';
      edit.type = 'button';
      edit.dataset.editBeachRegistry = item.id;
      edit.textContent = 'Redigera';
      const toggle = document.createElement('button');
      toggle.className = item.active === false ? 'secondary-button' : 'danger-button';
      toggle.type = 'button';
      toggle.dataset.toggleBeachRegistry = item.id;
      toggle.textContent = item.active === false ? 'Återaktivera' : 'Inaktivera';
      const remove = document.createElement('button');
      remove.className = 'danger-button';
      remove.type = 'button';
      remove.dataset.removeBeachRegistry = item.id;
      remove.textContent = 'Ta bort';
      actions.append(edit, toggle, remove);
      card.append(header, details, actions);
      list.appendChild(card);
    });
  }

  function persistEditableBeachRegistry(nextRegistry) {
    if (editableBeachRegistryReadOnly) {
      showStatus('beach-registry-status', 'Badplatsregistret kan inte ändras just nu.', true);
      return false;
    }
    editableBeachApi.validateRegistry(nextRegistry);
    const nextDocument = {
      ...settingsDocument,
      [editableBeachApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus('beach-registry-status', window.StadslassHost.getLastError() || 'Badplatsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    editableBeachRegistry = nextRegistry;
    editableBeachRegistryError = '';
    watchdog.step('runtime.registry.editable-beaches.saved', `Badplatsregistrets revision ${nextRegistry.revision} sparades atomiskt i inställningslagret.`);
    return true;
  }

  function editableBeachFormValue() {
    return {
      name: byId('beach-registry-name').value,
      addressOrPlusCode: byId('beach-registry-address').value,
      geofence: geofenceFormValue('beach-registry')
    };
  }

  async function applyBeachGeocodingResult(itemId, baseMessage) {
    const current = editableBeachRegistry && editableBeachRegistry.items.find((item) => item.id === itemId);
    if (!current || !current.addressOrPlusCode || current.geocoding.status !== 'pending') {
      showStatus('beach-registry-status', `${baseMessage} Nya platsval använder ändringen nästa gång appen startas.`);
      return;
    }
    watchdog.step('runtime.google.geocoding.beach.started', `Geokodning startades för badplats-ID ${current.id} genom den gemensamma registermetoden utan ny GPS-bevakning.`);
    const outcome = await requestSharedRegistryGeocoding(current, 'beach');
    const geocoding = outcome.geocoding;
    const resultMessage = outcome.isError
      ? `${baseMessage} ${outcome.detail} Badplatsen är sparad och kan rättas eller sparas igen senare.`
      : `${baseMessage} ${outcome.detail} Nya platsval använder ändringen nästa gång appen startas.`;
    const isError = outcome.isError;
    const timestamp = new Date().toISOString();
    const items = editableBeachRegistry.items.slice();
    const latest = items.find((item) => item.id === itemId);
    if (!latest) {
      showStatus('beach-registry-status', `${baseMessage} Geokodningsresultatet kunde inte kopplas till badplatsen.`, true);
      return;
    }
    if (latest.geocoding.status !== 'pending' || latest.geocoding.query !== current.geocoding.query || latest.addressOrPlusCode !== current.addressOrPlusCode) {
      watchdog.step('runtime.google.geocoding.beach.stale-result', `${current.id}: ett äldre geokodningsresultat ignorerades eftersom badplatsen ändrades under anropet.`, 'warning');
      showStatus('beach-registry-status', `${baseMessage} Ett äldre geokodningsresultat ignorerades eftersom badplatsen hade ändrats.`);
      return;
    }
    const updated = editableBeachApi.applyGeocoding(latest, geocoding, items, timestamp);
    const nextItems = items.map((item) => item.id === itemId ? updated : item);
    const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, nextItems, timestamp);
    if (!persistEditableBeachRegistry(nextRegistry)) {
      showStatus('beach-registry-status', `${baseMessage} Badplatsen är sparad, men koordinaterna kunde inte sparas. Spara badplatsen igen senare.`, true);
      return;
    }
    renderEditableBeachRegistry();
    showStatus('beach-registry-status', resultMessage, isError);
  }

  async function saveEditableBeach(event) {
    event.preventDefault();
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) {
      showStatus('beach-registry-status', 'Badplatsregistret är skrivskyddat eftersom det inte kunde verifieras eller sparas.', true);
      return;
    }
    const submitButton = byId('beach-registry-submit');
    submitButton.disabled = true;
    try {
      const items = editableBeachRegistry.items.slice();
      const timestamp = new Date().toISOString();
      let nextItems;
      let savedItem;
      let message;
      if (editingEditableBeachId) {
        const current = items.find((item) => item.id === editingEditableBeachId);
        if (!current) throw new Error('Badplatsen som skulle redigeras saknas.');
        savedItem = editableBeachApi.updateItem(current, editableBeachFormValue(), items, timestamp);
        nextItems = items.map((item) => item.id === current.id ? savedItem : item);
        message = `${savedItem.name} har uppdaterats.`;
      } else {
        savedItem = editableBeachApi.createItem(editableBeachFormValue(), items, timestamp);
        nextItems = items.concat(savedItem);
        message = `${savedItem.name} har lagts till.`;
      }
      const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, nextItems, timestamp);
      if (!persistEditableBeachRegistry(nextRegistry)) return;
      const savedItemId = savedItem.id;
      resetEditableBeachEditor();
      renderEditableBeachRegistry();
      if (savedItem.geocoding.status === 'pending' && savedItem.addressOrPlusCode) {
        showStatus('beach-registry-status', `${message} Koordinater hämtas från Google…`);
        await applyBeachGeocodingResult(savedItemId, message);
      } else {
        showStatus('beach-registry-status', `${message} Nya platsval använder ändringen nästa gång appen startas.`);
      }
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Badplatsen kunde inte sparas.', true);
    } finally {
      submitButton.disabled = !editableBeachRegistry || editableBeachRegistryReadOnly;
    }
  }

  function editEditableBeach(id) {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) return;
    const item = editableBeachRegistry.items.find((candidate) => candidate.id === id && candidate.hidden !== true);
    if (!item) {
      showStatus('beach-registry-status', 'Badplatsen som skulle redigeras saknas.', true);
      return;
    }
    editingEditableBeachId = item.id;
    byId('beach-registry-edit-id').value = item.id;
    byId('beach-registry-name').value = item.name;
    byId('beach-registry-address').value = item.addressOrPlusCode || '';
    renderGeocodingNote('beach-registry-geocoding-note', item.geocoding);
    setGeofenceForm('beach-registry', item.geofence);
    updateEditableBeachGeofenceVisibility();
    byId('beach-registry-submit').textContent = 'Spara ändringar';
    byId('beach-registry-cancel').hidden = false;
    showStatus('beach-registry-status', `Redigerar ${item.name}.`);
    scrollSettingsContentIntoView(byId('beach-registry-form'));
  }

  function saveEditableBeachGeofence() {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly || !editingEditableBeachId) {
      showStatus('beach-registry-status', 'Välj Redigera på en befintlig badplats innan geofence sparas separat.', true);
      return;
    }
    try {
      const items = editableBeachRegistry.items.slice();
      const current = items.find((item) => item.id === editingEditableBeachId);
      if (!current) throw new Error('Badplatsen som skulle få geofence saknas.');
      const timestamp = new Date().toISOString();
      const updated = editableBeachApi.updateGeofence(current, geofenceFormValue('beach-registry'), items, timestamp);
      const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, items.map((item) => item.id === current.id ? updated : item), timestamp);
      if (!persistEditableBeachRegistry(nextRegistry)) return;
      renderEditableBeachRegistry();
      editEditableBeach(updated.id);
      showStatus('beach-registry-status', `${updated.name}: geofence är sparat.`);
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Geofence kunde inte sparas.', true);
    }
  }

  function toggleEditableBeach(id) {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) return;
    try {
      const items = editableBeachRegistry.items.slice();
      const current = items.find((item) => item.id === id && item.hidden !== true);
      if (!current) throw new Error('Badplatsen som skulle ändras saknas.');
      const timestamp = new Date().toISOString();
      const updated = editableBeachApi.setActive(current, current.active === false, items, timestamp);
      const nextItems = items.map((item) => item.id === current.id ? updated : item);
      const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, nextItems, timestamp);
      if (!persistEditableBeachRegistry(nextRegistry)) return;
      if (editingEditableBeachId === current.id) resetEditableBeachEditor();
      renderEditableBeachRegistry();
      showStatus('beach-registry-status', `${updated.name} är nu ${updated.active ? 'aktiv' : 'inaktiv'}. Nya platsval använder ändringen nästa gång appen startas.`);
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Badplatsens status kunde inte ändras.', true);
    }
  }
  function removeEditableBeach(id) {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) return;
    try {
      const current = editableBeachRegistry.items.find((item) => item.id === id && item.hidden !== true);
      if (!current) throw new Error('Badplatsen som skulle tas bort saknas.');
      if (!window.confirm('Ta bort ' + current.name + '? Badplatsen och dess geofence tas bort. Kopplingar från Jobbtyper och Snabbval rensas. Andra registerposter samt sparade uppdrag och historik behålls.')) return;
      const timestamp = new Date().toISOString();
      const nextRegistry = editableBeachApi.removeFromRegistry(editableBeachRegistry, current, timestamp);
      const nextJobTypes = editableJobTypeRegistry ? editableJobTypeApi.withItems(editableJobTypeRegistry, editableJobTypeRegistry.items.map((item) => ({ ...item, ...(item.defaultDestinationPlaceId === current.id ? { defaultDestinationPlaceId: '' } : {}) })), timestamp) : null;
      const nextQuickChoices = quickChoiceRegistry ? quickChoiceApi.withItems(quickChoiceRegistry, clearQuickChoiceReferences(quickChoiceRegistry.items, current.id), timestamp) : null;
      saveRegistryRemoval(nextJobTypes, null, nextRegistry, nextQuickChoices);
      if (editingEditableBeachId === current.id) resetEditableBeachEditor();
      renderEditableBeachRegistry();
      showStatus('beach-registry-status', current.name + ' och dess kopplingar har tagits bort. Redan sparade uppdrag och historik är oförändrade.');
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Badplatsen kunde inte tas bort.', true);
    }
  }


  function effectiveQuickChoiceButtonName(item, status = null) {
    const resolved = status || quickChoiceApi.referenceStatus(item, jobTypeItems, placeItems, isOtherActivityJobType);
    if (item && item.buttonNameCustomized !== true && resolved.jobType && text(resolved.jobType.name)) {
      return text(resolved.jobType.name);
    }
    return text(item && item.buttonName, 'Snabbval');
  }

  function quickChoiceStatus(item) {
    const status = quickChoiceApi.referenceStatus(item, jobTypeItems, placeItems, isOtherActivityJobType);
    const issues = Array.isArray(status.issues) ? status.issues.slice() : [];
    const machineTransport = isMachineTransportJobType(status.jobType);
    // P110: Maskintransport är en generell uppdragsmall. Från och Till väljs
    // först när mallen öppnar Nytt uppdrag och ska därför inte göra snabbvalet
    // ogiltigt.
    if (machineTransport) {
      for (let index = issues.length - 1; index >= 0; index -= 1) {
        if (issues[index] === 'Från-plats saknas eller är inte tillgänglig' || issues[index] === 'Till-plats saknas eller är inte tillgänglig') issues.splice(index, 1);
      }
    }
    if (status.jobType && !status.otherActivity) {
      if (!machineTransport && status.fromPlace && !placeSupportsJobTypeRole(status.fromPlace, status.jobType.id, 'from')) {
        issues.push('Från-platsen är inte kopplad till Jobbtypen under Jobbtyper från');
      }
      if (!machineTransport && status.toPlace && !placeSupportsJobTypeRole(status.toPlace, status.jobType.id, 'destination')) {
        issues.push('Till-platsen är inte kopplad till Jobbtypen under Jobbtyper till');
      }
    }
    return { ...status, machineTransport, valid: issues.length === 0, issues, groupName: machineTransport ? 'Maskintransport' : status.groupName };
  }

  function migrateAtaDefaultsFromV58(registry, timestamp) {
    if (!editableJobTypeRegistry || !registry || !ataRouting) return { registry, jobTypes: editableJobTypeRegistry, changed: false };
    const quickItems = registry.items.map((item) => ({ ...item }));
    const grouped = new Map();
    quickItems.forEach((item) => {
      if (item.ataMigrationV59 === true) return;
      const key = text(item.jobTypeId);
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(item);
    });
    let changed = false;
    let nextTypes = editableJobTypeRegistry.items.map((item) => ({ ...item }));
    nextTypes = nextTypes.map((type) => {
      const group = grouped.get(type.id) || [];
      if (group.length === 0 || (type.ataEnabled === true || type.ataEnabled === false)) return type;
      if (ataRouting.isManualJobType(type)) {
        group.forEach((item) => { item.ataManual = item.ataDefault === true; item.ataMigrationV59 = true; changed = true; });
        return { ...type, ataEnabled: false };
      }
      const values = group.map((item) => item.ataDefault === true);
      const uniform = values.every((value) => value === values[0]);
      if (uniform) {
        group.forEach((item) => { item.ataMigrationV59 = true; changed = true; });
        return { ...type, ataEnabled: values[0] };
      }
      group.forEach((item) => { item.ataNeedsCorrection = true; item.ataLegacyDefault = item.ataDefault === true; item.ataMigrationV59 = true; changed = true; });
      return { ...type, ataEnabled: false };
    });
    // Types without old quick choices get a deliberate ordinary default.
    nextTypes = nextTypes.map((type) => type.ataEnabled === true || type.ataEnabled === false ? type : { ...type, ataEnabled: false });
    if (!changed && JSON.stringify(nextTypes) === JSON.stringify(editableJobTypeRegistry.items)) return { registry, jobTypes: editableJobTypeRegistry, changed: false };
    const nextJobTypes = editableJobTypeApi.withItems(editableJobTypeRegistry, nextTypes, timestamp);
    const nextQuick = quickChoiceApi.withItems(registry, quickItems, timestamp);
    return { registry: nextQuick, jobTypes: nextJobTypes, changed: true };
  }

  function loadQuickChoiceRegistry() {
    const stored = settingsDocument[quickChoiceApi.SETTINGS_KEY];
    try {
      const migration = quickChoiceApi.migrateRegistry(stored, jobTypeItems, new Date().toISOString());
      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [quickChoiceApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = writeSettingsDocument(nextDocument);
        if (!saved) throw new Error(window.StadslassHost.getLastError() || 'Snabbvalsregistret kunde inte migreras atomiskt.');
        settingsDocument = nextDocument;
        watchdog.step('runtime.registry.quick-choices.migrated', `Snabbvalsregistret migrerades till schema ${quickChoiceApi.SCHEMA_VERSION}; ${migration.normalizedJobTypeCount || 0} jobbtypsreferenser normaliserades till stabilt register-ID utan att ändra kö, Aktivt jobb eller Historik.`);
      }
      const ataMigration = migrateAtaDefaultsFromV58(migration.registry, new Date().toISOString());
      if (ataMigration.changed) {
        const nextDocument = { ...settingsDocument, [editableJobTypeApi.SETTINGS_KEY]: ataMigration.jobTypes, [quickChoiceApi.SETTINGS_KEY]: ataMigration.registry, settingsSchemaVersion: 1, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
        if (!writeSettingsDocument(nextDocument)) throw new Error(window.StadslassHost.getLastError() || 'ÄTA-migreringen kunde inte sparas atomiskt.');
        settingsDocument = nextDocument;
        editableJobTypeRegistry = ataMigration.jobTypes;
        applyEffectiveJobTypeRegistry(ataMigration.jobTypes.items);
        migration.registry = ataMigration.registry;
        watchdog.step('runtime.ata.v59.migrated', 'Paket 58:s fria snabbvals-ÄTA migrerades säkert till Jobbtyp eller markerades Behöver rättas utan att befintliga uppdrag ändrades.');
      }
      quickChoiceApi.validateRegistry(migration.registry);
      quickChoiceRegistry = migration.registry;
      quickChoiceRegistryError = '';
      watchdog.step('runtime.registry.quick-choices.validated', `${migration.registry.items.length} snabbval verifierades med stabila registerreferenser.`);
    } catch (error) {
      quickChoiceRegistry = null;
      quickChoiceRegistryError = error && error.message ? error.message : 'Snabbvalsregistret kunde inte verifieras.';
      watchdog.step('runtime.registry.quick-choices.invalid', `${quickChoiceRegistryError} Ingen registerdata har ändrats.`, 'warning');
    }
  }

  function persistQuickChoiceRegistry(nextRegistry) {
    quickChoiceApi.validateRegistry(nextRegistry);
    const nextDocument = {
      ...settingsDocument,
      [quickChoiceApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = writeSettingsDocument(nextDocument);
    if (!saved) {
      showStatus('quick-choice-registry-status', window.StadslassHost.getLastError() || 'Snabbvalsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    quickChoiceRegistry = nextRegistry;
    quickChoiceRegistryError = '';
    watchdog.step('runtime.registry.quick-choices.saved', `Snabbvalsregistrets revision ${nextRegistry.revision} sparades atomiskt i inställningslagret.`);
    renderQuickChoiceRegistry();
    renderQuickChoices();
    return true;
  }

  function populateQuickChoicePlaceOptions() {
    const jobTypeId = byId('quick-choice-registry-job-type').value;
    const jobType = findJobTypeById(jobTypeId);
    const routeEnabled = Boolean(jobType && !isOtherActivityJobType(jobType) && !isMachineTransportJobType(jobType));
    const fromPlaces = routeEnabled ? placesForJobType(jobType.id, 'from') : [];
    const destinationPlaces = routeEnabled ? placesForJobType(jobType.id, 'destination') : [];
    const fromSelect = byId('quick-choice-registry-from');
    const destinationSelect = byId('quick-choice-registry-to');
    const returnSelect = byId('quick-choice-registry-return');
    const previousFrom = fromSelect.value;
    const previousDestination = destinationSelect.value;
    const previousReturn = returnSelect.value;
    populateSelect(fromSelect.id, fromPlaces, !routeEnabled ? 'Välj jobbtyp först' : (fromPlaces.length ? 'Välj Från' : 'Ingen Från-plats kopplad'), 'from');
    populateSelect(destinationSelect.id, destinationPlaces, !routeEnabled ? 'Välj jobbtyp först' : (destinationPlaces.length ? 'Välj Till' : 'Ingen Till-plats kopplad'), 'destination');
    populateSelect(returnSelect.id, returnPlaces(), 'Välj Returplats', 'return');
    fromSelect.disabled = !routeEnabled || fromPlaces.length === 0;
    destinationSelect.disabled = !routeEnabled || destinationPlaces.length === 0;
    if (selectContainsValue(fromSelect, previousFrom)) fromSelect.value = previousFrom;
    if (selectContainsValue(destinationSelect, previousDestination)) destinationSelect.value = previousDestination;
    if (selectContainsValue(returnSelect, previousReturn)) returnSelect.value = previousReturn;
  }

  function syncQuickChoiceFormControls(changedMode = '') {
    const jobType = findJobTypeById(byId('quick-choice-registry-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const routeFields = byId('quick-choice-registry-route-fields');
    const from = byId('quick-choice-registry-from');
    const to = byId('quick-choice-registry-to');
    const returnToggle = byId('quick-choice-registry-return-required');
    const returnWrap = byId('quick-choice-registry-return-wrap');
    const returnPlace = byId('quick-choice-registry-return');
    const multiLoad = byId('quick-choice-registry-multi-load');
    routeFields.hidden = otherActivity || machineTransport;
    from.required = !otherActivity && !machineTransport;
    to.required = !otherActivity && !machineTransport;
    if (otherActivity || machineTransport) {
      from.value = '';
      to.value = '';
      returnToggle.checked = false;
      returnPlace.value = '';
      multiLoad.checked = false;
    }
    if (changedMode === 'return' && returnToggle.checked) multiLoad.checked = false;
    if (changedMode === 'multi' && multiLoad.checked) returnToggle.checked = false;
    returnWrap.hidden = otherActivity || machineTransport || !returnToggle.checked;
    if (returnToggle.checked && !returnPlace.value && from.value) returnPlace.value = from.value;
    const ataToggle = byId('quick-choice-registry-ata-default');
    const ataChoice = ataToggle.closest('.choice-row');
    const manual = ataRouting && ataRouting.isManualJobType(jobType);
    const inherited = ataRouting && ataRouting.jobTypeEnabled(jobType);
    ataChoice.hidden = !manual;
    if (!manual) ataToggle.checked = false;
    byId('quick-choice-registry-ata-from-jobtype').hidden = !inherited;
    byId('quick-choice-registry-ata-recipient-panel').hidden = !(manual ? ataToggle.checked : inherited);
    renderAtaRecipientContacts('quick', ataRecipientInput('quick'));
  }

  function resetQuickChoiceEditor() {
    editingQuickChoiceId = '';
    const form = byId('quick-choice-registry-form');
    form.reset();
    populateSelect('quick-choice-registry-job-type', jobTypeItems, 'Välj Jobbtyp');
    populateQuickChoicePlaceOptions();
    byId('quick-choice-registry-edit-id').value = '';
    byId('quick-choice-registry-button-name').dataset.autoSuggested = 'true';
    byId('quick-choice-registry-submit').textContent = 'Lägg till snabbval';
    byId('quick-choice-registry-cancel').hidden = true;
    syncQuickChoiceFormControls();
  }

  function quickChoiceFormValue() {
    const jobType = findJobTypeById(byId('quick-choice-registry-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const returnRequired = !otherActivity && !machineTransport && byId('quick-choice-registry-return-required').checked;
    return {
      buttonName: byId('quick-choice-registry-button-name').value,
      buttonNameCustomized: byId('quick-choice-registry-button-name').dataset.autoSuggested !== 'true',
      jobTypeId: text(jobType && jobType.id),
      jobTypeName: text(jobType && jobType.name),
      fromPlaceId: otherActivity || machineTransport ? '' : byId('quick-choice-registry-from').value,
      toPlaceId: otherActivity || machineTransport ? '' : byId('quick-choice-registry-to').value,
      returnRequired,
      returnPlaceId: returnRequired ? (byId('quick-choice-registry-return').value || byId('quick-choice-registry-from').value) : '',
      multiLoad: !otherActivity && !machineTransport && !returnRequired && byId('quick-choice-registry-multi-load').checked,
      comment: byId('quick-choice-registry-comment').value,
      ataManual: ataRouting && ataRouting.isManualJobType(jobType) ? byId('quick-choice-registry-ata-default').checked : false,
      ataRecipient: ataRecipientInput('quick')
    };
  }

  function renderQuickChoiceRegistry() {
    const list = byId('quick-choice-registry-list');
    if (!list) return;
    list.replaceChildren();
    const disabled = !quickChoiceRegistry;
    byId('quick-choice-registry-form').querySelectorAll('input, select, textarea, button').forEach((element) => {
      element.disabled = disabled;
    });
    if (disabled) {
      byId('quick-choice-registry-count').textContent = '–';
      byId('quick-choice-registry-invalid-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${quickChoiceRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('quick-choice-registry-status', 'Snabbvalsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const resolved = quickChoiceRegistry.items.map((item) => ({ item, status: quickChoiceStatus(item) }));
    resolved.sort((a, b) => {
      const groupCompare = a.status.groupName.localeCompare(b.status.groupName, 'sv-SE', { sensitivity: 'base' });
      if (groupCompare !== 0) return groupCompare;
      return effectiveQuickChoiceButtonName(a.item, a.status).localeCompare(effectiveQuickChoiceButtonName(b.item, b.status), 'sv-SE', { sensitivity: 'base' });
    });
    byId('quick-choice-registry-count').textContent = String(resolved.length);
    byId('quick-choice-registry-invalid-count').textContent = String(resolved.filter((entry) => !entry.status.valid).length);

    if (resolved.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Snabbvalsregistret är tomt. Lägg till de uppdrag som du använder ofta.';
      list.appendChild(empty);
      return;
    }

    resolved.forEach(({ item, status }) => {
      const card = document.createElement('article');
      card.className = `registry-card${status.valid ? '' : ' is-invalid'}`;
      card.dataset.quickChoiceRegistryId = item.quickChoiceId;
      const heading = document.createElement('h4');
      heading.textContent = effectiveQuickChoiceButtonName(item, status);
      card.appendChild(heading);

      const details = document.createElement('dl');
      details.className = 'registry-detail-list';
      const pairs = [
        ['Jobbtyp', text(status.jobType && status.jobType.name, 'Saknas')],
        ['Från', status.otherActivity ? 'Övrig verksamhet' : (status.machineTransport ? 'Väljs när uppdraget skapas' : text(status.fromPlace && status.fromPlace.name, 'Saknas'))],
        ['Till', status.otherActivity ? 'Ej aktuell' : (status.machineTransport ? 'Väljs när uppdraget skapas' : text(status.toPlace && status.toPlace.name, 'Saknas'))],
        ['Retur', status.machineTransport ? 'Väljs när uppdraget skapas' : (item.returnRequired ? text(status.returnPlace && status.returnPlace.name, 'Saknas') : 'Nej')],
        ['Flerlass', status.machineTransport ? 'Väljs när uppdraget skapas' : (item.multiLoad ? 'Ja' : 'Nej')],
        ['ÄTA', ataRouting && ataRouting.choiceMode(status.jobType, item) ? (ataRouting.isManualJobType(status.jobType) ? 'Ja, manuellt val' : 'Ja, från Jobbtyp') : 'Nej']
      ];
      pairs.forEach(([label, value]) => {
        const row = document.createElement('div');
        const dt = document.createElement('dt');
        const dd = document.createElement('dd');
        dt.textContent = label;
        dd.textContent = value;
        row.append(dt, dd);
        details.appendChild(row);
      });
      card.appendChild(details);
      if (item.comment) {
        const note = document.createElement('p');
        note.className = 'queue-note';
        note.textContent = item.comment;
        card.appendChild(note);
      }
      if (!status.valid) {
        const warning = document.createElement('p');
        warning.className = 'registry-warning';
        warning.textContent = `Behöver rättas: ${status.issues.join('. ')}.`;
        card.appendChild(warning);
      }
      if (item.ataNeedsCorrection === true) {
        const warning = document.createElement('p');
        warning.className = 'registry-warning';
        warning.textContent = 'Behöver rättas: äldre ÄTA-val för samma Jobbtyp var olika. Välj ÄTA-status på Jobbtypen och kontrollera sedan snabbvalet.';
        card.appendChild(warning);
      }
      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.type = 'button';
      edit.className = 'secondary-button';
      edit.dataset.editQuickChoice = item.quickChoiceId;
      edit.textContent = 'Redigera';
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'danger-button';
      remove.dataset.removeQuickChoice = item.quickChoiceId;
      remove.textContent = 'Ta bort';
      actions.append(edit, remove);
      card.appendChild(actions);
      list.appendChild(card);
    });
  }

  function saveQuickChoice(event) {
    event.preventDefault();
    if (!quickChoiceRegistry) {
      showStatus('quick-choice-registry-status', 'Snabbvalsregistret är skrivskyddat eftersom det inte kunde verifieras.', true);
      return;
    }
    try {
      const now = new Date().toISOString();
      const items = quickChoiceRegistry.items.slice();
      const current = editingQuickChoiceId ? items.find((item) => item.quickChoiceId === editingQuickChoiceId) : null;
      if (editingQuickChoiceId && !current) throw new Error('Snabbvalet som skulle redigeras finns inte längre.');
      const formValue = quickChoiceFormValue();
      formValue.ataRecipient = ensureAtaRecipientContact(formValue.ataRecipient, 'quick-choice', 'quick-choice-registry-status');
      const nextItem = current
        ? quickChoiceApi.updateItem(current, formValue, items, now)
        : quickChoiceApi.createItem(formValue, items, now);
      const status = quickChoiceStatus(nextItem);
      if (!status.valid) throw new Error(status.issues.join('. '));
      const nextItems = current ? items.map((item) => item.quickChoiceId === current.quickChoiceId ? nextItem : item) : items.concat(nextItem);
      const nextRegistry = quickChoiceApi.withItems(quickChoiceRegistry, nextItems, now);
      if (!persistQuickChoiceRegistry(nextRegistry)) return;
      const message = current ? `${effectiveQuickChoiceButtonName(nextItem, status)} har uppdaterats.` : `${effectiveQuickChoiceButtonName(nextItem, status)} har lagts till.`;
      resetQuickChoiceEditor();
      showStatus('quick-choice-registry-status', message);
    } catch (error) {
      showStatus('quick-choice-registry-status', error && error.message ? error.message : 'Snabbvalet kunde inte sparas.', true);
    }
  }

  function editQuickChoice(id) {
    if (!quickChoiceRegistry) return;
    const item = quickChoiceRegistry.items.find((candidate) => candidate.quickChoiceId === id);
    if (!item) {
      showStatus('quick-choice-registry-status', 'Snabbvalet som skulle redigeras saknas.', true);
      return;
    }
    const status = quickChoiceStatus(item);
    editingQuickChoiceId = item.quickChoiceId;
    byId('quick-choice-registry-edit-id').value = item.quickChoiceId;
    byId('quick-choice-registry-job-type').value = status.jobType ? status.jobType.id : '';
    populateQuickChoicePlaceOptions();
    byId('quick-choice-registry-button-name').value = effectiveQuickChoiceButtonName(item, status);
    byId('quick-choice-registry-button-name').dataset.autoSuggested = item.buttonNameCustomized === true ? 'false' : 'true';
    byId('quick-choice-registry-from').value = status.fromPlace ? status.fromPlace.id : '';
    byId('quick-choice-registry-to').value = status.toPlace ? status.toPlace.id : '';
    byId('quick-choice-registry-return-required').checked = item.returnRequired === true;
    byId('quick-choice-registry-return').value = status.returnPlace ? status.returnPlace.id : (status.fromPlace ? status.fromPlace.id : '');
    byId('quick-choice-registry-multi-load').checked = item.multiLoad === true;
    byId('quick-choice-registry-comment').value = item.comment;
    byId('quick-choice-registry-ata-default').checked = item.ataManual === true;
    writeAtaRecipientInput('quick', item.ataRecipient || null);
    renderAtaRecipientContacts('quick', item.ataRecipient || null);
    syncQuickChoiceFormControls();
    byId('quick-choice-registry-submit').textContent = 'Spara ändringar';
    byId('quick-choice-registry-cancel').hidden = false;
    byId('quick-choice-registry-card').scrollIntoView({ block: 'start' });
    showStatus('quick-choice-registry-status', status.valid ? 'Ändra uppgifterna och tryck Spara ändringar.' : `Rätta snabbvalet: ${status.issues.join('. ')}.` , !status.valid);
  }

  function removeQuickChoice(id) {
    if (!quickChoiceRegistry) return;
    try {
      const current = quickChoiceRegistry.items.find((item) => item.quickChoiceId === id);
      const nextItems = quickChoiceApi.removeItem(id, quickChoiceRegistry.items);
      const nextRegistry = quickChoiceApi.withItems(quickChoiceRegistry, nextItems, new Date().toISOString());
      if (!persistQuickChoiceRegistry(nextRegistry)) return;
      if (editingQuickChoiceId === id) resetQuickChoiceEditor();
      showStatus('quick-choice-registry-status', `${current ? effectiveQuickChoiceButtonName(current, quickChoiceStatus(current)) : 'Snabbvalet'} har tagits bort. Redan skapade uppdrag är oförändrade.`);
    } catch (error) {
      showStatus('quick-choice-registry-status', error && error.message ? error.message : 'Snabbvalet kunde inte tas bort.', true);
    }
  }

  function renderQuickChoices() {
    const container = byId('quick-choice-groups');
    const quickChoiceCount = byId('quick-choice-count');
    if (!container) return;
    container.replaceChildren();
    clearQuickChoiceFallbackState();
    if (!quickChoiceRegistry) {
      if (quickChoiceCount) quickChoiceCount.textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${quickChoiceRegistryError} Snabbval kan inte användas förrän registret har rättats.`;
      container.appendChild(error);
      return;
    }
    const resolved = quickChoiceRegistry.items.map((item) => ({ item, status: quickChoiceStatus(item) }));
    if (quickChoiceCount) quickChoiceCount.textContent = String(resolved.length);
    if (resolved.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga snabbval är skapade. Öppna Inställningar → Vanliga åtgärder → Snabbval.';
      container.appendChild(empty);
      return;
    }
    const groups = new Map();
    resolved.forEach((entry) => {
      const key = entry.status.groupName;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(entry);
    });
    Array.from(groups.entries())
      .sort((a, b) => a[0].localeCompare(b[0], 'sv-SE', { sensitivity: 'base' }))
      .forEach(([groupName, entries]) => {
        entries.sort((a, b) => effectiveQuickChoiceButtonName(a.item, a.status).localeCompare(effectiveQuickChoiceButtonName(b.item, b.status), 'sv-SE', { sensitivity: 'base' }));
        const section = document.createElement('section');
        section.className = 'quick-choice-group';
        const heading = document.createElement('h3');
        heading.textContent = groupName;
        const grid = document.createElement('div');
        grid.className = 'quick-choice-button-grid';
        entries.forEach(({ item, status }) => {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = `quick-choice-button${status.valid ? '' : ' is-invalid'}`;
          button.dataset.useQuickChoice = item.quickChoiceId;
          button.disabled = !status.valid;
          const name = document.createElement('strong');
          name.textContent = effectiveQuickChoiceButtonName(item, status);
          const detail = document.createElement('small');
          if (!status.valid) {
            detail.textContent = `Behöver rättas: ${status.issues.join(', ')}`;
          } else if (status.otherActivity) {
            detail.textContent = `${item.ataDefault === true ? 'ÄTA · ' : ''}${item.comment || 'Användarens tidsrapportering'}`;
          } else if (status.machineTransport) {
            detail.textContent = 'Välj maskin, Från och Till';
          } else {
            const route = [];
            if (item.ataDefault === true) route.push('ÄTA');
            route.push(`Till ${status.toPlace.name}`);
            if (item.returnRequired) route.push(`retur ${status.returnPlace.name}`);
            if (item.multiLoad) route.push('flerlass');
            detail.textContent = route.join(' · ');
          }
          button.append(name, detail);
          grid.appendChild(button);
        });
        section.append(heading, grid);
        container.appendChild(section);
      });
  }

  function beginQuickChoiceAction(actionKey) {
    const now = Date.now();
    const key = text(actionKey, 'quick-choice-action');
    if (quickChoiceActionInProgress || (key === quickChoiceLastActionKey && now < quickChoiceActionLockedUntil)) return false;
    quickChoiceActionInProgress = true;
    quickChoiceLastActionKey = key;
    quickChoiceActionLockedUntil = now + PRESS_DELAY_MS;
    return true;
  }

  function endQuickChoiceAction() {
    quickChoiceActionInProgress = false;
  }

  function quickChoiceFallbackVisible() {
    const fallback = byId('quick-choice-queue-fallback');
    return Boolean(fallback && !fallback.hidden);
  }

  function clearQuickChoiceFallbackState(options = {}) {
    pendingQuickChoiceFallbackItem = null;
    pendingQuickChoiceFallbackId = '';
    const fallback = byId('quick-choice-queue-fallback');
    if (fallback) fallback.hidden = true;
    if (options.clearStatus && byId('quick-choice-status')) {
      showStatus('quick-choice-status', text(options.message));
    }
  }

  function refreshActiveJobForQuickChoice(options = {}) {
    if (!isVehicleRole()) return true;
    try {
      const nextDocument = readActiveJobDocument();
      const changed = JSON.stringify(nextDocument) !== JSON.stringify(activeJobDocument);
      activeJobDocument = nextDocument;
      activeJobLoaded = true;
      if (changed) {
        syncActiveJobGpsConsumer();
        syncActiveGeofenceContext();
        if (currentView === 'active') renderActiveJob();
      }
      return true;
    } catch (error) {
      activeJobLoaded = false;
      watchdog.step('runtime.quick-choice.active-job-refresh-failed', error && error.message ? error.message : 'Aktivt jobb kunde inte läsas inför Snabbval.', 'warning');
      if (options.showError !== false) {
        showStatus('quick-choice-status', 'Aktivt jobb kunde inte kontrolleras. Lägg i kö kan fortfarande användas utan att ett aktivt uppdrag skrivs över.', true);
      }
      return false;
    }
  }

  function quickChoiceConflictStatus(id) {
    if (!quickChoiceRegistry || !text(id)) return null;
    const item = quickChoiceRegistry.items.find((candidate) => candidate.quickChoiceId === id);
    if (!item) return null;
    const status = quickChoiceStatus(item);
    return status.valid ? { item, status } : null;
  }

  function activeJobBlocksQuickChoice(status) {
    if (!activeJobExists()) return false;
    const mayStartBesideOtherActivity = isOtherActivity(activeJobDocument)
      && !status.otherActivity
      && activeJobDocument.status !== 'completing';
    return !mayStartBesideOtherActivity;
  }

  function invalidateQuickChoiceFallbackForActiveJobChange() {
    const hadConflict = Boolean(pendingQuickChoiceFallbackItem) || quickChoiceFallbackVisible();
    if (!hadConflict) return;
    clearQuickChoiceFallbackState();
    if (currentView === 'quickChoices') {
      showStatus('quick-choice-status', 'Aktivt jobb har ändrats. Tryck på snabbvalet igen för att använda den aktuella statusen.');
    }
  }

  function selectedQuickChoiceMode() {
    const checked = document.querySelector('input[name="quickChoiceMode"]:checked');
    return checked && checked.value === 'direct' ? 'direct' : 'queue';
  }

  function buildQuickChoiceQueueItem(item, status) {
    const now = new Date().toISOString();
    const jobId = createLocalId('job');
    const returnPlace = item.returnRequired ? status.returnPlace : null;
    return normalizeJobRecord({
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: jobId,
      jobId,
      status: 'queued',
      source: isVehicleRole() ? 'manual-vehicle-received' : 'manual-mobile-planning',
      jobTypeId: status.jobType.id,
      jobTypeName: status.jobType.name,
      fromPlaceId: status.otherActivity ? '' : status.fromPlace.id,
      fromPlaceName: status.otherActivity ? '' : status.fromPlace.name,
      destinationPlaceId: status.otherActivity ? '' : status.toPlace.id,
      destinationPlaceName: status.otherActivity ? '' : status.toPlace.name,
      returnPlaceId: returnPlace ? returnPlace.id : '',
      returnPlaceName: returnPlace ? returnPlace.name : '',
      returnRequired: item.returnRequired === true,
      multiLoad: status.otherActivity || item.returnRequired ? false : item.multiLoad === true,
      material: status.otherActivity ? {} : deriveMaterial(status.jobType.id, status.fromPlace.id, status.toPlace.id),
      plannedDate: '',
      plannedTime: '',
      note: item.comment,
      ata: ataRouting.jobAtaSnapshot({
        enabled: ataRouting.choiceMode(status.jobType, item),
        source: ataRouting.isManualJobType(status.jobType) ? 'manual-job-choice' : 'quick-choice',
        quickChoiceId: item.quickChoiceId,
        recipient: ataRouting.recipientPriority(status.jobType, item, 'quick-choice', now),
        timestamp: now
      }),
      createdAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: {
        createdRole: text(hostInfo.role),
        createdRoleLabel: text(hostInfo.roleLabel),
        createdDeviceId: text(hostInfo.deviceId),
        modelVersion: JOB_MODEL_VERSION
      }
    }, 'job');
  }

  function appendQuickChoiceToQueue(queueItem, message) {
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('quick-choice-status', 'Kön måste kunna läsas innan uppdraget kan skapas.', true);
      return false;
    }
    const saved = persistQueue([...queueDocument, queueItem], message);
    if (saved) showStatus('quick-choice-status', message);
    return saved;
  }

  function openMachineTransportQuickChoice(item, status) {
    machineQuickFlowActive = false;
    machineQuickWizard = { jobType: status.jobType, comment: text(item.comment), machine: null, direction: '' };
    const dialog=machineQuickWizardDialog(); if (!dialog) { showStatus('quick-choice-status', 'Maskinguiden kunde inte öppnas.', true); return; }
    dialog.hidden=false; dialog.setAttribute('aria-hidden','false'); document.body.classList.add('modal-open'); machineQuickWizardMachineButtons();
  }

  async function useQuickChoice(id) {
    if (!quickChoiceRegistry || !canUseQueue() || !beginQuickChoiceAction(`use:${text(id)}`)) return;
    try {
      const item = quickChoiceRegistry.items.find((candidate) => candidate.quickChoiceId === id);
      if (!item) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Snabbvalet finns inte längre.', true);
        renderQuickChoices();
        return;
      }
      const status = quickChoiceStatus(item);
      if (!status.valid) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', `Snabbvalet måste rättas i Inställningar: ${status.issues.join('. ')}.`, true);
        renderQuickChoices();
        return;
      }
      if (status.machineTransport) {
        clearQuickChoiceFallbackState();
        openMachineTransportQuickChoice(item, status);
        return;
      }
      const queueItem = buildQuickChoiceQueueItem(item, status);
      const name = effectiveQuickChoiceButtonName(item, status);
      if (selectedQuickChoiceMode() === 'queue') {
        clearQuickChoiceFallbackState();
        appendQuickChoiceToQueue(queueItem, `${name} är skapat som ett vanligt uppdrag och lagt i kön.`);
        return;
      }
      if (!isVehicleRole()) {
        byId('quick-choice-mode-queue').checked = true;
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Starta direkt är endast tillgängligt på 189 / Surfplatta. Välj snabbvalet igen för att lägga det i planeringskön.', true);
        return;
      }
      if (!refreshActiveJobForQuickChoice()) return;
      if (activeJobBlocksQuickChoice(status)) {
        pendingQuickChoiceFallbackItem = queueItem;
        pendingQuickChoiceFallbackId = item.quickChoiceId;
        byId('quick-choice-queue-fallback').hidden = false;
        showStatus('quick-choice-status', 'Ett vanligt aktivt uppdrag pågår. Inget nytt uppdrag har startats och det aktiva uppdraget är oförändrat.', true);
        return;
      }
      clearQuickChoiceFallbackState();
      if (!appendQuickChoiceToQueue(queueItem, `${name} förbereds för direkt start som ett vanligt uppdrag.`)) return;
      if (!refreshActiveJobForQuickChoice()) {
        showStatus('quick-choice-status', `${name} ligger kvar i kön eftersom Aktivt jobb inte kunde kontrolleras på nytt.`, true);
        return;
      }
      if (activeJobBlocksQuickChoice(status)) {
        showStatus('quick-choice-status', `${name} ligger kvar i kön eftersom ett aktivt uppdrag hann ändras före direktstart.`, true);
        return;
      }
      await startQueueItem(queueItem.id);
      if (activeJobLoaded && activeJobExists() && text(activeJobDocument.jobId) === text(queueItem.jobId)) return;
      showStatus('quick-choice-status', `${name} kunde inte startas direkt och ligger kvar i kön.`, true);
    } finally {
      endQuickChoiceAction();
    }
  }

  function queuePendingQuickChoiceFallback() {
    if (!pendingQuickChoiceFallbackItem || !beginQuickChoiceAction('fallback-queue')) return;
    try {
      const pending = pendingQuickChoiceFallbackItem;
      const resolved = quickChoiceConflictStatus(pendingQuickChoiceFallbackId);
      if (!resolved) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Snabbvalet eller dess uppgifter har ändrats. Tryck på snabbvalet igen.', true);
        return;
      }
      const activeReadable = refreshActiveJobForQuickChoice({ showError: false });
      if (activeReadable && !activeJobBlocksQuickChoice(resolved.status)) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Aktivt jobb har ändrats. Tryck på snabbvalet igen för att använda den aktuella statusen.');
        return;
      }
      clearQuickChoiceFallbackState();
      appendQuickChoiceToQueue(pending, 'Uppdraget är skapat som ett vanligt uppdrag och lagt i kön. Det aktiva uppdraget är oförändrat.');
    } finally {
      endQuickChoiceAction();
    }
  }

  function cancelQuickChoiceFallback() {
    clearQuickChoiceFallbackState();
    showStatus('quick-choice-status', 'Åtgärden avbröts. Inget uppdrag skapades.');
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return '';
    }
    const parts = value.split('-').map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return new Intl.DateTimeFormat('sv-SE', { year: 'numeric', month: 'short', day: 'numeric' }).format(date);
  }

  function formatTimestamp(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return 'Saknas';
    }
    return new Intl.DateTimeFormat('sv-SE', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Stockholm'
    }).format(date);
  }

  function createLocalId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(random);
    } else {
      random[0] = Math.floor(Math.random() * 0xffffffff);
      random[1] = Math.floor(Math.random() * 0xffffffff);
    }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function displayQueueItem(item, index) {
    const source = normalizeJobRecord(isPlainObject(item) ? item : {}, `queue-display-${index}`);
    return {
      id: text(source.id, `legacy-${index}`),
      jobId: text(source.jobId, text(source.id, `legacy-${index}`)),
      jobTypeId: text(source.jobTypeId),
      jobType: text(source.jobTypeName, text(source.jobType, 'Uppdrag')),
      otherActivity: isOtherActivity(source),
      fromPlaceId: text(source.fromPlaceId),
      from: text(source.fromPlaceName, text(source.from, 'Från saknas')),
      destinationPlaceId: text(source.destinationPlaceId),
      destination: text(source.destinationPlaceName, text(source.destination, 'Till saknas')),
      returnPlaceId: text(source.returnPlaceId),
      returnPlaceName: text(source.returnPlaceName),
      returnRequired: source.returnRequired === true || Boolean(text(source.returnPlaceId)),
      material: isPlainObject(source.material) ? source.material : {},
      note: text(source.note),
      plannedDate: text(source.plannedDate),
      plannedTime: text(source.plannedTime),
      source: text(source.source),
      multiLoad: source.multiLoad === true,
      machineTransport: isPlainObject(source.machineTransport) ? source.machineTransport : null,
      modelVersion: Number(source.jobModelVersion) || 1,
      pausedFromActive: source.pausedFromActive === true && text(source.status) === 'paused',
      pausedPhase: text(source.phase),
      ataEnabled: ataApi.isEnabled(source),
      ataRecipient: source.ata && source.ata.recipient && source.ata.recipient.email ? source.ata.recipient : null
    };
  }

  function queueMetaChip(label, extraClass = '') {
    const chip = document.createElement('span');
    chip.className = `meta-chip${extraClass ? ` ${extraClass}` : ''}`;
    chip.textContent = label;
    return chip;
  }

  function queueItemIndexById(id) {
    return queueDocument.findIndex((candidate, index) => displayQueueItem(candidate, index).id === id);
  }

  function queueItemById(id) {
    const index = queueItemIndexById(id);
    return index >= 0 ? { index, raw: queueDocument[index], display: displayQueueItem(queueDocument[index], index) } : null;
  }

  function activeJobMatchesQueueItem(id) {
    return activeJobLoaded && activeJobExists() && text(activeJobDocument.sourceQueueItemId) === id;
  }

  function renderQueue() {
    const list = byId('queue-list');
    list.replaceChildren();
    byId('queue-count').textContent = String(queueDocument.length);
    syncQueueIncomingMarker();
    const sendSelected = byId('p138-send-selected');
    if (sendSelected) sendSelected.hidden = !isMobileRole();

    if (queueDocument.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Kön är tom.';
      list.appendChild(empty);
      return;
    }

    const today = localDateKey(new Date());
    queueDocument.forEach((rawItem, index) => {
      const item = displayQueueItem(rawItem, index);
      const card = document.createElement('article');
      card.className = 'queue-card';
      card.dataset.queueId = item.id;

      const header = document.createElement('div');
      header.className = 'queue-card-header';
      const heading = document.createElement('h3');
      heading.textContent = item.jobType;
      if (isMobileRole()) {
        const choice = document.createElement('input'); choice.type = 'checkbox'; choice.dataset.p138Send = item.id;
        choice.checked = !rawItem.p138Transfer;
        choice.disabled = !p150MobileAssignmentCanBeSent(rawItem);
        choice.setAttribute('aria-label', `Välj ${item.jobType} för överföring till 189`); header.appendChild(choice);
      }
      header.appendChild(heading);
      card.appendChild(header);

      const route = document.createElement('p');
      route.className = 'queue-route';
      route.textContent = item.otherActivity ? 'Användarens tidsrapportering' : `${item.from} → ${item.destination}`;
      card.appendChild(route);

      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      if (item.ataEnabled) meta.appendChild(queueMetaChip('ÄTA', 'ata-chip'));
      if (item.machineTransport) {
        meta.appendChild(queueMetaChip(`Maskinflak: ${item.machineTransport.hasMachineBed === true ? 'Ja' : 'Nej'}`, 'model-chip'));
        if (text(item.machineTransport.workshopPlaceName)) meta.appendChild(queueMetaChip(`Vald plats: ${text(item.machineTransport.workshopPlaceName)}`, 'model-chip'));
      }
      if (item.plannedDate) {
        meta.appendChild(queueMetaChip(formatDate(item.plannedDate) || item.plannedDate));
        if (item.plannedDate > today) {
          meta.appendChild(queueMetaChip('Framtida uppdrag', 'future'));
        }
      } else {
        meta.appendChild(queueMetaChip('Datum saknas'));
      }
      if (item.plannedTime) {
        meta.appendChild(queueMetaChip(`Kl. ${item.plannedTime}`));
      }
      if (isMobileRole() && rawItem.p138Transfer) {
        const states = { 'sent-waiting':'Skickat – väntar på 189', accepted:'Skickat och mottaget', 'already-accepted':'Redan mottaget av 189', 'rejected-conflict':'Tidskonflikt – ändra eller radera', 'validation-error':'Valideringsfel', 'conflict-pending':'Tidskonflikt – väntar på beslut på 189' };
        meta.appendChild(queueMetaChip(states[text(rawItem.p138Transfer.status)] || 'Sändnings-/transportfel'));
      }
      if (item.pausedFromActive) meta.appendChild(queueMetaChip(`Pausat · ${phaseLabel(item.pausedPhase)}`, 'paused-chip'));
      if (item.returnRequired) meta.appendChild(queueMetaChip(`Retur: ${item.returnPlaceName || item.from}`));
      if (item.multiLoad) meta.appendChild(queueMetaChip('Flerlass', 'model-chip'));
      const materialText = [text(item.material.code), text(item.material.facilityPlaceName)].filter(Boolean).join(' · ');
      if (materialText) meta.appendChild(queueMetaChip(`Mtrl: ${materialText}`));
      card.appendChild(meta);
      if (item.ataEnabled && item.ataRecipient) {
        const recipientLabel = ataNotificationApi.recipientQueueLabel(item.ataRecipient);
        if (recipientLabel) {
          const recipient = document.createElement('p');
          recipient.className = 'field-help';
          recipient.textContent = recipientLabel;
          card.appendChild(recipient);
        }
      }
      if (item.note) {
        const note = document.createElement('p');
        note.className = 'queue-note';
        note.textContent = item.note;
        card.appendChild(note);
      }


      if (isVehicleRole()) {
        const startButton = document.createElement('button');
        startButton.type = 'button';
        startButton.className = 'primary-button queue-start-button';
        startButton.dataset.startQueueItem = item.id;
        if (activeJobMatchesQueueItem(item.id)) {
          startButton.textContent = 'Slutför flytt till Aktivt jobb';
        } else if (activeJobLoaded && activeJobExists() && !(isOtherActivity(activeJobDocument) && !item.otherActivity && activeJobDocument.status !== 'completing')) {
          startButton.textContent = 'Aktivt jobb pågår';
          startButton.disabled = true;
        } else if (activeJobLoaded && isOtherActivity(activeJobDocument) && !item.otherActivity) {
          startButton.textContent = item.pausedFromActive ? 'Fortsätt – ÖV pausas automatiskt' : 'Starta – ÖV pausas automatiskt';
        } else {
          startButton.textContent = item.pausedFromActive ? 'Fortsätt uppdrag' : 'Starta som Aktivt jobb';
        }
        card.appendChild(startButton);
      }

      const editButton = document.createElement('button');
      editButton.type = 'button';
      editButton.className = 'secondary-button queue-edit-button';
      editButton.dataset.editQueueItem = item.id;
      editButton.textContent = 'Redigera uppdrag';
      card.appendChild(editButton);

      if (pendingQueueDeleteId === item.id) {
        const confirm = document.createElement('div');
        confirm.className = 'inline-confirm confirm-actions';
        const message = document.createElement('p');
        message.textContent = `Ta bort ${item.jobType}: ${item.otherActivity ? 'användarens tidsrapportering' : `${item.from} → ${item.destination}`} från kön? Aktivt jobb och Historik påverkas inte.`;
        const accept = document.createElement('button');
        accept.type = 'button';
        accept.className = 'danger-button is-solid';
        accept.dataset.confirmQueueDelete = item.id;
        accept.textContent = 'Bekräfta borttagning';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.dataset.cancelQueueDelete = item.id;
        cancel.textContent = 'Avbryt';
        confirm.append(message, accept, cancel);
        card.appendChild(confirm);
      } else {
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'danger-button';
        remove.dataset.requestQueueDelete = item.id;
        remove.textContent = 'Ta bort från kö';
        card.appendChild(remove);
      }
      list.appendChild(card);
    });
  }

  function loadQueueIfNeeded() {
    if (!canUseQueue()) {
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (queueLoaded) {
      return;
    }
    try {
      queueDocument = readQueueDocument();
      if (isMobileRole()) {
        const cutoff = Date.now() - 24 * 60 * 60 * 1000;
        const retained = queueDocument.filter((raw) => {
          const transfer = raw && raw.p138Transfer;
          return !(transfer && ['accepted','already-accepted'].includes(text(transfer.status)) && Date.parse(text(transfer.packageReceivedAt)) > 0 && Date.parse(text(transfer.packageReceivedAt)) <= cutoff);
        });
        if (retained.length !== queueDocument.length && window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(retained))) queueDocument = retained;
      }
      queueLoaded = true;
      renderQueue();
      showStatus('queue-load-status', '');
    } catch (error) {
      watchdog.step('runtime.store.queue.invalid', error.message || 'Kön kunde inte läsas.', 'warning');
      showStatus('queue-load-status', error.message || 'Kön kunde inte läsas.', true);
    }
  }

  function persistQueue(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('queue-form-status', window.StadslassHost.getLastError() || 'Kön kunde inte sparas.', true);
      return false;
    }
    queueDocument = nextDocument;
    queueLoaded = true;
    pendingQueueDeleteId = '';
    renderQueue();
    showStatus('queue-form-status', successMessage);
    return true;
  }

  function syncJobModeControls(scope, changedMode = '') {
    const prefix = scope === 'active' ? 'active-job-' : 'job-';
    const otherActivity = isOtherActivityJobType(byId(`${prefix}type`).value);
    const machineTransport = isMachineTransportJobType(byId(`${prefix}type`).value);
    const transportFields = byId(`${prefix}transport-fields`);
    const returnToggle = byId(`${prefix}return-required`);
    const multiToggle = byId(`${prefix}multi-load`);
    const returnWrap = byId(`${prefix}return-wrap`);
    const returnSelect = byId(`${prefix}return`);
    const fromSelect = byId(`${prefix}from`);
    const destinationSelect = byId(`${prefix}destination`);
    transportFields.hidden = otherActivity;
    refreshMachineSelect(scope);
    fromSelect.required = !otherActivity;
    destinationSelect.required = !otherActivity;
    if (otherActivity) {
      fromSelect.value = '';
      destinationSelect.value = '';
      returnSelect.value = '';
      returnToggle.checked = false;
      multiToggle.checked = false;
    }
    if (machineTransport) {
      const materialPanel = byId(`${prefix === 'active-job-' ? 'active-' : 'job-'}material-panel`);
      if (materialPanel) materialPanel.hidden = true;
    }
    if (changedMode === 'return' && returnToggle.checked) multiToggle.checked = false;
    if (changedMode === 'multi' && multiToggle.checked) returnToggle.checked = false;
    returnWrap.hidden = otherActivity || !returnToggle.checked;
    if (returnToggle.checked && !returnSelect.value && fromSelect.value && selectContainsValue(returnSelect, fromSelect.value)) returnSelect.value = fromSelect.value;
    syncTemporaryPlacePanels(scope);
    syncAtaForm(scope, false);
  }

  function resetQueueForm() {
    editingQueueId = '';
    machineQuickFlowActive = false;
    byId('queue-form').reset();
    byId('planned-date').value = p138Today();
    resetTemporaryPlaceForm('queue');
    refreshPlaceFormsForJobType('');
    byId('queue-form-heading').textContent = 'Lägg till planerat uppdrag';
    byId('queue-submit-button').textContent = 'Lägg i planeringskö';
    byId('queue-cancel-edit').hidden = true;
    clearAtaRecipient('queue');
    syncJobModeControls('queue');
    syncAtaForm('queue', true);
    updateMaterialPanel('');
    syncQueueFormVisibility();
  }

  function renderMachineRegistry() {
    const list = byId('machine-registry-list'); if (!list) return;
    const workshop = byId('machine-registry-workshop');
    const previous = workshop.value; workshop.replaceChildren();
    const none = document.createElement('option'); none.value=''; none.textContent='Ingen verkstad'; workshop.appendChild(none);
    jobModel.getPlaceItems().forEach((place) => { const option=document.createElement('option'); option.value=place.id; option.textContent=place.name; workshop.appendChild(option); });
    if (selectContainsValue(workshop, previous)) workshop.value=previous;
    list.replaceChildren();
    normalizedMachineItems().forEach((machine) => {
      const card=document.createElement('article'); card.className='registry-card';
      const heading=document.createElement('h4'); heading.textContent=machine.name; card.appendChild(heading);
      const detail=document.createElement('p'); const place=findPlaceById(machine.workshopPlaceId); detail.textContent=[place ? `Verkstad: ${place.name}` : '', Number.isFinite(machine.weight) ? `Vikt: ${machine.weight} ton` : ''].filter(Boolean).join(' · ') || 'Ingen verkstad eller vikt angiven.'; card.appendChild(detail);
      const edit=document.createElement('button'); edit.type='button'; edit.className='secondary-button'; edit.textContent='Redigera'; edit.dataset.machineEdit=machine.id;
      const remove=document.createElement('button'); remove.type='button'; remove.className='danger-button'; remove.textContent='Ta bort'; remove.dataset.machineRemove=machine.id; card.append(edit,remove); list.appendChild(card);
    });
  }

  function saveMachineRegistry(event) {
    event.preventDefault();
    try {
      const id=text(byId('machine-registry-edit-id').value) || createLocalId('machine');
      const name=text(byId('machine-registry-name').value); if (!name) throw new Error('Skriv ett maskinnamn.');
      const rawWeight=text(byId('machine-registry-weight').value); const weight=rawWeight === '' ? null : Number(rawWeight.replace(',', '.'));
      if (weight !== null && (!Number.isFinite(weight) || weight < 0)) throw new Error('Maskinvikt måste vara ett positivt tal eller tomt.');
      const item={id,name,workshopPlaceId:text(byId('machine-registry-workshop').value),weight,updatedAt:new Date().toISOString()};
      const prior=normalizedMachineItems(); const existing=prior.find((candidate)=>candidate.id===id);
      const machines=existing ? prior.map((candidate)=>candidate.id===id?{...candidate,...item}:candidate) : prior.concat(item);
      const next={...settingsDocument,machines,settingsUpdatedByPackageVersion:PACKAGE_VERSION};
      if (!writeSettingsDocument(next)) throw new Error(window.StadslassHost.getLastError() || 'Maskinregistret kunde inte sparas.');
      settingsDocument=next; byId('machine-registry-form').reset(); byId('machine-registry-edit-id').value=''; byId('machine-registry-cancel').hidden=true; renderMachineRegistry(); refreshMachineSelect('queue'); refreshMachineSelect('active'); showStatus('machine-registry-status', existing?'Maskinen är uppdaterad.':'Maskinen är sparad.');
    } catch(error) { showStatus('machine-registry-status', error.message || 'Maskinen kunde inte sparas.',true); }
  }

  function handleMachineRegistryAction(event) {
    const button=event.target.closest('button'); if (!button) return; const id=text(button.dataset.machineEdit || button.dataset.machineRemove); if (!id) return;
    const machine=normalizedMachineItems().find((item)=>item.id===id); if (!machine) return;
    if (button.dataset.machineRemove) {
      const next={...settingsDocument,machines:normalizedMachineItems().filter((item)=>item.id!==id),settingsUpdatedByPackageVersion:PACKAGE_VERSION};
      if (writeSettingsDocument(next)) { settingsDocument=next; renderMachineRegistry(); refreshMachineSelect('queue'); refreshMachineSelect('active'); showStatus('machine-registry-status','Maskinen är borttagen. Sparade uppdrag behåller sin maskinbild.'); }
      return;
    }
    byId('machine-registry-edit-id').value=machine.id; byId('machine-registry-name').value=machine.name; byId('machine-registry-workshop').value=machine.workshopPlaceId; byId('machine-registry-weight').value=Number.isFinite(machine.weight)?String(machine.weight):''; byId('machine-registry-cancel').hidden=false;
  }

  function editQueueItem(id) {
    if (!canUseQueue() || !queueLoaded) {
      showStatus('queue-form-status', 'Öppna kön innan du redigerar ett uppdrag.', true);
      return;
    }
    const selected = queueItemById(id);
    if (!selected) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    const item = selected.display;
    editingQueueId = item.id;
    machineQuickFlowActive = Boolean(selected.raw.machineTransport);
    byId('job-type').value = item.jobTypeId;
    refreshPlaceFormsForJobType('');
    refreshMachineSelect('queue');
    byId('job-machine').value = text(selected.raw.machine && selected.raw.machine.id);
    if (machineQuickFlowActive) {
      const state=selected.raw.machineTransport;
      const bed=document.querySelector(`input[name="jobMachineBed"][value="${state.hasMachineBed===true?'yes':'no'}"]`); if(bed)bed.checked=true;
      const direction=document.querySelector(`input[name="jobMachineDirection"][value="${text(state.direction)}"]`); if(direction)direction.checked=true;
      byId('job-machine-weight').value=Number.isFinite(Number(state.effectiveWeight))?String(state.effectiveWeight):'';
    }
    byId('job-from').value = item.fromPlaceId;
    byId('job-destination').value = item.destinationPlaceId;
    byId('job-return').value = item.returnPlaceId;
    byId('job-return-required').checked = item.returnRequired;
    byId('job-multi-load').checked = item.multiLoad;
    loadTemporaryPlaceForm('queue', selected.raw);
    syncJobModeControls('queue');
    if (machineQuickFlowActive) { renderMachineQuickFlow(); if(selectContainsValue(byId('job-machine-workshop'),text(selected.raw.machineTransport.workshopPlaceId)))byId('job-machine-workshop').value=text(selected.raw.machineTransport.workshopPlaceId); renderMachineQuickFlow(); }
    byId('job-note').value = item.note;
    byId('job-ata').checked = ataApi.isEnabled(selected.raw);
    writeAtaRecipientInput('queue', selected.raw.ata && selected.raw.ata.recipient);
    renderAtaRecipientContacts('queue', selected.raw.ata && selected.raw.ata.recipient);
    byId('planned-date').value = item.plannedDate;
    byId('planned-time').value = item.plannedTime;
    byId('queue-form-heading').textContent = 'Redigera köuppdrag';
    byId('queue-submit-button').textContent = 'Spara ändringar';
    byId('queue-cancel-edit').hidden = false;
    updateMaterialPanel('');
    syncQueueFormVisibility();
    byId('queue-form-heading').scrollIntoView({ block: 'start' });
    const routeNeedsCorrection = !isOtherActivityJobType(item.jobTypeId)
      && (!selectContainsValue(byId('job-from'), item.fromPlaceId) || !selectContainsValue(byId('job-destination'), item.destinationPlaceId));
    showStatus('queue-form-status', routeNeedsCorrection
      ? 'Uppdragets tidigare Från eller Till kan inte längre användas med jobbtypen. Välj giltiga platser innan du sparar eller startar.'
      : 'Ändra uppgifterna och tryck Spara ändringar.', routeNeedsCorrection);
  }

  function cancelQueueEdit() {
    if (!editingQueueId) return;
    resetQueueForm();
    showStatus('queue-form-status', 'Redigeringen avbröts. Kön är oförändrad.');
  }

  async function createQueueItem(event) {
    event.preventDefault();
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (isVehicleRole() && !editingQueueId && !machineQuickFlowActive) {
      showStatus('queue-load-status', '189:s operativa kö tar emot uppdrag från Mobil och befintliga köuppdrag kan redigeras.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('queue-form-status', 'Kön måste kunna läsas innan ett uppdrag kan sparas.', true);
      return;
    }
    const jobType = findJobTypeById(byId('job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const machine = machineTransport ? machineSnapshot(byId('job-machine').value) : null;
    const machineTransportState = machineTransport ? machineTransportStateFromQueueForm(machine) : null;
    const fromPlace = otherActivity ? null : resolveFormPlaceSelection('queue', 'from');
    const destinationPlace = otherActivity ? null : resolveFormPlaceSelection('queue', 'destination');
    const returnRequired = !otherActivity && byId('job-return-required').checked;
    const selectedReturnPlace = returnRequired ? findPlaceById(byId('job-return').value) : null;
    const returnPlace = returnRequired ? (selectedReturnPlace || fromPlace) : null;
    if (!jobType || (!otherActivity && (!fromPlace || !destinationPlace)) || (machineQuickFlowActive && machineTransport && !machineTransportState)) {
      showStatus('queue-form-status', otherActivity ? 'Välj jobbtyp.' : 'Välj jobbtyp, Från och Till.', true);
      return;
    }
    if (!otherActivity && !machineTransport
      && ((fromPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(fromPlace, jobType.id, 'from'))
        || (destinationPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(destinationPlace, jobType.id, 'destination')))) {
      showStatus('queue-form-status', 'Från eller Till är inte kopplad till vald Jobbtyp i Platsregistret. Välj en giltig kombination.', true);
      return;
    }
    const now = new Date().toISOString();
    const selected = editingQueueId ? queueItemById(editingQueueId) : null;
    if (editingQueueId && !selected) {
      showStatus('queue-form-status', 'Köposten som skulle redigeras finns inte längre. Kön är oförändrad.', true);
      return;
    }
    const jobId = selected ? selected.display.jobId : createLocalId('job');
    // A paused active job is only visiting the queue. Editing its fields must
    // not turn it into an ordinary queued job, otherwise startQueueItem would
    // correctly follow the new-job branch and reset its saved work state.
    const pausedActiveEdit = Boolean(selected
      && selected.raw.pausedFromActive === true
      && text(selected.raw.status) === 'paused');
    const material = otherActivity ? {} : deriveMaterialForSelections(jobType.id, fromPlace, destinationPlace);
    const temporaryPlaces = otherActivity ? {} : collectTemporaryPlaces('queue');
    const rawItem = {
      ...(selected ? selected.raw : {}),
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: selected ? selected.display.id : jobId,
      jobId,
      status: pausedActiveEdit ? 'paused' : 'queued',
      pausedFromActive: pausedActiveEdit,
      source: pausedActiveEdit
        ? text(selected.raw.source, 'vehicle-queue')
        : (isVehicleRole() ? 'manual-vehicle-received' : 'manual-mobile-planning'),
      jobTypeId: jobType.id,
      jobTypeName: jobType.name,
      fromPlaceId: text(fromPlace && fromPlace.id),
      fromPlaceName: text(fromPlace && fromPlace.name),
      destinationPlaceId: text(destinationPlace && destinationPlace.id),
      destinationPlaceName: text(destinationPlace && destinationPlace.name),
      returnPlaceId: returnPlace ? text(returnPlace.id) : '',
      returnPlaceName: returnPlace ? text(returnPlace.name) : '',
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : byId('job-multi-load').checked,
      ...(machineTransport ? { machine: machine ? { ...machine, weight: machineTransportState && machineTransportState.effectiveWeight || machine.weight } : null, machineLoads: machine ? [{ loadNumber: 1, machine: { ...machine, weight: machineTransportState && machineTransportState.effectiveWeight || machine.weight } }] : [], ...(machineTransportState ? { machineTransport: machineTransportState } : {}) } : {}),
      material,
      plannedDate: text(byId('planned-date').value) || p138Today(),
      plannedTime: text(byId('planned-time').value),
      note: text(byId('job-note').value),
      createdAt: selected ? text(selected.raw.createdAt, now) : now,
      createdByPackageVersion: selected ? selected.raw.createdByPackageVersion : PACKAGE_VERSION,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: { ...(selected && isPlainObject(selected.raw.metadata) ? selected.raw.metadata : {}), createdRole: text(selected && selected.raw.metadata && selected.raw.metadata.createdRole, text(hostInfo.role)), createdRoleLabel: text(selected && selected.raw.metadata && selected.raw.metadata.createdRoleLabel, text(hostInfo.roleLabel)), createdDeviceId: text(selected && selected.raw.metadata && selected.raw.metadata.createdDeviceId, text(hostInfo.deviceId)), modelVersion: JOB_MODEL_VERSION }
    };
    if (Object.keys(temporaryPlaces).length) rawItem.temporaryPlaces = temporaryPlaces;
    else delete rawItem.temporaryPlaces;
    const recipient = ensureAtaRecipientContact(ataRecipientInput('queue'), editingQueueId ? 'queue-edit' : 'manual-job-choice', 'queue-form-status');
    const ataSnapshot = ataRouting.jobAtaSnapshot({
      enabled: byId('job-ata').checked,
      source: editingQueueId ? 'queue-edit' : (ataRouting.isManualJobType(jobType) ? 'manual-job-choice' : (ataRouting.jobTypeEnabled(jobType) ? 'job-type' : 'manual-job-choice')),
      recipient: recipient || (byId('job-ata').checked ? ataRouting.defaultRecipient(jobType) : null),
      timestamp: now,
      existing: selected && selected.raw.ata
    });
    if (ataSnapshot) rawItem.ata = ataSnapshot;
    else delete rawItem.ata;
    const item = normalizeJobRecord(rawItem, 'job');
    const successMessage = selected ? 'Ändringarna är sparade i den lokala kön.' : (isVehicleRole() ? 'Uppdraget är sparat i 189:s lokala operativa kö.' : 'Uppdraget är sparat i Mobilens lokala planeringskö.');
    const nextDocument = p138Sort(selected ? queueDocument.map((entry, index) => index === selected.index ? item : entry) : [...queueDocument, item]);
    if (persistQueue(nextDocument, successMessage)) {
      const startMachineDirectly = machineQuickFlowActive && selectedQuickChoiceMode() === 'direct' && isVehicleRole();
      resetQueueForm();
      showStatus('queue-form-status', successMessage);
      if (startMachineDirectly) await startQueueItem(item.id);
    }
  }

  function requestQueueDelete(id) {
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded || queueItemIndexById(id) < 0) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    pendingQueueDeleteId = id;
    renderQueue();
    revealInlineControl('#queue-list .inline-confirm', previousScrollY);
    showStatus('queue-form-status', 'Bekräfta borttagningen eller avbryt.');
  }

  function cancelQueueDelete(id) {
    if (pendingQueueDeleteId !== id) {
      return;
    }
    const previousScrollY = currentScrollY();
    pendingQueueDeleteId = '';
    renderQueue();
    preserveScrollAfterRender(previousScrollY);
    showStatus('queue-form-status', 'Borttagningen avbröts. Kön är oförändrad.');
  }

  function confirmQueueDelete(id) {
    if (!canUseQueue() || pendingQueueDeleteId !== id) {
      showStatus('queue-form-status', 'Borttagningen kunde inte bekräftas och kön är oförändrad.', true);
      return;
    }
    const index = queueItemIndexById(id);
    if (index < 0) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    if (activeJobMatchesQueueItem(id)) {
      pendingQueueDeleteId = '';
      renderQueue();
      showStatus('queue-form-status', 'Köposten hör ihop med det aktiva jobbet och kan inte tas bort här. Aktivt jobb och kön är oförändrade.', true);
      return;
    }
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    persistQueue(nextDocument, 'Uppdraget är borttaget från kön.');
  }

  function removeQueueItemByIndex(index, successMessage) {
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    return persistQueue(nextDocument, successMessage);
  }

  async function startQueueItem(id) {
    if (!isVehicleRole()) {
      showStatus('queue-form-status', 'Endast 189 / Surfplatta får starta ett uppdrag från den operativa kön.', true);
      return;
    }
    if (!queueLoaded) {
      loadQueueIfNeeded();
    }
    const selected = queueItemById(id);
    if (!queueLoaded || !selected) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    if (!activeJobLoaded) {
      loadActiveJobIfNeeded();
    }
    if (!activeJobLoaded) {
      showStatus('queue-form-status', 'Aktivt jobb måste kunna kontrolleras innan uppdraget startas.', true);
      return;
    }

    const item = selected.display;
    const now = new Date().toISOString();
    let otherActivityToPark = null;
    if (activeJobExists()) {
      if (text(activeJobDocument.sourceQueueItemId) === id) {
        if (removeQueueItemByIndex(selected.index, 'Köposten togs bort. Uppdraget var redan säkert sparat som Aktivt jobb.')) {
          activateView('active');
          showStatus('active-load-status', 'Uppdraget är aktivt och den kvarvarande köposten har städats bort.');
        }
      } else if (isOtherActivity(activeJobDocument) && !item.otherActivity && activeJobDocument.status !== 'completing') {
        otherActivityToPark = pauseOtherActivityAutomatically(activeJobDocument, now, item.jobId);
      } else {
        renderQueue();
        showStatus('queue-form-status', 'Ett annat aktivt jobb pågår. Köuppdraget har inte ändrats.', true);
        return;
      }
      if (!otherActivityToPark) return;
    }

    if (activeJobStartInProgress) {
      showStatus('queue-form-status', 'Startpositionen fastställs redan för ett uppdrag.', true);
      return;
    }
    activeJobStartInProgress = true;
    const queueFromPlace = item.otherActivity ? null : resolveJobPlace(selected.raw, 'from');
    if (!item.otherActivity && initialPhaseNeedsGps(queueFromPlace)) {
      showStatus('queue-form-status', 'Appen fastställer startpositionen innan uppdraget startas.');
    }
    let queueInitialPhase;
    try {
      const machineBedPickupRequired = selected.raw.machineTransport && selected.raw.machineTransport.machineBedPickupRequired === true && !text(selected.raw.machineTransport.machineBedVisitedAt);
      queueInitialPhase = item.otherActivity
        ? { phase: phaseService.PHASES.OTHER_ACTIVITY, source: 'queue-start', reason: 'other_activity_started_from_queue' }
        : (machineBedPickupRequired ? { phase:phaseService.PHASES.START_ROUTE,source:'machine-bed-prestage',reason:'machine_bed_pickup_required' } : await determineInitialPhaseForPlace(queueFromPlace));
    } finally {
      activeJobStartInProgress = false;
    }
    if (activeJobExists() && !otherActivityToPark) {
      showStatus('queue-form-status', 'Ett annat aktivt jobb blev tillgängligt medan startpositionen hämtades. Köuppdraget är oförändrat.', true);
      return;
    }

    let nextActiveJob;
    if (item.pausedFromActive) {
      const {
        parkedOtherActivity: _staleParkedActivity,
        sourceQueueSnapshot: _previousQueueSnapshot,
        ...pausedSnapshot
      } = selected.raw;
      const pausedFrom = text(pausedSnapshot.pausedAt);
      const pausePeriods = Array.isArray(pausedSnapshot.pausePeriods) ? pausedSnapshot.pausePeriods.filter(isPlainObject) : [];
      const completedPause = pausedFrom ? { from: pausedFrom, to: now, mode: 'queued' } : null;
      const completedPauseMs = completedPause ? Math.max(0, new Date(now).getTime() - new Date(pausedFrom).getTime()) : 0;
      const resumedSegments = resumeWorkSegment(pausedSnapshot, now);
      nextActiveJob = normalizeJobRecord({
        ...pausedSnapshot,
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: item.jobId,
        jobId: item.jobId,
        status: 'active',
        pausedAt: '',
        pausedFromActive: false,
        resumedFromQueueAt: now,
        sourceQueueItemId: item.id,
        sourceQueueSnapshot: pausedSnapshot,
        ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
        pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
        pausedTotalMs: (Number(pausedSnapshot.pausedTotalMs) || 0) + completedPauseMs,
        workSegments: resumedSegments,
        continuationCount: Math.max(0, resumedSegments.length - 1),
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: appendActiveEvent(pausedSnapshot, 'job_resumed', now, 'queue-resume', { fromPausedQueue: true })
      }, 'active');
    } else {
      nextActiveJob = normalizeJobRecord({
        ...selected.raw,
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: item.jobId,
        jobId: item.jobId,
        status: 'active',
        phase: queueInitialPhase.phase,
        source: 'vehicle-queue',
        sourceQueueItemId: item.id,
        sourceQueueSnapshot: selected.raw,
        returnRequired: item.otherActivity ? false : item.returnRequired === true,
        multiLoad: item.otherActivity ? false : item.multiLoad === true,
        ...(item.otherActivity ? {} : {
          currentLoadNumber: 1,
          loadCycles: [{ loadNumber: 1, loadingStartedAt: queueInitialPhase.phase === phaseService.PHASES.LOADING ? now : '', outcome: 'open' }]
        }),
        ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
        startedAt: now,
        workSegments: [{ segmentNumber: 1, startedAt: now, endedAt: '', endReason: '', note: text(item.note) }],
        continuationCount: 0,
        updatedAt: now,
        createdByPackageVersion: PACKAGE_VERSION,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: [{ type: item.otherActivity ? 'other_activity_started_from_queue' : 'job_started_from_queue', at: now, source: 'vehicle-queue', packageVersion: PACKAGE_VERSION }]
      }, 'active');
      nextActiveJob = phaseService.initializeRecord(nextActiveJob, queueInitialPhase.phase, now, queueInitialPhase.reason, queueInitialPhase.source);
    }

    const activeSaveMessage = item.pausedFromActive
      ? (otherActivityToPark ? 'ÖV pausades automatiskt och det pausade uppdraget fortsätter från sparad fas.' : 'Det pausade uppdraget fortsätter från sparad fas.')
      : (otherActivityToPark ? 'ÖV pausades automatiskt och köuppdraget sparades som Aktivt jobb.' : 'Köuppdraget sparades först som Aktivt jobb.');
    if (!persistActiveJob(nextActiveJob, activeSaveMessage)) {
      showStatus('queue-form-status', 'Aktivt jobb kunde inte sparas. Köposten är oförändrad.', true);
      return;
    }

    if (!removeQueueItemByIndex(selected.index, 'Uppdraget flyttades från 189:s operativa kö till Aktivt jobb.')) {
      renderQueue();
      showStatus('queue-form-status', 'Aktivt jobb är säkert sparat, men köposten kunde inte tas bort. Tryck på startknappen igen för att slutföra flytten.', true);
      return;
    }

    activateView('active');
    showStatus('active-load-status', item.pausedFromActive
      ? (otherActivityToPark ? 'Det pausade uppdraget fortsätter från sparad fas. ÖV är säkert automatiskt pausad bakom uppdraget.' : 'Det pausade uppdraget fortsätter från sparad fas.')
      : (otherActivityToPark ? 'ÖV är säkert automatiskt pausad bakom uppdraget.' : ''));
  }

  function renderSyncRoleView() { renderSyncV63(); }

  function activeJobExists() {
    return isPlainObject(activeJobDocument) && Boolean(text(activeJobDocument.id));
  }

  function activeEvents(documentValue) {
    return Array.isArray(documentValue.events) ? documentValue.events.filter(isPlainObject) : [];
  }

  function activeWorkSegments(documentValue = activeJobDocument) {
    const stored = Array.isArray(documentValue.workSegments) ? documentValue.workSegments.filter(isPlainObject) : [];
    if (stored.length > 0) return stored;
    const startedAt = text(documentValue.startedAt);
    return startedAt ? [{ segmentNumber: 1, startedAt, endedAt: '', endReason: '', note: text(documentValue.note) }] : [];
  }

  function closeOpenWorkSegment(documentValue, endedAt, endReason) {
    const segments = activeWorkSegments(documentValue);
    const openIndex = segments.findIndex((segment) => !text(segment.endedAt));
    if (openIndex < 0) return segments;
    return segments.map((segment, index) => index === openIndex ? { ...segment, endedAt, endReason } : segment);
  }

  function resumeWorkSegment(documentValue, startedAt) {
    const segments = activeWorkSegments(documentValue);
    if (segments.some((segment) => !text(segment.endedAt))) return segments;
    return [...segments, { segmentNumber: segments.length + 1, startedAt, endedAt: '', endReason: '', note: text(documentValue.note) }];
  }

  function parkedOtherActivity(documentValue = activeJobDocument) {
    return isPlainObject(documentValue.parkedOtherActivity) && isOtherActivity(documentValue.parkedOtherActivity)
      ? documentValue.parkedOtherActivity
      : null;
  }

  function pauseOtherActivityAutomatically(documentValue, pausedAt, forJobId) {
    if (!isOtherActivity(documentValue)) return null;
    if (text(documentValue.status) !== 'active') {
      return {
        ...documentValue,
        pauseMode: text(documentValue.pauseMode, 'manual'),
        autoResumeEligible: false,
        parkedForJobId: text(forJobId),
        parkedAt: pausedAt
      };
    }
    return {
      ...documentValue,
      status: 'paused',
      pausedAt,
      pauseMode: 'automatic',
      autoResumeEligible: true,
      autoPausedForJobId: text(forJobId),
      parkedForJobId: text(forJobId),
      parkedAt: pausedAt,
      workSegments: closeOpenWorkSegment(documentValue, pausedAt, 'auto-paused-for-job'),
      updatedAt: pausedAt,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(documentValue, 'other_activity_auto_paused', pausedAt, 'automatic', { forJobId: text(forJobId) })
    };
  }

  function resumeOtherActivityAutomatically(documentValue, resumedAt, afterJobId) {
    if (!isOtherActivity(documentValue)) return null;
    if (text(documentValue.status) === 'active') return documentValue;
    if (text(documentValue.status) !== 'paused' || text(documentValue.pauseMode) !== 'automatic' || documentValue.autoResumeEligible !== true) {
      return documentValue;
    }
    const pausePeriods = Array.isArray(documentValue.pausePeriods) ? documentValue.pausePeriods.filter(isPlainObject) : [];
    const pausedFrom = text(documentValue.pausedAt);
    const completedPause = pausedFrom ? { from: pausedFrom, to: resumedAt, mode: 'automatic' } : null;
    const completedPauseMs = completedPause ? Math.max(0, new Date(resumedAt).getTime() - new Date(pausedFrom).getTime()) : 0;
    const nextSegments = resumeWorkSegment(documentValue, resumedAt);
    return {
      ...documentValue,
      status: 'active',
      pausedAt: '',
      pauseMode: '',
      autoResumeEligible: false,
      autoPausedForJobId: '',
      parkedForJobId: text(afterJobId),
      pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
      pausedTotalMs: (Number(documentValue.pausedTotalMs) || 0) + completedPauseMs,
      workSegments: nextSegments,
      continuationCount: Math.max(0, nextSegments.length - 1),
      updatedAt: resumedAt,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(documentValue, 'other_activity_auto_resumed', resumedAt, 'automatic', { afterJobId: text(afterJobId) })
    };
  }

  function restoreOtherActivityAfterJob(documentValue, restoredAt) {
    const parked = parkedOtherActivity(documentValue);
    if (!parked) return null;
    const resumed = resumeOtherActivityAutomatically(parked, restoredAt, stableJobId(documentValue, 'completed-job'));
    return {
      ...resumed,
      parkedForJobId: '',
      parkedAt: '',
      restoredAfterJobAt: restoredAt
    };
  }

  function phaseLabel(phase) {
    return phaseService ? phaseService.label(phase) : text(phase, 'Lastning');
  }

  function statusLabel(status) {
    if (status === 'paused') return 'Pausat';
    if (status === 'completing') return 'Avslut väntar';
    return 'Aktivt';
  }

  function activeLoads(documentValue = activeJobDocument) {
    return Array.isArray(documentValue.loads) ? documentValue.loads.filter((value) => Number.isFinite(Number(value)) && Number(value) >= 0).map(Number) : [];
  }

  function activeTotalWeight(documentValue = activeJobDocument) {
    return activeLoads(documentValue).reduce((sum, value) => sum + value, 0);
  }

  function activeLoadCycles(documentValue = activeJobDocument) {
    const stored = Array.isArray(documentValue.loadCycles) ? documentValue.loadCycles.filter(isPlainObject) : [];
    if (stored.length > 0) return stored;
    const entries = Array.isArray(documentValue.weightEntries) ? documentValue.weightEntries.filter(isPlainObject) : [];
    if (entries.length > 0) {
      return entries.map((entry, index) => ({
        loadNumber: index + 1,
        loadingStartedAt: text(documentValue.startedAt),
        unloadingStartedAt: text(documentValue.unloadingStartedAt),
        completedAt: text(entry.at),
        weight: Number(entry.weight),
        outcome: 'registered'
      }));
    }
    return [{ loadNumber: 1, loadingStartedAt: text(documentValue.startedAt), outcome: documentValue.noEmptying === true ? 'no-emptying' : 'open' }];
  }

  function currentLoadNumber(documentValue = activeJobDocument) {
    return Math.max(1, Number(documentValue.currentLoadNumber) || activeLoadCycles(documentValue).length || 1);
  }

  function currentLoadCycle(documentValue = activeJobDocument) {
    const number = currentLoadNumber(documentValue);
    return activeLoadCycles(documentValue).find((cycle) => Number(cycle.loadNumber) === number) || null;
  }

  function currentLoadHasOutcome(documentValue = activeJobDocument) {
    const cycle = currentLoadCycle(documentValue);
    return Boolean(cycle && (cycle.outcome === 'registered' || cycle.outcome === 'no-emptying' || cycle.outcome === 'missing-confirmed'));
  }

  function currentLoadWeightStatusMessage(documentValue = activeJobDocument) {
    const loadNumber = currentLoadNumber(documentValue);
    const cycle = currentLoadCycle(documentValue);
    if (!cycle) return '';
    if (cycle.outcome === 'no-emptying') return `Ingen tömning är registrerad för lass ${loadNumber}.`;
    if (cycle.outcome !== 'registered') return '';
    const hasCycleWeight = cycle.weight !== '' && cycle.weight !== null && cycle.weight !== undefined && Number.isFinite(Number(cycle.weight));
    const entry = (Array.isArray(documentValue.weightEntries) ? documentValue.weightEntries : []).find((candidate) => isPlainObject(candidate) && Number(candidate.loadNumber) === loadNumber);
    const hasEntryWeight = entry && entry.weight !== '' && entry.weight !== null && entry.weight !== undefined && Number.isFinite(Number(entry.weight));
    return hasCycleWeight || hasEntryWeight ? `Vikten är registrerad för lass ${loadNumber}.` : '';
  }

  function updateCurrentLoadCycle(documentValue, updates) {
    const number = currentLoadNumber(documentValue);
    const cycles = activeLoadCycles(documentValue);
    const index = cycles.findIndex((cycle) => Number(cycle.loadNumber) === number);
    if (index < 0) return [...cycles, { loadNumber: number, loadingStartedAt: text(documentValue.startedAt), outcome: 'open', ...updates }];
    return cycles.map((cycle, cycleIndex) => cycleIndex === index ? { ...cycle, ...updates, loadNumber: number } : cycle);
  }

  function isBeachPlaceRecord(place) {
    const roles = place && Array.isArray(place.roles) ? place.roles : [];
    return Boolean(place && (place.category === 'badplats' || roles.includes('beach')));
  }

  function isSeaweedToBeach(documentValue) {
    if (canonicalJobTypeId(documentValue.jobTypeId) !== 'JT-1010') return false;
    return isBeachPlaceRecord(findPlaceById(documentValue.destinationPlaceId));
  }

  function seaweedFlowType(documentValue) {
    if (canonicalJobTypeId(documentValue.jobTypeId) !== 'JT-1010') return '';
    const from = findPlaceById(documentValue.fromPlaceId);
    const destination = findPlaceById(documentValue.destinationPlaceId);
    if (text(documentValue.destinationPlaceId) === 'PL-1007') return 'till_bioanlaggning';
    if (isBeachPlaceRecord(destination)) return isBeachPlaceRecord(from) ? 'mellan_badplatser' : 'till_badplats';
    return 'ovrig_havstang';
  }

  function seaweedFlowLabel(documentValue) {
    const flow = seaweedFlowType(documentValue);
    if (flow === 'till_bioanlaggning') return 'Inkörning till Bio · kod 611 · verklig Bioanläggningsvikt';
    if (flow === 'mellan_badplatser') return 'Mellan badplatser · vikt valfri och märks mellankörningsvikt';
    if (flow === 'till_badplats') return 'Utkörning till badplats · vikt valfri';
    return flow ? 'Övrigt Havstångsflöde' : '';
  }

  function seaweedWeightMetadata(documentValue) {
    const flowType = seaweedFlowType(documentValue);
    if (!flowType) return {};
    const role = flowType === 'till_bioanlaggning' ? 'verklig_bioanlaggning' : 'mellankorningsvikt';
    return {
      role,
      roleLabel: role === 'verklig_bioanlaggning' ? 'Verklig/invägd Bioanläggningsvikt' : 'Mellankörningsvikt / aktuell flakvikt',
      flowType,
      materialCode: flowType === 'till_bioanlaggning' ? '611' : ''
    };
  }

  function weightPolicy(documentValue) {
    const jobTypeId = canonicalJobTypeId(documentValue.jobTypeId);
    if (jobTypeId === 'JT-1001' || jobTypeId === 'JT-1011') return { mode: 'not-required', label: 'Vikt behövs inte för denna jobbtyp.' };
    if (isSeaweedToBeach(documentValue)) return { mode: 'not-required', label: 'Havstång till badplats får avslutas utan vikt.' };
    if (jobTypeId === 'JT-1013' || jobTypeId === 'JT-1014') return { mode: 'optional', label: 'Vikt är valfri för denna jobbtyp.' };
    return { mode: 'required', label: 'Registrera vikt eller välj Ingen tömning före Klart.' };
  }

  function weightOutcome(documentValue) {
    const loads = activeLoads(documentValue);
    if (loads.length > 0) return 'registered';
    if (documentValue.noEmptying === true) return 'no-emptying';
    if (documentValue.weightMissingConfirmed === true) return 'missing-confirmed';
    return 'missing';
  }

  function weightStatusLabel(documentValue) {
    const outcome = weightOutcome(documentValue);
    if (outcome === 'registered') return `${activeTotalWeight(documentValue).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    if (outcome === 'no-emptying') return 'Ingen tömning';
    if (outcome === 'missing-confirmed') return 'Avslutat utan vikt';
    return weightPolicy(documentValue).mode === 'required' ? 'Vikt saknas' : 'Vikt ej obligatorisk';
  }

  function parseWeightInput(value) {
    const raw = String(value || '').trim().replace(',', '.');
    if (!/^\d+(?:\.\d{0,3})?$/.test(raw)) return NaN;
    return Number(raw);
  }

  function noteWithoutNoEmptyingMarker(value) {
    return text(value)
      .replace(/\s*[–-]\s*Ej behov av tömning/giu, '')
      .replace(/Ej behov av tömning\s*[–-]\s*/giu, '')
      .replace(/^Ej behov av tömning$/giu, '')
      .trim();
  }

  function focusActiveWeightInput(options = {}) {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att registrera vikt på.', true);
      return false;
    }
    const input = byId('active-weight-input');
    if (!input || byId('active-weight-panel').hidden) {
      showStatus('active-weight-status', 'Viktfältet är inte tillgängligt för detta uppdrag.', true);
      return false;
    }
    if (!String(input.value || '').trim() && isMachineTransportJobType(activeJobDocument.jobTypeId) && machineTransportApi) {
      const selected = isPlainObject(activeJobDocument.machine) ? activeJobDocument.machine : null;
      const current = selected ? machineSnapshot(selected.id) : null;
      const effectiveWeight = machineTransportApi.effectiveWeight(activeJobDocument) || (current && Number.isFinite(current.weight) && current.weight > 0 ? current.weight : null);
      if (Number.isFinite(effectiveWeight) && effectiveWeight >= 0) input.value = String(effectiveWeight);
    }
    const focusInput = () => {
      try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
      if (typeof input.setSelectionRange === 'function') {
        const end = String(input.value || '').length;
        try { input.setSelectionRange(end, end); } catch (_) {}
      }
    };
    focusInput();
    window.requestAnimationFrame(focusInput);
    if (options.showHint !== false) {
      showStatus('active-weight-status', 'Skriv vikten i ton och tryck Ange vikt. Siffertangentbordet ska vara öppet.');
    }
    return true;
  }

  function registerActiveWeight() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att registrera vikt på.', true);
      return false;
    }
    const input = byId('active-weight-input');
    if (!String(input.value || '').trim()) {
      focusActiveWeightInput({ showHint: false });
      showStatus('active-weight-status', 'Skriv vikten i ton. 0 är tillåtet för tomtransport eller tomt flak.', true);
      return false;
    }
    const weight = parseWeightInput(input.value);
    if (!Number.isFinite(weight) || weight < 0) {
      focusActiveWeightInput({ showHint: false });
      showStatus('active-weight-status', 'Skriv en giltig vikt i ton. Använd exempelvis 12,5. 0 är tillåtet.', true);
      return false;
    }
    if (weight > 17) {
      focusActiveWeightInput({ showHint: false });
      showStatus('active-weight-status', 'Maxvikt per lass är 17 ton.', true);
      return false;
    }
    const now = new Date().toISOString();
    const loadNumber = currentLoadNumber(activeJobDocument);
    const currentCycle = currentLoadCycle(activeJobDocument);
    const automaticMachineWeight = input.dataset.machineAutoWeight === 'true';
    const existingEntry = (Array.isArray(activeJobDocument.weightEntries) ? activeJobDocument.weightEntries : []).find((entry) => isPlainObject(entry) && Number(entry.loadNumber) === loadNumber);
    if (currentCycle && currentCycle.outcome === 'registered' && !(existingEntry && existingEntry.source === 'machine-auto' && !automaticMachineWeight)) {
      showStatus('active-weight-status', `Lass ${loadNumber} har redan en registrerad vikt. Påbörja nästa transport innan nästa lass vägs.`, true);
      return false;
    }
    const priorLoads = activeLoads(activeJobDocument); const loads = existingEntry && existingEntry.source === 'machine-auto' && !automaticMachineWeight
      ? priorLoads.map((value, index) => index === loadNumber - 1 ? weight : value)
      : [...priorLoads, weight];
    const entries = Array.isArray(activeJobDocument.weightEntries) ? activeJobDocument.weightEntries.filter(isPlainObject) : [];
    const seaweedWeight = seaweedWeightMetadata(activeJobDocument);
    let nextDocument = {
      ...activeJobDocument,
      loads,
      totalWeight: loads.reduce((sum, value) => sum + value, 0),
      weightEntries: (existingEntry && existingEntry.source === 'machine-auto' && !automaticMachineWeight ? entries.filter((entry) => entry !== existingEntry) : entries).concat({ weight, at: now, phase: text(activeJobDocument.phase, 'loading'), loadNumber, source: automaticMachineWeight ? 'machine-auto' : 'manual', ...seaweedWeight }),
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { weight, completedAt: now, outcome: 'registered', weightRole: text(seaweedWeight.role), flowType: text(seaweedWeight.flowType) }),
      ...(text(seaweedWeight.role) ? { havstangFlowType: seaweedWeight.flowType, havstangWeightRole: seaweedWeight.role, havstangWeightRoleLabel: seaweedWeight.roleLabel, havstangWeightIsFinal: seaweedWeight.role === 'verklig_bioanlaggning' } : {}),
      noEmptying: false,
      weightMissingConfirmed: false,
      weightOutcome: 'registered',
      note: noteWithoutNoEmptyingMarker(activeJobDocument.note),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'weight_registered', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber } : entry)
    };
    delete input.dataset.machineAutoWeight;
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    if (currentPhase === phaseService.PHASES.UNLOADING) {
      const nextPhase = activeJobDocument.returnRequired === true
        ? phaseService.PHASES.RETURN_TRANSPORT
        : phaseService.PHASES.READY_TO_COMPLETE;
      nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.LOAD_REGISTERED, now, 'weight_registered_in_unloading', 'manual', { loadNumber, nextPhase });
      nextDocument = phaseVisualService.markLoadRegistered(nextDocument, stableJobId(activeJobDocument, 'active'), nextPhase, now);
    } else if (currentPhase === phaseService.PHASES.RETURN_UNLOADING) {
      nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.READY_TO_COMPLETE, now, 'weight_registered_in_return_unloading', 'manual', { loadNumber });
    }
    pendingWeightlessCompletion = false;
    if (persistActiveJob(nextDocument, `Vikt ${weight.toLocaleString('sv-SE', { maximumFractionDigits: 3 })} ton registrerades och sparades lokalt.`)) {
      input.value = '';
      showStatus('active-weight-status', `Vikten är registrerad för lass ${loadNumber}.`);
      return true;
    }
    return false;
  }

  function markActiveNoEmptying() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att markera.', true);
      return;
    }
    if (currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-weight-status', `Lass ${currentLoadNumber(activeJobDocument)} har redan ett registrerat utfall.`, true);
      return;
    }
    const now = new Date().toISOString();
    const marker = 'Ej behov av tömning';
    const note = text(activeJobDocument.note);
    const nextNote = note.toLocaleLowerCase('sv-SE').includes(marker.toLocaleLowerCase('sv-SE')) ? note : (note ? `${note} – ${marker}` : marker);
    let nextDocument = {
      ...activeJobDocument,
      noEmptying: true,
      noEmptyingAt: now,
      weightMissingConfirmed: false,
      weightOutcome: 'no-emptying',
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { completedAt: now, outcome: 'no-emptying' }),
      excludeFromTimeEstimate: true,
      excludeFromEstimateLearning: true,
      learningExcludedReason: marker,
      note: nextNote,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'no_emptying', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber: currentLoadNumber(activeJobDocument) } : entry)
    };
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    if (currentPhase === phaseService.PHASES.UNLOADING) {
      const nextPhase = activeJobDocument.returnRequired === true
        ? phaseService.PHASES.RETURN_TRANSPORT
        : phaseService.PHASES.READY_TO_COMPLETE;
      nextDocument = buildPhaseTransitionDocument(nextDocument, nextPhase, now, 'no_emptying_registered_in_unloading', 'manual', { loadNumber: currentLoadNumber(activeJobDocument) });
    } else if (currentPhase === phaseService.PHASES.RETURN_UNLOADING) {
      nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.READY_TO_COMPLETE, now, 'no_emptying_registered_in_return_unloading', 'manual', { loadNumber: currentLoadNumber(activeJobDocument) });
    }
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, 'Ingen tömning är registrerad. Uppdraget undantas från framtida tidsinlärning.');
  }

  function clearLoadRegisteredTimer() {
    if (loadRegisteredTimer !== null) window.clearTimeout(loadRegisteredTimer);
    loadRegisteredTimer = null;
    loadRegisteredTimerJobId = '';
    loadRegisteredTimerUntil = '';
  }

  function p124DeferAutomaticReturnRoutes(documentValue) {
    const snapshot = p116LastGpsSnapshot || currentGpsSnapshot();
    if (!routesService || !routesService.valid(snapshot)) return documentValue;
    return {
      ...documentValue,
      p124RoutesAwaitingMotion: {
        phase: phaseService.PHASES.RETURN_TRANSPORT,
        latitude: Number(snapshot.latitude),
        longitude: Number(snapshot.longitude),
        timestamp: Number(snapshot.timestamp),
        accuracy: Number(snapshot.accuracy),
        armedAt: new Date().toISOString()
      }
    };
  }

  function completeLoadRegisteredPhase(expectedJobId, expectedUntil) {
    clearLoadRegisteredTimer();
    if (!activeJobLoaded || !activeJobExists() || text(activeJobDocument.status) !== 'active') return;
    if (phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.LOAD_REGISTERED) return;
    const activeId = stableJobId(activeJobDocument, 'active');
    if (activeId !== expectedJobId || !phaseVisualService.timerMatches(activeJobDocument, expectedJobId, expectedUntil)) return;
    const targetPhase = phaseService.normalizePhase(text(activeJobDocument.loadRegisteredNextPhase), '');
    if (![phaseService.PHASES.RETURN_TRANSPORT, phaseService.PHASES.READY_TO_COMPLETE].includes(targetPhase)) {
      showStatus('active-action-status', 'Lass registrerat saknar en säker nästa fas. Uppdraget är bevarat.', true);
      return;
    }
    const now = new Date().toISOString();
    let nextDocument = buildPhaseTransitionDocument(activeJobDocument, targetPhase, now, 'load_registered_delay_completed', 'timer');
    // P124: The automatic hand-off from Lass registrerat must finish locally.
    // Routes may resume only after a later, proven movement from this position.
    if (targetPhase === phaseService.PHASES.RETURN_TRANSPORT) nextDocument = p124DeferAutomaticReturnRoutes(nextDocument);
    persistActiveJob(nextDocument, targetPhase === phaseService.PHASES.RETURN_TRANSPORT
      ? 'Lasset är registrerat. Returtransport kan fortsätta.'
      : 'Lasset är registrerat. Uppdraget är redo att avslutas.');
  }

  function scheduleLoadRegisteredTransition() {
    if (!activeJobLoaded || !activeJobExists()
      || text(activeJobDocument.status) !== 'active'
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.LOAD_REGISTERED) {
      clearLoadRegisteredTimer();
      return;
    }
    const jobId = stableJobId(activeJobDocument, 'active');
    const until = text(activeJobDocument.loadRegisteredUntil);
    if (!jobId || !until || text(activeJobDocument.loadRegisteredJobId) !== jobId) {
      clearLoadRegisteredTimer();
      showStatus('active-action-status', 'Lass registrerat väntar, men tidsmarkeringen är ofullständig. Uppdraget är bevarat.', true);
      return;
    }
    if (loadRegisteredTimer !== null && loadRegisteredTimerJobId === jobId && loadRegisteredTimerUntil === until) return;
    clearLoadRegisteredTimer();
    const remaining = phaseVisualService.remainingMs(activeJobDocument);
    if (remaining <= 0) {
      completeLoadRegisteredPhase(jobId, until);
      return;
    }
    loadRegisteredTimerJobId = jobId;
    loadRegisteredTimerUntil = until;
    loadRegisteredTimer = window.setTimeout(() => completeLoadRegisteredPhase(jobId, until), remaining);
  }

  function activePhaseControl(phase, status, returnRequired, otherActivity) {
    if (otherActivity) return Object.freeze({ phase: phaseService.PHASES.OTHER_ACTIVITY, label: 'Övrig verksamhet', action: '' });
    const base = phaseActionService.resolve(phase, phaseService);
    const multiLoadReady = activeJobDocument.multiLoad === true
      && returnRequired !== true
      && phase === phaseService.PHASES.READY_TO_COMPLETE
      && status === 'active'
      && currentLoadHasOutcome(activeJobDocument);
    if (!multiLoadReady) return base;
    return Object.freeze({
      phase,
      label: `Påbörja nästa transport (${currentLoadNumber(activeJobDocument) + 1})`,
      action: phaseActionService.ACTIONS.START_NEXT_LOAD
    });
  }

  function renderActiveJob() {
    const jobCard = byId('active-job-card');
    const pill = byId('active-status-pill');
    const summaryCard = byId('active-summary-card');
    jobCard.hidden = true;
    summaryCard.hidden = false;
    summaryCard.style.display = '';
    byId('active-load-status').hidden = true;
    byId('active-load-status').textContent = '';
    pill.classList.remove('is-active', 'is-paused', 'is-completing');

    if (!activeJobLoaded) {
      clearActivePhaseVisuals();
      pill.textContent = 'Ej laddat';
      syncLocalJobActions();
      syncActiveJobNavigationMarker();
      return;
    }
    if (!activeJobExists()) {
      clearActivePhaseVisuals();
      if (ataBillingDialogOpen) closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveReset = false;
      pendingActiveComplete = false;
      pendingWeightlessCompletion = false;
      pill.textContent = 'Inget jobb';
      clearLoadRegisteredTimer();
      syncLocalJobActions();
      syncActiveJobNavigationMarker();
      return;
    }

    const status = text(activeJobDocument.status, 'active');
    const phase = phaseService.normalizePhase(text(activeJobDocument.phase, 'loading'));
    const otherActivity = isOtherActivity(activeJobDocument);
    const parkedActivity = parkedOtherActivity(activeJobDocument);
    pill.textContent = statusLabel(status);
    pill.classList.add(status === 'paused' ? 'is-paused' : (status === 'completing' ? 'is-completing' : 'is-active'));
    byId('active-display-type').textContent = text(activeJobDocument.jobType, 'Uppdrag');
    const activeMachine = isPlainObject(activeJobDocument.machine) ? text(activeJobDocument.machine.name) : '';
    if (activeMachine) byId('active-display-type').textContent += ` · ${activeMachine}`;
    const activeAtaBadge = byId('active-ata-badge');
    activeAtaBadge.hidden = !ataApi.isEnabled(activeJobDocument);
    const returnRequired = !otherActivity && activeJobDocument.returnRequired === true;
    byId('active-route').hidden = otherActivity;
    byId('active-route').textContent = returnRequired
      ? `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')} → ${text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Returplats saknas'))}`
      : (otherActivity ? 'Användarens tidsrapportering' : `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')}`);
    const parkedStatus = byId('active-other-activity-status');
    parkedStatus.hidden = !parkedActivity;
    parkedStatus.textContent = !parkedActivity
      ? ''
      : (parkedActivity.status === 'active'
        ? 'Övrig verksamhet pågår automatiskt medan detta uppdrag är pausat.'
        : (parkedActivity.autoResumeEligible === true
          ? 'Övrig verksamhet är automatiskt pausad bakom detta uppdrag.'
          : 'Övrig verksamhet är manuellt pausad bakom detta uppdrag och återstartas inte automatiskt.'));
    byId('active-display-phase').textContent = phaseLabel(phase);
    renderActivePhaseTrack(activeJobDocument);
    byId('active-display-started').textContent = formatTimestamp(activeJobDocument.startedAt);
    p116RenderLiveTime();
    byId('active-display-distance').textContent = routesService ? routesService.formatDistance(p118DisplayedRouteMeters(activeJobDocument)) : '–';
    p121RenderEta();
    byId('active-event-count').textContent = String(activeEvents(activeJobDocument).length);
    byId('active-display-return').textContent = returnRequired ? text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Från-plats')) : 'Ingen';
    const activeMaterial = isPlainObject(activeJobDocument.material) ? activeJobDocument.material : {};
    byId('active-display-material').textContent = [text(activeMaterial.code), text(activeMaterial.facilityPlaceName)].filter(Boolean).join(' · ') || 'Ej aktuellt';
    byId('active-display-loads').textContent = String(activeLoads(activeJobDocument).length);
    byId('active-display-current-load').textContent = activeJobDocument.multiLoad === true ? String(currentLoadNumber(activeJobDocument)) : 'Enkellass';
    byId('active-display-weight').textContent = `${activeTotalWeight(activeJobDocument).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    ['active-return-row', 'active-material-row', 'active-loads-row', 'active-weight-row'].forEach((id) => {
      byId(id).hidden = otherActivity;
    });
    byId('active-current-load-row').hidden = otherActivity || activeJobDocument.multiLoad !== true;
    const seaweedLabel = seaweedFlowLabel(activeJobDocument);
    byId('active-seaweed-row').hidden = !seaweedLabel;
    byId('active-display-seaweed').textContent = seaweedLabel || '–';
    byId('active-weight-rule').textContent = weightPolicy(activeJobDocument).label;
    byId('active-weight-panel').hidden = otherActivity;
    showStatus('active-weight-status', otherActivity ? '' : currentLoadWeightStatusMessage(activeJobDocument));
    const activeNote = text(activeJobDocument.note);
    const noteInput = byId('active-note-editor-input');
    if (document.activeElement !== noteInput) noteInput.value = activeNote;
    byId('active-display-note').hidden = !activeNote;
    byId('active-display-note').textContent = activeNote ? `Anteckning: ${activeNote}` : '';
    const phaseAction = byId('active-phase-action');
    const phaseControl = activePhaseControl(phase, status, returnRequired, otherActivity);
    phaseAction.hidden = false;
    phaseAction.textContent = phaseControl.label;
    phaseAction.dataset.phaseAction = phaseControl.action;
    phaseAction.setAttribute('aria-label', phaseControl.label || 'Fasåtgärd');
    phaseAction.disabled = otherActivity || status !== 'active' || pendingActiveComplete || pendingWeightlessCompletion || ataBillingDialogOpen || phase === phaseService.PHASES.LOAD_REGISTERED;
    applyActivePhaseVisuals(phase, otherActivity);
    const weightSubmitButton = byId('active-weight-submit');
    weightSubmitButton.hidden = false;
    weightSubmitButton.disabled = false;
    weightSubmitButton.textContent = 'Ange vikt';
    const pauseButton = byId('active-pause-action');
    pauseButton.hidden = false;
    pauseButton.disabled = status === 'completing' || pendingActiveComplete || pendingWeightlessCompletion || ataBillingDialogOpen;
    pauseButton.textContent = status === 'paused'
      ? (otherActivity ? 'Fortsätt' : 'Flytta pausat uppdrag till kö')
      : 'Pausa';
    const completeButton = byId('active-complete-request');
    completeButton.hidden = false;
    completeButton.disabled = !['active', 'paused', 'completing'].includes(status) || pendingActiveComplete || pendingWeightlessCompletion || ataBillingDialogOpen;
    completeButton.textContent = status === 'completing' ? 'Slutför avslut' : 'Klart';
    byId('active-complete-confirm').hidden = !pendingActiveComplete || ataBillingDialogOpen;
    byId('active-complete-without-weight-confirm').hidden = !pendingWeightlessCompletion || ataBillingDialogOpen;
    byId('active-reset-request').hidden = pendingActiveReset || status === 'completing';
    byId('active-reset-confirm').hidden = !pendingActiveReset;
    byId('active-reset-message').textContent = isPlainObject(activeJobDocument.sourceQueueSnapshot)
      ? 'Uppdraget återställs först i 189:s operativa kö och tas därefter bort från Aktivt jobb. Det förs inte till Historik.'
      : (otherActivity
        ? 'Övrig verksamhet tas bort ur Aktivt jobb och förs inte till Historik.'
        : 'Det manuellt startade uppdraget tas bort ur Aktivt jobb och förs inte till Historik.');
    jobCard.hidden = false;
    summaryCard.hidden = true;
    summaryCard.style.display = 'none';
    byId('active-load-status').hidden = true;
    byId('active-load-status').textContent = '';
    syncLocalJobActions();
    syncActiveJobNavigationMarker();
    scheduleLoadRegisteredTransition();
    p122ScheduleDrivingRoutes('render');
  }

  function loadActiveJobIfNeeded() {
    if (!canUseActiveJob()) {
      showStatus('active-role-note', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (activeJobLoaded) {
      renderActiveJob();
      return;
    }
    try {
      activeJobDocument = readActiveJobDocument();
      activeJobLoaded = true;
      renderActiveJob();
      syncActiveJobGpsConsumer();
      syncActiveGeofenceContext();
      showStatus('active-load-status', activeJobExists() ? '' : 'Inget aktivt jobb finns.');
    } catch (error) {
      watchdog.step('runtime.store.active.invalid', error.message || 'Aktivt jobb kunde inte läsas.', 'warning');
      renderActiveJob();
      syncActiveJobGpsConsumer();
      syncActiveGeofenceContext();
      showStatus('active-load-status', error.message || 'Aktivt jobb kunde inte läsas.', true);
    }
  }

  function persistActiveJob(nextDocument, successMessage, options = {}) {
    const previousActiveDocument = activeJobDocument;
    const saved = window.StadslassHost.writeStore(ACTIVE_JOB_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('active-action-status', window.StadslassHost.getLastError() || 'Aktivt jobb kunde inte sparas.', true);
      return false;
    }
    activeJobDocument = nextDocument;
    activeJobLoaded = true;
    pendingActiveReset = false;
    renderActiveJob();
    syncActiveJobGpsConsumer();
    syncActiveGeofenceContext();
    if (queueLoaded) renderQueue();
    invalidateQuickChoiceFallbackForActiveJobChange();
    syncLocalJobActions();
    if (!options.p119Route) {
      const previousPhase = phaseService.normalizePhase(text(previousActiveDocument && previousActiveDocument.phase));
      const phaseChanged = previousPhase !== phaseService.normalizePhase(text(nextDocument && nextDocument.phase));
      const resumed = text(previousActiveDocument && previousActiveDocument.status) !== 'active' && text(nextDocument && nextDocument.status) === 'active';
      p119RouteGeneration += 1;
      p122ScheduleDrivingRoutes(phaseChanged ? 'phase-change' : (resumed ? 'resume' : 'persist'), phaseChanged || options.resumed === true || resumed);
    }
    if (!options.silent && text(successMessage)) showStatus('active-action-status', successMessage);
    return true;
  }

  function appendActiveEvent(documentValue, type, at, source = 'manual', extra = {}) {
    return [...activeEvents(documentValue), { type, at, source, packageVersion: PACKAGE_VERSION, ...extra }];
  }

  async function createActiveJob(event) {
    event.preventDefault();
    if (!canUseActiveJob()) {
      showStatus('active-form-status', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (!activeJobLoaded) loadActiveJobIfNeeded();
    if (!activeJobLoaded) {
      showStatus('active-form-status', 'Aktivt jobb måste kunna läsas innan ett nytt uppdrag kan startas.', true);
      return;
    }
    if (activeJobExists()) {
      showStatus('active-form-status', 'Ett aktivt uppdrag pågår. Uppdraget kan bara läggas i kö.', true);
      return;
    }
    const jobType = findJobTypeById(byId('active-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const machine = machineTransport ? machineSnapshot(byId('active-job-machine').value) : null;
    if (!jobType) {
      showStatus('active-form-status', 'Välj jobbtyp.', true);
      return;
    }
    const fromPlace = otherActivity ? null : resolveFormPlaceSelection('active', 'from');
    const destinationPlace = otherActivity ? null : resolveFormPlaceSelection('active', 'destination');
    const returnRequired = !otherActivity && byId('active-job-return-required').checked;
    const selectedReturnPlace = returnRequired ? findPlaceById(byId('active-job-return').value) : null;
    const returnPlace = returnRequired ? (selectedReturnPlace || fromPlace) : null;
    if (!otherActivity && (!fromPlace || !destinationPlace)) {
      showStatus('active-form-status', 'Välj jobbtyp, Från och Till.', true);
      return;
    }
    if (!otherActivity && !machineTransport
      && ((fromPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(fromPlace, jobType.id, 'from'))
        || (destinationPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(destinationPlace, jobType.id, 'destination')))) {
      showStatus('active-form-status', 'Från eller Till är inte kopplad till vald Jobbtyp i Platsregistret. Välj en giltig kombination.', true);
      return;
    }
    if (activeJobStartInProgress) {
      showStatus('active-form-status', 'Startpositionen fastställs redan för ett uppdrag.', true);
      return;
    }
    activeJobStartInProgress = true;
    if (!otherActivity && initialPhaseNeedsGps(fromPlace)) {
      showStatus('active-form-status', 'Appen fastställer startpositionen innan uppdraget startas.');
    }
    let initialPhase;
    try {
      initialPhase = otherActivity
        ? { phase: phaseService.PHASES.OTHER_ACTIVITY, source: 'job-start', reason: 'other_activity_started' }
        : await determineInitialPhaseForPlace(fromPlace);
    } finally {
      activeJobStartInProgress = false;
    }
    if (activeJobExists()) {
      showStatus('active-form-status', 'Ett aktivt jobb blev tillgängligt medan startpositionen hämtades. Formuläret är oförändrat.', true);
      return;
    }
    const now = new Date().toISOString();
    const jobId = createLocalId('job');
    const otherActivityToPark = null;
    const temporaryPlaces = otherActivity ? {} : collectTemporaryPlaces('active');
    const rawDocument = {
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: jobId,
      jobId,
      status: 'active',
      phase: initialPhase.phase,
      source: 'manual-local',
      jobTypeId: jobType.id,
      jobTypeName: jobType.name,
      fromPlaceId: text(fromPlace && fromPlace.id),
      fromPlaceName: text(fromPlace && fromPlace.name),
      destinationPlaceId: text(destinationPlace && destinationPlace.id),
      destinationPlaceName: text(destinationPlace && destinationPlace.name),
      returnPlaceId: returnPlace ? text(returnPlace.id) : '',
      returnPlaceName: returnPlace ? text(returnPlace.name) : '',
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : byId('active-job-multi-load').checked,
      ...(machineTransport ? { machine, machineLoads: machine ? [{ loadNumber: 1, machine }] : [] } : {}),
      ...(otherActivity ? {} : {
        currentLoadNumber: 1,
        loadCycles: [{ loadNumber: 1, loadingStartedAt: initialPhase.phase === phaseService.PHASES.LOADING ? now : '', outcome: 'open' }]
      }),
      ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
      material: otherActivity ? {} : deriveMaterialForSelections(jobType.id, fromPlace, destinationPlace),
      note: text(byId('active-job-note').value),
      ata: ataRouting.jobAtaSnapshot({
        enabled: byId('active-job-ata').checked,
        source: ataRouting.isManualJobType(jobType) ? 'manual-job-choice' : (ataRouting.jobTypeEnabled(jobType) ? 'job-type' : 'manual-job-choice'),
        recipient: ensureAtaRecipientContact(ataRecipientInput('active'), 'manual-job-choice', 'active-form-status') || (byId('active-job-ata').checked ? ataRouting.defaultRecipient(jobType) : null),
        timestamp: now
      }),
      startedAt: now,
      workSegments: [{ segmentNumber: 1, startedAt: now, endedAt: '', endReason: '', note: text(byId('active-job-note').value) }],
      continuationCount: 0,
      updatedAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: { createdRole: text(hostInfo.role), createdRoleLabel: text(hostInfo.roleLabel), createdDeviceId: text(hostInfo.deviceId), modelVersion: JOB_MODEL_VERSION },
      events: [{ type: otherActivity ? 'other_activity_started' : 'job_started', at: now, source: 'manual', packageVersion: PACKAGE_VERSION }]
    };
    if (Object.keys(temporaryPlaces).length) rawDocument.temporaryPlaces = temporaryPlaces;
    let nextDocument = normalizeJobRecord(rawDocument, 'active');
    nextDocument = phaseService.initializeRecord(nextDocument, initialPhase.phase, now, initialPhase.reason, initialPhase.source);
    if (persistActiveJob(nextDocument, otherActivity
      ? 'Övrig verksamhet startades som användarens tidsrapportering och sparades lokalt.'
      : (otherActivityToPark ? 'ÖV pausades automatiskt och uppdraget startades lokalt.' : 'Uppdraget startades med gemensam uppdragsmodell och sparades lokalt.'))) {
      resetLocalJobForm();
      activateView('active');
    }
  }

  function resetLocalJobForm() {
    byId('active-form').reset();
    resetTemporaryPlaceForm('active');
    refreshPlaceFormsForJobType('active-');
    syncJobModeControls('active');
    clearAtaRecipient('active');
    syncAtaForm('active', true);
    updateMaterialPanel('active-');
    syncLocalJobActions();
  }

  function createLocalQueueItem() {
    if (!isVehicleRole() || localQueueCreateInProgress) return;
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('active-form-status', 'Kön måste kunna läsas innan uppdraget kan läggas i kö.', true);
      return;
    }
    localQueueCreateInProgress = true;
    syncLocalJobActions();
    try {
      const jobType = findJobTypeById(byId('active-job-type').value);
      const otherActivity = isOtherActivityJobType(jobType);
      const machineTransport = isMachineTransportJobType(jobType);
      const machine = machineTransport ? machineSnapshot(byId('active-job-machine').value) : null;
      const fromPlace = otherActivity ? null : resolveFormPlaceSelection('active', 'from');
      const destinationPlace = otherActivity ? null : resolveFormPlaceSelection('active', 'destination');
      const returnRequired = !otherActivity && byId('active-job-return-required').checked;
      const selectedReturnPlace = returnRequired ? findPlaceById(byId('active-job-return').value) : null;
      const returnPlace = returnRequired ? (selectedReturnPlace || fromPlace) : null;
      if (!jobType || (!otherActivity && (!fromPlace || !destinationPlace))) {
        showStatus('active-form-status', otherActivity ? 'Välj jobbtyp.' : 'Välj jobbtyp, Från och Till.', true);
        return;
      }
      if (!otherActivity && !machineTransport
        && ((fromPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(fromPlace, jobType.id, 'from'))
          || (destinationPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(destinationPlace, jobType.id, 'destination')))) {
        showStatus('active-form-status', 'Från eller Till är inte kopplad till vald Jobbtyp i Platsregistret. Välj en giltig kombination.', true);
        return;
      }
      const now = new Date().toISOString();
      const jobId = createLocalId('job');
      const temporaryPlaces = otherActivity ? {} : collectTemporaryPlaces('active');
      const rawItem = {
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: jobId,
        jobId,
        status: 'queued',
        source: 'manual-vehicle-local',
        jobTypeId: jobType.id,
        jobTypeName: jobType.name,
        fromPlaceId: text(fromPlace && fromPlace.id),
        fromPlaceName: text(fromPlace && fromPlace.name),
        destinationPlaceId: text(destinationPlace && destinationPlace.id),
        destinationPlaceName: text(destinationPlace && destinationPlace.name),
        returnPlaceId: returnPlace ? text(returnPlace.id) : '',
        returnPlaceName: returnPlace ? text(returnPlace.name) : '',
        returnRequired,
        multiLoad: otherActivity || returnRequired ? false : byId('active-job-multi-load').checked,
        ...(machineTransport ? { machine, machineLoads: machine ? [{ loadNumber: 1, machine }] : [] } : {}),
        material: otherActivity ? {} : deriveMaterialForSelections(jobType.id, fromPlace, destinationPlace),
        plannedDate: '',
        plannedTime: '',
        note: text(byId('active-job-note').value),
        createdAt: now,
        createdByPackageVersion: PACKAGE_VERSION,
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        metadata: { createdRole: text(hostInfo.role), createdRoleLabel: text(hostInfo.roleLabel), createdDeviceId: text(hostInfo.deviceId), modelVersion: JOB_MODEL_VERSION }
      };
      if (Object.keys(temporaryPlaces).length) rawItem.temporaryPlaces = temporaryPlaces;
      const recipient = ensureAtaRecipientContact(ataRecipientInput('active'), 'manual-job-choice', 'active-form-status');
      const ataSnapshot = ataRouting.jobAtaSnapshot({
        enabled: byId('active-job-ata').checked,
        source: ataRouting.isManualJobType(jobType) ? 'manual-job-choice' : (ataRouting.jobTypeEnabled(jobType) ? 'job-type' : 'manual-job-choice'),
        recipient: recipient || (byId('active-job-ata').checked ? ataRouting.defaultRecipient(jobType) : null),
        timestamp: now
      });
      if (ataSnapshot) rawItem.ata = ataSnapshot;
      const item = normalizeJobRecord(rawItem, 'job');
      if (persistQueue([...queueDocument, item], 'Uppdraget är sparat i 189:s operativa kö.')) {
        resetLocalJobForm();
        activateView('queue');
        showStatus('queue-load-status', 'Uppdraget är sparat i kön.');
      }
    } finally {
      localQueueCreateInProgress = false;
      syncLocalJobActions();
    }
  }

  function completeActiveReturnUnloading() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.status !== 'active'
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.RETURN_UNLOADING) {
      showStatus('active-action-status', 'Aktivt jobb väntar inte på genomförd returlossning.', true);
      return;
    }
    const now = new Date().toISOString();
    let nextDocument = buildPhaseTransitionDocument(
      activeJobDocument,
      phaseService.PHASES.READY_TO_COMPLETE,
      now,
      'manual_return_unloading_completed',
      'manual'
    );
    nextDocument = phaseActionService.markReturnUnloadingCompleted(nextDocument, now, PACKAGE_VERSION);
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, 'Returlossningen är registrerad. Uppdraget är redo att avslutas manuellt med Klart.');
  }

  function advanceActivePhase() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Fasåtgärden kan bara användas när uppdraget är aktivt.', true);
      return;
    }
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    const phaseControl = activePhaseControl(currentPhase, activeJobDocument.status, activeJobDocument.returnRequired === true, isOtherActivity(activeJobDocument));
    if (phaseControl.action === phaseActionService.ACTIONS.START_LOADING) {
      const now = new Date().toISOString();
      const nextDocument = buildPhaseTransitionDocument(activeJobDocument, phaseService.PHASES.LOADING, now, 'manual_start_route_completed', 'manual');
      persistActiveJob(nextDocument, 'Lastning aktiverades manuellt och sparades lokalt.');
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.REGISTER_WEIGHT) {
      focusActiveWeightInput();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.SHOW_LOAD_REGISTERED) {
      showStatus('active-action-status', 'Lasset är registrerat. Nästa fas aktiveras automatiskt efter den korta mellanfasen.');
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.ARRIVE_RETURN) {
      markActiveReturnArrived();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.COMPLETE_RETURN_UNLOADING) {
      completeActiveReturnUnloading();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.REQUEST_COMPLETE) {
      requestActiveComplete();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.START_NEXT_LOAD) {
      startNextActiveLoad();
      return;
    }

    let nextPhase = '';
    let reason = '';
    if (phaseControl.action === phaseActionService.ACTIONS.COMPLETE_LOADING) {
      nextPhase = phaseService.PHASES.TRANSPORT;
      reason = 'manual_loading_completed';
    } else if (phaseControl.action === phaseActionService.ACTIONS.ARRIVE_DESTINATION) {
      nextPhase = phaseService.PHASES.UNLOADING;
      reason = 'manual_arrival_registered';
    } else {
      showStatus('active-action-status', 'Den manuella fasfunktionen är inte aktuell i denna fas.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, nextPhase, now, reason, 'manual');
    persistActiveJob(nextDocument, nextPhase === phaseService.PHASES.TRANSPORT
      ? 'Transport påbörjades och sparades lokalt.'
      : (isSeaweedToBeach(activeJobDocument) ? 'Framme vid badplats registrerades manuellt och sparades lokalt.' : 'Lossning påbörjades och sparades lokalt.'));
  }

  function startNextActiveLoad() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.multiLoad !== true) {
      showStatus('active-action-status', 'Uppdraget är inte markerat som Flerlass.', true);
      return;
    }
    if (activeJobDocument.returnRequired === true) {
      showStatus('active-action-status', 'Retur och Flerlass kan inte vara aktiva samtidigt i detta flöde.', true);
      return;
    }
    const phase = phaseService.normalizePhase(activeJobDocument.phase);
    if (activeJobDocument.status !== 'active' || phase !== phaseService.PHASES.READY_TO_COMPLETE) {
      showStatus('active-action-status', 'Nästa transport kan påbörjas först när aktuellt lass är registrerat och redo.', true);
      return;
    }
    if (!currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-action-status', 'Registrera vikt eller Ingen tömning för aktuellt lass innan nästa transport.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextNumber = currentLoadNumber(activeJobDocument) + 1;
    const cycles = activeLoadCycles(activeJobDocument);
    let nextDocument = {
      ...activeJobDocument,
      currentLoadNumber: nextNumber,
      loadCycles: [...cycles, { loadNumber: nextNumber, loadingStartedAt: '', outcome: 'open' }],
      noEmptying: false,
      noEmptyingAt: '',
      weightMissingConfirmed: false,
      weightOutcome: activeLoads(activeJobDocument).length > 0 ? 'registered' : 'missing',
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'next_transport_started', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber: nextNumber } : entry)
    };
    nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.START_ROUTE, now, 'manual_next_transport', 'manual', { loadNumber: nextNumber });
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, `Startsträcka för lass ${nextNumber} har påbörjats.`);
  }

  function startActiveReturn() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.returnRequired !== true
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.UNLOADING
      || activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Returen kan påbörjas först efter lossningen i ett returuppdrag.', true);
      return;
    }
    if (weightPolicy(activeJobDocument).mode === 'required' && !currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-action-status', 'Registrera vikt eller Ingen tömning innan returen påbörjas.', true);
      return;
    }
    const now = new Date().toISOString();
    const returnPlaceName = text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Från-plats'));
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, phaseService.PHASES.RETURN_TRANSPORT, now, 'manual_return_started', 'manual');
    persistActiveJob(nextDocument, `Retur till ${returnPlaceName} påbörjades manuellt.`);
  }

  function markActiveReturnArrived() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.returnRequired !== true
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.RETURN_TRANSPORT
      || activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Aktivt jobb väntar inte på ankomst till en returplats.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, phaseService.PHASES.RETURN_UNLOADING, now, 'manual_return_arrival', 'manual');
    persistActiveJob(nextDocument, `${text(activeJobDocument.returnPlaceName, 'Returplats')} är manuellt registrerad som nådd.`);
  }

  function pauseOrdinaryJobToQueue() {
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('active-action-status', 'Den operativa kön kunde inte läsas. Pausen stoppades och Aktivt jobb är oförändrat.', true);
      return;
    }

    const now = new Date().toISOString();
    const wasAlreadyPaused = text(activeJobDocument.status) === 'paused';
    const jobId = stableJobId(activeJobDocument, 'paused-job');
    const queueId = text(activeJobDocument.sourceQueueItemId, jobId);
    const pausedSegments = closeOpenWorkSegment(activeJobDocument, now, 'paused-to-queue');
    const { parkedOtherActivity: _parkedActivity, ...ordinaryJob } = activeJobDocument;
    const pausedQueueItem = normalizeJobRecord({
      ...ordinaryJob,
      id: queueId,
      jobId,
      status: 'paused',
      pausedAt: wasAlreadyPaused ? text(activeJobDocument.pausedAt, now) : now,
      pausedFromActive: true,
      pausedIntoQueueAt: now,
      workSegments: pausedSegments,
      continuationCount: Math.max(0, pausedSegments.length - 1),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(ordinaryJob, wasAlreadyPaused ? 'paused_job_moved_to_queue' : 'job_paused', now, 'manual', { movedToQueue: true })
    }, 'queue-active-pause');
    const nextQueue = [
      pausedQueueItem,
      ...queueDocument.filter((item, index) => displayQueueItem(item, index).jobId !== jobId)
    ];

    if (!persistQueue(nextQueue, 'Det pausade uppdraget placerades överst i 189:s operativa kö.')) {
      showStatus('active-action-status', 'Uppdraget kunde inte sparas i kön. Pausen stoppades och Aktivt jobb är oförändrat.', true);
      return;
    }

    const restoredOtherActivity = restoreOtherActivityAfterJob(activeJobDocument, now);
    if (!persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Uppdraget pausades till kön och Övrig verksamhet är nu synligt aktiv.'
        : 'Uppdraget pausades till kön. Manuellt pausad Övrig verksamhet är synligt bevarad utan automatisk återstart.')
      : 'Uppdraget pausades och flyttades överst i kön.')) {
      showStatus('active-action-status', 'Kökopian är säkert sparad, men Aktivt jobb kunde inte växlas. Tryck Pausa igen för att slutföra flytten utan dubblett.', true);
      return;
    }

    showStatus('active-load-status', restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Övrig verksamhet fortsätter synligt. Det pausade uppdraget ligger överst i kön.'
        : 'Övrig verksamhet är fortsatt manuellt pausad. Det pausade uppdraget ligger överst i kön.')
      : 'Inget aktivt jobb finns. Det pausade uppdraget ligger överst i kön och ett annat uppdrag kan startas.');
  }

  function toggleActivePause() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status === 'completing') {
      showStatus('active-action-status', 'Ett väntande avslut kan inte pausas eller fortsättas.', true);
      return;
    }
    if (!isOtherActivity(activeJobDocument) && ['active', 'paused'].includes(activeJobDocument.status)) {
      pauseOrdinaryJobToQueue();
      return;
    }
    const nextStatus = activeJobDocument.status === 'paused' ? 'active' : 'paused';
    const now = new Date().toISOString();
    const pausePeriods = Array.isArray(activeJobDocument.pausePeriods) ? activeJobDocument.pausePeriods.filter(isPlainObject) : [];
    const pausedFrom = text(activeJobDocument.pausedAt);
    const completedPause = nextStatus === 'active' && pausedFrom ? { from: pausedFrom, to: now } : null;
    const pausedTotalMs = Number(activeJobDocument.pausedTotalMs) || 0;
    const completedPauseMs = completedPause ? Math.max(0, new Date(now).getTime() - new Date(pausedFrom).getTime()) : 0;
    const nextWorkSegments = nextStatus === 'paused'
      ? closeOpenWorkSegment(activeJobDocument, now, 'paused')
      : resumeWorkSegment(activeJobDocument, now);
    const otherActivity = isOtherActivity(activeJobDocument);
    const parkedActivity = parkedOtherActivity(activeJobDocument);
    const nextParkedActivity = parkedActivity
      ? (nextStatus === 'paused'
        ? resumeOtherActivityAutomatically(parkedActivity, now, stableJobId(activeJobDocument, 'paused-job'))
        : pauseOtherActivityAutomatically(parkedActivity, now, stableJobId(activeJobDocument, 'resumed-job')))
      : null;
    const nextDocument = {
      ...activeJobDocument,
      status: nextStatus,
      pausedAt: nextStatus === 'paused' ? now : '',
      ...(otherActivity ? {
        pauseMode: nextStatus === 'paused' ? 'manual' : '',
        autoResumeEligible: false,
        autoPausedForJobId: ''
      } : {}),
      ...(nextParkedActivity ? { parkedOtherActivity: nextParkedActivity } : {}),
      pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
      pausedTotalMs: pausedTotalMs + completedPauseMs,
      workSegments: nextWorkSegments,
      continuationCount: Math.max(0, nextWorkSegments.length - 1),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, nextStatus === 'paused' ? 'job_paused' : 'job_resumed', now)
    };
    persistActiveJob(nextDocument, nextStatus === 'paused'
      ? (nextParkedActivity && nextParkedActivity.status === 'active'
        ? 'Uppdraget pausades och Övrig verksamhet återupptogs automatiskt.'
        : (otherActivity ? 'Övrig verksamhet pausades manuellt och återstartas inte automatiskt.' : 'Uppdraget pausades och sparades lokalt.'))
      : (nextParkedActivity && nextParkedActivity.status === 'paused' && nextParkedActivity.autoResumeEligible === true
        ? 'Uppdraget fortsätter och Övrig verksamhet pausades automatiskt.'
        : (otherActivity ? 'Övrig verksamhet fortsätter och sparades lokalt.' : 'Uppdraget fortsätter och sparades lokalt.')));
  }

  function requestActiveReset() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      return;
    }
    const previousScrollY = currentScrollY();
    pendingActiveReset = true;
    renderActiveJob();
    revealInlineControl('#active-reset-confirm', previousScrollY);
    showStatus('active-action-status', 'Bekräfta avbrottet eller avbryt.');
  }

  function cancelActiveReset() {
    const previousScrollY = currentScrollY();
    pendingActiveReset = false;
    renderActiveJob();
    preserveScrollAfterRender(previousScrollY);
    showStatus('active-action-status', 'Avbrottet avbröts. Aktivt jobb är oförändrat.');
  }

  function confirmActiveReset() {
    if (!pendingActiveReset || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avbrottet kunde inte bekräftas.', true);
      return;
    }
    const queueSnapshot = isPlainObject(activeJobDocument.sourceQueueSnapshot) ? activeJobDocument.sourceQueueSnapshot : null;
    const restoredAt = new Date().toISOString();
    if (queueSnapshot) {
      if (!queueLoaded) loadQueueIfNeeded();
      if (!queueLoaded) {
        pendingActiveReset = false;
        renderActiveJob();
        showStatus('active-action-status', 'Den operativa kön kunde inte läsas. Avbrottet stoppades och Aktivt jobb är bevarat.', true);
        return;
      }
      const jobId = stableJobId(activeJobDocument, 'active-abort');
      const alreadyRestored = queueDocument.some((item, index) => displayQueueItem(item, index).jobId === jobId);
      if (!alreadyRestored) {
        const restored = normalizeJobRecord({
          ...queueSnapshot,
          id: text(activeJobDocument.sourceQueueItemId, text(queueSnapshot.id, jobId)),
          jobId,
          status: 'queued',
          restoredFromActiveAbortAt: restoredAt,
          restoredByPackageVersion: PACKAGE_VERSION
        }, 'queue-abort-restore');
        if (!persistQueue([...queueDocument, restored], 'Det avbrutna uppdraget återställdes i 189:s operativa kö.')) {
          pendingActiveReset = false;
          renderActiveJob();
          showStatus('active-action-status', 'Uppdraget kunde inte återställas i kön. Avbrottet stoppades och Aktivt jobb är bevarat.', true);
          return;
        }
      }
    }
    const restoredOtherActivity = restoreOtherActivityAfterJob(activeJobDocument, restoredAt);
    if (persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? 'Uppdraget avbröts och Övrig verksamhet återställdes säkert.'
      : (queueSnapshot ? 'Uppdraget avbröts och är återställt i 189:s operativa kö.' : 'Det manuellt startade uppdraget avbröts. Ingen historik ändrades.'))) {
      showStatus('active-load-status', restoredOtherActivity
        ? (restoredOtherActivity.status === 'active' ? 'Övrig verksamhet fortsätter efter avbrottet.' : 'Övrig verksamhet är fortsatt manuellt pausad efter avbrottet.')
        : (queueSnapshot ? 'Inget aktivt jobb finns. Uppdraget ligger åter i 189:s operativa kö.' : 'Det manuellt startade uppdraget avbröts. Inget aktivt jobb finns.'));
    }
  }

  function historyItemDisplay(rawItem, index) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    return {
      id: text(item.id, `history-${index}`),
      jobId: text(item.jobId, text(item.sourceJobId, text(item.id))),
      jobTypeId: text(item.jobTypeId),
      jobType: text(item.jobTypeName, text(item.jobType, 'Uppdrag')),
      legacyDisplayType: text(item.archiveSource && item.archiveSource.sourceDisplayType, text(item.sourceDisplayType)),
      otherActivity: isOtherActivity(item),
      from: text(item.fromPlaceName, text(item.from, 'Från saknas')),
      fromPlaceId: text(item.fromPlaceId),
      destination: text(item.destinationPlaceName, text(item.destination, 'Till saknas')),
      destinationPlaceId: text(item.destinationPlaceId),
      returnPlaceName: text(item.returnPlaceName),
      returnRequired: item.returnRequired === true,
      material: isPlainObject(item.material) ? item.material : {},
      note: text(item.note),
      modelVersion: Number(item.jobModelVersion) || 1,
      startedAt: text(item.startedAt),
      completedAt: text(item.completedAt),
      status: text(item.status, 'completed'),
      loads: Array.isArray(item.loads) ? item.loads : [],
      totalWeight: Number(item.totalWeight) || 0,
      weightOutcome: text(item.weightOutcome),
      multiLoad: item.multiLoad === true,
      machine: isPlainObject(item.machine) ? text(item.machine.name) : '',
      machineLoads: Array.isArray(item.machineLoads) ? item.machineLoads.filter(isPlainObject) : [],
      loadCycles: Array.isArray(item.loadCycles) ? item.loadCycles.filter(isPlainObject) : [],
      workSegments: Array.isArray(item.workSegments) ? item.workSegments.filter(isPlainObject) : [],
      continuationCount: Number(item.continuationCount) || 0,
      archiveReadOnly: false,
      archiveSource: isHistoryArchiveSource(item),
      receiptImported: isReceiptImportedHistoryItem(item),
      receiptRowId: text(item.receiptRowId),
      receiptRegistryLinked: Boolean(text(item.jobTypeId) && text(item.fromPlaceId) && text(item.destinationPlaceId)),
      receiptRegistryReferenceMissing: item.receiptRegistryReferenceMissing === true,
      receiptTime: text(item.receiptTime),
      facility: text(item.facility),
      likelyAta: text(item.likelyAta),
      estimatedTimeWindow: isPlainObject(item.estimatedTimeWindow) ? item.estimatedTimeWindow : null,
      trashState: isPlainObject(item.trashState) ? item.trashState : {},
      ataEnabled: !isReceiptImportedHistoryItem(item) && ataApi.isEnabled(item),
      billing: !isReceiptImportedHistoryItem(item) ? ataBillingApi.snapshotFromRecord(item) : null
    };
  }

  function historyEditDateTimeValue(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    const pad = (number) => String(number).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function historyEditIsoValue(value) {
    const raw = text(value);
    if (!raw) return '';
    const date = new Date(raw);
    return Number.isNaN(date.getTime()) ? '' : date.toISOString();
  }

  function historyWeightEdit(record, weight) {
    const loads = Array.isArray(record.loads) ? record.loads.slice() : [];
    if (loads.length === 1) {
      loads[0] = isPlainObject(loads[0]) ? { ...loads[0], weight } : weight;
    }
    const loadCycles = Array.isArray(record.loadCycles) ? record.loadCycles.map((cycle) => ({ ...cycle })) : [];
    if (loadCycles.length === 1) loadCycles[0].weight = weight;
    return { totalWeight: weight, loads, loadCycles };
  }

  function isHistoryItemTrashed(item) {
    return isPlainObject(item)
      && isPlainObject(item.trashState)
      && text(item.trashState.status) === 'trashed';
  }

  function historyArchiveSourceId(item) {
    return historyArchiveApi ? historyArchiveApi.sourceId(item) : '';
  }

  function isHistoryArchiveSource(item) {
    return Boolean(historyArchiveSourceId(item));
  }

  function isHistoryArchiveControl(item) {
    return Boolean(historyArchiveApi && historyArchiveApi.isControl(item));
  }

  function effectiveHistoryArchiveRecords(forLearning = false) {
    const source = forLearning && historyArchiveApi ? historyArchiveApi.learningRecords() : historyArchiveRecords;
    return historyArchiveApi ? Array.from(historyArchiveApi.effective(source, historyDocument)) : [];
  }

  function writableHistoryRecord(id) {
    const key = text(id);
    const localIndex = historyItemIndexById(key);
    if (localIndex >= 0) return { record: historyDocument[localIndex], index: localIndex, fromArchive: false };
    const archive = historyArchiveRecords.find((item) => historyArchiveSourceId(item) === key);
    return archive ? { record: archive, index: -1, fromArchive: true } : null;
  }

  function materializeHistoryArchiveRecord(record) {
    return historyArchiveApi.materialize(record, new Date().toISOString(), PACKAGE_VERSION);
  }

  function replaceOrAppendHistoryRecord(resolved, updated) {
    if (resolved.index >= 0) return historyDocument.map((item, index) => index === resolved.index ? updated : item);
    return historyDocument.concat(updated);
  }

  function activeHistoryEntries() {
    const ordinary = historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => !isHistoryArchiveControl(item) && !isHistoryItemTrashed(item));
    const receiptOffset = historyDocument.length;
    const receipts = receiptRows().map((rawRow, index) => { const row=resolvedReceiptRow(rawRow); const item=receiptApi.projection(row, receiptEstimateMinutes(row)); item.receiptRegistryReferenceMissing=row.registryReferenceMissing===true; return { item, index: receiptOffset + index }; });
    const archiveOffset = receiptOffset + receipts.length;
    const archive = effectiveHistoryArchiveRecords(false).map((item, index) => ({ item, index: archiveOffset + index }));
    return ordinary.concat(receipts, archive);
  }

  // P166: Statistik och tidsinlärning läser enbart Host24:s category=history.
  // Vanliga poster, kvittoposter och v419-arkivposter ligger alla i den kategorin.
  // Ingen JSON-källa eller legacy-projektion får blandas in här.
  function nativeHistoryEntries({ forLearning = false } = {}) {
    const ordinary = historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => !isHistoryArchiveControl(item) && !isHistoryItemTrashed(item));
    const receiptOffset = historyDocument.length;
    const receipts = receiptRows().map((rawRow, index) => {
      const row = resolvedReceiptRow(rawRow);
      const item = receiptApi.projection(row, receiptEstimateMinutes(row));
      item.receiptRegistryReferenceMissing = row.registryReferenceMissing === true;
      return { item, index: receiptOffset + index };
    });
    let archived = [];
    try {
      const source = nativeStorage && nativeStorage.isActive && nativeStorage.isActive()
        ? Array.from(nativeStorage.archiveRecords())
        : [];
      archived = historyArchiveApi
        ? Array.from(historyArchiveApi.effective(source, historyDocument))
        : source;
    } catch (error) {
      watchdog.step('runtime.native-storage.history-archive.read-failed', error.message || 'Native arkivhistorik kunde inte läsas.', 'warning');
    }
    const archiveOffset = receiptOffset + receipts.length;
    const archive = archived.map((item, index) => ({ item, index: archiveOffset + index }));
    const all = ordinary.concat(receipts, archive);
    return forLearning
      ? all.filter(({ item }) => !isReceiptImportedHistoryItem(item))
      : all;
  }

  function trashedHistoryEntries() {
    return historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => !isHistoryArchiveControl(item) && isHistoryItemTrashed(item))
      .sort((a, b) => new Date(text(b.item.trashState.trashedAt)).getTime() - new Date(text(a.item.trashState.trashedAt)).getTime());
  }

  function historyRouteText(item) {
    if (item.otherActivity) return 'Användarens tidsrapportering';
    return item.returnRequired
      ? `${item.from} → ${item.destination} → ${item.returnPlaceName || item.from}`
      : `${item.from} → ${item.destination}`;
  }

  function durationText(startedAt, completedAt) {
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return 'Tid saknas';
    const minutes = Math.max(0, Math.round((end - start) / 60000));
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    return hours > 0 ? `${hours} h ${rest} min` : `${rest} min`;
  }

  function durationMinutes(startedAt, completedAt) {
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    return Number.isFinite(start) && Number.isFinite(end) && end >= start ? Math.max(0, Math.round((end - start) / 60000)) : 0;
  }

  function workMinutes(item) {
    if (historyService) {
      const value = historyService.workMinutes(item);
      if (value !== null) return value;
    }
    if (!item.workSegments.length) return durationMinutes(item.startedAt, item.completedAt);
    return item.workSegments.reduce((sum, segment) => sum + durationMinutes(segment.startedAt, segment.endedAt || item.completedAt), 0);
  }

  function formatMinutes(minutes) {
    return minutes >= 60 ? `${Math.floor(minutes / 60)} h ${minutes % 60} min` : `${minutes} min`;
  }

  function statisticsMetrics(displayed) {
    return {
      jobs: displayed.length,
      loads: displayed.reduce((sum, item) => sum + item.loads.length, 0),
      weight: displayed.reduce((sum, item) => sum + item.totalWeight, 0),
      minutes: displayed.reduce((sum, item) => sum + (isReceiptImportedHistoryItem(item) ? 0 : workMinutes(item)), 0)
    };
  }

  function renderSummaryMetrics(prefix, metrics) {
    byId(`${prefix}-summary-jobs`).textContent = String(metrics.jobs);
    byId(`${prefix}-summary-loads`).textContent = String(metrics.loads);
    byId(`${prefix}-summary-weight`).textContent = `${metrics.weight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    byId(`${prefix}-summary-time`).textContent = formatMinutes(metrics.minutes);
  }

  function historySummary(items, prefix) {
    const displayed = items.map(({ item, index }) => historyItemDisplay(item, index));
    renderSummaryMetrics(prefix, statisticsMetrics(displayed));
  }

  function historySearchText(item) {
    return [item.jobType, item.machine, ...item.machineLoads.map((load) => text(load.machine && load.machine.name)), item.from, item.destination, item.returnPlaceName, item.note, item.material.code, item.material.facilityPlaceName]
      .filter(Boolean).join(' ').toLocaleLowerCase('sv-SE');
  }

  function localDateFromTimestamp(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : localDateKey(date);
  }

  function historyCalendarExplicitDate(rawItem) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    const candidates = [item.date, item.receiptDate, item.historyDate, item.completedDate];
    return candidates.map((value) => text(value)).find((value) => /^\d{4}-\d{2}-\d{2}$/.test(value)) || '';
  }

  function historyCalendarDateKey(rawItem, index) {
    const explicitDate = historyCalendarExplicitDate(rawItem);
    if (explicitDate) return explicitDate;
    const item = isPlainObject(rawItem) ? rawItem : {};
    const displayed = historyItemDisplay(item, index);
    const timestamp = displayed.completedAt || text(item.endAt) || text(item.end) || displayed.startedAt;
    return localDateFromTimestamp(timestamp);
  }

  function isReceiptImportedHistoryItem(rawItem) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    if (item.receiptImported === true || item.kvittoImported === true || item.kvittoimporterad === true) return true;
    if (text(item.receiptRowId) || /^receipt[_-]/i.test(text(item.id))) return true;
    const source = [item.source, item.historySource, item.importSource, item.kind, item.recordType]
      .map((value) => text(value).toLocaleLowerCase('sv-SE'))
      .filter(Boolean).join(' ');
    return source.includes('receipt-import') || source.includes('receipt_import') || source.includes('kvittoimport');
  }

  function isAtaHistoryItem(rawItem) {
    return !isReceiptImportedHistoryItem(rawItem) && ataApi.isEnabled(rawItem);
  }

  function historyCalendarCountLabel(entries) {
    const list = Array.isArray(entries) ? entries : [];
    if (list.length === 0) return '';
    return list.length === 1 ? '1 jobb' : `${list.length} jobb`;
  }

  function historyCalendarShortDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
    const [, month, day] = value.split('-');
    return `${Number(day)}/${Number(month)}`;
  }

  function historyCalendarWeekdayLabel(date) {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
    if (date.getDay() === 0) return 'Söndag';
    const value = new Intl.DateTimeFormat('sv-SE', { weekday: 'short' }).format(date).replace('.', '');
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : '';
  }

  function currentMonthKey(date = new Date()) {
    return localDateKey(date).slice(0, 7);
  }

  function normalizedHistoryMonth(value) {
    return /^\d{4}-\d{2}$/.test(text(value)) ? text(value) : currentMonthKey();
  }

  function ensureHistoryCalendarSelection() {
    const monthInput = byId('history-month');
    const today = localDateKey(new Date());
    const todayMonth = today.slice(0, 7);
    const month = normalizedHistoryMonth(monthInput && monthInput.value ? monthInput.value : historySelectedMonth);
    historySelectedMonth = month;
    if (monthInput && monthInput.value !== month) monthInput.value = month;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(historySelectedDate) || historySelectedDate.slice(0, 7) !== month) {
      historySelectedDate = month === todayMonth ? today : `${month}-01`;
    }
    return { month, today, todayMonth };
  }

  function renderHistoryCalendar(sortedEntries) {
    const grid = byId('history-calendar-grid');
    const info = byId('history-calendar-selected-info');
    if (!grid || !info) return [];
    const { month, today } = ensureHistoryCalendarSelection();
    const [year, monthNumber] = month.split('-').map(Number);
    const first = new Date(year, monthNumber - 1, 1, 12, 0, 0);
    const firstOffset = (first.getDay() + 6) % 7;
    const lastDay = new Date(year, monthNumber, 0, 12, 0, 0).getDate();
    const entriesByDate = new Map();
    (Array.isArray(sortedEntries) ? sortedEntries : []).forEach((entry) => {
      const dateKey = historyCalendarDateKey(entry.item, entry.index);
      if (!dateKey || dateKey.slice(0, 7) !== month) return;
      if (!entriesByDate.has(dateKey)) entriesByDate.set(dateKey, []);
      entriesByDate.get(dateKey).push(entry);
    });

    const fragment = document.createDocumentFragment();
    for (let index = 0; index < firstOffset; index += 1) {
      const empty = document.createElement('div');
      empty.className = 'history-calendar-day empty';
      empty.setAttribute('aria-hidden', 'true');
      fragment.appendChild(empty);
    }
    for (let day = 1; day <= lastDay; day += 1) {
      const dateKey = `${year}-${String(monthNumber).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const date = new Date(year, monthNumber - 1, day, 12, 0, 0);
      const entries = entriesByDate.get(dateKey) || [];
      const label = historyCalendarCountLabel(entries);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'history-calendar-day';
      button.dataset.historyCalendarDate = dateKey;
      button.setAttribute('role', 'gridcell');
      button.setAttribute('aria-pressed', dateKey === historySelectedDate ? 'true' : 'false');
      button.setAttribute('aria-label', `${formatDate(dateKey) || dateKey}. ${label || 'Inga uppdrag'}.`);
      if (dateKey === historySelectedDate) button.classList.add('selected');
      if (dateKey === today) button.classList.add('is-today');
      if (entries.length > 0) button.classList.add('has-jobs');
      if (entries.some(({ item }) => isAtaHistoryItem(item))) button.classList.add('has-ata');
      if (Array.isArray(settingsDocument.ataDailyMailDraftDates) && settingsDocument.ataDailyMailDraftDates.includes(dateKey)) button.classList.add('has-daily-mail-draft');
      const individualAta = entries.map(({ item }) => item).filter((item) => ataMailApi && ataMailApi.isEligible(item));
      if (individualAta.length && individualAta.every((item) => ataMailApi.status(item).lastAction === ataMailApi.ACTIONS.OPENED)) button.classList.add('has-individual-ata-mail-drafts');
      const number = document.createElement('span');
      number.textContent = String(day);
      const sub = document.createElement('small');
      sub.textContent = label || historyCalendarWeekdayLabel(date);
      button.append(number, sub);
      fragment.appendChild(button);
    }
    grid.replaceChildren(fragment);

    const selected = entriesByDate.get(historySelectedDate) || [];
    const selectedLabel = historyCalendarCountLabel(selected) || 'Inga uppdrag';
    info.textContent = `Valt datum: ${historyCalendarShortDate(historySelectedDate)} · ${selectedLabel}.`;
    return selected;
  }

  function selectHistoryCalendarDate(value) {
    const dateKey = text(value);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return;
    historySelectedDate = dateKey;
    historySelectedMonth = dateKey.slice(0, 7);
    const monthInput = byId('history-month');
    if (monthInput) monthInput.value = historySelectedMonth;
    renderHistoryViews();
  }

  function showTodayInHistoryCalendar() {
    const today = localDateKey(new Date());
    historySelectedDate = today;
    historySelectedMonth = today.slice(0, 7);
    const monthInput = byId('history-month');
    if (monthInput) monthInput.value = historySelectedMonth;
    renderHistoryViews();
  }

  function createAtaUnderlagCard(rawItem, surface) {
    if (!ataMailApi || !ataMailApi.isEligible(rawItem)) return null;
    const underlag = ataMailApi.individual(rawItem, ataMailSettings().template);
    const card = document.createElement('section'); card.className = 'ata-underlag-card';
    const title = document.createElement('h4'); title.textContent = 'ÄTA-underlag';
    const recipient = document.createElement('p'); recipient.className = 'field-help'; recipient.textContent = `Till: ${ataMailApi.recipientText(underlag.recipient)}`;
    card.append(title, recipient);
    if (surface === 'today') {
      const status = document.createElement('p'); status.className = 'field-help'; status.textContent = `Status: ${ataMailApi.status(rawItem).label}`; card.appendChild(status);
    }
    const actions = document.createElement('div'); actions.className = 'ata-underlag-actions';
    const view = document.createElement('button'); view.type = 'button'; view.className = 'secondary-button'; view.textContent = surface === 'history' ? 'Visa uppdrag' : 'Visa underlag'; view.dataset.ataUnderlagView = rawItem.id; view.dataset.ataUnderlagSurface = surface; actions.appendChild(view);
    if (surface === 'today') {
      const open = document.createElement('button'); open.type = 'button'; open.className = 'primary-button'; open.textContent = 'Öppna mailutkast'; open.dataset.ataUnderlagOpen = rawItem.id;
      const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'secondary-button'; copy.textContent = 'Kopiera underlag'; copy.dataset.ataUnderlagCopy = rawItem.id;
      actions.append(open, copy);
    }
    card.appendChild(actions); return card;
  }

  function createAtaDailyCard(entries, day) {
    if (!ataMailApi) return null;
    const underlag = ataMailApi.daily(entries.map(({ item }) => item), day, ataMailSettings().supervisor);
    if (!underlag.jobs.length) return null;
    const card = document.createElement('section'); card.className = 'ata-daily-card';
    const title = document.createElement('h4'); title.textContent = 'ÄTA-dagsmail';
    const info = document.createElement('p'); info.className = 'field-help'; info.textContent = `${day} · ${underlag.jobs.length} ÄTA-uppdrag · Debiterbar tid: ${ataMailApi.minutes(underlag.totalMinutes)} · Total vikt: ${ataMailApi.decimal(underlag.totalWeight)} ton`;
    const recipient = document.createElement('p'); recipient.className = 'field-help'; recipient.textContent = `Till: ${ataMailApi.recipientText(underlag.recipient)}`;
    const actions = document.createElement('div'); actions.className = 'ata-underlag-actions';
    const view = document.createElement('button'); view.type = 'button'; view.className = 'secondary-button'; view.textContent = 'Visa dagsunderlag'; view.dataset.ataDailyView = day;
    const open = document.createElement('button'); open.type = 'button'; open.className = 'primary-button'; open.textContent = 'Öppna mailutkast'; open.dataset.ataDailyOpen = day; open.disabled = !underlag.recipient.valid;
    const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'secondary-button'; copy.textContent = 'Kopiera dagsunderlag'; copy.dataset.ataDailyCopy = day;
    actions.append(view, open, copy); card.append(title, info, recipient, actions); return card;
  }

  function createHistoryCard(rawItem, index, options = {}) {
    const item = historyItemDisplay(rawItem, index);
    const trashMode = options.mode === 'trash';
    const readOnly = options.readOnly === true;
    const card = document.createElement('article');
    card.className = `queue-card history-card${trashMode ? ' trash-card' : ''}`;
    card.dataset.historyCardId = item.id;
    const heading = document.createElement('h3');
    heading.textContent = item.jobType;
    const route = document.createElement('p');
    route.className = 'queue-route';
    route.textContent = historyRouteText(item);
    const meta = document.createElement('div');
    meta.className = 'queue-meta';
    if (trashMode) {
      meta.appendChild(queueMetaChip(`Raderad: ${formatTimestamp(text(item.trashState.trashedAt))}`, 'trash-chip'));
    }
    if (item.ataEnabled) meta.appendChild(queueMetaChip('ÄTA', 'ata-chip'));
    if (item.receiptImported) meta.appendChild(queueMetaChip('Kvittoimporterad', 'model-chip'));
    if (item.receiptImported && !item.receiptRegistryLinked) meta.appendChild(queueMetaChip('Äldre kvitto – saknar registerkoppling'));
    else if (item.receiptImported && item.receiptRegistryReferenceMissing) meta.appendChild(queueMetaChip('Registerreferens saknas'));
    meta.appendChild(queueMetaChip(formatTimestamp(item.completedAt)));
    if (item.receiptImported) {
      if (item.receiptTime) meta.appendChild(queueMetaChip(`Kvittotid: ${item.receiptTime}`));
      meta.appendChild(queueMetaChip(item.estimatedTimeWindow ? `Uppskattad tid: ${item.estimatedTimeWindow.minutes} min` : 'Snittid saknas'));
      meta.appendChild(queueMetaChip('Källa: Kvittoimport'));
    } else meta.appendChild(queueMetaChip(`Tid: ${historyService ? historyService.formatMinutes(historyService.workMinutes(rawItem)) : formatMinutes(workMinutes(item))}`));
    if (item.billing) meta.appendChild(queueMetaChip(`Debiterbar tid: ${ataBillingApi.formatMinutes(item.billing.minutes)}`, 'ata-chip'));
    if (item.returnPlaceName) meta.appendChild(queueMetaChip(`Retur: ${item.returnPlaceName}`));
    const historyMaterial = [text(item.material.code), text(item.material.facilityPlaceName)].filter(Boolean).join(' · ');
    if (historyMaterial) meta.appendChild(queueMetaChip(`Mtrl: ${historyMaterial}`));
    if (canonicalJobTypeId(item.jobTypeId) === 'JT-1010') {
      const roleLabel = text(rawItem && rawItem.havstangWeightRoleLabel);
      meta.appendChild(queueMetaChip(item.destinationPlaceId === 'PL-1007' ? 'Havstång: Inkörning till Bio' : 'Havstång: Badplats/mellankörning', 'model-chip'));
      if (roleLabel && item.loads.length > 0) meta.appendChild(queueMetaChip(roleLabel));
    }
    if (item.multiLoad) meta.appendChild(queueMetaChip(`Flerlass: ${item.loads.length} lass`, 'model-chip'));
    if (item.continuationCount > 0) meta.appendChild(queueMetaChip(`Fortsättning: ${item.continuationCount}`, 'model-chip'));
    if (item.loads.length > 0) meta.appendChild(queueMetaChip(`Vikt: ${item.totalWeight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`));
    else if (item.weightOutcome === 'no-emptying') meta.appendChild(queueMetaChip('Ingen tömning'));
    else if (item.weightOutcome === 'missing-confirmed') meta.appendChild(queueMetaChip('Utan vikt'));
    card.append(heading, route, meta);
    if (item.note) { const note = document.createElement('p'); note.className = 'queue-note'; note.textContent = item.note; card.appendChild(note); }
    const details = document.createElement('details');
    details.className = 'history-details';
    const summary = document.createElement('summary');
    summary.textContent = 'Visa detaljer';
    const detailGrid = document.createElement('div');
    detailGrid.className = 'history-detail-grid';
    const detailRows = item.receiptImported ? [
      ['Kvittotid', item.receiptTime || 'Saknas'],
      ['Uppskattad start', item.estimatedTimeWindow ? formatTimestamp(item.estimatedTimeWindow.start) : 'Saknas'],
      ['Uppskattat slut', item.estimatedTimeWindow ? formatTimestamp(item.estimatedTimeWindow.end) : 'Saknas'],
      ['Anläggning', item.facility || 'Saknas'],
      ['Trolig ÄTA', item.likelyAta || 'Saknas'],
      ['Källa', 'Kvittoimport']
    ] : [
      ['Start', formatTimestamp(item.startedAt)],
      ['Avslut', formatTimestamp(item.completedAt)],
      ['Total tid', durationText(item.startedAt, item.completedAt)],
      ['Tid', historyService ? historyService.formatMinutes(historyService.workMinutes(rawItem)) : formatMinutes(workMinutes(item))],
      ...(item.billing ? [['Debiterbar tid', ataBillingApi.formatMinutes(item.billing.minutes)]] : []),
      ['Lass', String(item.loads.length)],
      ['Fortsättningar', String(item.continuationCount)]
    ];
    detailRows.forEach(([label, value]) => {
      const row = document.createElement('span');
      const strong = document.createElement('strong');
      strong.textContent = `${label}: `;
      row.append(strong, document.createTextNode(value));
      detailGrid.appendChild(row);
    });
    details.append(summary, detailGrid);
    if (item.loads.length > 0) {
      const loadList = document.createElement('ol');
      loadList.className = 'history-load-list';
      item.loads.forEach((load, loadIndex) => {
        const row = document.createElement('li');
        const value = Number(isPlainObject(load) ? load.weight : load);
        row.textContent = `Lass ${loadIndex + 1}: ${Number.isFinite(value) ? value.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 }) : 'vikt saknas'}${Number.isFinite(value) ? ' ton' : ''}`;
        loadList.appendChild(row);
      });
      details.appendChild(loadList);
    }
    card.appendChild(details);

    if (readOnly) return card;

    if (!trashMode) {
      const underlagCard = createAtaUnderlagCard(rawItem, options.surface === 'today' ? 'today' : 'history');
      if (underlagCard) card.appendChild(underlagCard);
    }

    const actions = document.createElement('div');
    actions.className = 'history-actions';
    if (trashMode) {
      const restore = document.createElement('button');
      restore.type = 'button';
      restore.className = 'primary-button';
      restore.textContent = 'Återställ';
      restore.dataset.restoreHistoryTrash = item.id;
      actions.appendChild(restore);

      if (pendingTrashPermanentDeleteId !== item.id) {
        const requestPermanentDelete = document.createElement('button');
        requestPermanentDelete.type = 'button';
        requestPermanentDelete.className = 'danger-button';
        requestPermanentDelete.textContent = 'Ta bort permanent';
        requestPermanentDelete.dataset.requestHistoryPermanentDelete = item.id;
        actions.appendChild(requestPermanentDelete);
      }
      card.appendChild(actions);

      if (pendingTrashPermanentDeleteId === item.id) {
        const confirmation = document.createElement('div');
        confirmation.className = 'inline-confirm';
        const message = document.createElement('p');
        message.textContent = `Ta bort ${item.jobType}: ${historyRouteText(item)} permanent? Hela uppdraget försvinner och kan inte återställas.`;
        const confirm = document.createElement('button');
        confirm.type = 'button';
        confirm.className = 'danger-button is-solid';
        confirm.textContent = 'Bekräfta permanent radering';
        confirm.dataset.confirmHistoryPermanentDelete = item.id;
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.textContent = 'Avbryt';
        cancel.dataset.cancelHistoryPermanentDelete = item.id;
        confirmation.append(message, confirm, cancel);
        card.appendChild(confirmation);
      }
    } else if (item.receiptImported) {
      const removeReceipt = document.createElement('button');
      removeReceipt.type = 'button'; removeReceipt.className = 'danger-button'; removeReceipt.textContent = 'Ta bort kvittorad';
      removeReceipt.dataset.deleteReceiptRow = item.receiptRowId; actions.appendChild(removeReceipt); card.appendChild(actions);
    } else if (pendingHistoryTrashId === item.id) {
      const confirmation = document.createElement('div');
      confirmation.className = 'inline-confirm';
      const message = document.createElement('p');
      message.textContent = `Flytta ${item.jobType}: ${historyRouteText(item)} till Papperskorgen? Jobbet tas bort från Idag, Historik och Sammanställning men kan återställas.`;
      const confirm = document.createElement('button');
      confirm.type = 'button';
      confirm.className = 'danger-button is-solid';
      confirm.textContent = 'Bekräfta flytt';
      confirm.dataset.confirmHistoryTrash = item.id;
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'secondary-button';
      cancel.textContent = 'Avbryt';
      cancel.dataset.cancelHistoryTrash = item.id;
      confirmation.append(message, confirm, cancel);
      card.appendChild(confirmation);
    } else if (editingHistoryBillingId === item.id) {
      const edit = document.createElement('div');
      edit.className = 'history-billing-edit';
      const label = document.createElement('label');
      label.textContent = 'Debiterbar tid i minuter';
      const input = document.createElement('input');
      input.type = 'number';
      input.inputMode = 'numeric';
      input.min = '0';
      input.step = '1';
      input.value = item.billing ? String(item.billing.minutes) : '';
      input.dataset.historyBillingInput = item.id;
      label.appendChild(input);
      const editActions = document.createElement('div');
      editActions.className = 'history-actions';
      const save = document.createElement('button');
      save.type = 'button';
      save.className = 'primary-button';
      save.textContent = 'Spara ändring';
      save.dataset.saveHistoryBilling = item.id;
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'secondary-button';
      cancel.textContent = 'Avbryt';
      cancel.dataset.cancelHistoryBilling = item.id;
      editActions.append(save, cancel);
      const status = document.createElement('p');
      status.className = 'form-status';
      status.setAttribute('role', 'status');
      status.setAttribute('aria-live', 'polite');
      status.dataset.historyBillingStatus = item.id;
      edit.append(label, editActions, status);
      card.appendChild(edit);
    } else if (editingTodayHistoryId === item.id) {
      const edit = document.createElement('div');
      edit.className = 'history-billing-edit';
      const fields = [
        ['jobType', 'Jobbtyp', item.jobType], ['from', 'Från', item.from], ['destination', 'Till', item.destination],
        ['startedAt', 'Starttid', historyEditDateTimeValue(item.startedAt)], ['completedAt', 'Sluttid', historyEditDateTimeValue(item.completedAt)],
        ['totalWeight', 'Total vikt i ton', item.totalWeight ?? ''], ['note', 'Anteckning', item.note || '']
      ];
      fields.forEach(([key, labelText, value]) => {
        const label = document.createElement('label'); label.textContent = labelText;
        const input = key === 'note' ? document.createElement('textarea') : document.createElement('input');
        input.value = value; input.dataset.todayEditField = key; input.dataset.todayEditId = item.id;
        if (input instanceof HTMLInputElement) {
          if (key === 'startedAt' || key === 'completedAt') input.type = 'datetime-local';
          else if (key === 'totalWeight') { input.type = 'number'; input.step = '0.001'; input.min = '0'; input.inputMode = 'decimal'; }
          else input.type = 'text';
        }
        label.appendChild(input); edit.appendChild(label);
      });
      const editActions = document.createElement('div'); editActions.className = 'history-actions';
      const save = document.createElement('button'); save.type = 'button'; save.className = 'primary-button'; save.textContent = 'Spara ändring'; save.dataset.saveTodayEdit = item.id;
      const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'secondary-button'; cancel.textContent = 'Avbryt'; cancel.dataset.cancelTodayEdit = item.id;
      const status = document.createElement('p'); status.className = 'form-status'; status.setAttribute('role', 'status'); status.setAttribute('aria-live', 'polite'); status.dataset.todayEditStatus = item.id;
      editActions.append(save, cancel); edit.append(editActions, status); card.appendChild(edit);
    } else {
      if ((options.surface === 'today' || options.surface === 'history') && isVehicleRole()) {
        const editToday = document.createElement('button');
        editToday.type = 'button'; editToday.className = 'secondary-button'; editToday.textContent = 'Redigera'; editToday.dataset.editToday = item.id;
        actions.appendChild(editToday);
      }
      if (item.ataEnabled) {
        const editBilling = document.createElement('button');
        editBilling.type = 'button';
        editBilling.className = 'secondary-button';
        editBilling.textContent = 'Redigera avslutat jobb';
        editBilling.dataset.editHistoryBilling = item.id;
        actions.appendChild(editBilling);
      }
      const requestTrash = document.createElement('button');
      requestTrash.type = 'button';
      requestTrash.className = 'danger-button';
      requestTrash.textContent = 'Flytta till Papperskorgen';
      requestTrash.dataset.requestHistoryTrash = item.id;
      actions.appendChild(requestTrash);
      card.appendChild(actions);
    }
    return card;
  }

  function renderHistoryGroups(items, container, surface = 'history') {
    let currentDate = '';
    items.forEach(({ item, index }) => {
      const dateKey = localDateFromTimestamp(historyItemDisplay(item, index).completedAt) || 'Datum saknas';
      if (dateKey !== currentDate) {
        currentDate = dateKey;
        const heading = document.createElement('h3');
        heading.className = 'history-day-heading';
        const parsed = new Date(`${dateKey}T12:00:00`);
        heading.textContent = Number.isNaN(parsed.getTime()) ? dateKey : parsed.toLocaleDateString('sv-SE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        container.appendChild(heading);
      }
      container.appendChild(createHistoryCard(item, index, { surface }));
    });
  }

  function addStatisticsGroup(groups, key, label, item) {
    if (!groups.has(key)) groups.set(key, { key, label, items: [] });
    groups.get(key).items.push(item);
  }

  function renderStatisticsTable(bodyId, groups, compare) {
    const body = byId(bodyId);
    body.replaceChildren();
    const rows = Array.from(groups.values()).sort(compare);
    if (rows.length === 0) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 5;
      cell.className = 'statistics-empty';
      cell.textContent = 'Inga poster i perioden.';
      row.appendChild(cell);
      body.appendChild(row);
      return;
    }
    rows.forEach((group) => {
      const metrics = statisticsMetrics(group.items);
      const row = document.createElement('tr');
      [
        group.label,
        String(metrics.jobs),
        String(metrics.loads),
        `${metrics.weight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`,
        formatMinutes(metrics.minutes)
      ].forEach((value) => {
        const cell = document.createElement('td');
        cell.textContent = value;
        row.appendChild(cell);
      });
      body.appendChild(row);
    });
  }

  function renderStatisticsView() {
    const dateFrom = text(byId('statistics-date-from').value);
    const dateTo = text(byId('statistics-date-to').value);
    const all = nativeHistoryEntries().map(({ item, index }) => historyItemDisplay(item, index));
    const displayed = all.filter((item) => {
      const dateKey = localDateFromTimestamp(item.completedAt);
      return (!dateFrom || dateKey >= dateFrom) && (!dateTo || dateKey <= dateTo);
    });
    byId('statistics-count').textContent = displayed.length === all.length ? String(all.length) : `${displayed.length}/${all.length}`;
    renderSummaryMetrics('statistics', statisticsMetrics(displayed));

    const dayGroups = new Map();
    const jobTypeGroups = new Map();
    displayed.forEach((item) => {
      const dateKey = localDateFromTimestamp(item.completedAt) || 'Datum saknas';
      addStatisticsGroup(dayGroups, dateKey, formatDate(dateKey) || dateKey, item);
      const jobType = item.jobType || 'Jobbtyp saknas';
      const jobTypeKey = receiptApi.registryGroupKey(item.jobTypeId, jobType);
      addStatisticsGroup(jobTypeGroups, jobTypeKey, jobType, item);
    });

    renderStatisticsTable('statistics-day-body', dayGroups, (a, b) => b.key.localeCompare(a.key, 'sv-SE'));
    renderStatisticsTable('statistics-job-type-body', jobTypeGroups, (a, b) => a.label.localeCompare(b.label, 'sv-SE'));
    renderExcelMailProfile();
  }

  function excelMailProfile() { const value=isPlainObject(settingsDocument.excelMailV1) ? settingsDocument.excelMailV1 : {}; return { ...value, email:text(value.email), email2:text(value.email2), contactId:text(value.contactId), contactId2:text(value.contactId2) }; }
  function excelMailContact(recipientNumber) { const profile=excelMailProfile(), id=recipientNumber===2?profile.contactId2:profile.contactId; return ataNotificationApi ? ataNotificationApi.contactsForDisplay(ataNotificationSettings()).find((item)=>item.id===id) || null : null; }
  function excelMailRecipient(recipientNumber) { const profile=excelMailProfile(), contact=excelMailContact(recipientNumber), selectedId=recipientNumber===2?profile.contactId2:profile.contactId, fallback=recipientNumber===2?profile.email2:profile.email; return selectedId ? (contact ? { email:text(contact.email), error:'' } : { email:'', error:`Mottagare ${recipientNumber} finns inte längre i Adressbok. Välj och spara en kontakt på nytt.` }) : { email:fallback, error:'' }; }
  function availableExcelMonths() {
    const months=new Set();
    nativeHistoryEntries().map(({item,index})=>historyItemDisplay(item,index)).filter((item)=>!item.otherActivity).forEach((item)=>{
      const date=localDateFromTimestamp(item.completedAt);
      if (/^\d{4}-\d{2}-\d{2}$/.test(date)) months.add(date.slice(0,7));
    });
    const current=new Date(); months.add(`${current.getFullYear()}-${String(current.getMonth()+1).padStart(2,'0')}`);
    return Array.from(months).sort().reverse();
  }
  function excelMailSelection() {
    const period=text(byId('excel-mail-period') && byId('excel-mail-period').value,'current_month');
    const month=text(byId('excel-mail-month') && byId('excel-mail-month').value);
    return { period, month };
  }
  function excelMailPeriodLabel(selection) {
    if (selection.period==='today') return 'idag';
    if (selection.period==='current_month') return 'denna månad';
    if (selection.period==='month') return selection.month || 'vald månad';
    return 'all historik';
  }
  function renderExcelMailPeriodControls() {
    const periodEl=byId('excel-mail-period'), monthEl=byId('excel-mail-month'), wrap=byId('excel-mail-month-wrap'), summary=byId('excel-mail-period-summary');
    if (!periodEl || !monthEl || !wrap || !summary) return;
    const previous=text(monthEl.value), months=availableExcelMonths();
    monthEl.innerHTML='';
    months.forEach((month)=>{ const option=document.createElement('option'); option.value=month; option.textContent=month; monthEl.appendChild(option); });
    monthEl.value=months.includes(previous) ? previous : months[0];
    wrap.hidden=periodEl.value!=='month';
    summary.textContent=`Export: ${excelMailPeriodLabel(excelMailSelection())}.`;
  }
  function excelRowsForSelection(selection) {
    const today=localDateFromTimestamp(new Date().toISOString());
    const currentMonth=today.slice(0,7);
    return nativeHistoryEntries().map(({item,index})=>historyItemDisplay(item,index)).filter((item)=>!item.otherActivity).filter((item)=>{
      const date=localDateFromTimestamp(item.completedAt);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
      if (selection.period==='today') return date===today;
      if (selection.period==='current_month') return date.slice(0,7)===currentMonth;
      if (selection.period==='month') return date.slice(0,7)===selection.month;
      return true;
    });
  }
  function renderExcelMailContacts() {
    [1,2].forEach((recipientNumber)=>{
      const select=byId(`excel-mail-contact-${recipientNumber}`);
      if (!select || !ataNotificationApi) return;
      const profile=excelMailProfile(), saved=recipientNumber===2?profile.contactId2:profile.contactId, previous=text(select.value)||saved;
      select.replaceChildren();
      const empty=document.createElement('option'); empty.value=''; empty.textContent='Välj från Adressbok'; select.appendChild(empty);
      ataNotificationApi.contactsForDisplay(ataNotificationSettings()).forEach((contact)=>{
        const option=document.createElement('option'); option.value=contact.id; option.textContent=ataNotificationApi.recipientListLabel(contact); select.appendChild(option);
      });
      if (selectContainsValue(select,previous)) select.value=previous;
    });
  }
  function selectExcelMailContact(recipientNumber) {
    const select=byId(`excel-mail-contact-${recipientNumber}`);
    const input=byId(recipientNumber===2?'excel-mail-email-2':'excel-mail-email');
    if (!select || !input || !ataNotificationApi) return;
    const contact=ataNotificationApi.contactsForDisplay(ataNotificationSettings()).find((item)=>item.id===text(select.value));
    input.value=contact ? text(contact.email) : '';
  }
  function renderExcelMailProfile() { const profile=excelMailProfile(), input1=byId('excel-mail-email'), input2=byId('excel-mail-email-2'), recipient1=excelMailRecipient(1), recipient2=excelMailRecipient(2); if(input1 && document.activeElement!==input1) input1.value=recipient1.email || (profile.contactId ? '' : profile.email); if(input2 && document.activeElement!==input2) input2.value=recipient2.email || (profile.contactId2 ? '' : profile.email2); renderExcelMailContacts(); renderExcelMailPeriodControls(); }
  function saveExcelMailRecipient() {
    const email=text(byId('excel-mail-email').value), email2=text(byId('excel-mail-email-2').value), contactId=text(byId('excel-mail-contact-1').value), contactId2=text(byId('excel-mail-contact-2').value);
    const valid=(value)=>!value || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    if(!valid(email)) { showStatus('excel-mail-status','Mottagare 1 har en ogiltig mailadress.',true); return; }
    if(!valid(email2)) { showStatus('excel-mail-status','Mottagare 2 har en ogiltig mailadress.',true); return; }
    const next={...settingsDocument,excelMailV1:{...excelMailProfile(),email,email2,contactId,contactId2},settingsUpdatedByPackageVersion:PACKAGE_VERSION};
    if(!writeSettingsDocument(next)) { showStatus('excel-mail-status',nativeStorageErrorMessage('Mailadresserna kunde inte sparas.'),true); return; }
    settingsDocument=next; showStatus('excel-mail-status','Mailadresserna är sparade lokalt.');
  }
  function excelCleanJobTypeLabel(value) { return text(value,'Jobbtyp saknas').replace(/\s+[–-]\s+äldre\/ospecificera(?:d|t)\s*$/i,''); }
  function excelExportNote(item) {
    const note=text(item && item.note);
    const standard='Kvittoimporterad. Eventuell Start/Slut är uppskattad från Kvittotid och snittid och används inte för tidsinlärning.';
    return isReceiptImportedHistoryItem(item) && note===standard ? 'Kvittoimporterat uppdrag' : note;
  }
  function excelJobTypeLabels(item) {
    const ordinary=excelCleanJobTypeLabel(text(item && item.jobType, 'Jobbtyp saknas'));
    const source=`${text(item && item.legacyDisplayType)} ${text(item && item.jobType)}`.toLowerCase();
    const isCompactor=canonicalJobTypeId(text(item && item.jobTypeId)) === 'JT-1006' || source.includes('komprimator');
    if (!isCompactor) return [ordinary];
    const specific=source.includes('41099') ? 'Komprimator 41099' : source.includes('41360') ? 'Komprimator 41360' : source.includes('slottskogen') ? 'Komprimator Slottskogen' : 'Komprimator';
    return [specific, 'Komprimator – totalt'];
  }
  function buildNativeExcelWorkbook(selection=excelMailSelection()) {
    if (!xlsxExport || typeof xlsxExport.buildWorkbook!=='function') throw new Error('Den lokala XLSX-exporttjänsten saknas.');
    const rows=excelRowsForSelection(selection);
    const period=excelMailPeriodLabel(selection); const metrics=statisticsMetrics(rows);
    const byDay=new Map(), byType=new Map(), byMonth=new Map();
    const addExcelGroup=(map,key,item)=>{ const value=map.get(key)||{jobs:0,loads:0,weight:0,minutes:0,receiptJobs:0,nonReceiptJobs:0}; value.jobs++; value.loads+=item.loads.length; value.weight+=item.totalWeight; value.minutes+=item.receiptImported?0:workMinutes(item); if (item.receiptImported) value.receiptJobs++; else value.nonReceiptJobs++; map.set(key,value); };
    rows.forEach((item)=>{ const day=localDateFromTimestamp(item.completedAt)||'Datum saknas'; const month=/^\d{4}-\d{2}/.test(day) ? day.slice(0,7) : 'Datum saknas'; addExcelGroup(byDay,day,item); addExcelGroup(byMonth,month,item); excelJobTypeLabels(item).forEach((type)=>addExcelGroup(byType,type,item)); });
    const summary=[['Sammanställning','Lastbil 189'],['Period',period],['Exportdatum',new Date().toLocaleString('sv-SE')],['Antal jobb',metrics.jobs],['Antal last',metrics.loads],['Totalvikt i ton',metrics.weight],['Total tid timmar',metrics.minutes/60]];
    const table=(heading,map)=>[heading,...Array.from(map.entries()).sort(([a],[b])=>a.localeCompare(b,'sv-SE')).map(([label,v])=>[excelCleanJobTypeLabel(label),v.jobs,v.loads,v.weight,v.minutes/60])];
    const byDayTable=[['Datum','Jobb','Antal last','Total vikt i ton','Tid timmar','Kommentar'],...Array.from(byDay.entries()).sort(([a],[b])=>a.localeCompare(b,'sv-SE')).map(([label,v])=>[label,v.jobs,v.loads,v.weight,v.minutes/60,v.minutes===0&&v.receiptJobs>0&&v.nonReceiptJobs===0?'Kvittoimporterat uppdrag':''])];
    const diagram=[['Månad','Antal jobb'],...Array.from(byMonth.entries()).sort(([a],[b])=>a.localeCompare(b,'sv-SE')).map(([month,value])=>[month,value.jobs])];
    const details=[['Datum','Jobbtyp','Från','Till','Antal last','Angiven vikt i ton','Tid timmar','ÄTA-jobb','Debiterbar tid timmar','Kommentar'],...rows.slice().sort((a,b)=>text(a.completedAt).localeCompare(text(b.completedAt))).map((item)=>{ const billing=isPlainObject(item.billing)?item.billing:{}; const billable=Math.max(0,Number(billing.minutes||billing.billableMinutes||item.billableMinutes||0)||0); return [localDateFromTimestamp(item.completedAt),excelJobTypeLabels(item)[0],item.from,item.destination,item.loads.length,item.totalWeight,(item.receiptImported?0:workMinutes(item))/60,item.ataEnabled?'Ja':'',billable>0?billable/60:'',excelExportNote(item)]; })];
    return xlsxExport.buildWorkbook({sheets:[{name:'Sammanfattning',rows:summary},{name:'Diagram månad',rows:diagram},{name:'Dag för dag',rows:byDayTable},{name:'Per jobbtyp',rows:table(['Jobbtyp','Jobb','Antal last','Total vikt i ton','Tid timmar'],byType)},{name:'Detaljer',rows:details}]});
  }

  function mailNativeExcel(recipientNumber=1) { try { const resolved=excelMailRecipient(recipientNumber), recipient=resolved.email, label=`Mottagare ${recipientNumber===2 ? 2 : 1}`; if(resolved.error) throw new Error(resolved.error); if(!recipient) throw new Error(`${label} saknar mailadress.`); if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) throw new Error(`${label} har en ogiltig mailadress.`); if(!mailService || !xlsxExport) throw new Error('Appens XLSX-mailtjänst saknas.'); const selection=excelMailSelection(); if(selection.period==='month'&&!/^\d{4}-\d{2}$/.test(selection.month)) throw new Error('Välj en giltig månad för Excel-exporten.'); const workbook=buildNativeExcelWorkbook(selection); const contentBase64=xlsxExport.toBase64(workbook.bytes); const periodLabel=excelMailPeriodLabel(selection); const stamp=selection.period==='month'?selection.month:selection.period; mailService.open({mailType:'summary-excel',recipient,subject:`Lastbil 189 Sammanställning ${periodLabel}`,body:`Sammanställning för ${periodLabel} finns bifogad som Excel-fil. Övrig verksamhet ingår inte.`,attachment:{fileName:`stadslass_sammanstallning_${stamp}.xlsx`,mimeType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',contentBase64}},hostInfo); showStatus('excel-mail-status',`Excel för ${periodLabel} har öppnats i mailappen som bilaga till ${label.toLowerCase()}. Kontrollera och skicka mailet där.`); } catch(error) { showStatus('excel-mail-status',error.message||'Excel-mailutkastet kunde inte öppnas.',true); } }


  function openStatisticsFromHome() { activeSettingsGroup='export'; activeSettingsFunction='statistics'; showView('settings'); prepareSettingsFunction('statistics'); renderSettingsWorkspace(true); }

  function openExcelMailFromStatistics() { activeSettingsGroup='export'; activeSettingsFunction='excel-mail'; showView('settings'); prepareSettingsFunction('excel-mail'); renderSettingsWorkspace(true); renderExcelMailProfile(); }

  function quickChoiceTimeRows() {
    const records = nativeHistoryEntries({ forLearning: true }).map(({ item }) => item);
    const median = (values) => etaService && etaService.median ? etaService.median(values) : null;
    return (quickChoiceRegistry && Array.isArray(quickChoiceRegistry.items) ? quickChoiceRegistry.items : []).map((quick) => {
      const required = quick.returnRequired === true ? ['loading','transport','unloading','return_transport','return_unloading'] : ['loading','transport','unloading'];
      const samples = records.map((record) => {
        if (!record || isReceiptImportedHistoryItem(record) || record.excludeFromEstimateLearning === true || (record.trashState && record.trashState.trashedAt) || record.needsMatching === true) return null;
        if (text(record.jobTypeId) !== text(quick.jobTypeId) || text(record.fromPlaceId) !== text(quick.fromPlaceId) || text(record.destinationPlaceId) !== text(quick.toPlaceId) || Boolean(record.returnRequired) !== Boolean(quick.returnRequired)) return null;
        if (quick.returnRequired && text(record.returnPlaceId) !== text(quick.returnPlaceId || quick.fromPlaceId)) return null;
        const timeline = Array.isArray(record.phaseTimeline) ? record.phaseTimeline : [], durations = new Map();
        timeline.forEach((entry) => { const phase=text(entry && entry.phase), start=new Date(text(entry && entry.startedAt)).getTime(), end=new Date(text(entry && entry.endedAt)).getTime(); if(required.includes(phase) && Number.isFinite(start) && Number.isFinite(end) && end >= start) durations.set(phase, Math.round((end-start)/60000)); });
        if (!required.every((phase) => Number.isFinite(durations.get(phase)) && durations.get(phase) >= 0 && durations.get(phase) <= 180)) return null;
        return required.reduce((total, phase) => total + durations.get(phase), 0);
      }).filter(Number.isFinite);
      return { name:text(quick.buttonName, 'Namnlöst snabbval'), samples:samples.length, minutes:samples.length >= 3 ? median(samples) : null };
    }).sort((a,b) => a.name.localeCompare(b.name, 'sv-SE'));
  }

  function renderQuickChoiceTimesView() {
    const body=byId('quick-choice-times-body'); if(!body) return; body.replaceChildren();
    try { const rows=quickChoiceTimeRows(); if(!rows.length) { const row=document.createElement('tr'), cell=document.createElement('td'); cell.colSpan=3; cell.textContent='Inga aktiva snabbval finns.'; row.appendChild(cell); body.appendChild(row); return; } rows.forEach((item) => { const row=document.createElement('tr'); [item.name,Number.isFinite(item.minutes)?`${item.minutes} min`:'För få godkända uppdrag (minst 3)',String(item.samples)].forEach((value) => { const cell=document.createElement('td'); cell.textContent=value; row.appendChild(cell); }); body.appendChild(row); }); } catch (error) { watchdog.step('runtime.quick-choice-times.failed', error.message || 'Snitttider kunde inte beräknas.', 'warning'); const row=document.createElement('tr'), cell=document.createElement('td'); cell.colSpan=3; cell.textContent='Snitttider kunde inte beräknas.'; row.appendChild(cell); body.appendChild(row); }
  }

  function renderHistoryViews() {
    const surface = historyActionSurface();
    const renderToday = surface === 'today';
    const renderHistory = surface === 'history';
    const renderTrash = surface === 'trash';
    const renderStatistics = surface === 'statistics';
    const renderQuickTimes = currentView === 'quickChoices';
    if (!renderToday && !renderHistory && !renderTrash && !renderStatistics && !renderQuickTimes) return;
    const todayList = byId('today-list');
    const historyList = byId('history-list');
    if (renderToday) todayList.replaceChildren();
    if (renderHistory) historyList.replaceChildren();
    const activeEntries = activeHistoryEntries();
    const todayKey = localDateKey(new Date());
    const todayItems = activeEntries
      .filter(({ item, index }) => historyCalendarDateKey(item, index) === todayKey && !isReceiptImportedHistoryItem(item))
      .sort((a, b) => new Date(historyItemDisplay(b.item, b.index).completedAt).getTime() - new Date(historyItemDisplay(a.item, a.index).completedAt).getTime());
    const sorted = renderHistory ? activeEntries
      .sort((a, b) => {
        const dateA = historyCalendarDateKey(a.item, a.index);
        const dateB = historyCalendarDateKey(b.item, b.index);
        if (dateA !== dateB) return dateB.localeCompare(dateA, 'sv-SE');
        return new Date(historyItemDisplay(b.item, b.index).completedAt).getTime() - new Date(historyItemDisplay(a.item, a.index).completedAt).getTime();
      }) : activeEntries;
    const selectedItems = renderHistory ? renderHistoryCalendar(sorted) : [];
    if (renderToday) {
      byId('today-count').textContent = String(todayItems.length);
      historySummary(todayItems, 'today');
    }
    if (renderHistory) byId('history-count').textContent = String(selectedItems.length);

    if (renderToday && todayItems.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga avslutade jobb idag.';
      todayList.appendChild(empty);
    } else if (renderToday) {
      const dailyCard = createAtaDailyCard(todayItems, todayKey);
      if (dailyCard) todayList.appendChild(dailyCard);
      renderHistoryGroups(todayItems, todayList, 'today');
    }

    if (renderHistory && selectedItems.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = sorted.length === 0 ? 'Historiken är tom.' : 'Inga avslutade jobb eller kvittorader att visa för valt datum.';
      historyList.appendChild(empty);
    } else if (renderHistory) {
      const selectedDailyCard = createAtaDailyCard(selectedItems, historySelectedDate);
      if (selectedDailyCard) historyList.appendChild(selectedDailyCard);
      selectedItems.forEach(({ item, index }) => historyList.appendChild(createHistoryCard(item, index, { surface: 'history', readOnly: isMobileRole() })));
    }
    if (renderTrash) renderTrashView();
    if (renderStatistics) renderStatisticsView();
    if (renderQuickTimes) renderQuickChoiceTimesView();
  }

  function renderTrashView() {
    const trashList = byId('trash-list');
    const trashed = trashedHistoryEntries();
    trashList.replaceChildren();
    byId('trash-count').textContent = String(trashed.length);
    if (trashed.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Papperskorgen är tom.';
      trashList.appendChild(empty);
      return;
    }
    trashed.forEach(({ item, index }) => trashList.appendChild(createHistoryCard(item, index, { mode: 'trash' })));
  }

  function historyItemIndexById(id) {
    const key = text(id);
    return historyDocument.findIndex((item, index) => historyItemDisplay(item, index).id === key);
  }

  function historyActionSurface() {
    if (currentView === 'today') return 'today';
    if (currentView === 'settings') {
      if (activeSettingsFunction === 'statistics') return 'statistics';
      if (activeSettingsFunction === 'trash') return 'trash';
      if (activeSettingsFunction === 'history') return 'history';
    }
    const todayView = byId('view-today');
    if (todayView && todayView.hidden === false) return 'today';
    const historyPanel = byId('settings-history-panel');
    if (historyPanel && historyPanel.hidden === false) return 'history';
    const statisticsPanel = byId('settings-statistics-panel');
    if (statisticsPanel && statisticsPanel.hidden === false) return 'statistics';
    const trashPanel = byId('settings-trash-panel');
    if (trashPanel && trashPanel.hidden === false) return 'trash';
    return 'history';
  }

  function currentHistoryActionStatusId() {
    return historyStatusId(historyActionSurface());
  }

  function currentHistoryActionListSelector() {
    return historyActionSurface() === 'today'
      ? '#today-list .inline-confirm'
      : '#history-list .inline-confirm';
  }

  function currentHistoryActionContainer() {
    return historyActionSurface() === 'today' ? byId('today-list') : byId('history-list');
  }

  function historyBillingElement(id, attribute) {
    const container = currentHistoryActionContainer();
    if (!container) return null;
    return Array.from(container.querySelectorAll(`[${attribute}]`))
      .find((element) => text(element.dataset[attribute.replace(/^data-/, '').replace(/-([a-z])/g, (_, letter) => letter.toUpperCase())]) === text(id)) || null;
  }

  function requestTodayEdit(id) {
    const resolved = writableHistoryRecord(id);
    if (!isVehicleRole() || !resolved || isHistoryItemTrashed(resolved.record)) return;
    editingTodayHistoryId = text(id); pendingHistoryTrashId = ''; editingHistoryBillingId = '';
    renderHistoryViews();
  }

  function cancelTodayEdit(id) {
    if (editingTodayHistoryId !== text(id)) return;
    editingTodayHistoryId = ''; renderHistoryViews(); showStatus('today-load-status', 'Redigeringen avbröts.');
  }

  function saveTodayEdit(id) {
    const key = text(id); const resolved = writableHistoryRecord(key);
    if (!isVehicleRole() || editingTodayHistoryId !== key || !resolved) return;
    const inlineStatus = Array.from(document.querySelectorAll('[data-today-edit-status]')).find((element) => text(element.dataset.todayEditStatus) === key);
    const showEditStatus = (message, error = false) => { if (inlineStatus) { inlineStatus.textContent = message; inlineStatus.classList.toggle('is-error', error); } else showStatus(currentHistoryActionStatusId(), message, error); };
    const record = resolved.fromArchive ? materializeHistoryArchiveRecord(resolved.record) : resolved.record; const fields = {};
    document.querySelectorAll('[data-today-edit-id]').forEach((input) => { if (text(input.dataset.todayEditId) === key) fields[input.dataset.todayEditField] = text(input.value); });
    const weight = fields.totalWeight === '' ? record.totalWeight : Number(String(fields.totalWeight).replace(',', '.'));
    if (!Number.isFinite(weight) || weight < 0) { showEditStatus('Vikten måste vara noll eller ett positivt tal.', true); return; }
    if (Array.isArray(record.loads) && record.loads.length > 1 && Math.abs(weight - Number(record.totalWeight || 0)) > 0.000001) { showEditStatus('Flerlassuppdrag kan inte få en ny totalvikt här, eftersom vikten per lass då blir okänd.', true); return; }
    const startedAt = fields.startedAt ? historyEditIsoValue(fields.startedAt) : text(record.startedAt);
    const completedAt = fields.completedAt ? historyEditIsoValue(fields.completedAt) : text(record.completedAt);
    if (!startedAt || !completedAt) { showEditStatus('Starttid och sluttid måste vara giltiga.', true); return; }
    if (new Date(completedAt).getTime() < new Date(startedAt).getTime()) { showEditStatus('Sluttiden kan inte vara före starttiden.', true); return; }
    const weightFields = historyWeightEdit(record, weight);
    const now = new Date().toISOString();
    const updated = normalizeJobRecord({ ...record, ...weightFields, jobType: fields.jobType, jobTypeName: fields.jobType, from: fields.from, fromPlaceName: fields.from, destination: fields.destination, destinationPlaceName: fields.destination, startedAt, completedAt, note: fields.note, excludeFromEstimateLearning: true, learningExcludedReason: 'manual_today_edit', manuallyEditedAt: now, updatedAt: now, updatedByPackageVersion: PACKAGE_VERSION }, 'history');
    try {
      const nextDocument = replaceOrAppendHistoryRecord(resolved, updated);
      if (!writeHistoryDocument(nextDocument)) { showEditStatus(window.StadslassHost.getLastError() || 'Uppdraget kunde inte sparas lokalt.', true); return; }
      historyDocument = nextDocument;
      historyLoaded = true;
      editingTodayHistoryId = '';
      renderHistoryViews();
      showStatus(currentHistoryActionStatusId(), 'Ändringen sparades. Uppdraget undantas från framtida inlärning.');
    } catch (error) { showEditStatus(error && error.message ? error.message : 'Uppdraget kunde inte sparas.', true); }
  }

  function requestHistoryBillingEdit(id) {
    const key = text(id);
    const resolved = writableHistoryRecord(key);
    if (!canUseActiveJob() || !resolved || isHistoryItemTrashed(resolved.record) || !ataApi.isEnabled(resolved.record)) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = '';
    editingHistoryBillingId = key;
    renderHistoryViews();
    revealInlineControl(`${historyActionSurface() === 'today' ? '#today-list' : '#history-list'} .history-billing-edit`, previousScrollY);
    const input = historyBillingElement(key, 'data-history-billing-input');
    if (input) {
      try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
    }
  }

  function cancelHistoryBillingEdit(id) {
    if (editingHistoryBillingId !== text(id) || historyBillingOperationId) return;
    const previousScrollY = currentScrollY();
    editingHistoryBillingId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus(currentHistoryActionStatusId(), 'Redigeringen av debiterbar tid avbröts.');
  }

  function saveHistoryBillingEdit(id) {
    const key = text(id);
    if (!key || historyBillingOperationId || editingHistoryBillingId !== key) return;
    const resolved = writableHistoryRecord(key);
    if (!resolved) {
      showStatus(currentHistoryActionStatusId(), 'Debiterbar tid kunde inte sparas eftersom rätt historikpost inte kunde identifieras.', true);
      return;
    }
    const record = resolved.fromArchive ? materializeHistoryArchiveRecord(resolved.record) : resolved.record;
    if (isHistoryItemTrashed(record) || !ataApi.isEnabled(record)) return;
    const input = historyBillingElement(key, 'data-history-billing-input');
    const inlineStatus = historyBillingElement(key, 'data-history-billing-status');
    if (!input) {
      showStatus(currentHistoryActionStatusId(), 'Fältet för debiterbar tid saknas.', true);
      return;
    }
    const raw = String(input.value ?? '').trim();
    let updated;
    try {
      if (!raw) updated = ataBillingApi.removeFromRecord(record, new Date().toISOString());
      else if (!/^\d+$/.test(raw) || !Number.isSafeInteger(Number(raw)) || Number(raw) < 0) {
        throw new Error('Skriv ett helt antal minuter från 0 och uppåt, eller lämna fältet tomt för att ta bort tiden.');
      } else updated = ataBillingApi.editRecord(record, Number(raw), new Date().toISOString());
    } catch (error) {
      if (inlineStatus) {
        inlineStatus.textContent = error.message || 'Debiterbar tid kunde inte sparas.';
        inlineStatus.classList.add('is-error');
      }
      try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
      return;
    }

    historyBillingOperationId = key;
    try {
      const nextDocument = replaceOrAppendHistoryRecord(resolved, updated);
      const message = raw ? 'Debiterbar tid uppdaterades utan att arbetstiden ändrades.' : 'Debiterbar tid togs bort utan att arbetstiden ändrades.';
      if (!persistHistory(nextDocument, message, currentHistoryActionStatusId())) return;
      editingHistoryBillingId = '';
      renderHistoryViews();
    } finally {
      historyBillingOperationId = '';
    }
  }

  function requestHistoryTrash(id) {
    const resolved = writableHistoryRecord(id);
    if (!canUseActiveJob() || !resolved || isHistoryItemTrashed(resolved.record)) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = text(id);
    renderHistoryViews();
    revealInlineControl(currentHistoryActionListSelector(), previousScrollY);
  }

  function cancelHistoryTrash(id) {
    if (pendingHistoryTrashId !== text(id) || historyTrashOperationId) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus(currentHistoryActionStatusId(), 'Flytten till Papperskorgen avbröts. Historiken är oförändrad.');
  }

  function historyItemIndexesById(id) {
    const key = text(id);
    const indexes = [];
    historyDocument.forEach((item, index) => {
      if (historyItemDisplay(item, index).id === key) indexes.push(index);
    });
    return indexes;
  }

  function confirmHistoryTrash(id) {
    const key = text(id);
    if (!key || historyTrashOperationId) return;
    const resolved = writableHistoryRecord(key);
    if (!canUseActiveJob() || pendingHistoryTrashId !== key || !resolved) {
      return;
    }
    if (isHistoryItemTrashed(resolved.record)) return;

    historyTrashOperationId = key;
    const statusId = currentHistoryActionStatusId();
    const now = new Date().toISOString();
    const writable = resolved.fromArchive ? materializeHistoryArchiveRecord(resolved.record) : resolved.record;
    const trashed = {
          ...writable,
          trashState: {
            status: 'trashed',
            source: 'completed-job',
            trashedAt: now,
            trashedByPackageVersion: PACKAGE_VERSION
          }
        };
    const nextDocument = replaceOrAppendHistoryRecord(resolved, trashed);
    pendingHistoryTrashId = '';
    try {
      if (!persistHistory(nextDocument, 'Uppdraget flyttades till Papperskorgen.', statusId)) {
        pendingHistoryTrashId = key;
        renderHistoryViews();
      }
    } finally {
      historyTrashOperationId = '';
    }
  }

  function restoreHistoryTrash(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const nextDocument = historyDocument.map((item, itemIndex) => {
      if (itemIndex !== index) return item;
      const restored = { ...item };
      delete restored.trashState;
      return restored;
    });
    pendingTrashPermanentDeleteId = '';
    persistHistory(nextDocument, 'Uppdraget återställdes till Idag och Historik.', 'trash-load-status');
  }

  function requestHistoryPermanentDelete(id) {
    const index = historyItemIndexById(id);
    if (!canUseActiveJob() || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const previousScrollY = currentScrollY();
    pendingTrashPermanentDeleteId = historyItemDisplay(historyDocument[index], index).id;
    renderHistoryViews();
    revealInlineControl('#trash-list .inline-confirm', previousScrollY);
  }

  function cancelHistoryPermanentDelete(id) {
    if (pendingTrashPermanentDeleteId !== text(id)) return;
    const previousScrollY = currentScrollY();
    pendingTrashPermanentDeleteId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus('trash-load-status', 'Den permanenta raderingen avbröts. Uppdraget finns kvar i Papperskorgen.');
  }

  function confirmHistoryPermanentDelete(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || pendingTrashPermanentDeleteId !== key || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const record = historyDocument[index];
    let nextDocument = historyDocument.filter((_, itemIndex) => itemIndex !== index);
    const sourceId = historyArchiveSourceId(record);
    if (sourceId) {
      nextDocument = nextDocument.filter((item) => !(isHistoryArchiveControl(item) && text(item.archiveSourceId) === sourceId));
      nextDocument.push(historyArchiveApi.tombstone(record, new Date().toISOString(), PACKAGE_VERSION));
    }
    pendingTrashPermanentDeleteId = '';
    if (!persistHistory(nextDocument, 'Uppdraget och all data i posten togs bort permanent.', 'trash-load-status')) {
      pendingTrashPermanentDeleteId = key;
      renderHistoryViews();
    }
  }

  function historyStatusId(target) {
    if (target === 'today') return 'today-load-status';
    if (target === 'statistics') return 'statistics-load-status';
    if (target === 'trash') return 'trash-load-status';
    return 'history-load-status';
  }

  function loadHistoryArchiveIfNeeded(target = 'history') {
    if (!historyArchiveApi || !nativeStorage || !nativeStorage.isActive() || historyArchiveLoaded || historyArchiveLoading) return;
    historyArchiveLoading = true;
    try {
      historyArchiveRecords = Array.from(nativeStorage.archiveRecords());
      historyArchiveLoaded = true;
      watchdog.step('runtime.history-archive.loaded', `${historyArchiveRecords.length} native arkivposter lästes vid behov.`);
      if (historyLoaded && currentView === 'settings' && activeSettingsFunction === 'history') renderHistoryViews();
      if (activeJobLoaded && activeJobExists()) p121RenderEta();
    } catch (error) {
      watchdog.step('runtime.history-archive.invalid', error.message || 'Native historikarkivet kunde inte läsas.', 'warning');
      showStatus(historyStatusId(target), error.message || 'Native historikarkivet kunde inte läsas.', true);
    } finally { historyArchiveLoading = false; }
  }

  function historyProgressElements(target) {
    const prefix = target === 'today' ? 'today' : 'history';
    return {
      wrap: byId(`${prefix}-history-progress`),
      label: byId(`${prefix}-history-progress-label`),
      value: byId(`${prefix}-history-progress-value`),
      bar: byId(`${prefix}-history-progress-bar`)
    };
  }

  function showHistoryProgress(target, loaded, total, phase = 'loading') {
    const elements = historyProgressElements(target);
    if (!elements.wrap || !elements.label || !elements.value || !elements.bar) return;
    const safeTotal = Math.max(0, Number(total) || 0);
    const safeLoaded = Math.max(0, Math.min(Number(loaded) || 0, safeTotal || Number(loaded) || 0));
    const percent = safeTotal > 0 ? Math.min(100, Math.round((safeLoaded / safeTotal) * 100)) : (phase === 'complete' ? 100 : 0);
    elements.wrap.hidden = false;
    elements.bar.value = percent;
    elements.value.textContent = `${percent} %`;
    elements.label.textContent = phase === 'complete'
      ? `Historik klar: ${safeLoaded} av ${safeTotal} poster`
      : `Laddar historik: ${safeLoaded} av ${safeTotal} poster`;
  }

  function hideHistoryProgress(target) {
    const elements = historyProgressElements(target);
    if (elements.wrap) elements.wrap.hidden = true;
  }

  async function loadHistoryForView(target) {
    if (!canReadHistory()) {
      showStatus('role-boundary-note', 'Historik är blockerad på denna enhetsroll.', true);
      return false;
    }
    if (historyLoaded) {
      renderHistoryViews();
      showStatus(historyStatusId(target), '');
      return true;
    }
    if (historyLoading) {
      showStatus(historyStatusId(target), 'Historiken laddas redan.');
      return false;
    }
    historyLoading = true;
    showHistoryProgress(target, 0, 0, 'loading');
    try {
      await new Promise((resolve) => window.requestAnimationFrame ? window.requestAnimationFrame(resolve) : window.setTimeout(resolve, 0));
      const bundle = await nativeStorage.historyBundleWithProgress(({ loaded, total, category }) => {
        showHistoryProgress(target, loaded, total, category === 'complete' ? 'complete' : 'loading');
      });
      historyDocument = migrateArrayStore(HISTORY_STORE, bundle.combinedHistory, 'Native historik migrerades till aktuell uppdragsmodell med bevarade ID:n.');
      historyArchiveRecords = Array.isArray(bundle.archive) ? bundle.archive : [];
      historyArchiveLoaded = true;
      historyLoaded = true;
      renderHistoryViews();
      window.setTimeout(() => hideHistoryProgress(target), 350);
      showStatus(historyStatusId(target), '');
      return true;
    } catch (error) {
      watchdog.step('runtime.store.history.invalid', error.message || 'Historiken kunde inte läsas.', 'warning');
      hideHistoryProgress(target);
      showStatus(historyStatusId(target), error.message || 'Historiken kunde inte läsas.', true);
      return false;
    } finally {
      historyLoading = false;
    }
  }

  function loadHistoryIfNeeded(target = 'history') {
    if (!canReadHistory()) {
      showStatus('role-boundary-note', 'Historik är blockerad på denna enhetsroll.', true);
      return false;
    }
    if (!historyLoaded) {
      try {
        historyDocument = readHistoryDocument();
        historyLoaded = true;
        renderHistoryViews();
      } catch (error) {
        watchdog.step('runtime.store.history.invalid', error.message || 'Historiken kunde inte läsas.', 'warning');
        showStatus(historyStatusId(target), error.message || 'Historiken kunde inte läsas.', true);
        return false;
      }
    }
    if (['history', 'statistics'].includes(target)) loadHistoryArchiveIfNeeded(target);
    showStatus(historyStatusId(target), '');
    return true;
  }

  function loadNativeHistoryForReadOnly(target) {
    if (!historyLoaded) {
      try { historyDocument = readHistoryDocument(); historyLoaded = true; }
      catch (error) { watchdog.step('runtime.store.history.invalid', error.message || 'Native historik kunde inte läsas.', 'warning'); showStatus(historyStatusId(target), error.message || 'Native historik kunde inte läsas.', true); return false; }
    }
    if (target === 'statistics') renderStatisticsView();
    if (target === 'quick-choice-times') renderQuickChoiceTimesView();
    showStatus(historyStatusId(target), '');
    return true;
  }

  function persistHistory(nextDocument, successMessage, statusId = 'active-action-status') {
    const saved = writeHistoryDocument(nextDocument);
    if (!saved) {
      showStatus(statusId, window.StadslassHost.getLastError() || 'Historiken kunde inte sparas.', true);
      return false;
    }
    historyDocument = nextDocument;
    historyLoaded = true;
    renderHistoryViews();
    showStatus(statusId, successMessage);
    return true;
  }

  function setAtaBillingDialogStep(step) {
    const choice = byId('ata-billing-choice-step');
    const round = byId('ata-billing-round-step');
    if (!choice || !round) return;
    const showRound = step === 'round';
    choice.hidden = showRound;
    round.hidden = !showRound;
    showStatus('ata-billing-status', '');
  }

  function ensureAtaBillingBackGuard() {
    if (ataBillingBackGuardActive || !window.history || typeof window.history.pushState !== 'function') return;
    try {
      window.history.pushState({ ...(isPlainObject(window.history.state) ? window.history.state : {}), stadslassAtaBilling: true }, '', window.location.href);
      ataBillingBackGuardActive = true;
    } catch (_) {
      ataBillingBackGuardActive = false;
    }
  }

  function releaseAtaBillingBackGuard(fromPopState = false) {
    if (!ataBillingBackGuardActive) return;
    ataBillingBackGuardActive = false;
    if (fromPopState || !window.history || typeof window.history.back !== 'function') return;
    ataBillingBackGuardClosing = true;
    try { window.history.back(); } catch (_) {}
    window.setTimeout(() => { ataBillingBackGuardClosing = false; }, 0);
  }

  function closeAtaBillingDialog(options = {}) {
    const dialog = byId('ata-billing-dialog');
    ataBillingDialogOpen = false;
    ataBillingDraft = null;
    ataBillingActionInProgress = false;
    if (dialog) {
      dialog.hidden = true;
      dialog.setAttribute('aria-hidden', 'true');
    }
    document.body.classList.remove('modal-open');
    releaseAtaBillingBackGuard(options.fromPopState === true);
    if (options.clearCandidate === true) completionCandidateAt = '';
  }

  function cancelAtaBillingDialog(options = {}) {
    if (!ataBillingDialogOpen || ataBillingActionInProgress) return;
    closeAtaBillingDialog({ fromPopState: options.fromPopState === true, clearCandidate: true });
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    renderActiveJob();
    showStatus('active-action-status', 'Avslutet avbröts. Aktivt jobb är oförändrat.');
  }

  function openAtaBillingDialog(documentValue, completedAt) {
    const timestamp = text(completedAt) || new Date().toISOString();
    const totalMinutes = ataBillingApi.totalWorkMinutes(documentValue, timestamp);
    const totalRounded = ataBillingApi.roundTotalUp(totalMinutes);
    const phaseResult = ataBillingApi.phaseWorkMinutes(documentValue, timestamp);
    const phaseOptions = ataBillingApi.halfHourOptions(phaseResult.minutes);
    ataBillingDraft = {
      completedAt: timestamp,
      totalMinutes,
      totalRounded,
      phaseMinutes: phaseResult.minutes,
      phaseFallbackUsed: phaseResult.fallbackUsed === true,
      phaseOptions
    };
    ataBillingDialogOpen = true;
    ataBillingActionInProgress = false;
    pendingActiveComplete = false;
    const dialog = byId('ata-billing-dialog');
    if (!dialog) throw new Error('Dialogen för debiterbar tid saknas.');
    byId('ata-billing-total-summary').textContent = `${ataBillingApi.formatMinutes(totalMinutes)} → ${ataBillingApi.formatMinutes(totalRounded)}`;
    const phaseChoice = byId('ata-billing-phase-choice');
    if (phaseResult.fallbackUsed) {
      byId('ata-billing-phase-summary').textContent = 'Kan inte beräknas – totaltid används';
      phaseChoice.disabled = true;
      phaseChoice.setAttribute('aria-disabled', 'true');
    } else {
      const phaseResultText = phaseOptions.exact
        ? `${ataBillingApi.formatMinutes(phaseResult.minutes)} → ${ataBillingApi.formatMinutes(phaseOptions.lower)}`
        : `${ataBillingApi.formatMinutes(phaseResult.minutes)} → ${ataBillingApi.formatMinutes(phaseOptions.lower)} eller ${ataBillingApi.formatMinutes(phaseOptions.upper)}`;
      byId('ata-billing-phase-summary').textContent = phaseResultText;
      phaseChoice.disabled = false;
      phaseChoice.setAttribute('aria-disabled', 'false');
    }
    byId('ata-billing-manual-minutes').value = '';
    byId('ata-billing-round-actions').replaceChildren();
    setAtaBillingDialogStep('choice');
    dialog.hidden = false;
    dialog.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    ensureAtaBillingBackGuard();
    renderActiveJob();
    window.requestAnimationFrame(() => {
      const firstChoice = byId('ata-billing-total-choice');
      if (firstChoice) {
        try { firstChoice.focus({ preventScroll: true }); } catch (_) { firstChoice.focus(); }
      }
    });
  }

  function selectedAtaBillingSnapshot(mode, minutes, sourceMinutes, fallbackUsed = false) {
    return ataBillingApi.createBilling({
      minutes,
      mode,
      sourceMinutes,
      fallbackUsed,
      selectedAt: new Date().toISOString()
    });
  }

  function useAtaBillingManual() {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    const input = byId('ata-billing-manual-minutes');
    const minutes = ataBillingApi.parseCompletionManual(input ? input.value : '');
    if (minutes === null) {
      showStatus('ata-billing-status', 'Skriv ett helt antal minuter. Minsta debiterbara tid är 30 minuter.', true);
      if (input) {
        try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
      }
      return;
    }
    finalizeActiveCompletion(selectedAtaBillingSnapshot(ataBillingApi.MODES.MANUAL, minutes, minutes));
  }

  function useAtaBillingTotal() {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    finalizeActiveCompletion(selectedAtaBillingSnapshot(
      ataBillingApi.MODES.TOTAL_UP,
      ataBillingDraft.totalRounded,
      ataBillingDraft.totalMinutes
    ));
  }

  function chooseAtaBillingPhaseLevel(mode, minutes) {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    finalizeActiveCompletion(selectedAtaBillingSnapshot(
      mode,
      minutes,
      ataBillingDraft.phaseMinutes,
      ataBillingDraft.phaseFallbackUsed
    ));
  }

  function showAtaBillingPhaseRoundStep() {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    const options = ataBillingDraft.phaseOptions;
    byId('ata-billing-round-underlag').textContent = `Underlag: ${ataBillingApi.formatMinutes(options.sourceMinutes)}. Välj debiterbar tid enligt 30-minutersregeln.`;
    const actions = byId('ata-billing-round-actions');
    actions.replaceChildren();
    if (options.exact) {
      const exact = document.createElement('button');
      exact.type = 'button';
      exact.className = 'primary-button';
      exact.textContent = `Använd ${ataBillingApi.formatMinutes(options.lower)}`;
      exact.addEventListener('click', () => chooseAtaBillingPhaseLevel(ataBillingApi.MODES.PHASES_EXACT, options.lower), { once: true });
      actions.appendChild(exact);
    } else {
      const lower = document.createElement('button');
      lower.type = 'button';
      lower.className = 'primary-button';
      lower.textContent = `Nedåt till ${ataBillingApi.formatMinutes(options.lower)}`;
      lower.addEventListener('click', () => chooseAtaBillingPhaseLevel(ataBillingApi.MODES.PHASES_DOWN, options.lower), { once: true });
      const upper = document.createElement('button');
      upper.type = 'button';
      upper.className = 'primary-button';
      upper.textContent = `Uppåt till ${ataBillingApi.formatMinutes(options.upper)}`;
      upper.addEventListener('click', () => chooseAtaBillingPhaseLevel(ataBillingApi.MODES.PHASES_UP, options.upper), { once: true });
      actions.append(lower, upper);
    }
    setAtaBillingDialogStep('round');
  }

  function activeCompletionPhase(documentValue = activeJobDocument) {
    if (isOtherActivity(documentValue)) return phaseService.PHASES.OTHER_ACTIVITY;
    return phaseService.PHASES.READY_TO_COMPLETE;
  }

  function requestActiveComplete() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (ataBillingDialogOpen) {
      showStatus('active-action-status', 'Välj debiterbar tid eller avbryt den öppna dialogen först.', true);
      return;
    }
    if (pendingActiveComplete || pendingWeightlessCompletion) {
      showStatus('active-action-status', 'En avslutskontroll är redan öppen. Bekräfta eller avbryt den först.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    const normalCompletionPhase = activeCompletionPhase(activeJobDocument);
    const earlyCompletion = currentPhase !== normalCompletionPhase;
    const policy = weightPolicy(activeJobDocument);
    const missingRequiredOutcome = activeJobDocument.multiLoad === true ? !currentLoadHasOutcome(activeJobDocument) : weightOutcome(activeJobDocument) === 'missing';
    if (policy.mode === 'required' && missingRequiredOutcome) {
      pendingWeightlessCompletion = true;
      renderActiveJob();
      revealInlineControl('#active-complete-without-weight-confirm', previousScrollY);
      showStatus('active-action-status', earlyCompletion
        ? `Uppdraget är i fasen ${phaseLabel(currentPhase)} och vikt saknas. Du kan registrera vikt, välja Ingen tömning eller uttryckligen avsluta ändå utan vikt.`
        : 'Vikt saknas. Registrera verklig vikt, välj Ingen tömning eller välj uttryckligen Avsluta ändå utan vikt.', true);
      return;
    }
    pendingWeightlessCompletion = false;
    completionCandidateAt = text(activeJobDocument.completedAt, completionCandidateAt || new Date().toISOString());
    if (!earlyCompletion && currentPhase === phaseService.PHASES.READY_TO_COMPLETE) {
      pendingActiveComplete = true;
      confirmActiveComplete();
      return;
    }
    pendingActiveComplete = true;
    renderActiveJob();
    revealInlineControl('#active-complete-confirm', previousScrollY);
    showStatus('active-action-status', activeJobDocument.status === 'completing'
      ? 'Bekräfta att det väntande avslutet ska slutföras.'
      : (earlyCompletion
        ? `Uppdraget är i fasen ${phaseLabel(currentPhase)}. Bekräfta om du ändå vill avsluta det.`
        : 'Bekräfta avslutet eller avbryt.'), earlyCompletion);
  }

  function saveActiveNote() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    const value = text(byId('active-note-editor-input').value).slice(0, 500);
    if (value === text(activeJobDocument.note)) {
      showStatus('active-note-editor-status', 'Anteckningen är redan sparad.');
      return;
    }
    const next = { ...activeJobDocument, note: value, updatedAt: new Date().toISOString(), updatedByPackageVersion: PACKAGE_VERSION };
    if (persistActiveJob(next, 'Anteckningen sparades utan att arbetsläget ändrades.')) {
      renderActiveJob();
      showStatus('active-note-editor-status', 'Anteckningen sparades.');
    }
  }

  function cancelActiveComplete() {
    if (ataBillingDialogOpen) {
      cancelAtaBillingDialog();
      return;
    }
    const previousScrollY = currentScrollY();
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    completionCandidateAt = '';
    renderActiveJob();
    preserveScrollAfterRender(previousScrollY);
    showStatus('active-action-status', 'Avslutet avbröts. Aktivt jobb är oförändrat.');
  }

  function allowActiveCompleteWithoutWeight() {
    if (!pendingWeightlessCompletion || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avslut utan vikt kunde inte bekräftas.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    const now = new Date().toISOString();
    const nextDocument = {
      ...activeJobDocument,
      weightMissingConfirmed: true,
      weightMissingConfirmedAt: now,
      weightOutcome: 'missing-confirmed',
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { completedAt: now, outcome: 'missing-confirmed' }),
      excludeFromTimeEstimate: true,
      excludeFromEstimateLearning: true,
      learningExcludedReason: 'Avslutat utan registrerad vikt',
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'weight_missing_confirmed', now)
    };
    pendingWeightlessCompletion = false;
    if (!persistActiveJob(nextDocument, 'Avslut utan vikt är uttryckligen markerat och undantas från framtida tidsinlärning.')) return;
    completionCandidateAt = text(activeJobDocument.completedAt, now);
    pendingActiveComplete = true;
    renderActiveJob();
    revealInlineControl('#active-complete-confirm', previousScrollY);
    showStatus('active-action-status', 'Bekräfta nu att uppdraget ska avslutas och sparas i Idag och Historik.');
  }

  function completionRecordFromActive(documentValue, historyId, completedAt) {
    const completedSegments = closeOpenWorkSegment(documentValue, completedAt, 'completed');
    const phaseClosedDocument = isOtherActivity(documentValue) ? documentValue : phaseService.closeRecord(documentValue, completedAt, 'job_completed', 'manual');
    const { parkedOtherActivity: _parkedOtherActivity, ...historySource } = phaseClosedDocument;
    const completed = normalizeJobRecord({
      ...historySource,
      workSegments: completedSegments,
      continuationCount: Math.max(0, completedSegments.length - 1),
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: historyId,
      jobId: stableJobId(documentValue, 'history'),
      status: 'completed',
      sourceJobId: stableJobId(documentValue, 'history'),
      source: text(documentValue.source, 'local'),
      sourceQueueItemId: text(documentValue.sourceQueueItemId),
      sourceQueueSnapshot: isPlainObject(documentValue.sourceQueueSnapshot) ? documentValue.sourceQueueSnapshot : undefined,
      startedAt: text(documentValue.startedAt),
      transportStartedAt: text(documentValue.transportStartedAt),
      unloadingStartedAt: text(documentValue.unloadingStartedAt),
      completedAt,
      events: activeEvents(historySource),
      completedByPackageVersion: PACKAGE_VERSION
    }, 'history');
    const activeMinutes = historyService ? historyService.workMinutes(completed, new Date(completedAt).getTime()) : null;
    return { ...completed, activeWorkMinutes: activeMinutes, p116Learning: isPlainObject(completed.p116Learning) ? completed.p116Learning : { schemaVersion: 1, samples: [] } };
  }

  function confirmActiveComplete() {
    if (!pendingActiveComplete || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avslutet kunde inte bekräftas.', true);
      return;
    }
    const completedAt = text(activeJobDocument.completedAt, completionCandidateAt || new Date().toISOString());
    const existingBilling = ataBillingApi.snapshotFromRecord(activeJobDocument);
    if (ataApi.isEnabled(activeJobDocument) && !existingBilling) {
      try {
        openAtaBillingDialog(activeJobDocument, completedAt);
      } catch (error) {
        showStatus('active-action-status', error.message || 'Dialogen för debiterbar tid kunde inte öppnas.', true);
      }
      return;
    }
    finalizeActiveCompletion(existingBilling);
  }

  function finalizeActiveCompletion(billingSnapshot = null) {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists() || ataBillingActionInProgress) {
      if (ataBillingDialogOpen) showStatus('ata-billing-status', 'Avslutet kunde inte genomföras.', true);
      else showStatus('active-action-status', 'Avslutet kunde inte genomföras.', true);
      return;
    }
    const ataEnabled = ataApi.isEnabled(activeJobDocument);
    const normalizedBilling = billingSnapshot ? ataBillingApi.normalizeBilling(billingSnapshot) : ataBillingApi.snapshotFromRecord(activeJobDocument);
    if (ataEnabled && !normalizedBilling) {
      showStatus(ataBillingDialogOpen ? 'ata-billing-status' : 'active-action-status', 'Välj debiterbar tid innan ÄTA-uppdraget avslutas.', true);
      return;
    }

    ataBillingActionInProgress = true;
    const now = new Date().toISOString();
    const completedAt = text(activeJobDocument.completedAt, text(ataBillingDraft && ataBillingDraft.completedAt, completionCandidateAt || now));
    const historyId = text(activeJobDocument.completionHistoryId, `history-${text(activeJobDocument.id)}`);
    let completionSource = activeJobDocument;
    if (!isOtherActivity(completionSource)
      && phaseService.normalizePhase(completionSource.phase) !== phaseService.PHASES.READY_TO_COMPLETE) {
      completionSource = buildPhaseTransitionDocument(completionSource, phaseService.PHASES.READY_TO_COMPLETE, completedAt, 'manual_completion_override', 'manual');
    }
    if (ataEnabled && normalizedBilling) {
      completionSource = ataBillingApi.applyToRecord(completionSource, normalizedBilling, normalizedBilling.editedAt || normalizedBilling.selectedAt || now);
    }

    let completingDocument = completionSource;
    if (activeJobDocument.status !== 'completing' || !text(activeJobDocument.completionHistoryId)
      || (ataEnabled && !ataBillingApi.snapshotFromRecord(activeJobDocument))) {
      completingDocument = {
        ...completionSource,
        status: 'completing',
        completionHistoryId: historyId,
        completedAt,
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: appendActiveEvent(completionSource, 'job_completion_started', now, 'manual', ataEnabled && normalizedBilling
          ? { billableMinutes: normalizedBilling.minutes, billingMode: normalizedBilling.mode }
          : {})
      };
      pendingActiveComplete = false;
      if (!persistActiveJob(completingDocument, 'Avslutet markerades säkert före historikskrivningen.')) {
        ataBillingActionInProgress = false;
        if (ataBillingDialogOpen) showStatus('ata-billing-status', 'Debiterbar tid är vald men Aktivt jobb kunde inte sparas. Försök igen.', true);
        return;
      }
    }

    if (!loadHistoryIfNeeded('history')) {
      closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveComplete = false;
      ataBillingActionInProgress = false;
      renderActiveJob();
      showStatus('active-action-status', 'Avslutet väntar. Historiken kunde inte läsas och det aktiva uppdraget är kvar.', true);
      return;
    }

    const existingIndex = historyDocument.findIndex((item) => isPlainObject(item) && text(item.id) === historyId);
    let nextHistory = historyDocument;
    if (existingIndex < 0) {
      const record = completionRecordFromActive(completingDocument, historyId, completedAt);
      nextHistory = [...historyDocument, record];
    } else if (ataEnabled && normalizedBilling) {
      nextHistory = historyDocument.map((item, index) => index === existingIndex
        ? ataBillingApi.applyToRecord(item, normalizedBilling, normalizedBilling.editedAt || normalizedBilling.selectedAt || now)
        : item);
    }

    if (nextHistory !== historyDocument
      && !persistHistory(nextHistory, 'Det avslutade jobbet sparades i Historik.')) {
      closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveComplete = false;
      ataBillingActionInProgress = false;
      renderActiveJob();
      showStatus('active-action-status', 'Avslutet väntar. Aktivt jobb och vald debiterbar tid är bevarade och kan slutföras igen.', true);
      return;
    }

    const restoredOtherActivity = restoreOtherActivityAfterJob(completingDocument, completedAt);
    if (!persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Uppdraget är avslutat och Övrig verksamhet har återupptagits automatiskt.'
        : 'Uppdraget är avslutat. Manuellt pausad Övrig verksamhet är bevarad utan automatisk återstart.')
      : 'Uppdraget är avslutat och Aktivt jobb är tömt.')) {
      closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveComplete = false;
      ataBillingActionInProgress = false;
      renderActiveJob();
      showStatus('active-action-status', 'Historiken är sparad, men Aktivt jobb kunde inte växlas säkert. Tryck Slutför avslut igen.', true);
      return;
    }
    pendingActiveComplete = false;
    completionCandidateAt = '';
    closeAtaBillingDialog({ clearCandidate: true });
    ataBillingActionInProgress = false;
    if (restoredOtherActivity) {
      activateView('queue');
      showStatus('queue-load-status', restoredOtherActivity.status === 'active'
        ? 'Uppdraget sparades i Historik och Övrig verksamhet fortsätter automatiskt.'
        : 'Uppdraget sparades i Historik. Övrig verksamhet är fortsatt manuellt pausad.');
    } else {
      activateView('queue');
      showStatus('queue-load-status', 'Uppdraget avslutades och sparades i Idag och Historik.');
      if (ataEnabled) {
        // Mail is deliberately opened only after history and active-job writes have both succeeded.
        openIndividualUnderlag(historyId, 'completion');
      }
    }
  }

  function refreshUpdateStatus() {
    if (runtimeDisposed || runtimeFailed || !bridgeAvailable()) return;
    const element = byId('update-status');
    if (!element) return;
    const textValue = window.StadslassHost.getUpdateStatus();
    element.textContent = textValue || (hostInfo && hostInfo.updateStatus) || 'Ingen uppdateringsstatus tillgänglig.';
  }

  function requestUpdateCheck() {
    if (runtimeDisposed || runtimeFailed || !bridgeAvailable()) return;
    const element = byId('update-status');
    if (element) element.textContent = 'Söker efter funktionsuppdatering…';
    window.StadslassHost.requestUpdateCheck();
    window.setTimeout(() => {
      if (!runtimeDisposed && !runtimeFailed) refreshUpdateStatus();
    }, 250);
  }

  function installEventHandlers() {
    ['pointerdown','touchstart','keydown'].forEach((kind) => document.addEventListener(kind, p144UnlockAudio, { once: true, passive: true, capture: true }));
    byId('open-queue').addEventListener('click', () => activateView('queue'));
    byId('open-active-job').addEventListener('click', () => activateView('active'));
    byId('open-today').addEventListener('click', () => activateView('today'));
    byId('open-history-from-home').addEventListener('click', () => activateView('history'));
    byId('open-statistics-from-home').addEventListener('click', openStatisticsFromHome);
    byId('history-month').addEventListener('change', (event) => {
      historySelectedMonth = normalizedHistoryMonth(event.currentTarget.value);
      historySelectedDate = '';
      renderHistoryViews();
    });
    byId('history-calendar-today').addEventListener('click', showTodayInHistoryCalendar);
    byId('history-calendar-grid').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-history-calendar-date]');
      if (button) selectHistoryCalendarDate(button.dataset.historyCalendarDate || '');
    });
    byId('statistics-date-from').addEventListener('change', renderStatisticsView);
    byId('statistics-date-to').addEventListener('change', renderStatisticsView);
    byId('statistics-clear-filters').addEventListener('click', () => {
      byId('statistics-date-from').value = '';
      byId('statistics-date-to').value = '';
      renderStatisticsView();
    });
    byId('statistics-open-excel-mail').addEventListener('click', openExcelMailFromStatistics);
    byId('excel-mail-period').addEventListener('change', renderExcelMailPeriodControls);
    byId('excel-mail-month').addEventListener('change', renderExcelMailPeriodControls);
    byId('excel-mail-save').addEventListener('click', saveExcelMailRecipient);
    byId('excel-mail-contact-1').addEventListener('change', () => selectExcelMailContact(1));
    byId('excel-mail-contact-2').addEventListener('change', () => selectExcelMailContact(2));
    byId('excel-mail-email').addEventListener('input', () => { const select=byId('excel-mail-contact-1'); if(select) select.value=''; });
    byId('excel-mail-email-2').addEventListener('input', () => { const select=byId('excel-mail-contact-2'); if(select) select.value=''; });
    byId('excel-mail-send-1').addEventListener('click', () => mailNativeExcel(1));
    byId('excel-mail-send-2').addEventListener('click', () => mailNativeExcel(2));
    byId('machine-quick-close').addEventListener('click', () => closeMachineQuickWizard('Maskintransporten avbröts. Inget uppdrag skapades.'));
    const handleHistoryAction = (event) => {
      const underlagView = event.target.closest('button[data-ata-underlag-view]');
      const underlagOpen = event.target.closest('button[data-ata-underlag-open]');
      const underlagCopy = event.target.closest('button[data-ata-underlag-copy]');
      const dailyView = event.target.closest('button[data-ata-daily-view]');
      const dailyOpen = event.target.closest('button[data-ata-daily-open]');
      const dailyCopy = event.target.closest('button[data-ata-daily-copy]');
      const editBilling = event.target.closest('button[data-edit-history-billing]');
      const editToday = event.target.closest('button[data-edit-today]');
      const saveToday = event.target.closest('button[data-save-today-edit]');
      const cancelToday = event.target.closest('button[data-cancel-today-edit]');
      const saveBilling = event.target.closest('button[data-save-history-billing]');
      const cancelBilling = event.target.closest('button[data-cancel-history-billing]');
      const requestTrash = event.target.closest('button[data-request-history-trash]');
      const confirmTrash = event.target.closest('button[data-confirm-history-trash]');
      const cancelTrash = event.target.closest('button[data-cancel-history-trash]');
      const restoreTrash = event.target.closest('button[data-restore-history-trash]');
      const requestPermanentDelete = event.target.closest('button[data-request-history-permanent-delete]');
      const confirmPermanentDelete = event.target.closest('button[data-confirm-history-permanent-delete]');
      const cancelPermanentDelete = event.target.closest('button[data-cancel-history-permanent-delete]');
      const deleteReceipt = event.target.closest('button[data-delete-receipt-row]');
      if (deleteReceipt) {
        deleteReceiptRow(deleteReceipt.dataset.deleteReceiptRow || '');
      } else if (editToday) {
        requestTodayEdit(editToday.dataset.editToday || '');
      } else if (saveToday) {
        saveTodayEdit(saveToday.dataset.saveTodayEdit || '');
      } else if (cancelToday) {
        cancelTodayEdit(cancelToday.dataset.cancelTodayEdit || '');
      } else if (underlagView) {
        openIndividualUnderlag(underlagView.dataset.ataUnderlagView || '', underlagView.dataset.ataUnderlagSurface === 'history' ? 'history' : 'today');
      } else if (underlagOpen) {
        openIndividualUnderlag(underlagOpen.dataset.ataUnderlagOpen || '', 'today');
        handleAtaMailOpen();
      } else if (underlagCopy) {
        openIndividualUnderlag(underlagCopy.dataset.ataUnderlagCopy || '', 'today');
        handleAtaMailCopy();
      } else if (dailyView) {
        openDailyUnderlag(dailyView.dataset.ataDailyView || '');
      } else if (dailyOpen) {
        openDailyUnderlag(dailyOpen.dataset.ataDailyOpen || '');
        handleAtaMailOpen();
      } else if (dailyCopy) {
        openDailyUnderlag(dailyCopy.dataset.ataDailyCopy || '');
        handleAtaMailCopy();
      } else if (editBilling) {
        requestHistoryBillingEdit(editBilling.dataset.editHistoryBilling || '');
      } else if (saveBilling) {
        saveHistoryBillingEdit(saveBilling.dataset.saveHistoryBilling || '');
      } else if (cancelBilling) {
        cancelHistoryBillingEdit(cancelBilling.dataset.cancelHistoryBilling || '');
      } else if (requestTrash) {
        requestHistoryTrash(requestTrash.dataset.requestHistoryTrash || '');
      } else if (confirmTrash) {
        confirmHistoryTrash(confirmTrash.dataset.confirmHistoryTrash || '');
      } else if (cancelTrash) {
        cancelHistoryTrash(cancelTrash.dataset.cancelHistoryTrash || '');
      } else if (restoreTrash) {
        restoreHistoryTrash(restoreTrash.dataset.restoreHistoryTrash || '');
      } else if (requestPermanentDelete) {
        requestHistoryPermanentDelete(requestPermanentDelete.dataset.requestHistoryPermanentDelete || '');
      } else if (confirmPermanentDelete) {
        confirmHistoryPermanentDelete(confirmPermanentDelete.dataset.confirmHistoryPermanentDelete || '');
      } else if (cancelPermanentDelete) {
        cancelHistoryPermanentDelete(cancelPermanentDelete.dataset.cancelHistoryPermanentDelete || '');
      }
    };
    byId('today-list').addEventListener('click', handleHistoryAction);
    byId('history-list').addEventListener('click', handleHistoryAction);
    byId('trash-list').addEventListener('click', handleHistoryAction);
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      button.addEventListener('click', () => activateView(button.dataset.target));
    });
    document.querySelectorAll('.settings-group-button[data-settings-group]').forEach((button) => {
      button.addEventListener('click', () => toggleSettingsGroup(button.dataset.settingsGroup));
    });
    document.querySelectorAll('.settings-function-button[data-settings-function]').forEach((button) => {
      button.addEventListener('click', () => toggleSettingsFunction(button.dataset.settingsGroupOwner, button.dataset.settingsFunction));
    });
    byId('settings-form').addEventListener('submit', saveSettings);
    byId('notification-sound-test').addEventListener('click', p142TestNotificationAudio);
    byId('p121-routes-budget-correct').addEventListener('click', correctP121Budget);
    byId('google-service-form').addEventListener('submit', saveGoogleSettings);
    byId('machine-registry-form').addEventListener('submit', saveMachineRegistry);
    byId('machine-registry-cancel').addEventListener('click', () => { byId('machine-registry-form').reset(); byId('machine-registry-edit-id').value=''; byId('machine-registry-cancel').hidden=true; });
    byId('machine-registry-list').addEventListener('click', handleMachineRegistryAction);
    byId('google-service-clear').addEventListener('click', clearGoogleSettings);
    byId('quick-choice-registry-form').addEventListener('submit', saveQuickChoice);
    byId('quick-choice-registry-cancel').addEventListener('click', () => {
      resetQuickChoiceEditor();
      showStatus('quick-choice-registry-status', 'Redigeringen avbröts.');
    });
    byId('quick-choice-registry-job-type').addEventListener('change', () => {
      const selected = findJobTypeById(byId('quick-choice-registry-job-type').value);
      const nameInput = byId('quick-choice-registry-button-name');
      if (!nameInput.value || nameInput.dataset.autoSuggested === 'true') {
        nameInput.value = text(selected && selected.name);
        nameInput.dataset.autoSuggested = 'true';
      }
      populateQuickChoicePlaceOptions();
      syncQuickChoiceFormControls();
      syncAtaForm('quick', true);
    });
    byId('quick-choice-registry-button-name').addEventListener('input', (event) => {
      event.currentTarget.dataset.autoSuggested = 'false';
    });
    byId('quick-choice-registry-from').addEventListener('change', () => {
      const suggested = jobModel.suggestedDestination(byId('quick-choice-registry-job-type').value, byId('quick-choice-registry-from').value);
      if (suggested && !byId('quick-choice-registry-to').value) byId('quick-choice-registry-to').value = suggested;
      if (byId('quick-choice-registry-return-required').checked) byId('quick-choice-registry-return').value = byId('quick-choice-registry-from').value;
      syncQuickChoiceFormControls();
    });
    byId('quick-choice-registry-return-required').addEventListener('change', () => syncQuickChoiceFormControls('return'));
    byId('quick-choice-registry-multi-load').addEventListener('change', () => syncQuickChoiceFormControls('multi'));
    byId('quick-choice-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-quick-choice]');
      const remove = event.target.closest('button[data-remove-quick-choice]');
      if (edit) editQuickChoice(edit.dataset.editQuickChoice || '');
      else if (remove) removeQuickChoice(remove.dataset.removeQuickChoice || '');
    });
    byId('ata-notification-supervisor-form').addEventListener('submit', (event) => {
      event.preventDefault();
      try {
        const next = ataNotificationApi.updateSupervisor(ataNotificationSettings(), { name: byId('ata-notification-supervisor-name').value, email: byId('ata-notification-supervisor-email').value });
        if (persistAtaNotificationSettings(next, 'ata-notification-supervisor-status', 'Arbetsledare för dagsmail sparad lokalt.')) renderAtaNotificationSettings();
      } catch (error) { showStatus('ata-notification-supervisor-status', error.message || 'Arbetsledaren kunde inte sparas.', true); }
    });
    byId('ata-notification-supervisor-clear').addEventListener('click', () => {
      if (!ataNotificationSettings().supervisor) return;
      setAtaNotificationConfirmation('Rensa sparad arbetsledare för dagsmail?', 'Bekräfta rensning', () => { const next = { ...ataNotificationSettings(), supervisor: null }; if (persistAtaNotificationSettings(next, 'ata-notification-supervisor-status', 'Arbetsledare för dagsmail har rensats.')) { renderAtaNotificationSettings(); clearAtaNotificationConfirmation(); } }, 'ata-notification-supervisor-status');
    });
    byId('ata-notification-contact-form').addEventListener('submit', saveAtaNotificationContact);
    byId('ata-notification-contact-reset').addEventListener('click', () => resetAtaNotificationContactForm('Formuläret är rensat.'));
    byId('ata-notification-contact-list').addEventListener('click', handleAtaNotificationContactList);
    byId('ata-notification-contact-sync').addEventListener('click', syncAddressBookContacts);
    byId('ata-notification-template-fields').addEventListener('change', scheduleAtaNotificationTemplateSave);
    byId('ata-notification-template-closing').addEventListener('input', scheduleAtaNotificationTemplateSave);
    byId('ata-notification-template-reset').addEventListener('click', () => setAtaNotificationConfirmation('Återställ standardmallen? Dina mallval och den fria avslutningstexten återställs.', 'Återställ standardmall', () => { const next = ataNotificationApi.updateTemplate(ataNotificationSettings(), ataNotificationApi.defaultTemplate()); if (persistAtaNotificationSettings(next, 'ata-notification-template-status', 'Mailmall sparad lokalt. 12 av 12 standardfält är aktiva.')) { renderAtaNotificationSettings(); clearAtaNotificationConfirmation(); } }, 'ata-notification-template-status'));
    byId('ata-notification-confirm-accept').addEventListener('click', () => { const action = ataNotificationPendingAction; if (typeof action === 'function') action(); });
    byId('ata-notification-confirm-cancel').addEventListener('click', clearAtaNotificationConfirmation);
    byId('quick-choice-groups').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-use-quick-choice]');
      if (button) useQuickChoice(button.dataset.useQuickChoice || '');
    });
    document.querySelectorAll('input[name="quickChoiceMode"]').forEach((input) => {
      input.addEventListener('change', () => {
        clearQuickChoiceFallbackState({ clearStatus: true });
      });
    });
    byId('quick-choice-fallback-queue').addEventListener('click', queuePendingQuickChoiceFallback);
    byId('quick-choice-fallback-cancel').addEventListener('click', cancelQuickChoiceFallback);
    byId('job-type-registry-form').addEventListener('submit', saveEditableJobType);
    byId('job-type-registry-ata-enabled').addEventListener('change', () => syncAtaForm('jobtype', false));
    byId('job-type-registry-cancel').addEventListener('click', () => {
      resetEditableJobTypeEditor();
      showStatus('job-type-registry-status', 'Redigeringen avbröts.');
    });
    byId('job-type-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-job-type-registry]');
      const remove = event.target.closest('button[data-remove-job-type-registry]');
      if (edit) {
        editEditableJobType(edit.dataset.editJobTypeRegistry || '');
      } else if (remove) {
        removeEditableJobType(remove.dataset.removeJobTypeRegistry || '');
      }
    });
    byId('place-registry-form').addEventListener('submit', saveEditablePlace);
    byId('place-registry-cancel').addEventListener('click', () => {
      resetEditablePlaceEditor();
      showStatus('place-registry-status', 'Redigeringen avbröts.');
    });
    byId('place-registry-geofence-enabled').addEventListener('change', updateEditablePlaceGeofenceVisibility);
    byId('place-registry-geofence-type').addEventListener('change', updateEditablePlaceGeofenceVisibility);
    byId('place-registry-clear-geofence').addEventListener('click', () => { resetPlaceGeofenceForm(); updateEditablePlaceGeofenceVisibility(); showStatus('place-registry-status', 'Geofenceformuläret är rensat. Ändringen sparas först när du väljer Spara ändringar.'); });
    byId('place-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-place-registry]');
      const remove = event.target.closest('button[data-remove-place-registry]');
      if (edit) {
        editEditablePlace(edit.dataset.editPlaceRegistry || '');
      } else if (remove) {
        removeEditablePlace(remove.dataset.removePlaceRegistry || '');
      }
    });
    byId('beach-registry-form').addEventListener('submit', saveEditableBeach);
    byId('beach-registry-geofence-enabled').addEventListener('change', updateEditableBeachGeofenceVisibility);
    byId('beach-registry-geofence-type').addEventListener('change', updateEditableBeachGeofenceVisibility);
    byId('beach-registry-save-geofence').addEventListener('click', saveEditableBeachGeofence);
    byId('beach-registry-clear-geofence').addEventListener('click', () => { resetBeachGeofenceForm(); updateEditableBeachGeofenceVisibility(); showStatus('beach-registry-status', 'Geofenceformuläret är rensat. Ändringen sparas först när du väljer Spara geofence eller sparar badplatsen.'); });
    byId('beach-registry-cancel').addEventListener('click', () => {
      resetEditableBeachEditor();
      showStatus('beach-registry-status', 'Redigeringen avbröts.');
    });
    byId('beach-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-beach-registry]');
      const toggle = event.target.closest('button[data-toggle-beach-registry]');
      const remove = event.target.closest('button[data-remove-beach-registry]');
      if (edit) {
        editEditableBeach(edit.dataset.editBeachRegistry || '');
      } else if (toggle) {
        toggleEditableBeach(toggle.dataset.toggleBeachRegistry || '');
      } else if (remove) {
        removeEditableBeach(remove.dataset.removeBeachRegistry || '');
      }
    });
    byId('request-register-from-189').addEventListener('click', requestRegistryFrom189);
    byId('request-history-from-189').addEventListener('click', requestHistoryFromOtherUnit);
    byId('request-history-from-mobile').addEventListener('click', requestHistoryFromOtherUnit);
    byId('history-sync-conflicts').addEventListener('click', (event) => {
      const keep = event.target.closest('button[data-history-sync-keep]');
      const add = event.target.closest('button[data-history-sync-add]');
      if (keep) resolveHistorySyncConflict(keep.dataset.historySyncKeep || '', false);
      else if (add) resolveHistorySyncConflict(add.dataset.historySyncAdd || '', true);
    });
    byId('history-sync-review').addEventListener('click', (event) => {
      if (event.target.closest('button[data-history-sync-cancel]')) { showStatus('history-sync-status', 'Historikpaketet ligger kvar som väntande för senare granskning.'); return; }
      if (event.target.closest('button[data-history-sync-merge]')) {
        const selected = Array.from(document.querySelectorAll('input[data-history-sync-select]:checked')).map((input) => input.dataset.historySyncSelect || '');
        finishPendingHistoryPackage(selected);
      }
    });
    byId('check-update').addEventListener('click', requestUpdateCheck);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());
    byId('copy-watchdog').addEventListener('click', () => watchdog.copyReport(byId('watchdog-copy-status')));
    byId('gps-retry').addEventListener('click', () => {
      showStatus('gps-retry-status', 'GPS försöker igen.');
      gpsService.retry();
    });
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('visibilitychange', p144HandleAutoFetchVisibility);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushAtaNotificationTemplate(); });
    window.addEventListener('pagehide', flushAtaNotificationTemplate);
    window.addEventListener('pagehide', p144StopAutoFetch);
    byId('queue-form').addEventListener('submit', createQueueItem);
    byId('p138-send-selected').addEventListener('click', sendSelectedAssignments);
    byId('active-form-queue-submit').addEventListener('click', createLocalQueueItem);
    byId('queue-cancel-edit').addEventListener('click', cancelQueueEdit);
    byId('job-type').addEventListener('change', () => { refreshPlaceFormsForJobType(''); updateMaterialPanel(''); syncJobModeControls('queue'); syncAtaForm('queue', true); });
    byId('job-machine').addEventListener('change', () => { refreshPlaceFormsForJobType(''); syncJobModeControls('queue'); document.querySelectorAll('input[name="jobMachineBed"],input[name="jobMachineDirection"]').forEach(input=>{input.checked=false;}); byId('job-machine-workshop').value=''; byId('job-machine-weight').value=''; renderMachineQuickFlow(); });
    document.querySelectorAll('input[name="jobMachineBed"],input[name="jobMachineDirection"]').forEach(input=>input.addEventListener('change',renderMachineQuickFlow));
    byId('job-machine-workshop').addEventListener('change',renderMachineQuickFlow);
    byId('job-machine-weight').addEventListener('input',renderMachineQuickFlow);
    byId('job-from').addEventListener('change', () => { applySuggestedDestination(''); updateMaterialPanel(''); syncJobModeControls('queue'); syncTemporaryPlacePanels('queue'); });
    byId('job-destination').addEventListener('change', () => { updateMaterialPanel(''); syncTemporaryPlacePanels('queue'); });
    byId('job-return-required').addEventListener('change', () => syncJobModeControls('queue', 'return'));
    byId('job-multi-load').addEventListener('change', () => syncJobModeControls('queue', 'multi'));
    byId('active-job-type').addEventListener('change', () => { refreshPlaceFormsForJobType('active-'); updateMaterialPanel('active-'); syncJobModeControls('active'); syncAtaForm('active', true); });
    byId('active-job-machine').addEventListener('change', () => { refreshPlaceFormsForJobType('active-'); syncJobModeControls('active'); });
    ['queue', 'active', 'quick', 'jobtype'].forEach((scope) => {
      const ids = ataRecipientIds(scope);
      if (byId(ids.toggle)) byId(ids.toggle).addEventListener('change', () => syncAtaForm(scope, false));
      if (byId(ids.contact)) byId(ids.contact).addEventListener('change', () => selectAtaRecipientContact(scope));
      if (byId(ids.clear)) byId(ids.clear).addEventListener('click', () => clearAtaRecipient(scope));
    });
    byId('active-job-from').addEventListener('change', () => { applySuggestedDestination('active-'); updateMaterialPanel('active-'); syncJobModeControls('active'); syncTemporaryPlacePanels('active'); });
    byId('active-job-destination').addEventListener('change', () => { updateMaterialPanel('active-'); syncTemporaryPlacePanels('active'); });
    byId('active-job-return-required').addEventListener('change', () => syncJobModeControls('active', 'return'));
    byId('active-job-multi-load').addEventListener('change', () => syncJobModeControls('active', 'multi'));
    for (const scope of ['queue', 'active']) {
      for (const role of ['from', 'destination']) {
        const elements = temporaryFormElements(scope, role);
        elements.name.addEventListener('input', () => temporaryPlaceNameChanged(scope, role));
        elements.address.addEventListener('input', () => temporaryPlaceAddressChanged(scope, role));
        elements.check.addEventListener('click', () => checkTemporaryPlace(scope, role));
        elements.clear.addEventListener('click', () => clearTemporaryPlace(scope, role));
      }
    }
    byId('queue-list').addEventListener('click', (event) => {
      const startButton = event.target.closest('button[data-start-queue-item]');
      const editButton = event.target.closest('button[data-edit-queue-item]');
      const requestButton = event.target.closest('button[data-request-queue-delete]');
      const confirmButton = event.target.closest('button[data-confirm-queue-delete]');
      const cancelButton = event.target.closest('button[data-cancel-queue-delete]');
      if (startButton) {
        startQueueItem(startButton.dataset.startQueueItem || '');
      } else if (editButton) {
        editQueueItem(editButton.dataset.editQueueItem || '');
      } else if (requestButton) {
        requestQueueDelete(requestButton.dataset.requestQueueDelete || '');
      } else if (confirmButton) {
        confirmQueueDelete(confirmButton.dataset.confirmQueueDelete || '');
      } else if (cancelButton) {
        cancelQueueDelete(cancelButton.dataset.cancelQueueDelete || '');
      }
    });
    byId('backup-export').addEventListener('click', backupExport);
    byId('backup-import').addEventListener('click', backupPickImport);
    byId('backup-confirm').addEventListener('click', backupConfirmImport);
    byId('backup-cancel').addEventListener('click', () => { pendingBackupPreview=null; byId('backup-preview').hidden=true; showStatus('backup-status','Importen avbröts. Ingen data ändrades.'); });
    byId('receipt-file-pick').addEventListener('click', pickReceiptFile);
    byId('receipt-paste-prepare').addEventListener('click', () => prepareReceiptImport(byId('receipt-paste-input').value, { fileName: 'inklistrad text' }));
    byId('receipt-confirm').addEventListener('click', confirmReceiptImport);
    byId('receipt-cancel').addEventListener('click', cancelReceiptImport);
    byId('receipt-history-list').addEventListener('click', (event) => { const button=event.target.closest('button[data-delete-receipt-row]'); if(button) deleteReceiptRow(button.dataset.deleteReceiptRow||''); });
    byId('sync-v63-config-form').addEventListener('submit', saveSyncV63Configuration);
    byId('sync-v63-check').addEventListener('click', checkSyncV63Connection);
    byId('sync-v63-clear').addEventListener('click', clearSyncV63Configuration);
    byId('mailbox-send-test').addEventListener('click', sendMailboxTestLetter);
    byId('mailbox-fetch').addEventListener('click', fetchMailboxPost);
    window.addEventListener('stadslass:sync-result', handleGithubConnectionCheckResult);
    byId('report-mail-save').addEventListener('click', saveReportMailRecipient);
    byId('performance-monitor-start-new').addEventListener('click', startNewPerformanceTest);
    byId('performance-monitor-stop').addEventListener('click', stopPerformanceMonitor);
    byId('performance-report-copy').addEventListener('click', () => copyStoredReport('performance'));
    byId('performance-report-download').addEventListener('click', () => downloadStoredReport('performance'));
    byId('performance-report-mail').addEventListener('click', () => mailStoredReport('performance'));
    byId('performance-report-clear').addEventListener('click', () => clearReportView('performance'));
    byId('sync-diagnostic-rerun').addEventListener('click', runSyncDiagnosticInventory);
    byId('sync-report-copy').addEventListener('click', () => copyStoredReport('sync'));
    byId('sync-report-download').addEventListener('click', () => downloadStoredReport('sync'));
    byId('sync-report-mail').addEventListener('click', () => mailStoredReport('sync'));
    byId('sync-report-clear').addEventListener('click', () => clearReportView('sync'));
    window.addEventListener('stadslass:text-export-result', (event) => {
      const detail = event && event.detail ? event.detail : {};
      const requestId = text(detail.requestId);
      if (requestId && requestId === backupExportRequestId) {
        backupExportRequestId = '';
        try { window.StadslassHost.acknowledgeTextFileExportResult(requestId); } catch (_) {}
        if (detail.status === 'saved') showStatus('backup-status', 'Backup sparad.');
        else if (detail.status === 'cancelled') showStatus('backup-status', 'Sparningen av backup avbröts.');
        else showStatus('backup-status', 'Backupfilen kunde inte sparas.', true);
        return;
      }
      const exportInfo = liveReportExports.get(requestId);
      if (exportInfo) {
        liveReportExports.delete(requestId);
        renderLiveReportExportState();
        const statusId = exportInfo.type === 'performance' ? 'performance-report-status' : 'sync-diagnostic-status';
        const label = exportInfo.type === 'performance' ? 'Prestandarapport' : 'Sync-/postrapport';
        if (detail.status === 'saved') showStatus(statusId, `${label} sparad.`);
        else if (detail.status === 'cancelled') showStatus(statusId, `Sparningen av ${label.toLowerCase()} avbröts. Rapporten ligger kvar.`);
        else if (detail.status === 'write_error') showStatus(statusId, `${label} kunde inte sparas. Rapporten ligger kvar.`, true);
        return;
      }
    });
    window.addEventListener('stadslass:text-import-result', (event) => {
      const detail = event && event.detail ? event.detail : {};
      if (text(detail.requestId) === receiptImportRequestId) {
        receiptImportRequestId = '';
        if (detail.status === 'selected') prepareReceiptImport(detail.contentUtf8 || '', { fileName: text(detail.fileName) });
        else if (detail.status === 'cancelled') showStatus('receipt-status','Valet av kvittofil avbröts.');
        else if (detail.status === 'read_error') showStatus('receipt-status','Kvittofilen kunde inte läsas.',true);
      } else if (detail.status === 'selected') backupPrepareImport(detail.contentUtf8 || '');
      else if (detail.status === 'cancelled') showStatus('backup-status','Valet av backupfil avbröts.');
      else if (detail.status === 'read_error') showStatus('backup-status','Backupfilen kunde inte läsas.',true);
    });
    // Återgång till appen uppdaterar endast lokal GitHub-konfigurationsstatus; ingen synktrafik startas.
    window.addEventListener('focus', () => { if (githubSecureBridgeReady) renderSyncV63(); });
    byId('active-form').addEventListener('submit', createActiveJob);
    byId('active-phase-action').addEventListener('click', advanceActivePhase);
    byId('active-pause-action').addEventListener('click', toggleActivePause);
    byId('active-weight-submit').addEventListener('click', registerActiveWeight);
    byId('active-no-emptying').addEventListener('click', markActiveNoEmptying);
    byId('active-weight-input').addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === 'NumpadEnter') {
        event.preventDefault();
        if (registerActiveWeight()) {
          event.currentTarget.blur();
        }
      }
    });
    byId('active-complete-request').addEventListener('click', requestActiveComplete);
    byId('active-note-editor-save').addEventListener('click', saveActiveNote);
    byId('active-complete-without-weight').addEventListener('click', allowActiveCompleteWithoutWeight);
    byId('active-complete-without-weight-cancel').addEventListener('click', cancelActiveComplete);
    byId('active-complete-cancel').addEventListener('click', cancelActiveComplete);
    byId('active-complete-confirm-button').addEventListener('click', confirmActiveComplete);
    byId('ata-mail-open').addEventListener('click', handleAtaMailOpen);
    byId('ata-mail-copy').addEventListener('click', handleAtaMailCopy);
    byId('ata-mail-skip').addEventListener('click', handleAtaMailSkip);
    byId('ata-mail-close').addEventListener('click', closeAtaMailDialog);
    byId('ata-billing-save-manual').addEventListener('click', useAtaBillingManual);
    byId('ata-billing-phase-choice').addEventListener('click', showAtaBillingPhaseRoundStep);
    byId('ata-billing-total-choice').addEventListener('click', useAtaBillingTotal);
    byId('ata-billing-cancel').addEventListener('click', () => cancelAtaBillingDialog());
    byId('ata-billing-round-back').addEventListener('click', () => setAtaBillingDialogStep('choice'));
    byId('ata-billing-round-cancel').addEventListener('click', () => cancelAtaBillingDialog());
    byId('ata-billing-manual-minutes').addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === 'NumpadEnter') {
        event.preventDefault();
        useAtaBillingManual();
      }
    });
    window.addEventListener('popstate', () => {
      if (ataBillingBackGuardClosing) {
        ataBillingBackGuardClosing = false;
        return;
      }
      if (ataBillingDialogOpen) {
        ataBillingBackGuardActive = false;
        cancelAtaBillingDialog({ fromPopState: true });
      }
      if (ataMailDialogContext) closeAtaMailDialog();
    });
    window.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && ataBillingDialogOpen) {
        event.preventDefault();
        cancelAtaBillingDialog();
      }
      if (event.key === 'Escape' && ataMailDialogContext) { event.preventDefault(); closeAtaMailDialog(); }
    });
    document.addEventListener('backbutton', (event) => {
      if (ataBillingDialogOpen) {
        event.preventDefault();
        cancelAtaBillingDialog();
      }
      if (ataMailDialogContext) { event.preventDefault(); closeAtaMailDialog(); }
    });
    byId('active-reset-request').addEventListener('click', requestActiveReset);
    byId('active-reset-cancel').addEventListener('click', cancelActiveReset);
    byId('active-reset-confirm-button').addEventListener('click', confirmActiveReset);
  }

  function verifyRuntime() {
    if (!watchdog) {
      throw new Error('Runtime-Watchdog saknas.');
    }
    watchdog.step('runtime.bootstrap.verify', 'Värdbrygga, CSS och versionskontrakt verifieras.');
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    if (!syncDiagnosticApi || typeof syncDiagnosticApi.create !== 'function') {
      throw new Error('Den neutrala verifieringstjänsten saknas.');
    }
    if (!ataApi
      || typeof ataApi.normalizeSnapshot !== 'function'
      || typeof ataApi.snapshotFromRecord !== 'function'
      || typeof ataApi.isEnabled !== 'function'
      || typeof ataApi.createManual !== 'function'
      || typeof ataApi.createFromQuickChoice !== 'function'
      || typeof ataApi.editSnapshot !== 'function'
      || typeof ataApi.display !== 'function') {
      throw new Error('Den gemensamma ÄTA-modulen saknas.');
    }
    if (!ataBillingApi
      || typeof ataBillingApi.snapshotFromRecord !== 'function'
      || typeof ataBillingApi.createBilling !== 'function'
      || typeof ataBillingApi.totalWorkMinutes !== 'function'
      || typeof ataBillingApi.phaseWorkMinutes !== 'function'
      || typeof ataBillingApi.roundTotalUp !== 'function'
      || typeof ataBillingApi.halfHourOptions !== 'function'
      || typeof ataBillingApi.editRecord !== 'function') {
      throw new Error('Modulen för debiterbar ÄTA-tid saknas.');
    }
    if (!ataRouting
      || typeof ataRouting.isManualJobType !== 'function'
      || typeof ataRouting.jobAtaSnapshot !== 'function'
      || typeof ataRouting.recipientForSave !== 'function'
      || typeof ataRouting.propagateRecipient !== 'function') {
      throw new Error('Den gemensamma ÄTA-styrningen saknas.');
    }
    if (!ataNotificationApi
      || typeof ataNotificationApi.settingsFromDocument !== 'function'
      || typeof ataNotificationApi.documentWithSettings !== 'function'
      || typeof ataNotificationApi.saveContact !== 'function'
      || typeof ataNotificationApi.canonicalMatch !== 'function'
      || typeof ataNotificationApi.applyIncoming !== 'function') {
      throw new Error('Modulen för ÄTA avisering saknas.');
    }
    if (!ataMailApi
      || typeof ataMailApi.isEligible !== 'function'
      || typeof ataMailApi.individual !== 'function'
      || typeof ataMailApi.daily !== 'function'
      || typeof ataMailApi.withStatus !== 'function') {
      throw new Error('Modulen för ÄTA-underlag saknas.');
    }
    if (!quickChoiceApi
      || typeof quickChoiceApi.migrateRegistry !== 'function'
      || typeof quickChoiceApi.validateRegistry !== 'function'
      || typeof quickChoiceApi.createItem !== 'function'
      || typeof quickChoiceApi.updateItem !== 'function'
      || typeof quickChoiceApi.removeItem !== 'function'
      || typeof quickChoiceApi.referenceStatus !== 'function'
      || typeof quickChoiceApi.resolveJobTypeReference !== 'function') {
      throw new Error('Modulen för Snabbvalsregistret saknas.');
    }
    if (!editableJobTypeApi
      || typeof editableJobTypeApi.validateRegistry !== 'function'
      || typeof editableJobTypeApi.createItem !== 'function'
      || typeof editableJobTypeApi.removeItem !== 'function'
      || typeof editableJobTypeApi.migrateAndMergeRegistry !== 'function'
      || typeof editableJobTypeApi.removeFromRegistry !== 'function'
      || typeof editableJobTypeApi.resolveReference !== 'function') {
      throw new Error('Modulen för det redigerbara jobbtypsregistret saknas.');
    }
    if (!googleService
      || typeof googleService.validateSettings !== 'function'
      || typeof googleService.maskApiKey !== 'function'
      || typeof googleService.geocode !== 'function'
      || typeof googleService.reverseGeocode !== 'function'
      || typeof googleService.diagnosticFromError !== 'function'
      || typeof googleService.appendDiagnostic !== 'function'
      || typeof googleService.errorStatus !== 'function'
      || typeof googleService.userMessageForError !== 'function'
      || typeof googleService.pendingGeocoding !== 'function'
      || typeof googleService.resolvedGeocoding !== 'function'
      || typeof googleService.failedGeocoding !== 'function') {
      throw new Error('Den gemensamma Google-tjänsten saknas.');
    }
    if (!editablePlaceApi
      || typeof editablePlaceApi.validateRegistry !== 'function'
      || typeof editablePlaceApi.createItem !== 'function'
      || typeof editablePlaceApi.updateItem !== 'function'
      || typeof editablePlaceApi.applyGeocoding !== 'function'
      || typeof editablePlaceApi.removeItem !== 'function'
      || typeof editablePlaceApi.removeFromRegistry !== 'function'
      || typeof editablePlaceApi.migrateRegistry !== 'function'
      || typeof editablePlaceApi.referencesJobType !== 'function'
      || typeof editablePlaceApi.updateGeofence !== 'function'
      || typeof editablePlaceApi.buildEffectivePlaces !== 'function') {
      throw new Error('Modulen för det redigerbara platsregistret saknas.');
    }
    if (!editableBeachApi
      || typeof editableBeachApi.validateRegistry !== 'function'
      || typeof editableBeachApi.createItem !== 'function'
      || typeof editableBeachApi.updateItem !== 'function'
      || typeof editableBeachApi.applyGeocoding !== 'function'
      || typeof editableBeachApi.setActive !== 'function'
      || typeof editableBeachApi.removeFromRegistry !== 'function'
      || typeof editableBeachApi.migrateRegistry !== 'function'
      || typeof editableBeachApi.buildEffectivePlaces !== 'function'
      || typeof editableBeachApi.updateGeofence !== 'function') {
      throw new Error('Modulen för det redigerbara badplatsregistret saknas.');
    }
    if (!gpsService
      || typeof gpsService.setConsumer !== 'function'
      || typeof gpsService.subscribe !== 'function'
      || typeof gpsService.retry !== 'function') {
      throw new Error('Den gemensamma GPS-tjänsten saknas.');
    }
    if (!temporaryPlaceService
      || typeof temporaryPlaceService.selectionId !== 'function'
      || typeof temporaryPlaceService.normalizePlace !== 'function'
      || typeof temporaryPlaceService.runtimePlace !== 'function'
      || typeof temporaryPlaceService.placeForJobRole !== 'function') {
      throw new Error('Modulen för Annan plats saknas.');
    }
    if (!routesService || typeof routesService.fetchDistance !== 'function' || !historyService || typeof historyService.workMinutes !== 'function') {
      throw new Error('P116:s sträcke- eller tidstjänst saknas.');
    }
    if (!historyArchiveApi || typeof historyArchiveApi.load !== 'function') {
      throw new Error('Historikarkivets migrationskälla saknas.');
    }
    if (!phaseService
      || typeof phaseService.normalizePhase !== 'function'
      || typeof phaseService.initializeRecord !== 'function'
      || typeof phaseService.transitionRecord !== 'function'
      || typeof phaseService.closeRecord !== 'function'
      || typeof phaseService.determineInitialPhase !== 'function') {
      throw new Error('Den gemensamma fasmotorn saknas.');
    }
    if (!phaseActionService
      || typeof phaseActionService.resolve !== 'function'
      || typeof phaseActionService.markReturnUnloadingCompleted !== 'function') {
      throw new Error('Fasknappens gemensamma fasfunktion saknas.');
    }
    if (!phaseVisualService
      || typeof phaseVisualService.normalizeColors !== 'function'
      || typeof phaseVisualService.resolveColor !== 'function'
      || typeof phaseVisualService.markLoadRegistered !== 'function'
      || typeof phaseVisualService.remainingMs !== 'function') {
      throw new Error('Fasfärg och Lass registrerat-tjänsten saknas.');
    }
    if (!geofenceService
      || typeof geofenceService.normalizeDefinition !== 'function'
      || typeof geofenceService.setActiveContext !== 'function'
      || typeof geofenceService.subscribeEvents !== 'function'
      || typeof geofenceService.pointInPolygon !== 'function') {
      throw new Error('Den gemensamma geofence-tjänsten saknas.');
    }
    const styleReady = getComputedStyle(document.documentElement).getPropertyValue('--module-style-ready').trim();
    if (styleReady !== '1') {
      throw new Error('Modulens CSS kunde inte verifieras.');
    }
    hostInfo = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!hostInfo) {
      throw new Error('Värdinformationen kunde inte läsas.');
    }
    if (Number(hostInfo.hostVersionCode) < MINIMUM_HOST_VERSION) {
      throw new Error('Host24 eller senare krävs för P163:s native verksamhetslagring.');
    }
    if (Number(hostInfo.googleTransportApiVersion) < 1 || typeof window.StadslassHost.getGoogleTransportStatus !== 'function') {
      throw new Error('Värdappens säkra Google Routes-transport saknas.');
    }
    if (Number(hostInfo.mailboxTransportApiVersion) < 1 || typeof window.StadslassHost.requestMailboxTransport !== 'function') {
      throw new Error('Host24:s mailboxtransport saknas.');
    }
    if (!nativeStorage || typeof nativeStorage.assertCapabilities !== 'function' || typeof nativeStorage.migrate !== 'function') {
      throw new Error('P163:s centrala native lagringsadapter saknas.');
    }
    nativeStorage.assertCapabilities(hostInfo);
    if (Number(hostInfo.packageVersion) !== PACKAGE_VERSION) {
      throw new Error('Paketversionen i värdbryggan stämmer inte.');
    }
    if (Number(hostInfo.watchdogApiVersion) < 1) {
      throw new Error('Värdappens Watchdog-brygga saknas eller är för gammal.');
    }
    if (Number(hostInfo.emailDraftApiVersion) < 1 || Number(hostInfo.clipboardApiVersion) < 1) {
      throw new Error('Värdappens mail- eller kopieringsfunktion saknas.');
    }
    watchdog.setContext(hostInfo);
  }

  async function start() {
    try {
      // P137 startar den fristående prestandamonitorn före övrig paketlogik; färdiga rapporter återställs efter inställningsläsningen.
      try { const monitor = performanceEnsure(); if (monitor) monitor.start(); } catch (_) {}
      try {
        syncDiagnosticEnsure();
        syncDiagnosticObserve('diagnostic-activated', { order: 'after-performance-monitor' });
      } catch (_) {}
      if (!watchdog) {
        throw new Error('Runtime-Watchdog kunde inte laddas.');
      }
      watchdog.step('runtime.bootstrap.start', `Funktionspaket ${PACKAGE_VERSION} startar.`);
      verifyRuntime();
      performanceObserve('app-start', { hostVersion: text(hostInfo && hostInfo.hostVersionName), role: text(hostInfo && hostInfo.role) });
      syncDiagnosticObserve('bootstrap-verified', { packageVersion: PACKAGE_VERSION });
      watchdog.step('runtime.native-storage.migration-start', 'P163 verifierar eller migrerar lokal beständig verksamhetsdata kategori för kategori innan normal drift och Sync startar.');
      const archiveSeed = await historyArchiveApi.load();
      try {
        await nativeStorage.migrate({ archiveRecords: Array.from(archiveSeed.records || []) });
      } catch (migrationError) {
        if (typeof watchdog.setStorageDiagnostics === 'function') {
          try { watchdog.setStorageDiagnostics(nativeStorage.diagnostics()); } catch (_) {}
        }
        throw migrationError;
      }
      try {
        const storageDiagnostics = await nativeStorage.refreshDiagnostics();
        if (typeof watchdog.setStorageDiagnostics === 'function') watchdog.setStorageDiagnostics(storageDiagnostics);
      } catch (diagnosticError) {
        watchdog.step('runtime.native-storage.diagnostics-warning', diagnosticError.message || 'Native lagringsdiagnostik kunde inte uppdateras.', 'warning');
      }
      watchdog.step('runtime.native-storage.migration-complete', 'Alla obligatoriska lokala kategorier är verifierade. Sync får starta efter READY.');
      settingsDocument = readSettingsDocument();
      discardPreP152PendingRegistryPackage();
      loadStoredReportSnapshots();
      renderReportMailProfile();
      renderReportViews();
      loadGoogleSettings();
      loadEditableJobTypeRegistry();
      loadEditablePlaceRegistry();
      loadEditableBeachRegistry();
      buildEffectivePlaceRegistry();
      validateRegistries();
      loadQuickChoiceRegistry();
      populateRegistryForms();
      refreshPlaceFormsForJobType('');
      refreshPlaceFormsForJobType('active-');
      syncJobModeControls('queue');
      syncJobModeControls('active');
      updateMaterialPanel('');
      updateMaterialPanel('active-');
      resetEditableJobTypeEditor();
      resetEditablePlaceEditor();
      resetEditableBeachEditor();
      resetQuickChoiceEditor();
      renderGoogleSettings();
      renderEditableJobTypeRegistry();
      renderEditablePlaceRegistry();
      renderEditableBeachRegistry();
      renderMachineRegistry();
      renderQuickChoiceRegistry();
      renderAtaNotificationSettings();
      renderQuickChoices();
      renderReceiptHistory();
      watchdog.step('runtime.ui.preferences', 'Sparade UI-inställningar tillämpas utan automatisk skrivning.');
      applyUiPreferences(normalizedUiPreferences(settingsDocument));
      renderHostInfo();
      applyRoleBoundaries();
      if (canUseActiveJob()) {
        loadActiveJobIfNeeded();
      }
      installBottomNavLayoutGuard();
      const registryButton = byId('request-register-from-189'); if (registryButton) registryButton.hidden = mailboxUnitFromRole() !== 'mobile';
      const mobileHistoryButton = byId('request-history-from-189'); if (mobileHistoryButton) mobileHistoryButton.hidden = mailboxUnitFromRole() !== 'mobile';
      const vehicleHistoryButton = byId('request-history-from-mobile'); if (vehicleHistoryButton) vehicleHistoryButton.hidden = mailboxUnitFromRole() !== '189';
      const vehicleHistoryPanel = byId('history-sync-panel'); if (vehicleHistoryPanel) vehicleHistoryPanel.hidden = mailboxUnitFromRole() !== '189';
      const conflictCard = byId('history-sync-conflict-card'); if (conflictCard) conflictCard.hidden = !canUseQueue();
      installPressFeedback();
      installEventHandlers();
      restoreRuntimeView();
      renderSyncV63();
      watchdog.step('runtime.mailbox.pre-ready', 'Beställningsstyrd Sync är installerad men startar ingen GitHub-trafik före READY.');
      unsubscribeGpsSnapshot = gpsService.subscribe(renderGpsSnapshot);
      p116StartTimeTicker();
      unsubscribeGeofenceEvents = geofenceService.subscribeEvents(handleGeofenceEvent);
      geofenceRuntimeReady = true;
      watchdog.step('runtime.geofence.ready', 'Gemensam cirkel-/polygonmotor och visuell fasmotor verifierades utan separat GPS-bevakning eller manuella arbetsåtgärder.');
      refreshUpdateStatus();
      if (!runtimeDisposed && !runtimeFailed) updatePollTimer = window.setInterval(refreshUpdateStatus, 2500);
      watchdog.ready();
      byId('watchdog-state').textContent = watchdog.getStatus();
      byId('watchdog-phase').textContent = watchdog.getLastPhase();
      window.StadslassHost.markReady(PACKAGE_VERSION);
      githubSecureBridgeReady = true;
      p144ScheduleAutoFetch();
      mailboxSyncEnsure();
      resumePendingRegistryPackage();
      pendingHistorySyncPackage = historySyncState().pendingPackage || null;
      renderHistorySyncConflicts();
      renderHistorySyncReview();
      // Väntande historikpaket bevaras, men öppnas bara när användaren själv väljer Historik.
      renderSyncV63();
      renderMailboxSync();
      watchdog.step('runtime.mailbox.ready', 'P144 mailboxtransport är redo. Gul Kö-notis släcks när Kö öppnas, valt notisljud används en gång per hämtning med nytt verksamhetsinnehåll och automatisk hämtning körs var femte minut endast när appen är aktiv.');
      p119RoutesTrusted = true;
      p119RouteGeneration += 1;
      p122ScheduleDrivingRoutes('ready', true);
      gpsRuntimeReady = true;
      gpsService.setForeground(document.visibilityState !== 'hidden');
      syncGpsDiagnosticsConsumer();
      syncActiveJobGpsConsumer();
      syncActiveGeofenceContext();
    } catch (error) {
      if (watchdog) {
        watchdog.fail(error, 'runtime.bootstrap.failed');
      } else {
        const main = document.createElement('main');
        main.className = 'content';
        const heading = document.createElement('h1');
        heading.textContent = 'Stadslass kunde inte starta';
        const body = document.createElement('p');
        body.textContent = error && error.message ? error.message : 'Okänt startfel.';
        main.append(heading, body);
        document.body.replaceChildren(main);
      }
    }
  }

  function disposeRuntime(options = {}) {
    const failed = options && options.failed === true;
    if (failed) runtimeFailed = true;
    if (runtimeDisposed) return;
    runtimeDisposed = true;
    if (mailboxSync && typeof mailboxSync.dispose === 'function') { try { mailboxSync.dispose(); } catch (_) {} mailboxSync = null; }
    if (p141NotificationAudioContext && typeof p141NotificationAudioContext.close === 'function') { try { p141NotificationAudioContext.close(); } catch (_) {} p141NotificationAudioContext = null; p141NotificationBufferPromise = null; }
    if (p122RouteScheduleTimer !== null) {
      window.clearTimeout(p122RouteScheduleTimer);
      p122RouteScheduleTimer = null;
    }
    if (ataBillingDialogOpen) closeAtaBillingDialog({ fromPopState: true });
    if (ataMailDialogContext) closeAtaMailDialog();
    cancelPendingPressActions();
    clearLoadRegisteredTimer();
    if (performanceMonitor) performanceMonitor.stop(failed ? 'runtime-failed' : 'runtime-disposed');
    if (updatePollTimer !== null) {
      window.clearInterval(updatePollTimer);
      updatePollTimer = null;
    }
    window.removeEventListener('resize', updateBottomNavReservedSpace);
    window.removeEventListener('orientationchange', updateBottomNavReservedSpace);
    if (bottomNavResizeObserver) {
      bottomNavResizeObserver.disconnect();
      bottomNavResizeObserver = null;
    }
    if (bottomNavLayoutFrame !== null) {
      window.cancelAnimationFrame(bottomNavLayoutFrame);
      bottomNavLayoutFrame = null;
    }
    if (unsubscribeGpsSnapshot) {
      unsubscribeGpsSnapshot();
      unsubscribeGpsSnapshot = null;
    }
    if (unsubscribeGeofenceEvents) {
      unsubscribeGeofenceEvents();
      unsubscribeGeofenceEvents = null;
    }
    document.removeEventListener('visibilitychange', handleVisibilityChange);
    geofenceRuntimeReady = false;
    if (geofenceService && typeof geofenceService.destroy === 'function') geofenceService.destroy();
    gpsRuntimeReady = false;
    if (gpsService && typeof gpsService.destroy === 'function') gpsService.destroy();
  }

  function handleRuntimeFatal() {
    disposeRuntime({ failed: true });
  }

  window.addEventListener('stadslass-runtime-fatal', handleRuntimeFatal);
  window.addEventListener('pagehide', () => disposeRuntime());
  window.addEventListener('beforeunload', () => disposeRuntime());

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
