(() => {
  'use strict';

  const SETTINGS_KEY = 'editableBeachRegistryV1';
  const SCHEMA_VERSION = 1;
  const MANUAL_ID_PATTERN = /^BP3-[0-9a-f]{32}$/;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedText(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function emptyRegistry() {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      items: []
    };
  }

  function randomBytes() {
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(bytes);
      return bytes;
    }
    const seed = `${Date.now()}-${Math.random()}-${Math.random()}`;
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = seed.charCodeAt(index % seed.length) ^ Math.floor(Math.random() * 256);
    }
    return bytes;
  }

  function generateStableId(items = []) {
    const existing = new Set(items.map((item) => text(item && item.id)));
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const hex = Array.from(randomBytes(), (value) => value.toString(16).padStart(2, '0')).join('');
      const id = `BP3-${hex}`;
      if (!existing.has(id)) return id;
    }
    throw new Error('Ett unikt badplats-ID kunde inte skapas.');
  }

  function validateItem(item) {
    if (!isPlainObject(item)) throw new Error('En badplats har fel format.');
    if (!MANUAL_ID_PATTERN.test(text(item.id))) throw new Error('En badplats saknar ett giltigt stabilt ID.');
    if (!normalizedText(item.name)) throw new Error('Badplatsens namn saknas.');
    if (normalizedText(item.name).length > 100) throw new Error('Badplatsens namn får vara högst 100 tecken.');
    if (!text(item.createdAt) || !text(item.updatedAt)) throw new Error('Badplatsens tidsstämplar saknas.');
    return true;
  }

  function validateItems(items) {
    if (!Array.isArray(items)) throw new Error('Badplatsregistret saknar en giltig lista.');
    const ids = new Set();
    const names = new Set();
    items.forEach((item) => {
      validateItem(item);
      const id = text(item.id);
      const nameKey = normalizedText(item.name).toLocaleLowerCase('sv-SE');
      if (ids.has(id)) throw new Error('Badplatsregistret innehåller dubbla ID:n.');
      if (names.has(nameKey)) throw new Error('Det finns redan en badplats med samma namn.');
      ids.add(id);
      names.add(nameKey);
    });
    return true;
  }

  function validateRegistry(registry) {
    if (!isPlainObject(registry)) throw new Error('Badplatsregistret har fel format.');
    if (registry.schemaVersion !== SCHEMA_VERSION) throw new Error('Badplatsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Badplatsregistret har en ogiltig revision.');
    validateItems(registry.items);
    return true;
  }

  function normalizedInput(input) {
    const value = isPlainObject(input) ? input : {};
    return {
      name: normalizedText(value.name)
    };
  }

  function createItem(input, existingItems = [], timestamp = new Date().toISOString()) {
    const item = {
      id: generateStableId(existingItems),
      ...normalizedInput(input),
      createdAt: timestamp,
      updatedAt: timestamp
    };
    validateItems(existingItems.concat(item));
    return item;
  }

  function updateItem(current, input, existingItems = [], timestamp = new Date().toISOString()) {
    validateItem(current);
    const updated = {
      ...current,
      ...normalizedInput(input),
      updatedAt: timestamp
    };
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Badplatsen som skulle redigeras saknas.');
    validateItems(nextItems);
    return updated;
  }

  function removeItem(current, existingItems = []) {
    validateItem(current);
    if (!existingItems.some((item) => item.id === current.id)) throw new Error('Badplatsen som skulle tas bort saknas.');
    const nextItems = existingItems.filter((item) => item.id !== current.id);
    validateItems(nextItems);
    return nextItems;
  }

  function withItems(registry, items, timestamp = new Date().toISOString()) {
    validateRegistry(registry);
    validateItems(items);
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      items: items.map((item) => ({ ...item }))
    };
    validateRegistry(next);
    return next;
  }

  window.StadslassBeachRegistry = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    emptyRegistry,
    validateItem,
    validateRegistry,
    createItem,
    updateItem,
    removeItem,
    withItems
  });
})();
