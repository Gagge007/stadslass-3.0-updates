#!/usr/bin/env python3
"""Static package contract for Stadslass 3.0 function package 63."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def require(condition, message):
    if not condition:
        raise AssertionError(message)

module = json.loads((ROOT / 'module.json').read_text(encoding='utf-8'))
app = (ROOT / 'js/app.js').read_text(encoding='utf-8')
service = (ROOT / 'js/sync-service.js').read_text(encoding='utf-8')
html = (ROOT / 'index.html').read_text(encoding='utf-8')
schema = json.loads((ROOT / 'data/sync-schema.json').read_text(encoding='utf-8'))
functions = json.loads((ROOT / 'data/functions.json').read_text(encoding='utf-8'))

require(module['packageVersion'] == 63, 'module packageVersion must be 63')
require(module['minHostVersionCode'] == 12, 'package 63 must require host v12')
require(module['packageType'] == 'stadslass-web-module', 'module package type changed')
require('js/sync-service.js' in html and 'js/sync-protocol.js' in html, 'both sync paths must be loaded')
require("const PACKAGE_VERSION = 63;" in app, 'app must expose version 63')
require("const MINIMUM_HOST_VERSION = 12;" in app, 'app must declare host v12 package minimum')
require('getHostInfo' in app and 'getDeviceIdentity' in app and 'enqueueSyncRequest' in service, 'v12 bridge is not integrated')
require('setSyncConfiguration' in app and 'clearSyncConfiguration' in app, 'safe configuration controls missing')
require('stadslass:sync-result' in app and 'getSyncRequestStatus' in service, 'missed-result recovery missing')
require('active_work' in service and 'shared_queue' in service and 'on_demand' in service, 'required priorities missing')
require('SYNC_RUNTIME_POLICY_V63' in service, 'sync policy must be central')
require('planning-commands.json' in app and 'command-results.json' in app, 'planning ledger/result protocol missing')
require("lease: 'stadslass3.work-lease.v1'" in service and 'vehicle_189' in app, 'work ownership is missing')
require('driftlogg_v4_full' not in app + service, 'protected 2.0 storage must not be touched')

store_constants = set(re.findall(r"const\s+[A-Z_]+_STORE\s*=\s*'([^']+)'", app))
require(store_constants == {'settings', 'queue', 'activeJob', 'history', 'syncOutbox'}, f'unexpected store set: {sorted(store_constants)}')
require('writeStore(ACTIVE_JOB_STORE' in app and 'sync-v63-mirror-active' in app, 'active status must be local-only plus read mirror')
require('innerHTML' not in app, 'remote sync text must not use innerHTML')
require('browseradapter' not in (app + service).lower() and 'lastbil 205' not in (app + service).lower(), 'web/multi-vehicle scope leaked in')
require('sync-v63-token' in html and 'type="password"' in html, 'token field missing')
require('GitHub-token' not in service, 'token must not be handled in sync service')

sync_rules = ' '.join(schema.get('rules', []))
for required in ['Automatic GitHub sync', 'read-only', 'activeJob', 'shared queue', 'manual text transfer']:
    require(required.lower() in sync_rules.lower(), f'sync schema lacks rule: {required}')

required_functions = {
    'SYNC-V63-CONFIG', 'SYNC-V63-SERVICE', 'SYNC-V63-ACTIVE-MIRROR', 'SYNC-V63-SHARED-QUEUE',
    'SYNC-V63-PLANNING-COMMANDS', 'SYNC-V63-RECEIPT', 'SYNC-V63-OWNERSHIP', 'SYNC-V63-ON-DEMAND',
    'SYNC-V63-OFFLINE', 'SYNC-V63-DIAGNOSTICS', 'SYNC-V63-MANUAL-RESERVE'
}
found_functions = {item.get('id') for item in functions.get('functions', [])}
require(required_functions <= found_functions, f'missing function registrations: {sorted(required_functions-found_functions)}')

for report_name in ['build-decision.json', 'technical-test-report.json', 'regression-report.json', 'migration-report.json', 'error-state-report.json', 'sync-architecture-report.json', 'sync-protocol-report.json', 'security-report.json', 'role-and-ownership-report.json', 'deferred-practical-test-report.json']:
    report = json.loads((ROOT / 'reports' / report_name).read_text(encoding='utf-8'))
    require(report.get('packageVersion') == 63, f'{report_name} must be for package 63')

entries = {item['path']: item for item in module['files']}
actual = {str(path.relative_to(ROOT)).replace('\\', '/') for path in ROOT.rglob('*') if path.is_file() and path.name != 'module.json' and '__pycache__' not in path.parts and path.suffix != '.pyc'}
require(set(entries) == actual, f'manifest differs: missing={sorted(actual-set(entries))}, extra={sorted(set(entries)-actual)}')
for name, entry in entries.items():
    content = (ROOT / name).read_bytes()
    require(entry['size'] == len(content), f'manifest size mismatch: {name}')
    require(entry['sha256'] == hashlib.sha256(content).hexdigest(), f'manifest hash mismatch: {name}')

for path in ROOT.rglob('*'):
    if not path.is_file():
        continue
    require(path.suffix.lower() not in {'.pem', '.key', '.p12', '.pfx'}, f'private key-like file included: {path.name}')
    if path.suffix.lower() in {'.js', '.json', '.html', '.css', '.py', '.txt', '.md'}:
        value = path.read_text(encoding='utf-8', errors='ignore')
        private_marker = 'BEGIN ' + 'PRIVATE KEY'
        rsa_marker = 'BEGIN RSA ' + 'PRIVATE KEY'
        require(private_marker not in value and rsa_marker not in value, f'private content in {path.name}')
        local_build_prefix = '/mnt' + '/data/'
        require(local_build_prefix not in value, f'local build path in {path.name}')

print(json.dumps({'status': 'PASS', 'packageVersion': 63, 'minHostVersionCode': 12, 'registeredFunctions': len(required_functions), 'storeNames': sorted(store_constants)}, ensure_ascii=False))
