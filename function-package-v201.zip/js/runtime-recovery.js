(() => {
  'use strict';
  const host=()=>window.StadslassHost;
  const diagnostic=(event,data)=>{try{window.StadslassBackgroundDiagnostic?.record(event,data);}catch(_){}};
  const jobId=j=>window.StadslassJobModel ? window.StadslassJobModel.stableJobId(j,'active') : String(j.jobId||j.id||'');
  function read(slot) {try{const h=host();const v=h&&typeof h.readRuntimeCheckpoint==='function'?h.readRuntimeCheckpoint(slot):window.localStorage.getItem('stadslass.runtime.'+slot);const parsed=JSON.parse(v||'{}');return parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{};}catch(_){return {};}}
  function write(slot,value) {try {const h=host(),json=JSON.stringify(value);if(json.length>65536)return false;if(h&&typeof h.writeRuntimeCheckpoint==='function')return h.writeRuntimeCheckpoint(slot,json)===true;window.localStorage.setItem('stadslass.runtime.'+slot,json);return true;}catch(_){return false;}}
  function clear(slot) {const ok=write(slot,{});diagnostic(slot+'.checkpoint.clear',{result:ok});return ok;}
  function navigation(job) {return write('route',{schemaVersion:1,jobId:jobId(job),view:'active',at:Date.now()});}
  function restoreRoute(job) {const v=read('route');clear('route');const valid=v.schemaVersion===1&&v.view==='active'&&job&&job.status==='active'&&v.jobId===jobId(job)&&Number.isFinite(v.at)&&v.at<=Date.now()&&Date.now()-v.at<=43200000;diagnostic('route.checkpoint.restore',{result:!!valid});return valid?'active':'';}
  window.StadslassRuntimeRecovery=Object.freeze({read,write,clear,navigation,restoreRoute});
})();
