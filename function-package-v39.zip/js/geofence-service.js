(() => {
  'use strict';

  const TYPES = Object.freeze({ CIRCLE: 'circle', POLYGON: 'polygon' });
  const ROLE_LABELS = Object.freeze({ from: 'Från', destination: 'Till', return: 'Retur' });
  const EARTH_RADIUS_METERS = 6371008.8;
  const gps = window.StadslassGpsService || null;
  const eventListeners = new Set();
  let unsubscribeGps = null;
  let activeContext = null;
  let confirmedState = 'unknown';
  let latestDiagnostic = Object.freeze({ reason: 'NO_CONTEXT', at: new Date().toISOString() });

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    if (typeof value === 'string' && !value.trim()) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : Number.NaN;
  }

  function validLatitude(value) {
    return Number.isFinite(value) && value >= -90 && value <= 90;
  }

  function validLongitude(value) {
    return Number.isFinite(value) && value >= -180 && value <= 180;
  }

  function normalizePoint(value) {
    const latitude = Array.isArray(value) ? optionalNumber(value[0]) : optionalNumber(value && (value.latitude ?? value.lat));
    const longitude = Array.isArray(value) ? optionalNumber(value[1]) : optionalNumber(value && (value.longitude ?? value.lon ?? value.lng));
    if (!validLatitude(latitude) || !validLongitude(longitude)) return null;
    return Object.freeze({ latitude, longitude });
  }

  function normalizePoints(value) {
    if (!Array.isArray(value)) return [];
    const points = value.map(normalizePoint).filter(Boolean);
    if (points.length > 1) {
      const first = points[0];
      const last = points[points.length - 1];
      if (first.latitude === last.latitude && first.longitude === last.longitude) points.pop();
    }
    return points;
  }

  function normalizeDefinition(value, fallbackCoordinates = null) {
    const source = isPlainObject(value) ? value : {};
    const fallback = normalizePoint(fallbackCoordinates);
    const type = text(source.type) === TYPES.POLYGON ? TYPES.POLYGON : TYPES.CIRCLE;
    const sourceLatitude = optionalNumber(source.latitude);
    const sourceLongitude = optionalNumber(source.longitude);
    const circleLatitude = validLatitude(sourceLatitude) ? sourceLatitude : (fallback ? fallback.latitude : null);
    const circleLongitude = validLongitude(sourceLongitude) ? sourceLongitude : (fallback ? fallback.longitude : null);
    return Object.freeze({
      enabled: source.enabled === true,
      type,
      visualLoadingLock: source.visualLoadingLock === true,
      visualUnloadingLock: source.visualUnloadingLock === true,
      latitude: type === TYPES.CIRCLE ? circleLatitude : null,
      longitude: type === TYPES.CIRCLE ? circleLongitude : null,
      radiusMeters: type === TYPES.CIRCLE ? optionalNumber(source.radiusMeters) : null,
      polygonPoints: type === TYPES.POLYGON ? Object.freeze(normalizePoints(source.polygonPoints || source.points)) : Object.freeze([]),
      toleranceMeters: optionalNumber(source.toleranceMeters)
    });
  }

  function validateDefinition(value, options = {}) {
    const definition = normalizeDefinition(value);
    if (![TYPES.CIRCLE, TYPES.POLYGON].includes(definition.type)) throw new Error('Geofencets typ är ogiltig.');
    if (definition.toleranceMeters !== null && (Number.isNaN(definition.toleranceMeters) || definition.toleranceMeters < 0 || definition.toleranceMeters > 100000)) {
      throw new Error('Geofencets tolerans måste vara minst 0 och högst 100000 meter.');
    }
    if (definition.type === TYPES.CIRCLE) {
      const coordinatePair = validLatitude(definition.latitude) && validLongitude(definition.longitude);
      if ((definition.latitude === null) !== (definition.longitude === null)) throw new Error('Geofencets centrumkoordinater måste finnas som ett par.');
      if (definition.radiusMeters !== null && (Number.isNaN(definition.radiusMeters) || definition.radiusMeters <= 0 || definition.radiusMeters > 100000)) {
        throw new Error('Geofencets radie måste vara större än 0 och högst 100000 meter.');
      }
      if (definition.enabled && !coordinatePair && options.allowMissingCircleCenter !== true) throw new Error('Cirkelgeofence saknar giltig centrumkoordinat.');
      if (definition.enabled && definition.radiusMeters === null) throw new Error('Cirkelgeofence saknar radie.');
    } else {
      if (definition.polygonPoints.length > 0 && definition.polygonPoints.length < 3) throw new Error('Polygongeofence måste ha minst tre giltiga punkter.');
      if (definition.enabled && definition.polygonPoints.length < 3) throw new Error('Polygongeofence måste ha minst tre giltiga punkter.');
      const unique = new Set(definition.polygonPoints.map((point) => `${point.latitude},${point.longitude}`));
      if (definition.enabled && unique.size < 3) throw new Error('Polygongeofence måste ha minst tre olika punkter.');
    }
    if (definition.enabled && definition.toleranceMeters === null) throw new Error('Geofencets tolerans måste fyllas i när Geofence är aktiverat.');
    return definition;
  }

  function parsePolygonPoints(value) {
    const source = typeof value === 'string' ? value : '';
    if (!source.trim()) return [];
    return source.split(/\r?\n/).map((line, index) => {
      const trimmed = line.trim();
      if (!trimmed) return null;
      const parts = trimmed.split(/[;,\s]+/).filter(Boolean);
      if (parts.length !== 2) throw new Error(`Polygonpunkt ${index + 1} måste innehålla latitud och longitud.`);
      const point = normalizePoint([parts[0], parts[1]]);
      if (!point) throw new Error(`Polygonpunkt ${index + 1} innehåller ogiltiga koordinater.`);
      return point;
    }).filter(Boolean);
  }

  function formatPolygonPoints(points) {
    return normalizePoints(points).map((point) => `${point.latitude}, ${point.longitude}`).join('\n');
  }

  function toRadians(value) { return value * Math.PI / 180; }

  function distanceMeters(a, b) {
    const p1 = normalizePoint(a); const p2 = normalizePoint(b);
    if (!p1 || !p2) return Number.NaN;
    const lat1 = toRadians(p1.latitude); const lat2 = toRadians(p2.latitude);
    const dLat = lat2 - lat1; const dLon = toRadians(p2.longitude - p1.longitude);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
    return 2 * EARTH_RADIUS_METERS * Math.asin(Math.min(1, Math.sqrt(h)));
  }

  function pointInPolygon(pointValue, pointsValue) {
    const point = normalizePoint(pointValue); const points = normalizePoints(pointsValue);
    if (!point || points.length < 3) return false;
    let inside = false;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
      const xi = points[i].longitude; const yi = points[i].latitude;
      const xj = points[j].longitude; const yj = points[j].latitude;
      const intersects = ((yi > point.latitude) !== (yj > point.latitude))
        && (point.longitude < ((xj - xi) * (point.latitude - yi) / ((yj - yi) || Number.EPSILON)) + xi);
      if (intersects) inside = !inside;
    }
    return inside;
  }

  function localXY(point, origin) {
    const latitudeScale = Math.PI * EARTH_RADIUS_METERS / 180;
    const longitudeScale = latitudeScale * Math.cos(toRadians(origin.latitude));
    return { x: (point.longitude - origin.longitude) * longitudeScale, y: (point.latitude - origin.latitude) * latitudeScale };
  }

  function segmentDistanceMeters(point, a, b) {
    const p = localXY(point, point); const p1 = localXY(a, point); const p2 = localXY(b, point);
    const dx = p2.x - p1.x; const dy = p2.y - p1.y;
    if (dx === 0 && dy === 0) return Math.hypot(p.x - p1.x, p.y - p1.y);
    const t = Math.max(0, Math.min(1, ((p.x - p1.x) * dx + (p.y - p1.y) * dy) / (dx * dx + dy * dy)));
    return Math.hypot(p.x - (p1.x + t * dx), p.y - (p1.y + t * dy));
  }

  function distanceToPolygonBoundaryMeters(pointValue, pointsValue) {
    const point = normalizePoint(pointValue); const points = normalizePoints(pointsValue);
    if (!point || points.length < 3) return Number.NaN;
    let nearest = Number.POSITIVE_INFINITY;
    for (let i = 0; i < points.length; i += 1) {
      nearest = Math.min(nearest, segmentDistanceMeters(point, points[i], points[(i + 1) % points.length]));
    }
    return nearest;
  }

  function classifyPosition(definitionValue, snapshot) {
    const definition = validateDefinition(definitionValue);
    const point = normalizePoint(snapshot);
    const accuracy = optionalNumber(snapshot && snapshot.accuracy);
    if (!point || !Number.isFinite(accuracy) || accuracy < 0) return Object.freeze({ state: 'uncertain', reason: 'POSITION_INVALID' });
    const tolerance = definition.toleranceMeters || 0;
    if (definition.type === TYPES.CIRCLE) {
      const distance = distanceMeters(point, { latitude: definition.latitude, longitude: definition.longitude });
      if (distance + accuracy <= definition.radiusMeters) return Object.freeze({ state: 'inside', distanceMeters: distance });
      if (distance - accuracy >= definition.radiusMeters + tolerance) return Object.freeze({ state: 'outside', distanceMeters: distance });
      return Object.freeze({ state: 'uncertain', reason: 'BOUNDARY_UNCERTAIN', distanceMeters: distance });
    }
    const inside = pointInPolygon(point, definition.polygonPoints);
    const edgeDistance = distanceToPolygonBoundaryMeters(point, definition.polygonPoints);
    if (inside && edgeDistance >= accuracy) return Object.freeze({ state: 'inside', distanceMeters: edgeDistance });
    if (!inside && edgeDistance >= tolerance + accuracy) return Object.freeze({ state: 'outside', distanceMeters: edgeDistance });
    return Object.freeze({ state: 'uncertain', reason: 'BOUNDARY_UNCERTAIN', distanceMeters: edgeDistance });
  }

  function maskedDiagnostic(reason, snapshot = null, classification = null) {
    latestDiagnostic = Object.freeze({
      reason,
      jobId: activeContext ? activeContext.jobId : '',
      placeId: activeContext ? activeContext.placeId : '',
      placeRole: activeContext ? ROLE_LABELS[activeContext.placeRole] : '',
      geometryType: activeContext ? (activeContext.geofence.type === TYPES.CIRCLE ? 'Cirkel' : 'Polygon') : '',
      internalState: confirmedState,
      gpsAccuracyMeters: Number.isFinite(snapshot && snapshot.accuracy) ? Number(snapshot.accuracy) : null,
      positionAgeMs: Number.isFinite(snapshot && snapshot.age) ? Number(snapshot.age) : null,
      boundaryDistanceMeters: Number.isFinite(classification && classification.distanceMeters) ? Math.round(classification.distanceMeters) : null,
      at: new Date().toISOString()
    });
  }

  function emit(direction, snapshot) {
    const event = Object.freeze({
      jobId: activeContext.jobId,
      placeId: activeContext.placeId,
      placeRole: ROLE_LABELS[activeContext.placeRole],
      geometryType: activeContext.geofence.type === TYPES.CIRCLE ? 'Cirkel' : 'Polygon',
      direction,
      timestamp: new Date(Number(snapshot.timestamp) || Date.now()).toISOString(),
      gpsAccuracyMeters: Number(snapshot.accuracy),
      positionAgeMs: Number(snapshot.age)
    });
    eventListeners.forEach((listener) => { try { listener(event); } catch (_) {} });
    return event;
  }

  function handleGpsSnapshot(snapshot) {
    if (!activeContext) return;
    if (!snapshot || snapshot.isUsable !== true || !Number.isFinite(snapshot.age)) {
      maskedDiagnostic('POSITION_UNUSABLE', snapshot);
      return;
    }
    let classification;
    try { classification = classifyPosition(activeContext.geofence, snapshot); }
    catch (_) { maskedDiagnostic('GEOFENCE_INVALID', snapshot); return; }
    if (classification.state === 'uncertain') { maskedDiagnostic(classification.reason || 'BOUNDARY_UNCERTAIN', snapshot, classification); return; }
    if (confirmedState === 'unknown') {
      confirmedState = classification.state;
      maskedDiagnostic('BASELINE_SET', snapshot, classification);
      return;
    }
    if (classification.state === confirmedState) { maskedDiagnostic('STATE_STABLE', snapshot, classification); return; }
    confirmedState = classification.state;
    emit(classification.state === 'inside' ? 'ENTER' : 'EXIT', snapshot);
    maskedDiagnostic('EVENT_EMITTED', snapshot, classification);
  }

  function ensureGpsSubscription() {
    if (unsubscribeGps || !gps || typeof gps.subscribe !== 'function') return;
    unsubscribeGps = gps.subscribe(handleGpsSnapshot);
  }

  function clearContext() {
    activeContext = null;
    confirmedState = 'unknown';
    if (gps && typeof gps.setConsumer === 'function') gps.setConsumer('geofence', false, 'Geofence');
    maskedDiagnostic('NO_CONTEXT');
  }

  function setActiveContext(value) {
    if (!isPlainObject(value) || value.active !== true) { clearContext(); return null; }
    const jobId = text(value.jobId); const placeId = text(value.placeId); const placeRole = text(value.placeRole);
    if (!jobId || !placeId || !ROLE_LABELS[placeRole] || value.dynamicCurrentLocation === true || /current[-_ ]?location|nuvarande/i.test(placeId)) { clearContext(); return null; }
    const geofence = validateDefinition(value.geofence);
    if (!geofence.enabled) { clearContext(); return null; }
    const next = Object.freeze({ jobId, placeId, placeRole, geofence });
    const key = `${jobId}|${placeId}|${placeRole}|${JSON.stringify(geofence)}`;
    const currentKey = activeContext ? `${activeContext.jobId}|${activeContext.placeId}|${activeContext.placeRole}|${JSON.stringify(activeContext.geofence)}` : '';
    if (key !== currentKey) confirmedState = 'unknown';
    activeContext = next;
    ensureGpsSubscription();
    gps.setConsumer('geofence', true, 'Geofence');
    maskedDiagnostic(key === currentKey ? 'CONTEXT_STABLE' : 'CONTEXT_CHANGED');
    if (typeof gps.getSnapshot === 'function') handleGpsSnapshot(gps.getSnapshot());
    return next;
  }

  function subscribeEvents(listener) {
    if (typeof listener !== 'function') throw new Error('Geofence-lyssnaren måste vara en funktion.');
    eventListeners.add(listener);
    return () => eventListeners.delete(listener);
  }

  function getSnapshot() {
    return Object.freeze({ active: Boolean(activeContext), context: activeContext, confirmedState, diagnostic: latestDiagnostic });
  }

  function destroy() {
    clearContext();
    if (unsubscribeGps) { unsubscribeGps(); unsubscribeGps = null; }
    eventListeners.clear();
  }

  window.StadslassGeofenceService = Object.freeze({
    TYPES,
    normalizeDefinition,
    validateDefinition,
    parsePolygonPoints,
    formatPolygonPoints,
    distanceMeters,
    pointInPolygon,
    distanceToPolygonBoundaryMeters,
    classifyPosition,
    setActiveContext,
    subscribeEvents,
    getSnapshot,
    destroy
  });
})();
