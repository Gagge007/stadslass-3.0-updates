(() => {
  'use strict';

  const ACTIONS = Object.freeze({
    SHOW_START_ROUTE: 'show-start-route',
    COMPLETE_LOADING: 'complete-loading',
    ARRIVE_DESTINATION: 'arrive-destination',
    REGISTER_WEIGHT: 'register-weight',
    SHOW_LOAD_REGISTERED: 'show-load-registered',
    ARRIVE_RETURN: 'arrive-return',
    COMPLETE_RETURN_UNLOADING: 'complete-return-unloading',
    REQUEST_COMPLETE: 'request-complete'
  });

  const DEFINITIONS = Object.freeze({
    start_route: Object.freeze({ label: 'Startsträcka', action: ACTIONS.SHOW_START_ROUTE }),
    loading: Object.freeze({ label: 'Lastning', action: ACTIONS.COMPLETE_LOADING }),
    transport: Object.freeze({ label: 'Transport', action: ACTIONS.ARRIVE_DESTINATION }),
    unloading: Object.freeze({ label: 'Ange vikt efter lossning', action: ACTIONS.REGISTER_WEIGHT }),
    load_registered: Object.freeze({ label: 'Lass registrerat', action: ACTIONS.SHOW_LOAD_REGISTERED }),
    return_transport: Object.freeze({ label: 'Returtransport', action: ACTIONS.ARRIVE_RETURN }),
    return_unloading: Object.freeze({ label: 'Returlossning genomförd', action: ACTIONS.COMPLETE_RETURN_UNLOADING }),
    ready_to_complete: Object.freeze({ label: 'Redo att avslutas', action: ACTIONS.REQUEST_COMPLETE })
  });

  function resolve(phaseValue, phaseService) {
    if (!phaseService || typeof phaseService.normalizePhase !== 'function') {
      throw new Error('Fasmotorn saknas för fasknappen.');
    }
    const phase = phaseService.normalizePhase(phaseValue);
    const definition = DEFINITIONS[phase];
    if (!definition) {
      throw new Error('Aktuell fas saknar en giltig fasknappsdefinition.');
    }
    return Object.freeze({ phase, label: definition.label, action: definition.action });
  }

  function markReturnUnloadingCompleted(documentValue, at, packageVersion) {
    const source = documentValue && typeof documentValue === 'object' && !Array.isArray(documentValue) ? documentValue : {};
    const timestamp = typeof at === 'string' ? at.trim() : '';
    if (!timestamp) throw new Error('Genomförd returlossning saknar tidpunkt.');
    const events = Array.isArray(source.events) ? source.events.slice() : [];
    return {
      ...source,
      returnUnloadingCompletedAt: timestamp,
      returnLeg: {
        ...(source.returnLeg && typeof source.returnLeg === 'object' && !Array.isArray(source.returnLeg) ? source.returnLeg : {}),
        unloadedAt: timestamp,
        status: 'unloaded'
      },
      updatedAt: timestamp,
      updatedByPackageVersion: Number(packageVersion) || 0,
      events: [...events, {
        type: 'return_unloading_completed',
        at: timestamp,
        source: 'manual',
        packageVersion: Number(packageVersion) || 0,
        fromPhase: 'return_unloading',
        toPhase: 'ready_to_complete'
      }]
    };
  }

  window.StadslassPhaseActionService = Object.freeze({
    ACTIONS,
    DEFINITIONS,
    resolve,
    markReturnUnloadingCompleted
  });
})();
