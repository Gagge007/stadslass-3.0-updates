(() => {
  'use strict';

  const SETTINGS_KEY = 'editableJobTypeRegistryV1';
  const SCHEMA_VERSION = 4;
  const LEGACY_SCHEMA_VERSIONS = Object.freeze([1, 2, 3]);
  const SPECIAL_ROLES = Object.freeze(['none', 'havstang', 'machine-transport']);
  const MANUAL_ID_PATTERN = /^JT3-[0-9a-f]{32}$/;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedName(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function emptyRegistry() {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      items: []
    };
  }

  function randomBytes() {
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(bytes);
      return bytes;
    }
    const seed = `${Date.now()}-${Math.random()}-${Math.random()}`;
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = seed.charCodeAt(index % seed.length) ^ Math.floor(Math.random() * 256);
    }
    return bytes;
  }

  function generateStableId(items = []) {
    const existing = new Set(items.map((item) => text(item && item.id)));
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const hex = Array.from(randomBytes(), (value) => value.toString(16).padStart(2, '0')).join('');
      const id = `JT3-${hex}`;
      if (!existing.has(id)) return id;
    }
    throw new Error('Ett unikt jobbtyps-ID kunde inte skapas.');
  }

  function validateItem(item, { schemaVersion = SCHEMA_VERSION } = {}) {
    if (!isPlainObject(item)) throw new Error('En jobbtyp har fel format.');
    if (!MANUAL_ID_PATTERN.test(text(item.id))) throw new Error('En jobbtyp saknar ett giltigt stabilt ID.');
    if (!normalizedName(item.name)) throw new Error('Jobbtypens namn saknas.');
    if (normalizedName(item.name).length > 100) throw new Error('Jobbtypens namn får vara högst 100 tecken.');
    if (schemaVersion === 1 && typeof item.active !== 'boolean') throw new Error('Jobbtypens äldre aktiv-status är ogiltig.');
    if (schemaVersion !== 1 && Object.prototype.hasOwnProperty.call(item, 'active')) throw new Error('Jobbtypen innehåller en inaktuell aktiv-status.');
    if (schemaVersion <= 3) {
      if (!['required', 'optional', 'not-used'].includes(text(item.weightMode))) throw new Error('Jobbtypens äldre viktinställning är ogiltig.');
    } else if (Object.prototype.hasOwnProperty.call(item, 'weightMode')) {
      throw new Error('Jobbtypen innehåller ett inaktuellt viktfält.');
    }
    if (schemaVersion < 3) {
      if (typeof item.supportsReturn !== 'boolean') throw new Error('Jobbtypens äldre returinställning är ogiltig.');
      if (typeof item.supportsMultiLoad !== 'boolean') throw new Error('Jobbtypens äldre flerlassinställning är ogiltig.');
    } else if (Object.prototype.hasOwnProperty.call(item, 'supportsReturn')
      || Object.prototype.hasOwnProperty.call(item, 'supportsMultiLoad')) {
      throw new Error('Jobbtypen innehåller inaktuella Retur- eller Flerlassfält.');
    }
    if (!SPECIAL_ROLES.includes(text(item.specialRole))) throw new Error('Jobbtypens specialtyp är ogiltig.');
    if (!text(item.createdAt) || !text(item.updatedAt)) throw new Error('Jobbtypens tidsstämplar saknas.');
    return true;
  }

  function validateItems(items, { schemaVersion = SCHEMA_VERSION } = {}) {
    if (!Array.isArray(items)) throw new Error('Jobbtypsregistret saknar en giltig lista.');
    const ids = new Set();
    const names = new Set();
    const specialRoles = new Set();
    items.forEach((item) => {
      validateItem(item, { schemaVersion });
      const id = text(item.id);
      const nameKey = normalizedName(item.name).toLocaleLowerCase('sv-SE');
      if (ids.has(id)) throw new Error('Jobbtypsregistret innehåller dubbla ID:n.');
      if (names.has(nameKey)) throw new Error('Det finns redan en jobbtyp med samma namn.');
      ids.add(id);
      names.add(nameKey);
      if ((schemaVersion !== 1 || item.active) && item.specialRole !== 'none') {
        if (specialRoles.has(item.specialRole)) {
          throw new Error(`Det kan bara finnas en jobbtyp med specialtypen ${item.specialRole === 'havstang' ? 'Havstång' : 'Maskintransport'}.`);
        }
        specialRoles.add(item.specialRole);
      }
    });
    return true;
  }

  function validateRegistry(registry) {
    if (!isPlainObject(registry)) throw new Error('Jobbtypsregistret har fel format.');
    if (registry.schemaVersion !== SCHEMA_VERSION) throw new Error('Jobbtypsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Jobbtypsregistret har en ogiltig revision.');
    validateItems(registry.items);
    return true;
  }

  function normalizedInput(input) {
    const value = isPlainObject(input) ? input : {};
    return {
      name: normalizedName(value.name),
      specialRole: text(value.specialRole)
    };
  }

  function createItem(input, existingItems = [], timestamp = new Date().toISOString()) {
    const normalized = normalizedInput(input);
    const item = {
      id: generateStableId(existingItems),
      name: normalized.name,
      specialRole: normalized.specialRole,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    validateItems(existingItems.concat(item));
    return item;
  }

  function updateItem(current, input, existingItems = [], timestamp = new Date().toISOString()) {
    validateItem(current);
    const normalized = normalizedInput(input);
    const updated = {
      ...current,
      name: normalized.name,
      specialRole: normalized.specialRole,
      updatedAt: timestamp
    };
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Jobbtypen som skulle redigeras saknas.');
    validateItems(nextItems);
    return updated;
  }

  function removeItem(current, existingItems = []) {
    validateItem(current);
    if (!existingItems.some((item) => item.id === current.id)) throw new Error('Jobbtypen som skulle tas bort saknas.');
    const nextItems = existingItems.filter((item) => item.id !== current.id);
    validateItems(nextItems);
    return nextItems;
  }

  function migrateRegistry(registry, timestamp = new Date().toISOString()) {
    if (!isPlainObject(registry)) throw new Error('Jobbtypsregistret har fel format.');
    if (registry.schemaVersion === SCHEMA_VERSION) {
      validateRegistry(registry);
      return { registry, migrated: false };
    }
    if (!LEGACY_SCHEMA_VERSIONS.includes(registry.schemaVersion)) {
      throw new Error('Jobbtypsregistret har en okänd schemaversion.');
    }
    if (!Number.isInteger(registry.revision) || registry.revision < 0) {
      throw new Error('Jobbtypsregistret har en ogiltig revision.');
    }
    validateItems(registry.items, { schemaVersion: registry.schemaVersion });
    const migratedItems = registry.items.map((item) => {
      const {
        active: _discardedActiveStatus,
        weightMode: _discardedWeightMode,
        supportsReturn: _discardedReturnSetting,
        supportsMultiLoad: _discardedMultiLoadSetting,
        ...preserved
      } = item;
      return preserved;
    });
    validateItems(migratedItems);
    const migrated = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      items: migratedItems
    };
    validateRegistry(migrated);
    return { registry: migrated, migrated: true };
  }

  function withItems(registry, items, timestamp = new Date().toISOString()) {
    validateRegistry(registry);
    validateItems(items);
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      items: items.map((item) => ({ ...item }))
    };
    validateRegistry(next);
    return next;
  }

  window.StadslassJobTypeRegistry = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    SPECIAL_ROLES,
    emptyRegistry,
    validateItem,
    validateRegistry,
    createItem,
    updateItem,
    removeItem,
    migrateRegistry,
    withItems
  });
})();
