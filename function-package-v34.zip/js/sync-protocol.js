(() => {
  'use strict';

  const SCHEMA_VERSION = 1;
  const TRANSFER_PROTOCOL = 'stadslass.queue-transfer.v1';
  const RECEIPT_PROTOCOL = 'stadslass.queue-receipt.v1';
  const TRANSFER_PREFIX = 'STADSLASS3-QTX1.';
  const RECEIPT_PREFIX = 'STADSLASS3-QRC1.';
  const MAX_JOBS = 20;
  const MAX_TEXT_LENGTH = 220000;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function canonicalValue(value) {
    if (Array.isArray(value)) return value.map(canonicalValue);
    if (isPlainObject(value)) {
      const result = {};
      Object.keys(value).sort().forEach((key) => {
        if (value[key] !== undefined) result[key] = canonicalValue(value[key]);
      });
      return result;
    }
    return value;
  }

  function canonicalJson(value) {
    return JSON.stringify(canonicalValue(value));
  }

  function utf8Bytes(value) {
    const input = String(value);
    if (typeof TextEncoder === 'function') return Array.from(new TextEncoder().encode(input));
    const escaped = unescape(encodeURIComponent(input));
    return Array.from(escaped, (character) => character.charCodeAt(0));
  }

  function utf8String(bytes) {
    if (typeof TextDecoder === 'function') return new TextDecoder('utf-8', { fatal: true }).decode(new Uint8Array(bytes));
    let binary = '';
    bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
    return decodeURIComponent(escape(binary));
  }

  function rightRotate(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
  }

  function sha256Hex(value) {
    const bytes = utf8Bytes(value);
    const bitLength = bytes.length * 8;
    bytes.push(0x80);
    while ((bytes.length % 64) !== 56) bytes.push(0);
    const high = Math.floor(bitLength / 0x100000000);
    const low = bitLength >>> 0;
    for (let shift = 24; shift >= 0; shift -= 8) bytes.push((high >>> shift) & 0xff);
    for (let shift = 24; shift >= 0; shift -= 8) bytes.push((low >>> shift) & 0xff);

    const h = [
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ];
    const k = [
      0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
      0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
      0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
      0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
      0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
      0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
      0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
      0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    ];
    const words = new Array(64);
    for (let offset = 0; offset < bytes.length; offset += 64) {
      for (let index = 0; index < 16; index += 1) {
        const position = offset + index * 4;
        words[index] = ((bytes[position] << 24) | (bytes[position + 1] << 16) | (bytes[position + 2] << 8) | bytes[position + 3]) >>> 0;
      }
      for (let index = 16; index < 64; index += 1) {
        const x = words[index - 15];
        const y = words[index - 2];
        const s0 = rightRotate(x, 7) ^ rightRotate(x, 18) ^ (x >>> 3);
        const s1 = rightRotate(y, 17) ^ rightRotate(y, 19) ^ (y >>> 10);
        words[index] = (words[index - 16] + s0 + words[index - 7] + s1) >>> 0;
      }
      let [a,b,c,d,e,f,g,hh] = h;
      for (let index = 0; index < 64; index += 1) {
        const s1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
        const choice = (e & f) ^ ((~e) & g);
        const temp1 = (hh + s1 + choice + k[index] + words[index]) >>> 0;
        const s0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
        const majority = (a & b) ^ (a & c) ^ (b & c);
        const temp2 = (s0 + majority) >>> 0;
        hh = g; g = f; f = e; e = (d + temp1) >>> 0; d = c; c = b; b = a; a = (temp1 + temp2) >>> 0;
      }
      h[0] = (h[0] + a) >>> 0; h[1] = (h[1] + b) >>> 0; h[2] = (h[2] + c) >>> 0; h[3] = (h[3] + d) >>> 0;
      h[4] = (h[4] + e) >>> 0; h[5] = (h[5] + f) >>> 0; h[6] = (h[6] + g) >>> 0; h[7] = (h[7] + hh) >>> 0;
    }
    return h.map((part) => part.toString(16).padStart(8, '0')).join('');
  }

  function bytesToBase64Url(bytes) {
    let binary = '';
    bytes.forEach((byte) => { binary += String.fromCharCode(byte); });
    const encoded = typeof btoa === 'function' ? btoa(binary) : Buffer.from(binary, 'binary').toString('base64');
    return encoded.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
  }

  function base64UrlToBytes(value) {
    const normalized = value.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
    const binary = typeof atob === 'function' ? atob(padded) : Buffer.from(padded, 'base64').toString('binary');
    return Array.from(binary, (character) => character.charCodeAt(0));
  }

  function encodeDocument(prefix, documentValue) {
    return `${prefix}${bytesToBase64Url(utf8Bytes(JSON.stringify(documentValue)))}`;
  }

  function decodeDocument(prefix, transferText) {
    const value = text(transferText);
    if (!value.startsWith(prefix)) throw new Error('Överföringstexten har fel format eller version.');
    if (value.length > MAX_TEXT_LENGTH) throw new Error('Överföringstexten är för stor.');
    try {
      const decoded = utf8String(base64UrlToBytes(value.slice(prefix.length)));
      const documentValue = JSON.parse(decoded);
      if (!isPlainObject(documentValue)) throw new Error('Dokumentet är inte ett objekt.');
      return documentValue;
    } catch (error) {
      throw new Error(`Överföringstexten kunde inte avkodas: ${error.message || 'okänt fel'}`);
    }
  }

  function withChecksum(base) {
    return { ...base, checksumAlgorithm: 'sha256', checksum: sha256Hex(canonicalJson(base)) };
  }

  function verifyChecksum(documentValue) {
    const checksum = text(documentValue.checksum);
    if (documentValue.checksumAlgorithm !== 'sha256' || !/^[a-f0-9]{64}$/.test(checksum)) throw new Error('Kontrollsumman saknas eller har fel format.');
    const base = { ...documentValue };
    delete base.checksum;
    delete base.checksumAlgorithm;
    const expected = sha256Hex(canonicalJson(base));
    if (expected !== checksum) throw new Error('Kontrollsumman stämmer inte. Texten kan vara skadad eller ändrad.');
  }

  function assertSource(source, expectedRole) {
    if (!isPlainObject(source) || text(source.role) !== expectedRole || !text(source.deviceId)) throw new Error('Källenheten eller källrollen är ogiltig.');
  }

  function assertTarget(target, expectedRole) {
    if (!isPlainObject(target) || text(target.role) !== expectedRole) throw new Error('Målrollen är ogiltig.');
  }

  function createTransfer(options) {
    const jobs = Array.isArray(options.jobs) ? options.jobs : [];
    if (jobs.length < 1 || jobs.length > MAX_JOBS || jobs.some((job) => !isPlainObject(job) || !text(job.jobId))) throw new Error('Överföringen måste innehålla 1–20 giltiga uppdrag.');
    const base = {
      schemaVersion: SCHEMA_VERSION,
      protocol: TRANSFER_PROTOCOL,
      transferId: text(options.transferId),
      createdAt: text(options.createdAt),
      packageVersion: Number(options.packageVersion) || 0,
      source: { role: 'mobile', roleLabel: text(options.sourceRoleLabel, 'Mobil'), deviceId: text(options.sourceDeviceId) },
      target: { role: 'vehicle_189', roleLabel: '189 / Surfplatta' },
      jobs: JSON.parse(JSON.stringify(jobs))
    };
    if (!base.transferId || !base.createdAt || !base.source.deviceId) throw new Error('Överföringens identitet eller källuppgifter saknas.');
    const envelope = withChecksum(base);
    return { envelope, text: encodeDocument(TRANSFER_PREFIX, envelope) };
  }

  function parseTransfer(transferText) {
    const envelope = decodeDocument(TRANSFER_PREFIX, transferText);
    if (envelope.schemaVersion !== SCHEMA_VERSION || envelope.protocol !== TRANSFER_PROTOCOL || !text(envelope.transferId) || !text(envelope.createdAt)) throw new Error('Överföringens protokoll eller identitet är ogiltig.');
    assertSource(envelope.source, 'mobile');
    assertTarget(envelope.target, 'vehicle_189');
    if (!Array.isArray(envelope.jobs) || envelope.jobs.length < 1 || envelope.jobs.length > MAX_JOBS || envelope.jobs.some((job) => !isPlainObject(job) || !text(job.jobId))) throw new Error('Överföringens uppdragslista är ogiltig.');
    verifyChecksum(envelope);
    return envelope;
  }

  function createReceipt(options) {
    const jobIds = Array.isArray(options.jobIds) ? options.jobIds.map((value) => text(value)).filter(Boolean) : [];
    if (!text(options.transferId) || jobIds.length < 1 || !text(options.receivedByDeviceId)) throw new Error('Kvittots överförings-ID, jobb-ID eller mottagarenhet saknas.');
    const base = {
      schemaVersion: SCHEMA_VERSION,
      protocol: RECEIPT_PROTOCOL,
      receiptId: text(options.receiptId),
      transferId: text(options.transferId),
      receivedAt: text(options.receivedAt),
      packageVersion: Number(options.packageVersion) || 0,
      status: text(options.status, 'accepted'),
      source: { role: 'vehicle_189', roleLabel: '189 / Surfplatta', deviceId: text(options.receivedByDeviceId) },
      target: { role: 'mobile', roleLabel: 'Mobil', deviceId: text(options.targetDeviceId) },
      jobIds
    };
    if (!base.receiptId || !base.receivedAt || !['accepted','already-present'].includes(base.status)) throw new Error('Kvittots identitet, tid eller status är ogiltig.');
    const envelope = withChecksum(base);
    return { envelope, text: encodeDocument(RECEIPT_PREFIX, envelope) };
  }

  function parseReceipt(receiptText) {
    const envelope = decodeDocument(RECEIPT_PREFIX, receiptText);
    if (envelope.schemaVersion !== SCHEMA_VERSION || envelope.protocol !== RECEIPT_PROTOCOL || !text(envelope.receiptId) || !text(envelope.transferId) || !text(envelope.receivedAt)) throw new Error('Kvittots protokoll eller identitet är ogiltig.');
    assertSource(envelope.source, 'vehicle_189');
    assertTarget(envelope.target, 'mobile');
    if (!['accepted','already-present'].includes(envelope.status) || !Array.isArray(envelope.jobIds) || envelope.jobIds.length < 1 || envelope.jobIds.some((value) => !text(value))) throw new Error('Kvittots status eller jobb-ID är ogiltiga.');
    verifyChecksum(envelope);
    return envelope;
  }

  window.StadslassSyncProtocol = Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    transferProtocol: TRANSFER_PROTOCOL,
    receiptProtocol: RECEIPT_PROTOCOL,
    canonicalJson,
    sha256Hex,
    createTransfer,
    parseTransfer,
    createReceipt,
    parseReceipt
  });
})();
