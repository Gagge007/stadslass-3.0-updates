(() => {
  'use strict';

  const SETTINGS_KEY = 'editablePlaceRegistryV1';
  const SCHEMA_VERSION = 1;
  const MANUAL_ID_PATTERN = /^PL3-[0-9a-f]{32}$/;
  const JOB_TYPE_ID_PATTERN = /^JT3-[0-9a-f]{32}$/;
  const GEOFENCE_TYPE = 'circle';

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedText(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    if (typeof value === 'string' && !value.trim()) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : Number.NaN;
  }

  function uniqueIds(value) {
    if (!Array.isArray(value)) return [];
    return Array.from(new Set(value.map(text).filter(Boolean))).sort();
  }

  function emptyRegistry() {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      items: []
    };
  }

  function randomBytes() {
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(bytes);
      return bytes;
    }
    const seed = `${Date.now()}-${Math.random()}-${Math.random()}`;
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = seed.charCodeAt(index % seed.length) ^ Math.floor(Math.random() * 256);
    }
    return bytes;
  }

  function generateStableId(items = []) {
    const existing = new Set(items.map((item) => text(item && item.id)));
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const hex = Array.from(randomBytes(), (value) => value.toString(16).padStart(2, '0')).join('');
      const id = `PL3-${hex}`;
      if (!existing.has(id)) return id;
    }
    throw new Error('Ett unikt plats-ID kunde inte skapas.');
  }

  function validateJobTypeIds(ids, label, validJobTypeIds) {
    if (!Array.isArray(ids)) throw new Error(`${label} saknar en giltig lista.`);
    if (ids.length !== new Set(ids).size) throw new Error(`${label} innehåller dubbla jobbtyper.`);
    ids.forEach((id) => {
      if (!JOB_TYPE_ID_PATTERN.test(text(id))) throw new Error(`${label} innehåller ett ogiltigt jobbtyps-ID.`);
      if (validJobTypeIds && !validJobTypeIds.has(id)) throw new Error(`${label} hänvisar till en jobbtyp som inte finns.`);
    });
  }

  function validateGeofence(geofence) {
    if (!isPlainObject(geofence)) throw new Error('Platsens geofence har fel format.');
    if (typeof geofence.enabled !== 'boolean') throw new Error('Platsens geofence saknar giltig av/på-status.');
    if (text(geofence.type) !== GEOFENCE_TYPE) throw new Error('Platsens geofence måste vara en cirkel.');
    if (typeof geofence.visualLoadingLock !== 'boolean') throw new Error('Platsens visuella lastningslås är ogiltigt.');
    if (typeof geofence.visualUnloadingLock !== 'boolean') throw new Error('Platsens visuella lossningslås är ogiltigt.');

    const latitude = optionalNumber(geofence.latitude);
    const longitude = optionalNumber(geofence.longitude);
    const radiusMeters = optionalNumber(geofence.radiusMeters);
    const toleranceMeters = optionalNumber(geofence.toleranceMeters);

    if (latitude !== null && (!Number.isFinite(latitude) || latitude < -90 || latitude > 90)) {
      throw new Error('Geofencets latitud måste vara mellan -90 och 90.');
    }
    if (longitude !== null && (!Number.isFinite(longitude) || longitude < -180 || longitude > 180)) {
      throw new Error('Geofencets longitud måste vara mellan -180 och 180.');
    }
    if (radiusMeters !== null && (!Number.isFinite(radiusMeters) || radiusMeters <= 0 || radiusMeters > 100000)) {
      throw new Error('Geofencets radie måste vara större än 0 meter.');
    }
    if (toleranceMeters !== null && (!Number.isFinite(toleranceMeters) || toleranceMeters < 0 || toleranceMeters > 100000)) {
      throw new Error('Geofencets tolerans måste vara 0 meter eller större.');
    }
    if (geofence.enabled && [latitude, longitude, radiusMeters, toleranceMeters].some((value) => value === null)) {
      throw new Error('Geofencets latitud, longitud, radie och tolerans måste fyllas i.');
    }
    return true;
  }

  function validateItem(item, validJobTypeIds = null) {
    if (!isPlainObject(item)) throw new Error('En plats har fel format.');
    if (!MANUAL_ID_PATTERN.test(text(item.id))) throw new Error('En plats saknar ett giltigt stabilt ID.');
    if (!normalizedText(item.name)) throw new Error('Platsens namn saknas.');
    if (normalizedText(item.name).length > 100) throw new Error('Platsens namn får vara högst 100 tecken.');
    if (text(item.addressOrPlusCode).length > 300) throw new Error('Adress eller Plus Code får vara högst 300 tecken.');
    if (text(item.placeRequirements).length > 1000) throw new Error('Platskrav får vara högst 1000 tecken.');
    if (text(item.openingHours).length > 300) throw new Error('Öppettider får vara högst 300 tecken.');
    if (typeof item.canBeReturnPlace !== 'boolean') throw new Error('Platsens returplatsval är ogiltigt.');
    validateJobTypeIds(item.jobTypeFromIds, 'Jobbtyper från', validJobTypeIds);
    validateJobTypeIds(item.jobTypeToIds, 'Jobbtyper till', validJobTypeIds);
    validateGeofence(item.geofence);
    if (!text(item.createdAt) || !text(item.updatedAt)) throw new Error('Platsens tidsstämplar saknas.');
    return true;
  }

  function validateItems(items, validJobTypeIds = null) {
    if (!Array.isArray(items)) throw new Error('Platsregistret saknar en giltig lista.');
    const ids = new Set();
    const names = new Set();
    items.forEach((item) => {
      validateItem(item, validJobTypeIds);
      const id = text(item.id);
      const nameKey = normalizedText(item.name).toLocaleLowerCase('sv-SE');
      if (ids.has(id)) throw new Error('Platsregistret innehåller dubbla ID:n.');
      if (names.has(nameKey)) throw new Error('Det finns redan en plats med samma namn.');
      ids.add(id);
      names.add(nameKey);
    });
    return true;
  }

  function validateRegistry(registry, validJobTypeIds = null) {
    if (!isPlainObject(registry)) throw new Error('Platsregistret har fel format.');
    if (registry.schemaVersion !== SCHEMA_VERSION) throw new Error('Platsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Platsregistret har en ogiltig revision.');
    validateItems(registry.items, validJobTypeIds);
    return true;
  }

  function normalizedGeofence(value) {
    const source = isPlainObject(value) ? value : {};
    return {
      enabled: Boolean(source.enabled),
      type: GEOFENCE_TYPE,
      visualLoadingLock: Boolean(source.visualLoadingLock),
      visualUnloadingLock: Boolean(source.visualUnloadingLock),
      latitude: optionalNumber(source.latitude),
      longitude: optionalNumber(source.longitude),
      radiusMeters: optionalNumber(source.radiusMeters),
      toleranceMeters: optionalNumber(source.toleranceMeters)
    };
  }

  function normalizedInput(input) {
    const value = isPlainObject(input) ? input : {};
    return {
      name: normalizedText(value.name),
      addressOrPlusCode: text(value.addressOrPlusCode),
      placeRequirements: text(value.placeRequirements),
      openingHours: text(value.openingHours),
      canBeReturnPlace: Boolean(value.canBeReturnPlace),
      jobTypeFromIds: uniqueIds(value.jobTypeFromIds),
      jobTypeToIds: uniqueIds(value.jobTypeToIds),
      geofence: normalizedGeofence(value.geofence)
    };
  }

  function createItem(input, existingItems = [], validJobTypeIds = null, timestamp = new Date().toISOString()) {
    const normalized = normalizedInput(input);
    const item = {
      id: generateStableId(existingItems),
      ...normalized,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    validateItems(existingItems.concat(item), validJobTypeIds);
    return item;
  }

  function updateItem(current, input, existingItems = [], validJobTypeIds = null, timestamp = new Date().toISOString()) {
    validateItem(current, validJobTypeIds);
    const normalized = normalizedInput(input);
    const updated = {
      ...current,
      ...normalized,
      geofence: {
        ...(isPlainObject(current.geofence) ? current.geofence : {}),
        ...normalized.geofence
      },
      updatedAt: timestamp
    };
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Platsen som skulle redigeras saknas.');
    validateItems(nextItems, validJobTypeIds);
    return updated;
  }

  function removeItem(current, existingItems = [], validJobTypeIds = null) {
    validateItem(current, validJobTypeIds);
    if (!existingItems.some((item) => item.id === current.id)) throw new Error('Platsen som skulle tas bort saknas.');
    const nextItems = existingItems.filter((item) => item.id !== current.id);
    validateItems(nextItems, validJobTypeIds);
    return nextItems;
  }

  function withItems(registry, items, validJobTypeIds = null, timestamp = new Date().toISOString()) {
    validateRegistry(registry, validJobTypeIds);
    validateItems(items, validJobTypeIds);
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      items: items.map((item) => ({
        ...item,
        jobTypeFromIds: item.jobTypeFromIds.slice(),
        jobTypeToIds: item.jobTypeToIds.slice(),
        geofence: { ...item.geofence }
      }))
    };
    validateRegistry(next, validJobTypeIds);
    return next;
  }

  function referencesJobType(registry, jobTypeId) {
    if (!isPlainObject(registry) || !Array.isArray(registry.items)) return false;
    return registry.items.some((item) => (Array.isArray(item.jobTypeFromIds) && item.jobTypeFromIds.includes(jobTypeId))
      || (Array.isArray(item.jobTypeToIds) && item.jobTypeToIds.includes(jobTypeId)));
  }

  window.StadslassPlaceRegistry = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    GEOFENCE_TYPE,
    emptyRegistry,
    validateItem,
    validateRegistry,
    createItem,
    updateItem,
    removeItem,
    withItems,
    referencesJobType
  });
})();
