(() => {
  'use strict';

  const FRESH_POSITION_MS = 60 * 1000;
  const LOW_ACCURACY_METERS = 100;
  const FIRST_FIX_WAIT_MS = 20 * 1000;
  const consumers = new Map();
  const listeners = new Set();

  let watchId = null;
  let watchGeneration = 0;
  let firstFixTimer = null;
  let ageTimer = null;
  let permissionStatus = null;
  let permissionBlocked = false;
  let permissionDeniedCount = 0;
  let everGranted = false;
  let foreground = document.visibilityState !== 'hidden';

  let state = {
    latitude: null,
    longitude: null,
    accuracy: null,
    timestamp: null,
    status: 'GPS inte startad',
    errorCode: null,
    latestError: '',
    isUsable: false,
    isWatching: false
  };

  const consumerLabels = Object.freeze({
    activeJob: 'Aktivt jobb',
    gpsDiagnostics: 'GPS-status'
  });

  function activeConsumerNames() {
    return Array.from(consumers.entries())
      .filter(([, value]) => value.active)
      .map(([name]) => name);
  }

  function consumerReasons() {
    return Array.from(consumers.entries())
      .filter(([, value]) => value.active)
      .map(([name, value]) => value.reason || consumerLabels[name] || name);
  }

  function positionAge(now = Date.now()) {
    if (!Number.isFinite(state.timestamp)) return null;
    return Math.max(0, now - state.timestamp);
  }

  function derivePositionState(now = Date.now()) {
    const age = positionAge(now);
    const hasPosition = Number.isFinite(state.latitude)
      && Number.isFinite(state.longitude)
      && Number.isFinite(state.accuracy)
      && Number.isFinite(state.timestamp);
    const isFresh = hasPosition && age <= FRESH_POSITION_MS;
    const hasLowAccuracy = hasPosition && state.accuracy > LOW_ACCURACY_METERS;
    const isUsable = hasPosition && isFresh && !hasLowAccuracy;
    return { age, hasPosition, isFresh, hasLowAccuracy, isUsable };
  }

  function snapshot() {
    const derived = derivePositionState();
    let status = state.status;
    if (state.isWatching && derived.hasPosition) {
      if (!derived.isFresh) status = 'Positionen är gammal';
      else if (derived.hasLowAccuracy) status = 'Låg noggrannhet';
      else status = 'Position tillgänglig';
    }
    return Object.freeze({
      latitude: state.latitude,
      longitude: state.longitude,
      accuracy: state.accuracy,
      timestamp: state.timestamp,
      age: derived.age,
      status,
      errorCode: state.errorCode,
      latestError: state.latestError,
      isUsable: derived.isUsable,
      isWatching: state.isWatching,
      isFresh: derived.isFresh,
      hasLowAccuracy: derived.hasLowAccuracy,
      activeConsumers: Object.freeze(activeConsumerNames()),
      activeReasons: Object.freeze(consumerReasons()),
      appState: foreground ? 'förgrund' : 'bakgrund'
    });
  }

  function notify() {
    const value = snapshot();
    listeners.forEach((listener) => {
      try {
        listener(value);
      } catch (_) {
        // En diagnostiklyssnare får aldrig stoppa positionstjänsten.
      }
    });
  }

  function setState(patch) {
    state = { ...state, ...patch };
    notify();
  }

  function clearFirstFixTimer() {
    if (firstFixTimer !== null) {
      window.clearTimeout(firstFixTimer);
      firstFixTimer = null;
    }
  }

  function clearAgeTimer() {
    if (ageTimer !== null) {
      window.clearInterval(ageTimer);
      ageTimer = null;
    }
  }

  function ensureAgeTimer() {
    if (ageTimer !== null) return;
    ageTimer = window.setInterval(() => {
      if (!state.isWatching || !Number.isFinite(state.timestamp)) return;
      notify();
    }, 1000);
  }

  function clearNativeWatch() {
    clearFirstFixTimer();
    clearAgeTimer();
    watchGeneration += 1;
    if (watchId !== null && navigator.geolocation) {
      try {
        navigator.geolocation.clearWatch(watchId);
      } catch (_) {
        // Bevakningen betraktas ändå som avslutad lokalt.
      }
    }
    watchId = null;
    state = { ...state, isWatching: false };
  }

  function stop(status = 'GPS inte startad', errorCode = null, latestError = '') {
    clearNativeWatch();
    setState({ status, errorCode, latestError, isWatching: false, isUsable: false });
  }

  function permissionErrorStatus(error) {
    const message = String(error && error.message ? error.message : '');
    if (/permanent|inställning|settings/i.test(message) || permissionDeniedCount > 1) {
      return 'Behörighet permanent nekad';
    }
    return 'Behörighet nekad';
  }

  function handlePosition(position, generation) {
    if (generation !== watchGeneration || watchId === null) return;
    clearFirstFixTimer();
    permissionBlocked = false;
    permissionDeniedCount = 0;
    everGranted = true;
    setState({
      latitude: Number(position.coords.latitude),
      longitude: Number(position.coords.longitude),
      accuracy: Number(position.coords.accuracy),
      timestamp: Number(position.timestamp) || Date.now(),
      status: 'Position tillgänglig',
      errorCode: null,
      latestError: '',
      isWatching: true
    });
    ensureAgeTimer();
  }

  function handlePositionError(error, generation) {
    if (generation !== watchGeneration || watchId === null) return;
    const code = Number(error && error.code) || 0;
    const message = String(error && error.message ? error.message : 'Okänt positionsfel.');
    if (code === 1) {
      permissionDeniedCount += 1;
      permissionBlocked = true;
      const revoked = everGranted;
      stop(
        revoked ? 'Behörighet återkallad' : permissionErrorStatus(error),
        code,
        revoked
          ? 'Tidigare tillåten platsbehörighet har återkallats.'
          : message
      );
      return;
    }
    if (code === 2) {
      setState({
        status: 'Positionstjänst avstängd eller otillgänglig',
        errorCode: code,
        latestError: message,
        isWatching: true
      });
      return;
    }
    if (code === 3) {
      setState({
        status: 'Position kunde inte hämtas',
        errorCode: code,
        latestError: message,
        isWatching: true
      });
      return;
    }
    setState({
      status: 'GPS-fel',
      errorCode: code || 'UNKNOWN',
      latestError: message,
      isWatching: true
    });
  }

  function permissionState() {
    return permissionStatus && typeof permissionStatus.state === 'string'
      ? permissionStatus.state
      : 'unknown';
  }

  function startWatch() {
    if (watchId !== null || !foreground || activeConsumerNames().length === 0 || permissionBlocked) return;
    if (!navigator.geolocation || typeof navigator.geolocation.watchPosition !== 'function') {
      stop('Positionstjänst avstängd eller otillgänglig', 'UNAVAILABLE', 'Webbläsarens geolocationstöd saknas.');
      return;
    }

    const currentPermission = permissionState();
    setState({
      status: currentPermission === 'prompt' ? 'Begär behörighet' : 'Söker position',
      errorCode: null,
      latestError: '',
      isWatching: false
    });

    const generation = watchGeneration + 1;
    watchGeneration = generation;
    try {
      watchId = navigator.geolocation.watchPosition(
        (position) => handlePosition(position, generation),
        (error) => handlePositionError(error, generation),
        {
          enableHighAccuracy: true,
          maximumAge: 15000,
          timeout: FIRST_FIX_WAIT_MS
        }
      );
      state = { ...state, isWatching: true };
      notify();
      firstFixTimer = window.setTimeout(() => {
        if (generation !== watchGeneration || watchId === null || Number.isFinite(state.timestamp)) return;
        setState({
          status: 'Position kunde inte hämtas',
          errorCode: 'FIRST_FIX_TIMEOUT',
          latestError: 'Ingen position har kommit inom den första väntetiden.',
          isWatching: true
        });
      }, FIRST_FIX_WAIT_MS);
    } catch (error) {
      stop('GPS-fel', 'START_FAILED', String(error && error.message ? error.message : error));
    }
  }

  function reconcile() {
    const needed = activeConsumerNames().length > 0;
    if (!needed) {
      stop();
      return;
    }
    if (!foreground) {
      stop('GPS inte startad', null, 'Appen är i bakgrunden. GPS återupptas vid återgång till förgrunden.');
      return;
    }
    if (permissionBlocked) {
      notify();
      return;
    }
    startWatch();
  }

  function setConsumer(name, active, reason = '') {
    const safeName = String(name || '').trim();
    if (!safeName) throw new Error('GPS-behovskällan måste ha ett namn.');
    consumers.set(safeName, { active: active === true, reason: String(reason || '').trim() });
    reconcile();
    notify();
  }

  function retry() {
    permissionBlocked = false;
    clearNativeWatch();
    setState({
      status: permissionState() === 'prompt' ? 'Begär behörighet' : 'Söker position',
      errorCode: null,
      latestError: '',
      isWatching: false
    });
    reconcile();
  }

  function setForeground(value) {
    foreground = value === true;
    if (!foreground) {
      clearNativeWatch();
      setState({
        status: 'GPS inte startad',
        errorCode: null,
        latestError: activeConsumerNames().length > 0
          ? 'Appen är i bakgrunden. GPS återupptas vid återgång till förgrunden.'
          : '',
        isWatching: false
      });
      return;
    }
    reconcile();
  }

  function subscribe(listener) {
    if (typeof listener !== 'function') throw new Error('GPS-lyssnaren måste vara en funktion.');
    listeners.add(listener);
    listener(snapshot());
    return () => listeners.delete(listener);
  }

  async function installPermissionObserver() {
    if (!navigator.permissions || typeof navigator.permissions.query !== 'function') return;
    try {
      permissionStatus = await navigator.permissions.query({ name: 'geolocation' });
      if (permissionStatus.state === 'granted') everGranted = true;
      permissionStatus.addEventListener('change', () => {
        if (permissionStatus.state === 'granted') {
          everGranted = true;
          permissionBlocked = false;
          reconcile();
        } else if (permissionStatus.state === 'denied') {
          const revoked = everGranted;
          permissionBlocked = true;
          stop(
            revoked ? 'Behörighet återkallad' : 'Behörighet nekad',
            1,
            revoked
              ? 'Tidigare tillåten platsbehörighet har återkallats.'
              : 'Platsbehörighet är nekad.'
          );
        } else {
          notify();
        }
      });
      notify();
    } catch (_) {
      permissionStatus = null;
    }
  }

  function destroy() {
    consumers.clear();
    listeners.clear();
    clearNativeWatch();
  }

  installPermissionObserver();

  window.StadslassGpsService = Object.freeze({
    setConsumer,
    retry,
    setForeground,
    subscribe,
    getSnapshot: snapshot,
    destroy,
    constants: Object.freeze({
      freshPositionMs: FRESH_POSITION_MS,
      lowAccuracyMeters: LOW_ACCURACY_METERS
    })
  });
})();
