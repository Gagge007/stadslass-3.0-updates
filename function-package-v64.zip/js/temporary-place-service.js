(() => {
  'use strict';

  const SCHEMA_VERSION = 1;
  const SERVICE_VERSION = 1;
  const RADIUS_METERS = 80;
  const IDS = Object.freeze({
    from: 'SYS-TEMPORARY-FROM',
    destination: 'SYS-TEMPORARY-DESTINATION'
  });
  const LABELS = Object.freeze({
    from: 'Från annan plats',
    destination: 'Till annan plats'
  });
  const STATUSES = Object.freeze(['not-requested', 'resolved', 'failed', 'unavailable', 'invalid-input']);

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function roleKey(value) {
    return value === 'destination' ? 'destination' : 'from';
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined' || (typeof value === 'string' && !value.trim())) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function validCoordinates(latitude, longitude) {
    const lat = optionalNumber(latitude);
    const lon = optionalNumber(longitude);
    return lat !== null && lon !== null && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
  }

  function selectionId(role) {
    return IDS[roleKey(role)];
  }

  function selectionLabel(role) {
    return LABELS[roleKey(role)];
  }

  function isTemporarySelection(value, role = '') {
    const id = text(value);
    if (!id) return false;
    if (role) return id === selectionId(role);
    return id === IDS.from || id === IDS.destination;
  }

  function emptyPlace(role) {
    const resolvedRole = roleKey(role);
    return {
      schemaVersion: SCHEMA_VERSION,
      role: resolvedRole,
      selectionId: selectionId(resolvedRole),
      temporaryPlaceName: '',
      addressOrPlusCode: '',
      checkedReference: '',
      normalizedAddress: '',
      geocodingStatus: 'not-requested',
      latitude: null,
      longitude: null,
      coordinateValid: false,
      errorCode: '',
      errorMessage: '',
      resolvedAt: '',
      updatedAt: '',
      radiusMeters: RADIUS_METERS,
      source: 'temporary-other-place'
    };
  }

  function normalizePlace(value, role) {
    const resolvedRole = roleKey(role || (value && value.role));
    const source = isPlainObject(value) ? value : {};
    const status = STATUSES.includes(text(source.geocodingStatus)) ? text(source.geocodingStatus) : 'not-requested';
    const latitude = optionalNumber(source.latitude);
    const longitude = optionalNumber(source.longitude);
    const coordinateValid = status === 'resolved'
      && source.coordinateValid !== false
      && validCoordinates(latitude, longitude)
      && Boolean(text(source.normalizedAddress, text(source.addressOrPlusCode)));
    return {
      schemaVersion: SCHEMA_VERSION,
      role: resolvedRole,
      selectionId: selectionId(resolvedRole),
      temporaryPlaceName: text(source.temporaryPlaceName, text(source.name)),
      addressOrPlusCode: text(source.addressOrPlusCode, text(source.reference)),
      checkedReference: text(source.checkedReference),
      normalizedAddress: text(source.normalizedAddress, text(source.formattedAddress)),
      geocodingStatus: coordinateValid ? 'resolved' : (status === 'resolved' ? 'not-requested' : status),
      latitude: coordinateValid ? latitude : null,
      longitude: coordinateValid ? longitude : null,
      coordinateValid,
      errorCode: coordinateValid ? '' : text(source.errorCode),
      errorMessage: coordinateValid ? '' : text(source.errorMessage),
      resolvedAt: coordinateValid ? text(source.resolvedAt) : '',
      updatedAt: text(source.updatedAt),
      radiusMeters: RADIUS_METERS,
      source: 'temporary-other-place'
    };
  }

  function normalizeCollection(value) {
    const source = isPlainObject(value) ? value : {};
    const result = {};
    if (isPlainObject(source.from)) result.from = normalizePlace(source.from, 'from');
    if (isPlainObject(source.destination)) result.destination = normalizePlace(source.destination, 'destination');
    return result;
  }

  function displayLabel(placeValue, role) {
    const place = normalizePlace(placeValue, role);
    return text(place.temporaryPlaceName)
      || text(place.normalizedAddress)
      || text(place.addressOrPlusCode)
      || selectionLabel(place.role);
  }

  function invalidatePlace(placeValue, nextReference, timestamp = new Date().toISOString()) {
    const place = normalizePlace(placeValue, placeValue && placeValue.role);
    return {
      ...place,
      addressOrPlusCode: text(nextReference),
      checkedReference: '',
      normalizedAddress: '',
      geocodingStatus: 'not-requested',
      latitude: null,
      longitude: null,
      coordinateValid: false,
      errorCode: '',
      errorMessage: '',
      resolvedAt: '',
      updatedAt: timestamp
    };
  }

  function withName(placeValue, nextName, timestamp = new Date().toISOString()) {
    const place = normalizePlace(placeValue, placeValue && placeValue.role);
    return { ...place, temporaryPlaceName: text(nextName), updatedAt: timestamp };
  }

  function resolvedPlace(placeValue, resultValue, checkedReference, timestamp = new Date().toISOString()) {
    const place = normalizePlace(placeValue, placeValue && placeValue.role);
    const result = isPlainObject(resultValue) ? resultValue : {};
    const address = text(result.streetAddress, text(result.normalizedAddress));
    if (!address) throw new Error('Google-resultatet saknar en användbar gata eller väg.');
    if (!validCoordinates(result.latitude, result.longitude)) throw new Error('Google-resultatet saknar giltiga koordinater.');
    return {
      ...place,
      addressOrPlusCode: address,
      checkedReference: text(checkedReference, place.addressOrPlusCode),
      normalizedAddress: address,
      geocodingStatus: 'resolved',
      latitude: Number(result.latitude),
      longitude: Number(result.longitude),
      coordinateValid: true,
      errorCode: '',
      errorMessage: '',
      resolvedAt: timestamp,
      updatedAt: timestamp
    };
  }

  function failedPlace(placeValue, reference, errorValue, status = 'failed', timestamp = new Date().toISOString()) {
    const place = normalizePlace(placeValue, placeValue && placeValue.role);
    const error = isPlainObject(errorValue) || errorValue instanceof Error ? errorValue : {};
    const normalizedStatus = STATUSES.includes(status) && status !== 'resolved' ? status : 'failed';
    return {
      ...place,
      addressOrPlusCode: text(reference),
      checkedReference: '',
      normalizedAddress: '',
      geocodingStatus: normalizedStatus,
      latitude: null,
      longitude: null,
      coordinateValid: false,
      errorCode: text(error.code, 'GEOCODING_FAILED'),
      errorMessage: text(error.message, 'Adresskontrollen misslyckades.'),
      resolvedAt: '',
      updatedAt: timestamp
    };
  }

  function geofenceForPlace(placeValue, contextRole) {
    const place = normalizePlace(placeValue, placeValue && placeValue.role);
    if (!place.coordinateValid || !validCoordinates(place.latitude, place.longitude)) return null;
    const role = contextRole === 'return' ? 'return' : roleKey(contextRole || place.role);
    return {
      enabled: true,
      type: 'circle',
      latitude: place.latitude,
      longitude: place.longitude,
      radiusMeters: RADIUS_METERS,
      toleranceMeters: 0,
      visualLoadingLock: role === 'from',
      visualUnloadingLock: role === 'destination' || role === 'return',
      temporaryRuntimeGeofence: true
    };
  }

  function runtimePlace(placeValue, contextRole, jobId = '') {
    const sourceRole = roleKey(placeValue && placeValue.role);
    const place = normalizePlace(placeValue, sourceRole);
    const geofence = geofenceForPlace(place, contextRole || sourceRole);
    return {
      id: selectionId(sourceRole),
      name: displayLabel(place, sourceRole),
      roles: [sourceRole, ...(contextRole === 'return' ? ['return'] : [])],
      temporaryOtherPlace: true,
      temporaryRole: sourceRole,
      jobId: text(jobId),
      latitude: place.latitude,
      longitude: place.longitude,
      geofence
    };
  }

  function placeForJobRole(jobValue, role) {
    const job = isPlainObject(jobValue) ? jobValue : {};
    const places = normalizeCollection(job.temporaryPlaces);
    if (role === 'from' && isTemporarySelection(job.fromPlaceId, 'from') && places.from) {
      return runtimePlace(places.from, 'from', job.jobId || job.id);
    }
    if (role === 'destination' && isTemporarySelection(job.destinationPlaceId, 'destination') && places.destination) {
      return runtimePlace(places.destination, 'destination', job.jobId || job.id);
    }
    if (role === 'return') {
      const returnId = text(job.returnPlaceId, text(job.fromPlaceId));
      if (isTemporarySelection(returnId, 'from') && places.from) {
        return runtimePlace(places.from, 'return', job.jobId || job.id);
      }
    }
    return null;
  }

  window.StadslassTemporaryPlaceService = Object.freeze({
    SCHEMA_VERSION,
    SERVICE_VERSION,
    RADIUS_METERS,
    IDS,
    LABELS,
    STATUSES,
    validCoordinates,
    selectionId,
    selectionLabel,
    isTemporarySelection,
    emptyPlace,
    normalizePlace,
    normalizeCollection,
    displayLabel,
    invalidatePlace,
    withName,
    resolvedPlace,
    failedPlace,
    geofenceForPlace,
    runtimePlace,
    placeForJobRole
  });
})();
