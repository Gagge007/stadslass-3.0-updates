(() => {
  'use strict';
  const PREFIX = 'sync-reader-v64-';
  const MAX_SNAPSHOTS = 1500 * 1024;
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const bytes = (value) => new TextEncoder().encode(String(value || '')).length;
  const hash = (value) => { let h = 2166136261; for (const c of new TextEncoder().encode(String(value || ''))) { h ^= c; h = Math.imul(h, 16777619); } return `fnv1a-${(h >>> 0).toString(16).padStart(8, '0')}`; };
  const secret = /token|authorization|password|secret|apikey|googlekey|privatekey|credential|bearer|keystore/i;
  function sanitize(value, depth = 0) {
    if (depth > 32) return '[truncated-depth]';
    if (Array.isArray(value)) return value.map((item) => sanitize(item, depth + 1));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, secret.test(key) ? '[redacted]' : sanitize(item, depth + 1)]));
    return typeof value === 'string' && /(?:ghp_|github_pat_|Bearer\s+)/i.test(value) ? '[redacted]' : value;
  }
  function diff(before, after, prefix = '', output = { added: [], changed: [], removed: [] }) {
    if (JSON.stringify(before) === JSON.stringify(after)) return output;
    if (!before || !after || typeof before !== 'object' || typeof after !== 'object' || Array.isArray(before) || Array.isArray(after)) { output.changed.push(prefix || '$'); return output; }
    const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
    keys.forEach((key) => { const path = prefix ? `${prefix}.${key}` : key; if (!(key in before)) output.added.push(path); else if (!(key in after)) output.removed.push(path); else diff(before[key], after[key], path, output); });
    return output;
  }
  function create(environment) {
    const now = () => new Date().toISOString();
    const entries = () => environment.getOutbox().filter((entry) => entry && text(entry.kind).startsWith(PREFIX));
    const save = (next) => environment.saveOutbox(next);
    const state = () => entries().find((entry) => entry.kind === `${PREFIX}session`) || { id: `${PREFIX}session`, kind: `${PREFIX}session`, schemaVersion: 1, lastResetAt: '', active: null };
    function persistSession(next) { const all = environment.getOutbox().filter((entry) => entry && entry.kind !== `${PREFIX}session`); return save([...all, next]); }
    function start(name) { const current = state(); if (current.active) return current.active; const session = { id: `reader-${Date.now().toString(36)}`, name: text(name, 'Detaljerad synctest'), startedAt: now(), eventCount: 0, snapshotBytes: 0, truncated: false }; persistSession({ ...current, active: session }); return session; }
    function finish() { const current = state(); if (!current.active) return null; const closed = { ...current.active, endedAt: now() }; persistSession({ ...current, active: null, lastClosed: closed }); return closed; }
    function observe(event) {
      const current = state(); const clean = sanitize(event || {}); const serialized = JSON.stringify(clean); const id = `${PREFIX}event-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      const record = { id, kind: `${PREFIX}event`, schemaVersion: 1, at: now(), category: text(clean.category, 'sync'), lifecycle: text(clean.lifecycle), operation: text(clean.operation), path: text(clean.path), requestId: text(clean.requestId), commandId: text(clean.commandId), jobId: text(clean.jobId), byteLength: Number(clean.byteLength) || bytes(serialized), hash: hash(serialized), result: text(clean.result), detail: { ...clean, body: undefined } };
      let next = [...environment.getOutbox(), record];
      if (current.active && !current.active.truncated && clean.body !== undefined) {
        const snapshot = sanitize(clean.body); const snapshotText = typeof snapshot === 'string' ? snapshot : JSON.stringify(snapshot);
        if (current.active.snapshotBytes + bytes(snapshotText) <= MAX_SNAPSHOTS) next.push({ id: `${PREFIX}snapshot-${record.id}`, kind: `${PREFIX}snapshot`, eventId: id, value: snapshot, hash: hash(snapshotText), byteLength: bytes(snapshotText) });
        else current.active.truncated = true;
      }
      if (current.active) next = next.map((item) => item.kind === `${PREFIX}session` ? { ...item, active: { ...current.active, eventCount: current.active.eventCount + 1, snapshotBytes: current.active.snapshotBytes + (clean.body === undefined ? 0 : bytes(JSON.stringify(sanitize(clean.body)))) } } : item);
      return save(next);
    }
    function report(meta) {
      const current = state(); const events = entries().filter((entry) => entry.kind === `${PREFIX}event`); const snapshots = entries().filter((entry) => entry.kind === `${PREFIX}snapshot`);
      const lines = ['STADSLASS SYNCRAPPORT', `PackageVersion: 64`, `HostVersion: ${text(meta && meta.hostVersion)}`, `Roll: ${text(meta && meta.role)}`, `Fordons-ID: ${text(meta && meta.vehicleId)}`, `Skapad: ${now()}`, `Senaste nollställning: ${text(current.lastResetAt, 'Aldrig')}`, '', 'SAMMANFATTNING', `Händelser: ${events.length}`, `GET: ${events.filter((e) => e.operation === 'GET').length}`, `PUT: ${events.filter((e) => e.operation === 'PUT').length}`, `Snapshots: ${snapshots.length}`, `Trunkerad: ${Boolean(current.active && current.active.truncated)}`, '', 'KRONOLOGISK HÄNDELSELOGG'];
      events.forEach((event) => lines.push(`${event.at} | ${event.lifecycle || event.category} | ${event.operation || '-'} | ${event.path || '-'} | ${event.result || '-'} | ${event.byteLength} byte | ${event.hash}`));
      return lines.join('\n') + '\n';
    }
    function reset() { const current = state(); const remaining = environment.getOutbox().filter((entry) => !(entry && text(entry.kind).startsWith(PREFIX))); return save([...remaining, { id: `${PREFIX}session`, kind: `${PREFIX}session`, schemaVersion: 1, lastResetAt: now(), active: null }]); }
    return Object.freeze({ start, finish, observe, report, reset, state, entries, sanitize, diff, hash, bytes });
  }
  window.StadslassSyncReader = Object.freeze({ create, sanitize, diff, hash, bytes, PREFIX });
})();
