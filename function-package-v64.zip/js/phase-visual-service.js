(() => {
  'use strict';

  const SETTINGS_KEY = 'phaseColorsV1';
  const LOAD_REGISTERED_DELAY_MS = 5000;
  const DEFAULT_COLORS = Object.freeze({
    start_route: '#ef8f8f',
    loading: '#76a7e8',
    transport: '#ee9b55',
    unloading: '#6fbd72',
    load_registered: '#68c9c3',
    return_unloading: '#9a72c5',
    ready_to_complete: '#e3c655'
  });
  const COLOR_SETTING_PHASES = Object.freeze([
    'start_route',
    'loading',
    'transport',
    'unloading',
    'load_registered',
    'return_unloading',
    'ready_to_complete'
  ]);

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' && value.trim() ? value.trim() : fallback;
  }

  function normalizeHex(value, fallback) {
    const candidate = text(value).toLowerCase();
    return /^#[0-9a-f]{6}$/.test(candidate) ? candidate : fallback;
  }

  function normalizeColors(value) {
    const source = isPlainObject(value) ? value : {};
    const result = {};
    COLOR_SETTING_PHASES.forEach((phase) => {
      result[phase] = normalizeHex(source[phase], DEFAULT_COLORS[phase]);
    });
    return Object.freeze(result);
  }

  function settingPhase(phaseValue, phaseService) {
    if (!phaseService || typeof phaseService.normalizePhase !== 'function') return 'loading';
    const phase = phaseService.normalizePhase(phaseValue);
    return phase === phaseService.PHASES.RETURN_TRANSPORT ? phaseService.PHASES.TRANSPORT : phase;
  }

  function resolveColor(phaseValue, storedValue, phaseService) {
    const colors = normalizeColors(storedValue);
    const phase = settingPhase(phaseValue, phaseService);
    return colors[phase] || DEFAULT_COLORS.loading;
  }

  function contrastTextColor(hexValue) {
    const hex = normalizeHex(hexValue, DEFAULT_COLORS.loading).slice(1);
    const r = Number.parseInt(hex.slice(0, 2), 16);
    const g = Number.parseInt(hex.slice(2, 4), 16);
    const b = Number.parseInt(hex.slice(4, 6), 16);
    const luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    return luminance > 0.58 ? '#102a3a' : '#ffffff';
  }


  function mixHex(baseValue, targetValue, targetShare) {
    const base = normalizeHex(baseValue, DEFAULT_COLORS.loading).slice(1);
    const target = normalizeHex(targetValue, '#ffffff').slice(1);
    const share = Math.min(1, Math.max(0, Number(targetShare) || 0));
    const channels = [0, 2, 4].map((offset) => {
      const from = Number.parseInt(base.slice(offset, offset + 2), 16);
      const to = Number.parseInt(target.slice(offset, offset + 2), 16);
      return Math.round(from + ((to - from) * share)).toString(16).padStart(2, '0');
    });
    return `#${channels.join('')}`;
  }

  function softPalette(baseValue) {
    const base = normalizeHex(baseValue, DEFAULT_COLORS.loading);
    const button = mixHex(base, '#ffffff', 0.12);
    const buttonLight = mixHex(base, '#ffffff', 0.34);
    const backdropBottom = mixHex(base, '#ffffff', 0.58);
    const backdropMiddle = mixHex(base, '#ffffff', 0.76);
    const backdropTop = mixHex(base, '#ffffff', 0.91);
    const border = mixHex(base, '#102a3a', 0.12);
    return Object.freeze({
      base,
      button,
      buttonLight,
      backdropBottom,
      backdropMiddle,
      backdropTop,
      border,
      text: contrastTextColor(button)
    });
  }

  function markLoadRegistered(documentValue, jobId, nextPhase, at) {
    const source = isPlainObject(documentValue) ? documentValue : {};
    const timestamp = text(at);
    const parsedAt = Date.parse(timestamp);
    const normalizedJobId = text(jobId);
    const normalizedNextPhase = text(nextPhase);
    if (!normalizedJobId || !Number.isFinite(parsedAt) || !normalizedNextPhase) {
      throw new Error('Lass registrerat saknar giltigt jobb, nästa fas eller tidpunkt.');
    }
    return {
      ...source,
      loadRegisteredAt: timestamp,
      loadRegisteredUntil: new Date(parsedAt + LOAD_REGISTERED_DELAY_MS).toISOString(),
      loadRegisteredNextPhase: normalizedNextPhase,
      loadRegisteredJobId: normalizedJobId
    };
  }

  function remainingMs(documentValue, nowMs = Date.now()) {
    const source = isPlainObject(documentValue) ? documentValue : {};
    const untilMs = Date.parse(text(source.loadRegisteredUntil));
    if (!Number.isFinite(untilMs)) return 0;
    return Math.max(0, untilMs - Number(nowMs));
  }

  function timerMatches(documentValue, jobId, until) {
    const source = isPlainObject(documentValue) ? documentValue : {};
    return text(source.loadRegisteredJobId) === text(jobId)
      && text(source.loadRegisteredUntil) === text(until);
  }

  function clearLoadRegistered(documentValue) {
    const source = isPlainObject(documentValue) ? documentValue : {};
    const {
      loadRegisteredAt: _loadRegisteredAt,
      loadRegisteredUntil: _loadRegisteredUntil,
      loadRegisteredNextPhase: _loadRegisteredNextPhase,
      loadRegisteredJobId: _loadRegisteredJobId,
      ...rest
    } = source;
    return rest;
  }

  window.StadslassPhaseVisualService = Object.freeze({
    SETTINGS_KEY,
    LOAD_REGISTERED_DELAY_MS,
    DEFAULT_COLORS,
    COLOR_SETTING_PHASES,
    normalizeColors,
    settingPhase,
    resolveColor,
    contrastTextColor,
    mixHex,
    softPalette,
    markLoadRegistered,
    remainingMs,
    timerMatches,
    clearLoadRegistered
  });
})();
