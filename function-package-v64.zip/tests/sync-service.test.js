#!/usr/bin/env node
'use strict';

const assert = require('assert');
global.window = {};
require('../js/sync-service.js');
const api = window.StadslassSyncService;
let assertions = 0;
const ok = (value, message) => { assertions += 1; assert.ok(value, message); };
const equal = (actual, expected, message) => { assertions += 1; assert.strictEqual(actual, expected, message); };

const info = { syncTransportApiVersion: 1, deviceIdentityApiVersion: 1, syncCredentialApiVersion: 1 };
ok(api.hostCapabilities(info), 'v12 API 1 must be detected');
ok(!api.hostCapabilities({}), 'missing API must not activate sync');
equal(api.pathFor({ syncV63: { syncRoot: 'stadslass-3-sync' } }, '189', 'active-status.json'), 'stadslass-3-sync/vehicles/189/active-status.json');
assert.throws(() => api.pathFor({}, '189', '../active-status.json'), /ogiltig/i); assertions += 1;
assert.throws(() => api.request('GET', '../bad', api.PRIORITIES.active, 'x'), /ogiltigt/i); assertions += 1;
assert.throws(() => api.request('PUT', 'safe.json', api.PRIORITIES.active, 'x', 'x'.repeat(901 * 1024)), /för stor/i); assertions += 1;

const installation = 'installation-12345678';
const active = {
  id: 'job-1', jobId: 'job-1', status: 'active', phase: 'transport', jobTypeName: 'Blandat',
  fromPlaceName: 'Ringön', destinationPlaceName: 'Renova', note: '<img src=x>',
  gpsTrack: [{ latitude: 57.7 }], geofence: { polygon: [1, 2] }, googleApiKey: 'never'
};
const status = api.activeStatus(active, '189', installation, 2, { workSessionId: 'work-1', leaseUpdatedAt: '2026-08-02T00:00:00Z', leaseExpiresAt: '2026-08-02T00:02:00Z' });
equal(status.protocol, api.PROTOCOLS.active);
equal(status.sequence, 2);
equal(status.activeJob.jobId, 'job-1');
ok(!('gpsTrack' in status.activeJob), 'GPS tracks must not mirror');
ok(!('geofence' in status.activeJob), 'geofence must not mirror');
ok(!('googleApiKey' in status.activeJob), 'keys must not mirror');
const empty = api.activeStatus({}, '189', installation, 3, null);
ok(empty.hasActiveJob === false && empty.activeJob === null, 'terminal empty status is explicit');

const original = { id: 'job-a', jobId: 'job-a', jobRevision: 3, jobTypeName: 'Annat', futureField: { keep: true } };
const create = api.command('create', installation, '189', { id: 'job-b', jobId: 'job-b', jobRevision: 1, jobTypeName: 'Nytt' });
let applied = api.applyCommand([original], {}, create, '189', installation, new Set());
equal(applied.result.status, 'applied');
equal(applied.queue.length, 2);
equal(applied.queue[1].jobId, 'job-b');
ok(applied.notification, 'newly persisted create is the only notification case');
applied = api.applyCommand(applied.queue, {}, create, '189', installation, new Set());
equal(applied.result.status, 'already-present');
const edit = api.command('edit', installation, '189', { id: 'job-a', jobId: 'job-a', jobRevision: 3, jobTypeName: 'Ändrat', newField: 'new' }, 3);
applied = api.applyCommand([original], {}, edit, '189', installation, new Set());
equal(applied.result.status, 'applied');
equal(applied.queue[0].jobId, 'job-a');
equal(applied.queue[0].jobRevision, 4);
ok(applied.queue[0].futureField.keep, 'unknown fields survive edit');
const staleEdit = api.command('edit', installation, '189', { id: 'job-a', jobId: 'job-a' }, 2);
equal(api.applyCommand([original], {}, staleEdit, '189', installation, new Set()).result.status, 'rejected');
equal(api.applyCommand([original], { id: 'active-1', sourceQueueItemId: 'job-a', status: 'active' }, edit, '189', installation, new Set()).result.status, 'rejected');
const remove = api.command('delete', installation, '189', original, 3);
applied = api.applyCommand([original], {}, remove, '189', installation, new Set());
equal(applied.result.status, 'applied');
equal(applied.queue.length, 0);
equal(api.applyCommand([], {}, remove, '189', installation, new Set()).result.status, 'rejected');
const demand = api.onDemandRequest('history', installation, '189', { month: '2026-08' });
equal(demand.protocol, api.PROTOCOLS.onDemand);
equal(demand.sourceRole, 'mobile');
assert.throws(() => api.onDemandRequest('delete-history', installation, '189'), /Ogiltig/i); assertions += 1;

let outbox = [];
const requests = [];
const host = {
  enqueueSyncRequest(raw) { requests.push(JSON.parse(raw)); return JSON.stringify({ ok: true, status: 'accepted' }); },
  getSyncRequestStatus(id) { return JSON.stringify({ requestId: id, status: 'succeeded', body: '{}' }); }
};
const service = api.create({ host: () => host, getHostInfo: () => info, readOutbox: () => outbox, saveOutbox: (next) => { outbox = next; return true; } });
const queued = service.enqueue('put-active', 'PUT', 'stadslass-3-sync/vehicles/189/active-status.json', api.PRIORITIES.active, JSON.stringify(status), '', 'active_work/189');
ok(queued.ok, 'host accepted request');
equal(requests[0].priority, 'active_work');
equal(outbox.length, 1);
ok(!JSON.stringify(outbox).includes('token'), 'outbox never receives a token');
const result = service.recover(queued.requestId);
equal(result.status, 'succeeded');
equal(service.recordResult(queued.requestId, result).state, 'succeeded');
ok(api.terminal('succeeded') && !api.terminal('failed_retryable'), 'only terminal results acknowledge');
console.log(`PASS sync-service.test.js (${assertions} assertions)`);
