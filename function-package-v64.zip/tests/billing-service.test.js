'use strict';
const assert = require('assert');
const fs = require('fs');
const vm = require('vm');
const path = require('path');

const source = fs.readFileSync(path.join(__dirname, '..', 'js', 'ata', 'billing-service.js'), 'utf8');
const context = { window: {}, console, Date, Math, Number, String, Object, Array, Set, JSON };
vm.createContext(context);
vm.runInContext(source, context, { filename: 'billing-service.js' });
const api = context.window.StadslassAtaBilling;
assert(api, 'Billing API should be available');

function iso(minutes) {
  return new Date(Date.UTC(2026, 0, 1, 0, minutes, 0)).toISOString();
}

function job(overrides = {}) {
  return {
    startedAt: iso(0),
    workSegments: [{ startedAt: iso(0), endedAt: iso(150) }],
    phaseTimeline: [
      { phase: 'start_route', startedAt: iso(0), endedAt: iso(10) },
      { phase: 'loading', startedAt: iso(10), endedAt: iso(40) },
      { phase: 'transport', startedAt: iso(40), endedAt: iso(70) },
      { phase: 'unloading', startedAt: iso(70), endedAt: iso(100) },
      { phase: 'return_transport', startedAt: iso(100), endedAt: iso(130) },
      { phase: 'return_unloading', startedAt: iso(130), endedAt: iso(140) },
      { phase: 'ready_to_complete', startedAt: iso(140), endedAt: iso(150) }
    ],
    ata: { enabled: true, source: 'manual', updatedAt: iso(0) },
    ...overrides
  };
}

// Total time and pause awareness.
assert.strictEqual(api.totalWorkMinutes(job(), iso(150)), 150);
assert.strictEqual(api.totalWorkMinutes(job({ workSegments: [
  { startedAt: iso(0), endedAt: iso(50) },
  { startedAt: iso(60), endedAt: iso(150) }
] }), iso(150)), 140);

// Total-time 30-minute rule.
assert.strictEqual(api.roundTotalUp(1), 30);
assert.strictEqual(api.roundTotalUp(29), 30);
assert.strictEqual(api.roundTotalUp(30), 30);
assert.strictEqual(api.roundTotalUp(31), 60);
assert.strictEqual(api.roundTotalUp(60), 60);
assert.strictEqual(api.roundTotalUp(77), 90);
assert.strictEqual(api.roundTotalUp(121), 150);

// Completion manual input.
assert.strictEqual(api.parseCompletionManual('29'), null);
assert.strictEqual(api.parseCompletionManual('30'), 30);
assert.strictEqual(api.parseCompletionManual('47'), 47);
assert.strictEqual(api.parseCompletionManual(''), null);
assert.strictEqual(api.parseCompletionManual('-1'), null);
assert.strictEqual(api.parseCompletionManual('12.5'), null);
assert.strictEqual(api.parseCompletionManual('abc'), null);

// Phase basis excludes start route and final return.
let phase = api.phaseWorkMinutes(job({ returnRequired: true }), iso(150));
assert.deepStrictEqual(JSON.parse(JSON.stringify(phase)), { minutes: 90, fallbackUsed: false, phaseIntervalCount: 1 });

// Paused time is removed by intersecting with work segments.
phase = api.phaseWorkMinutes(job({
  returnRequired: true,
  workSegments: [
    { startedAt: iso(0), endedAt: iso(50) },
    { startedAt: iso(60), endedAt: iso(150) }
  ]
}), iso(150));
assert.strictEqual(phase.minutes, 80);
assert.strictEqual(phase.fallbackUsed, false);

// Multi-load records may include an actual between-load return_transport interval.
phase = api.phaseWorkMinutes(job({ multiLoad: true, returnRequired: false }), iso(150));
assert.strictEqual(phase.minutes, 120);
assert.strictEqual(phase.fallbackUsed, false);

// Missing reliable phase timestamps uses pause-aware total time without inventing entries.
const fallbackJob = job({ phaseTimeline: [], workSegments: [{ startedAt: iso(0), endedAt: iso(77) }] });
phase = api.phaseWorkMinutes(fallbackJob, iso(77));
assert.strictEqual(phase.minutes, 77);
assert.strictEqual(phase.fallbackUsed, true);
assert.strictEqual(fallbackJob.phaseTimeline.length, 0);

// Lower/upper 30-minute levels.
assert.deepStrictEqual(JSON.parse(JSON.stringify(api.halfHourOptions(47))), { sourceMinutes: 47, lower: 30, upper: 60, exact: false });
assert.deepStrictEqual(JSON.parse(JSON.stringify(api.halfHourOptions(60))), { sourceMinutes: 60, lower: 60, upper: 60, exact: true });
assert.deepStrictEqual(JSON.parse(JSON.stringify(api.halfHourOptions(77))), { sourceMinutes: 77, lower: 60, upper: 90, exact: false });
assert.deepStrictEqual(JSON.parse(JSON.stringify(api.halfHourOptions(102))), { sourceMinutes: 102, lower: 90, upper: 120, exact: false });
assert.deepStrictEqual(JSON.parse(JSON.stringify(api.halfHourOptions(12))), { sourceMinutes: 12, lower: 30, upper: 30, exact: true });

// Billing is stored inside the existing ATA object and preserves work data.
const original = job({ jobId: 'job-1' });
const billing = api.createBilling({ minutes: 90, mode: api.MODES.TOTAL_UP, sourceMinutes: 77, selectedAt: iso(150) });
const applied = api.applyToRecord(original, billing, iso(150));
assert.strictEqual(applied.jobId, 'job-1');
assert.strictEqual(applied.ata.enabled, true);
assert.strictEqual(applied.ata.billing.minutes, 90);
assert.deepStrictEqual(applied.workSegments, original.workSegments);
assert.deepStrictEqual(applied.phaseTimeline, original.phaseTimeline);

// History correction allows zero and blank/removal is separate.
const corrected = api.editRecord(applied, 0, iso(160));
assert.strictEqual(corrected.ata.billing.minutes, 0);
assert.strictEqual(corrected.ata.billing.mode, api.MODES.MANUAL_CORRECTION);
assert.strictEqual(corrected.startedAt, original.startedAt);
const removed = api.removeFromRecord(corrected, iso(170));
assert.strictEqual(Object.prototype.hasOwnProperty.call(removed.ata, 'billing'), false);
assert.strictEqual(removed.ata.enabled, true);

console.log('PASS billing-service.test.js');
