'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const context = { window: { StadslassAtaNotificationSettings: { TEMPLATE_FIELDS: ['jobType','fromPlace','toPlace','returnPlace','date','startedAt','completedAt','billableTime','loadCount','totalWeight','note','truck189'] } }, Date, Math, Number, String, Object, Array, JSON, RegExp, Intl };
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', 'ata', 'mail-underlag-service.js'), 'utf8'), context);
const api = context.window.StadslassAtaMailUnderlag;
assert(api);

const job = {
  id: 'job-1', status: 'completed', jobTypeName: 'Kompost', fromPlaceName: 'Ringön (BAS)', destinationPlaceName: 'Renova Bioanläggning',
  returnRequired: false, startedAt: '2026-07-31T05:30:00+02:00', completedAt: '2026-07-31T07:10:00+02:00',
  loads: [{ weight: 4.5 }, { weight: 2 }], totalWeight: 6.5, note: 'Kontrollerad kommentar',
  ata: { enabled: true, recipient: { name: 'Beställare', email: 'bestallare@example.se' }, billing: { minutes: 90 } }
};
const tpl = { fields: { jobType: true, fromPlace: true, toPlace: true, returnPlace: true, date: true, startedAt: true, completedAt: true, billableTime: true, loadCount: true, totalWeight: true, note: true, truck189: true }, closingText: 'Egen avslutning' };
assert.strictEqual(api.isEligible(job), true);
assert.strictEqual(api.isEligible({ ...job, ata: { enabled: false } }), false);
assert.strictEqual(api.isEligible({ ...job, status: 'active' }), false);
assert.strictEqual(api.isEligible({ ...job, trashState: { status: 'trashed' } }), false);
assert.strictEqual(api.isEligible({ ...job, receiptImported: true }), false);
const individual = api.individual(job, tpl);
assert.strictEqual(individual.subject, 'ÄTA uppdrag lastbil 189');
['Jobbtyp: Kompost','Från: Ringön (BAS)','Till: Renova Bioanläggning','Datum: 2026-07-31','Starttid: 05:30','Sluttid: 07:10','Debiterbar tid: 90 min','Antal lass: 2','Total vikt: 6,5 ton','Kommentar: Kontrollerad kommentar','Lastbil: 189','Egen avslutning'].forEach((line) => assert(individual.body.includes(line), line));
assert.strictEqual(individual.preview, individual.body);
assert(!individual.body.startsWith('Till:'));
assert(!individual.body.includes('Ämne: ÄTA uppdrag lastbil 189'));
assert(!api.body(job, { fields: { note: false }, closingText: '' }).includes('Kommentar:'));
assert.strictEqual(api.recipient({ name: 'X', email: 'x@example.se' }).valid, true);
assert.strictEqual(api.recipient({ name: 'X', email: 'fel' }).valid, false);
assert.strictEqual(api.recipientText({}), 'Mottagare saknas');

const duplicateAddressJob = {
  ...job,
  fromPlaceName: 'Humlevägen 1 Landvetter',
  destinationPlaceName: 'Lergodsgatan 1 Göteborg',
  temporaryPlaces: {
    from: { normalizedAddress: '  HUMLEVÄGEN  1, Landvetter. ' },
    destination: { displayAddress: 'Lergodsgatan 1 Göteborg' }
  }
};
const duplicateBody = api.body(duplicateAddressJob, tpl);
assert.strictEqual((duplicateBody.match(/^Från:/gm) || []).length, 1);
assert.strictEqual((duplicateBody.match(/^Till:/gm) || []).length, 1);
assert(!duplicateBody.includes('Från adress:'));
assert(!duplicateBody.includes('Till adress:'));
const namedPlaceJob = {
  ...duplicateAddressJob,
  fromPlaceName: 'Ringön BAS',
  temporaryPlaces: { ...duplicateAddressJob.temporaryPlaces, from: { normalizedAddress: 'Stenkolsgatan 2 Göteborg' } }
};
const namedPlaceBody = api.body(namedPlaceJob, tpl);
assert(namedPlaceBody.includes('Från: Ringön BAS'));
assert(namedPlaceBody.includes('Från adress: Stenkolsgatan 2 Göteborg'));
assert.strictEqual(api.addressAddsInformation('Humlevägen 1', 'Humlevägen 11'), true);
assert.strictEqual(api.addressAddsInformation('Humlevägen 1 Landvetter', 'Humlevägen 1, Landvetter.'), false);
const dated = { ...job, id: 'job-2', startedAt: '2026-07-31T08:00:00+02:00', completedAt: '2026-07-31T09:00:00+02:00', ata: { ...job.ata, billing: { minutes: 30 } } };
const daily = api.daily([dated, job, { ...job, id: 'other-day', completedAt: '2026-08-01T07:00:00+02:00' }], '2026-07-31', { name: 'Arbetsledare', email: 'chef@example.se' });
assert.strictEqual(daily.jobs.length, 2);
assert.strictEqual(daily.totalMinutes, 120);
assert.strictEqual(daily.totalWeight, 13);
assert(daily.body.includes('Här kommer dagens ÄTA-uppdrag för lastbil 189.'));
assert(daily.body.endsWith('Mvh\nLastbil 189'));
assert.strictEqual(daily.preview, daily.body);
assert(!daily.preview.startsWith('Till:'));
assert.strictEqual(daily.body.indexOf('1. ÄTA-uppdrag') < daily.body.indexOf('2. ÄTA-uppdrag'), true);
const opened = api.withStatus(job, api.ACTIONS.OPENED, 'opened', '2026-07-31T08:00:00.000Z');
assert.strictEqual(api.status(opened).label, 'Mailutkast öppnat');
assert.strictEqual(opened.ata.mail.draftOpenedAt, '2026-07-31T08:00:00.000Z');
const copied = api.withStatus(opened, api.ACTIONS.COPIED, 'copied', '2026-07-31T08:02:00.000Z');
assert.strictEqual(api.status(copied).label, 'Underlag kopierat');
assert.strictEqual(copied.ata.mail.draftOpenedAt, '2026-07-31T08:00:00.000Z');
assert.strictEqual(copied.ata.mail.underlagCopiedAt, '2026-07-31T08:02:00.000Z');
const skipped = api.withStatus(copied, api.ACTIONS.SKIPPED, 'skipped', '2026-07-31T08:03:00.000Z');
assert.strictEqual(api.status(skipped).label, 'Ej skickat nu');
assert.strictEqual(skipped.ata.mail.notSentAt, '2026-07-31T08:03:00.000Z');
assert.strictEqual(api.status(job).label, 'Ej valt');
console.log('PASS ata-mail-underlag-service.test.js (50 assertions)');
