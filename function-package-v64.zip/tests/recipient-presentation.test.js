'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const context = { window: { crypto: { randomUUID: () => 'generated-id' } }, Date, Math, Number, String, Object, Array, JSON, RegExp, Intl, Uint8Array };
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', 'ata', 'notification-settings-service.js'), 'utf8'), context);
const api = context.window.StadslassAtaNotificationSettings;
assert(api);
assert.strictEqual(api.PACKAGE_VERSION, 62);
assert.strictEqual(api.recipientListLabel({ name: ' Test ', email: 'test@example.se' }), 'Test');
assert.strictEqual(api.recipientListLabel({ name: '', email: 'hidden@example.se' }), 'Namnlös mottagare');
assert.strictEqual(api.recipientListLabel({ name: '   ', email: 'hidden@example.se' }), 'Namnlös mottagare');
assert.strictEqual(api.recipientListLabel({ name: '<img src=x onerror=1>', email: 'safe@example.se' }), '<img src=x onerror=1>');
assert.strictEqual(api.recipientQueueLabel({ contactId: 'a', name: ' Test ', email: 'test@example.se' }), 'ÄTA-mottagare: Test');
assert.strictEqual(api.recipientQueueLabel({ contactId: 'a', name: '', email: 'hidden@example.se' }), 'ÄTA-mottagare vald');
assert.strictEqual(api.recipientQueueLabel({ name: '', email: 'hidden@example.se' }), 'ÄTA-mottagare vald');
assert.strictEqual(api.recipientQueueLabel({}), '');
assert(!api.recipientListLabel({ name: '', email: 'hidden@example.se' }).includes('@'));
assert(!api.recipientQueueLabel({ contactId: 'a', name: '', email: 'hidden@example.se' }).includes('@'));
const settings = api.normalizeSettings({ futureSettings: { keep: true }, contacts: [
  { id: 'a', name: 'Samma', email: 'a@example.se', createdAt: '2026-01-01T00:00:00Z', future: 1 },
  { id: 'b', name: 'Samma', email: 'b@example.se', createdAt: '2026-01-02T00:00:00Z', future: 2 },
  { id: 'c', name: '', email: 'c@example.se', createdAt: '2026-01-03T00:00:00Z', future: 3 },
  { id: 'invalid', name: 'Ogiltig', email: 'fel', createdAt: '2026-01-04T00:00:00Z', future: 4 }
]});
const display = api.contactsForDisplay(settings);
assert.strictEqual(display.length, 3);
assert.deepStrictEqual(Array.from(display.map(x => x.id)).sort(), ['a','b','c']);
assert.strictEqual(display.find(x => x.id === 'c').email, 'c@example.se');
assert.strictEqual(display.find(x => x.id === 'c').future, 3);
assert.strictEqual(settings.futureSettings.keep, true);
assert.strictEqual(api.canonicalMatch(settings, ' A@EXAMPLE.SE ').id, 'a');
assert.strictEqual(api.normalizeEmail(' A@EXAMPLE.SE '), 'a@example.se');
const proposal = api.saveContact(settings, { id: 'a', name: 'Samma', email: 'a@example.se' }, '2026-02-01T00:00:00Z');
assert.strictEqual(proposal.contact.id, 'a');
assert.strictEqual(proposal.contact.email, 'a@example.se');
assert.strictEqual(proposal.requiresConfirmation, false);
const duplicate = api.saveContact(settings, { name: 'Ny', email: ' A@EXAMPLE.SE ' }, '2026-02-01T00:00:00Z');
assert.strictEqual(duplicate.requiresConfirmation, true);
assert.strictEqual(duplicate.duplicates[0].id, 'a');
assert.strictEqual(api.contactsForDisplay(api.commitContact(settings, duplicate.contact)).length, 4);
assert(!('active' in api.normalizeSettings({ contacts: [{ id: 'legacy', name: 'Legacy', email: 'legacy@example.se', active: false }] }).contacts[0]) || api.normalizeSettings({ contacts: [{ id: 'legacy', name: 'Legacy', email: 'legacy@example.se', active: false }] }).contacts[0].active === false);
console.log('PASS recipient-presentation.test.js (26 assertions)');
