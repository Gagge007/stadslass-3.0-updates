(() => {
  'use strict';

  const SCHEMA_VERSION = 2;
  const KINDS = Object.freeze({ HISTORY: 'history', RECEIPT: 'receipt', ARCHIVE: 'archive' });
  const text = (value) => typeof value === 'string' ? value.trim() : '';
  const plain = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const clone = (value) => JSON.parse(JSON.stringify(value));

  function normalize(item) {
    if (plain(item) && [KINDS.HISTORY, KINDS.RECEIPT, KINDS.ARCHIVE].includes(text(item.syncKind)) && plain(item.record)) {
      const normalized = { syncKind: text(item.syncKind), record: clone(item.record) };
      if (normalized.syncKind === KINDS.RECEIPT && plain(item.receiptRow)) normalized.receiptRow = clone(item.receiptRow);
      return normalized;
    }
    if (plain(item)) return { syncKind: KINDS.HISTORY, record: clone(item) };
    return null;
  }

  function record(item) {
    const normalized = normalize(item);
    return normalized ? normalized.record : null;
  }

  function kind(item) {
    const normalized = normalize(item);
    return normalized ? normalized.syncKind : '';
  }

  function buildSnapshot({ historyRecords = [], receiptRows = [], archiveRecords = [], receiptProjector = null, sourceUnit = '', exportedAt = '' } = {}) {
    const records = [];
    (Array.isArray(historyRecords) ? historyRecords : []).filter(plain).forEach((value) => {
      records.push({ syncKind: KINDS.HISTORY, record: clone(value) });
    });
    (Array.isArray(receiptRows) ? receiptRows : []).filter(plain).forEach((row, index) => {
      const projected = typeof receiptProjector === 'function' ? receiptProjector(row, index) : null;
      if (!plain(projected)) throw new Error('Kvittohistoriken kunde inte projiceras för historiksynk.');
      records.push({ syncKind: KINDS.RECEIPT, record: clone(projected), receiptRow: clone(row) });
    });
    (Array.isArray(archiveRecords) ? archiveRecords : []).filter(plain).forEach((value) => {
      records.push({ syncKind: KINDS.ARCHIVE, record: clone(value) });
    });
    return {
      schemaVersion: SCHEMA_VERSION,
      exportedAt: text(exportedAt) || new Date().toISOString(),
      sourceUnit: text(sourceUnit),
      scope: 'all-history',
      counts: {
        historyRecords: (Array.isArray(historyRecords) ? historyRecords : []).filter(plain).length,
        receiptRows: (Array.isArray(receiptRows) ? receiptRows : []).filter(plain).length,
        archiveRecords: (Array.isArray(archiveRecords) ? archiveRecords : []).filter(plain).length,
        totalRecords: records.length
      },
      records
    };
  }

  function transportId(item, helpers = {}) {
    const normalized = normalize(item);
    if (!normalized) return '';
    const value = normalized.record;
    if (normalized.syncKind === KINDS.RECEIPT) {
      const row = normalized.receiptRow || {};
      const direct = text(row.id) || text(value.receiptRowId) || text(value.id);
      if (direct) return `receipt:${direct}`;
      if (typeof helpers.receiptKey === 'function') return `receipt-key:${text(helpers.receiptKey(row))}`;
      return '';
    }
    if (normalized.syncKind === KINDS.ARCHIVE) {
      const direct = typeof helpers.archiveSourceId === 'function' ? text(helpers.archiveSourceId(value)) : (text(value.archiveSourceId) || text(value.id));
      return direct ? `archive:${direct}` : '';
    }
    const direct = typeof helpers.historyId === 'function' ? text(helpers.historyId(value)) : (text(value.id) || text(value.jobId) || text(value.sourceJobId));
    return direct ? `history:${direct}` : '';
  }

  function selectedByIds(items, ids, helpers = {}) {
    const selected = new Set((Array.isArray(ids) ? ids : []).map(text).filter(Boolean));
    return (Array.isArray(items) ? items : []).filter((item) => selected.has(transportId(item, helpers)));
  }

  function splitAccepted(items) {
    const result = { history: [], receipts: [], archive: [] };
    (Array.isArray(items) ? items : []).forEach((item) => {
      const normalized = normalize(item);
      if (!normalized) return;
      if (normalized.syncKind === KINDS.RECEIPT) result.receipts.push(clone(normalized.receiptRow || {}));
      else if (normalized.syncKind === KINDS.ARCHIVE) result.archive.push(clone(normalized.record));
      else result.history.push(clone(normalized.record));
    });
    return result;
  }


  function accumulateTransfer(existingTransfer, pkg, maxParts = 20) {
    if (!plain(pkg) || !plain(pkg.payload) || !Array.isArray(pkg.payload.records)) throw new Error('Historikdelen är ogiltig.');
    const payload = pkg.payload;
    const transferId = text(payload.transferId);
    const requestId = text(pkg.requestId);
    const from = text(pkg.from);
    const partCount = Number(payload.partCount);
    const partIndex = Number(payload.partIndex);
    const totalRecordCount = Number(payload.totalRecordCount);
    if (!transferId || !requestId || !from || !Number.isInteger(partCount) || partCount < 2 || partCount > maxParts || !Number.isInteger(partIndex) || partIndex < 0 || partIndex >= partCount) {
      throw new Error('Historikpaketets delinformation är ogiltig.');
    }
    if (!Number.isInteger(totalRecordCount) || totalRecordCount < 0) throw new Error('Historikpaketets totalantal är ogiltigt.');
    let transfer;
    if (plain(existingTransfer) && text(existingTransfer.transferId) === transferId) transfer = clone(existingTransfer);
    else transfer = { transferId, requestId, from, partCount, totalRecordCount, parts: {}, receivedAt: new Date().toISOString(), exportedAt: text(payload.exportedAt), sourceUnit: text(payload.sourceUnit), scope: text(payload.scope) || 'all-history', schemaVersion: Number(payload.schemaVersion) || SCHEMA_VERSION };
    if (text(transfer.requestId) !== requestId || text(transfer.from) !== from || Number(transfer.partCount) !== partCount || Number(transfer.totalRecordCount) !== totalRecordCount) {
      throw new Error('Historikdelarna har olika transferidentitet.');
    }
    if (!plain(transfer.parts)) transfer.parts = {};
    const key = String(partIndex);
    const incomingPart = { packageId: text(pkg.packageId), records: clone(payload.records) };
    const prior = transfer.parts[key];
    if (plain(prior)) {
      if (JSON.stringify(prior) !== JSON.stringify(incomingPart)) throw new Error('Samma historikdel har mottagits med olika innehåll.');
    } else {
      transfer.parts[key] = incomingPart;
    }
    const complete = Array.from({ length: partCount }, (_, index) => plain(transfer.parts[String(index)])).every(Boolean);
    if (!complete) return { transfer, complete: false, duplicate: plain(prior), combinedPayload: null };
    const records = [];
    for (let index = 0; index < partCount; index += 1) records.push(...transfer.parts[String(index)].records);
    if (records.length !== totalRecordCount) throw new Error('Historikdelarna ger fel totalt antal poster.');
    return {
      transfer,
      complete: true,
      duplicate: plain(prior),
      combinedPayload: {
        schemaVersion: Number(transfer.schemaVersion) || SCHEMA_VERSION,
        exportedAt: text(transfer.exportedAt),
        sourceUnit: text(transfer.sourceUnit),
        scope: text(transfer.scope) || 'all-history',
        transferId,
        partCount,
        totalRecordCount: records.length,
        records
      }
    };
  }

  window.StadslassHistorySync = Object.freeze({ SCHEMA_VERSION, KINDS, normalize, record, kind, buildSnapshot, transportId, selectedByIds, splitAccepted, accumulateTransfer });
})();
