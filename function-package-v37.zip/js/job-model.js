(() => {
  'use strict';

  const JOB_MODEL_VERSION = 2;
  const PACKAGE_VERSION = 37;
  const registries = window.StadslassRegistries || null;
  const jobTypeItems = registries && registries.jobTypes && Array.isArray(registries.jobTypes.items) ? registries.jobTypes.items : [];
  const conditionalRules = registries && registries.jobTypes && Array.isArray(registries.jobTypes.conditionalRules) ? registries.jobTypes.conditionalRules : [];
  let placeItems = Object.freeze([]);
  let placesInitialized = false;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function normalizedName(value) {
    return text(value).toLocaleLowerCase('sv-SE');
  }

  function immutablePlace(item) {
    const copy = { ...item };
    if (Array.isArray(item.aliases)) copy.aliases = Object.freeze(item.aliases.slice());
    if (Array.isArray(item.roles)) copy.roles = Object.freeze(item.roles.slice());
    if (Array.isArray(item.allowedJobTypeIds)) copy.allowedJobTypeIds = Object.freeze(item.allowedJobTypeIds.slice());
    return Object.freeze(copy);
  }

  function initializePlaces(items) {
    if (placesInitialized) throw new Error('Uppdragsmodellens effektiva platslista är redan låst för denna körning.');
    if (!Array.isArray(items) || items.length < 1) throw new Error('Den effektiva platslistan är tom eller saknas.');
    const ids = new Set();
    const normalized = items.map((item) => {
      if (!isPlainObject(item) || !text(item.id) || !text(item.name)) throw new Error('Den effektiva platslistan innehåller en ogiltig plats.');
      if (ids.has(text(item.id))) throw new Error('Den effektiva platslistan innehåller dubbla plats-ID:n.');
      ids.add(text(item.id));
      return immutablePlace(item);
    });
    placeItems = Object.freeze(normalized);
    placesInitialized = true;
    return placeItems;
  }

  function getPlaceItems() {
    if (!placesInitialized) throw new Error('Uppdragsmodellens effektiva platslista har inte initierats.');
    return placeItems;
  }

  function findJobTypeById(id) {
    return jobTypeItems.find((item) => item && text(item.id) === text(id)) || null;
  }

  function findJobTypeByName(name) {
    const key = normalizedName(name);
    if (!key) return null;
    return jobTypeItems.find((item) => item && ([item.name].concat(Array.isArray(item.aliases) ? item.aliases : [])).some((candidate) => normalizedName(candidate) === key)) || null;
  }

  function isOtherActivityJobType(value) {
    const type = typeof value === 'string' ? findJobTypeById(value) : value;
    return Boolean(type && (text(type.id) === 'JT-1001' || text(type.specialRole) === 'other-activity'));
  }

  function findPlaceById(id) {
    if (!placesInitialized) return null;
    return placeItems.find((item) => item && text(item.id) === text(id)) || null;
  }

  function findPlaceByName(name) {
    if (!placesInitialized) return null;
    const key = normalizedName(name);
    if (!key) return null;
    const matches = placeItems.filter((item) => item && ([item.name].concat(Array.isArray(item.aliases) ? item.aliases : [])).some((candidate) => normalizedName(candidate) === key));
    return matches.find((item) => item.hidden !== true && item.active !== false) || matches[0] || null;
  }

  function validateRegistries() {
    if (!registries || !registries.jobSchema || Number(registries.jobSchema.jobModelVersion) !== JOB_MODEL_VERSION) {
      throw new Error('Uppdragsmodellens register saknas eller har fel version.');
    }
    if (!placesInitialized) throw new Error('Uppdragsmodellen har inte initierats med den effektiva platslistan.');
    if (jobTypeItems.length < 1 || placeItems.length < 1) {
      throw new Error('Jobbtyps- eller platsregistret är tomt.');
    }
    const jobTypeIds = new Set();
    const placeIds = new Set();
    jobTypeItems.forEach((item) => {
      if (!item || !text(item.id) || !text(item.name) || jobTypeIds.has(item.id)) throw new Error('Jobbtypsregistret har ogiltigt eller dubblerat ID.');
      jobTypeIds.add(item.id);
    });
    placeItems.forEach((item) => {
      if (!item || !text(item.id) || !text(item.name) || placeIds.has(item.id)) throw new Error('Platsregistret har ogiltigt eller dubblerat ID.');
      placeIds.add(item.id);
    });
    conditionalRules.forEach((rule) => {
      if (!findJobTypeById(rule.jobTypeId)) throw new Error('Materialregel hänvisar till okänd jobbtyp.');
      if (text(rule.fromPlaceId) && !findPlaceById(rule.fromPlaceId)) throw new Error('Materialregel hänvisar till okänd Från-plats.');
      if (text(rule.destinationPlaceId) && !findPlaceById(rule.destinationPlaceId)) throw new Error('Materialregel hänvisar till okänd Till-plats.');
      if (text(rule.facilityPlaceId) && !findPlaceById(rule.facilityPlaceId)) throw new Error('Materialregel hänvisar till okänd anläggning.');
    });
    return { jobTypeCount: jobTypeItems.length, placeCount: placeItems.length, jobModelVersion: JOB_MODEL_VERSION };
  }

  function createId(prefix = 'job') {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') window.crypto.getRandomValues(random);
    else { random[0] = Math.floor(Math.random() * 0xffffffff); random[1] = Math.floor(Math.random() * 0xffffffff); }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function stableJobId(raw, prefix = 'job') {
    return text(raw && raw.jobId, text(raw && raw.sourceJobId, text(raw && raw.id))) || createId(prefix);
  }

  function deriveMaterial(jobTypeId, fromPlaceId, destinationPlaceId) {
    const type = findJobTypeById(jobTypeId);
    if (!type) return { code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' };
    const destination = findPlaceById(destinationPlaceId);
    const conditional = conditionalRules.find((rule) => text(rule.jobTypeId) === text(jobTypeId)
      && (!text(rule.fromPlaceId) || text(rule.fromPlaceId) === text(fromPlaceId))
      && (!text(rule.destinationPlaceId) || text(rule.destinationPlaceId) === text(destinationPlaceId)));
    if (conditional) {
      const fallbackFacility = findPlaceById(conditional.facilityPlaceId);
      return {
        code: text(conditional.materialCode),
        facilityPlaceId: destination ? destination.id : text(conditional.facilityPlaceId),
        facilityPlaceName: destination ? destination.name : text(fallbackFacility && fallbackFacility.name),
        ruleId: text(conditional.id)
      };
    }
    if (text(type.materialRule) === 'none' || text(type.materialRule) === 'not-material-transport') {
      return { code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' };
    }
    const facility = destination || findPlaceById(type.defaultDestinationPlaceId);
    return {
      code: text(type.materialCode),
      facilityPlaceId: facility ? facility.id : '',
      facilityPlaceName: facility ? facility.name : '',
      ruleId: (facility || text(type.materialCode)) ? `MR-${text(type.id)}` : ''
    };
  }

  function suggestedDestination(jobTypeId, fromPlaceId) {
    const type = findJobTypeById(jobTypeId);
    if (!type) return '';
    const conditional = conditionalRules.find((rule) => text(rule.jobTypeId) === text(jobTypeId)
      && text(rule.fromPlaceId) && text(rule.fromPlaceId) === text(fromPlaceId));
    return conditional ? text(conditional.facilityPlaceId) : text(type.defaultDestinationPlaceId);
  }

  function normalizeJobRecord(raw, context = 'job') {
    const source = isPlainObject(raw) ? raw : {};
    const legacyJobTypeName = text(source.jobTypeName, text(source.jobType, text(source.displayType)));
    const jobType = findJobTypeById(source.jobTypeId) || findJobTypeByName(legacyJobTypeName);
    const legacyFromName = text(source.fromPlaceName, text(source.from, text(source.placeLabel)));
    const legacyDestinationName = text(source.destinationPlaceName, text(source.destination, text(source.destLabel)));
    const legacyReturnName = text(source.returnPlaceName, text(source.returnPlace, text(source.returnDestination)));
    const fromPlace = findPlaceById(source.fromPlaceId) || findPlaceByName(legacyFromName);
    const destinationPlace = findPlaceById(source.destinationPlaceId) || findPlaceByName(legacyDestinationName);
    const returnPlace = findPlaceById(source.returnPlaceId) || findPlaceByName(legacyReturnName);
    const otherActivity = isOtherActivityJobType(jobType);
    const returnRequired = !otherActivity && (source.returnRequired === true || source.returnRequiredAtStart === true || Boolean(returnPlace));
    const jobId = stableJobId(source, context);
    const derived = deriveMaterial(jobType ? jobType.id : '', fromPlace ? fromPlace.id : '', destinationPlace ? destinationPlace.id : '');
    const material = otherActivity ? { code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' } : (isPlainObject(source.material) ? { ...derived, ...source.material } : derived);
    const metadata = isPlainObject(source.metadata) ? source.metadata : {};
    const fromName = fromPlace ? fromPlace.name : legacyFromName;
    const destinationName = destinationPlace ? destinationPlace.name : legacyDestinationName;
    return {
      ...source,
      schemaVersion: Math.max(Number(source.schemaVersion) || 1, 2),
      jobModelVersion: JOB_MODEL_VERSION,
      jobId,
      id: text(source.id, jobId),
      jobTypeId: jobType ? jobType.id : text(source.jobTypeId),
      jobTypeName: jobType ? jobType.name : legacyJobTypeName || 'Uppdrag',
      jobType: jobType ? jobType.name : legacyJobTypeName || 'Uppdrag',
      fromPlaceId: fromPlace ? fromPlace.id : text(source.fromPlaceId),
      fromPlaceName: fromName || (otherActivity ? '' : 'Från saknas'),
      from: fromName || (otherActivity ? '' : 'Från saknas'),
      destinationPlaceId: destinationPlace ? destinationPlace.id : text(source.destinationPlaceId),
      destinationPlaceName: destinationName || (otherActivity ? '' : 'Till saknas'),
      destination: destinationName || (otherActivity ? '' : 'Till saknas'),
      returnPlaceId: returnPlace ? returnPlace.id : text(source.returnPlaceId),
      returnPlaceName: returnPlace ? returnPlace.name : legacyReturnName,
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : (source.multiLoad === true || source.flerlass === true),
      note: text(source.note, text(source.comment)),
      material,
      ...(otherActivity ? {
        phase: 'other_activity',
        activityKind: 'other-activity',
        timeReportingScope: 'user',
        vehicleUsage: 'optional-tool',
        gpsEnabled: false,
        excludeFromEstimateLearning: true,
        learningExcludedReason: 'Övrig verksamhet är användartid och ska inte ingå i transportinlärning',
        pauseMode: text(source.pauseMode, text(source.status) === 'paused' ? 'manual' : ''),
        autoResumeEligible: source.autoResumeEligible === true && text(source.pauseMode) === 'automatic'
      } : {}),
      metadata: {
        ...metadata,
        modelVersion: JOB_MODEL_VERSION,
        migratedFromSchemaVersion: Number(source.jobModelVersion) === JOB_MODEL_VERSION ? Number(metadata.migratedFromSchemaVersion) || 0 : Number(source.schemaVersion) || 1,
        lastUpdatedByPackageVersion: PACKAGE_VERSION
      }
    };
  }

  const api = {
    JOB_MODEL_VERSION,
    PACKAGE_VERSION,
    jobTypeItems,
    conditionalRules,
    isPlainObject,
    text,
    initializePlaces,
    getPlaceItems,
    validateRegistries,
    findJobTypeById,
    findJobTypeByName,
    isOtherActivityJobType,
    findPlaceById,
    findPlaceByName,
    deriveMaterial,
    suggestedDestination,
    stableJobId,
    normalizeJobRecord
  };
  Object.defineProperty(api, 'placeItems', { enumerable: true, get: () => placeItems });
  window.StadslassJobModel = Object.freeze(api);
})();
