#!/usr/bin/env python3
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_BASE_SHA256 = '4bbaf01ca895ef0fe19e783ee7470c489fb95d8462fa31c91da659aa010d80f0'


def load_json(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))


def require(condition, message):
    if not condition:
        raise AssertionError(message)

module = load_json('module.json')
functions = load_json('data/functions.json')
schema = load_json('data/job-schema.json')
versions = load_json('data/version-history.json')
html = (ROOT / 'index.html').read_text(encoding='utf-8')
app = (ROOT / 'js/app.js').read_text(encoding='utf-8')
ata = (ROOT / 'js/ata/ata-service.js').read_text(encoding='utf-8')
billing = (ROOT / 'js/ata/billing-service.js').read_text(encoding='utf-8')
watchdog = (ROOT / 'js/watchdog.js').read_text(encoding='utf-8')
job_model = (ROOT / 'js/job-model.js').read_text(encoding='utf-8')
quick_choices = (ROOT / 'js/quick-choice-registry.js').read_text(encoding='utf-8')

require(module['packageVersion'] == 58, 'module.json packageVersion must be 58')
require(module['minHostVersionCode'] == 8, 'host minimum must remain 8')
require(functions['currentPackageVersion'] == 58, 'functions current package must be 58')
require(versions['currentPackageVersion'] == 58, 'version history current package must be 58')
require(versions['entries'][0]['packageVersion'] == 58, 'version 58 must be first')
require(versions['entries'][0].get('basePackageSha256') == EXPECTED_BASE_SHA256, 'v57 base SHA must be recorded')

for name, source in {
    'app.js': app,
    'ata-service.js': ata,
    'billing-service.js': billing,
    'watchdog.js': watchdog,
    'job-model.js': job_model,
    'quick-choice-registry.js': quick_choices,
}.items():
    require(re.search(r'(?:PACKAGE_VERSION\s*=|packageVersion\s*:)\s*58', source) is not None,
            f'{name} must expose runtime version 58')

required_function_ids = {
    'ATA-BILLING-MODULE-056',
    'ATA-BILLING-COMPLETION-DIALOG-056',
    'ATA-BILLING-TOTAL-056',
    'ATA-BILLING-PHASES-056',
    'ATA-BILLING-MANUAL-056',
    'ATA-BILLING-HISTORY-DISPLAY-056',
    'ATA-BILLING-HISTORY-EDIT-056',
    'ATA-BILLING-TRASH-PERSISTENCE-056',
    'RUNTIME-PACKAGE-VERSION-056',
    'ATA-NOTIFICATION-SETTINGS-057',
    'ATA-NOTIFICATION-CONTACT-IDENTITY-057',
    'ATA-NOTIFICATION-TEMPLATE-057',
    'ATA-NOTIFICATION-EMAIL-LAYOUT-058',
    'ATA-NOTIFICATION-DUPLICATE-WARNING-058',
    'ATA-NOTIFICATION-CONTACTS-NO-ACTIVE-058',
    'RUNTIME-PACKAGE-VERSION-058',
}
ids = {item.get('id') for item in functions.get('functions', [])}
require(required_function_ids <= ids, 'required package 56-58 functions must be registered')

billing_schema = schema.get('ata', {}).get('fields', {}).get('billing', {})
require(billing_schema.get('schemaVersion') == '1', 'billing schema must be registered inside ATA')
require(schema.get('ata', {}).get('billableTime', {}).get('separateFromWorkTime') is True,
        'billing must remain separate from work time')

require('js/ata/billing-service.js' in html, 'billing service script missing')
require('js/ata/notification-settings-service.js' in html, 'notification settings service script missing')
require(html.index('js/ata/billing-service.js') < html.index('js/ata/ata-service.js'),
        'billing service must load before ATA normalization')
for element_id in [
    'ata-billing-dialog', 'ata-billing-manual-minutes', 'ata-billing-save-manual',
    'ata-billing-use-phases', 'ata-billing-use-total', 'ata-billing-cancel',
    'ata-billing-round-step', 'ata-billing-round-actions',
]:
    require(f'id="{element_id}"' in html, f'missing UI element {element_id}')

# Package 55 fixes must remain in the source.
require('settings-history-panel' in app and 'settings-trash-panel' in app, 'current settings panels must remain used')
require("byId('view-trash').hidden" not in app and "byId('view-statistics').hidden" not in app,
        'obsolete unsafe view accesses must not return')
require('runtimeDisposed' in app and 'runtimeFailed' in app, 'runtime disposal guards must remain')
require("if (!status) return;" in app or "if (!statusElement) return;" in app or "if (!element) return;" in app,
        'periodic DOM writes must retain null guards')

# No parallel store was introduced for billable time.
store_constants = set(re.findall(r"const\s+[A-Z_]+_STORE\s*=\s*'([^']+)'", app))
require(store_constants == {'settings', 'queue', 'activeJob', 'history', 'syncOutbox'},
        f'unexpected store introduced: {sorted(store_constants)}')
require('readStore' not in billing and 'writeStore' not in billing, 'billing service must not own storage')
require('billableMinutesV' not in app + ata + billing, 'legacy 2.0 version-bound billing key must not be copied')
notification = (ROOT / 'js/ata/notification-settings-service.js').read_text(encoding='utf-8')
require("SETTINGS_KEY = 'ataNotificationSettingsV1'" in notification, 'notification settings must use the shared settings document key')
require('sync-protocol.js' not in notification, 'notification settings must not implement current sync')
require('data-settings-function="ata-notification"' in html, 'ÄTA avisering must use common settings navigation')
require('data-settings-group-owner="common-actions"' in html, 'ÄTA avisering must live under common actions')
require('Fritt avslutstext' in html and 'Återställ standardmall' in html, 'mail template UI must be present')
require('Gmail' not in notification and 'mailto:' not in app, 'no mail integration may be introduced')


css = (ROOT / 'css/app.css').read_text(encoding='utf-8')
require('input[type="email"]' in css and 'box-sizing: border-box' in css,
        'email inputs must use the shared full-width 3.0 field layout')
require('ata-notification-contact-active' not in html, 'active recipient checkbox must be removed')
require('Aktiv mottagare' not in html and 'Inaktiva mottagare' not in html,
        'active/inactive recipient help UI must be removed')
require('data-ata-notification-toggle' not in app and 'setContactActive' not in notification,
        'active/inactive contact behavior must be removed')
require("actions.append(edit, remove)" in app, 'contact cards must contain only edit and remove actions')
require("'ata-notification-contact-status'" in app and 'insertAdjacentElement' in app,
        'duplicate warning must be placed visibly beside the contact form')

# Completion behavior contract.
require('parseCompletionManual' in billing and 'MINIMUM_MINUTES = 30' in billing,
        'manual completion minimum must be 30 minutes')
require('Math.ceil(source / MINIMUM_MINUTES)' in billing, 'total time must round upward')
require("new Set(['loading', 'transport', 'unloading'])" in billing,
        'phase basis must include loading, transport and unloading')
for excluded in ['start_route', 'return_unloading', 'ready_to_complete']:
    require(excluded not in re.search(r"const INCLUDED_PHASES = .*", billing).group(0),
            f'{excluded} must not be a base included phase')
require("completionCandidateAt = text(activeJobDocument.completedAt, completionCandidateAt || new Date().toISOString());" in app,
        'fixed completion candidate must be recorded')
require(app.index('if (policy.mode === \'required\'') < app.index("completionCandidateAt = text(activeJobDocument.completedAt, completionCandidateAt || new Date().toISOString());"),
        'completion candidate must be set only after required-weight validation')
require('Aktivt jobb och vald debiterbar tid är bevarade' in app,
        'history write failure must preserve active job and billing')

# Manifest must cover the exact finished package payload except module.json itself.
manifest_entries = {entry['path']: entry for entry in module.get('files', [])}
actual_files = {
    str(path.relative_to(ROOT)).replace('\\', '/')
    for path in ROOT.rglob('*')
    if path.is_file() and path.name != 'module.json' and '__pycache__' not in path.parts and path.suffix != '.pyc'
}
require(set(manifest_entries) == actual_files,
        f'manifest file set differs: missing={sorted(actual_files-set(manifest_entries))}, extra={sorted(set(manifest_entries)-actual_files)}')
for relative, entry in manifest_entries.items():
    payload = (ROOT / relative).read_bytes()
    require(entry.get('size') == len(payload), f'manifest size mismatch for {relative}')
    require(entry.get('sha256') == hashlib.sha256(payload).hexdigest(), f'manifest hash mismatch for {relative}')

# CSP remains strict in the shipped HTML.
require("default-src 'none'" in html and "script-src 'self'" in html and "connect-src https://maps.googleapis.com" in html,
        'strict CSP must remain in shipped HTML')

# No secrets or local build paths.
for path in ROOT.rglob('*'):
    if not path.is_file():
        continue
    require(path.suffix.lower() not in {'.pem', '.key', '.p12', '.pfx'}, f'private key-like file included: {path.name}')
    if path.suffix.lower() in {'.js', '.json', '.html', '.css', '.py', '.txt'}:
        text = path.read_text(encoding='utf-8', errors='ignore')
        private_marker = 'BEGIN ' + 'PRIVATE KEY'
        rsa_private_marker = 'BEGIN RSA ' + 'PRIVATE KEY'
        require(private_marker not in text and rsa_private_marker not in text,
                f'private key content included in {path.relative_to(ROOT)}')
        local_marker = '/mnt' + '/data/'
        require(local_marker not in text, f'local build path included in {path.relative_to(ROOT)}')

print(json.dumps({
    'status': 'PASS',
    'packageVersion': 58,
    'minHostVersionCode': 8,
    'registeredFunctions': len(required_function_ids),
    'storeNames': sorted(store_constants),
}, ensure_ascii=False))
