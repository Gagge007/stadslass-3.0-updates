# Praktiska tester – permanent startapp v15

## V14 – originfix och produktionsrensning

1. Installera v14 över v13 utan avinstallation. Kontrollera att roll, installerat paket och befintliga syncinställningar finns kvar.
2. Öppna syncinställningarna och tryck **Spara syncinställningar**. Det får inte visas `origin_denied`.
3. Tryck **Kontrollera anslutning**. Ett eventuellt nät- eller tokenfel är ett separat fel, men inte `origin_denied`.
4. Öppna Teknisk information och kontrollera att testvärdesraden och testknappen inte finns.

Testet är klart när inställningarna går att spara utan `origin_denied` och övriga bevarade uppgifter finns kvar.

## V13 – rapportfil och mailbilaga

1. Installera v13 över v12 och kontrollera att roll och data finns kvar.
2. Spara en liten syncrapport och kontrollera att Android visar en sparplatsdialog och att en riktig `.txt`-fil skapas.
3. Maila samma rapport och kontrollera att Gmail öppnas med filen bifogad, utan att mailet skickas.
4. Avbryt en sparning och kontrollera att syncläsarens logg och vanlig sync är kvar.

## 1. Säker uppdatering

Installera v12 ovanpå v11 utan avinstallation. Kontrollera att roll, enhets-ID, installerat funktionspaket och inställningar finns kvar, att appen når READY och att inga nya syncknappar eller ändrat arbetsflöde visas.

## 2. Senaste speglingsstatus vinner

Kör genom en teknisk testmodul två statusrequest med samma `coalesceKey`. Låt den första få ett återförsöksbart nätfel och köa sedan en nyare status. Kontrollera att den äldre får `superseded` och aldrig publiceras efter den nyare.

## 3. PUT efter timeout

Simulera att GitHub tog emot ett PUT men att svaret timeoutade. Kontrollera att v12 först gör GET-reconcile, känner igen identiskt innehåll och avslutar som `succeeded` utan ett andra PUT.

## 4. Regression

Kontrollera ÄTA-mailutkast, Kopiera underlag, GPS, geokodning, Back, modulstart och Sök efter funktionsuppdatering.

Testmodulen får inte bli permanent produktionsfunktion och får inte använda verklig arbetsdata.
