# Säkerhetsgränser – 3.0-host-15

## V14 – betrodd modulsession för känsliga hostbryggor

- Känsliga hostanrop godtas endast från den aktuella WebView-instansen, samma laddningsgeneration och samma verifierade aktiva modulinstallation efter committed huvudram och READY.
- Den lokala origin valideras med URI-delarna HTTPS, exakt host `stadslass.local` och effektiv port 443. Path, query och fragment gör inte en annars korrekt lokal origin främmande.
- Behörigheten läser inte WebViews aktuella URL vid varje JavaScriptanrop. Ett tillfälligt tomt eller `about:blank` efter etablerad session ändrar därför inte ensamt behörigheten.
- Sessionen återkallas före främmande huvudnavigation, vid lokal omladdning, modulbyte, rollback, WebView-destruktion och renderprocessfel. Gammal generation och tidigare JavaScriptbrygga nekas.
- `origin_denied` finns kvar för verkligt obehöriga anrop. Watchdog registrerar endast säker teknisk orsak och aldrig token, requestbody, arbetsdata eller kommentar.

## V13 – central mailbilaga och textfilexport

- Endast `openEmailDraftWithAttachment` får använda `ACTION_SEND`, och då enbart för högst en lokalt skapad UTF-8 `.txt`-bilaga från den avgränsade FileProvider-mappen.
- Gmail kan väljas först genom sitt kända paket; om det saknas används Androids vanliga mail-/delningsflöde. Stadslass skickar aldrig mailet och läser inga konton.
- `requestTextFileExport` använder `ACTION_CREATE_DOCUMENT`. Användaren väljer själv sparplats och appen begär inga breda lagringsbehörigheter.
- Rapportinnehåll, token och nycklar skrivs inte till Watchdog, SharedPreferences eller hoststores.

## Androididentitet och behörigheter

Paket-ID, namespace, SharedPreferences och permanent APK-signering är oförändrade. Manifestet deklarerar endast `INTERNET`, `ACCESS_COARSE_LOCATION` och `ACCESS_FINE_LOCATION`. Ingen bakgrundsposition, kontakt-, konto-, lagrings- eller mailbehörighet införs.

## Signerade funktionspaket

Endast manifest med `packageType: stadslass-web-module-zip-v1` accepteras. Payload verifieras med SHA-256 och RSA/SHA-256 innan kandidat skapas. Kandidaten måste lämna READY-kvitto före promovering. Current, backup och rollback är bevarade.

Äldre JSON-testpaket stöds inte från v10. Vid första och senare starter får endast filerna `stadslass-function-package.json` och `stadslass-function-package.backup.json` tas bort.

## Avgränsad städning

Städningen får endast ta bort de två exakta äldre JSON-testfilerna. Äldre sparade testvärden lämnas orörda; produktions-UI visar dem inte. `SharedPreferences.clear()` är förbjuden. Roll, enhets-ID, funktionspaketversion, okända framtida nycklar, modulstruktur, Watchdog och alla arbetsdatalager ska bevaras.

## Mailutkast och urklipp

Mailutkast öppnas med Android `ACTION_SENDTO` och `mailto:`. Ingen `ACTION_SEND`, Gmail-paketlåsning, OAuth, SMTP, Gmail API eller automatisk sändning tillåts. `no_mail_app` får endast följa av `ActivityNotFoundException`.

## WebView och nätverk

Modul-WebViewens generella nätverksladdning är blockerad. Endast den lokala signerade moduloriginen och den strikt validerade Google Geocoding-bryggan tillåts. Redirects och otillåtna endpoints blockeras.

## Arbetsdata och Watchdog

`settings`, `queue`, `activeJob`, `history` och `syncOutbox` ligger i separata privata AtomicFile-lager. Watchdog får endast lagra tekniska faser och får aldrig läsa, reparera eller normalisera arbetsdata. Kontrollsidan visar en förenklad användarstatus; den kopierbara rapporten behåller tekniska faser.


## V11 – synccredential och transport

- GitHub-token krypteras med Android Keystore AES/GCM och kan inte läsas tillbaka genom JavaScript.
- Request- och responsebody lagras endast i AES/GCM-krypterade separata poster i `noBackupFilesDir`.
- Endast `api.github.com` och konfigurerad owner/repository/branch används; redirects följs inte med Authorization.
- JavaScript kan inte ange URL, API-bas eller Authorization-header.
- Bryggan är passiv och läser inga modulstores eller arbetsdata.
- `ACCESS_NETWORK_STATE` används endast för kontrollerad återstart när processen är aktiv.

## V12 – ordning och tvetydiga PUT

En äldre coalescad status får inte återförsökas efter en nyare. Alla återförsöksbara PUT verifieras med GET-reconcile före ny skrivning. Ingen arbetsdata tolkas eller sammanfogas.
