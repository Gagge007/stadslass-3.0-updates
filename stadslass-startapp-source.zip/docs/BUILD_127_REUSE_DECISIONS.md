# Bedömning av utvecklingsbygge 127

## Återanvänt som princip eller kontrakt

- Local-first: arbetsdata ska inte vara beroende av nätverk.
- Separation mellan data, arbetslogik, rendering och sync.
- Historik och tunga funktioner ska inte behandlas vid varje arbetsknapp.
- Stabil lokal HTTPS-origin och blockerad extern WebView-åtkomst.
- Ingen läsning av `driftlogg_v4_full` under den isolerade utvecklingsfasen.
- Funktionsregister och kontroller ska följa kodändringen.

## Omskrivet för den permanenta startappen

- Hela Androidbehållaren och startlogiken är ny Java/Gradle-kod baserad på praktiskt godkänd startapp v3.
- Modulinstallation, filverifiering, kandidatprovstart, reservväxling och datalager är nya implementationer.
- WebView-serveringen är en begränsad filinterceptor för signerade installerade moduler, inte bygge 127:s inbäddade distributionspaket.
- Rollvalet är fortsatt lokalt och valbart; bygge 127:s fasta 189-roll används inte.

## Avvisat

- Paket-ID `se.stadslass.development`.
- Utvecklingscertifikatet och PKCS#12-filen från bygge 127.
- Den gamla byggskriptbaserade Androidcontainern och dess smali-/DEX-kedja.
- Inbäddning av hela bygge 127:s 214 JavaScript-moduler i APK:n.
- Syntetiska terminal-, kvitto-, mail-, ETA-, GPS- och synckedjor som verkliga driftfunktioner.
- Direkt återanvändning av jobb-, historik-, export- eller synklogik utan separat granskning.
- Produktionsdata, 2.0-lagring, verklig GPS, mail och verklig sync.

## Watchdog-bedömning för version 5

Återanvänt selektivt från bygge 127 är endast principerna om tydliga uppstartsfaser, stopp vid verkligt startfel och kopierbar diagnostik. Den cirka 677 KiB stora genererade `dist/assets/watchdog.js`, dess syntetiska kontrollkedjor och äldre timeoutbeteende har inte kopierats. V5 använder en liten native värd-Watchdog och paket 8 använder en separat liten runtime-Watchdog. Timeout kvitteras av explicit READY och får inte larma efter lyckad start.
