# Watchdog-kontrakt version 1

## Värdlager

`HostWatchdog` får endast lagra tekniska händelser i `files/stadslass-watchdog/host-watchdog.json`.

Tillåtna typer av uppgifter:

- tidsstämpel
- fasnamn
- allvarlighetsgrad
- begränsad teknisk detalj
- värdversion och paketversion
- kandidatmarkering och fallbackmarkering

Förbjudet:

- innehåll från settings, queue, activeJob, history eller syncOutbox
- automatisk reparation eller migrering av arbetsdata
- privat nyckel, API-nyckel eller repository-secret

## Geokodningsbrygga

Tillåtna värdfaser är generiska: anrop blockerat, redirect blockerat, svar mottaget, för stort svar, ogiltig status eller nätverksfel. Detaljen får endast innehålla fas och numerisk HTTP-status. URL, querystring, API-nyckel, söktext, koordinater och svarskropp är förbjudna.

## Runtime-brygga

- `watchdogStep(phase, detail, severity)` registrerar begränsad diagnostik.
- `getHostWatchdogReport()` returnerar värdens rapport.
- `copyWatchdogReport(runtimeReport)` sammanfogar och kopierar rapport efter användaråtgärd.
- `markReady(packageVersion)` är fortsatt det enda kvittot som kan godkänna kandidatstart.

## Timeout och fallback

Paketets `readyTimeoutMs` styr väntan på READY och ska ligga inom modulkontraktets tillåtna intervall. Timeout ska inte användas för att radera arbetsdata. Current-runtimefel får högst utlösa ett verifierat fallbackförsök per startkedja.

## Kontrollsidans presentation från v10

Den normala kontrollsidan visar endast användarstatusen Redo, Varning, Fel, Reservläge eller Startar samt en begränsad begriplig text. Rå fas och teknisk detalj ska endast finnas i den kopierbara rapporten och i lagrad Watchdog-JSON. En lyckad senare mailöppning ska ersätta en tidigare aktuell mailöppningsvarning i användarpresentationen utan att historiken raderas.


## V11 syncdiagnostik

Watchdog får registrera begränsat request-ID, terminal status, HTTP-status och neutral felkod. Token, Authorization-header, requestbody, responsebody, full path, adress, kommentar eller arbetsobjekt får inte registreras. Skadade krypterade poster isoleras med en generell teknisk varning.

## V12 syncåterförsök

Superseded och reconcile redovisas endast med begränsat request-ID, status, HTTP-kod och felkod. Requestbody, responsebody och token loggas inte.

## V14 betrodd modulsession

Watchdog får registrera att en modulsession skapats, committats, blivit READY eller återkallats samt en begränsad orsak som `wrong_webview_generation`, `main_frame_not_committed`, `module_not_ready` eller `session_revoked`. Rapporten får inte innehålla WebView-URL, query, fragment, token, Authorization-header, requestbody, syncdata eller arbetskommentar.
