# Säker egen uppdatering – API version 1

Startapp v16 kontrollerar `startapp-latest.json` endast vid appstart och efter ett uttryckligt tryck i Inställningar → Enhet & utseende.

Manifestet använder schema version 1 och de kritiska fälten `packageType`, `packageId`, `versionCode`, `versionName`, `apkUrl`, `apkSha256`, `apkSizeBytes`, `signingCertificateSha256`, `minimumUpdaterVersionCode`, `required` och `publishedAt`. `required: true` betyder att en högre startappversion måste installeras före ny normal användning.

- `activeJob` läses endast som ett smalt ja/nej-kontrakt. `active`, `paused`, `completing` eller läsfel skjuter upp all automatisk kontroll utan UI.
- En känd ny obligatorisk startapp blockerar ny normal användning men kan aldrig avbryta ett pågående arbete.
- APK hämtas endast från låst HTTPS-sökväg i det publika uppdateringsrepositoryt.
- Storlek, SHA-256, paket-ID, versionskod, versionsnamn och samma APK-certifikat som installerad Stadslass verifieras före installation.
- Androids installationsruta måste godkännas av användaren.
- Ingen bakgrundstjänst, boot receiver eller periodisk kontroll används.
