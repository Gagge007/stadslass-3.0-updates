# Kontrakt för modulens datalager

| API-namn | Privat fil | Standardvärde | Maxstorlek |
|---|---|---:|---:|
| `settings` | `settings.json` | `{}` | 256 KiB |
| `queue` | `queue.json` | `[]` | 1 MiB |
| `activeJob` | `active-job.json` | `{}` | 1 MiB |
| `history` | `history.json` | `[]` | 8 MiB |
| `syncOutbox` | `sync-outbox.json` | `[]` | 2 MiB |

Varje skrivning måste vara ett giltigt JSON-objekt eller en JSON-lista och genomförs med `AtomicFile`. Ett lager läses bara genom ett explicit anrop från den signerade modulen. Det finns ingen automatisk samladdning av historik och aktiv driftdata.

## Watchdog är inte ett arbetsdatalager

`files/stadslass-watchdog/host-watchdog.json` är separat teknisk diagnostik. Den ingår inte i de fem modul-API-lagren och får inte innehålla deras dokumentinnehåll eller användas för att reparera dem.
