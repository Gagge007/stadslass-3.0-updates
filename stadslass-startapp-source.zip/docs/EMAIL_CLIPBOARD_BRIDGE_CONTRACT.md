# Mail- och urklippsbrygga – host API version 1

## openEmailDraft(recipient, subject, body)

Metodsignaturen och API-versionen är oförändrade. V11 bygger en `ACTION_SENDTO`-intent med en UTF-8-procentkodad `mailto:`-URI:

- mottagare i mailto-delen
- `subject` som queryparameter
- `body` som queryparameter

`Intent.EXTRA_SUBJECT` och `Intent.EXTRA_TEXT` används inte som ensam sanning. `resolveActivity` används inte. Ingen Gmail-låsning, OAuth, SMTP, automatisk sändning eller `ACTION_SEND` finns.

Status:

- `opened`: Android accepterade öppningen
- `no_mail_app`: endast faktisk `ActivityNotFoundException`
- `invalid_request`: ogiltiga eller för stora värden
- `host_error`: annat tekniskt fel

Startappen kan inte se om användaren skickar mailet.

## copyText(label, text)

Kopierar ren text till Androids urklipp med befintliga storleksgränser. Ingen mail- eller urklippstext loggas i Watchdog.
