# Mailbilaga – host API version 2

`openEmailDraftWithAttachment(requestJson)` tar ett validerat mailunderlag med schemaVersion 1, mottagare, ämne, brödtext och noll eller en `.txt`-bilaga med MIME `text/plain`.

Endast den centrala hostbryggan kan skapa Android-intent. Med bilaga används begränsad `ACTION_SEND`, temporär FileProvider-URI och läsrättighet. Gmail provas först när det är begärt; annars används Androids reservflöde. Utkastet skickas aldrig automatiskt.

Tillåtna resultat är `opened_gmail`, `opened_mail_app`, `invalid_request`, `attachment_error`, `no_mail_app` och `host_error`. Resultatet innehåller aldrig innehåll, token eller hemligheter.
