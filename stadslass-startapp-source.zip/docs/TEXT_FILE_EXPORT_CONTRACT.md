# Textfilexport – host API version 1

`requestTextFileExport(requestJson)` validerar en UTF-8 `.txt`-fil och öppnar Androids `ACTION_CREATE_DOCUMENT`. Användaren väljer sparplats och inga breda lagringsbehörigheter används.

Endast en textsparning kan vara aktiv åt gången. Ett nytt sparförsök medan en tidigare sparruta väntar eller dess resultat ännu inte är kvitterat nekas med status `export_in_progress`. Detta krävs eftersom Androids återanrop för dokumentval saknar `requestId`.

Status kan hämtas med `getTextFileExportStatus(requestId)` och terminalt resultat kvitteras med `acknowledgeTextFileExportResult(requestId)`. Eventet `stadslass:text-export-result` innehåller endast requestId och status: `saved`, `cancelled` eller `write_error`.
