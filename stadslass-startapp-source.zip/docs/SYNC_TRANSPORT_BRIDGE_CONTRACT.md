# StadslassHost sync transport bridge – API version 1

## Arkitekturgräns

Startappen transporterar ogenomskinlig text och teknisk metadata. Den läser eller skriver inte `settings`, `queue`, `activeJob`, `history`, `syncOutbox` eller `driftlogg_v4_full`. Funktionspaketet äger arbetsbetydelse, lokala sanningsregler, UI och konfliktbeslut.

## API-versioner

`getHostInfo()` redovisar:

- `syncTransportApiVersion: 1`
- `deviceIdentityApiVersion: 1`
- `syncCredentialApiVersion: 1`

## Hostmetoder

- `getDeviceIdentity()`
- `setSyncConfiguration(configJson)`
- `getSyncConfigurationStatus()`
- `clearSyncConfiguration()`
- `enqueueSyncRequest(requestJson)`
- `getSyncRequestStatus(requestId)`
- `listPendingSyncRequests()`
- `retryPendingSyncRequests()`
- `acknowledgeSyncResult(requestId)`

Metoderna är endast avsedda för den låsta lokala HTTPS-originen `https://stadslass.local` i den aktuella verifierade modulsessionen. Path, query och fragment avgör inte origin. Samma WebView-generation måste ha verifierad modulinstallation, committed huvudram och READY; främmande navigation, modulbyte, rollback och renderprocessfel återkallar behörigheten.

## Konfiguration

`setSyncConfiguration` accepterar exakt `owner`, `repository`, `branch` och `token`. Token krypteras med Android Keystore AES/GCM och returneras aldrig till JavaScript. Status visar endast icke-hemliga repositoryvärden. Syncdata ligger i `noBackupFilesDir` och Androidbackup är avstängd.

## Requestschema

Ett request innehåller `requestId`, `operation`, `path`, `priority`, `channel`, `createdAt`, `body`, `expectedSha` och valfri `coalesceKey`.

- operation: `GET` eller `PUT`
- priority: `fast_lane`, `active_work`, `shared_queue`, `on_demand`
- body: ogenomskinlig UTF-8-text, högst 1 MiB
- path: relativ repositorypath, högst 512 tecken
- max 200 väntande poster och 8 MiB sammanlagd body
- svar: högst 2 MiB

För PUT skapar värden GitHub Contents API-payload med base64-kodad body, konfigurerad branch, generiskt commitmeddelande med request-ID och `expectedSha` när det finns. För GET returneras avkodad filtext och GitHub-SHA.

## Prioritet och coalescing

Nästa request väljs i ordningen `fast_lane`, `active_work`, `shared_queue`, `on_demand`, därefter stabil köordning. `fast_lane` är reserverad för små kritiska transportmeddelanden, exempelvis work lease och närvaro/handskakning. Endast ett anrop körs samtidigt per enhet. Samma icke-tomma `coalesceKey` ersätter äldre väntande poster med status `pending` eller `failed_retryable`. En redan `running` post avbryts inte, men får terminalstatus `superseded` i stället för nytt återförsök om en nyare post med samma nyckel redan väntar. Den äldre posten får aldrig publiceras efter den nyare.

## Beständighet och deduplicering

Varje request, resultat och deduppost lagras i separat AES/GCM-krypterad fil. En skadad post isoleras utan att hela kön raderas. Samma request-ID accepteras inte igen medan det finns i pending, result eller den begränsade dedupliceringsjournalen. Journalen har högst 500 poster och 30 dagars retention.

Varje PUT med ett återförsöksbart eller tvetydigt resultat reconcileras genom säker GET före retry, inklusive timeout, nätfel, återförsöksbara HTTP-svar och processavbrott. Om remoteinnehållet redan motsvarar den ogenomskinliga bodytexten redovisas success; vid ändrad SHA redovisas conflict. Startappen slår aldrig ihop JSON eller skriver över konflikt automatiskt.

## Statusar

Mottagning: `accepted`, `duplicate`, `invalid_request`, `configuration_missing`, `queue_full`, `host_error`.

Request/resultat: `pending`, `running`, `succeeded`, `failed_retryable`, `failed_permanent`, `conflict`, `superseded`, `unknown`.

## Event

Terminalt resultat signaleras med DOM-eventet `stadslass:sync-result`. Eventdetail innehåller endast request-ID och status. Fullt resultat hämtas med `getSyncRequestStatus`, så missade event kan återhämtas efter WebView- eller appomstart.

## Återförsök

Kontrollerad exponentiell backoff börjar på 5 sekunder och begränsas till 15 minuter. Retry sker när processen startar, appen återgår, nät blir tillgängligt eller funktionspaketet uttryckligen begär retry. Ingen foreground service, boot receiver, WorkManager-loop eller bakgrundsbehörighet används.

## Diagnostik

Watchdog får endast request-ID i begränsad teknisk form, status, HTTP-kod och felkod. Token, requestbody, responsebody, adresser, kommentarer och arbetsobjekt loggas inte.
