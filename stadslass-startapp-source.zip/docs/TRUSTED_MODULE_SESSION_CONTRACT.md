# Betrodd modulsession – kontrakt version 2

Startappens betrodda modulsession har två uttryckliga behörighetsnivåer.

## Bootstrapnivå

Efter att det signerade funktionspaketet har verifierats, rätt WebView och laddningsgeneration har bundits och huvudramen har committat exakt den lokala HTTPS-originen får modulen läsa och skriva de fem befintliga hoststores som krävs för bootstrap och migrering. READY krävs inte för dessa två metoder.

Tillåtna bootstrapmetoder:

- `readStore`
- `writeStore`

Bootstrapnivån är fortsatt bunden till aktuell WebView, generation, moduleId, packageVersion och installerad modulidentitet. Främmande origin, stale generation, modulbyte och återkallad session nekas.

## Full READY-nivå

Efter ett giltigt READY-kvitto för samma verifierade generation får övriga känsliga hostfunktioner användas, bland annat sync credentials, synctransport, mailbilaga, textfilexport och urklipp.

## Säkerhetsgräns

Endast HTTPS med exakt host `stadslass.local` och effektiv port 443 är tillåten. URI:n parsas i delar. Path, query och fragment kan variera. `http`, `file`, `content`, `data`, annan port, användarnamn i URI:n, subdomän, lookalike och trailing dot nekas.

Ny huvudnavigation, modulbyte, rollback, WebView-destruktion, renderprocessfel eller ny generation återkallar båda behörighetsnivåerna omedelbart.

## Bakåtkompatibilitet

Inget JavaScript-anropsformat och ingen befintlig API-version ändras. Funktionspaket 65 kan läsa settings under bootstrap och lämna READY utan att sync-, mail- eller exportfunktionerna öppnas i förtid.
