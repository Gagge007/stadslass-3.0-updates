# Startapp v18 – prioriterad transport

Startapp v18 bygger på v17 och behåller samma paket-ID, signering, SharedPreferences,
modulmotor, lagringsgränser och GitHub-transport. Den enda funktionsändringen är den
nya prioriteten `fast_lane`. Den ligger före `active_work`, `shared_queue` och
`on_demand`, men värden kör fortfarande högst ett transportanrop åt gången per enhet.
`fast_lane` är reserverad för små kritiska meddelanden som work lease och
närvaro/handskakning; startappen tolkar aldrig deras innehåll.

# Startapp v17 – riktad rapportfix

- Tillåter endast en pågående Android-textsparning åt gången.
- Binder sparresultatet till den enda aktiva exporten i stället för till första elementet i en väntande lista.
- Hindrar att en synkrapport kan sparas med innehållet från en tidigare prestandarapport.
- Bevarar paket-ID, permanent APK-signering, arbetsdata, roll, sync, modulinstallation och egen uppdatering.

# Startapp v15 – riktad bootstrapfix

- Rättar cirkelberoendet där `readStore` och `writeStore` nekades med `module_not_ready` innan funktionspaketet kunde lämna READY.
- Inför separat bootstrapbehörighet efter verifierad modul, committed lokal origin och rätt WebView-generation.
- Behåller full READY-spärr för sync credentials, synctransport, mail, bilagor, textfilexport och urklipp.
- Bevarar origin-, generations-, modul- och återkallningsskyddet från v14.
- Funktionspaket 65 och alla lagrade data används oförändrade.

# Changelog

## 3.0-host-14 – 2026-08-02

- Rättar den felaktiga `origin_denied`-spärren för den verifierade och READY-markerade aktiva funktionsmodulen.
- Ersätter URL-ögonblicksbilden som enda behörighetsgrund med en native-hanterad betrodd modulsession: rätt WebView, generation, verifierad modulinstallation, committed lokal origin och READY måste samtidigt stämma.
- Behåller `origin_denied` för främmande origin, fel port, lookalike, gammal generation, modulbyte, rollback, renderprocessfel och återkallad session.
- Låter den betrodda sessionen behålla sin etablerade behörighet vid tillfälligt tomt eller `about:blank` från WebView, utan att tillåta ny navigation eller gammal JavaScriptreferens.
- Lägger samma behörighetsgrind framför hoststores, sync, synccredential, mailbilaga, textfilexport och urklipp utan ändrade API-format eller synctransportlogik.
- Bevarar gamla sparade testvärden om de finns kvar sedan tidigare, men visar inte testvärde eller testknapp i produktionsgränssnittet.

## 3.0-host-13 – 2026-08-02

- Höjer `versionCode` till 13 och behåller paket-ID, SharedPreferences, modulinstallation och permanent APK-signering.
- Lägger till den centrala bryggan `openEmailDraftWithAttachment` för ett mailutkast med högst en UTF-8-textbilaga. Gmail provas först och Androids mailflöde är reserv; inget mail skickas automatiskt.
- Lägger till begränsad FileProvider-delning från endast `cache/stadslass-reports/` och Androids `ACTION_CREATE_DOCUMENT` för användarvald textsparning.
- Behåller `openEmailDraft`, geolocation, geokodning, clipboard och v12:s synctransport oförändrade i funktion och prioritet.

## 3.0-host-12 – 2026-08-02

- Säkerställer att en nyare request med samma `coalesceKey` ersätter äldre `pending` och `failed_retryable` statusposter.
- Hindrar en äldre running-status från att återgå till återförsök när en nyare status redan väntar.
- Normaliserar kvarvarande coalescade v11-poster vid start så endast den senaste väntande statusen bevaras.
- Markerar varje återförsöksbart PUT för GET-baserad reconcile före ett nytt PUT.
- Behåller syncTransport API version 1, paket-ID, permanent signering, rollfördelning och den passiva arbetsdatagränsen.

## 3.0-host-11 – 2026-08-02

- Rättar `openEmailDraft` så mottagare, ämne och brödtext ligger i UTF-8-kodad `mailto:`-URI.
- Behåller `ACTION_SENDTO`, direkt `startActivity` och `ActivityNotFoundException` som enda `no_mail_app`-sanning.
- Lägger till passiv `syncTransportApiVersion: 1`, `deviceIdentityApiVersion: 1` och `syncCredentialApiVersion: 1`.
- Lägger till neutral installationsidentitet som överlever APK-uppdatering.
- Lägger till Keystore-skyddad GitHub-konfiguration utan tokenåterläsning.
- Lägger till krypterad beständig prioriterad request-/resultatkö, coalescing, deduplicering, återförsök, konfliktstatus och WebView-event.
- Lägger till `ACCESS_NETWORK_STATE` för nätåterkomst medan processen är aktiv; ingen bakgrundstjänst eller bakgrundsposition.
- Aktiverar ingen arbetsdatasync och ändrar inte nuvarande funktionspakets arbetsflöde.

# Ändringshistorik

## 3.0-host-10

- Höjer `versionCode` till 10 och `versionName` till `3.0-host-10` utan att ändra paket-ID, SharedPreferences eller permanent signering.
- Rättar falskt `no_mail_app` genom att ta bort `resolveActivity()`-förkontrollen och försöka öppna `ACTION_SENDTO` direkt.
- Returnerar `no_mail_app` endast vid verklig `ActivityNotFoundException`; andra fel ger `host_error`.
- Behåller exakt samma publika mail- och urklippskontrakt som v9.
- Tar bort de synliga produktions-testvärdena och deras händelsekod.
- Tar bort stöd för äldre signerade JSON-testpaket och kräver explicit ZIP-pakettyp i `latest.json`.
- Rensar endast de två gamla testnycklarna och de två exakta legacy-JSON-filerna, utan `SharedPreferences.clear()` och utan påverkan på roll, enhets-ID, modul eller arbetsdata.
- Förenklar kontrollsidans Watchdog-presentation till användarstatus och begriplig feltext medan den kopierbara rapporten behåller tekniska faser.
- Tar bort den långa tekniska informationsrutan och gamla versionsreferenser från produktionsgränssnittet.

## 3.0-host-7

- Höjer versionCode från 6 till 7 och versionName från `3.0-host-6` till `3.0-host-7` för permanent signerad uppdatering över v6.
- Inför en begränsad Android-nätverksbrygga i `WebViewClient.shouldInterceptRequest` för exakt Google Geocoding-endpoint.
- Behåller `setBlockNetworkLoads(true)` och blockerar fortsatt alla andra externa nätverksanrop från funktionsmodulen.
- Tillåter endast HTTPS, GET, standardport, exakt sökväg samt parametrarna `address`, `key`, `language=sv` och `region=se` med fasta format- och storleksgränser.
- Följer inte redirects, använder inte cache, begränsar svar till 1 MiB och återlämnar endast ett maskerat svar till `https://stadslass.local`.
- Lagrar eller rapporterar aldrig API-nyckel, söktext, koordinater, full URL eller svarskropp i Android-lagret eller Watchdog.
- Lägger inte till någon ny JavaScript-interface, ny Google API-nyckel, nytt Google-projekt, nya API:er, Routes, ETA, reverse geocoding, geofence, kartvisning eller fasstyrning.
- Behåller GPS-tjänstens gemensamma positionssanning och samtliga v6-gränser för geolocation, modulverifiering, reservstart, datalager och offline-start.

## 3.0-host-6

- Höjer versionCode från 5 till 6 och versionName från `3.0-host-5` till `3.0-host-6` för permanent signerad uppdatering över v5.
- Deklarerar Android-behörigheterna `ACCESS_COARSE_LOCATION` och `ACCESS_FINE_LOCATION`.
- Aktiverar WebView-geolocation med `WebChromeClient.onGeolocationPermissionsShowPrompt`.
- Begär platsbehörighet först när den aktiva signerade modulen faktiskt använder webbläsarens geolocation.
- Kontrollerar aktuell Android-behörighet omedelbart innan varje WebView-svar.
- Hanterar ungefärlig, exakt, nekad, permanent nekad och återkallad platsbehörighet samt återgång från Android-inställningar, bakgrund och appomstart.
- Begränsar geolocation till den låsta lokala HTTPS-originen och sparar aldrig ett bestående WebView-tillstånd för geolocation.
- Lägger inte till bakgrundsposition, `ACCESS_BACKGROUND_LOCATION`, Google, Routes, koordinathämtning, geofence, GPS-styrning eller automatisk fasväxling.
- Behåller paket-ID, signeringssecrets, uppdateringsmodell, SHA-256/RSA, READY-kvitto, Watchdog, reservpaket, atomisk lagring, datalager, roller, enhets-ID och offline-start.

## 3.0-host-5 – källkorrigering 2

- Korrigerar GitHub `lintRelease`-stoppet där `RenderProcessGoneDetail.didCrash()` anropades utan API 26-skydd trots `minSdk 24`.
- Behåller `minSdk 24`, paket-ID, versionCode 5, versionName, SharedPreferences och permanent APK-signering oförändrade.
- Lägger till en källkontroll som stoppar framtida återinförande av samma API-kompatibilitetsfel.
- Ändrar inte Watchdogens datagränser, reservstart, modulformat eller arbetsdatalager.

## 3.0-host-5

- Behöll i v5 exakt paket-ID, SharedPreferences, roll, enhets-ID och dåvarande lokala testvärden från praktiskt godkänd v4. Testvärdena avvecklas först i v10.
- Inför en separat atomisk värd-Watchdog för start-, uppdaterings- och modulstartsfaser.
- Övervakar WebView-huvudfel, renderprocessbortfall och uteblivet READY-kvitto.
- Inför automatisk verifierad reservstart för ett redan installerat paket som inte kan starta.
- Begränsar reservförsöket till ett per runtime-startkedja för att förhindra loop.
- Inför kopierbar sammanfogad värd- och runtime-Watchdog-rapport.
- Utökar JavaScript-bryggan med versionsstyrt Watchdog-API utan ny arbetsdataåtkomst.
- Watchdog får inte läsa, radera, normalisera eller reparera arbetsdatalager.
- Behåller v4:s signatur-, ZIP-, WebView-, offline- och datalagerskydd.

## 3.0-host-4

- Korrigerade bakåtnavigeringen genom AndroidX `OnBackPressedDispatcher`.
- Införde signerade ZIP-moduler, filvis hashkontroll, kandidatprovstart, reservpaket, offline-start och fem separata datalager.

## 3.0-host-9

- Lägger till versionsstyrd `openEmailDraft` via Android `ACTION_SENDTO` och `mailto:`.
- Lägger till versionsstyrd `copyText` för klartext till Androids urklipp.
- Ingen Gmail-låsning, OAuth, automatisk mailsändning eller ny Android-behörighet.
- Bevarar v8:s geokodning, GPS, lagring, paketverifiering och Watchdog.
