# Kontrakt för signerade modulpaket

Manifestet `latest.json` använder schema 1 och måste innehålla:

- `packageType`: `stadslass-web-module-zip-v1`
- `packageVersion`
- `minHostVersionCode`
- `payloadUrl`
- `payloadSha256`
- `payloadSignature`

ZIP-paketet innehåller `module.json` samt deklarerade runtimefiler. `module.json` använder:

- `schemaVersion`: 1
- `packageType`: `stadslass-web-module`
- `packageVersion`
- `minHostVersionCode`
- `moduleId`
- `title`
- `entryPoint`
- `readyTimeoutMs`
- `files`: sökväg, SHA-256, MIME-typ och storlek för varje runtimefil

Aktivering sker i två faser:

1. Hämta, verifiera, packa upp och filvalidera till kandidat.
2. Starta kandidaten och invänta `StadslassHost.markReady(packageVersion)` innan katalogerna växlas.

Den privata funktionsuppdateringsnyckeln används endast utanför repositoryt för att signera ZIP-filen. Appen och repositoryn innehåller endast den offentliga nyckeln.

## Watchdog-krav från värdversion 5

Funktionspaket som kräver `minHostVersionCode: 5` kan använda Watchdog-API version 1. Ett runtimepaket ska ladda sin felinfångning före övrig appkod, rapportera centrala bootstrapfaser och lämna `markReady` först när appskalet faktiskt är användbart. Ett fel före READY ska ge synlig diagnostik och får inte skriva om arbetsdata.

## Krav från värdversion 10

`packageType` måste finnas och vara exakt `stadslass-web-module-zip-v1`. Manifest utan pakettyp eller med annan pakettyp avvisas. Äldre JSON-testpaket kan inte installeras.


## Host v11 compatibility

Ett funktionspaket upptäcker syncbryggan genom `getHostInfo().syncTransportApiVersion === 1`. Om värdet saknas ska paketet falla tillbaka utan fatalfel. V11 aktiverar inte sync automatiskt och ändrar inte det befintliga `syncOutbox`-lagret.
