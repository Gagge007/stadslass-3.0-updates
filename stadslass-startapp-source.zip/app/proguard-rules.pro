# Steg 1 använder inte kodminimering. Filen finns för ett komplett standardprojekt.
