package se.gagge007.stadslass.v3;

/**
 * Keeps one Android text-save request bound to its content until the module has
 * received and acknowledged its result. Android's document callback has no
 * request identifier, so allowing a second request before the first has ended
 * could otherwise save the wrong report.
 */
final class TextExportCoordinator {
    static final class PendingTextExport {
        final String requestId;
        final String fileName;
        final byte[] content;
        String status = "save_dialog_opened";
        String message = "";

        PendingTextExport(String requestId, String fileName, byte[] content) {
            this.requestId = requestId;
            this.fileName = fileName;
            this.content = content;
        }
    }

    private PendingTextExport active;

    synchronized PendingTextExport begin(String requestId, String fileName, byte[] content) {
        if (active != null) return null;
        active = new PendingTextExport(requestId, fileName, content);
        return active;
    }

    synchronized PendingTextExport activeForResult() {
        return active;
    }

    synchronized PendingTextExport complete(String status, String message) {
        if (active == null) return null;
        active.status = status;
        active.message = message == null ? "" : message;
        return active;
    }

    synchronized PendingTextExport get(String requestId) {
        if (active == null || !active.requestId.equals(requestId)) return null;
        return active;
    }

    synchronized boolean acknowledge(String requestId) {
        if (active == null || !active.requestId.equals(requestId)
                || "save_dialog_opened".equals(active.status)) {
            return false;
        }
        active = null;
        return true;
    }
}
