package se.gagge007.stadslass.v3;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

final class ModulePackage {
    private static final int MAX_METADATA_BYTES = 64 * 1024;
    private static final long MAX_RUNTIME_FILE_BYTES = 2L * 1024L * 1024L;
    private static final long MAX_TOTAL_RUNTIME_BYTES = 8L * 1024L * 1024L;
    private static final Pattern MODULE_ID_PATTERN =
            Pattern.compile("[a-z0-9][a-z0-9._-]{2,79}");
    private static final Pattern SAFE_PATH_PATTERN =
            Pattern.compile("[A-Za-z0-9._/-]{1,180}");

    final File baseDirectory;
    final int packageVersion;
    final int minimumHostVersionCode;
    final String moduleId;
    final String title;
    final String entryPoint;
    final int readyTimeoutMs;
    final Map<String, RuntimeFile> runtimeFiles;

    private ModulePackage(File baseDirectory,
                          int packageVersion,
                          int minimumHostVersionCode,
                          String moduleId,
                          String title,
                          String entryPoint,
                          int readyTimeoutMs,
                          Map<String, RuntimeFile> runtimeFiles) {
        this.baseDirectory = baseDirectory;
        this.packageVersion = packageVersion;
        this.minimumHostVersionCode = minimumHostVersionCode;
        this.moduleId = moduleId;
        this.title = title;
        this.entryPoint = entryPoint;
        this.readyTimeoutMs = readyTimeoutMs;
        this.runtimeFiles = Collections.unmodifiableMap(runtimeFiles);
    }

    static ModulePackage loadAndValidate(File directory) throws Exception {
        if (directory == null || !directory.isDirectory()) {
            throw new IllegalArgumentException("Modulkatalogen saknas.");
        }

        File metadataFile = new File(directory, "module.json");
        byte[] metadataBytes = readLimited(metadataFile, MAX_METADATA_BYTES);
        JSONObject metadata = new JSONObject(
                new String(metadataBytes, StandardCharsets.UTF_8));

        if (metadata.getInt("schemaVersion") != 1) {
            throw new IllegalArgumentException("Okänt modulformat.");
        }
        if (!"stadslass-web-module".equals(metadata.getString("packageType"))) {
            throw new IllegalArgumentException("Fel pakettyp.");
        }

        int packageVersion = metadata.getInt("packageVersion");
        int minimumHost = metadata.getInt("minHostVersionCode");
        String moduleId = limitedText(metadata.getString("moduleId"), 80);
        String title = limitedText(metadata.getString("title"), 100);
        String entryPoint = validateRelativePath(metadata.getString("entryPoint"));
        int readyTimeoutMs = metadata.optInt("readyTimeoutMs", 15000);

        if (packageVersion < 1 || minimumHost < 1) {
            throw new IllegalArgumentException("Ogiltiga versionsvärden.");
        }
        if (!MODULE_ID_PATTERN.matcher(moduleId).matches()) {
            throw new IllegalArgumentException("Ogiltigt modul-ID.");
        }
        if (readyTimeoutMs < 5000 || readyTimeoutMs > 30000) {
            throw new IllegalArgumentException("Ogiltig starttimeout.");
        }

        JSONArray files = metadata.getJSONArray("files");
        if (files.length() < 3 || files.length() > 128) {
            throw new IllegalArgumentException("Ogiltigt antal modulfiler.");
        }

        Map<String, RuntimeFile> runtimeFiles = new LinkedHashMap<>();
        long totalBytes = 0;
        for (int index = 0; index < files.length(); index++) {
            JSONObject item = files.getJSONObject(index);
            String path = validateRelativePath(item.getString("path"));
            String expectedHash = item.getString("sha256").toLowerCase(Locale.ROOT);
            String mimeType = limitedText(item.getString("mimeType"), 80);
            long declaredSize = item.getLong("size");

            if (!expectedHash.matches("[0-9a-f]{64}")) {
                throw new IllegalArgumentException("Ogiltig kontrollsumma för " + path + ".");
            }
            if (declaredSize < 1 || declaredSize > MAX_RUNTIME_FILE_BYTES) {
                throw new IllegalArgumentException("Ogiltig filstorlek för " + path + ".");
            }
            if (runtimeFiles.containsKey(path)) {
                throw new IllegalArgumentException("Dubblettfil i modulmetadata: " + path + ".");
            }

            File runtimeFile = resolveInside(directory, path);
            if (!runtimeFile.isFile() || runtimeFile.length() != declaredSize) {
                throw new IllegalArgumentException("Modulfil saknas eller har fel storlek: " + path + ".");
            }
            String actualHash = sha256Hex(runtimeFile);
            if (!actualHash.equals(expectedHash)) {
                throw new SecurityException("Kontrollsumman stämmer inte för " + path + ".");
            }

            totalBytes += declaredSize;
            if (totalBytes > MAX_TOTAL_RUNTIME_BYTES) {
                throw new IllegalArgumentException("Modulpaketets uppackade innehåll är för stort.");
            }
            runtimeFiles.put(path,
                    new RuntimeFile(path, expectedHash, mimeType, declaredSize));
        }

        if (!runtimeFiles.containsKey(entryPoint)) {
            throw new IllegalArgumentException("Startfilen saknas i fillistan.");
        }
        String entryMime = runtimeFiles.get(entryPoint).mimeType;
        if (!"text/html".equals(entryMime)) {
            throw new IllegalArgumentException("Startfilen måste vara HTML.");
        }

        verifyNoUndeclaredFiles(directory, directory, runtimeFiles);

        return new ModulePackage(directory, packageVersion, minimumHost,
                moduleId, title, entryPoint, readyTimeoutMs, runtimeFiles);
    }

    File resolveRuntimeFile(String relativePath) throws Exception {
        String safePath = validateRelativePath(relativePath);
        if (!runtimeFiles.containsKey(safePath)) {
            throw new SecurityException("Modulen försökte läsa en oregistrerad fil.");
        }
        return resolveInside(baseDirectory, safePath);
    }

    String mimeTypeFor(String relativePath) {
        RuntimeFile file = runtimeFiles.get(relativePath);
        return file == null ? "application/octet-stream" : file.mimeType;
    }

    private static void verifyNoUndeclaredFiles(File root,
                                                 File current,
                                                 Map<String, RuntimeFile> declared)
            throws Exception {
        File[] children = current.listFiles();
        if (children == null) {
            throw new IllegalArgumentException("Modulkatalogen kunde inte läsas.");
        }
        String rootPath = root.getCanonicalPath();
        for (File child : children) {
            if (child.isDirectory()) {
                verifyNoUndeclaredFiles(root, child, declared);
                continue;
            }
            String childPath = child.getCanonicalPath();
            if (!childPath.startsWith(rootPath + File.separator)) {
                throw new SecurityException("Modulfil ligger utanför modulkatalogen.");
            }
            String relative = childPath.substring(rootPath.length() + 1)
                    .replace(File.separatorChar, '/');
            if ("module.json".equals(relative)) {
                continue;
            }
            if (!declared.containsKey(relative)) {
                throw new SecurityException("Oregistrerad fil i modulpaketet: " + relative + ".");
            }
        }
    }

    static String validateRelativePath(String input) {
        String path = input == null ? "" : input.trim();
        if (!SAFE_PATH_PATTERN.matcher(path).matches()
                || path.startsWith("/")
                || path.endsWith("/")
                || path.contains("\\")
                || path.contains("//")) {
            throw new IllegalArgumentException("Ogiltig modulsökväg.");
        }
        String[] segments = path.split("/");
        for (String segment : segments) {
            if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment)) {
                throw new IllegalArgumentException("Ogiltig modulsökväg.");
            }
        }
        return path;
    }

    private static File resolveInside(File root, String relativePath) throws Exception {
        File resolved = new File(root, relativePath);
        String rootPath = root.getCanonicalPath();
        String resolvedPath = resolved.getCanonicalPath();
        if (!resolvedPath.startsWith(rootPath + File.separator)) {
            throw new SecurityException("Sökvägen lämnar modulkatalogen.");
        }
        return resolved;
    }

    private static byte[] readLimited(File file, int maximumBytes) throws Exception {
        if (!file.isFile() || file.length() <= 0 || file.length() > maximumBytes) {
            throw new IllegalArgumentException("Modulmetadata saknas eller är för stor.");
        }
        try (InputStream input = new FileInputStream(file);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) {
                    throw new IllegalArgumentException("Modulmetadata är för stor.");
                }
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private static String limitedText(String value, int maximumLength) {
        String text = value == null ? "" : value.trim();
        if (text.isEmpty() || text.length() > maximumLength) {
            throw new IllegalArgumentException("Ogiltig text i modulmetadata.");
        }
        return text;
    }

    private static String sha256Hex(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new FileInputStream(file)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) {
                digest.update(buffer, 0, read);
            }
        }
        StringBuilder result = new StringBuilder(64);
        for (byte value : digest.digest()) {
            result.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        }
        return result.toString();
    }

    static final class RuntimeFile {
        final String path;
        final String sha256;
        final String mimeType;
        final long size;

        RuntimeFile(String path, String sha256, String mimeType, long size) {
            this.path = path;
            this.sha256 = sha256;
            this.mimeType = mimeType;
            this.size = size;
        }
    }
}
