package se.gagge007.stadslass.v3;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public final class MainActivity extends ComponentActivity {
    private static final String PREFS_NAME = "stadslass_3_permanent_host_preferences";
    private static final String KEY_ROLE = "device_role";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String KEY_FUNCTION_VERSION = "function_package_version";
    private static final String KEY_SYNC_INSTALLATION_ID = "sync_installation_id_v1";
    private static final String KEY_SYNC_INSTALLATION_CREATED_AT =
            "sync_installation_created_at_v1";
    private static final String KEY_LOCATION_PERMISSION_REQUESTED =
            "location_permission_requested";
    private static final String KEY_LOCATION_PERMISSION_GRANTED =
            "location_permission_granted";

    private static final String ROLE_MOBILE = "mobile";
    private static final String ROLE_189 = "vehicle_189";

    private static final String UPDATE_MANIFEST_URL =
            "https://raw.githubusercontent.com/Gagge007/stadslass-3.0-updates/main/latest.json";
    private static final String ALLOWED_UPDATE_BASE =
            "https://raw.githubusercontent.com/Gagge007/stadslass-3.0-updates/main/";
    private static final String MODULE_PACKAGE_TYPE = "stadslass-web-module-zip-v1";
    private static final String UPDATE_PUBLIC_KEY_BASE64 =
            "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAjp/b/Z9MFBPUO+plILgaEVPTOBhEvtI875CyhAsw9Ux4FtPBaHK9n/yb0GhT3bR4QmdDFGnqsiHmyfdJpTqte4QiRLQGnO/Vahr6R7gU2KV37MqyX19TRNVXv5KkeVi7tRS8Kw3+Jwll/xieeD5Pa1PAZD5c6zpUQbzWZS/csNsyjZTEz6RLIg9yeYH8o5NkrGrGg2pSgvjx+DR7poNRuf67txYds+R8Y7JyCMqUTw+AWwl96xVXBFclrfp+Ef3Cd/l16GoDc3lCFKKen/Y9g7HIj1zy+e0bSkhnE/U5sGVFud5MGuFDNCTHDp2JElFOQq8fZJoVWeVelTwlKQdDkpt3z6TASqCWflH8cQdWg2/yZyin0Ea/8GIwqDSFsUCXuwp8TECVKclphL+Es31BzAk8N1l7PkLjdeAXUETX8tVIYZETq+C1Vg8ybSq5N7SzlTGA0lYWNeu1an+kqb+JORUdR9UDQyOeaYFtr/bnfZo+QTFjbpY6O8dgC/RHgFfVAgMBAAE=";

    private static final int MAX_MANIFEST_BYTES = 64 * 1024;
    private static final int MAX_MODULE_ARCHIVE_BYTES = 5 * 1024 * 1024;
    private static final String MODULE_ORIGIN = "https://stadslass.local/module/";
    private static final String MODULE_GEOLOCATION_ORIGIN = "https://stadslass.local";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 306;
    private static final int LOCATION_PERMISSION_DENIED = 0;
    private static final int LOCATION_PERMISSION_APPROXIMATE = 1;
    private static final int LOCATION_PERMISSION_PRECISE = 2;
    private static final int EMAIL_DRAFT_API_VERSION = 2;
    private static final int EMAIL_ATTACHMENT_API_VERSION = 1;
    private static final int TEXT_FILE_EXPORT_API_VERSION = 1;
    private static final int CLIPBOARD_API_VERSION = 1;
    private static final long HOST_ACTION_TIMEOUT_MS = 5000L;
    private static final int MAX_EMAIL_RECIPIENT_LENGTH = 512;
    private static final int MAX_EMAIL_SUBJECT_LENGTH = 998;
    private static final int MAX_EMAIL_BODY_LENGTH = 128 * 1024;
    private static final int MAX_EMAIL_URI_LENGTH = 512 * 1024;
    private static final int MAX_EMAIL_ATTACHMENT_BYTES = 2 * 1024 * 1024;
    private static final int MAX_TEXT_EXPORT_BYTES = 2 * 1024 * 1024;
    private static final int TEXT_EXPORT_REQUEST_CODE = 1307;
    private static final int MAX_CLIPBOARD_LABEL_LENGTH = 256;
    private static final int MAX_CLIPBOARD_TEXT_LENGTH = 256 * 1024;

    private final AtomicBoolean updateInProgress = new AtomicBoolean(false);
    private final AtomicBoolean promotionInProgress = new AtomicBoolean(false);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private SharedPreferences preferences;
    private ModuleInstaller moduleInstaller;
    private ModuleDataStore moduleDataStore;
    private HostWatchdog hostWatchdog;
    private GeocodingNetworkBridge geocodingNetworkBridge;
    private SyncConfigurationStore syncConfigurationStore;
    private SyncTransportManager syncTransportManager;
    private StartAppUpdateManager startAppUpdateManager;
    private final TrustedModuleSession trustedModuleSession = new TrustedModuleSession();
    private String deviceId;
    private String syncInstallationId;
    private long syncInstallationCreatedAt;
    private String updateStatus = "Inte kontrollerad";
    private String startAppUpdateStatus = "Inte kontrollerad";
    private TextView startAppUpdateStatusView;
    private boolean normalApplicationStarted;
    private String lastBridgeError = "";
    private ModulePackage activeModule;
    private WebView moduleWebView;
    private boolean moduleViewActive;
    private boolean candidateMode;
    private boolean moduleReady;
    private int moduleLoadGeneration;
    private boolean runtimeFallbackAttempted;
    private GeolocationPermissions.Callback pendingGeolocationCallback;
    private String pendingGeolocationOrigin;
    private int pendingGeolocationGeneration;
    private boolean locationPermissionRequestInFlight;
    private boolean awaitingLocationSettings;
    private AlertDialog locationSettingsDialog;
    private final TextExportCoordinator textExportCoordinator = new TextExportCoordinator();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(getColor(R.color.stadslass_background));
        getWindow().setNavigationBarColor(Color.WHITE);

        hostWatchdog = new HostWatchdog(this);
        geocodingNetworkBridge = new GeocodingNetworkBridge(hostWatchdog);
        hostWatchdog.startSession(getVersionName(), getVersionCode());
        hostWatchdog.record("host.onCreate", "info",
                "Startappens aktivitet skapades.", 0, false);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (moduleViewActive) {
                    showHostControlScreen();
                    return;
                }
                setEnabled(false);
                getOnBackPressedDispatcher().onBackPressed();
            }
        });

        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        moduleInstaller = new ModuleInstaller(this);
        moduleDataStore = new ModuleDataStore(this);
        startAppUpdateManager = new StartAppUpdateManager(
                this, preferences, moduleDataStore, hostWatchdog,
                new StartAppUpdateManager.Listener() {
                    @Override
                    public void onStartupCanContinue(String status) {
                        startAppUpdateStatus = status;
                        startNormalApplication();
                    }

                    @Override
                    public void onRequiredUpdate(StartAppUpdateManifest manifest,
                                                 String status) {
                        startAppUpdateStatus = status;
                        showRequiredStartAppUpdate(manifest);
                    }

                    @Override
                    public void onManualStatus(String status) {
                        startAppUpdateStatus = status;
                        if (startAppUpdateStatusView != null) {
                            startAppUpdateStatusView.setText(status);
                        }
                        dispatchStartAppUpdateStatus(status);
                    }
                });
        hostWatchdog.record("host.storage.ready", "info",
                "SharedPreferences och separata moduldatalager initierades.",
                0, false);
        deviceId = preferences.getString(KEY_DEVICE_ID, null);
        if (deviceId == null || deviceId.trim().isEmpty()) {
            deviceId = UUID.randomUUID().toString();
            if (!preferences.edit().putString(KEY_DEVICE_ID, deviceId).commit()) {
                throw new IllegalStateException("Enhets-ID kunde inte sparas.");
            }
        }
        ensureSyncInstallationIdentity();
        syncConfigurationStore = new SyncConfigurationStore(preferences);
        syncTransportManager = new SyncTransportManager(
                this, hostWatchdog, syncConfigurationStore,
                this::dispatchSyncResultEvent);
        syncTransportManager.start();

        cleanupLegacyTestArtifacts();
        activeModule = moduleInstaller.loadCurrentOrBackup();
        hostWatchdog.record("host.module.resolve",
                activeModule == null ? "warning" : "info",
                activeModule == null
                        ? "Inget installerat modulpaket kunde läsas."
                        : "Installerat modulpaket verifierades lokalt.",
                activeModule == null ? 0 : activeModule.packageVersion, false);
        if (activeModule != null) {
            preferences.edit()
                    .putInt(KEY_FUNCTION_VERSION, activeModule.packageVersion)
                    .apply();
        }

        if (startAppUpdateManager.shouldDeferForActiveWork()) {
            startNormalApplication();
        } else {
            showStartAppCheckingScreen();
            startAppUpdateManager.checkAtStartup(getVersionCode());
        }
    }

    private void startNormalApplication() {
        if (normalApplicationStarted) {
            return;
        }
        normalApplicationStarted = true;
        startAppUpdateStatusView = null;
        String role = preferences.getString(KEY_ROLE, null);
        if (isValidRole(role) && activeModule != null) {
            showModule(activeModule, false);
        } else {
            renderCurrentState();
        }
        if (isValidRole(role)) {
            checkForFunctionUpdate(true);
        }
    }

    private void showStartAppCheckingScreen() {
        destroyModuleWebView();
        moduleViewActive = false;
        LinearLayout content = createPage();
        content.addView(createTitle(getString(R.string.app_name)));
        content.addView(createBody("Kontrollerar startappversion…"));
        content.addView(createSpacer(18));
        startAppUpdateStatusView = createValue(
                "Kontrollen görs endast vid appstart och påverkar inte sparad arbetsdata.");
        content.addView(startAppUpdateStatusView);
        setContentView(wrapInScrollView(content));
    }

    private void showRequiredStartAppUpdate(StartAppUpdateManifest manifest) {
        destroyModuleWebView();
        moduleViewActive = false;
        LinearLayout content = createPage();
        content.addView(createTitle("Startappen behöver uppdateras"));
        content.addView(createBody(
                "En ny version måste installeras innan Stadslass kan användas vidare. "
                        + "Sparade uppdrag och arbetsdata påverkas inte."));
        content.addView(createSpacer(18));
        content.addView(createLabel("Installerad version"));
        content.addView(createValue(getVersionName()));
        content.addView(createSpacer(12));
        content.addView(createLabel("Ny version"));
        content.addView(createValue(manifest.versionName));
        content.addView(createSpacer(18));
        startAppUpdateStatusView = createValue(startAppUpdateStatus);
        content.addView(startAppUpdateStatusView);
        content.addView(createSpacer(12));

        Button installButton = createPrimaryButton("Hämta och installera");
        installButton.setOnClickListener(view -> {
            installButton.setEnabled(false);
            startAppUpdateStatus = "Förbereder verifierad hämtning…";
            startAppUpdateStatusView.setText(startAppUpdateStatus);
            startAppUpdateManager.requestInstall(manifest);
            mainHandler.postDelayed(() -> installButton.setEnabled(true), 1500L);
        });
        content.addView(installButton);
        content.addView(createSpacer(12));

        Button closeButton = createSecondaryButton("Stäng appen");
        closeButton.setOnClickListener(view -> finishAndRemoveTask());
        content.addView(closeButton);
        content.addView(createSpacer(24));
        setContentView(wrapInScrollView(content));
        hostWatchdog.markReady("host.self-update.required", 0,
                "Obligatorisk startappuppdatering visas utan åtkomst till arbetsvyn.");
    }

    private void dispatchStartAppUpdateStatus(String status) {
        if (!moduleViewActive || moduleWebView == null) {
            return;
        }
        String script = "window.dispatchEvent(new CustomEvent('stadslass:startapp-update-status',"
                + "{detail:{status:" + JSONObject.quote(status == null ? "" : status)
                + "}}));";
        moduleWebView.evaluateJavascript(script, null);
    }

    private void installStartAppUpdateSettingsPanel() {
        if (moduleWebView == null || startAppUpdateManager == null) {
            return;
        }
        String script = "(function(){try{"
                + "if(document.getElementById('startapp-update-card'))return;"
                + "var group=document.getElementById('settings-group-device-appearance');"
                + "if(!group||!window.StadslassHost)return;"
                + "var card=document.createElement('article');"
                + "card.id='startapp-update-card';card.className='section-card';"
                + "var h=document.createElement('h2');h.textContent='Startappuppdatering';card.appendChild(h);"
                + "var p=document.createElement('p');p.className='section-intro';"
                + "p.textContent='Sök manuellt efter en ny signerad Stadslass-startapp.';card.appendChild(p);"
                + "var b=document.createElement('button');b.type='button';b.className='secondary-button';"
                + "b.textContent='Sök efter startappuppdatering';card.appendChild(b);"
                + "var s=document.createElement('p');s.id='startapp-update-status';"
                + "s.className='form-status';s.setAttribute('role','status');s.setAttribute('aria-live','polite');"
                + "s.textContent='Installerad startapp: ' + "
                + JSONObject.quote(getVersionName()) + ";card.appendChild(s);group.appendChild(card);"
                + "function refresh(){try{card.hidden=!window.StadslassHost.canCheckStartAppUpdate();}"
                + "catch(e){card.hidden=true;}}"
                + "b.addEventListener('click',function(){refresh();if(card.hidden)return;"
                + "b.disabled=true;s.textContent='Kontrollerar startappversion…';"
                + "var r=window.StadslassHost.checkStartAppUpdate();"
                + "if(r!=='started'){s.textContent='Kontrollen kunde inte startas.';b.disabled=false;}});"
                + "window.addEventListener('stadslass:startapp-update-status',function(e){"
                + "s.textContent=(e.detail&&e.detail.status)||'Kontrollen är klar.';b.disabled=false;refresh();});"
                + "new MutationObserver(refresh).observe(group,{attributes:true,attributeFilter:['hidden']});"
                + "document.addEventListener('click',function(e){var t=e.target;"
                + "if(t&&t.closest&&t.closest('[data-settings-group=\"device-appearance\"]'))"
                + "setTimeout(refresh,0);});refresh();"
                + "}catch(e){}})();";
        moduleWebView.evaluateJavascript(script, null);
    }

    @Override
    protected void onDestroy() {
        if (syncTransportManager != null) {
            syncTransportManager.close();
        }
        destroyModuleWebView();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (preferences != null) {
            reconcileLocationPermissionAfterResume();
        }
        if (syncTransportManager != null) {
            syncTransportManager.onHostResume();
        }
        if (startAppUpdateManager != null) {
            startAppUpdateManager.onResume();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }
        locationPermissionRequestInFlight = false;
        int permissionLevel = currentLocationPermissionLevel();
        persistLocationPermissionState(permissionLevel);
        if (permissionLevel != LOCATION_PERMISSION_DENIED) {
            answerPendingGeolocationFromCurrentStatus(
                    "Androids platsbehörighet beviljades.");
        } else if (isLocationPermissionPermanentlyDenied()) {
            showLocationSettingsRecovery();
        } else {
            answerPendingGeolocation(false,
                    "Androids platsbehörighet nekades.");
        }
    }

    private void ensureSyncInstallationIdentity() {
        syncInstallationId = preferences.getString(KEY_SYNC_INSTALLATION_ID, "");
        syncInstallationCreatedAt = preferences.getLong(
                KEY_SYNC_INSTALLATION_CREATED_AT, 0L);
        if (!syncInstallationId.trim().isEmpty() && syncInstallationCreatedAt > 0L) {
            return;
        }
        String newId = UUID.randomUUID().toString();
        long createdAt = System.currentTimeMillis();
        boolean saved = preferences.edit()
                .putString(KEY_SYNC_INSTALLATION_ID, newId)
                .putLong(KEY_SYNC_INSTALLATION_CREATED_AT, createdAt)
                .commit();
        if (!saved) {
            throw new IllegalStateException("Installations-ID kunde inte sparas.");
        }
        syncInstallationId = newId;
        syncInstallationCreatedAt = createdAt;
    }

    private String moduleSessionIdentity(ModulePackage module) {
        if (module == null || module.baseDirectory == null) {
            return "";
        }
        return module.moduleId + "|" + module.packageVersion + "|"
                + module.baseDirectory.getAbsolutePath();
    }

    private boolean isTrustedBridgeCall(int bridgeGeneration, ModulePackage bridgeModule) {
        TrustedModuleSession.Decision decision = trustedModuleSession.authorize(
                moduleWebView,
                bridgeGeneration,
                bridgeModule == null ? "" : bridgeModule.moduleId,
                bridgeModule == null ? 0 : bridgeModule.packageVersion,
                moduleSessionIdentity(bridgeModule));
        if (decision == TrustedModuleSession.Decision.ALLOWED) {
            return true;
        }
        hostWatchdog.record("host.bridge.denied", "warning",
                "Känsligt värdanrop nekades: " + decision.name().toLowerCase(Locale.ROOT),
                bridgeModule == null ? 0 : bridgeModule.packageVersion, candidateMode);
        return false;
    }

    private boolean isTrustedBootstrapBridgeCall(int bridgeGeneration,
                                                   ModulePackage bridgeModule) {
        TrustedModuleSession.Decision decision = trustedModuleSession.authorizeBootstrap(
                moduleWebView,
                bridgeGeneration,
                bridgeModule == null ? "" : bridgeModule.moduleId,
                bridgeModule == null ? 0 : bridgeModule.packageVersion,
                moduleSessionIdentity(bridgeModule));
        if (decision == TrustedModuleSession.Decision.ALLOWED) {
            return true;
        }
        hostWatchdog.record("host.bridge.bootstrap.denied", "warning",
                "Bootstrapanrop nekades: "
                        + decision.name().toLowerCase(Locale.ROOT),
                bridgeModule == null ? 0 : bridgeModule.packageVersion, candidateMode);
        return false;
    }

    private void revokeTrustedModuleSession(String phase, String detail) {
        trustedModuleSession.revoke();
        hostWatchdog.record(phase, "info", detail,
                activeModule == null ? 0 : activeModule.packageVersion, candidateMode);
    }

    private void dispatchSyncResultEvent(String requestId, String status) {
        runOnUiThread(() -> {
            if (!moduleViewActive || moduleWebView == null) {
                return;
            }
            try {
                JSONObject detail = new JSONObject();
                detail.put("requestId", requestId == null ? "" : requestId);
                detail.put("status", status == null ? "unknown" : status);
                String encoded = Base64.encodeToString(
                        detail.toString().getBytes(StandardCharsets.UTF_8),
                        Base64.NO_WRAP);
                String script = "(function(){try{"
                        + "var d=JSON.parse(atob('" + encoded + "'));"
                        + "window.dispatchEvent(new CustomEvent("
                        + "'stadslass:sync-result',{detail:d}));"
                        + "}catch(e){}})();";
                moduleWebView.evaluateJavascript(script, null);
            } catch (Exception ignored) {
                // Resultatet kan alltid hämtas via getSyncRequestStatus().
            }
        });
    }

    private static Uri buildMailtoUri(String recipient, String subject, String body) {
        String uriText = MailtoUriBuilder.build(recipient, subject, body);
        if (uriText.length() > MAX_EMAIL_URI_LENGTH) {
            throw new IllegalArgumentException("Mailutkastet är för stort.");
        }
        return Uri.parse(uriText);
    }

    private boolean isValidRole(String role) {
        return ROLE_MOBILE.equals(role) || ROLE_189.equals(role);
    }

    private void renderCurrentState() {
        destroyModuleWebView();
        moduleViewActive = false;
        String role = preferences.getString(KEY_ROLE, null);
        if (isValidRole(role)) {
            showSavedRole(role);
        } else {
            showRoleSelection();
        }
    }

    private void showRoleSelection() {
        LinearLayout content = createPage();
        content.addView(createTitle(getString(R.string.choose_role_title)));
        content.addView(createBody(getString(R.string.choose_role_body)));
        content.addView(createSpacer(18));

        Button mobileButton = createPrimaryButton(getString(R.string.role_mobile));
        mobileButton.setOnClickListener(view -> saveRole(ROLE_MOBILE));
        content.addView(mobileButton);
        content.addView(createSpacer(12));

        Button role189Button = createPrimaryButton(getString(R.string.role_189));
        role189Button.setOnClickListener(view -> saveRole(ROLE_189));
        content.addView(role189Button);
        content.addView(createSpacer(24));

        setContentView(wrapInScrollView(content));
        hostWatchdog.markReady("host.role-selection.ready", 0,
                "Rollvalet visas och värdappen kan användas.");
    }

    private void showSavedRole(String role) {
        LinearLayout content = createPage();
        content.addView(createTitle(getString(R.string.app_name)));
        content.addView(createBody(getString(R.string.step_status) + " · " + getVersionName()));
        content.addView(createSpacer(22));

        content.addView(createLabel(getString(R.string.active_role)));
        content.addView(createValue(roleLabel(role)));
        content.addView(createSpacer(18));

        content.addView(createLabel(getString(R.string.device_id)));
        content.addView(createValue(deviceId));
        content.addView(createSpacer(18));

        content.addView(createLabel(getString(R.string.function_package)));
        ModulePackage installedModule = moduleInstaller.loadCurrentOrBackup();
        if (installedModule != null) {
            content.addView(createValue("Modulpaket version "
                    + installedModule.packageVersion + " · " + installedModule.title));
            content.addView(createSpacer(12));
            Button startModuleButton = createPrimaryButton(
                    getString(R.string.start_module));
            startModuleButton.setOnClickListener(view -> {
                activeModule = installedModule;
                showModule(installedModule, false);
            });
            content.addView(startModuleButton);
        } else {
            content.addView(createValue(getString(R.string.function_package_none)));
        }
        content.addView(createSpacer(20));

        content.addView(createLabel(getString(R.string.update_status)));
        content.addView(createValue(updateStatus));
        content.addView(createSpacer(10));

        Button updateButton = createSecondaryButton(getString(R.string.check_update));
        updateButton.setEnabled(!updateInProgress.get());
        updateButton.setOnClickListener(view -> checkForFunctionUpdate(false));
        content.addView(updateButton);
        content.addView(createSpacer(18));

        Button changeRoleButton = createSecondaryButton(getString(R.string.change_role));
        changeRoleButton.setOnClickListener(view -> confirmRoleChange());
        content.addView(changeRoleButton);
        content.addView(createSpacer(24));

        content.addView(createLabel(getString(R.string.watchdog_status)));
        content.addView(createValue(hostWatchdog.userStatus()));
        String watchdogMessage = hostWatchdog.userMessage();
        if (!watchdogMessage.isEmpty()) {
            content.addView(createBody(watchdogMessage));
        }
        content.addView(createSpacer(10));
        Button copyWatchdogButton = createSecondaryButton(
                getString(R.string.copy_watchdog_report));
        copyWatchdogButton.setOnClickListener(view -> {
            copyWatchdogReport("");
            updateStatus = "Watchdog-rapporten kopierades.";
            renderCurrentState();
        });
        content.addView(copyWatchdogButton);
        content.addView(createSpacer(24));

        setContentView(wrapInScrollView(content));
        hostWatchdog.markReady("host.control.ready",
                installedModule == null ? 0 : installedModule.packageVersion,
                "Värdappens kontrollsida visas.");
    }

    private void saveRole(String role) {
        if (!preferences.edit().putString(KEY_ROLE, role).commit()) {
            showError("Kunde inte spara rollen",
                    "Försök igen. Ingen annan data har ändrats.");
            return;
        }
        ModulePackage installed = moduleInstaller.loadCurrentOrBackup();
        if (installed != null) {
            activeModule = installed;
            showModule(installed, false);
        } else {
            showSavedRole(role);
        }
        checkForFunctionUpdate(true);
    }

    private void cleanupLegacyTestArtifacts() {
        boolean currentRemoved = deleteLegacyTestFile("stadslass-function-package.json");
        boolean backupRemoved = deleteLegacyTestFile(
                "stadslass-function-package.backup.json");
        if (currentRemoved && backupRemoved) {
            hostWatchdog.record("host.cleanup.legacy-test-data", "info",
                    "Äldre JSON-testfiler städades säkert. Sparade äldre värden bevarades.",
                    0, false);
        } else {
            hostWatchdog.record("host.cleanup.legacy-test-data", "warning",
                    "Alla äldre JSON-testfiler kunde inte tas bort. Övrig appdata lämnades orörd.",
                    0, false);
        }
    }

    private boolean deleteLegacyTestFile(String fileName) {
        File file = new File(getFilesDir(), fileName);
        return !file.exists() || file.delete();
    }

    private void checkForFunctionUpdate(boolean automatic) {
        if (!updateInProgress.compareAndSet(false, true)) {
            return;
        }

        updateStatus = automatic ? "Kontrollerar automatiskt…" : "Kontrollerar…";
        hostWatchdog.record("host.update.start", "info",
                automatic ? "Automatisk uppdateringskontroll startade."
                        : "Manuell uppdateringskontroll startade.",
                activeModule == null ? 0 : activeModule.packageVersion, false);
        refreshVisibleStatus();

        new Thread(() -> {
            try {
                byte[] manifestBytes = downloadBytes(
                        UPDATE_MANIFEST_URL + "?t=" + System.currentTimeMillis(),
                        MAX_MANIFEST_BYTES,
                        false,
                        "application/json");
                JSONObject manifest = new JSONObject(
                        new String(manifestBytes, StandardCharsets.UTF_8));
                hostWatchdog.record("host.update.manifest", "info",
                        "latest.json hämtades och kunde tolkas.", 0, false);

                if (manifest.getInt("schemaVersion") != 1) {
                    throw new IllegalArgumentException("Okänt manifestformat.");
                }

                int remoteVersion = manifest.getInt("packageVersion");
                int minimumHost = manifest.getInt("minHostVersionCode");
                if (remoteVersion < 1 || minimumHost < 1) {
                    throw new IllegalArgumentException("Ogiltiga manifestversioner.");
                }
                if (minimumHost > getVersionCode()) {
                    throw new IllegalStateException(
                            "Funktionspaketet kräver en nyare startapp.");
                }

                int installedVersion = Math.max(
                        preferences.getInt(KEY_FUNCTION_VERSION, 0),
                        moduleInstaller.installedPackageVersion());
                if (remoteVersion <= installedVersion) {
                    setUpdateResult("Senaste funktionsversionen är redan installerad.");
                    return;
                }

                String payloadUrl = manifest.getString("payloadUrl");
                validatePayloadUrl(payloadUrl);
                String packageType = manifest.optString("packageType", "");
                if (!MODULE_PACKAGE_TYPE.equals(packageType)) {
                    throw new IllegalArgumentException(
                            "Manifestet måste avse ett signerat ZIP-modulpaket.");
                }

                byte[] payloadBytes = downloadBytes(
                        payloadUrl + "?t=" + System.currentTimeMillis(),
                        MAX_MODULE_ARCHIVE_BYTES,
                        true,
                        "application/zip");

                String expectedHash = manifest.getString("payloadSha256")
                        .toLowerCase(Locale.ROOT);
                if (!expectedHash.matches("[0-9a-f]{64}")) {
                    throw new SecurityException("Manifestets kontrollsumma är ogiltig.");
                }
                String actualHash = sha256Hex(payloadBytes);
                if (!actualHash.equals(expectedHash)) {
                    throw new SecurityException("Kontrollsumman stämmer inte.");
                }
                hostWatchdog.record("host.update.sha256", "info",
                        "Payloadens SHA-256 verifierades.", remoteVersion, true);

                String signatureBase64 = manifest.getString("payloadSignature");
                if (!verifySignature(payloadBytes, signatureBase64)) {
                    throw new SecurityException("Signaturen är ogiltig.");
                }
                hostWatchdog.record("host.update.rsa", "info",
                        "Payloadens RSA/SHA-256-signatur verifierades.",
                        remoteVersion, true);

                ModulePackage candidate = moduleInstaller.stageVerifiedArchive(payloadBytes);
                hostWatchdog.record("host.update.stage", "info",
                        "Paketet packades upp, filverifierades och sparades som kandidat.",
                        candidate.packageVersion, true);
                if (candidate.packageVersion != remoteVersion) {
                    moduleInstaller.discardCandidate();
                    throw new SecurityException("Versionsnumren stämmer inte överens.");
                }
                if (candidate.minimumHostVersionCode > getVersionCode()) {
                    moduleInstaller.discardCandidate();
                    throw new IllegalStateException(
                            "Modulpaketet kräver en nyare startapp.");
                }
                launchCandidateForHealthCheck(candidate);
            } catch (Exception error) {
                moduleInstaller.discardCandidate();
                hostWatchdog.record("host.update.failed", "warning",
                        safeMessage(error),
                        activeModule == null ? 0 : activeModule.packageVersion, true);
                setUpdateResult("Uppdateringen misslyckades: " + safeMessage(error));
            }
        }, "stadslass-update-check").start();
    }

    private void launchCandidateForHealthCheck(ModulePackage candidate) {
        runOnUiThread(() -> {
            activeModule = candidate;
            candidateMode = true;
            updateStatus = "Verifierat modulpaket version " + candidate.packageVersion
                    + " startas i säker provkörning…";
            hostWatchdog.record("host.candidate.launch", "info",
                    "Verifierad kandidat startas i WebView-prov.",
                    candidate.packageVersion, true);
            showModule(candidate, true);
        });
    }

    private byte[] downloadBytes(String address,
                                 int maximumBytes,
                                 boolean payload,
                                 String accept) throws Exception {
        URL url = new URL(address);
        if (!"https".equalsIgnoreCase(url.getProtocol())) {
            throw new SecurityException("Endast HTTPS är tillåtet.");
        }
        if (payload) {
            validatePayloadUrl(address);
        } else if (!"raw.githubusercontent.com".equalsIgnoreCase(url.getHost())
                || url.getPort() != -1
                || url.getUserInfo() != null) {
            throw new SecurityException("Fel manifestvärd.");
        }

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(10000);
        connection.setReadTimeout(20000);
        connection.setRequestMethod("GET");
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept", accept);
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", "Stadslass-3.0-host-v18");

        int responseCode = connection.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK) {
            connection.disconnect();
            throw new IllegalStateException("HTTP-fel " + responseCode + ".");
        }

        int declaredLength = connection.getContentLength();
        if (declaredLength > maximumBytes) {
            connection.disconnect();
            throw new IllegalArgumentException("Filen är för stor.");
        }

        try (InputStream input = connection.getInputStream();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) {
                    throw new IllegalArgumentException("Filen är för stor.");
                }
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        } finally {
            connection.disconnect();
        }
    }

    private void validatePayloadUrl(String address) throws Exception {
        URL url = new URL(address);
        String cleanAddress = address;
        int queryIndex = cleanAddress.indexOf('?');
        if (queryIndex >= 0) {
            cleanAddress = cleanAddress.substring(0, queryIndex);
        }
        String path = url.getPath();
        String query = url.getQuery();
        if (!"https".equalsIgnoreCase(url.getProtocol())
                || !"raw.githubusercontent.com".equalsIgnoreCase(url.getHost())
                || url.getPort() != -1
                || url.getUserInfo() != null
                || url.getRef() != null
                || (query != null && !query.matches("t=[0-9]+"))
                || path == null
                || !path.startsWith("/Gagge007/stadslass-3.0-updates/main/")
                || path.contains("/../")
                || path.contains("/./")
                || path.contains("//")
                || path.contains("\\")
                || !cleanAddress.startsWith(ALLOWED_UPDATE_BASE)) {
            throw new SecurityException("Uppdateringsadressen är inte tillåten.");
        }
    }

    private boolean verifySignature(byte[] payload, String signatureBase64)
            throws Exception {
        byte[] keyBytes = Base64.decode(UPDATE_PUBLIC_KEY_BASE64, Base64.DEFAULT);
        PublicKey key = KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(keyBytes));

        Signature verifier = Signature.getInstance("SHA256withRSA");
        verifier.initVerify(key);
        verifier.update(payload);
        return verifier.verify(Base64.decode(signatureBase64, Base64.DEFAULT));
    }

    private String sha256Hex(byte[] data) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder result = new StringBuilder(digest.length * 2);
        for (byte value : digest) {
            result.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        }
        return result.toString();
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void showModule(ModulePackage module, boolean isCandidate) {
        showModule(module, isCandidate, false);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void showModule(ModulePackage module,
                            boolean isCandidate,
                            boolean fallbackLaunch) {
        destroyModuleWebView();
        moduleViewActive = true;
        candidateMode = isCandidate;
        moduleReady = false;
        if (!fallbackLaunch) {
            runtimeFallbackAttempted = false;
        }
        activeModule = module;
        hostWatchdog.record("host.module.webview.create", "info",
                fallbackLaunch ? "Reservpaketet skapar en ny låst WebView."
                        : "Modulpaketet skapar en ny låst WebView.",
                module.packageVersion, isCandidate);
        moduleLoadGeneration++;
        int generation = moduleLoadGeneration;

        WebView webView = new WebView(this);
        moduleWebView = webView;
        trustedModuleSession.begin(webView, generation, module.moduleId,
                module.packageVersion, moduleSessionIdentity(module));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setDatabaseEnabled(false);
        settings.setGeolocationEnabled(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBlockNetworkLoads(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);
        webView.setBackgroundColor(getColor(R.color.stadslass_background));
        webView.addJavascriptInterface(new HostBridge(generation, module), "StadslassHost");
        webView.setWebViewClient(new SignedModuleWebViewClient(module, generation));
        webView.setWebChromeClient(new SignedModuleWebChromeClient(generation));

        setContentView(webView);

        try {
            File entryFile = module.resolveRuntimeFile(module.entryPoint);
            String html = new String(readFile(entryFile, 2 * 1024 * 1024),
                    StandardCharsets.UTF_8);
            webView.loadDataWithBaseURL(
                    MODULE_ORIGIN,
                    html,
                    "text/html",
                    "UTF-8",
                    null);
            hostWatchdog.record("host.module.entry.load", "info",
                    "Deklarerad HTML-startfil lämnades till WebView.",
                    module.packageVersion, isCandidate);
        } catch (Exception error) {
            handleModuleLoadFailure(generation,
                    "Startfilen kunde inte läsas: " + safeMessage(error));
            return;
        }

        mainHandler.postDelayed(() -> {
            if (generation != moduleLoadGeneration || moduleReady) {
                return;
            }
            handleModuleLoadFailure(generation,
                    "Modulen lämnade inget READY-kvitto inom "
                            + module.readyTimeoutMs + " ms.");
        }, module.readyTimeoutMs);
    }

    private byte[] readFile(File file, int maximumBytes) throws Exception {
        if (!file.isFile() || file.length() <= 0 || file.length() > maximumBytes) {
            throw new IllegalArgumentException("Modulfil saknas eller är för stor.");
        }
        try (InputStream input = new FileInputStream(file);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) {
                    throw new IllegalArgumentException("Modulfilen är för stor.");
                }
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private void handleModuleLoadFailure(int generation, String reason) {
        if (generation != moduleLoadGeneration) {
            return;
        }
        revokeTrustedModuleSession("host.module.session.revoked",
                "Den betrodda modulsessionen återkallades efter modulfel.");
        int failedVersion = activeModule == null ? 0 : activeModule.packageVersion;
        hostWatchdog.record("host.module.failed", "fatal", reason,
                failedVersion, candidateMode);

        if (candidateMode) {
            moduleInstaller.discardCandidate();
            updateInProgress.set(false);
            updateStatus = "Kandidatmodulen avvisades: " + reason
                    + " Föregående fungerande paket behölls.";
            activeModule = moduleInstaller.loadCurrentOrBackup();
            if (activeModule != null) {
                hostWatchdog.markFallback(
                        "Kandidatprovet misslyckades. Installerat paket startas igen.",
                        activeModule.packageVersion);
                showModule(activeModule, false, true);
            } else {
                renderCurrentState();
            }
            return;
        }

        if (!runtimeFallbackAttempted && moduleInstaller.loadBackup() != null) {
            runtimeFallbackAttempted = true;
            try {
                ModulePackage restored = moduleInstaller.rollbackToBackup();
                activeModule = restored;
                preferences.edit()
                        .putInt(KEY_FUNCTION_VERSION, restored.packageVersion)
                        .apply();
                updateStatus = "Installerad modul kunde inte startas. "
                        + "Reservpaket version " + restored.packageVersion
                        + " återställdes automatiskt.";
                hostWatchdog.markFallback(
                        "Aktuellt paket felade. Verifierat reservpaket återställdes.",
                        restored.packageVersion);
                showModule(restored, false, true);
                return;
            } catch (Exception fallbackError) {
                hostWatchdog.record("host.module.fallback.failed", "fatal",
                        safeMessage(fallbackError), failedVersion, false);
            }
        }

        updateStatus = "Installerad modul kunde inte startas: " + reason
                + " Ingen fungerande reserv kunde startas.";
        showHostControlScreen();
    }

    private void markModuleReady(int packageVersion, int bridgeGeneration,
                                 ModulePackage bridgeModule) {
        runOnUiThread(() -> {
            if (!moduleViewActive || activeModule == null
                    || activeModule.packageVersion != packageVersion
                    || bridgeGeneration != moduleLoadGeneration
                    || bridgeModule != activeModule
                    || !trustedModuleSession.markReady(moduleWebView, bridgeGeneration,
                    bridgeModule.moduleId, bridgeModule.packageVersion,
                    moduleSessionIdentity(bridgeModule))) {
                hostWatchdog.record("host.module.ready.denied", "warning",
                        "READY-kvittot hörde inte till aktuell verifierad modulsession.",
                        packageVersion, candidateMode);
                return;
            }
            moduleReady = true;
            if (!candidateMode) {
                installStartAppUpdateSettingsPanel();
            }
            hostWatchdog.markReady("host.module.ready", packageVersion,
                    candidateMode
                            ? "Kandidatmodulen lämnade giltigt READY-kvitto."
                            : "Installerad modul lämnade giltigt READY-kvitto.");
            if (!candidateMode) {
                updateStatus = "Modulpaket version " + packageVersion
                        + " startade lokalt.";
                return;
            }
            if (!promotionInProgress.compareAndSet(false, true)) {
                return;
            }

            int generation = moduleLoadGeneration;
            new Thread(() -> {
                try {
                    ModulePackage promoted = moduleInstaller.promoteCandidate();
                    boolean versionSaved = preferences.edit()
                            .putInt(KEY_FUNCTION_VERSION, promoted.packageVersion)
                            .commit();
                    runOnUiThread(() -> {
                        promotionInProgress.set(false);
                        updateInProgress.set(false);
                        updateStatus = "Modulpaket version "
                                + promoted.packageVersion
                                + " installerades, provstartades och aktiverades."
                                + (versionSaved ? "" : " Versionsmarkören återställs från paketet vid nästa start.");
                        activeModule = promoted;
                        hostWatchdog.markReady("host.candidate.promoted",
                                promoted.packageVersion,
                                "Kandidaten provstartades och gjordes aktuell.");
                        if (generation == moduleLoadGeneration && moduleViewActive) {
                            showModule(promoted, false);
                        } else {
                            refreshVisibleStatus();
                        }
                    });
                } catch (Exception error) {
                    moduleInstaller.discardCandidate();
                    runOnUiThread(() -> {
                        promotionInProgress.set(false);
                        updateInProgress.set(false);
                        updateStatus = "Kandidatmodulen kunde inte aktiveras: "
                                + safeMessage(error)
                                + " Föregående fungerande paket behölls.";
                        hostWatchdog.record("host.candidate.promote.failed",
                                "warning", safeMessage(error),
                                activeModule == null ? 0 : activeModule.packageVersion,
                                true);
                        activeModule = moduleInstaller.loadCurrentOrBackup();
                        if (generation == moduleLoadGeneration && moduleViewActive
                                && activeModule != null) {
                            showModule(activeModule, false);
                        } else {
                            refreshVisibleStatus();
                        }
                    });
                }
            }, "stadslass-module-promotion").start();
        });
    }

    private void showHostControlScreen() {
        runOnUiThread(this::renderCurrentState);
    }

    private void destroyModuleWebView() {
        revokeTrustedModuleSession("host.module.session.revoked",
                "Den betrodda modulsessionen återkallades när WebView stängdes.");
        answerPendingGeolocation(false,
                "WebView stängdes innan platsbegäran kunde besvaras.");
        moduleLoadGeneration++;
        if (moduleWebView != null) {
            moduleWebView.removeJavascriptInterface("StadslassHost");
            moduleWebView.stopLoading();
            moduleWebView.setWebViewClient(null);
            moduleWebView.setWebChromeClient(null);
            moduleWebView.destroy();
            moduleWebView = null;
        }
    }

    private int currentLocationPermissionLevel() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            return LOCATION_PERMISSION_PRECISE;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            return LOCATION_PERMISSION_APPROXIMATE;
        }
        return LOCATION_PERMISSION_DENIED;
    }

    private void persistLocationPermissionState(int permissionLevel) {
        if (preferences == null) {
            return;
        }
        preferences.edit()
                .putBoolean(KEY_LOCATION_PERMISSION_GRANTED,
                        permissionLevel != LOCATION_PERMISSION_DENIED)
                .apply();
    }

    private boolean isLocationPermissionPermanentlyDenied() {
        if (preferences == null
                || !preferences.getBoolean(KEY_LOCATION_PERMISSION_REQUESTED, false)
                || currentLocationPermissionLevel() != LOCATION_PERMISSION_DENIED) {
            return false;
        }
        return !shouldShowRequestPermissionRationale(
                Manifest.permission.ACCESS_COARSE_LOCATION)
                && !shouldShowRequestPermissionRationale(
                Manifest.permission.ACCESS_FINE_LOCATION);
    }

    private boolean isAllowedGeolocationOrigin(String origin) {
        if (origin == null) {
            return false;
        }
        Uri uri = Uri.parse(origin);
        return "https".equalsIgnoreCase(uri.getScheme())
                && "stadslass.local".equalsIgnoreCase(uri.getHost())
                && uri.getPort() == -1;
    }

    private void handleGeolocationPrompt(int generation,
                                         String origin,
                                         GeolocationPermissions.Callback callback) {
        runOnUiThread(() -> {
            if (callback == null
                    || generation != moduleLoadGeneration
                    || !moduleViewActive
                    || moduleWebView == null
                    || !isAllowedGeolocationOrigin(origin)) {
                if (callback != null) {
                    callback.invoke(origin == null ? "" : origin, false, false);
                }
                hostWatchdog.record("host.location.origin.denied", "warning",
                        "Geolocation nekades för en icke tillåten eller inaktiv origin.",
                        activeModule == null ? 0 : activeModule.packageVersion,
                        candidateMode);
                return;
            }

            answerPendingGeolocation(false,
                    "En ny platsbegäran ersatte den föregående.");
            pendingGeolocationCallback = callback;
            pendingGeolocationOrigin = origin;
            pendingGeolocationGeneration = generation;

            int permissionLevel = currentLocationPermissionLevel();
            persistLocationPermissionState(permissionLevel);
            if (permissionLevel != LOCATION_PERMISSION_DENIED) {
                answerPendingGeolocationFromCurrentStatus(
                        permissionLevel == LOCATION_PERMISSION_PRECISE
                                ? "Exakt position är tillåten."
                                : "Ungefärlig position är tillåten.");
                return;
            }

            if (isLocationPermissionPermanentlyDenied()) {
                showLocationSettingsRecovery();
                return;
            }

            preferences.edit()
                    .putBoolean(KEY_LOCATION_PERMISSION_REQUESTED, true)
                    .apply();
            locationPermissionRequestInFlight = true;
            requestPermissions(new String[]{
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    LOCATION_PERMISSION_REQUEST_CODE);
        });
    }

    private void answerPendingGeolocationFromCurrentStatus(String detail) {
        int permissionLevel = currentLocationPermissionLevel();
        persistLocationPermissionState(permissionLevel);
        answerPendingGeolocation(
                permissionLevel != LOCATION_PERMISSION_DENIED,
                detail);
    }

    private void answerPendingGeolocation(boolean allow, String detail) {
        GeolocationPermissions.Callback callback = pendingGeolocationCallback;
        String origin = pendingGeolocationOrigin;
        int generation = pendingGeolocationGeneration;
        pendingGeolocationCallback = null;
        pendingGeolocationOrigin = null;
        pendingGeolocationGeneration = 0;
        awaitingLocationSettings = false;

        if (locationSettingsDialog != null) {
            locationSettingsDialog.dismiss();
            locationSettingsDialog = null;
        }
        if (callback == null) {
            return;
        }

        int currentPermissionLevel = currentLocationPermissionLevel();
        boolean currentAllow = allow
                && currentPermissionLevel != LOCATION_PERMISSION_DENIED
                && generation == moduleLoadGeneration
                && moduleViewActive
                && moduleWebView != null
                && isAllowedGeolocationOrigin(origin);
        callback.invoke(origin, currentAllow, false);
        hostWatchdog.record(
                currentAllow ? "host.location.allowed" : "host.location.denied",
                currentAllow ? "info" : "warning",
                detail,
                activeModule == null ? 0 : activeModule.packageVersion,
                candidateMode);
    }

    private void showLocationSettingsRecovery() {
        if (pendingGeolocationCallback == null
                || locationSettingsDialog != null) {
            return;
        }
        locationSettingsDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.location_permission_settings_title)
                .setMessage(R.string.location_permission_settings_body)
                .setPositiveButton(R.string.open_settings_action,
                        (dialog, which) -> openLocationAppSettings())
                .setNegativeButton(R.string.cancel_action,
                        (dialog, which) -> answerPendingGeolocation(false,
                                "Permanent nekad platsbehörighet ändrades inte."))
                .setOnCancelListener(dialog -> answerPendingGeolocation(false,
                        "Platsbehörighetsdialogen avbröts."))
                .create();
        locationSettingsDialog.show();
    }

    private void openLocationAppSettings() {
        try {
            awaitingLocationSettings = true;
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
        } catch (Exception error) {
            answerPendingGeolocation(false,
                    "Appens behörighetsinställningar kunde inte öppnas.");
        }
    }

    private void reconcileLocationPermissionAfterResume() {
        int permissionLevel = currentLocationPermissionLevel();
        boolean wasGranted = preferences.getBoolean(
                KEY_LOCATION_PERMISSION_GRANTED, false);
        boolean isGranted = permissionLevel != LOCATION_PERMISSION_DENIED;
        if (wasGranted && !isGranted) {
            GeolocationPermissions.getInstance().clear(MODULE_GEOLOCATION_ORIGIN);
            hostWatchdog.record("host.location.revoked", "warning",
                    "Tidigare platsbehörighet har återkallats.",
                    activeModule == null ? 0 : activeModule.packageVersion,
                    candidateMode);
        }
        persistLocationPermissionState(permissionLevel);

        if (locationPermissionRequestInFlight
                || pendingGeolocationCallback == null) {
            return;
        }
        if (awaitingLocationSettings) {
            awaitingLocationSettings = false;
            answerPendingGeolocationFromCurrentStatus(
                    isGranted
                            ? "Platsbehörighet återställdes i Android-inställningar."
                            : "Platsbehörighet är fortfarande nekad efter Android-inställningar.");
        } else if (isGranted) {
            answerPendingGeolocationFromCurrentStatus(
                    "Platsbehörighet återställdes efter återgång från bakgrunden.");
        }
    }

    private void setUpdateResult(String status) {
        runOnUiThread(() -> {
            updateStatus = status;
            updateInProgress.set(false);
            refreshVisibleStatus();
        });
    }

    private void refreshVisibleStatus() {
        if (!moduleViewActive) {
            renderCurrentState();
        }
    }

    private String safeMessage(Exception error) {
        String message = error.getMessage();
        if (message == null || message.trim().isEmpty()) {
            return error.getClass().getSimpleName();
        }
        return message.trim();
    }

    private void copyWatchdogReport(String runtimeReport) {
        String role = preferences == null ? ""
                : preferences.getString(KEY_ROLE, "");
        String report = hostWatchdog.buildReport(
                roleLabel(role),
                deviceId == null ? "" : deviceId,
                activeModule == null ? 0 : activeModule.packageVersion,
                updateStatus,
                runtimeReport);
        ClipboardManager clipboard = (ClipboardManager)
                getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText(
                    "Stadslass Watchdog-rapport", report));
        }
    }

    private void recordRuntimeWatchdog(String phase,
                                       String detail,
                                       String severity) {
        String safePhase = phase == null ? "runtime.unknown" : phase.trim();
        if (!safePhase.matches("[A-Za-z0-9._-]{1,120}")) {
            safePhase = "runtime.invalid-phase";
        }
        String safeDetail = detail == null ? "" : detail.trim();
        if (safeDetail.length() > 1200) {
            safeDetail = safeDetail.substring(0, 1200);
        }
        String safeSeverity = "fatal".equalsIgnoreCase(severity)
                ? "fatal"
                : ("warning".equalsIgnoreCase(severity) ? "warning" : "info");
        hostWatchdog.record(safePhase, safeSeverity, safeDetail,
                activeModule == null ? 0 : activeModule.packageVersion,
                candidateMode);
    }

    private void confirmRoleChange() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.change_role_confirm_title)
                .setMessage(R.string.change_role_confirm_body)
                .setNegativeButton(R.string.cancel_action, null)
                .setPositiveButton(R.string.continue_action, (dialog, which) -> {
                    if (preferences.edit().remove(KEY_ROLE).commit()) {
                        showRoleSelection();
                    }
                })
                .show();
    }

    private void showError(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private String roleLabel(String role) {
        return ROLE_189.equals(role)
                ? getString(R.string.role_189)
                : getString(R.string.role_mobile);
    }

    private String getVersionName() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "okänd version" : info.versionName;
        } catch (Exception ignored) {
            return "okänd version";
        }
    }

    private int getVersionCode() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) {
                long value = info.getLongVersionCode();
                return value > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) value;
            }
            return info.versionCode;
        } catch (Exception ignored) {
            return 0;
        }
    }

    private ScrollView wrapInScrollView(View content) {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(getColor(R.color.stadslass_background));
        scrollView.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return scrollView;
    }

    private LinearLayout createPage() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        int horizontal = dp(this, 24);
        int vertical = dp(this, 36);
        layout.setPadding(horizontal, vertical, horizontal, vertical);
        return layout;
    }

    private TextView createTitle(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(getColor(R.color.stadslass_text));
        view.setTextSize(29);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setGravity(Gravity.CENTER);
        view.setLayoutParams(fullWidthWrap());
        return view;
    }

    private TextView createBody(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(getColor(R.color.stadslass_muted));
        view.setTextSize(17);
        view.setGravity(Gravity.CENTER);
        view.setPadding(0, dp(this, 12), 0, 0);
        view.setLayoutParams(fullWidthWrap());
        return view;
    }

    private TextView createLabel(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(getColor(R.color.stadslass_muted));
        view.setTextSize(14);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLayoutParams(fullWidthWrap());
        return view;
    }

    private TextView createValue(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(getColor(R.color.stadslass_text));
        view.setTextSize(19);
        view.setPadding(0, dp(this, 4), 0, 0);
        view.setTextIsSelectable(true);
        view.setLayoutParams(fullWidthWrap());
        return view;
    }

    private Button createPrimaryButton(String text) {
        Button button = createBaseButton(text);
        button.setTextColor(Color.WHITE);
        GradientDrawable background = new GradientDrawable();
        background.setColor(getColor(R.color.stadslass_blue));
        background.setCornerRadius(dp(this, 12));
        button.setBackground(background);
        return button;
    }

    private Button createSecondaryButton(String text) {
        Button button = createBaseButton(text);
        button.setTextColor(getColor(R.color.stadslass_blue_dark));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(this, 12));
        background.setStroke(dp(this, 2), getColor(R.color.stadslass_blue));
        button.setBackground(background);
        return button;
    }

    private Button createBaseButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(18);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(this, 58));
        button.setGravity(Gravity.CENTER);
        button.setLayoutParams(fullWidthWrap());
        return button;
    }

    private View createSpacer(int heightDp) {
        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(1, dp(this, heightDp)));
        return spacer;
    }

    private LinearLayout.LayoutParams fullWidthWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    private static String hostActionResult(boolean ok, String status) {
        try {
            JSONObject result = new JSONObject();
            result.put("ok", ok);
            result.put("status", status == null ? "host_error" : status);
            return result.toString();
        } catch (Exception ignored) {
            return "{\"ok\":false,\"status\":\"host_error\"}";
        }
    }

    private static String hostActionResult(boolean ok, String status, String requestId,
                                           boolean attachmentCreated, String fileName,
                                           int byteLength) {
        try {
            JSONObject result = new JSONObject();
            result.put("ok", ok);
            result.put("status", status == null ? "host_error" : status);
            result.put("requestId", requestId == null ? "" : requestId);
            result.put("attachmentCreated", attachmentCreated);
            result.put("fileName", fileName == null ? "" : fileName);
            result.put("byteLength", Math.max(0, byteLength));
            return result.toString();
        } catch (Exception ignored) {
            return "{\"ok\":false,\"status\":\"host_error\"}";
        }
    }

    private static String safeReportFileName(String source) {
        String value = source == null ? "" : source.trim();
        if (value.isEmpty() || value.length() > 120 || value.contains("..")
                || value.contains("/") || value.contains("\\\\")
                || value.matches(".*[\\u0000-\\u001f\\u007f].*")) return "";
        value = value.replaceAll("[^A-Za-z0-9._-]", "_");
        if (!value.endsWith(".txt")) value += ".txt";
        return value.length() <= 120 ? value : "";
    }

    private File reportDirectory() throws Exception {
        File directory = new File(getCacheDir(), "stadslass-reports");
        if (!directory.exists() && !directory.mkdirs()) throw new Exception("Rapportmappen kunde inte skapas.");
        return directory;
    }

    private File createReportAttachment(String fileName, byte[] content) throws Exception {
        File directory = reportDirectory();
        File target = new File(directory, fileName);
        try (FileOutputStream output = new FileOutputStream(target, false)) {
            output.write(content);
            output.flush();
        }
        return target;
    }

    private void dispatchTextExportResultEvent(String requestId, String status) {
        if (moduleWebView == null || requestId == null) return;
        String script = "window.dispatchEvent(new CustomEvent('stadslass:text-export-result',{detail:{requestId:"
                + JSONObject.quote(requestId) + ",status:" + JSONObject.quote(status) + "}}));";
        moduleWebView.evaluateJavascript(script, null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != TEXT_EXPORT_REQUEST_CODE) return;
        TextExportCoordinator.PendingTextExport pending = textExportCoordinator.activeForResult();
        if (pending == null) return;
        String status;
        String message = "";
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            status = "cancelled";
        } else {
            try (OutputStream output = getContentResolver().openOutputStream(data.getData(), "w")) {
                if (output == null) throw new Exception("Skrivning kunde inte öppnas.");
                output.write(pending.content);
                output.flush();
                status = "saved";
            } catch (Exception error) {
                status = "write_error";
                message = safeMessage(error);
            }
        }
        pending = textExportCoordinator.complete(status, message);
        if (pending != null) {
            dispatchTextExportResultEvent(pending.requestId, pending.status);
        }
    }

    private final class HostBridge {
        private final int bridgeGeneration;
        private final ModulePackage bridgeModule;

        HostBridge(int generation, ModulePackage module) {
            bridgeGeneration = generation;
            bridgeModule = module;
        }

        private boolean isTrustedCall() {
            return isTrustedBridgeCall(bridgeGeneration, bridgeModule);
        }

        private boolean isTrustedBootstrapCall() {
            return isTrustedBootstrapBridgeCall(bridgeGeneration, bridgeModule);
        }

        @JavascriptInterface
        public String getHostInfo() {
            try {
                JSONObject info = new JSONObject();
                info.put("hostVersionCode", getVersionCode());
                info.put("hostVersionName", getVersionName());
                info.put("packageVersion",
                        activeModule == null ? 0 : activeModule.packageVersion);
                info.put("moduleId", activeModule == null ? "" : activeModule.moduleId);
                info.put("role", preferences.getString(KEY_ROLE, ""));
                info.put("roleLabel", roleLabel(preferences.getString(KEY_ROLE, "")));
                info.put("deviceId", deviceId);
                info.put("updateStatus", updateStatus);
                info.put("storageApiVersion", 1);
                info.put("watchdogApiVersion", 1);
                info.put("emailDraftApiVersion", EMAIL_DRAFT_API_VERSION);
                info.put("emailAttachmentApiVersion", EMAIL_ATTACHMENT_API_VERSION);
                info.put("textFileExportApiVersion", TEXT_FILE_EXPORT_API_VERSION);
                info.put("clipboardApiVersion", CLIPBOARD_API_VERSION);
                info.put("syncTransportApiVersion",
                        SyncTransportManager.SYNC_TRANSPORT_API_VERSION);
                info.put("deviceIdentityApiVersion",
                        SyncTransportManager.DEVICE_IDENTITY_API_VERSION);
                info.put("syncCredentialApiVersion",
                        SyncTransportManager.SYNC_CREDENTIAL_API_VERSION);
                info.put("trustedModuleSessionRevision", 2);
                info.put("selfUpdateApiVersion", StartAppUpdateManager.SELF_UPDATE_API_VERSION);
                info.put("startAppUpdateCheckAvailable",
                        startAppUpdateManager != null
                                && !startAppUpdateManager.shouldDeferForActiveWork());
                info.put("watchdogStatus", hostWatchdog.summary());
                return info.toString();
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return "{}";
            }
        }

        @JavascriptInterface
        public boolean canCheckStartAppUpdate() {
            return isTrustedCall()
                    && startAppUpdateManager != null
                    && !startAppUpdateManager.shouldDeferForActiveWork();
        }

        @JavascriptInterface
        public String checkStartAppUpdate() {
            if (!isTrustedCall() || startAppUpdateManager == null
                    || startAppUpdateManager.shouldDeferForActiveWork()) {
                return "unavailable";
            }
            runOnUiThread(() -> startAppUpdateManager.checkManually(getVersionCode()));
            return "started";
        }

        @JavascriptInterface
        public String readStore(String storeName) {
            if (!isTrustedBootstrapCall()) {
                return "";
            }
            try {
                lastBridgeError = "";
                return moduleDataStore.read(storeName);
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return "";
            }
        }

        @JavascriptInterface
        public boolean writeStore(String storeName, String json) {
            if (!isTrustedBootstrapCall()) {
                return false;
            }
            try {
                moduleDataStore.write(storeName, json);
                lastBridgeError = "";
                return true;
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return false;
            }
        }

        @JavascriptInterface
        public String openEmailDraft(String recipient, String subject, String body) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            String safeRecipient = recipient == null ? "" : recipient.trim();
            String safeSubject = subject == null ? "" : subject;
            String safeBody = body == null ? "" : body;
            if (safeRecipient.length() > MAX_EMAIL_RECIPIENT_LENGTH
                    || safeSubject.length() > MAX_EMAIL_SUBJECT_LENGTH
                    || safeBody.length() > MAX_EMAIL_BODY_LENGTH) {
                return hostActionResult(false, "invalid_request");
            }

            CountDownLatch latch = new CountDownLatch(1);
            AtomicReference<String> status = new AtomicReference<>("host_error");
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setData(buildMailtoUri(
                            safeRecipient, safeSubject, safeBody));
                    startActivity(intent);
                    lastBridgeError = "";
                    hostWatchdog.record("host.emailDraft.opened", "info",
                            "Android accepterade öppning av ett mailutkast.",
                            activeModule == null ? 0 : activeModule.packageVersion, false);
                    status.set("opened");
                } catch (ActivityNotFoundException error) {
                    hostWatchdog.record("host.emailDraft.no-app", "warning",
                            "Ingen app kunde ta emot mailutkastet.",
                            activeModule == null ? 0 : activeModule.packageVersion, false);
                    status.set("no_mail_app");
                } catch (Exception error) {
                    lastBridgeError = safeMessage(error);
                    hostWatchdog.record("host.emailDraft.error", "warning",
                            "Mailutkast kunde inte öppnas.",
                            activeModule == null ? 0 : activeModule.packageVersion, false);
                    status.set("host_error");
                } finally {
                    latch.countDown();
                }
            });
            try {
                if (!latch.await(HOST_ACTION_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    return hostActionResult(false, "host_error");
                }
            } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                return hostActionResult(false, "host_error");
            }
            String finalStatus = status.get();
            return hostActionResult("opened".equals(finalStatus), finalStatus);
        }

        @JavascriptInterface
        public String openEmailDraftWithAttachment(String requestJson) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            String requestId = "";
            String fileName = "";
            boolean attachmentCreated = false;
            int byteLength = 0;
            try {
                JSONObject request = new JSONObject(requestJson == null ? "" : requestJson);
                if (request.optInt("schemaVersion", 0) != 1) {
                    return hostActionResult(false, "invalid_request", "", false, "", 0);
                }
                requestId = request.optString("requestId", "").trim();
                String recipient = request.optString("recipient", "").trim();
                String subject = request.optString("subject", "");
                String body = request.optString("body", "");
                boolean preferGmail = request.optBoolean("preferGmail", true);
                if (requestId.isEmpty() || requestId.length() > 160 || recipient.isEmpty()
                        || recipient.length() > MAX_EMAIL_RECIPIENT_LENGTH || subject.length() > MAX_EMAIL_SUBJECT_LENGTH
                        || body.length() > MAX_EMAIL_BODY_LENGTH) {
                    return hostActionResult(false, "invalid_request", requestId, false, "", 0);
                }
                Uri attachmentUri = null;
                if (!request.isNull("attachment")) {
                    JSONObject attachment = request.optJSONObject("attachment");
                    if (attachment == null || !"text/plain".equals(attachment.optString("mimeType", ""))) {
                        return hostActionResult(false, "invalid_request", requestId, false, "", 0);
                    }
                    fileName = safeReportFileName(attachment.optString("fileName", ""));
                    String content = attachment.optString("contentUtf8", "");
                    byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                    if (fileName.isEmpty() || bytes.length == 0 || bytes.length > MAX_EMAIL_ATTACHMENT_BYTES) {
                        return hostActionResult(false, "invalid_request", requestId, false, "", 0);
                    }
                    File attachmentFile = createReportAttachment(fileName, bytes);
                    attachmentUri = FileProvider.getUriForFile(MainActivity.this,
                            "se.gagge007.stadslass.v3.reportfiles", attachmentFile);
                    attachmentCreated = true;
                    byteLength = bytes.length;
                }
                final Uri finalAttachmentUri = attachmentUri;
                final String safeRecipient = recipient;
                final String safeSubject = subject;
                final String safeBody = body;
                final boolean safePreferGmail = preferGmail;
                CountDownLatch latch = new CountDownLatch(1);
                AtomicReference<String> status = new AtomicReference<>("host_error");
                runOnUiThread(() -> {
                    try {
                        Intent intent;
                        if (finalAttachmentUri == null) {
                            intent = new Intent(Intent.ACTION_SENDTO);
                            intent.setData(buildMailtoUri(safeRecipient, safeSubject, safeBody));
                        } else {
                            intent = new Intent(Intent.ACTION_SEND);
                            intent.setType("text/plain");
                            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{safeRecipient});
                            intent.putExtra(Intent.EXTRA_SUBJECT, safeSubject);
                            intent.putExtra(Intent.EXTRA_TEXT, safeBody);
                            intent.putExtra(Intent.EXTRA_STREAM, finalAttachmentUri);
                            intent.setClipData(ClipData.newRawUri("Stadslass syncrapport", finalAttachmentUri));
                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        }
                        if (safePreferGmail) {
                            try {
                                intent.setPackage("com.google.android.gm");
                                startActivity(intent);
                                status.set("opened_gmail");
                            } catch (ActivityNotFoundException missingGmail) {
                                intent.setPackage(null);
                                startActivity(intent);
                                status.set("opened_mail_app");
                            }
                        } else {
                            startActivity(intent);
                            status.set("opened_mail_app");
                        }
                    } catch (ActivityNotFoundException error) {
                        status.set("no_mail_app");
                    } catch (Exception error) {
                        lastBridgeError = safeMessage(error);
                        status.set(finalAttachmentUri == null ? "host_error" : "attachment_error");
                    } finally {
                        latch.countDown();
                    }
                });
                if (!latch.await(HOST_ACTION_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                    return hostActionResult(false, "host_error", requestId, attachmentCreated, fileName, byteLength);
                }
                String result = status.get();
                boolean ok = "opened_gmail".equals(result) || "opened_mail_app".equals(result);
                return hostActionResult(ok, result, requestId, attachmentCreated, fileName, byteLength);
            } catch (Exception error) {
                return hostActionResult(false, attachmentCreated ? "attachment_error" : "invalid_request",
                        requestId, attachmentCreated, fileName, byteLength);
            }
        }

        @JavascriptInterface
        public String requestTextFileExport(String requestJson) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            try {
                JSONObject request = new JSONObject(requestJson == null ? "" : requestJson);
                String requestId = request.optString("requestId", "").trim();
                String fileName = safeReportFileName(request.optString("fileName", ""));
                byte[] content = request.optString("contentUtf8", "").getBytes(StandardCharsets.UTF_8);
                if (request.optInt("schemaVersion", 0) != 1 || requestId.isEmpty() || requestId.length() > 160
                        || !"text/plain".equals(request.optString("mimeType", "")) || fileName.isEmpty()
                        || content.length == 0 || content.length > MAX_TEXT_EXPORT_BYTES) {
                    return hostActionResult(false, "invalid_request", requestId, false, fileName, 0);
                }
                TextExportCoordinator.PendingTextExport pending =
                        textExportCoordinator.begin(requestId, fileName, content);
                if (pending == null) {
                    return hostActionResult(false, "export_in_progress", requestId, false, fileName, 0);
                }
                runOnUiThread(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TITLE, fileName);
                    startActivityForResult(intent, TEXT_EXPORT_REQUEST_CODE);
                });
                return hostActionResult(true, "save_dialog_opened", requestId, false, fileName, content.length);
            } catch (Exception error) {
                return hostActionResult(false, "invalid_request");
            }
        }

        @JavascriptInterface
        public String getTextFileExportStatus(String requestId) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            TextExportCoordinator.PendingTextExport pending =
                    textExportCoordinator.get(requestId == null ? "" : requestId.trim());
            if (pending == null) return hostActionResult(false, "invalid_request");
            return hostActionResult("save_dialog_opened".equals(pending.status) || "saved".equals(pending.status),
                    pending.status, pending.requestId, false, pending.fileName, pending.content.length);
        }

        @JavascriptInterface
        public String acknowledgeTextFileExportResult(String requestId) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            TextExportCoordinator.PendingTextExport pending =
                    textExportCoordinator.get(requestId == null ? "" : requestId.trim());
            if (pending == null || "save_dialog_opened".equals(pending.status)) return hostActionResult(false, "invalid_request");
            if (!textExportCoordinator.acknowledge(pending.requestId)) {
                return hostActionResult(false, "invalid_request");
            }
            return hostActionResult(true, "acknowledged", pending.requestId, false, pending.fileName, pending.content.length);
        }

        @JavascriptInterface
        public boolean copyText(String label, String text) {
            if (!isTrustedCall()) {
                return false;
            }
            String safeLabel = label == null ? "Stadslass" : label.trim();
            String safeText = text == null ? "" : text;
            if (safeLabel.isEmpty()) {
                safeLabel = "Stadslass";
            }
            if (safeLabel.length() > MAX_CLIPBOARD_LABEL_LENGTH
                    || safeText.length() > MAX_CLIPBOARD_TEXT_LENGTH) {
                return false;
            }
            CountDownLatch latch = new CountDownLatch(1);
            AtomicBoolean copied = new AtomicBoolean(false);
            String finalLabel = safeLabel;
            runOnUiThread(() -> {
                try {
                    ClipboardManager clipboard = (ClipboardManager)
                            getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(ClipData.newPlainText(finalLabel, safeText));
                        copied.set(true);
                    }
                } catch (Exception error) {
                    lastBridgeError = safeMessage(error);
                    hostWatchdog.record("host.clipboard.error", "warning",
                            "Text kunde inte kopieras till urklipp.",
                            activeModule == null ? 0 : activeModule.packageVersion, false);
                } finally {
                    latch.countDown();
                }
            });
            try {
                return latch.await(HOST_ACTION_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                        && copied.get();
            } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                return false;
            }
        }

        @JavascriptInterface
        public String getDeviceIdentity() {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            try {
                JSONObject result = new JSONObject();
                result.put("ok", true);
                result.put("installationId", syncInstallationId);
                result.put("createdAt", syncInstallationCreatedAt);
                result.put("hostVersionCode", getVersionCode());
                return result.toString();
            } catch (Exception ignored) {
                return hostActionResult(false, "host_error");
            }
        }

        @JavascriptInterface
        public String setSyncConfiguration(String configJson) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncConfigurationStore == null) {
                return hostActionResult(false, "host_error");
            }
            String result = syncConfigurationStore.setConfiguration(configJson);
            if (syncTransportManager != null) {
                syncTransportManager.onConfigurationChanged();
            }
            return result;
        }

        @JavascriptInterface
        public String getSyncConfigurationStatus() {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            return syncConfigurationStore == null
                    ? hostActionResult(false, "host_error")
                    : syncConfigurationStore.statusJson();
        }

        @JavascriptInterface
        public String clearSyncConfiguration() {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncConfigurationStore == null) {
                return hostActionResult(false, "host_error");
            }
            String result = syncConfigurationStore.clearConfiguration();
            if (syncTransportManager != null) {
                syncTransportManager.onConfigurationCleared();
            }
            return result;
        }

        @JavascriptInterface
        public String enqueueSyncRequest(String requestJson) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncTransportManager == null) {
                return hostActionResult(false, "host_error");
            }
            try {
                return syncTransportManager.enqueue(requestJson);
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return hostActionResult(false, "host_error");
            }
        }

        @JavascriptInterface
        public String getSyncRequestStatus(String requestId) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncTransportManager == null) {
                return hostActionResult(false, "host_error");
            }
            try {
                return syncTransportManager.getStatus(requestId);
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return hostActionResult(false, "host_error");
            }
        }

        @JavascriptInterface
        public String listPendingSyncRequests() {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncTransportManager == null) {
                return hostActionResult(false, "host_error");
            }
            try {
                return syncTransportManager.listPending();
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return hostActionResult(false, "host_error");
            }
        }

        @JavascriptInterface
        public String retryPendingSyncRequests() {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncTransportManager == null) {
                return hostActionResult(false, "host_error");
            }
            try {
                return syncTransportManager.retryPending();
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return hostActionResult(false, "host_error");
            }
        }

        @JavascriptInterface
        public String acknowledgeSyncResult(String requestId) {
            if (!isTrustedCall()) {
                return hostActionResult(false, "origin_denied");
            }
            if (syncTransportManager == null) {
                return hostActionResult(false, "host_error");
            }
            try {
                return syncTransportManager.acknowledge(requestId);
            } catch (Exception error) {
                lastBridgeError = safeMessage(error);
                return hostActionResult(false, "host_error");
            }
        }

        @JavascriptInterface
        public String getLastError() {
            return lastBridgeError;
        }

        @JavascriptInterface
        public String getUpdateStatus() {
            return updateStatus;
        }

        @JavascriptInterface
        public void requestUpdateCheck() {
            runOnUiThread(() -> checkForFunctionUpdate(false));
        }

        @JavascriptInterface
        public void showHostControl() {
            showHostControlScreen();
        }

        @JavascriptInterface
        public void watchdogStep(String phase, String detail, String severity) {
            recordRuntimeWatchdog(phase, detail, severity);
        }

        @JavascriptInterface
        public String getHostWatchdogReport() {
            return hostWatchdog.buildReport(
                    roleLabel(preferences.getString(KEY_ROLE, "")),
                    deviceId,
                    activeModule == null ? 0 : activeModule.packageVersion,
                    updateStatus,
                    "");
        }

        @JavascriptInterface
        public boolean copyWatchdogReport(String runtimeReport) {
            String safeReport = runtimeReport == null ? "" : runtimeReport;
            if (safeReport.length() > 64 * 1024) {
                safeReport = safeReport.substring(0, 64 * 1024);
            }
            String finalReport = safeReport;
            runOnUiThread(() -> MainActivity.this.copyWatchdogReport(finalReport));
            return true;
        }

        @JavascriptInterface
        public void markReady(int packageVersion) {
            markModuleReady(packageVersion, bridgeGeneration, bridgeModule);
        }
    }

    private final class SignedModuleWebViewClient extends WebViewClient {
        private final ModulePackage module;
        private final int generation;

        SignedModuleWebViewClient(ModulePackage module, int generation) {
            this.module = module;
            this.generation = generation;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(
                WebView view, WebResourceRequest request) {
            try {
                if (!"GET".equalsIgnoreCase(request.getMethod())) {
                    return blockedResponse();
                }
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme())
                        && "stadslass.local".equalsIgnoreCase(uri.getHost())
                        && uri.getPort() == -1
                        && uri.getPath() != null
                        && uri.getPath().startsWith("/module/")) {
                    String relativePath = uri.getPath().substring("/module/".length());
                    File file = module.resolveRuntimeFile(relativePath);
                    String mimeType = module.mimeTypeFor(relativePath);
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("X-Content-Type-Options", "nosniff");
                    return new WebResourceResponse(
                            mimeType,
                            isTextMime(mimeType) ? "UTF-8" : null,
                            200,
                            "OK",
                            headers,
                            new FileInputStream(file));
                }
                if (geocodingNetworkBridge != null
                        && geocodingNetworkBridge.matches(request)) {
                    return geocodingNetworkBridge.execute(
                            request, module.packageVersion, candidateMode);
                }
                return blockedResponse();
            } catch (Exception error) {
                return blockedResponse();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (!request.isForMainFrame()) {
                return !TrustedModuleSession.isExpectedOrigin(uri.toString());
            }
            revokeTrustedModuleSession("host.module.navigation.revoked",
                    "Den betrodda modulsessionen återkallades före ny huvudnavigation.");
            moduleReady = false;
            if (!TrustedModuleSession.isExpectedOrigin(uri.toString())) {
                return true;
            }
            mainHandler.post(() -> {
                if (generation == moduleLoadGeneration && moduleWebView == view) {
                    showModule(module, candidateMode, false);
                }
            });
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            if (generation != moduleLoadGeneration || moduleWebView != view) {
                return;
            }
            if (trustedModuleSession.hasCommittedMainFrame()) {
                revokeTrustedModuleSession("host.module.navigation.revoked",
                        "Den betrodda modulsessionen återkallades vid ny huvudladdning.");
                moduleReady = false;
                mainHandler.post(() -> {
                    if (generation == moduleLoadGeneration && moduleWebView == view) {
                        showModule(module, candidateMode, false);
                    }
                });
            }
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            if (generation != moduleLoadGeneration || moduleWebView != view) {
                return;
            }
            if (!trustedModuleSession.commitMainFrame(view, generation,
                    module.moduleId, module.packageVersion, moduleSessionIdentity(module), url)) {
                moduleReady = false;
                hostWatchdog.record("host.module.origin.denied", "warning",
                        "Huvudramen matchade inte den lokala modulorigin som värdappen äger.",
                        module.packageVersion, candidateMode);
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            hostWatchdog.record("host.module.page-finished", "info",
                    "WebView avslutade huvudsidans laddning och väntar på READY.",
                    module.packageVersion, candidateMode);
        }

        @Override
        public void onReceivedError(WebView view,
                                    WebResourceRequest request,
                                    WebResourceError error) {
            if (request.isForMainFrame()) {
                String description = error.getDescription() == null
                        ? "okänt WebView-fel"
                        : error.getDescription().toString();
                handleModuleLoadFailure(generation, description);
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view,
                                           RenderProcessGoneDetail detail) {
            revokeTrustedModuleSession("host.module.session.revoked",
                    "Den betrodda modulsessionen återkallades när WebView-processen försvann.");
            boolean rendererCrashed = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && detail != null
                    && detail.didCrash();
            String reason = rendererCrashed
                    ? "WebView-processen kraschade."
                    : "WebView-processen avslutades av systemet.";
            handleModuleLoadFailure(generation, reason);
            return true;
        }

        private WebResourceResponse blockedResponse() {
            byte[] message = "Blocked".getBytes(StandardCharsets.UTF_8);
            return new WebResourceResponse(
                    "text/plain",
                    "UTF-8",
                    403,
                    "Blocked",
                    Collections.singletonMap("Cache-Control", "no-store"),
                    new ByteArrayInputStream(message));
        }

        private boolean isTextMime(String mimeType) {
            return mimeType.startsWith("text/")
                    || "application/javascript".equals(mimeType)
                    || "application/json".equals(mimeType)
                    || "image/svg+xml".equals(mimeType);
        }
    }

    private final class SignedModuleWebChromeClient extends WebChromeClient {
        private final int generation;

        SignedModuleWebChromeClient(int generation) {
            this.generation = generation;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(
                String origin,
                GeolocationPermissions.Callback callback) {
            handleGeolocationPrompt(generation, origin, callback);
        }
    }


}
