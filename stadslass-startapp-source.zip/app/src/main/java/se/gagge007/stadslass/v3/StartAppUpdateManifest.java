package se.gagge007.stadslass.v3;

import org.json.JSONObject;

import java.net.URL;
import java.util.Locale;

final class StartAppUpdateManifest {
    static final int SCHEMA_VERSION = 1;
    static final String PACKAGE_TYPE = "stadslass-startapp-apk-v1";
    static final String PACKAGE_ID = "se.gagge007.stadslass.v3";
    static final String ALLOWED_BASE =
            "https://raw.githubusercontent.com/Gagge007/stadslass-3.0-updates/main/";

    final int versionCode;
    final String versionName;
    final String apkUrl;
    final String apkSha256;
    final long apkSizeBytes;
    final String signingCertificateSha256;
    final int minimumUpdaterVersionCode;
    final boolean requiredBeforeUse;
    final String publishedAt;

    private StartAppUpdateManifest(int versionCode,
                                   String versionName,
                                   String apkUrl,
                                   String apkSha256,
                                   long apkSizeBytes,
                                   String signingCertificateSha256,
                                   int minimumUpdaterVersionCode,
                                   boolean requiredBeforeUse,
                                   String publishedAt) {
        this.versionCode = versionCode;
        this.versionName = versionName;
        this.apkUrl = apkUrl;
        this.apkSha256 = apkSha256;
        this.apkSizeBytes = apkSizeBytes;
        this.signingCertificateSha256 = signingCertificateSha256;
        this.minimumUpdaterVersionCode = minimumUpdaterVersionCode;
        this.requiredBeforeUse = requiredBeforeUse;
        this.publishedAt = publishedAt;
    }

    static StartAppUpdateManifest parse(String json) throws Exception {
        JSONObject value = new JSONObject(json == null ? "" : json);
        if (value.getInt("schemaVersion") != SCHEMA_VERSION) {
            throw new IllegalArgumentException("Okänt startappsmanifest.");
        }
        if (!PACKAGE_TYPE.equals(value.getString("packageType"))) {
            throw new IllegalArgumentException("Manifestet avser inte en startapp.");
        }
        if (!PACKAGE_ID.equals(value.getString("packageId"))) {
            throw new SecurityException("Manifestet har fel paket-ID.");
        }
        int versionCode = value.getInt("versionCode");
        String versionName = requiredText(value, "versionName", 80);
        String apkUrl = requiredText(value, "apkUrl", 800);
        String apkSha256 = normalizedSha(value.getString("apkSha256"));
        long apkSizeBytes = value.getLong("apkSizeBytes");
        String certificate = normalizedSha(value.getString("signingCertificateSha256"));
        int minimumUpdater = value.getInt("minimumUpdaterVersionCode");
        boolean required = value.getBoolean("required");
        String publishedAt = requiredText(value, "publishedAt", 80);

        if (versionCode < 1 || minimumUpdater < 1) {
            throw new IllegalArgumentException("Manifestet har ogiltiga versionsnummer.");
        }
        if (apkSizeBytes < 1024 || apkSizeBytes > StartAppUpdateManager.MAX_APK_BYTES) {
            throw new IllegalArgumentException("Manifestet har ogiltig APK-storlek.");
        }
        validateApkUrl(apkUrl);
        return new StartAppUpdateManifest(versionCode, versionName, apkUrl,
                apkSha256, apkSizeBytes, certificate, minimumUpdater,
                required, publishedAt);
    }

    boolean requiresUpdate(int installedVersionCode) {
        return StartAppUpdatePolicy.requiresUpdate(
                requiredBeforeUse, versionCode, installedVersionCode);
    }

    private static String requiredText(JSONObject value, String key, int maximumLength)
            throws Exception {
        String text = value.getString(key).trim();
        if (text.isEmpty() || text.length() > maximumLength) {
            throw new IllegalArgumentException("Manifestfältet " + key + " är ogiltigt.");
        }
        return text;
    }

    private static String normalizedSha(String value) {
        String normalized = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        if (!normalized.matches("[0-9a-f]{64}")) {
            throw new IllegalArgumentException("Manifestet har ogiltig SHA-256.");
        }
        return normalized;
    }

    static void validateApkUrl(String address) throws Exception {
        URL url = new URL(address);
        String path = url.getPath();
        if (!"https".equalsIgnoreCase(url.getProtocol())
                || !"raw.githubusercontent.com".equalsIgnoreCase(url.getHost())
                || url.getPort() != -1
                || url.getUserInfo() != null
                || url.getQuery() != null
                || url.getRef() != null
                || path == null
                || !path.startsWith("/Gagge007/stadslass-3.0-updates/main/")
                || path.contains("/../")
                || path.contains("/./")
                || path.contains("//")
                || path.contains("\\")
                || !address.startsWith(ALLOWED_BASE)
                || !path.matches("/Gagge007/stadslass-3\\.0-updates/main/Stadslass-3\\.0-startapp-v[0-9]+\\.apk")) {
            throw new SecurityException("Startappens APK-adress är inte tillåten.");
        }
    }
}
