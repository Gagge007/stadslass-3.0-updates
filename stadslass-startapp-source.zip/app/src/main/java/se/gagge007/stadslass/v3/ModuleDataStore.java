package se.gagge007.stadslass.v3;

import android.content.Context;
import android.util.AtomicFile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

final class ModuleDataStore {
    static final String SETTINGS = "settings";
    static final String QUEUE = "queue";
    static final String ACTIVE_JOB = "activeJob";
    static final String HISTORY = "history";
    static final String SYNC_OUTBOX = "syncOutbox";

    private final File root;
    private final Map<String, StoreDefinition> stores;

    ModuleDataStore(Context context) {
        root = new File(context.getFilesDir(), "stadslass-module-data");
        Map<String, StoreDefinition> definitions = new LinkedHashMap<>();
        definitions.put(SETTINGS,
                new StoreDefinition("settings.json", "{}", 256 * 1024));
        definitions.put(QUEUE,
                new StoreDefinition("queue.json", "[]", 1024 * 1024));
        definitions.put(ACTIVE_JOB,
                new StoreDefinition("active-job.json", "{}", 1024 * 1024));
        definitions.put(HISTORY,
                new StoreDefinition("history.json", "[]", 8 * 1024 * 1024));
        definitions.put(SYNC_OUTBOX,
                new StoreDefinition("sync-outbox.json", "[]", 2 * 1024 * 1024));
        stores = Collections.unmodifiableMap(definitions);
    }

    synchronized String read(String storeName) throws Exception {
        StoreDefinition definition = requireStore(storeName);
        File file = new File(root, definition.fileName);
        if (!file.exists()) {
            return definition.emptyValue;
        }
        if (!file.isFile() || file.length() <= 0 || file.length() > definition.maximumBytes) {
            throw new IllegalStateException("Datalagret är skadat eller för stort.");
        }
        try (FileInputStream input = new FileInputStream(file);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > definition.maximumBytes) {
                    throw new IllegalStateException("Datalagret är för stort.");
                }
                output.write(buffer, 0, read);
            }
            String json = output.toString(StandardCharsets.UTF_8.name());
            validateJson(json);
            return json;
        }
    }

    synchronized void write(String storeName, String json) throws Exception {
        StoreDefinition definition = requireStore(storeName);
        if (json == null) {
            throw new IllegalArgumentException("Datalagret kan inte skrivas med tom data.");
        }
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        if (bytes.length <= 0 || bytes.length > definition.maximumBytes) {
            throw new IllegalArgumentException("Datalagrets storlek är ogiltig.");
        }
        validateJson(json);

        if (!root.exists() && !root.mkdirs()) {
            throw new IllegalStateException("Datalagringskatalogen kunde inte skapas.");
        }
        File target = new File(root, definition.fileName);
        AtomicFile atomicFile = new AtomicFile(target);
        FileOutputStream output = null;
        try {
            output = atomicFile.startWrite();
            output.write(bytes);
            output.flush();
            output.getFD().sync();
            atomicFile.finishWrite(output);
        } catch (Exception error) {
            if (output != null) {
                atomicFile.failWrite(output);
            }
            throw error;
        }
    }

    private StoreDefinition requireStore(String storeName) {
        StoreDefinition definition = stores.get(storeName);
        if (definition == null) {
            throw new SecurityException("Okänt datalager.");
        }
        return definition;
    }

    private static void validateJson(String json) throws Exception {
        String trimmed = json.trim();
        if (trimmed.startsWith("{")) {
            new JSONObject(trimmed);
        } else if (trimmed.startsWith("[")) {
            new JSONArray(trimmed);
        } else {
            throw new IllegalArgumentException("Datalagret måste innehålla ett JSON-objekt eller en JSON-lista.");
        }
    }

    private static final class StoreDefinition {
        final String fileName;
        final String emptyValue;
        final int maximumBytes;

        StoreDefinition(String fileName, String emptyValue, int maximumBytes) {
            this.fileName = fileName;
            this.emptyValue = emptyValue;
            this.maximumBytes = maximumBytes;
        }
    }
}
