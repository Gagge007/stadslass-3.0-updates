package se.gagge007.stadslass.v3;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.util.AtomicFile;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Generic host-owned GitHub transport. Request bodies are opaque file content;
 * this class never reads or writes module stores and never interprets Stadslass
 * job, phase, queue, history, weight or ÄTA semantics.
 */
final class SyncTransportManager {
    static final int SYNC_TRANSPORT_API_VERSION = 1;
    static final int DEVICE_IDENTITY_API_VERSION = 1;
    static final int SYNC_CREDENTIAL_API_VERSION = 1;

    private static final int MAX_REQUEST_BODY_BYTES = 1024 * 1024;
    private static final int MAX_RESPONSE_BODY_BYTES = 2 * 1024 * 1024;
    private static final int MAX_QUEUE_RECORDS = 200;
    private static final int MAX_QUEUE_BODY_BYTES = 8 * 1024 * 1024;
    private static final int MAX_DEDUP_RECORDS = 500;
    private static final long DEDUP_RETENTION_MS = 30L * 24L * 60L * 60L * 1000L;
    private static final int CONNECT_TIMEOUT_MS = 15_000;
    private static final int READ_TIMEOUT_MS = 30_000;


    interface ResultListener {
        void onSyncResult(String requestId, String status);
    }

    private final Context context;
    private final HostWatchdog watchdog;
    private final SyncConfigurationStore configurationStore;
    private final PersistentStore store;
    private final ResultListener resultListener;
    private final ScheduledExecutorService executor =
            Executors.newSingleThreadScheduledExecutor(runnable -> {
                Thread thread = new Thread(runnable, "StadslassSyncTransportV1");
                thread.setDaemon(true);
                return thread;
            });
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private final AtomicBoolean requestRunning = new AtomicBoolean(false);
    private final Object operationLock = new Object();
    private final Object scheduleLock = new Object();
    private ScheduledFuture<?> scheduledFuture;
    private long scheduledAtEpochMs = Long.MAX_VALUE;

    private final ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    SyncTransportManager(Context context,
                         HostWatchdog watchdog,
                         SyncConfigurationStore configurationStore,
                         ResultListener resultListener) {
        this.context = context.getApplicationContext();
        this.watchdog = watchdog;
        this.configurationStore = configurationStore;
        this.resultListener = resultListener;
        this.store = new PersistentStore(this.context, watchdog);
        this.connectivityManager = (ConnectivityManager)
                this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    void start() {
        recoverInterruptedRequests();
        registerNetworkCallback();
        triggerProcessing(0L);
    }

    void onHostResume() {
        triggerProcessing(0L);
    }

    void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        if (connectivityManager != null && networkCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(networkCallback);
            } catch (Exception ignored) {
                // Callback may already be unregistered by Android.
            }
        }
        synchronized (scheduleLock) {
            if (scheduledFuture != null) {
                scheduledFuture.cancel(false);
                scheduledFuture = null;
            }
        }
        executor.shutdownNow();
    }

    void onConfigurationChanged() {
        triggerProcessing(0L);
    }

    void onConfigurationCleared() {
        synchronized (operationLock) {
            for (RequestRecord request : store.loadRequests()) {
                if ("pending".equals(request.status)
                        || "failed_retryable".equals(request.status)) {
                    request.errorCode = "configuration_missing";
                    store.writeRequest(request);
                }
            }
        }
    }

    String enqueue(String requestJson) {
        if (closed.get()) {
            return simpleResult(false, "host_error", "", "transport_closed");
        }
        if (!configurationStore.isConfigured()) {
            return simpleResult(false, "configuration_missing", "", "configuration_missing");
        }

        final RequestRecord request;
        try {
            request = RequestRecord.fromIncoming(requestJson);
        } catch (ValidationException error) {
            return simpleResult(false, "invalid_request", error.requestId,
                    error.errorCode);
        } catch (Exception ignored) {
            return simpleResult(false, "invalid_request", "", "invalid_json");
        }

        synchronized (operationLock) {
            if (store.hasKnownRequestId(request.requestId)) {
                return simpleResult(true, "duplicate", request.requestId, "");
            }

            List<RequestRecord> pending = store.loadRequests();
            request.enqueuedAt = nextEnqueuedAt(pending);
            List<RequestRecord> supersededCandidates = new ArrayList<>();
            if (!request.coalesceKey.isEmpty()) {
                for (RequestRecord older : pending) {
                    if (request.coalesceKey.equals(older.coalesceKey)
                            && SyncTransportContract.isSupersedableWaitingStatus(
                            older.status)) {
                        supersededCandidates.add(older);
                    }
                }
            }

            long bodyBytes = request.body.getBytes(StandardCharsets.UTF_8).length;
            long queuedBytes = 0L;
            int projectedRecords = pending.size() - supersededCandidates.size();
            for (RequestRecord item : pending) {
                if (!supersededCandidates.contains(item)) {
                    queuedBytes += item.body.getBytes(StandardCharsets.UTF_8).length;
                }
            }
            if (projectedRecords >= MAX_QUEUE_RECORDS
                    || queuedBytes + bodyBytes > MAX_QUEUE_BODY_BYTES) {
                return simpleResult(false, "queue_full", request.requestId, "queue_limit");
            }

            store.writeRequest(request);
            store.writeDedup(request.requestId, "pending");
            for (RequestRecord older : supersededCandidates) {
                completeSuperseded(older);
            }
        }
        triggerProcessing(0L);
        return simpleResult(true, "accepted", request.requestId, "");
    }

    String getStatus(String requestId) {
        String safeId = requestId == null ? "" : requestId.trim();
        if (!SyncTransportContract.isValidRequestId(safeId)) {
            return simpleResult(false, "unknown", safeId, "invalid_request_id");
        }
        synchronized (operationLock) {
            RequestRecord request = store.readRequest(safeId);
            if (request != null) {
                return request.statusJson();
            }
            ResultRecord result = store.readResult(safeId);
            if (result != null) {
                return result.toJson(true).toString();
            }
            DedupRecord dedup = store.readDedup(safeId);
            if (dedup != null) {
                return simpleResult(true, dedup.status, safeId, "result_acknowledged");
            }
        }
        return simpleResult(false, "unknown", safeId, "not_found");
    }

    String listPending() {
        JSONArray array = new JSONArray();
        synchronized (operationLock) {
            for (RequestRecord request : sorted(store.loadRequests())) {
                array.put(request.metadataJson());
            }
        }
        JSONObject output = new JSONObject();
        put(output, "ok", true);
        put(output, "status", "ok");
        put(output, "requests", array);
        return output.toString();
    }

    String retryPending() {
        int changed = 0;
        synchronized (operationLock) {
            long now = System.currentTimeMillis();
            for (RequestRecord request : store.loadRequests()) {
                if ("pending".equals(request.status)
                        || "failed_retryable".equals(request.status)) {
                    request.status = "pending";
                    request.nextAttemptAt = now;
                    request.errorCode = "";
                    request.httpStatus = 0;
                    store.writeRequest(request);
                    changed++;
                }
            }
        }
        triggerProcessing(0L);
        JSONObject output = new JSONObject();
        put(output, "ok", true);
        put(output, "status", "retry_scheduled");
        put(output, "count", changed);
        return output.toString();
    }

    String acknowledge(String requestId) {
        String safeId = requestId == null ? "" : requestId.trim();
        if (!SyncTransportContract.isValidRequestId(safeId)) {
            return simpleResult(false, "invalid_request", safeId, "invalid_request_id");
        }
        synchronized (operationLock) {
            ResultRecord result = store.readResult(safeId);
            if (result == null) {
                return simpleResult(false, "unknown", safeId, "result_not_found");
            }
            store.deleteResult(safeId);
        }
        return simpleResult(true, "acknowledged", safeId, "");
    }

    private void recoverInterruptedRequests() {
        synchronized (operationLock) {
            long now = System.currentTimeMillis();
            for (RequestRecord request : store.loadRequests()) {
                if ("running".equals(request.status)) {
                    request.status = "failed_retryable";
                    request.reconcileBeforeRetry = "PUT".equals(request.operation);
                    request.errorCode = "interrupted_while_running";
                    request.nextAttemptAt = now;
                    store.writeRequest(request);
                }
            }
            normalizeCoalescedRequests();
            store.pruneDedup();
        }
    }


    private void normalizeCoalescedRequests() {
        List<RequestRecord> requests = store.loadRequests();
        for (RequestRecord candidate : requests) {
            if (candidate.coalesceKey == null || candidate.coalesceKey.isEmpty()
                    || !SyncTransportContract.isSupersedableWaitingStatus(
                    candidate.status)) {
                continue;
            }
            RequestRecord newest = candidate;
            for (RequestRecord other : requests) {
                if (!candidate.requestId.equals(other.requestId)
                        && candidate.coalesceKey.equals(other.coalesceKey)
                        && SyncTransportContract.isSupersedableWaitingStatus(
                        other.status)
                        && SyncTransportContract.isNewerRequest(
                        newest.enqueuedAt, newest.requestId,
                        other.enqueuedAt, other.requestId)) {
                    newest = other;
                }
            }
            if (!candidate.requestId.equals(newest.requestId)
                    && store.readRequest(candidate.requestId) != null) {
                completeSuperseded(candidate);
            }
        }
    }

    private void registerNetworkCallback() {
        if (connectivityManager == null) {
            return;
        }
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                triggerProcessing(0L);
            }
        };
        try {
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception error) {
            watchdog.record("host.sync.network-callback", "warning",
                    "Nätverkscallback kunde inte registreras.", 0, false);
        }
    }

    private void triggerProcessing(long delayMs) {
        if (closed.get()) {
            return;
        }
        long safeDelay = Math.max(0L, delayMs);
        long target = System.currentTimeMillis() + safeDelay;
        synchronized (scheduleLock) {
            if (scheduledFuture != null && !scheduledFuture.isDone()
                    && scheduledAtEpochMs <= target) {
                return;
            }
            if (scheduledFuture != null && !scheduledFuture.isDone()) {
                scheduledFuture.cancel(false);
            }
            scheduledAtEpochMs = target;
            scheduledFuture = executor.schedule(() -> {
                synchronized (scheduleLock) {
                    scheduledFuture = null;
                    scheduledAtEpochMs = Long.MAX_VALUE;
                }
                processNext();
            }, safeDelay, TimeUnit.MILLISECONDS);
        }
    }

    private void processNext() {
        try {
            processNextInternal();
        } catch (Exception error) {
            requestRunning.set(false);
            watchdog.record("host.sync.worker-error", "warning",
                    "Synctransportens arbetskö återhämtade sig efter ett tekniskt fel.",
                    0, false);
            triggerProcessing(SyncTransportContract.INITIAL_RETRY_DELAY_MS);
        }
    }

    private void processNextInternal() {
        if (closed.get() || requestRunning.get()) {
            return;
        }
        SyncConfigurationStore.Configuration configuration =
                configurationStore.loadForTransport();
        if (configuration == null || !isNetworkAvailable()) {
            return;
        }

        RequestRecord request;
        long nextDelay = -1L;
        synchronized (operationLock) {
            List<RequestRecord> requests = sorted(store.loadRequests());
            long now = System.currentTimeMillis();
            request = null;
            for (RequestRecord candidate : requests) {
                if (("pending".equals(candidate.status)
                        || "failed_retryable".equals(candidate.status))
                        && candidate.nextAttemptAt <= now) {
                    request = candidate;
                    break;
                }
                if ("pending".equals(candidate.status)
                        || "failed_retryable".equals(candidate.status)) {
                    long delay = Math.max(0L, candidate.nextAttemptAt - now);
                    nextDelay = nextDelay < 0 ? delay : Math.min(nextDelay, delay);
                }
            }
            if (request == null) {
                if (nextDelay >= 0L) {
                    triggerProcessing(nextDelay);
                }
                return;
            }
            request.status = "running";
            request.runningAt = now;
            store.writeRequest(request);
            store.writeDedup(request.requestId, "running");
        }

        requestRunning.set(true);
        RequestRecord selected = request;
        try {
            TransportOutcome outcome = execute(configuration, selected);
            applyOutcome(selected, outcome);
        } finally {
            requestRunning.set(false);
        }
        triggerProcessing(0L);
    }

    private TransportOutcome execute(SyncConfigurationStore.Configuration configuration,
                                     RequestRecord request) {
        try {
            if (request.reconcileBeforeRetry && "PUT".equals(request.operation)) {
                TransportOutcome reconciliation = reconcilePut(configuration, request);
                if (reconciliation != null) {
                    return reconciliation;
                }
                request.reconcileBeforeRetry = false;
                synchronized (operationLock) {
                    store.writeRequest(request);
                }
            }
            return "GET".equals(request.operation)
                    ? executeGet(configuration, request)
                    : executePut(configuration, request);
        } catch (SocketTimeoutException error) {
            return TransportOutcome.retryable(0, "timeout", 0L);
        } catch (javax.net.ssl.SSLException error) {
            return TransportOutcome.permanent(0, "tls_error");
        } catch (java.net.UnknownHostException error) {
            return TransportOutcome.retryable(0, "dns_error", 0L);
        } catch (Exception error) {
            return TransportOutcome.retryable(0, "network_error", 0L);
        }
    }

    /**
     * Reconciles an ambiguously interrupted PUT before any retry. This prevents
     * duplicate GitHub writes after process death without interpreting file data.
     */
    private TransportOutcome reconcilePut(
            SyncConfigurationStore.Configuration configuration,
            RequestRecord request) throws Exception {
        HttpResponse response = performRequest(configuration, request, "GET", null);
        if (response.statusCode == 404 && request.expectedSha.isEmpty()) {
            return null;
        }
        if (response.statusCode == 200) {
            GitHubContent content = decodeGitHubContent(response.body);
            if (content != null
                    && MessageDigest.isEqual(
                    content.bytes,
                    request.body.getBytes(StandardCharsets.UTF_8))) {
                return TransportOutcome.succeeded(
                        200, "", content.sha, "reconciled_after_restart");
            }
            if (content != null && !request.expectedSha.isEmpty()
                    && request.expectedSha.equals(content.sha)) {
                return null;
            }
            return TransportOutcome.conflict(response.statusCode,
                    "ambiguous_write_conflict", content == null ? "" : content.sha);
        }
        if (isRetryableHttp(response.statusCode)) {
            return TransportOutcome.retryable(response.statusCode,
                    "reconcile_retryable", response.retryAfterMs);
        }
        return TransportOutcome.permanent(response.statusCode,
                "reconcile_failed");
    }

    private TransportOutcome executeGet(
            SyncConfigurationStore.Configuration configuration,
            RequestRecord request) throws Exception {
        HttpResponse response = performRequest(configuration, request, "GET", null);
        if (response.statusCode == 200) {
            GitHubContent content = decodeGitHubContent(response.body);
            if (content == null) {
                return TransportOutcome.permanent(200, "invalid_github_response");
            }
            if (content.bytes.length > MAX_RESPONSE_BODY_BYTES) {
                return TransportOutcome.permanent(200, "response_too_large");
            }
            return TransportOutcome.succeeded(200,
                    new String(content.bytes, StandardCharsets.UTF_8),
                    content.sha, "");
        }
        return classifyHttpFailure(response, request);
    }

    private TransportOutcome executePut(
            SyncConfigurationStore.Configuration configuration,
            RequestRecord request) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("message", "Stadslass sync " + request.requestId);
        payload.put("content", Base64.encodeToString(
                request.body.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP));
        payload.put("branch", configuration.branch);
        if (!request.expectedSha.isEmpty()) {
            payload.put("sha", request.expectedSha);
        }
        HttpResponse response = performRequest(
                configuration, request, "PUT",
                payload.toString().getBytes(StandardCharsets.UTF_8));
        if (response.statusCode == 200 || response.statusCode == 201) {
            String responseSha = "";
            try {
                JSONObject root = new JSONObject(response.body);
                JSONObject content = root.optJSONObject("content");
                if (content != null) {
                    responseSha = content.optString("sha", "");
                }
            } catch (Exception ignored) {
                // A successful GitHub response may omit content metadata.
            }
            return TransportOutcome.succeeded(response.statusCode,
                    "", responseSha, "");
        }
        return classifyHttpFailure(response, request);
    }

    private TransportOutcome classifyHttpFailure(HttpResponse response,
                                                  RequestRecord request) {
        if (response.statusCode == 409
                || (response.statusCode == 422 && !request.expectedSha.isEmpty())) {
            return TransportOutcome.conflict(response.statusCode,
                    "github_version_conflict", "");
        }
        if (isRetryableHttp(response.statusCode)) {
            return TransportOutcome.retryable(response.statusCode,
                    "github_retryable_http", response.retryAfterMs);
        }
        return TransportOutcome.permanent(response.statusCode,
                "github_http_" + response.statusCode);
    }

    private HttpResponse performRequest(
            SyncConfigurationStore.Configuration configuration,
            RequestRecord request,
            String method,
            byte[] requestBody) throws Exception {
        URL url = new URL(buildContentsUrl(configuration, request.path,
                "GET".equals(method) ? configuration.branch : ""));
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestMethod(method);
        connection.setRequestProperty("Accept", "application/vnd.github+json");
        connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
        connection.setRequestProperty("Authorization", "Bearer " + configuration.token);
        connection.setRequestProperty("User-Agent", "Stadslass-3.0-host-v14");
        connection.setUseCaches(false);
        if (requestBody != null) {
            connection.setDoOutput(true);
            connection.setFixedLengthStreamingMode(requestBody.length);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (java.io.OutputStream output = connection.getOutputStream()) {
                output.write(requestBody);
                output.flush();
            }
        }
        int status = connection.getResponseCode();
        if (status >= 300 && status < 400) {
            connection.disconnect();
            return new HttpResponse(status, "", 0L);
        }
        InputStream input = status >= 400
                ? connection.getErrorStream()
                : connection.getInputStream();
        String body = readLimited(input, MAX_RESPONSE_BODY_BYTES);
        long retryAfterMs = parseRetryAfter(connection.getHeaderField("Retry-After"));
        connection.disconnect();
        return new HttpResponse(status, body, retryAfterMs);
    }

    private void applyOutcome(RequestRecord request, TransportOutcome outcome) {
        synchronized (operationLock) {
            if (outcome.retryable) {
                if (hasNewerCoalescedRequest(request)) {
                    completeSuperseded(request);
                    return;
                }
                request.status = "failed_retryable";
                request.attemptCount += 1;
                request.httpStatus = outcome.httpStatus;
                request.errorCode = outcome.errorCode;
                request.runningAt = 0L;
                request.reconcileBeforeRetry =
                        SyncTransportContract.requiresReconcileBeforeRetry(
                                request.operation, true);
                long backoff = outcome.retryAfterMs > 0L
                        ? Math.min(outcome.retryAfterMs, SyncTransportContract.MAX_RETRY_DELAY_MS)
                        : SyncTransportContract.retryDelay(request.attemptCount);
                request.nextAttemptAt = System.currentTimeMillis() + backoff;
                store.writeRequest(request);
                store.writeDedup(request.requestId, "failed_retryable");
                watchdog.record("host.sync.retryable", "warning",
                        "Ett synkanrop väntar på kontrollerat återförsök. requestId="
                                + safeDiagnostic(request.requestId)
                                + ", http=" + outcome.httpStatus
                                + ", error=" + safeDiagnostic(outcome.errorCode),
                        0, false);
                triggerProcessing(backoff);
                return;
            }

            ResultRecord result = ResultRecord.terminal(
                    request.requestId,
                    outcome.status,
                    outcome.httpStatus,
                    outcome.responseBody,
                    outcome.responseSha,
                    outcome.errorCode);
            store.writeResult(result);
            store.writeDedup(request.requestId, outcome.status);
            store.deleteRequest(request.requestId);
            notifyResult(request.requestId, outcome.status);
            String severity = "succeeded".equals(outcome.status) ? "info" : "warning";
            watchdog.record("host.sync.result", severity,
                    "Synkanrop avslutades. requestId="
                            + safeDiagnostic(request.requestId)
                            + ", status=" + safeDiagnostic(outcome.status)
                            + ", http=" + outcome.httpStatus,
                    0, false);
        }
    }


    private boolean hasNewerCoalescedRequest(RequestRecord request) {
        if (request.coalesceKey == null || request.coalesceKey.isEmpty()) {
            return false;
        }
        for (RequestRecord candidate : store.loadRequests()) {
            if (!request.requestId.equals(candidate.requestId)
                    && request.coalesceKey.equals(candidate.coalesceKey)
                    && SyncTransportContract.isNewerRequest(
                    request.enqueuedAt, request.requestId,
                    candidate.enqueuedAt, candidate.requestId)) {
                return true;
            }
        }
        return false;
    }

    private void completeSuperseded(RequestRecord request) {
        ResultRecord superseded = ResultRecord.terminal(
                request.requestId, "superseded", 0,
                "", "", "superseded_by_newer_request");
        store.writeResult(superseded);
        store.writeDedup(request.requestId, "superseded");
        store.deleteRequest(request.requestId);
        notifyResult(request.requestId, "superseded");
    }

    private static long nextEnqueuedAt(List<RequestRecord> requests) {
        long next = System.currentTimeMillis();
        for (RequestRecord request : requests) {
            next = Math.max(next, request.enqueuedAt + 1L);
        }
        return next;
    }

    private void notifyResult(String requestId, String status) {
        if (resultListener == null) {
            return;
        }
        try {
            resultListener.onSyncResult(requestId, status);
        } catch (Exception ignored) {
            // Missed events are recoverable through getSyncRequestStatus().
        }
    }

    private boolean isNetworkAvailable() {
        if (connectivityManager == null) {
            return false;
        }
        try {
            Network network = connectivityManager.getActiveNetwork();
            if (network == null) {
                return false;
            }
            NetworkCapabilities capabilities =
                    connectivityManager.getNetworkCapabilities(network);
            return capabilities != null
                    && capabilities.hasCapability(
                    NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception ignored) {
            return false;
        }
    }

    private static List<RequestRecord> sorted(List<RequestRecord> requests) {
        List<RequestRecord> copy = new ArrayList<>(requests);
        Collections.sort(copy, Comparator
                .comparingInt((RequestRecord item) -> SyncTransportContract.priorityValue(item.priority))
                .thenComparingLong(item -> item.enqueuedAt)
                .thenComparing(item -> item.requestId));
        return copy;
    }



    private static boolean isRetryableHttp(int statusCode) {
        return statusCode == 408 || statusCode == 425 || statusCode == 429
                || statusCode == 500 || statusCode == 502
                || statusCode == 503 || statusCode == 504;
    }

    private static String buildContentsUrl(
            SyncConfigurationStore.Configuration configuration,
            String path,
            String branchForGet) {
        Uri.Builder builder = new Uri.Builder()
                .scheme("https")
                .authority("api.github.com")
                .appendPath("repos")
                .appendPath(configuration.owner)
                .appendPath(configuration.repository)
                .appendPath("contents");
        for (String segment : path.split("/")) {
            builder.appendPath(segment);
        }
        if (branchForGet != null && !branchForGet.isEmpty()) {
            builder.appendQueryParameter("ref", branchForGet);
        }
        return builder.build().toString();
    }

    private static GitHubContent decodeGitHubContent(String responseBody) {
        try {
            JSONObject root = new JSONObject(responseBody == null ? "" : responseBody);
            if (!"base64".equalsIgnoreCase(root.optString("encoding", ""))) {
                return null;
            }
            String encoded = root.optString("content", "").replace("\n", "");
            byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
            return new GitHubContent(bytes, root.optString("sha", ""));
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String readLimited(InputStream input, int maximumBytes) throws Exception {
        if (input == null) {
            return "";
        }
        try (InputStream source = input;
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = source.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) {
                    throw new IllegalArgumentException("response_too_large");
                }
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static long parseRetryAfter(String value) {
        if (value == null || value.trim().isEmpty()) {
            return 0L;
        }
        try {
            long seconds = Long.parseLong(value.trim());
            return Math.max(0L, seconds * 1000L);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private static String safeDiagnostic(String value) {
        if (value == null) {
            return "";
        }
        String safe = value.replaceAll("[^A-Za-z0-9._:-]", "_");
        return safe.length() <= 96 ? safe : safe.substring(0, 96);
    }

    private static String simpleResult(boolean ok,
                                       String status,
                                       String requestId,
                                       String errorCode) {
        JSONObject output = new JSONObject();
        put(output, "ok", ok);
        put(output, "status", status);
        put(output, "requestId", requestId == null ? "" : requestId);
        put(output, "errorCode", errorCode == null ? "" : errorCode);
        return output.toString();
    }

    private static void put(JSONObject target, String key, Object value) {
        try {
            target.put(key, value);
        } catch (Exception ignored) {
            // JSON result construction must not crash the host.
        }
    }

    private static final class RequestRecord {
        String requestId;
        String operation;
        String path;
        String priority;
        String channel;
        String createdAt;
        String body;
        String expectedSha;
        String coalesceKey;
        String status;
        long enqueuedAt;
        long runningAt;
        long nextAttemptAt;
        int attemptCount;
        int httpStatus;
        String errorCode;
        boolean reconcileBeforeRetry;

        static RequestRecord fromIncoming(String json) throws Exception {
            JSONObject input = new JSONObject(json == null ? "" : json);
            Set<String> allowed = new HashSet<>();
            Collections.addAll(allowed, "requestId", "operation", "path",
                    "priority", "channel", "createdAt", "body",
                    "expectedSha", "coalesceKey");
            JSONArray names = input.names();
            if (names != null) {
                for (int index = 0; index < names.length(); index++) {
                    if (!allowed.contains(names.optString(index))) {
                        throw new ValidationException(
                                input.optString("requestId", ""), "unexpected_field");
                    }
                }
            }

            RequestRecord record = new RequestRecord();
            record.requestId = input.optString("requestId", "").trim();
            if (!SyncTransportContract.isValidRequestId(record.requestId)) {
                throw new ValidationException(record.requestId, "invalid_request_id");
            }
            record.operation = input.optString("operation", "").trim()
                    .toUpperCase(Locale.ROOT);
            if (!"GET".equals(record.operation) && !"PUT".equals(record.operation)) {
                throw new ValidationException(record.requestId, "invalid_operation");
            }
            record.path = input.optString("path", "").trim();
            if (!SyncTransportContract.isValidPath(record.path)) {
                throw new ValidationException(record.requestId, "invalid_path");
            }
            record.priority = input.optString("priority", "").trim();
            if (!SyncTransportContract.isValidPriority(record.priority)) {
                throw new ValidationException(record.requestId, "invalid_priority");
            }
            record.channel = input.optString("channel", "").trim();
            if (!SyncTransportContract.isValidChannel(record.channel)) {
                throw new ValidationException(record.requestId, "invalid_channel");
            }
            record.createdAt = input.optString("createdAt", "").trim();
            if (record.createdAt.isEmpty() || record.createdAt.length() > 80
                    || SyncTransportContract.containsControlCharacter(record.createdAt)) {
                throw new ValidationException(record.requestId, "invalid_created_at");
            }
            Object bodyValue = input.opt("body");
            if (bodyValue == null || bodyValue == JSONObject.NULL) {
                record.body = "";
            } else if (bodyValue instanceof String) {
                record.body = (String) bodyValue;
            } else {
                throw new ValidationException(record.requestId, "body_must_be_string");
            }
            if (record.body.getBytes(StandardCharsets.UTF_8).length
                    > MAX_REQUEST_BODY_BYTES) {
                throw new ValidationException(record.requestId, "body_too_large");
            }
            if ("PUT".equals(record.operation) && !input.has("body")) {
                throw new ValidationException(record.requestId, "body_required");
            }
            record.expectedSha = input.optString("expectedSha", "").trim();
            if (!record.expectedSha.isEmpty()
                    && !record.expectedSha.matches("^[a-fA-F0-9]{40,64}$")) {
                throw new ValidationException(record.requestId, "invalid_expected_sha");
            }
            record.coalesceKey = input.optString("coalesceKey", "").trim();
            if (!record.coalesceKey.isEmpty()
                    && !SyncTransportContract.isValidCoalesceKey(record.coalesceKey)) {
                throw new ValidationException(record.requestId, "invalid_coalesce_key");
            }
            long now = System.currentTimeMillis();
            record.status = "pending";
            record.enqueuedAt = now;
            record.nextAttemptAt = now;
            record.errorCode = "";
            return record;
        }

        JSONObject toJson() {
            JSONObject output = new JSONObject();
            put(output, "requestId", requestId);
            put(output, "operation", operation);
            put(output, "path", path);
            put(output, "priority", priority);
            put(output, "channel", channel);
            put(output, "createdAt", createdAt);
            put(output, "body", body);
            put(output, "expectedSha", expectedSha);
            put(output, "coalesceKey", coalesceKey);
            put(output, "status", status);
            put(output, "enqueuedAt", enqueuedAt);
            put(output, "runningAt", runningAt);
            put(output, "nextAttemptAt", nextAttemptAt);
            put(output, "attemptCount", attemptCount);
            put(output, "httpStatus", httpStatus);
            put(output, "errorCode", errorCode);
            put(output, "reconcileBeforeRetry", reconcileBeforeRetry);
            return output;
        }

        static RequestRecord fromStored(JSONObject input) throws Exception {
            RequestRecord record = new RequestRecord();
            record.requestId = input.getString("requestId");
            record.operation = input.getString("operation");
            record.path = input.getString("path");
            record.priority = input.getString("priority");
            record.channel = input.getString("channel");
            record.createdAt = input.optString("createdAt", "");
            record.body = input.optString("body", "");
            record.expectedSha = input.optString("expectedSha", "");
            record.coalesceKey = input.optString("coalesceKey", "");
            record.status = input.optString("status", "pending");
            record.enqueuedAt = input.optLong("enqueuedAt", 0L);
            record.runningAt = input.optLong("runningAt", 0L);
            record.nextAttemptAt = input.optLong("nextAttemptAt", 0L);
            record.attemptCount = input.optInt("attemptCount", 0);
            record.httpStatus = input.optInt("httpStatus", 0);
            record.errorCode = input.optString("errorCode", "");
            record.reconcileBeforeRetry =
                    input.optBoolean("reconcileBeforeRetry", false);
            if (!SyncTransportContract.isValidRequestId(record.requestId)
                    || !SyncTransportContract.isValidPath(record.path)) {
                throw new IllegalArgumentException("Invalid stored request.");
            }
            return record;
        }

        JSONObject metadataJson() {
            JSONObject output = new JSONObject();
            put(output, "requestId", requestId);
            put(output, "operation", operation);
            put(output, "path", path.length() <= 160 ? path : path.substring(0, 160));
            put(output, "priority", priority);
            put(output, "channel", channel);
            put(output, "status", status);
            put(output, "createdAt", createdAt);
            put(output, "enqueuedAt", enqueuedAt);
            put(output, "nextAttemptAt", nextAttemptAt);
            put(output, "attemptCount", attemptCount);
            put(output, "httpStatus", httpStatus);
            put(output, "errorCode", errorCode);
            return output;
        }

        String statusJson() {
            JSONObject output = metadataJson();
            put(output, "ok", true);
            put(output, "completedAt", 0L);
            put(output, "responseBody", "");
            put(output, "responseSha", "");
            return output.toString();
        }
    }



    private static final class ResultRecord {
        String requestId;
        String status;
        int httpStatus;
        long completedAt;
        String responseBody;
        String responseSha;
        String errorCode;

        static ResultRecord terminal(String requestId,
                                     String status,
                                     int httpStatus,
                                     String responseBody,
                                     String responseSha,
                                     String errorCode) {
            ResultRecord result = new ResultRecord();
            result.requestId = requestId;
            result.status = status;
            result.httpStatus = httpStatus;
            result.completedAt = System.currentTimeMillis();
            result.responseBody = responseBody == null ? "" : responseBody;
            result.responseSha = responseSha == null ? "" : responseSha;
            result.errorCode = errorCode == null ? "" : errorCode;
            return result;
        }

        JSONObject toJson(boolean includeBody) {
            JSONObject output = new JSONObject();
            put(output, "ok", "succeeded".equals(status));
            put(output, "requestId", requestId);
            put(output, "status", status);
            put(output, "httpStatus", httpStatus);
            put(output, "completedAt", completedAt);
            put(output, "responseBody", includeBody ? responseBody : "");
            put(output, "responseSha", responseSha);
            put(output, "errorCode", errorCode);
            return output;
        }

        static ResultRecord fromStored(JSONObject input) throws Exception {
            ResultRecord result = new ResultRecord();
            result.requestId = input.getString("requestId");
            result.status = input.getString("status");
            result.httpStatus = input.optInt("httpStatus", 0);
            result.completedAt = input.optLong("completedAt", 0L);
            result.responseBody = input.optString("responseBody", "");
            result.responseSha = input.optString("responseSha", "");
            result.errorCode = input.optString("errorCode", "");
            return result;
        }
    }

    private static final class DedupRecord {
        String requestId;
        String status;
        long updatedAt;

        JSONObject toJson() {
            JSONObject output = new JSONObject();
            put(output, "requestId", requestId);
            put(output, "status", status);
            put(output, "updatedAt", updatedAt);
            return output;
        }

        static DedupRecord fromStored(JSONObject input) throws Exception {
            DedupRecord record = new DedupRecord();
            record.requestId = input.getString("requestId");
            record.status = input.optString("status", "unknown");
            record.updatedAt = input.optLong("updatedAt", 0L);
            return record;
        }
    }

    private static final class PersistentStore {
        private final File requestDirectory;
        private final File resultDirectory;
        private final File dedupDirectory;
        private final SecurePayloadCipher cipher;
        private final HostWatchdog watchdog;

        PersistentStore(Context context, HostWatchdog watchdog) {
            File root = new File(context.getNoBackupFilesDir(), "sync-transport-v1");
            requestDirectory = new File(root, "requests");
            resultDirectory = new File(root, "results");
            dedupDirectory = new File(root, "dedup");
            requestDirectory.mkdirs();
            resultDirectory.mkdirs();
            dedupDirectory.mkdirs();
            cipher = new SecurePayloadCipher("stadslass_sync_transport_payload_v1");
            this.watchdog = watchdog;
        }

        synchronized void writeRequest(RequestRecord record) {
            writeEncrypted(fileFor(requestDirectory, record.requestId),
                    record.toJson().toString());
        }

        synchronized RequestRecord readRequest(String requestId) {
            try {
                String json = readEncrypted(fileFor(requestDirectory, requestId));
                return json == null ? null
                        : RequestRecord.fromStored(new JSONObject(json));
            } catch (Exception error) {
                quarantine(fileFor(requestDirectory, requestId), "request");
                return null;
            }
        }

        synchronized List<RequestRecord> loadRequests() {
            List<RequestRecord> records = new ArrayList<>();
            File[] files = requestDirectory.listFiles(
                    file -> file.isFile() && file.getName().endsWith(".enc"));
            if (files == null) {
                return records;
            }
            for (File file : files) {
                try {
                    String json = readEncrypted(file);
                    if (json != null) {
                        records.add(RequestRecord.fromStored(new JSONObject(json)));
                    }
                } catch (Exception error) {
                    quarantine(file, "request");
                }
            }
            return records;
        }

        synchronized void deleteRequest(String requestId) {
            delete(fileFor(requestDirectory, requestId));
        }

        synchronized void writeResult(ResultRecord result) {
            writeEncrypted(fileFor(resultDirectory, result.requestId),
                    result.toJson(true).toString());
        }

        synchronized ResultRecord readResult(String requestId) {
            try {
                String json = readEncrypted(fileFor(resultDirectory, requestId));
                return json == null ? null
                        : ResultRecord.fromStored(new JSONObject(json));
            } catch (Exception error) {
                quarantine(fileFor(resultDirectory, requestId), "result");
                return null;
            }
        }

        synchronized void deleteResult(String requestId) {
            delete(fileFor(resultDirectory, requestId));
        }

        synchronized void writeDedup(String requestId, String status) {
            DedupRecord record = new DedupRecord();
            record.requestId = requestId;
            record.status = status;
            record.updatedAt = System.currentTimeMillis();
            writeEncrypted(fileFor(dedupDirectory, requestId),
                    record.toJson().toString());
            pruneDedup();
        }

        synchronized DedupRecord readDedup(String requestId) {
            try {
                String json = readEncrypted(fileFor(dedupDirectory, requestId));
                return json == null ? null
                        : DedupRecord.fromStored(new JSONObject(json));
            } catch (Exception error) {
                quarantine(fileFor(dedupDirectory, requestId), "dedup");
                return null;
            }
        }

        synchronized boolean hasKnownRequestId(String requestId) {
            return fileFor(requestDirectory, requestId).isFile()
                    || fileFor(resultDirectory, requestId).isFile()
                    || fileFor(dedupDirectory, requestId).isFile();
        }

        synchronized void pruneDedup() {
            File[] files = dedupDirectory.listFiles(
                    file -> file.isFile() && file.getName().endsWith(".enc"));
            if (files == null || files.length == 0) {
                return;
            }
            List<DedupFile> candidates = new ArrayList<>();
            long cutoff = System.currentTimeMillis() - DEDUP_RETENTION_MS;
            for (File file : files) {
                try {
                    String json = readEncrypted(file);
                    DedupRecord record = DedupRecord.fromStored(new JSONObject(json));
                    if (record.updatedAt < cutoff
                            && !fileFor(requestDirectory, record.requestId).isFile()
                            && !fileFor(resultDirectory, record.requestId).isFile()) {
                        delete(file);
                    } else {
                        candidates.add(new DedupFile(file, record.updatedAt,
                                record.requestId));
                    }
                } catch (Exception error) {
                    quarantine(file, "dedup");
                }
            }
            if (candidates.size() <= MAX_DEDUP_RECORDS) {
                return;
            }
            Collections.sort(candidates,
                    Comparator.comparingLong(item -> item.updatedAt));
            int remove = candidates.size() - MAX_DEDUP_RECORDS;
            for (DedupFile candidate : candidates) {
                if (remove <= 0) {
                    break;
                }
                if (!fileFor(requestDirectory, candidate.requestId).isFile()
                        && !fileFor(resultDirectory, candidate.requestId).isFile()) {
                    delete(candidate.file);
                    remove--;
                }
            }
        }

        private void writeEncrypted(File file, String plainJson) {
            FileOutputStream output = null;
            AtomicFile atomicFile = new AtomicFile(file);
            try {
                byte[] bytes = cipher.encryptUtf8(plainJson)
                        .getBytes(StandardCharsets.UTF_8);
                output = atomicFile.startWrite();
                output.write(bytes);
                output.flush();
                output.getFD().sync();
                atomicFile.finishWrite(output);
            } catch (Exception error) {
                if (output != null) {
                    atomicFile.failWrite(output);
                }
                throw new IllegalStateException("Krypterad syncpost kunde inte sparas.");
            }
        }

        private String readEncrypted(File file) throws Exception {
            if (!file.isFile() || file.length() <= 0 || file.length() > 3L * 1024L * 1024L) {
                return null;
            }
            AtomicFile atomicFile = new AtomicFile(file);
            try (FileInputStream input = atomicFile.openRead();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int total = 0;
                int read;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > 3 * 1024 * 1024) {
                        throw new IllegalArgumentException("encrypted_record_too_large");
                    }
                    output.write(buffer, 0, read);
                }
                return cipher.decryptUtf8(
                        output.toString(StandardCharsets.UTF_8.name()));
            }
        }

        private void quarantine(File file, String kind) {
            if (file == null || !file.exists()) {
                return;
            }
            File target = new File(file.getParentFile(),
                    file.getName() + ".corrupt-" + System.currentTimeMillis());
            boolean moved = file.renameTo(target);
            watchdog.record("host.sync.corrupt-record", "warning",
                    "En skadad teknisk " + kind
                            + "post isolerades. moved=" + moved,
                    0, false);
        }

        private static File fileFor(File directory, String requestId) {
            return new File(directory, sha256(requestId) + ".enc");
        }

        private static String sha256(String value) {
            try {
                byte[] digest = MessageDigest.getInstance("SHA-256")
                        .digest(value.getBytes(StandardCharsets.UTF_8));
                StringBuilder output = new StringBuilder();
                for (byte item : digest) {
                    output.append(String.format(Locale.ROOT, "%02x", item & 0xff));
                }
                return output.toString();
            } catch (Exception error) {
                throw new IllegalStateException("SHA-256 saknas.");
            }
        }

        private static void delete(File file) {
            if (file != null && file.exists() && !file.delete()) {
                throw new IllegalStateException("Teknisk syncpost kunde inte tas bort.");
            }
        }
    }

    private static final class DedupFile {
        final File file;
        final long updatedAt;
        final String requestId;

        DedupFile(File file, long updatedAt, String requestId) {
            this.file = file;
            this.updatedAt = updatedAt;
            this.requestId = requestId;
        }
    }

    private static final class GitHubContent {
        final byte[] bytes;
        final String sha;

        GitHubContent(byte[] bytes, String sha) {
            this.bytes = bytes;
            this.sha = sha;
        }
    }

    private static final class HttpResponse {
        final int statusCode;
        final String body;
        final long retryAfterMs;

        HttpResponse(int statusCode, String body, long retryAfterMs) {
            this.statusCode = statusCode;
            this.body = body == null ? "" : body;
            this.retryAfterMs = retryAfterMs;
        }
    }

    private static final class TransportOutcome {
        final String status;
        final int httpStatus;
        final String responseBody;
        final String responseSha;
        final String errorCode;
        final boolean retryable;
        final long retryAfterMs;

        TransportOutcome(String status,
                         int httpStatus,
                         String responseBody,
                         String responseSha,
                         String errorCode,
                         boolean retryable,
                         long retryAfterMs) {
            this.status = status;
            this.httpStatus = httpStatus;
            this.responseBody = responseBody == null ? "" : responseBody;
            this.responseSha = responseSha == null ? "" : responseSha;
            this.errorCode = errorCode == null ? "" : errorCode;
            this.retryable = retryable;
            this.retryAfterMs = retryAfterMs;
        }

        static TransportOutcome succeeded(int httpStatus,
                                          String responseBody,
                                          String responseSha,
                                          String errorCode) {
            return new TransportOutcome("succeeded", httpStatus,
                    responseBody, responseSha, errorCode, false, 0L);
        }

        static TransportOutcome conflict(int httpStatus,
                                         String errorCode,
                                         String responseSha) {
            return new TransportOutcome("conflict", httpStatus,
                    "", responseSha, errorCode, false, 0L);
        }

        static TransportOutcome permanent(int httpStatus, String errorCode) {
            return new TransportOutcome("failed_permanent", httpStatus,
                    "", "", errorCode, false, 0L);
        }

        static TransportOutcome retryable(int httpStatus,
                                          String errorCode,
                                          long retryAfterMs) {
            return new TransportOutcome("failed_retryable", httpStatus,
                    "", "", errorCode, true, retryAfterMs);
        }
    }

    private static final class ValidationException extends Exception {
        final String requestId;
        final String errorCode;

        ValidationException(String requestId, String errorCode) {
            this.requestId = requestId == null ? "" : requestId;
            this.errorCode = errorCode;
        }
    }
}
