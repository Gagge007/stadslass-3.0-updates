package se.gagge007.stadslass.v3;

import java.nio.charset.StandardCharsets;

/** Pure UTF-8 mailto builder so encoding can be tested without Android UI. */
final class MailtoUriBuilder {
    private MailtoUriBuilder() {
    }

    static String build(String recipient, String subject, String body) {
        StringBuilder output = new StringBuilder("mailto:");
        output.append(percentEncode(recipient == null ? "" : recipient, true));
        boolean hasQuery = false;
        if (subject != null && !subject.isEmpty()) {
            output.append("?subject=").append(percentEncode(subject, false));
            hasQuery = true;
        }
        if (body != null && !body.isEmpty()) {
            output.append(hasQuery ? "&body=" : "?body=")
                    .append(percentEncode(body, false));
        }
        return output.toString();
    }

    static String percentEncode(String value, boolean recipientMode) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        StringBuilder output = new StringBuilder(bytes.length * 3);
        for (byte item : bytes) {
            int valueByte = item & 0xff;
            char character = (char) valueByte;
            if (isUnreserved(character)
                    || (recipientMode && isRecipientSafe(character))) {
                output.append(character);
            } else {
                output.append('%');
                output.append(toHex((valueByte >>> 4) & 0x0f));
                output.append(toHex(valueByte & 0x0f));
            }
        }
        return output.toString();
    }

    private static boolean isUnreserved(char value) {
        return (value >= 'A' && value <= 'Z')
                || (value >= 'a' && value <= 'z')
                || (value >= '0' && value <= '9')
                || value == '-' || value == '.' || value == '_'
                || value == '~';
    }

    private static boolean isRecipientSafe(char value) {
        return value == '@' || value == '+' || value == ',' || value == ';';
    }

    private static char toHex(int value) {
        return "0123456789ABCDEF".charAt(value & 0x0f);
    }
}
