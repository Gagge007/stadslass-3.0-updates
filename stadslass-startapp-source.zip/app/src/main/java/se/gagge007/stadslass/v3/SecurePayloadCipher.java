package se.gagge007.stadslass.v3;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Small Android Keystore-backed AES/GCM helper used only by the host's
 * sync credential and transport stores. It never exposes key material.
 */
final class SecurePayloadCipher {
    private static final String ANDROID_KEY_STORE = "AndroidKeyStore";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BITS = 128;

    private final String alias;

    SecurePayloadCipher(String alias) {
        this.alias = alias;
    }

    synchronized String encryptUtf8(String plainText) throws Exception {
        byte[] plain = plainText == null
                ? new byte[0]
                : plainText.getBytes(StandardCharsets.UTF_8);
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] encrypted = cipher.doFinal(plain);

        JSONObject envelope = new JSONObject();
        envelope.put("v", 1);
        envelope.put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
        envelope.put("data", Base64.encodeToString(encrypted, Base64.NO_WRAP));
        return envelope.toString();
    }

    synchronized String decryptUtf8(String envelopeText) throws Exception {
        JSONObject envelope = new JSONObject(envelopeText == null ? "" : envelopeText);
        if (envelope.optInt("v", 0) != 1) {
            throw new IllegalArgumentException("Okänd krypteringsversion.");
        }
        byte[] iv = Base64.decode(envelope.getString("iv"), Base64.DEFAULT);
        byte[] encrypted = Base64.decode(envelope.getString("data"), Base64.DEFAULT);
        if (iv.length < 12 || iv.length > 32 || encrypted.length < 16) {
            throw new IllegalArgumentException("Krypterad data har ogiltig struktur.");
        }
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, getExistingKey(),
                new GCMParameterSpec(TAG_LENGTH_BITS, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    synchronized boolean keyExists() {
        try {
            KeyStore keyStore = KeyStore.getInstance(ANDROID_KEY_STORE);
            keyStore.load(null);
            return keyStore.containsAlias(alias);
        } catch (Exception ignored) {
            return false;
        }
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEY_STORE);
        keyStore.load(null);
        if (keyStore.containsAlias(alias)) {
            return (SecretKey) keyStore.getKey(alias, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE);
        generator.init(new KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private SecretKey getExistingKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEY_STORE);
        keyStore.load(null);
        if (!keyStore.containsAlias(alias)) {
            throw new IllegalStateException("Krypteringsnyckeln saknas.");
        }
        SecretKey key = (SecretKey) keyStore.getKey(alias, null);
        if (key == null) {
            throw new IllegalStateException("Krypteringsnyckeln kunde inte läsas.");
        }
        return key;
    }
}
