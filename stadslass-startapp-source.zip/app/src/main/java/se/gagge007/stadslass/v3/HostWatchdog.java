package se.gagge007.stadslass.v3;

import android.content.Context;
import android.util.AtomicFile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.UUID;

/**
 * Minimal host-level watchdog. It records only technical startup/update state.
 * It never reads or modifies queue, active job, history, settings or sync data.
 */
final class HostWatchdog {
    private static final int SCHEMA_VERSION = 1;
    private static final int MAX_EVENTS = 80;
    private static final int MAX_DETAIL_LENGTH = 1200;
    private static final int MAX_FILE_BYTES = 256 * 1024;

    private final AtomicFile atomicFile;
    private JSONObject root;

    HostWatchdog(Context context) {
        File directory = new File(context.getFilesDir(), "stadslass-watchdog");
        if (!directory.exists()) {
            directory.mkdirs();
        }
        atomicFile = new AtomicFile(new File(directory, "host-watchdog.json"));
        root = loadRoot();
    }

    synchronized void startSession(String hostVersionName, int hostVersionCode) {
        JSONObject previous = root.optJSONObject("currentSession");
        if (previous != null && !"ready".equals(previous.optString("status"))) {
            put(root, "previousFailure", cloneObject(previous));
        }

        JSONObject session = new JSONObject();
        put(session, "sessionId", UUID.randomUUID().toString());
        put(session, "startedAtEpochMs", System.currentTimeMillis());
        put(session, "updatedAtEpochMs", System.currentTimeMillis());
        put(session, "hostVersionName", safe(hostVersionName, 120));
        put(session, "hostVersionCode", hostVersionCode);
        put(session, "status", "starting");
        put(session, "lastPhase", "host.session.start");
        put(session, "lastSeverity", "info");
        put(session, "fallbackUsed", false);
        put(session, "events", new JSONArray());

        put(root, "schemaVersion", SCHEMA_VERSION);
        put(root, "currentSession", session);
        appendEvent(session, "host.session.start", "info",
                "Ny värdsession startad.", 0, false);
        persist();
    }

    synchronized void record(String phase,
                             String severity,
                             String detail,
                             int packageVersion,
                             boolean candidate) {
        JSONObject session = requireSession();
        String safeSeverity = normalizeSeverity(severity);
        appendEvent(session, phase, safeSeverity, detail, packageVersion, candidate);
        put(session, "lastPhase", safe(phase, 120));
        put(session, "lastSeverity", safeSeverity);
        put(session, "updatedAtEpochMs", System.currentTimeMillis());
        if ("fatal".equals(safeSeverity)) {
            put(session, "status", "failed");
            put(root, "previousFailure", cloneObject(session));
        } else if ("warning".equals(safeSeverity)
                && "starting".equals(session.optString("status"))) {
            put(session, "status", "degraded");
        }
        persist();
    }

    synchronized void markFallback(String detail, int packageVersion) {
        JSONObject session = requireSession();
        put(session, "fallbackUsed", true);
        put(session, "status", "fallback");
        appendEvent(session, "host.module.fallback", "warning", detail,
                packageVersion, false);
        put(session, "lastPhase", "host.module.fallback");
        put(session, "lastSeverity", "warning");
        put(session, "updatedAtEpochMs", System.currentTimeMillis());
        persist();
    }

    synchronized void markReady(String phase, int packageVersion, String detail) {
        JSONObject session = requireSession();
        appendEvent(session, phase, "info", detail, packageVersion, false);
        String previousStatus = session.optString("status", "starting");
        if ("failed".equals(previousStatus)) {
            put(session, "status", "ready-with-error");
        } else if ("fallback".equals(previousStatus)) {
            put(session, "status", "ready-with-fallback");
        } else {
            put(session, "status", "ready");
        }
        put(session, "lastPhase", safe(phase, 120));
        put(session, "lastSeverity", "info");
        put(session, "readyAtEpochMs", System.currentTimeMillis());
        put(session, "updatedAtEpochMs", System.currentTimeMillis());
        persist();
    }

    synchronized String summary() {
        JSONObject session = root.optJSONObject("currentSession");
        if (session == null) {
            return "Ingen Watchdog-session";
        }
        String status = session.optString("status", "okänd");
        String phase = session.optString("lastPhase", "okänd fas");
        return statusLabel(status) + " · " + phase;
    }

    synchronized String userStatus() {
        JSONObject session = root.optJSONObject("currentSession");
        if (session == null) {
            return "Startar";
        }
        String status = session.optString("status", "starting");
        String severity = session.optString("lastSeverity", "info");
        if ("fatal".equals(severity) || "failed".equals(status)
                || "ready-with-error".equals(status)) {
            return "Fel";
        }
        if ("fallback".equals(status) || "ready-with-fallback".equals(status)) {
            return "Reservläge";
        }
        if ("warning".equals(severity) || "degraded".equals(status)) {
            return "Varning";
        }
        if ("ready".equals(status)) {
            return "Redo";
        }
        return "Startar";
    }

    synchronized String userMessage() {
        JSONObject session = root.optJSONObject("currentSession");
        if (session == null) {
            return "";
        }
        String phase = session.optString("lastPhase", "");
        String severity = session.optString("lastSeverity", "info");
        if ("runtime.ata.mail.open-failed".equals(phase)
                || "host.emailDraft.no-app".equals(phase)
                || "host.emailDraft.error".equals(phase)) {
            return "Mailutkastet kunde inte öppnas.";
        }
        if ("warning".equals(severity)) {
            return "En teknisk varning finns. Kopiera Watchdog-rapporten för detaljer.";
        }
        if ("fatal".equals(severity)) {
            return "Ett tekniskt fel har registrerats. Kopiera Watchdog-rapporten för detaljer.";
        }
        return "";
    }

    synchronized String buildReport(String role,
                                    String deviceId,
                                    int activePackageVersion,
                                    String updateStatus,
                                    String runtimeReport) {
        StringBuilder report = new StringBuilder();
        report.append("STADSLASS 3.0 WATCHDOG-RAPPORT\n");
        report.append("Skapad epoch ms: ").append(System.currentTimeMillis()).append('\n');
        report.append("Roll: ").append(safe(role, 120)).append('\n');
        report.append("Enhets-ID: ").append(safe(deviceId, 200)).append('\n');
        report.append("Aktivt funktionspaket: ").append(activePackageVersion).append('\n');
        report.append("Uppdateringsstatus: ").append(safe(updateStatus, 1200)).append("\n\n");
        report.append("VÄRD-WATCHDOG\n");
        try {
            report.append(root.toString(2));
        } catch (Exception ignored) {
            report.append(root.toString());
        }
        report.append('\n');
        String safeRuntime = runtimeReport == null ? "" : runtimeReport.trim();
        if (!safeRuntime.isEmpty()) {
            if (safeRuntime.length() > 64 * 1024) {
                safeRuntime = safeRuntime.substring(0, 64 * 1024);
            }
            report.append("\nRUNTIME-WATCHDOG\n").append(safeRuntime).append('\n');
        }
        return report.toString();
    }

    private JSONObject requireSession() {
        JSONObject session = root.optJSONObject("currentSession");
        if (session == null) {
            startSession("okänd", 0);
            session = root.optJSONObject("currentSession");
        }
        return session == null ? new JSONObject() : session;
    }

    private void appendEvent(JSONObject session,
                             String phase,
                             String severity,
                             String detail,
                             int packageVersion,
                             boolean candidate) {
        JSONArray events = session.optJSONArray("events");
        if (events == null) {
            events = new JSONArray();
            put(session, "events", events);
        }
        JSONObject event = new JSONObject();
        put(event, "atEpochMs", System.currentTimeMillis());
        put(event, "phase", safe(phase, 120));
        put(event, "severity", normalizeSeverity(severity));
        put(event, "detail", safe(detail, MAX_DETAIL_LENGTH));
        put(event, "packageVersion", packageVersion);
        put(event, "candidate", candidate);
        events.put(event);
        while (events.length() > MAX_EVENTS) {
            events.remove(0);
        }
    }

    private JSONObject loadRoot() {
        File base = atomicFile.getBaseFile();
        if (!base.exists() || !base.isFile() || base.length() <= 0
                || base.length() > MAX_FILE_BYTES) {
            return emptyRoot();
        }
        try (FileInputStream input = atomicFile.openRead();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_FILE_BYTES) {
                    return emptyRoot();
                }
                output.write(buffer, 0, read);
            }
            JSONObject loaded = new JSONObject(
                    output.toString(StandardCharsets.UTF_8.name()));
            if (loaded.optInt("schemaVersion", 0) != SCHEMA_VERSION) {
                return emptyRoot();
            }
            return loaded;
        } catch (Exception ignored) {
            return emptyRoot();
        }
    }

    private JSONObject emptyRoot() {
        JSONObject empty = new JSONObject();
        put(empty, "schemaVersion", SCHEMA_VERSION);
        return empty;
    }

    private void persist() {
        FileOutputStream output = null;
        try {
            byte[] bytes = root.toString().getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_FILE_BYTES) {
                JSONObject session = root.optJSONObject("currentSession");
                if (session != null) {
                    put(session, "events", tail(session.optJSONArray("events"), 30));
                }
                bytes = root.toString().getBytes(StandardCharsets.UTF_8);
            }
            output = atomicFile.startWrite();
            output.write(bytes);
            output.flush();
            output.getFD().sync();
            atomicFile.finishWrite(output);
        } catch (Exception ignored) {
            if (output != null) {
                atomicFile.failWrite(output);
            }
        }
    }

    private static JSONArray tail(JSONArray source, int maximum) {
        JSONArray result = new JSONArray();
        if (source == null) {
            return result;
        }
        int start = Math.max(0, source.length() - maximum);
        for (int index = start; index < source.length(); index++) {
            result.put(source.opt(index));
        }
        return result;
    }

    private static JSONObject cloneObject(JSONObject input) {
        try {
            return new JSONObject(input.toString());
        } catch (Exception ignored) {
            return new JSONObject();
        }
    }

    private static void put(JSONObject target, String key, Object value) {
        try {
            target.put(key, value);
        } catch (Exception ignored) {
            // Diagnostics must never crash or block normal app operation.
        }
    }

    private static String normalizeSeverity(String severity) {
        String value = severity == null ? "info"
                : severity.trim().toLowerCase(Locale.ROOT);
        if ("warning".equals(value) || "fatal".equals(value)) {
            return value;
        }
        return "info";
    }

    private static String statusLabel(String status) {
        if ("ready".equals(status)) {
            return "Redo";
        }
        if ("ready-with-error".equals(status)) {
            return "Värd redo · modulfel registrerat";
        }
        if ("ready-with-fallback".equals(status)) {
            return "Redo med reservpaket";
        }
        if ("failed".equals(status)) {
            return "Fel upptäckt";
        }
        if ("fallback".equals(status)) {
            return "Reservpaket används";
        }
        if ("degraded".equals(status)) {
            return "Varning";
        }
        return "Startar";
    }

    private static String safe(String value, int maximumLength) {
        String text = value == null ? "" : value.trim();
        text = text.replace('\u0000', ' ');
        if (text.length() > maximumLength) {
            return text.substring(0, maximumLength);
        }
        return text;
    }
}
