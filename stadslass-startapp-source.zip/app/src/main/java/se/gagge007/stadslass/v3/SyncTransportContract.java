package se.gagge007.stadslass.v3;

import java.util.Locale;
import java.util.regex.Pattern;

/** Pure validation and scheduling rules shared by the Android transport. */
final class SyncTransportContract {
    static final int MAX_REQUEST_ID_LENGTH = 160;
    static final int MAX_CHANNEL_LENGTH = 120;
    static final int MAX_COALESCE_KEY_LENGTH = 180;
    static final int MAX_PATH_LENGTH = 512;
    static final long INITIAL_RETRY_DELAY_MS = 5_000L;
    static final long MAX_RETRY_DELAY_MS = 15L * 60L * 1000L;

    private static final Pattern REQUEST_ID_PATTERN =
            Pattern.compile("^[A-Za-z0-9._:-]{1,160}$");
    private static final Pattern CHANNEL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._:/-]{1,120}$");
    private static final Pattern COALESCE_PATTERN =
            Pattern.compile("^[A-Za-z0-9._:/-]{1,180}$");
    private static final Pattern PATH_PATTERN =
            Pattern.compile("^[A-Za-z0-9._/-]{1,512}$");

    private SyncTransportContract() {
    }

    static boolean isValidRequestId(String value) {
        return value != null && REQUEST_ID_PATTERN.matcher(value).matches();
    }

    static boolean isValidChannel(String value) {
        return value != null && CHANNEL_PATTERN.matcher(value).matches();
    }

    static boolean isValidCoalesceKey(String value) {
        return value != null && (value.isEmpty()
                || COALESCE_PATTERN.matcher(value).matches());
    }

    static boolean isValidPath(String path) {
        if (path == null || !PATH_PATTERN.matcher(path).matches()
                || path.length() > MAX_PATH_LENGTH
                || path.startsWith("/") || path.endsWith("/")
                || path.contains("..") || path.contains("//")
                || path.contains("\\") || path.contains(":")
                || path.contains("?") || path.contains("#")
                || path.toLowerCase(Locale.ROOT).startsWith("http")) {
            return false;
        }
        for (String segment : path.split("/")) {
            if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment)) {
                return false;
            }
        }
        return true;
    }

    static int priorityValue(String priority) {
        if ("fast_lane".equals(priority)) {
            return 0;
        }
        if ("active_work".equals(priority)) {
            return 1;
        }
        if ("shared_queue".equals(priority)) {
            return 2;
        }
        if ("on_demand".equals(priority)) {
            return 3;
        }
        return Integer.MAX_VALUE;
    }

    static boolean isValidPriority(String priority) {
        return priorityValue(priority) != Integer.MAX_VALUE;
    }

    static boolean isSupersedableWaitingStatus(String status) {
        return "pending".equals(status) || "failed_retryable".equals(status);
    }

    static boolean isNewerRequest(long existingEnqueuedAt,
                                  String existingRequestId,
                                  long candidateEnqueuedAt,
                                  String candidateRequestId) {
        if (candidateEnqueuedAt != existingEnqueuedAt) {
            return candidateEnqueuedAt > existingEnqueuedAt;
        }
        String existing = existingRequestId == null ? "" : existingRequestId;
        String candidate = candidateRequestId == null ? "" : candidateRequestId;
        return candidate.compareTo(existing) > 0;
    }

    static boolean requiresReconcileBeforeRetry(String operation,
                                                 boolean retryable) {
        return retryable && "PUT".equals(operation);
    }

    static long retryDelay(int attemptCount) {
        int exponent = Math.min(8, Math.max(0, attemptCount - 1));
        long delay = INITIAL_RETRY_DELAY_MS * (1L << exponent);
        return Math.min(delay, MAX_RETRY_DELAY_MS);
    }

    static boolean containsControlCharacter(String value) {
        if (value == null) {
            return false;
        }
        for (int index = 0; index < value.length(); index++) {
            if (Character.isISOControl(value.charAt(index))) {
                return true;
            }
        }
        return false;
    }
}
