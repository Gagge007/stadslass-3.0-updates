package se.gagge007.stadslass.v3;

import android.content.Context;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

final class ModuleInstaller {
    private static final int MAX_ARCHIVE_ENTRIES = 128;
    private static final long MAX_ENTRY_BYTES = 2L * 1024L * 1024L;
    private static final long MAX_TOTAL_UNCOMPRESSED_BYTES = 8L * 1024L * 1024L;

    private final File modulesRoot;
    private final File currentDirectory;
    private final File backupDirectory;
    private final File candidateDirectory;

    ModuleInstaller(Context context) {
        modulesRoot = new File(context.getFilesDir(), "stadslass-modules");
        currentDirectory = new File(modulesRoot, "current");
        backupDirectory = new File(modulesRoot, "backup");
        candidateDirectory = new File(modulesRoot, "candidate");
    }

    synchronized ModulePackage loadCurrent() {
        return tryLoad(currentDirectory);
    }

    synchronized ModulePackage loadBackup() {
        return tryLoad(backupDirectory);
    }

    synchronized ModulePackage loadCurrentOrBackup() {
        ModulePackage current = loadCurrent();
        if (current != null) {
            return current;
        }
        return loadBackup();
    }

    synchronized ModulePackage rollbackToBackup() throws Exception {
        ModulePackage backup = ModulePackage.loadAndValidate(backupDirectory);
        if (!modulesRoot.exists() && !modulesRoot.mkdirs()) {
            throw new IllegalStateException("Modulkatalogen kunde inte skapas.");
        }

        File quarantine = new File(modulesRoot,
                "failed-runtime-" + UUID.randomUUID());
        File backupCopy = new File(modulesRoot,
                "backup-temp-" + UUID.randomUUID());
        boolean currentMoved = false;
        boolean backupBecameCurrent = false;
        boolean copyBecameBackup = false;

        // Prepare and verify a second copy before changing current/backup names.
        // This keeps the swap reversible even if storage or rename operations fail.
        copyDirectory(backupDirectory, backupCopy);
        ModulePackage preparedBackup = ModulePackage.loadAndValidate(backupCopy);
        if (preparedBackup.packageVersion != backup.packageVersion) {
            deleteRecursively(backupCopy);
            throw new SecurityException("Den förberedda reservkopian fick fel version.");
        }

        try {
            if (currentDirectory.exists()) {
                if (!currentDirectory.renameTo(quarantine)) {
                    throw new IllegalStateException(
                            "Det felande aktuella paketet kunde inte isoleras.");
                }
                currentMoved = true;
            }

            if (!backupDirectory.renameTo(currentDirectory)) {
                throw new IllegalStateException(
                        "Reservpaketet kunde inte göras aktuellt.");
            }
            backupBecameCurrent = true;

            if (!backupCopy.renameTo(backupDirectory)) {
                throw new IllegalStateException(
                        "Ny verifierad reservkopia kunde inte aktiveras.");
            }
            copyBecameBackup = true;

            ModulePackage restored = ModulePackage.loadAndValidate(currentDirectory);
            ModulePackage retainedBackup = ModulePackage.loadAndValidate(backupDirectory);
            if (restored.packageVersion != backup.packageVersion
                    || retainedBackup.packageVersion != restored.packageVersion) {
                throw new SecurityException("Fel reservversion efter återställning.");
            }

            deleteRecursively(quarantine);
            return restored;
        } catch (Exception error) {
            // Restore the pre-swap state whenever possible. No work data is touched.
            if (copyBecameBackup) {
                deleteRecursively(backupDirectory);
            } else {
                deleteRecursively(backupCopy);
            }
            if (backupBecameCurrent && currentDirectory.exists()) {
                currentDirectory.renameTo(backupDirectory);
            }
            if (currentMoved && quarantine.exists()) {
                quarantine.renameTo(currentDirectory);
            }
            throw error;
        }
    }

    synchronized ModulePackage stageVerifiedArchive(byte[] archiveBytes) throws Exception {
        if (archiveBytes == null || archiveBytes.length == 0) {
            throw new IllegalArgumentException("Modulpaketet är tomt.");
        }
        if (!modulesRoot.exists() && !modulesRoot.mkdirs()) {
            throw new IllegalStateException("Modulkatalogen kunde inte skapas.");
        }

        File temporary = new File(modulesRoot,
                "candidate-temp-" + UUID.randomUUID());
        if (!temporary.mkdirs()) {
            throw new IllegalStateException("Temporär modulkatalog kunde inte skapas.");
        }

        try {
            extractArchive(archiveBytes, temporary);
            ModulePackage candidate = ModulePackage.loadAndValidate(temporary);

            deleteRecursively(candidateDirectory);
            if (!temporary.renameTo(candidateDirectory)) {
                throw new IllegalStateException("Modulpaketet kunde inte aktiveras som kandidat.");
            }
            return ModulePackage.loadAndValidate(candidateDirectory);
        } catch (Exception error) {
            deleteRecursively(temporary);
            throw error;
        }
    }

    synchronized ModulePackage promoteCandidate() throws Exception {
        ModulePackage candidate = ModulePackage.loadAndValidate(candidateDirectory);
        ModulePackage current = tryLoad(currentDirectory);

        boolean movedCurrent = false;
        if (current != null) {
            deleteRecursively(backupDirectory);
            if (!currentDirectory.renameTo(backupDirectory)) {
                throw new IllegalStateException("Nuvarande modul kunde inte flyttas till reserv.");
            }
            movedCurrent = true;
        } else if (currentDirectory.exists()) {
            deleteRecursively(currentDirectory);
        }

        if (!candidateDirectory.renameTo(currentDirectory)) {
            if (movedCurrent && backupDirectory.exists()) {
                backupDirectory.renameTo(currentDirectory);
            }
            throw new IllegalStateException("Kandidatmodulen kunde inte göras aktuell.");
        }

        try {
            ModulePackage promoted = ModulePackage.loadAndValidate(currentDirectory);
            if (promoted.packageVersion != candidate.packageVersion) {
                throw new SecurityException("Fel modulversion efter aktivering.");
            }
            return promoted;
        } catch (Exception error) {
            deleteRecursively(currentDirectory);
            if (movedCurrent && backupDirectory.exists()) {
                backupDirectory.renameTo(currentDirectory);
            }
            throw error;
        }
    }

    synchronized void discardCandidate() {
        deleteRecursively(candidateDirectory);
    }

    synchronized int installedPackageVersion() {
        ModulePackage loaded = loadCurrentOrBackup();
        return loaded == null ? 0 : loaded.packageVersion;
    }

    private void extractArchive(byte[] archiveBytes, File destination) throws Exception {
        Set<String> paths = new HashSet<>();
        int entries = 0;
        long totalBytes = 0;
        String destinationPath = destination.getCanonicalPath();

        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(archiveBytes))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zip.getNextEntry()) != null) {
                entries++;
                if (entries > MAX_ARCHIVE_ENTRIES) {
                    throw new IllegalArgumentException("Modulpaketet innehåller för många filer.");
                }

                String path = entry.getName();
                if (entry.isDirectory()) {
                    String directoryPath = path.endsWith("/")
                            ? path.substring(0, path.length() - 1)
                            : path;
                    if (!directoryPath.isEmpty()) {
                        ModulePackage.validateRelativePath(directoryPath + "/placeholder.txt");
                    }
                    zip.closeEntry();
                    continue;
                }

                path = ModulePackage.validateRelativePath(path);
                if (!paths.add(path)) {
                    throw new SecurityException("Dubblettfil i modulpaketet: " + path + ".");
                }

                File outputFile = new File(destination, path);
                String outputPath = outputFile.getCanonicalPath();
                if (!outputPath.startsWith(destinationPath + File.separator)) {
                    throw new SecurityException("Otillåten sökväg i modulpaketet.");
                }
                File parent = outputFile.getParentFile();
                if (parent == null || (!parent.exists() && !parent.mkdirs())) {
                    throw new IllegalStateException("Modulkatalog kunde inte skapas.");
                }

                long entryBytes = 0;
                try (FileOutputStream output = new FileOutputStream(outputFile, false)) {
                    int read;
                    while ((read = zip.read(buffer)) != -1) {
                        entryBytes += read;
                        totalBytes += read;
                        if (entryBytes > MAX_ENTRY_BYTES
                                || totalBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                            throw new IllegalArgumentException(
                                    "Modulpaketets uppackade innehåll är för stort.");
                        }
                        output.write(buffer, 0, read);
                    }
                    output.flush();
                    output.getFD().sync();
                }
                zip.closeEntry();
            }
        }

        if (!paths.contains("module.json")) {
            throw new IllegalArgumentException("Modulpaketet saknar module.json.");
        }
    }

    private static void copyDirectory(File source, File destination) throws Exception {
        if (!source.isDirectory()) {
            throw new IllegalArgumentException("Källkatalogen för reservkopian saknas.");
        }
        if (destination.exists()) {
            deleteRecursively(destination);
        }
        if (!destination.mkdirs()) {
            throw new IllegalStateException("Temporär reservkatalog kunde inte skapas.");
        }
        File[] children = source.listFiles();
        if (children == null) {
            throw new IllegalStateException("Modulkatalogen kunde inte läsas.");
        }
        for (File child : children) {
            File target = new File(destination, child.getName());
            if (child.isDirectory()) {
                copyDirectory(child, target);
                continue;
            }
            try (java.io.FileInputStream input = new java.io.FileInputStream(child);
                 FileOutputStream output = new FileOutputStream(target, false)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    output.write(buffer, 0, read);
                }
                output.flush();
                output.getFD().sync();
            }
        }
    }

    private ModulePackage tryLoad(File directory) {
        try {
            return ModulePackage.loadAndValidate(directory);
        } catch (Exception ignored) {
            return null;
        }
    }

    static void deleteRecursively(File file) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursively(child);
                }
            }
        }
        file.delete();
    }
}
