package se.gagge007.stadslass.v3;

final class StartAppUpdatePolicy {
    private StartAppUpdatePolicy() {
    }

    static boolean hasActiveWork(String id, String status) {
        String safeId = id == null ? "" : id.trim();
        String safeStatus = status == null ? "" : status.trim();
        return !safeId.isEmpty() && ("active".equals(safeStatus)
                || "paused".equals(safeStatus)
                || "completing".equals(safeStatus));
    }

    static boolean requiresUpdate(boolean requiredBeforeUse,
                                  int remoteVersionCode,
                                  int installedVersionCode) {
        return requiredBeforeUse && remoteVersionCode > installedVersionCode;
    }
}
