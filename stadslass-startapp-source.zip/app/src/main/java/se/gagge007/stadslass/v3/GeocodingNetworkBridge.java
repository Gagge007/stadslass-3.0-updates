package se.gagge007.stadslass.v3;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Narrow native network bridge for approved forward and reverse Google Geocoding calls.
 *
 * The signed web module still builds the request and interprets the response.
 * This class only handles one exact HTTPS GET endpoint and two exact query shapes while the WebView's
 * general network loading remains blocked. It never persists or reports the
 * API key, query text, response body or coordinates.
 */
final class GeocodingNetworkBridge {
    private static final String GOOGLE_SCHEME = "https";
    private static final String GOOGLE_HOST = "maps.googleapis.com";
    private static final String GOOGLE_PATH = "/maps/api/geocode/json";
    private static final String MODULE_ORIGIN = "https://stadslass.local";
    private static final String MODULE_REFERER = "https://stadslass.local/module/";
    private static final String USER_AGENT = "Stadslass-3.0-host-v8-geocoding";

    private static final int CONNECT_TIMEOUT_MS = 8000;
    private static final int READ_TIMEOUT_MS = 12000;
    private static final int MAX_RAW_QUERY_LENGTH = 1400;
    private static final int MAX_ADDRESS_LENGTH = 500;
    private static final int MAX_LATLNG_LENGTH = 80;
    private static final int MAX_RESPONSE_BYTES = 1024 * 1024;

    private static final Set<String> FORWARD_QUERY_NAMES = new HashSet<>(
            Arrays.asList("address", "key", "language", "region"));
    private static final Set<String> REVERSE_QUERY_NAMES = new HashSet<>(
            Arrays.asList("latlng", "key", "language", "region"));
    private static final Pattern API_KEY_PATTERN = Pattern.compile(
            "^AIza[0-9A-Za-z_-]{20,100}$");
    private static final Pattern CONTROL_CHARACTER_PATTERN = Pattern.compile(
            "[\\u0000-\\u001F\\u007F]");
    private static final Pattern LATLNG_PATTERN = Pattern.compile(
            "^-?(?:\\d{1,2}(?:\\.\\d{1,15})?|90(?:\\.0{1,15})?),"
                    + "-?(?:\\d{1,3}(?:\\.\\d{1,15})?|180(?:\\.0{1,15})?)$");

    private final HostWatchdog watchdog;

    GeocodingNetworkBridge(HostWatchdog watchdog) {
        this.watchdog = watchdog;
    }

    boolean matches(WebResourceRequest request) {
        if (request == null || !"GET".equalsIgnoreCase(request.getMethod())) {
            return false;
        }
        return matchesUri(request.getUrl());
    }

    WebResourceResponse execute(WebResourceRequest request,
                                int packageVersion,
                                boolean candidate) {
        Uri uri = request == null ? null : request.getUrl();
        if (!matchesUri(uri)) {
            return null;
        }

        if (!hasAllowedQuery(uri)) {
            watchdog.record("host.geocoding.bridge.denied", "warning",
                    "Geokodningsbryggan blockerade ett anrop som inte följde det låsta kontraktet.",
                    packageVersion, candidate);
            return forbiddenResponse();
        }

        HttpURLConnection connection = null;
        try {
            URL url = new URL(uri.toString());
            connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);
            connection.setDoInput(true);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-store");
            connection.setRequestProperty("Pragma", "no-cache");
            connection.setRequestProperty("Origin", MODULE_ORIGIN);
            connection.setRequestProperty("Referer", MODULE_REFERER);
            connection.setRequestProperty("User-Agent", USER_AGENT);

            int responseCode = connection.getResponseCode();
            if (responseCode >= 300 && responseCode <= 399) {
                watchdog.record("host.geocoding.bridge.redirect-blocked", "warning",
                        "Google-geokodningens nätverksbrygga blockerade en HTTP-omdirigering.",
                        packageVersion, candidate);
                return bridgeErrorResponse(502, "Bad Gateway");
            }
            if (!isSupportedStatusCode(responseCode)) {
                watchdog.record("host.geocoding.bridge.invalid-status", "warning",
                        "Google-geokodningens nätverksbrygga fick en ogiltig HTTP-status.",
                        packageVersion, candidate);
                return bridgeErrorResponse(502, "Bad Gateway");
            }

            int declaredLength = connection.getContentLength();
            if (declaredLength > MAX_RESPONSE_BYTES) {
                watchdog.record("host.geocoding.bridge.response-too-large", "warning",
                        "Google-geokodningens svar överskred värdens storleksgräns.",
                        packageVersion, candidate);
                return bridgeErrorResponse(502, "Bad Gateway");
            }

            InputStream responseStream = responseCode >= 400
                    ? connection.getErrorStream()
                    : connection.getInputStream();
            byte[] responseBody = readLimited(responseStream, MAX_RESPONSE_BYTES);

            Map<String, String> headers = corsHeaders();
            headers.put("Content-Type", "application/json; charset=UTF-8");
            watchdog.record("host.geocoding.bridge.response", "info",
                    "Google-geokodningens nätverksbrygga returnerade ett maskerat HTTP-svar med status "
                            + responseCode + ".",
                    packageVersion, candidate);
            return new WebResourceResponse(
                    "application/json",
                    "UTF-8",
                    responseCode,
                    reasonPhrase(responseCode),
                    headers,
                    new ByteArrayInputStream(responseBody));
        } catch (Exception error) {
            watchdog.record("host.geocoding.bridge.network-error", "warning",
                    "Google-geokodningens nätverksbrygga fick ett nätverks- eller läsfel. Inga anropsdata sparades.",
                    packageVersion, candidate);
            // Returning null lets the still-blocked WebView request fail as a normal
            // fetch/network error, preserving the web module's existing error class.
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private boolean matchesUri(Uri uri) {
        return uri != null
                && GOOGLE_SCHEME.equalsIgnoreCase(uri.getScheme())
                && GOOGLE_HOST.equalsIgnoreCase(uri.getHost())
                && uri.getPort() == -1
                && uri.getUserInfo() == null
                && uri.getFragment() == null
                && GOOGLE_PATH.equals(uri.getPath());
    }

    private boolean hasAllowedQuery(Uri uri) {
        String rawQuery = uri.getEncodedQuery();
        if (rawQuery == null || rawQuery.isEmpty()
                || rawQuery.length() > MAX_RAW_QUERY_LENGTH) {
            return false;
        }

        Set<String> names = uri.getQueryParameterNames();
        boolean forward = FORWARD_QUERY_NAMES.equals(names);
        boolean reverse = REVERSE_QUERY_NAMES.equals(names);
        if (!forward && !reverse) {
            return false;
        }
        for (String name : names) {
            List<String> values = uri.getQueryParameters(name);
            if (values.size() != 1) {
                return false;
            }
        }

        String key = clean(uri.getQueryParameter("key"));
        String language = clean(uri.getQueryParameter("language"));
        String region = clean(uri.getQueryParameter("region"));
        if (!API_KEY_PATTERN.matcher(key).matches()
                || !"sv".equalsIgnoreCase(language)
                || !"se".equalsIgnoreCase(region)) {
            return false;
        }

        if (forward) {
            String address = clean(uri.getQueryParameter("address"));
            return !address.isEmpty()
                    && address.length() <= MAX_ADDRESS_LENGTH
                    && !CONTROL_CHARACTER_PATTERN.matcher(address).find();
        }
        return isValidLatLng(uri.getQueryParameter("latlng"));
    }

    private static boolean isValidLatLng(String value) {
        String latLng = value == null ? "" : value;
        if (latLng.isEmpty()
                || latLng.length() > MAX_LATLNG_LENGTH
                || CONTROL_CHARACTER_PATTERN.matcher(latLng).find()
                || !LATLNG_PATTERN.matcher(latLng).matches()) {
            return false;
        }
        String[] parts = latLng.split(",", -1);
        if (parts.length != 2) {
            return false;
        }
        try {
            double latitude = Double.parseDouble(parts[0]);
            double longitude = Double.parseDouble(parts[1]);
            return Double.isFinite(latitude)
                    && Double.isFinite(longitude)
                    && latitude >= -90.0
                    && latitude <= 90.0
                    && longitude >= -180.0
                    && longitude <= 180.0;
        } catch (NumberFormatException error) {
            return false;
        }
    }

    private static byte[] readLimited(InputStream input, int maximumBytes)
            throws Exception {
        if (input == null) {
            return new byte[0];
        }
        try (InputStream source = input;
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = source.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) {
                    throw new IllegalArgumentException("Svarskroppen är för stor.");
                }
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private static WebResourceResponse forbiddenResponse() {
        byte[] body = "Blocked".getBytes(StandardCharsets.UTF_8);
        return new WebResourceResponse(
                "text/plain",
                "UTF-8",
                403,
                "Forbidden",
                noStoreHeaders(),
                new ByteArrayInputStream(body));
    }

    private static WebResourceResponse bridgeErrorResponse(int statusCode,
                                                            String reasonPhrase) {
        byte[] body = "{}".getBytes(StandardCharsets.UTF_8);
        Map<String, String> headers = corsHeaders();
        headers.put("Content-Type", "application/json; charset=UTF-8");
        return new WebResourceResponse(
                "application/json",
                "UTF-8",
                statusCode,
                reasonPhrase,
                headers,
                new ByteArrayInputStream(body));
    }

    private static Map<String, String> corsHeaders() {
        Map<String, String> headers = noStoreHeaders();
        headers.put("Access-Control-Allow-Origin", MODULE_ORIGIN);
        headers.put("Access-Control-Allow-Methods", "GET");
        headers.put("Vary", "Origin");
        headers.put("X-Content-Type-Options", "nosniff");
        headers.put("Cross-Origin-Resource-Policy", "cross-origin");
        return headers;
    }

    private static Map<String, String> noStoreHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        headers.put("Pragma", "no-cache");
        return headers;
    }

    private static boolean isSupportedStatusCode(int statusCode) {
        return (statusCode >= 100 && statusCode <= 299)
                || (statusCode >= 400 && statusCode <= 599);
    }

    private static String reasonPhrase(int statusCode) {
        if (statusCode >= 200 && statusCode <= 299) {
            return "OK";
        }
        if (statusCode == 400) return "Bad Request";
        if (statusCode == 401) return "Unauthorized";
        if (statusCode == 403) return "Forbidden";
        if (statusCode == 404) return "Not Found";
        if (statusCode == 408) return "Request Timeout";
        if (statusCode == 429) return "Too Many Requests";
        if (statusCode >= 500) return "Server Error";
        return String.format(Locale.ROOT, "HTTP %d", statusCode);
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim();
    }
}
