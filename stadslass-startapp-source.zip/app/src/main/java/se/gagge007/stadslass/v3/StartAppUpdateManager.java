package se.gagge007.stadslass.v3;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

final class StartAppUpdateManager {
    static final int SELF_UPDATE_API_VERSION = 1;
    static final int MAX_APK_BYTES = 50 * 1024 * 1024;

    private static final String MANIFEST_URL =
            "https://raw.githubusercontent.com/Gagge007/stadslass-3.0-updates/main/startapp-latest.json";
    private static final int MAX_MANIFEST_BYTES = 64 * 1024;
    private static final String CACHE_KEY = "startapp_update_manifest_cache_v1";
    private static final String UPDATE_DIRECTORY = "startapp-updates";
    private static final String UPDATE_FILE = "startapp-update.apk";
    private static final String APK_MIME = "application/vnd.android.package-archive";

    interface Listener {
        void onStartupCanContinue(String status);
        void onRequiredUpdate(StartAppUpdateManifest manifest, String status);
        void onManualStatus(String status);
    }

    private final Activity activity;
    private final SharedPreferences preferences;
    private final ModuleDataStore moduleDataStore;
    private final HostWatchdog watchdog;
    private final Listener listener;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean checkInProgress = new AtomicBoolean(false);
    private final AtomicBoolean installInProgress = new AtomicBoolean(false);

    private volatile StartAppUpdateManifest pendingPermissionManifest;

    StartAppUpdateManager(Activity activity,
                          SharedPreferences preferences,
                          ModuleDataStore moduleDataStore,
                          HostWatchdog watchdog,
                          Listener listener) {
        this.activity = activity;
        this.preferences = preferences;
        this.moduleDataStore = moduleDataStore;
        this.watchdog = watchdog;
        this.listener = listener;
    }

    boolean shouldDeferForActiveWork() {
        try {
            JSONObject active = new JSONObject(moduleDataStore.read(ModuleDataStore.ACTIVE_JOB));
            if (active.length() == 0) {
                return false;
            }
            String id = active.optString("id", "").trim();
            String status = active.optString("status", "").trim();
            return StartAppUpdatePolicy.hasActiveWork(id, status);
        } catch (Exception error) {
            watchdog.record("host.self-update.active-work-unknown", "warning",
                    "Aktivt arbete kunde inte avgöras. Startappkontrollen skjuts upp.",
                    0, false);
            return true;
        }
    }

    void checkAtStartup(int installedVersionCode) {
        if (shouldDeferForActiveWork()) {
            listener.onStartupCanContinue("Startappkontrollen sköts upp för aktivt arbete.");
            return;
        }
        if (!checkInProgress.compareAndSet(false, true)) {
            return;
        }
        new Thread(() -> {
            try {
                StartAppUpdateManifest manifest = fetchManifestAndCache();
                if (manifest.requiresUpdate(installedVersionCode)) {
                    if (manifest.minimumUpdaterVersionCode > installedVersionCode) {
                        throw new IllegalStateException(
                                "Uppdateringen kräver en nyare uppdateringsmotor.");
                    }
                    postRequired(manifest,
                            "Startappen måste uppdateras innan Stadslass används vidare.");
                } else {
                    postStartupContinue("Startappen är aktuell.");
                }
            } catch (Exception error) {
                StartAppUpdateManifest cached = cachedManifest();
                if (cached != null && cached.requiresUpdate(installedVersionCode)
                        && cached.minimumUpdaterVersionCode <= installedVersionCode) {
                    postRequired(cached,
                            "En tidigare verifierad obligatorisk uppdatering väntar.");
                } else {
                    watchdog.record("host.self-update.startup-check-failed", "warning",
                            safeMessage(error), 0, false);
                    postStartupContinue(
                            "Startappkontrollen kunde inte slutföras. Stadslass startas säkert.");
                }
            } finally {
                checkInProgress.set(false);
            }
        }, "stadslass-startapp-check").start();
    }

    void checkManually(int installedVersionCode) {
        if (shouldDeferForActiveWork()) {
            return;
        }
        if (!checkInProgress.compareAndSet(false, true)) {
            postManualStatus("En startappkontroll pågår redan.");
            return;
        }
        postManualStatus("Kontrollerar startappversion…");
        new Thread(() -> {
            try {
                StartAppUpdateManifest manifest = fetchManifestAndCache();
                if (manifest.requiresUpdate(installedVersionCode)) {
                    if (manifest.minimumUpdaterVersionCode > installedVersionCode) {
                        throw new IllegalStateException(
                                "Uppdateringen kräver en nyare uppdateringsmotor.");
                    }
                    postRequired(manifest,
                            "Ny startapp " + manifest.versionName + " finns.");
                } else {
                    postManualStatus("Senaste startappversionen är redan installerad.");
                }
            } catch (Exception error) {
                watchdog.record("host.self-update.manual-check-failed", "warning",
                        safeMessage(error), 0, false);
                postManualStatus("Startappkontrollen misslyckades: " + safeMessage(error));
            } finally {
                checkInProgress.set(false);
            }
        }, "stadslass-startapp-manual-check").start();
    }

    void requestInstall(StartAppUpdateManifest manifest) {
        if (manifest == null || installInProgress.get()) {
            return;
        }
        if (shouldDeferForActiveWork()) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !activity.getPackageManager().canRequestPackageInstalls()) {
            pendingPermissionManifest = manifest;
            postManualStatus("Tillåt Stadslass att installera sin verifierade uppdatering.");
            Intent settingsIntent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(settingsIntent);
            return;
        }
        downloadVerifyAndOpenInstaller(manifest);
    }

    void onResume() {
        StartAppUpdateManifest pending = pendingPermissionManifest;
        if (pending == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        if (activity.getPackageManager().canRequestPackageInstalls()) {
            pendingPermissionManifest = null;
            requestInstall(pending);
        }
    }

    private StartAppUpdateManifest fetchManifestAndCache() throws Exception {
        String json = new String(downloadBytes(
                MANIFEST_URL + "?t=" + System.currentTimeMillis(),
                MAX_MANIFEST_BYTES, "application/json", false), StandardCharsets.UTF_8);
        StartAppUpdateManifest manifest = StartAppUpdateManifest.parse(json);
        if (!preferences.edit().putString(CACHE_KEY, json).commit()) {
            throw new IllegalStateException("Startappsmanifestet kunde inte cachelagras.");
        }
        watchdog.record("host.self-update.manifest-verified", "info",
                "Startappsmanifestet hämtades och verifierades.", 0, false);
        return manifest;
    }

    private StartAppUpdateManifest cachedManifest() {
        try {
            String json = preferences.getString(CACHE_KEY, "");
            return json == null || json.trim().isEmpty()
                    ? null : StartAppUpdateManifest.parse(json);
        } catch (Exception ignored) {
            return null;
        }
    }

    private void downloadVerifyAndOpenInstaller(StartAppUpdateManifest manifest) {
        if (!installInProgress.compareAndSet(false, true)) {
            return;
        }
        postManualStatus("Hämtar startapp " + manifest.versionName + "…");
        new Thread(() -> {
            try {
                byte[] apkBytes = downloadBytes(manifest.apkUrl,
                        MAX_APK_BYTES, APK_MIME, true);
                if (apkBytes.length != manifest.apkSizeBytes) {
                    throw new SecurityException("APK-filens storlek stämmer inte.");
                }
                String actualSha = sha256Hex(apkBytes);
                if (!actualSha.equals(manifest.apkSha256)) {
                    throw new SecurityException("APK-filens SHA-256 stämmer inte.");
                }
                File apkFile = writeUpdateFile(apkBytes);
                verifyArchive(apkFile, manifest);
                watchdog.record("host.self-update.apk-verified", "info",
                        "Startappens APK, version och signeringscertifikat verifierades.",
                        0, false);
                mainHandler.post(() -> openInstaller(apkFile));
            } catch (Exception error) {
                watchdog.record("host.self-update.install-failed", "warning",
                        safeMessage(error), 0, false);
                postManualStatus("Uppdateringen kunde inte öppnas: " + safeMessage(error));
            } finally {
                installInProgress.set(false);
            }
        }, "stadslass-startapp-download").start();
    }

    private File writeUpdateFile(byte[] bytes) throws Exception {
        File directory = new File(activity.getCacheDir(), UPDATE_DIRECTORY);
        if ((!directory.exists() && !directory.mkdirs()) || !directory.isDirectory()) {
            throw new IllegalStateException("Uppdateringsmappen kunde inte skapas.");
        }
        File target = new File(directory, UPDATE_FILE);
        try (FileOutputStream output = new FileOutputStream(target, false)) {
            output.write(bytes);
            output.flush();
            output.getFD().sync();
        }
        return target;
    }

    private void verifyArchive(File apkFile, StartAppUpdateManifest manifest) throws Exception {
        PackageManager packageManager = activity.getPackageManager();
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                ? PackageManager.GET_SIGNING_CERTIFICATES
                : PackageManager.GET_SIGNATURES;
        PackageInfo archive = packageManager.getPackageArchiveInfo(
                apkFile.getAbsolutePath(), flags);
        if (archive == null || !StartAppUpdateManifest.PACKAGE_ID.equals(archive.packageName)) {
            throw new SecurityException("APK-filen har fel paket-ID.");
        }
        long archiveVersion = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                ? archive.getLongVersionCode() : archive.versionCode;
        if (archiveVersion != manifest.versionCode
                || archiveVersion <= currentVersionCode()) {
            throw new SecurityException("APK-filens versionskod är ogiltig.");
        }
        if (archive.versionName == null
                || !manifest.versionName.equals(archive.versionName)) {
            throw new SecurityException("APK-filens versionsnamn stämmer inte.");
        }

        PackageInfo installed = packageManager.getPackageInfo(
                StartAppUpdateManifest.PACKAGE_ID, flags);
        String archiveCertificate = certificateSha256(archive);
        String installedCertificate = certificateSha256(installed);
        if (!archiveCertificate.equals(installedCertificate)
                || !archiveCertificate.equals(manifest.signingCertificateSha256)) {
            throw new SecurityException("APK-signeringen tillhör inte installerad Stadslass.");
        }
    }

    private String certificateSha256(PackageInfo packageInfo) throws Exception {
        Signature[] signatures;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (packageInfo.signingInfo == null) {
                throw new SecurityException("APK-signeringen saknas.");
            }
            signatures = packageInfo.signingInfo.hasMultipleSigners()
                    ? packageInfo.signingInfo.getApkContentsSigners()
                    : packageInfo.signingInfo.getSigningCertificateHistory();
        } else {
            signatures = packageInfo.signatures;
        }
        if (signatures == null || signatures.length != 1 || signatures[0] == null) {
            throw new SecurityException("APK-signeringen är inte entydig.");
        }
        return sha256Hex(signatures[0].toByteArray());
    }

    private void openInstaller(File apkFile) {
        try {
            Uri uri = FileProvider.getUriForFile(activity,
                    activity.getPackageName() + ".reportfiles", apkFile);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, APK_MIME);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(intent);
            postManualStatus("Androids installationsruta öppnades.");
        } catch (Exception error) {
            postManualStatus("Installationsrutan kunde inte öppnas: " + safeMessage(error));
        }
    }

    private byte[] downloadBytes(String address,
                                 int maximumBytes,
                                 String accept,
                                 boolean apk) throws Exception {
        URL url = new URL(address);
        if (!"https".equalsIgnoreCase(url.getProtocol())
                || !"raw.githubusercontent.com".equalsIgnoreCase(url.getHost())
                || url.getPort() != -1
                || url.getUserInfo() != null
                || url.getRef() != null) {
            throw new SecurityException("Fel uppdateringsvärd.");
        }
        if (apk) {
            StartAppUpdateManifest.validateApkUrl(address);
        } else if (!url.getPath().equals(
                "/Gagge007/stadslass-3.0-updates/main/startapp-latest.json")
                || (url.getQuery() != null && !url.getQuery().matches("t=[0-9]+"))) {
            throw new SecurityException("Fel startappsmanifest.");
        }

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(6000);
        connection.setReadTimeout(12000);
        connection.setRequestMethod("GET");
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept", accept);
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", "Stadslass-3.0-host-v18");
        int responseCode = connection.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK) {
            connection.disconnect();
            throw new IllegalStateException("HTTP-fel " + responseCode + ".");
        }
        int declaredLength = connection.getContentLength();
        if (declaredLength > maximumBytes) {
            connection.disconnect();
            throw new IllegalArgumentException("Uppdateringsfilen är för stor.");
        }
        try (InputStream input = connection.getInputStream();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > maximumBytes) {
                    throw new IllegalArgumentException("Uppdateringsfilen är för stor.");
                }
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        } finally {
            connection.disconnect();
        }
    }

    private int currentVersionCode() throws Exception {
        PackageInfo current = activity.getPackageManager().getPackageInfo(
                activity.getPackageName(), 0);
        long value = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P
                ? current.getLongVersionCode() : current.versionCode;
        if (value > Integer.MAX_VALUE) {
            throw new IllegalStateException("Installerad versionskod är för stor.");
        }
        return (int) value;
    }

    private static String sha256Hex(byte[] bytes) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
        StringBuilder result = new StringBuilder(digest.length * 2);
        for (byte value : digest) {
            result.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        }
        return result.toString();
    }

    private void postStartupContinue(String status) {
        mainHandler.post(() -> listener.onStartupCanContinue(status));
    }

    private void postRequired(StartAppUpdateManifest manifest, String status) {
        mainHandler.post(() -> listener.onRequiredUpdate(manifest, status));
    }

    private void postManualStatus(String status) {
        mainHandler.post(() -> listener.onManualStatus(status));
    }

    private static String safeMessage(Throwable error) {
        if (error == null || error.getMessage() == null
                || error.getMessage().trim().isEmpty()) {
            return "Okänt fel.";
        }
        String value = error.getMessage().trim();
        return value.length() > 240 ? value.substring(0, 240) : value;
    }
}
