package se.gagge007.stadslass.v3;

import java.net.URI;
import java.util.Locale;

/**
 * Native ownership record for the one verified module that may use sensitive
 * host bridges. Current WebView URL text is deliberately not consulted when a
 * bridge call is made: WebView may transiently report an empty or about:blank
 * URL even though the already committed, READY module is still active.
 */
final class TrustedModuleSession {
    enum Decision {
        ALLOWED,
        NO_TRUSTED_MODULE_SESSION,
        WRONG_WEBVIEW_GENERATION,
        MODULE_NOT_VERIFIED,
        MAIN_FRAME_NOT_COMMITTED,
        MODULE_NOT_READY,
        SESSION_REVOKED
    }

    private static final String EXPECTED_SCHEME = "https";
    private static final String EXPECTED_HOST = "stadslass.local";
    private static final int EXPECTED_EFFECTIVE_PORT = 443;

    private Object webViewIdentity;
    private int generation;
    private String moduleId = "";
    private int packageVersion;
    private String installationIdentity = "";
    private boolean verified;
    private boolean mainFrameCommitted;
    private boolean ready;
    private boolean revoked = true;

    synchronized void begin(Object webView, int loadGeneration, String verifiedModuleId,
                            int verifiedPackageVersion, String verifiedInstallationIdentity) {
        revoke();
        webViewIdentity = webView;
        generation = loadGeneration;
        moduleId = safe(verifiedModuleId);
        packageVersion = verifiedPackageVersion;
        installationIdentity = safe(verifiedInstallationIdentity);
        verified = webView != null && !moduleId.isEmpty()
                && packageVersion > 0 && !installationIdentity.isEmpty();
        revoked = !verified;
    }

    synchronized boolean commitMainFrame(Object webView, int loadGeneration,
                                         String currentModuleId, int currentPackageVersion,
                                         String currentInstallationIdentity, String committedUrl) {
        if (!matchesIdentity(webView, loadGeneration, currentModuleId,
                currentPackageVersion, currentInstallationIdentity)
                || !isExpectedOrigin(committedUrl)) {
            revoke();
            return false;
        }
        mainFrameCommitted = true;
        return true;
    }

    synchronized boolean markReady(Object webView, int loadGeneration,
                                   String currentModuleId, int currentPackageVersion,
                                   String currentInstallationIdentity) {
        if (!matchesIdentity(webView, loadGeneration, currentModuleId,
                currentPackageVersion, currentInstallationIdentity)
                || !mainFrameCommitted) {
            return false;
        }
        ready = true;
        return true;
    }

    synchronized Decision authorizeBootstrap(Object webView, int loadGeneration,
                                              String currentModuleId, int currentPackageVersion,
                                              String currentInstallationIdentity) {
        return authorizeInternal(webView, loadGeneration, currentModuleId,
                currentPackageVersion, currentInstallationIdentity, false);
    }

    synchronized Decision authorize(Object webView, int loadGeneration,
                                    String currentModuleId, int currentPackageVersion,
                                    String currentInstallationIdentity) {
        return authorizeInternal(webView, loadGeneration, currentModuleId,
                currentPackageVersion, currentInstallationIdentity, true);
    }

    private Decision authorizeInternal(Object webView, int loadGeneration,
                                       String currentModuleId, int currentPackageVersion,
                                       String currentInstallationIdentity,
                                       boolean requireReady) {
        if (revoked || webViewIdentity == null) {
            return Decision.NO_TRUSTED_MODULE_SESSION;
        }
        if (webViewIdentity != webView || generation != loadGeneration) {
            return Decision.WRONG_WEBVIEW_GENERATION;
        }
        if (!verified || !same(moduleId, currentModuleId)
                || packageVersion != currentPackageVersion
                || !same(installationIdentity, currentInstallationIdentity)) {
            return Decision.MODULE_NOT_VERIFIED;
        }
        if (!mainFrameCommitted) {
            return Decision.MAIN_FRAME_NOT_COMMITTED;
        }
        if (requireReady && !ready) {
            return Decision.MODULE_NOT_READY;
        }
        return Decision.ALLOWED;
    }

    synchronized boolean hasCommittedMainFrame() {
        return mainFrameCommitted && !revoked;
    }

    synchronized void revoke() {
        ready = false;
        mainFrameCommitted = false;
        verified = false;
        revoked = true;
        webViewIdentity = null;
        generation = 0;
        moduleId = "";
        packageVersion = 0;
        installationIdentity = "";
    }

    static boolean isExpectedOrigin(String value) {
        if (value == null || value.trim().isEmpty()) {
            return false;
        }
        try {
            URI uri = new URI(value);
            String scheme = uri.getScheme();
            String host = uri.getHost();
            int effectivePort = uri.getPort() == -1 ? EXPECTED_EFFECTIVE_PORT : uri.getPort();
            return uri.getUserInfo() == null
                    && scheme != null && EXPECTED_SCHEME.equalsIgnoreCase(scheme)
                    && host != null && EXPECTED_HOST.equals(host.toLowerCase(Locale.ROOT))
                    && effectivePort == EXPECTED_EFFECTIVE_PORT;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean matchesIdentity(Object webView, int loadGeneration,
                                    String currentModuleId, int currentPackageVersion,
                                    String currentInstallationIdentity) {
        return !revoked
                && webViewIdentity == webView
                && generation == loadGeneration
                && verified
                && same(moduleId, currentModuleId)
                && packageVersion == currentPackageVersion
                && same(installationIdentity, currentInstallationIdentity);
    }

    private static boolean same(String first, String second) {
        return safe(first).equals(safe(second));
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }
}
