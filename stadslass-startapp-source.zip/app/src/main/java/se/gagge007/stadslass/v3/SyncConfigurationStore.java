package se.gagge007.stadslass.v3;

import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Stores non-secret repository coordinates and a Keystore-encrypted token. */
final class SyncConfigurationStore {
    private static final String KEY_OWNER = "sync_v1_repository_owner";
    private static final String KEY_REPOSITORY = "sync_v1_repository_name";
    private static final String KEY_BRANCH = "sync_v1_repository_branch";
    private static final String KEY_TOKEN_BLOB = "sync_v1_github_token_encrypted";
    private static final String KEY_CONFIG_VERSION = "sync_v1_configuration_version";
    private static final int CONFIG_VERSION = 1;
    private static final int MAX_TOKEN_LENGTH = 1024;

    private static final Pattern OWNER_PATTERN =
            Pattern.compile("^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$");
    private static final Pattern REPOSITORY_PATTERN =
            Pattern.compile("^[A-Za-z0-9._-]{1,100}$");
    private static final Pattern BRANCH_PATTERN =
            Pattern.compile("^[A-Za-z0-9._/-]{1,255}$");

    private final SharedPreferences preferences;
    private final SecurePayloadCipher cipher;

    SyncConfigurationStore(SharedPreferences preferences) {
        this.preferences = preferences;
        this.cipher = new SecurePayloadCipher("stadslass_sync_credential_v1");
    }

    synchronized String setConfiguration(String configJson) {
        try {
            JSONObject input = new JSONObject(configJson == null ? "" : configJson);
            if (!hasOnlyAllowedFields(input)) {
                return result(false, "invalid_request", "unexpected_field");
            }
            String owner = input.optString("owner", "").trim();
            String repository = input.optString("repository", "").trim();
            String branch = input.optString("branch", "").trim();
            String token = input.optString("token", "").trim();
            String validationError = validate(owner, repository, branch, token);
            if (!validationError.isEmpty()) {
                return result(false, "invalid_request", validationError);
            }

            String encryptedToken = cipher.encryptUtf8(token);
            boolean saved = preferences.edit()
                    .putString(KEY_OWNER, owner)
                    .putString(KEY_REPOSITORY, repository)
                    .putString(KEY_BRANCH, branch)
                    .putString(KEY_TOKEN_BLOB, encryptedToken)
                    .putInt(KEY_CONFIG_VERSION, CONFIG_VERSION)
                    .commit();
            if (!saved) {
                return result(false, "host_error", "configuration_write_failed");
            }
            return statusJson();
        } catch (Exception ignored) {
            return result(false, "invalid_request", "invalid_json");
        }
    }

    synchronized String statusJson() {
        JSONObject output = new JSONObject();
        try {
            String owner = preferences.getString(KEY_OWNER, "");
            String repository = preferences.getString(KEY_REPOSITORY, "");
            String branch = preferences.getString(KEY_BRANCH, "");
            String blob = preferences.getString(KEY_TOKEN_BLOB, "");
            boolean configured = !owner.isEmpty() && !repository.isEmpty()
                    && !branch.isEmpty() && !blob.isEmpty();
            String errorCode = "";
            if (configured) {
                try {
                    String token = cipher.decryptUtf8(blob);
                    configured = token != null && !token.trim().isEmpty();
                    if (!configured) {
                        errorCode = "credential_empty";
                    }
                } catch (Exception error) {
                    configured = false;
                    errorCode = "credential_unavailable";
                }
            }
            output.put("ok", true);
            output.put("status", configured ? "configured" : "configuration_missing");
            output.put("configured", configured);
            output.put("owner", owner);
            output.put("repository", repository);
            output.put("branch", branch);
            output.put("configurationVersion",
                    preferences.getInt(KEY_CONFIG_VERSION, CONFIG_VERSION));
            output.put("errorCode", errorCode);
            return output.toString();
        } catch (Exception ignored) {
            return result(false, "host_error", "status_failed");
        }
    }

    synchronized boolean isConfigured() {
        return loadForTransport() != null;
    }

    synchronized Configuration loadForTransport() {
        try {
            String owner = preferences.getString(KEY_OWNER, "");
            String repository = preferences.getString(KEY_REPOSITORY, "");
            String branch = preferences.getString(KEY_BRANCH, "");
            String blob = preferences.getString(KEY_TOKEN_BLOB, "");
            if (owner.isEmpty() || repository.isEmpty() || branch.isEmpty() || blob.isEmpty()) {
                return null;
            }
            String token = cipher.decryptUtf8(blob);
            if (!validate(owner, repository, branch, token).isEmpty()) {
                return null;
            }
            return new Configuration(owner, repository, branch, token);
        } catch (Exception ignored) {
            return null;
        }
    }

    synchronized String clearConfiguration() {
        boolean saved = preferences.edit()
                .remove(KEY_OWNER)
                .remove(KEY_REPOSITORY)
                .remove(KEY_BRANCH)
                .remove(KEY_TOKEN_BLOB)
                .remove(KEY_CONFIG_VERSION)
                .commit();
        return result(saved, saved ? "cleared" : "host_error",
                saved ? "" : "configuration_clear_failed");
    }

    private static boolean hasOnlyAllowedFields(JSONObject input) {
        Set<String> allowed = new HashSet<>();
        allowed.add("owner");
        allowed.add("repository");
        allowed.add("branch");
        allowed.add("token");
        JSONArray names = input.names();
        if (names == null) {
            return true;
        }
        for (int index = 0; index < names.length(); index++) {
            if (!allowed.contains(names.optString(index))) {
                return false;
            }
        }
        return true;
    }

    private static String validate(String owner,
                                   String repository,
                                   String branch,
                                   String token) {
        if (!OWNER_PATTERN.matcher(owner).matches()) {
            return "invalid_owner";
        }
        if (!REPOSITORY_PATTERN.matcher(repository).matches()
                || ".".equals(repository) || "..".equals(repository)) {
            return "invalid_repository";
        }
        if (!BRANCH_PATTERN.matcher(branch).matches()
                || branch.startsWith("/") || branch.endsWith("/")
                || branch.endsWith(".") || branch.contains("..")
                || branch.contains("//") || branch.contains("@{")
                || branch.toLowerCase(Locale.ROOT).startsWith("http")) {
            return "invalid_branch";
        }
        if (token == null || token.trim().length() < 8
                || token.length() > MAX_TOKEN_LENGTH
                || containsControlCharacter(token)) {
            return "invalid_token";
        }
        return "";
    }

    private static boolean containsControlCharacter(String value) {
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (Character.isISOControl(character)) {
                return true;
            }
        }
        return false;
    }

    private static String result(boolean ok, String status, String errorCode) {
        try {
            JSONObject output = new JSONObject();
            output.put("ok", ok);
            output.put("status", status);
            output.put("errorCode", errorCode == null ? "" : errorCode);
            return output.toString();
        } catch (Exception ignored) {
            return "{\"ok\":false,\"status\":\"host_error\",\"errorCode\":\"json_failed\"}";
        }
    }

    static final class Configuration {
        final String owner;
        final String repository;
        final String branch;
        final String token;

        Configuration(String owner, String repository, String branch, String token) {
            this.owner = owner;
            this.repository = repository;
            this.branch = branch;
            this.token = token;
        }
    }
}
