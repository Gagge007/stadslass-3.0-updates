package se.gagge007.stadslass.v3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class TrustedModuleSessionTest {
    private static final Object VIEW = new Object();
    private static final String MODULE_ID = "stadslass-v3";
    private static final int PACKAGE_VERSION = 65;
    private static final String INSTALLATION = "verified-installation-65";

    private TrustedModuleSession committedSession(String origin) {
        TrustedModuleSession session = new TrustedModuleSession();
        session.begin(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION);
        assertTrue(session.commitMainFrame(VIEW, 7, MODULE_ID, PACKAGE_VERSION,
                INSTALLATION, origin));
        return session;
    }

    private TrustedModuleSession readySession(String origin) {
        TrustedModuleSession session = committedSession(origin);
        assertTrue(session.markReady(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        return session;
    }

    @Test
    public void bootstrapAllowsCommittedVerifiedModuleBeforeReady() {
        TrustedModuleSession session = new TrustedModuleSession();
        session.begin(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION);
        assertEquals(TrustedModuleSession.Decision.MAIN_FRAME_NOT_COMMITTED,
                session.authorizeBootstrap(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertTrue(session.commitMainFrame(VIEW, 7, MODULE_ID, PACKAGE_VERSION,
                INSTALLATION, "https://stadslass.local/module/"));
        assertEquals(TrustedModuleSession.Decision.ALLOWED,
                session.authorizeBootstrap(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertEquals(TrustedModuleSession.Decision.MODULE_NOT_READY,
                session.authorize(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertTrue(session.markReady(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertEquals(TrustedModuleSession.Decision.ALLOWED,
                session.authorize(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
    }

    @Test
    public void allowsVerifiedReadyModuleAcrossLocalPathsQueryAndFragment() {
        for (String url : new String[]{
                "https://stadslass.local/",
                "https://stadslass.local/index.html",
                "https://stadslass.local/module/index.html?mode=sync",
                "https://stadslass.local/internal/path#state"
        }) {
            TrustedModuleSession session = readySession(url);
            assertEquals(TrustedModuleSession.Decision.ALLOWED, session.authorize(
                    VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        }
    }

    @Test
    public void acceptsExplicitDefaultHttpsPortButRejectsOtherPortsAndSchemes() {
        assertTrue(TrustedModuleSession.isExpectedOrigin("https://stadslass.local:443/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("https://stadslass.local:444/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("http://stadslass.local/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("file:///module/index.html"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("content://stadslass.local/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("data:text/html,ok"));
    }

    @Test
    public void rejectsLookalikesUserInfoSubdomainsAndTrailingDot() {
        assertFalse(TrustedModuleSession.isExpectedOrigin("https://stadslass.local.evil/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("https://evil-stadslass.local/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("https://user@stadslass.local/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("https://sub.stadslass.local/module/"));
        assertFalse(TrustedModuleSession.isExpectedOrigin("https://stadslass.local./module/"));
    }

    @Test
    public void deniesStaleGenerationsModuleChangesAndExplicitRevocationAtBothLevels() {
        TrustedModuleSession session = readySession("https://stadslass.local/module/");
        assertEquals(TrustedModuleSession.Decision.WRONG_WEBVIEW_GENERATION,
                session.authorizeBootstrap(VIEW, 8, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertEquals(TrustedModuleSession.Decision.WRONG_WEBVIEW_GENERATION,
                session.authorize(VIEW, 8, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertEquals(TrustedModuleSession.Decision.MODULE_NOT_VERIFIED,
                session.authorizeBootstrap(VIEW, 7, "other-module", PACKAGE_VERSION, INSTALLATION));
        session.revoke();
        assertEquals(TrustedModuleSession.Decision.NO_TRUSTED_MODULE_SESSION,
                session.authorizeBootstrap(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
        assertEquals(TrustedModuleSession.Decision.NO_TRUSTED_MODULE_SESSION,
                session.authorize(VIEW, 7, MODULE_ID, PACKAGE_VERSION, INSTALLATION));
    }
}
