package se.gagge007.stadslass.v3;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class StartAppUpdateManifestTest {
    @Test
    public void allowedApkUrlIsAccepted() throws Exception {
        StartAppUpdateManifest.validateApkUrl(
                "https://raw.githubusercontent.com/Gagge007/stadslass-3.0-updates/main/Stadslass-3.0-startapp-v17.apk");
    }

    @Test(expected = SecurityException.class)
    public void foreignDownloadHostIsRejected() throws Exception {
        StartAppUpdateManifest.validateApkUrl(
                "https://example.invalid/Stadslass-3.0-startapp-v17.apk");
    }

    @Test
    public void requiredVersionPolicyIsMonotonic() {
        assertTrue(StartAppUpdatePolicy.requiresUpdate(true, 17, 16));
        assertFalse(StartAppUpdatePolicy.requiresUpdate(true, 16, 16));
        assertFalse(StartAppUpdatePolicy.requiresUpdate(false, 17, 16));
    }

    @Test
    public void activeWorkPolicyCoversAllProtectedStates() {
        assertTrue(StartAppUpdatePolicy.hasActiveWork("job-1", "active"));
        assertTrue(StartAppUpdatePolicy.hasActiveWork("job-1", "paused"));
        assertTrue(StartAppUpdatePolicy.hasActiveWork("job-1", "completing"));
        assertFalse(StartAppUpdatePolicy.hasActiveWork("", "active"));
        assertFalse(StartAppUpdatePolicy.hasActiveWork("job-1", "completed"));
    }
}
