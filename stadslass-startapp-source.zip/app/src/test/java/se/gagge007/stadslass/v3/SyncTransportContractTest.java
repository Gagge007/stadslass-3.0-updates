package se.gagge007.stadslass.v3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class SyncTransportContractTest {
    @Test
    public void prioritiesAreStrictlyOrdered() {
        assertTrue(SyncTransportContract.priorityValue("fast_lane")
                < SyncTransportContract.priorityValue("active_work"));
        assertTrue(SyncTransportContract.priorityValue("active_work")
                < SyncTransportContract.priorityValue("shared_queue"));
        assertTrue(SyncTransportContract.priorityValue("shared_queue")
                < SyncTransportContract.priorityValue("on_demand"));
    }

    @Test
    public void rejectsExternalAndTraversingPaths() {
        assertTrue(SyncTransportContract.isValidPath("sync/active/189.json"));
        assertFalse(SyncTransportContract.isValidPath("../secret"));
        assertFalse(SyncTransportContract.isValidPath("https://example.com/a"));
        assertFalse(SyncTransportContract.isValidPath("sync//queue.json"));
        assertFalse(SyncTransportContract.isValidPath("sync/file.json?x=1"));
    }

    @Test
    public void validatesTechnicalIdentifiers() {
        assertTrue(SyncTransportContract.isValidRequestId("189.active:0001"));
        assertFalse(SyncTransportContract.isValidRequestId("bad id"));
        assertTrue(SyncTransportContract.isValidChannel("active_work/189"));
        assertFalse(SyncTransportContract.isValidChannel("active work"));
        assertTrue(SyncTransportContract.isValidCoalesceKey("active:189"));
    }

    @Test
    public void retryDelayIsBounded() {
        assertEquals(5_000L, SyncTransportContract.retryDelay(1));
        assertEquals(10_000L, SyncTransportContract.retryDelay(2));
        assertEquals(15L * 60L * 1000L,
                SyncTransportContract.retryDelay(99));
    }

    @Test
    public void coalescingSupersedesAllWaitingRetryStates() {
        assertTrue(SyncTransportContract.isSupersedableWaitingStatus("pending"));
        assertTrue(SyncTransportContract.isSupersedableWaitingStatus("failed_retryable"));
        assertFalse(SyncTransportContract.isSupersedableWaitingStatus("running"));
        assertFalse(SyncTransportContract.isSupersedableWaitingStatus("succeeded"));
    }

    @Test
    public void newerRequestOrderingIsStable() {
        assertTrue(SyncTransportContract.isNewerRequest(
                100L, "active:0001", 101L, "active:0002"));
        assertFalse(SyncTransportContract.isNewerRequest(
                101L, "active:0002", 100L, "active:0001"));
        assertTrue(SyncTransportContract.isNewerRequest(
                100L, "active:0001", 100L, "active:0002"));
    }

    @Test
    public void everyRetryablePutRequiresReconciliation() {
        assertTrue(SyncTransportContract.requiresReconcileBeforeRetry("PUT", true));
        assertFalse(SyncTransportContract.requiresReconcileBeforeRetry("GET", true));
        assertFalse(SyncTransportContract.requiresReconcileBeforeRetry("PUT", false));
    }
}
