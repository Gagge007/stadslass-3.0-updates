package se.gagge007.stadslass.v3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class MailtoUriBuilderTest {
    @Test
    public void encodesRecipientSubjectAndBodyExactlyOnce() {
        String uri = MailtoUriBuilder.build(
                "test+189@example.com",
                "ÄTA uppdrag & kontroll",
                "Rad 1\nRad 2 + 10% #klart?");
        assertTrue(uri.startsWith("mailto:test+189@example.com?subject="));
        assertTrue(uri.contains("%C3%84TA%20uppdrag%20%26%20kontroll"));
        assertTrue(uri.contains("body=Rad%201%0ARad%202%20%2B%2010%25%20%23klart%3F"));
        assertFalse(uri.contains("%25C3%2584"));
        assertEquals(1, count(uri, "subject="));
        assertEquals(1, count(uri, "body="));
    }

    @Test
    public void omitsEmptyOptionalQueryValues() {
        assertEquals("mailto:test@example.com",
                MailtoUriBuilder.build("test@example.com", "", ""));
        assertEquals("mailto:test@example.com?body=Hej",
                MailtoUriBuilder.build("test@example.com", "", "Hej"));
    }

    private static int count(String value, String needle) {
        int count = 0;
        int offset = 0;
        while ((offset = value.indexOf(needle, offset)) >= 0) {
            count++;
            offset += needle.length();
        }
        return count;
    }
}
