package se.gagge007.stadslass.v3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@RunWith(AndroidJUnit4.class)
public final class WebViewOriginContractInstrumentationTest {
    private static final String MODULE_ID = "instrumentation-verified-module";
    private static final int PACKAGE_VERSION = 65;
    private static final String INSTALLATION = "instrumentation-verified-installation";

    @Test
    public void committedModuleCanBootstrapBeforeReadyButFullBridgeWaitsForReady() throws Exception {
        TrustedModuleSession session = new TrustedModuleSession();
        AtomicReference<WebView> webViewReference = new AtomicReference<>();
        CountDownLatch committed = new CountDownLatch(1);

        InstrumentationRegistry.getInstrumentation().runOnMainSync(() -> {
            WebView webView = new WebView(
                    InstrumentationRegistry.getInstrumentation().getTargetContext());
            webView.getSettings().setJavaScriptEnabled(true);
            webViewReference.set(webView);
            session.begin(webView, 1, MODULE_ID, PACKAGE_VERSION, INSTALLATION);
            webView.addJavascriptInterface(new SessionProbe(session, webView), "StadslassHost");
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageCommitVisible(WebView view, String url) {
                    if (session.commitMainFrame(view, 1, MODULE_ID, PACKAGE_VERSION,
                            INSTALLATION, url)) {
                        committed.countDown();
                    }
                }
            });
            webView.loadDataWithBaseURL("https://stadslass.local/module/",
                    "<html><body>bootstrap</body></html>", "text/html", "UTF-8", null);
        });

        assertTrue("Lokal WebView-huvudram committades inte",
                committed.await(20, TimeUnit.SECONDS));
        assertEquals("true", evaluate(webViewReference.get(),
                "StadslassHost.authorizeBootstrap()"));
        assertEquals("false", evaluate(webViewReference.get(),
                "StadslassHost.authorizeFull()"));

        InstrumentationRegistry.getInstrumentation().runOnMainSync(() ->
                assertTrue(session.markReady(webViewReference.get(), 1, MODULE_ID,
                        PACKAGE_VERSION, INSTALLATION)));
        assertEquals("true", evaluate(webViewReference.get(),
                "StadslassHost.authorizeFull()"));

        session.revoke();
        assertEquals("false", evaluate(webViewReference.get(),
                "StadslassHost.authorizeBootstrap()"));
        InstrumentationRegistry.getInstrumentation().runOnMainSync(() ->
                webViewReference.get().destroy());
    }

    private static String evaluate(WebView webView, String script) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> result = new AtomicReference<>("");
        InstrumentationRegistry.getInstrumentation().runOnMainSync(() ->
                webView.evaluateJavascript(script, value -> {
                    result.set(value);
                    latch.countDown();
                }));
        assertTrue("JavaScriptbryggan svarade inte", latch.await(10, TimeUnit.SECONDS));
        return result.get();
    }

    private static final class SessionProbe {
        private final TrustedModuleSession session;
        private final WebView webView;

        SessionProbe(TrustedModuleSession session, WebView webView) {
            this.session = session;
            this.webView = webView;
        }

        @JavascriptInterface
        public boolean authorizeBootstrap() {
            return session.authorizeBootstrap(webView, 1, MODULE_ID,
                    PACKAGE_VERSION, INSTALLATION) == TrustedModuleSession.Decision.ALLOWED;
        }

        @JavascriptInterface
        public boolean authorizeFull() {
            return session.authorize(webView, 1, MODULE_ID,
                    PACKAGE_VERSION, INSTALLATION) == TrustedModuleSession.Decision.ALLOWED;
        }
    }
}
