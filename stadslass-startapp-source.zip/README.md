# Stadslass 3.0 – permanent startapp v18

Startapp v17 bygger enbart vidare på startapp v16. Paket-ID, permanent APK-signering, SharedPreferences, roll, enhets-ID, signerad ZIP-modulmotor, GPS, geokodning, datalager, rollback och Watchdog är bevarade.

## Version och identitet

- Paket-ID och namespace: `se.gagge007.stadslass.v3`
- `versionCode`: `18`
- `versionName`: `3.0-host-18`
- SharedPreferences: `stadslass_3_permanent_host_preferences`
- APK-signering: samma permanenta keystore och Repository Secrets

## Rättad ÄTA-mailbrygga

`StadslassHost.openEmailDraft(recipient, subject, body)` använder fortsatt `ACTION_SENDTO`, men mottagare, ämne och brödtext läggs nu i en korrekt UTF-8-procentkodad `mailto:`-URI. Metodsignatur, returstatusar och `emailDraftApiVersion: 1` är oförändrade. Startappen kan endast bekräfta att Android öppnade ett utkast och kan aldrig se om användaren skickade mailet.

## Passiv generell synctransport API version 1

V11 lade till en passiv värdbrygga för framtida signerade funktionspaket:

- neutral beständig installationsidentitet
- Android Keystore-skyddad GitHub-token
- GET/PUT mot exakt konfigurerat GitHub-repository och branch
- krypterad beständig request- och resultatskö i `noBackupFilesDir`
- prioritet `fast_lane` → `active_work` → `shared_queue` → `on_demand`
- kontrollerad `coalesceKey`, deduplicering, återförsök och konfliktstatus
- återhämtning efter appomstart, WebView-omladdning och nätåterkomst
- `stadslass:sync-result`-event med återhämtning genom status-API

Bryggan är passiv tills ett framtida funktionspaket uttryckligen använder den. Den läser inte modulens stores, tolkar inte uppdrag och känner inte till jobbtyp, fas, vikt, köregler, historik eller ÄTA.


## Riktad v12-fix för syncåterförsök

V12 behåller API version 1 men säkrar två transportfall:

- en nyare status med samma `coalesceKey` ersätter även äldre `failed_retryable`-poster, och en äldre running-post får inte återgå till kön om en nyare status redan väntar
- varje återförsöksbart PUT markeras för GET-baserad reconcile innan nytt PUT, så timeout eller annat tvetydigt resultat inte skapar en dubbel skrivning

Startappen tolkar fortfarande inte arbetsdata och aktiverar ingen sync automatiskt.

## Behörigheter

V12 använder endast:

- `INTERNET`
- `ACCESS_NETWORK_STATE`
- `ACCESS_COARSE_LOCATION`
- `ACCESS_FINE_LOCATION`

Ingen bakgrundsposition, foreground service, boot receiver, kontakt-, konto-, telefon- eller lagringsbehörighet införs.

## Bevarade produktionsfunktioner

Mobil och 189 / Surfplatta, modulinstallation, SHA-256/RSA, kandidat, READY, current, backup, rollback, offline-start, separata modulstores, GPS, forward/reverse geokodning, urklipp, Back och Watchdog fungerar fortsatt utan synckonfiguration.

## Säker egen uppdatering

V16 kan kontrollera, hämta, verifiera och öppna Androidinstallationen för en ny permanent startapp. Aktivt arbete avbryts aldrig.

## Säker textsparning

En rapport i taget kan skickas till Androids sparruta. Nästa rapport får status `export_in_progress` tills den första har sparats, avbrutits eller kvitterats. Därmed kopplas varje sparresultat till rätt filnamn och rätt rapportinnehåll.
