#!/usr/bin/env python3
from pathlib import Path
import re, sys, tempfile, json
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text()
strings=(ROOT/'app/src/main/res/values/strings.xml').read_text()
checks=[]
def req(c,m): checks.append((bool(c),m))
req('cleanupLegacyTestArtifacts();' in main,'Städning körs vid start')
start=main.index('private void cleanupLegacyTestArtifacts()')
end=main.index('private void checkForFunctionUpdate',start)
block=main[start:end]
req('update_test_counter' not in block,'update_test_counter bevaras')
req('online_action_counter' not in block,'online_action_counter bevaras')
req('preferences.clear()' not in main and '.clear()' not in block,'SharedPreferences clear används inte')
req('deleteLegacyTestFile("stadslass-function-package.json")' in block,'legacy-current tas bort')
req('"stadslass-function-package.backup.json"' in block,'legacy-backup tas bort')
req('LegacyFunctionPackage' not in main,'Legacy-klassen är borttagen')
req('parseLegacyFunctionPackage' not in main,'Legacy-parsern är borttagen')
req('saveVerifiedLegacyPayload' not in main,'Legacy-installationen är borttagen')
req('optString("packageType", "")' in main,'Pakettyp saknar legacy-standard')
req('!MODULE_PACKAGE_TYPE.equals(packageType)' in main,'Endast ZIP-pakettyp godtas')
req('Äldre JSON-testpaket' not in main,'Legacy-testpaket visas inte')
req('Lokalt testvärde' not in strings and 'Öka testvärdet' not in strings,'Testvärden saknas i UI-resurser')
req('data_notice' not in strings and 'createNotice' not in main,'Teknisk informationsruta är borttagen')
req('hostWatchdog.userStatus()' in main and 'hostWatchdog.userMessage()' in main,'Kontrollsidan använder säker Watchdog-presentation')
req('runtime.ata.mail.open-failed' not in main,'Rå runtimefas är inte hårdkodad i UI')
# Simulate the exact migration plan against a v9-like fixture.
with tempfile.TemporaryDirectory() as td:
    d=Path(td)
    prefs={'device_role':'vehicle_189','device_id':'abc','function_package_version':60,
           'update_test_counter':8,'online_action_counter':3,'future_key':'keep'}
    files={
      'stadslass-function-package.json':b'legacy',
      'stadslass-function-package.backup.json':b'legacy-backup',
      'modules/current/module.json':b'current',
      'modules/backup/module.json':b'backup',
      'module-data/queue.json':b'{"jobs":[1]}',
      'stadslass-watchdog/host-watchdog.json':b'{"schemaVersion":1}'
    }
    for name,data in files.items():
      p=d/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
    before={name:(d/name).read_bytes() for name in files if not name.startswith('stadslass-function-package')}
    for name in ('stadslass-function-package.json','stadslass-function-package.backup.json'):
      p=d/name
      if p.exists(): p.unlink()
    req(prefs=={'device_role':'vehicle_189','device_id':'abc','function_package_version':60,
                'update_test_counter':8,'online_action_counter':3,'future_key':'keep'},
        'Roll, enhets-ID, testvärden, paketversion och okänd nyckel bevaras')
    req(not (d/'stadslass-function-package.json').exists() and not (d/'stadslass-function-package.backup.json').exists(),'Exakt två legacyfiler tas bort')
    req(all((d/name).read_bytes()==data for name,data in before.items()),'Modul, backup, arbetsdata och Watchdog är byte-identiska')
    # Idempotent second pass
    for name in ('stadslass-function-package.json','stadslass-function-package.backup.json'):
      p=d/name
      if p.exists(): p.unlink()
    req(all((d/name).read_bytes()==data for name,data in before.items()),'Andra körningen är idempotent')
failed=[m for ok,m in checks if not ok]
if failed:
 print('V10 CLEANUP CHECK FAILED')
 for m in failed: print('FAIL:',m)
 sys.exit(1)
print(f'V10 CLEANUP CHECK OK: {len(checks)} kontroller')
