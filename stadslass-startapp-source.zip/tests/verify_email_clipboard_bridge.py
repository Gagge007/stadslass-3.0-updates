#!/usr/bin/env python3
from pathlib import Path
import sys, urllib.parse
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text()
mailto=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/MailtoUriBuilder.java').read_text()
gradle=(ROOT/'app/build.gradle').read_text(); manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
method=main[main.index('public String openEmailDraft'):main.index('public String openEmailDraftWithAttachment')]
checks={
'versionCode 18':'versionCode 18' in gradle,
'versionName':"versionName '3.0-host-18'" in gradle,
'api versions':'EMAIL_DRAFT_API_VERSION = 2' in main and 'EMAIL_ATTACHMENT_API_VERSION = 1' in main and 'TEXT_FILE_EXPORT_API_VERSION = 1' in main and 'CLIPBOARD_API_VERSION = 1' in main,
'open method':'public String openEmailDraft(String recipient, String subject, String body)' in main,
'copy method':'public boolean copyText(String label, String text)' in main,
'action sendto':'Intent.ACTION_SENDTO' in method,
'mailto builder':'MailtoUriBuilder.build' in main and 'mailto:' in mailto,
'subject query':'?subject=' in mailto,
'body query':'&body=' in mailto and '?body=' in mailto,
'utf8':'StandardCharsets.UTF_8' in mailto,
'direct start':'startActivity(intent);' in method,
'no resolve':'resolveActivity(' not in method,
'activity not found':'catch (ActivityNotFoundException error)' in method and 'status.set("no_mail_app")' in method,
'host error':'status.set("host_error")' in method,
'opened':'status.set("opened")' in method,
'no extras':'Intent.EXTRA_SUBJECT' not in method and 'Intent.EXTRA_TEXT' not in method,
'central action send':'openEmailDraftWithAttachment' in main and 'Intent.ACTION_SEND' in main,
'Gmail lock only central':'setPackage("com.google.android.gm")' in main and main.count('setPackage(') == 2,
'limits':'MAX_EMAIL_BODY_LENGTH = 128 * 1024' in main and 'MAX_EMAIL_URI_LENGTH = 512 * 1024' in main,
'network permission':'ACCESS_NETWORK_STATE' in manifest,
'no background location':'ACCESS_BACKGROUND_LOCATION' not in manifest,
}
failed=[k for k,v in checks.items() if not v]
# Independent encoding oracle for required characters
subject='ÄTA uppdrag & kontroll'; body='Rad 1\nRad 2 + 10% #klart?'
encoded_subject=urllib.parse.quote(subject,safe='-._~')
encoded_body=urllib.parse.quote(body,safe='-._~')
if '%C3%84TA%20uppdrag%20%26%20kontroll' != encoded_subject: failed.append('encoding oracle subject')
if '%0A' not in encoded_body or '%2B' not in encoded_body or '%25' not in encoded_body: failed.append('encoding oracle body')
if failed:
 print('EMAIL/CLIPBOARD CHECK FAILED')
 for x in failed: print('FAIL:',x)
 sys.exit(1)
print(f'EMAIL/CLIPBOARD CHECK OK: {len(checks)+2} kontroller')
