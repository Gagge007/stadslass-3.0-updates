#!/usr/bin/env python3
from pathlib import Path
from xml.etree import ElementTree

ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text(encoding='utf-8')
manager=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/StartAppUpdateManager.java').read_text(encoding='utf-8')
manifest_java=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/StartAppUpdateManifest.java').read_text(encoding='utf-8')
policy=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/StartAppUpdatePolicy.java').read_text(encoding='utf-8')
gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
paths=(ROOT/'app/src/main/res/xml/report_file_paths.xml').read_text(encoding='utf-8')
errors=[]
def req(value,message):
    if not value: errors.append(message)
req('versionCode 18' in gradle and "versionName '3.0-host-18'" in gradle,'v18-identitet')
req('startapp-latest.json' in manager,'separat startappsmanifest')
req('getBoolean("required")' in manifest_java and 'getBoolean("requiredBeforeUse")' not in manifest_java,'manifestfältet required')
req('setInstanceFollowRedirects(false)' in manager,'inga HTTP-omdirigeringar')
req('manifest.apkSha256' in manager and 'manifest.apkSizeBytes' in manager,'hash och storlek')
req('getPackageArchiveInfo' in manager and 'archive.packageName' in manager,'APK-paket-ID')
req('certificateSha256(archive)' in manager and 'certificateSha256(installed)' in manager,'samma installerade certifikat')
req('canRequestPackageInstalls' in manager and 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' in manager,'Androidgodkännande')
req('FileProvider.getUriForFile' in manager and 'FLAG_GRANT_READ_URI_PERMISSION' in manager,'avgränsad APK-delning')
req('ModuleDataStore.ACTIVE_JOB' in manager and 'StartAppUpdatePolicy.hasActiveWork' in manager,'smal activeJob-spärr')
for status in ('active','paused','completing'):
    req(f'"{status}"' in policy,f'skyddad status {status}')
req('return true;' in manager[manager.index('catch (Exception error)'):manager.index('void checkAtStartup')],'läsfel skjuter upp kontroll')
req('showStartAppCheckingScreen();' in main and 'checkAtStartup(getVersionCode())' in main,'kontroll endast vid appstart')
req('public String checkStartAppUpdate()' in main and 'startapp-update-card' in main,'manuell knapp i Inställningar')
req('canCheckStartAppUpdate()' in main and 'card.hidden' in main,'knappen döljs under aktivt arbete')
req('selfUpdateApiVersion' in main,'host-API versionerad')
req('WorkManager' not in manager and 'BroadcastReceiver' not in manager and 'AlarmManager' not in manager,'ingen bakgrundskontroll')
req('startapp_updates' in paths and 'startapp-updates/' in paths,'FileProvider-sökväg')
root=ElementTree.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot(); ns='{http://schemas.android.com/apk/res/android}'
permissions=[x.attrib.get(ns+'name') for x in root.findall('uses-permission')]
req('android.permission.REQUEST_INSTALL_PACKAGES' in permissions,'installationsbehörighet')
for forbidden in ('android.permission.RECEIVE_BOOT_COMPLETED','android.permission.FOREGROUND_SERVICE','android.permission.MANAGE_EXTERNAL_STORAGE'):
    req(forbidden not in permissions,f'förbjuden behörighet {forbidden}')
req('driftlogg_v4_full' not in manager and 'QUEUE' not in manager and 'HISTORY' not in manager,'uppdateraren läser inte kö/historik/driftlogg')
req('raw.githubusercontent.com/Gagge007/stadslass-3.0-updates/main/' in manifest_java,'låst publiceringsbas')
if errors:
    print('V16 SELF UPDATE CHECK FAILED')
    for error in errors: print('FAIL:',error)
    raise SystemExit(1)
print('V16 SELF UPDATE CHECK OK:',24,'kontroller')
