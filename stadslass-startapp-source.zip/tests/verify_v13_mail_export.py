#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text(encoding='utf-8')
manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
errors = []
def req(value, message):
    if not value: errors.append(message)
req('openEmailDraft(String recipient, String subject, String body)' in main, 'bakåtkompatibel openEmailDraft saknas')
req('openEmailDraftWithAttachment(String requestJson)' in main, 'central bilagebrygga saknas')
req('requestTextFileExport(String requestJson)' in main and 'getTextFileExportStatus(String requestId)' in main and 'acknowledgeTextFileExportResult(String requestId)' in main, 'textfilexportens API saknas')
req('FileProvider.getUriForFile' in main and 'FLAG_GRANT_READ_URI_PERMISSION' in main and 'setClipData' in main, 'FileProvider-delningsskydd saknas')
req('Intent.ACTION_CREATE_DOCUMENT' in main and 'Intent.CATEGORY_OPENABLE' in main, 'användarvald textsparning saknas')
req('com.google.android.gm' in main and 'opened_gmail' in main and 'opened_mail_app' in main, 'Gmail-först med reservstatus saknas')
req('androidx.core.content.FileProvider' in manifest and 'android:exported="false"' in manifest and 'android:grantUriPermissions="true"' in manifest, 'FileProvider-manifest är inte avgränsat')
req('ACCESS_BACKGROUND_LOCATION' not in manifest and 'READ_CONTACTS' not in manifest and 'WRITE_EXTERNAL_STORAGE' not in manifest, 'förbjuden behörighet förekommer')
if errors:
    print('V13 MAIL/EXPORT CHECK FAILED'); print('\n'.join(errors)); raise SystemExit(1)
print('V13 MAIL/EXPORT CHECK OK: 9 kontroller')
