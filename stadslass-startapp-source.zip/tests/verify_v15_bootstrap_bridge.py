#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text(encoding='utf-8')
session = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/TrustedModuleSession.java').read_text(encoding='utf-8')
gradle = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')
unit = (ROOT / 'app/src/test/java/se/gagge007/stadslass/v3/TrustedModuleSessionTest.java').read_text(encoding='utf-8')
instrumentation = (ROOT / 'app/src/androidTest/java/se/gagge007/stadslass/v3/WebViewOriginContractInstrumentationTest.java').read_text(encoding='utf-8')
errors = []

def req(value, message):
    if not value:
        errors.append(message)

def body(signature):
    start = main.index(signature)
    end = main.find('\n        @JavascriptInterface', start + 1)
    return main[start:end]

req('versionCode 18' in gradle, 'versionCode är inte 18')
req("versionName '3.0-host-18'" in gradle, 'versionName är inte 3.0-host-18')
req('authorizeBootstrap' in session and 'authorizeInternal' in session,
    'bootstrapbehörighet saknas')
req('requireReady && !ready' in session,
    'full READY-spärr saknas')
req('isTrustedBootstrapBridgeCall' in main and 'isTrustedBootstrapCall' in main,
    'MainActivity saknar separat bootstrapgrind')
req('isTrustedBootstrapCall()' in body('        public String readStore(String storeName) {'),
    'readStore kräver fortfarande full READY')
req('isTrustedBootstrapCall()' in body('        public boolean writeStore(String storeName, String json) {'),
    'writeStore kräver fortfarande full READY')
for signature in (
    '        public String openEmailDraft(',
    '        public String openEmailDraftWithAttachment(',
    '        public String requestTextFileExport(',
    '        public boolean copyText(',
    '        public String setSyncConfiguration(',
    '        public String clearSyncConfiguration(',
    '        public String enqueueSyncRequest(',
    '        public String retryPendingSyncRequests(',
    '        public String acknowledgeSyncResult('
):
    req('isTrustedCall()' in body(signature), signature.strip() + ' saknar full READY-spärr')
req('trustedModuleSessionRevision", 2' in main, 'sessionrevision är inte 2')
req('bootstrapAllowsCommittedVerifiedModuleBeforeReady' in unit,
    'JVM-test för pre-READY bootstrap saknas')
req('committedModuleCanBootstrapBeforeReadyButFullBridgeWaitsForReady' in instrumentation,
    'Android/WebView-test för pre-READY bootstrap saknas')
req('loadDataWithBaseURL("https://stadslass.local/module/"' in instrumentation,
    'WebView-test använder inte verklig lokal origin')
req('startsWith' not in session and 'contains' not in session,
    'originbehörigheten använder osäker textmatchning')
req('origin_denied' in main, 'origin_denied saknas för verkligt otillåtna anrop')

if errors:
    print('V16 BOOTSTRAP BRIDGE CHECK FAILED')
    for error in errors:
        print('FAIL:', error)
    sys.exit(1)
print('V16 BOOTSTRAP BRIDGE CHECK OK: 20 kontroller')
