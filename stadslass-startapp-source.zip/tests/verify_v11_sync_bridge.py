#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text()
manager=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportManager.java').read_text()
config=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/SyncConfigurationStore.java').read_text()
cipher=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/SecurePayloadCipher.java').read_text()
contract=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportContract.java').read_text()
checks=[]
def req(c,m):checks.append((bool(c),m))
for api in ('syncTransportApiVersion','deviceIdentityApiVersion','syncCredentialApiVersion'):
 req(f'info.put("{api}"' in main,f'Hostinfo {api}')
for method in ('getDeviceIdentity','setSyncConfiguration','getSyncConfigurationStatus','clearSyncConfiguration','enqueueSyncRequest','getSyncRequestStatus','listPendingSyncRequests','retryPendingSyncRequests','acknowledgeSyncResult'):
 req(f'public String {method}' in main,f'Hostmetod {method}')
req(main.count('isTrustedCall()') >= 16 and 'isTrustedBridgeCall(int bridgeGeneration, ModulePackage bridgeModule)' in main,
    'Alla syncmetoder har betrodd modulsession')
req('UUID.randomUUID().toString()' in main and 'sync_installation_id_v1' in main,'Neutralt UUID')
for forbidden in ('ANDROID_ID','IMEI','TelephonyManager','.getDeviceId(','Build.MODEL'):
 req(forbidden not in main+manager+config,f'Ingen hårdvaruidentitet: {forbidden}')
req('AndroidKeyStore' in cipher and 'GCMParameterSpec' in cipher,'AES/GCM Keystore')
req('getNoBackupFilesDir()' in manager,'Kö i noBackup')
req('requestDirectory' in manager and 'resultDirectory' in manager and 'dedupDirectory' in manager,'Separata posttyper')
req('quarantine(' in manager and '.corrupt-' in manager,'Korruptpostisolering')
req('MAX_QUEUE_RECORDS = 200' in manager and 'MAX_QUEUE_BODY_BYTES = 8 * 1024 * 1024' in manager,'Kögränser')
req('MAX_DEDUP_RECORDS = 500' in manager and 'DEDUP_RETENTION_MS' in manager,'Dedupgränser')
req('active_work' in contract and 'shared_queue' in contract and 'on_demand' in contract,'Prioriteter')
req('superseded_by_newer_request' in manager,'Coalesce-resultat')
req('registerDefaultNetworkCallback' in manager and 'retryPending' in manager,'Nätåterkomst och manuell retry')
req('ScheduledExecutorService' in manager and 'newSingleThreadScheduledExecutor' in manager,'Asynkron enkel worker')
req('setInstanceFollowRedirects(false)' in manager,'Redirect blockeras')
req('.authority("api.github.com")' in manager,'Exakt GitHub API-host')
req('Authorization' in manager and 'configuration.token' in manager,'Host sätter token')
req('headers' not in manager[manager.index('static RequestRecord fromIncoming'):manager.index('JSONObject toJson()')].lower(),'Requestschema saknar egna headers')
req('isValidPath' in contract and 'path.contains("..")' in contract and 'startsWith("http")' in contract,'Path traversal/external URL blockeras')
req('MessageDigest.isEqual' in manager and 'reconcilePut' in manager,'Avbruten PUT reconcileras')
req('github_version_conflict' in manager and 'conflict' in manager,'Konfliktstatus')
req('stadslass:sync-result' in main and 'atob' in main,'Säkert event')
req('responseBody' in manager and 'includeBody' in manager,'Resultat kan återhämtas')
req('listPending' in manager and 'metadataJson' in manager,'Pendinglista utan body')
# ensure metadataJson body-free
m=manager[manager.index('JSONObject metadataJson()'):manager.index('String statusJson()')]
req('"body"' not in m,'Pendingmetadata exponerar inte body')
# secrets/logging boundary
watchdog_calls='\n'.join(re.findall(r'watchdog\.record\((.*?)\);',manager,re.S))
req('configuration.token' not in watchdog_calls and 'request.body' not in watchdog_calls and 'responseBody' not in watchdog_calls,'Watchdog loggar inte hemlig data')
req('ModuleDataStore' not in manager and 'driftlogg_v4_full' not in manager,'Ingen arbetsdataåtkomst')
req('WorkManager' not in manager and 'extends Service' not in manager and 'android.app.Service' not in manager and 'RECEIVE_BOOT_COMPLETED' not in manager,'Ingen bakgrundstjänst')
failed=[m for ok,m in checks if not ok]
if failed:
 print('V11 SYNC CHECK FAILED')
 for m in failed: print('FAIL:',m)
 sys.exit(1)
print(f'V11 SYNC CHECK OK: {len(checks)} kontroller')
