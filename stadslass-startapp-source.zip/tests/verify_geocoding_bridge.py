#!/usr/bin/env python3
from __future__ import annotations

import math
import re
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text(encoding='utf-8')
BRIDGE = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/GeocodingNetworkBridge.java').read_text(encoding='utf-8')
passes: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (passes if condition else errors).append(message)


def valid_latlng(value: str) -> bool:
    if not value or len(value) > 80 or re.search(r'[\x00-\x1f\x7f]', value):
        return False
    if re.fullmatch(r'-?(?:\d{1,2}(?:\.\d{1,15})?|90(?:\.0{1,15})?),-?(?:\d{1,3}(?:\.\d{1,15})?|180(?:\.0{1,15})?)', value) is None:
        return False
    parts = value.split(',')
    if len(parts) != 2:
        return False
    try:
        lat, lon = map(float, parts)
    except ValueError:
        return False
    return math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180


def allowed_url(value: str) -> bool:
    parsed = urlparse(value)
    if parsed.scheme.lower() != 'https':
        return False
    if parsed.hostname is None or parsed.hostname.lower() != 'maps.googleapis.com':
        return False
    if parsed.port is not None or parsed.username is not None or parsed.password is not None:
        return False
    if parsed.fragment or parsed.path != '/maps/api/geocode/json':
        return False
    if not parsed.query or len(parsed.query) > 1400:
        return False
    try:
        query = parse_qs(parsed.query, keep_blank_values=True, strict_parsing=True)
    except ValueError:
        return False
    forward = set(query) == {'address', 'key', 'language', 'region'}
    reverse = set(query) == {'latlng', 'key', 'language', 'region'}
    if not forward and not reverse:
        return False
    if any(len(values) != 1 for values in query.values()):
        return False
    key = query['key'][0].strip()
    if re.fullmatch(r'AIza[0-9A-Za-z_-]{20,100}', key) is None:
        return False
    if query['language'][0].strip().lower() != 'sv' or query['region'][0].strip().lower() != 'se':
        return False
    if forward:
        address = query['address'][0].strip()
        return 0 < len(address) <= 500 and not re.search(r'[\x00-\x1f\x7f]', address)
    return valid_latlng(query['latlng'][0])


valid_key = 'AIza' + 'A' * 35
valid_urls = [
    f'https://maps.googleapis.com/maps/api/geocode/json?address=JWGJ%2B967%2C%20G%C3%B6teborg&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?region=se&language=sv&key={valid_key}&address=Salsm%C3%A4staregatan%2018%2C%20G%C3%B6teborg',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57.686123,12.211456&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?region=se&latlng=-90.0,-180.0&language=sv&key={valid_key}',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=90,180&key={valid_key}&language=SV&region=SE',
]
invalid_urls = [
    f'http://maps.googleapis.com/maps/api/geocode/json?address=A&key={valid_key}&language=sv&region=se',
    f'https://evil.example/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/directions/json?latlng=57,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com:443/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=sv&region=se',
    f'https://user@maps.googleapis.com/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=sv&region=se#fragment',
    f'https://maps.googleapis.com/maps/api/geocode/json?address=A&latlng=57,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=sv&region=se&callback=x',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,12&latlng=58,13&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57%2C%2012&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=%2057%2C12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57%2C12%20&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=91,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,181&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=1e2,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=NaN,12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,+12&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,12,13&key={valid_key}&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?address=A&key=not-a-key&language=sv&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=en&region=se',
    f'https://maps.googleapis.com/maps/api/geocode/json?latlng=57,12&key={valid_key}&language=sv&region=us',
]
for value in valid_urls:
    require(allowed_url(value), f'Tillåtet geokodningsfall godkänns: {value[:75]}')
for value in invalid_urls:
    require(not allowed_url(value), f'Otillåtet nätverksfall stoppas: {value[:75]}')

require('setBlockNetworkLoads(true)' in MAIN, 'WebViewens generella nätladdning förblir blockerad')
require('new GeocodingNetworkBridge(hostWatchdog)' in MAIN, 'Värden initierar en enda geokodningsbrygga')
require('geocodingNetworkBridge.matches(request)' in MAIN and 'geocodingNetworkBridge.execute(' in MAIN, 'WebViewClient använder den begränsade bryggan')
require(MAIN.index('geocodingNetworkBridge.matches(request)') < MAIN.index('return blockedResponse();', MAIN.index('geocodingNetworkBridge.matches(request)')), 'Geokodningsbryggan prövas före det generella nätverksblocket')
require('GOOGLE_SCHEME = "https"' in BRIDGE and 'GOOGLE_HOST = "maps.googleapis.com"' in BRIDGE and 'GOOGLE_PATH = "/maps/api/geocode/json"' in BRIDGE, 'Bryggan låser exakt Google-endpoint')
require('"GET".equalsIgnoreCase(request.getMethod())' in BRIDGE, 'Bryggan accepterar endast GET')
require('FORWARD_QUERY_NAMES.equals(names)' in BRIDGE and 'REVERSE_QUERY_NAMES.equals(names)' in BRIDGE, 'Bryggan kräver exakt en av två parameteruppsättningar')
require('Arrays.asList("address", "key", "language", "region")' in BRIDGE and 'Arrays.asList("latlng", "key", "language", "region")' in BRIDGE, 'Endast godkända forward/reverse-parametrar finns')
require('isValidLatLng' in BRIDGE and 'LATLNG_PATTERN' in BRIDGE and 'Double.isFinite(latitude)' in BRIDGE, 'Koordinater syntax- och ändlighetsvalideras')
require('latitude >= -90.0' in BRIDGE and 'latitude <= 90.0' in BRIDGE and 'longitude >= -180.0' in BRIDGE and 'longitude <= 180.0' in BRIDGE, 'Koordinater intervallvalideras')
require('"sv".equalsIgnoreCase(language)' in BRIDGE and '"se".equalsIgnoreCase(region)' in BRIDGE, 'Språk och region är låsta')
require('API_KEY_PATTERN.matcher(key).matches()' in BRIDGE, 'API-nyckeln formatvalideras')
require('connection.setInstanceFollowRedirects(false)' in BRIDGE, 'Redirects är avstängda')
require('CONNECT_TIMEOUT_MS = 8000' in BRIDGE and 'READ_TIMEOUT_MS = 12000' in BRIDGE and 'MAX_RESPONSE_BYTES = 1024 * 1024' in BRIDGE, 'Timeout och svarsstorlek är låsta')
require('connection.setUseCaches(false)' in BRIDGE and 'connection.setDefaultUseCaches(false)' in BRIDGE, 'Bryggan använder inte nätverkscache')
require('headers.put("Access-Control-Allow-Origin", MODULE_ORIGIN)' in BRIDGE and 'Access-Control-Allow-Origin", "*"' not in BRIDGE, 'CORS är endast lokal origin')
require('connection.setRequestProperty("Origin", MODULE_ORIGIN)' in BRIDGE and 'connection.setRequestProperty("Referer", MODULE_REFERER)' in BRIDGE, 'Native-anropet bevarar låst origin/referrer')
require('addJavascriptInterface' not in BRIDGE and '@JavascriptInterface' not in BRIDGE, 'Ingen generell JavaScript-brygga exponeras')
for forbidden in ('SharedPreferences', 'AtomicFile', 'FileOutputStream', 'ModuleDataStore', 'writeStore(', 'readStore('):
    require(forbidden not in BRIDGE, f'Ingen förbjuden persistens: {forbidden}')
for forbidden in ('directions', 'routes.googleapis', 'distanceMatrix', 'GeofencingClient', 'LocationManager', 'requestLocationUpdates'):
    require(forbidden.lower() not in BRIDGE.lower(), f'Ingen annan nätverks/GPS-funktion: {forbidden}')
private_marker = 'BEGIN ' + 'PRIVATE KEY'
require(private_marker not in BRIDGE and 'AIza' in BRIDGE, 'Endast nyckelformat och ingen faktisk nyckel finns')
require(re.search(r'AIza[A-Za-z0-9_-]{20,}', BRIDGE) is None, 'Ingen full Google API-nyckel är inbyggd')
watchdog_calls = [line.strip() for line in BRIDGE.splitlines() if 'watchdog.record(' in line or '+ responseCode +' in line]
joined_watchdog = '\n'.join(watchdog_calls)
for sensitive_name in ('uri.toString', 'rawQuery', 'address', 'latLng', 'latitude', 'longitude', ' key ', 'responseBody'):
    require(sensitive_name not in joined_watchdog, f'Watchdog loggar inte känslig variabel: {sensitive_name}')
require('return null;' in BRIDGE and 'return geocodingNetworkBridge.execute(' in MAIN, 'Nätverksfel lämnas som befintlig fetch-felklass')

if errors:
    print('GEOCODING BRIDGE CHECK FAILED')
    for error in errors:
        print('FAIL:', error)
    print(f'{len(passes)} pass, {len(errors)} fail')
    raise SystemExit(1)
print(f'GEOCODING BRIDGE CHECK OK: {len(passes)} kontroller')
