#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path
from xml.etree import ElementTree
ROOT=Path(__file__).resolve().parents[1]
errors=[]; passes=[]
def req(c,m):(passes if c else errors).append(m)
def read(p): return (ROOT/p).read_text(encoding='utf-8')
gradle=read('app/build.gradle')
main=read('app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java')
manager=read('app/src/main/java/se/gagge007/stadslass/v3/SyncTransportManager.java')
config=read('app/src/main/java/se/gagge007/stadslass/v3/SyncConfigurationStore.java')
cipher=read('app/src/main/java/se/gagge007/stadslass/v3/SecurePayloadCipher.java')
mailto=read('app/src/main/java/se/gagge007/stadslass/v3/MailtoUriBuilder.java')
installer=read('app/src/main/java/se/gagge007/stadslass/v3/ModuleInstaller.java')
package_source=read('app/src/main/java/se/gagge007/stadslass/v3/ModulePackage.java')
storage=read('app/src/main/java/se/gagge007/stadslass/v3/ModuleDataStore.java')
watchdog=read('app/src/main/java/se/gagge007/stadslass/v3/HostWatchdog.java')
geocode=read('app/src/main/java/se/gagge007/stadslass/v3/GeocodingNetworkBridge.java')
trusted_session=read('app/src/main/java/se/gagge007/stadslass/v3/TrustedModuleSession.java')
all_java='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'app/src/main/java').rglob('*.java'))
req("applicationId 'se.gagge007.stadslass.v3'" in gradle,'Paket-ID låst')
req("namespace 'se.gagge007.stadslass.v3'" in gradle,'Namespace låst')
req('versionCode 18' in gradle,'versionCode 18')
req("versionName '3.0-host-18'" in gradle,'versionName 3.0-host-18')
req("testImplementation 'junit:junit:4.13.2'" in gradle,'JVM-enhetstester aktiverade')
req('stadslass_3_permanent_host_preferences' in main,'SharedPreferences bevarad')
for key in ('device_role','device_id','function_package_version'):
 req(key in main,f'Hostnyckel bevarad: {key}')
req('sync_installation_id_v1' in main and 'sync_installation_created_at_v1' in main,'Separat installationsidentitet')
for setting in ('setAllowContentAccess(false)','setAllowFileAccess(false)','setAllowFileAccessFromFileURLs(false)','setAllowUniversalAccessFromFileURLs(false)','setBlockNetworkLoads(true)','setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW)','setDomStorageEnabled(false)','setGeolocationEnabled(true)'):
 req(setting in main,f'WebView-skydd: {setting}')
req('Stadslass-3.0-host-v18' in main and 'Stadslass-3.0-host-v14' in manager,'Separata låsta User-Agent för värd och synctransport')
req('getOnBackPressedDispatcher().addCallback' in main and 'public void onBackPressed()' not in main,'Modern Back bevarad')
req('SHA256withRSA' in main and 'payloadSha256' in main,'Modulverifiering bevarad')
req('stageVerifiedArchive' in main and 'promoteCandidate' in main and 'markReady' in main,'Kandidat/READY bevarad')
req('rollbackToBackup' in installer and 'loadBackup' in installer,'Rollback bevarad')
req('validateRelativePath' in package_source and 'verifyNoUndeclaredFiles' in package_source,'Modulfilskydd bevarat')
for name,file in {'settings':'settings.json','queue':'queue.json','activeJob':'active-job.json','history':'history.json','syncOutbox':'sync-outbox.json'}.items():
 req(f'"{name}"' in storage and f'"{file}"' in storage,f'Modulstore bevarad: {name}')
req('AtomicFile' in storage,'Modulstore atomisk')
req('new HostWatchdog(this)' in main and 'host-watchdog.json' in watchdog,'Watchdog bevarad')
req('new GeocodingNetworkBridge(hostWatchdog)' in main and 'GOOGLE_HOST = "maps.googleapis.com"' in geocode,'Geokodning bevarad')
req('driftlogg_v4_full' not in all_java,'Java läser inte driftlogg_v4_full')
req('ModuleDataStore' not in manager and 'readStore(' not in manager and 'writeStore(' not in manager,'Synctransport saknar arbetsstoreåtkomst')
req('Intent.ACTION_SENDTO' in main and 'MailtoUriBuilder.build' in main,'Mailbrygga använder säker mailto')
legacy_mail=main[main.index('public String openEmailDraft'):main.index('public String openEmailDraftWithAttachment')]
req('Intent.EXTRA_SUBJECT' not in legacy_mail,'Bakåtkompatibelt mailflöde förlitar sig inte på subject-extra')
req('Intent.EXTRA_TEXT' not in legacy_mail,'Bakåtkompatibelt mailflöde förlitar sig inte på body-extra')
req('resolveActivity(' not in main,'Ingen resolveActivity-förkontroll')
req('openEmailDraftWithAttachment' in main and 'Intent.ACTION_SEND' in main,'Central bilagebrygga använder begränsad delning')
req('FileProvider.getUriForFile' in main and 'setPackage("com.google.android.gm")' in main,'FileProvider och Gmail-först finns centralt')
req('requestTextFileExport' in main and 'Intent.ACTION_CREATE_DOCUMENT' in main,'Textfilexport finns utan lagringsbehörighet')
req('?subject=' in mailto and '&body=' in mailto and 'StandardCharsets.UTF_8' in mailto,'UTF-8 procentkodad mailto-query')
for version in ('SYNC_TRANSPORT_API_VERSION = 1','DEVICE_IDENTITY_API_VERSION = 1','SYNC_CREDENTIAL_API_VERSION = 1'):
 req(version in manager,f'API-version: {version}')
for method in ('getDeviceIdentity()','setSyncConfiguration(String configJson)','getSyncConfigurationStatus()','clearSyncConfiguration()','enqueueSyncRequest(String requestJson)','getSyncRequestStatus(String requestId)','listPendingSyncRequests()','retryPendingSyncRequests()','acknowledgeSyncResult(String requestId)'):
 req(method in main,f'Hostmetod: {method}')
req('isTrustedBridgeCall(int bridgeGeneration, ModulePackage bridgeModule)' in main and 'TrustedModuleSession' in main,'Känsliga bryggor är bundna till betrodd modulsession')
req('AndroidKeyStore' in cipher and 'AES/GCM/NoPadding' in cipher,'Keystore AES/GCM')
status_block=config[config.index('String statusJson()'):config.index('synchronized boolean isConfigured()')]
req('stadslass_sync_credential_v1' in config and 'output.put("token"' not in status_block and 'output.put("tokenFragment"' not in status_block,'Status returnerar inte tokenfält')
req('getNoBackupFilesDir()' in manager and 'sync-transport-v1' in manager,'Syncposter ligger i noBackupFilesDir')
contract=read('app/src/main/java/se/gagge007/stadslass/v3/SyncTransportContract.java')
req('fast_lane' in contract and 'active_work' in contract and 'shared_queue' in contract and 'on_demand' in contract,'Fyra prioriteringar')
req('coalesceKey' in manager and 'superseded' in manager,'Coalescing med terminalstatus')
req('isSupersedableWaitingStatus' in contract and 'hasNewerCoalescedRequest' in manager,'V12 senaste status vinner')
req('normalizeCoalescedRequests();' in manager,'V12 normaliserar äldre coalescade poster')
req('requiresReconcileBeforeRetry' in contract and 'request.reconcileBeforeRetry =' in manager,'V12 reconcile före retryable PUT')
req('registerDefaultNetworkCallback' in manager and 'onHostResume()' in manager,'Nät/livscykelåterhämtning')
req('setInstanceFollowRedirects(false)' in manager and 'api.github.com' in manager,'Låst GitHubtransport utan redirects')
req('Authorization' in manager and 'Bearer ' in manager,'Authorization sätts av hosten')
req('github_version_conflict' in manager and 'ambiguous_write_conflict' in manager,'Konflikt och avbruten PUT-reconcile')
req('stadslass:sync-result' in main and 'getSyncRequestStatus' in main,'Återhämtningsbart resultevent')
req('MAX_QUEUE_RECORDS = 200' in manager and 'MAX_QUEUE_BODY_BYTES = 8 * 1024 * 1024' in manager,'Dokumenterade kögränser')
req('MAX_DEDUP_RECORDS = 500' in manager and 'DEDUP_RETENTION_MS' in manager,'Begränsad dedupjournal')
req('ACCESS_BACKGROUND_LOCATION' not in all_java and 'WorkManager' not in all_java and 'FOREGROUND_SERVICE' not in all_java,'Ingen bakgrundstjänst/position')
self_update=read('app/src/main/java/se/gagge007/stadslass/v3/StartAppUpdateManager.java')
self_manifest=read('app/src/main/java/se/gagge007/stadslass/v3/StartAppUpdateManifest.java')
self_policy=read('app/src/main/java/se/gagge007/stadslass/v3/StartAppUpdatePolicy.java')
req('startapp-latest.json' in self_update and 'setInstanceFollowRedirects(false)' in self_update,'Startappsmanifest utan redirects')
req('getPackageArchiveInfo' in self_update and 'certificateSha256' in self_update,'APK-identitet och certifikat verifieras')
req('manifest.apkSha256' in self_update and 'manifest.apkSizeBytes' in self_update,'APK-hash och storlek verifieras')
req('canRequestPackageInstalls' in self_update and 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' in self_update,'Androids installationsgodkännande används')
req('ModuleDataStore.ACTIVE_JOB' in self_update and 'StartAppUpdatePolicy.hasActiveWork' in self_update,'Aktivt arbete används endast som boolesk spärr')
req('active' in self_policy and 'paused' in self_policy and 'completing' in self_policy,'Alla skyddade arbetsstatusar finns')
req('path.matches(' in self_manifest and 'Stadslass-3' in self_manifest and 'raw.githubusercontent.com' in self_manifest,'APK-sökvägen är låst')
req('selfUpdateApiVersion' in main and 'startapp-update-card' in main,'Inställningsknapp och host-API finns')
req('startAppUpdateManager.shouldDeferForActiveWork()' in main,'Appstart skjuter upp kontroll under aktivt arbete')
req('startapp_updates' in read('app/src/main/res/xml/report_file_paths.xml'),'FileProvider delar endast uppdateringscache')
req((ROOT/'docs/SELF_UPDATE_CONTRACT.md').is_file(),'Självuppdateringskontrakt finns')
req('cleanupLegacyTestArtifacts();' in main and 'preferences.clear()' not in main and 'update_test_counter' not in main,'Äldre testvärde bevaras och städning är avgränsad')
manifest=ElementTree.parse(ROOT/'app/src/main/AndroidManifest.xml').getroot(); ns='{http://schemas.android.com/apk/res/android}'
permissions=[x.attrib.get(ns+'name') for x in manifest.findall('uses-permission')]
req('android.permission.REQUEST_INSTALL_PACKAGES' in permissions,'Installationsbehörigheten är uttrycklig')
req(permissions==['android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE','android.permission.ACCESS_COARSE_LOCATION','android.permission.ACCESS_FINE_LOCATION','android.permission.REQUEST_INSTALL_PACKAGES'],'Exakt fem avgränsade behörigheter')
for forbidden in ('android.permission.ACCESS_BACKGROUND_LOCATION','android.permission.READ_CONTACTS','android.permission.READ_PHONE_STATE','android.permission.FOREGROUND_SERVICE','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.QUERY_ALL_PACKAGES'):
 req(forbidden not in permissions,f'Förbjuden behörighet saknas: {forbidden}')
app=manifest.find('application')
req(app is not None and app.attrib.get(ns+'allowBackup')=='false','Backup avstängd')
req(app is not None and app.attrib.get(ns+'usesCleartextTraffic')=='false','Cleartext avstängt')
functions=json.loads(read('docs/FUNCTIONS.json')); ids=[x['id'] for x in functions['functions']]
req(functions['version']=='3.0-host-18','Funktionsregister v18')
for fid in ('HOST-SYNC-COALESCE-ORDER-002','HOST-SYNC-PUT-RECONCILE-002','HOST-MAILTO-QUERY-001','HOST-SYNC-IDENTITY-001','HOST-SYNC-CREDENTIAL-001','HOST-SYNC-TRANSPORT-001','HOST-SYNC-QUEUE-001','HOST-SYNC-RETRY-001','HOST-SYNC-EVENT-001','HOST-SYNC-DATA-BOUNDARY-001','HOST-TRUSTED-MODULE-SESSION-001'):
 req(fid in ids,f'V12-funktion registrerad: {fid}')
req(len(ids)==len(set(ids)),'Unika funktions-ID')
version=json.loads(read('VERSION.json'))
req(version['versionCode']==18 and version['versionName']=='3.0-host-18','VERSION.json v18')
req(version.get('basedOnVersion')=='3.0-host-17' and version.get('trustedModuleSessionRevision')==2,'V18 sessionsrevision och bygggrund')
req('moduleWebView.getUrl()' not in main and 'isExpectedOrigin' in trusted_session,'Bridgebehörighet använder inte aktuell URL-text')
req(version['syncTransportApiVersion']==1 and version['deviceIdentityApiVersion']==1 and version['syncCredentialApiVersion']==1,'VERSION.json API-versioner')
req((ROOT/'docs/SYNC_TRANSPORT_BRIDGE_CONTRACT.md').is_file(),'Synckontrakt finns')
req((ROOT/'docs/TRUSTED_MODULE_SESSION_CONTRACT.md').is_file(),'Trusted session-kontrakt finns')
# SOURCE_MANIFEST checked after generation
sm=ROOT/'docs/SOURCE_MANIFEST.json'
if sm.exists():
 data=json.loads(sm.read_text()); listed={x['path']:x for x in data['files']}; actual={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob('*') if p.is_file() and p!=sm and '.github' not in p.relative_to(ROOT).parts}
 req(set(listed)==set(actual),'Källmanifest listar exakt alla filer')
 for rel,p in actual.items():
  req(listed[rel]['size']==p.stat().st_size,f'Manifeststorlek: {rel}')
  req(listed[rel]['sha256']==hashlib.sha256(p.read_bytes()).hexdigest(),f'Manifesthash: {rel}')
else: errors.append('Källmanifest saknas')
if errors:
 print('SOURCE CHECK FAILED')
 for e in errors: print('FAIL:',e)
 print(len(passes),'pass',len(errors),'fail'); sys.exit(1)
print(f'SOURCE CHECK OK: {len(passes)} kontroller')
