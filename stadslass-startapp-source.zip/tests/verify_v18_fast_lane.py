#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
contract = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportContract.java').read_text(encoding='utf-8')
manager = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportManager.java').read_text(encoding='utf-8')
version = (ROOT / 'VERSION.json').read_text(encoding='utf-8')
errors = []

def req(value, message):
    if not value:
        errors.append(message)

req('"fast_lane".equals(priority)' in contract, 'fast_lane saknas')
req(contract.index('"fast_lane".equals(priority)') < contract.index('"active_work".equals(priority)'), 'fast_lane går inte före active_work')
req('return 0;' in contract[contract.index('"fast_lane".equals(priority)'):contract.index('"active_work".equals(priority)')], 'fast_lane har inte högsta prioritet')
req('newSingleThreadScheduledExecutor' in manager, 'transporten är inte fortsatt enkelspårig')
req('ModuleDataStore' not in manager and 'readStore(' not in manager and 'writeStore(' not in manager, 'transporten får inte läsa moduldata')
req('"versionCode": 18' in version and '"versionName": "3.0-host-18"' in version, 'startappens version är inte 18')

if errors:
    print('V18 FAST LANE CHECK FAILED')
    for error in errors:
        print('FAIL:', error)
    sys.exit(1)
print('V18 FAST LANE CHECK OK:', 6, 'kontroller')
