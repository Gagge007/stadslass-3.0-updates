#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
manager = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportManager.java').read_text(encoding='utf-8')
contract = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportContract.java').read_text(encoding='utf-8')
test = (ROOT / 'app/src/test/java/se/gagge007/stadslass/v3/SyncTransportContractTest.java').read_text(encoding='utf-8')
checks = []
def req(condition, message):
    checks.append((bool(condition), message))

req('isSupersedableWaitingStatus' in contract, 'Ren policy för pending/failed_retryable')
req('"pending".equals(status) || "failed_retryable".equals(status)' in contract,
    'Båda väntande retrylägen kan ersättas')
req('older.attemptCount == 0' not in manager,
    'Coalescing begränsas inte längre till första försöket')

enqueue_start = manager.index('String enqueue(String requestJson)')
enqueue_end = manager.index('String getStatus(String requestId)', enqueue_start)
enqueue = manager[enqueue_start:enqueue_end]
req('SyncTransportContract.isSupersedableWaitingStatus' in enqueue,
    'Enqueue ersätter pending och failed_retryable')
req('completeSuperseded(older)' in enqueue,
    'Äldre request får terminal superseded')
req(enqueue.index('if (projectedRecords >= MAX_QUEUE_RECORDS') < enqueue.index('completeSuperseded(older)'),
    'Ersättning sker först efter kapacitetskontroll')
req(enqueue.index('store.writeRequest(request)') < enqueue.index('completeSuperseded(older)'),
    'Nyaste request sparas före äldre raderas')
req('request.enqueuedAt = nextEnqueuedAt(pending)' in enqueue,
    'Nya request får stabilt senare köordning')

recover_start = manager.index('private void recoverInterruptedRequests()')
recover_end = manager.index('private void registerNetworkCallback()', recover_start)
recover = manager[recover_start:recover_end]
req('normalizeCoalescedRequests();' in recover,
    'Kvarvarande v11-dubbletter normaliseras vid start')
req('completeSuperseded(candidate)' in recover,
    'Äldre lagrade statusposter avslutas')

apply_start = manager.index('private void applyOutcome(')
apply_end = manager.index('private void notifyResult(', apply_start)
apply = manager[apply_start:apply_end]
req(apply.index('hasNewerCoalescedRequest(request)') < apply.index('request.status = "failed_retryable"'),
    'Nyare status kontrolleras före att äldre läggs tillbaka')
req('completeSuperseded(request)' in apply,
    'Running äldre request återgår inte efter nyare status')
req('SyncTransportContract.requiresReconcileBeforeRetry' in apply,
    'Retryable PUT markeras via ren policy')
req('request.reconcileBeforeRetry =' in apply,
    'Reconcileflaggan sparas före retry')

execute_start = manager.index('private TransportOutcome execute(')
execute_end = manager.index('private TransportOutcome reconcilePut(', execute_start)
execute = manager[execute_start:execute_end]
req('if (request.reconcileBeforeRetry && "PUT".equals(request.operation))' in execute,
    'PUT passerar reconcile före nytt PUT')
req(execute.index('reconcilePut(configuration, request)') < execute.index('executePut(configuration, request)'),
    'Reconcile sker före executePut')

req('everyRetryablePutRequiresReconciliation' in test,
    'JVM-test täcker PUT/GET retry-policy')
req('coalescingSupersedesAllWaitingRetryStates' in test,
    'JVM-test täcker väntande statusar')
req('newerRequestOrderingIsStable' in test,
    'JVM-test täcker stabil nyare-ordning')
req('SYNC_TRANSPORT_API_VERSION = 1' in manager,
    'Publik sync-API-version är fortsatt 1')
req('driftlogg_v4_full' not in manager and 'ModuleDataStore' not in manager,
    'Fixen saknar arbetsdataåtkomst')

failed = [message for ok, message in checks if not ok]
if failed:
    print('V12 SYNC RETRY CHECK FAILED')
    for message in failed:
        print('FAIL:', message)
    sys.exit(1)
print(f'V12 SYNC RETRY CHECK OK: {len(checks)} kontroller')
