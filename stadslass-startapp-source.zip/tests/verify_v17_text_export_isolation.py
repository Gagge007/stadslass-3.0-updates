#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text(encoding='utf-8')
coordinator = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/TextExportCoordinator.java').read_text(encoding='utf-8')
errors = []

def req(value, message):
    if not value:
        errors.append(message)

req('private final TextExportCoordinator textExportCoordinator' in main,
    'en enda exportkoordinator saknas')
req('pendingTextExports.values().iterator().next()' not in main,
    'Android-svaret kan fortfarande välja godtycklig väntande export')
req('textExportCoordinator.begin(requestId, fileName, content)' in main,
    'textsparing reserveras inte i koordinatorn')
req('"export_in_progress"' in main,
    'andra exporten nekas inte medan första är aktiv')
req('textExportCoordinator.activeForResult()' in main and 'textExportCoordinator.complete(status, message)' in main,
    'sparresultatet är inte bundet till den aktiva exporten')
req('textExportCoordinator.acknowledge(pending.requestId)' in main,
    'terminalt resultat frigör inte exakt rätt export')
req('if (active != null) return null;' in coordinator,
    'koordinatorn tillåter flera parallella sparningar')
req('if (active == null || !active.requestId.equals(requestId)' in coordinator,
    'status eller kvittens kan träffa fel export')

if errors:
    print('V17 TEXT EXPORT ISOLATION CHECK FAILED')
    for error in errors:
        print('FAIL:', error)
    sys.exit(1)
print('V17 TEXT EXPORT ISOLATION CHECK OK:', 8, 'kontroller')
