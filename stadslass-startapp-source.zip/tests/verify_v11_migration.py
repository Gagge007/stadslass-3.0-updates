#!/usr/bin/env python3
from pathlib import Path
import json, tempfile, sys, uuid
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text()
manager=(ROOT/'app/src/main/java/se/gagge007/stadslass/v3/SyncTransportManager.java').read_text()
checks=[]
def req(c,m):checks.append((bool(c),m))
req('preferences.clear()' not in main,'Ingen global preferences-rensning')
req('syncOutbox' not in manager,'Hostkö läser inte modulens syncOutbox')
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 prefs={'device_role':'vehicle_189','device_id':'visible-device','function_package_version':61,'future_key':'keep'}
 files={
  'modules/current/module.json':b'current', 'modules/candidate/module.json':b'candidate',
  'modules/backup/module.json':b'backup','module-data/settings.json':b'{"a":1}',
  'module-data/queue.json':b'{"jobs":[1]}','module-data/active-job.json':b'{"id":"x"}',
  'module-data/history.json':b'{"jobs":[2]}','module-data/sync-outbox.json':b'{"pending":[3]}',
  'stadslass-watchdog/host-watchdog.json':b'{"schemaVersion":1}' }
 for name,data in files.items():
  p=d/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
 before={k:(d/k).read_bytes() for k in files}
 prefs['sync_installation_id_v1']=str(uuid.uuid4()); prefs['sync_installation_created_at_v1']=1
 (d/'no_backup/sync-transport-v1/requests').mkdir(parents=True)
 req(prefs['device_role']=='vehicle_189' and prefs['device_id']=='visible-device' and prefs['function_package_version']==61 and prefs['future_key']=='keep','Roll/enhets-ID/paket/okänd nyckel bevaras')
 req(all((d/k).read_bytes()==v for k,v in before.items()),'Moduler och arbetsstores byte-identiska')
 req((d/'module-data/sync-outbox.json').read_bytes()==before['module-data/sync-outbox.json'],'syncOutbox migreras inte')
 req((d/'no_backup/sync-transport-v1/requests').is_dir(),'Tom separat hostkö skapas')
failed=[m for ok,m in checks if not ok]
if failed:
 print('V11 MIGRATION CHECK FAILED')
 for m in failed: print('FAIL:',m)
 sys.exit(1)
print(f'V11 MIGRATION CHECK OK: {len(checks)} kontroller')
