#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / 'app/src/main/java/se/gagge007/stadslass/v3/MainActivity.java').read_text(
    encoding='utf-8')
MANIFEST = ElementTree.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
ANDROID_NS = '{http://schemas.android.com/apk/res/android}'

passes: list[str] = []
errors: list[str] = []


def require(condition: bool, message: str) -> None:
    (passes if condition else errors).append(message)


def permission_level(coarse: bool, fine: bool) -> str:
    if fine:
        return 'precise'
    if coarse:
        return 'approximate'
    return 'denied'


def permanent_denial(requested_before: bool,
                     coarse: bool,
                     fine: bool,
                     coarse_rationale: bool,
                     fine_rationale: bool) -> bool:
    return (
        requested_before
        and permission_level(coarse, fine) == 'denied'
        and not coarse_rationale
        and not fine_rationale
    )


def answer_allowed(requested_allow: bool,
                   coarse: bool,
                   fine: bool,
                   same_generation: bool,
                   active_webview: bool,
                   allowed_origin: bool) -> bool:
    return (
        requested_allow
        and permission_level(coarse, fine) != 'denied'
        and same_generation
        and active_webview
        and allowed_origin
    )


require(permission_level(False, False) == 'denied',
        'Ingen Android-behörighet ger nekat svar')
require(permission_level(True, False) == 'approximate',
        'COARSE ger ungefärlig position')
require(permission_level(True, True) == 'precise',
        'FINE ger exakt position')
require(permission_level(False, True) == 'precise',
        'FINE prioriteras om plattformen rapporterar den')

require(not permanent_denial(False, False, False, False, False),
        'Första GPS-anropet klassas inte som permanent nekat')
require(not permanent_denial(True, False, False, True, False),
        'Vanlig nekning kan frågas igen när rationale finns')
require(permanent_denial(True, False, False, False, False),
        'Tidigare fråga utan rationale klassas som permanent nekat')
require(not permanent_denial(True, True, False, False, False),
        'COARSE-tillstånd klassas inte som nekat')
require(not permanent_denial(True, True, True, False, False),
        'FINE-tillstånd klassas inte som nekat')

require(answer_allowed(True, True, False, True, True, True),
        'Ungefärlig position kan godkänna aktiv lokal WebView')
require(answer_allowed(True, True, True, True, True, True),
        'Exakt position kan godkänna aktiv lokal WebView')
require(not answer_allowed(True, False, False, True, True, True),
        'Aktuell nekad Android-status stoppar ett tillåtet WebView-svar')
require(not answer_allowed(True, True, True, False, True, True),
        'Gammal WebView-generation stoppas')
require(not answer_allowed(True, True, True, True, False, True),
        'Inaktiv WebView stoppas')
require(not answer_allowed(True, True, True, True, True, False),
        'Främmande origin stoppas')
require(not answer_allowed(False, True, True, True, True, True),
        'Uttryckligt nekat WebView-svar förblir nekat')

permissions = [
    item.attrib.get(ANDROID_NS + 'name')
    for item in MANIFEST.findall('uses-permission')
]
require('android.permission.ACCESS_COARSE_LOCATION' in permissions,
        'Manifestet deklarerar COARSE')
require('android.permission.ACCESS_FINE_LOCATION' in permissions,
        'Manifestet deklarerar FINE')
require('android.permission.ACCESS_BACKGROUND_LOCATION' not in permissions,
        'Manifestet saknar bakgrundsposition')
require(len(permissions) == 5
        and 'android.permission.ACCESS_NETWORK_STATE' in permissions
        and 'android.permission.REQUEST_INSTALL_PACKAGES' in permissions,
        'Endast INTERNET, NETWORK_STATE, COARSE, FINE och startappinstallation finns')

on_create_start = MAIN.index('protected void onCreate(Bundle savedInstanceState)')
on_create_end = MAIN.index('@Override', on_create_start + 1)
on_create = MAIN[on_create_start:on_create_end]
require('requestPermissions(' not in on_create,
        'Vanlig appstart begär inte platsbehörighet')

prompt_start = MAIN.index('private void handleGeolocationPrompt(')
prompt_end = MAIN.index(
    'private void answerPendingGeolocationFromCurrentStatus(', prompt_start)
prompt_method = MAIN[prompt_start:prompt_end]
require('requestPermissions(' in prompt_method,
        'Androidfrågan finns endast i det aktiva geolocationflödet')
require('currentLocationPermissionLevel()' in prompt_method,
        'Aktuell status läses innan runtimefråga eller svar')
require('isLocationPermissionPermanentlyDenied()' in prompt_method,
        'Permanent nekad status kontrolleras före ny Androidfråga')

answer_start = MAIN.index('private void answerPendingGeolocation(boolean allow')
answer_end = MAIN.index('private void showLocationSettingsRecovery()', answer_start)
answer_method = MAIN[answer_start:answer_end]
require(answer_method.index('currentLocationPermissionLevel()')
        < answer_method.index('callback.invoke('),
        'Aktuell status kontrolleras precis före callback')
require('callback.invoke(origin, currentAllow, false)' in answer_method,
        'WebView-geolocation sparas inte permanent')

require('protected void onResume()' in MAIN
        and 'reconcileLocationPermissionAfterResume();' in MAIN,
        'Behörigheten kontrolleras vid återgång från bakgrunden')
require('wasGranted && !isGranted' in MAIN
        and 'GeolocationPermissions.getInstance().clear(' in MAIN,
        'Återkallad behörighet rensar lokalt WebView-beslut')
require('awaitingLocationSettings' in MAIN
        and 'ACTION_APPLICATION_DETAILS_SETTINGS' in MAIN,
        'Permanent nekad behörighet kan återställas via appinställningar')
require('setGeolocationEnabled(true)' in MAIN
        and 'onGeolocationPermissionsShowPrompt' in MAIN,
        'Full WebView-geolocation är inkopplad')
require('MODULE_GEOLOCATION_ORIGIN = "https://stadslass.local"' in MAIN,
        'Geolocation-origin är låst')
require('ACCESS_BACKGROUND_LOCATION' not in MAIN,
        'Java-koden saknar bakgrundsbehörighet')
for forbidden_api in (
        'LocationManager', 'FusedLocationProviderClient',
        'GeofencingClient', 'requestLocationUpdates'):
    require(forbidden_api not in MAIN,
            f'Ingen GPS-styrning har införts: {forbidden_api}')

if errors:
    print('GEOLOCATION CHECK FAILED')
    for error in errors:
        print('FAIL:', error)
    print(f'{len(passes)} pass, {len(errors)} fail')
    raise SystemExit(1)

print(f'GEOLOCATION CHECK OK: {len(passes)} kontroller')
