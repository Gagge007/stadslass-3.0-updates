(() => {
  'use strict';
  const STORE_KEY = 'receiptStoreV1';
  const MAX_IMPORT_BYTES = 2 * 1024 * 1024;
  const plain = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
  const text = (v) => typeof v === 'string' ? v.trim() : (v == null ? '' : String(v).trim());
  const fold = (v) => text(v).replace(/\s+/g, ' ').toLocaleLowerCase('sv-SE');
  const pad = (v) => String(v).padStart(2, '0');
  function date(value) {
    const raw = text(value); let match;
    if ((match = raw.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/))) return validDate(+match[1], +match[2], +match[3]);
    if ((match = raw.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/))) return validDate(+match[3], +match[2], +match[1]);
    return '';
  }
  function validDate(year, month, day) {
    const d = new Date(Date.UTC(year, month - 1, day));
    return d.getUTCFullYear() === year && d.getUTCMonth() === month - 1 && d.getUTCDate() === day ? `${year}-${pad(month)}-${pad(day)}` : '';
  }
  function receiptTime(value) {
    const match = text(value).replace('.', ':').match(/^(\d{1,2}):(\d{2})$/);
    if (!match || +match[1] > 23 || +match[2] > 59) return '';
    return `${pad(+match[1])}:${match[2]}`;
  }
  function weight(value) {
    const normalized = text(value).toLocaleLowerCase('sv-SE').replace(/\s*(ton|t)\s*$/, '').replace(/\s/g, '').replace(',', '.');
    const number = Number(normalized);
    return Number.isFinite(number) && number >= 0 ? Math.round(number * 1000) / 1000 : 0;
  }
  function minutes(value) {
    const number = Number(text(value).replace(',', '.'));
    return Number.isFinite(number) && number > 0 && number <= 24 * 60 ? Math.round(number) : 0;
  }
  function likelyAta(value) {
    const key = fold(value).replace(/ä/g, 'a');
    if (['ja','j','yes','true','1','ata'].includes(key)) return 'Ja';
    if (['nej','n','no','false','0'].includes(key)) return 'Nej';
    if (['osaker','mojlig','kanske'].includes(key)) return 'Osäker';
    return text(value) ? 'Osäker' : '';
  }
  function pick(row, names) {
    const entries = Object.entries(plain(row) ? row : {});
    const wanted = names.map((name) => fold(name).replace(/[^a-z0-9åäö]/g, ''));
    const found = entries.find(([key]) => wanted.includes(fold(key).replace(/[^a-z0-9åäö]/g, '')));
    return found ? found[1] : '';
  }
  function normalize(row, context = {}) {
    const normalizedDate = date(pick(row, ['datum','date']));
    const normalizedTime = receiptTime(pick(row, ['kvittotid','receiptTime','time','tid']));
    const normalizedWeight = weight(pick(row, ['vikt','weight','nettovikt','netWeight']));
    const normalizedMinutes = minutes(pick(row, ['snittid','estimatedMinutes','durationMinutes','minutes']));
    const from = text(pick(row, ['fran','från','from'])) || 'Okänd';
    const result = {
      id: text(row && row.id), date: normalizedDate, receiptTime: normalizedTime,
      facility: text(pick(row, ['anläggning','anlaggning','facility'])), materialCode: text(pick(row, ['materialKod','material/kod','material','code'])),
      weight: normalizedWeight, jobType: text(pick(row, ['jobbtyp','jobType','type'])), from,
      to: text(pick(row, ['till','to','destination'])), likelyAta: likelyAta(pick(row, ['troligAta','trolig ÄTA','likelyAta'])),
      estimatedMinutes: normalizedMinutes, sourceBatchId: text(context.batchId || pick(row, ['batchId','batch'])),
      sourceFileName: text(context.fileName), receiptImported: true, source: 'receipt_import'
    };
    const warnings = [];
    if (!result.date) warnings.push('Datum saknas eller är ogiltigt');
    if (!result.receiptTime) warnings.push('Kvittotid saknas');
    if (!result.jobType) warnings.push('Jobbtyp saknas');
    if (result.from === 'Okänd') warnings.push('Från saknas');
    if (!result.to) warnings.push('Till saknas');
    if (!(result.weight > 0)) warnings.push('Vikt saknas eller är 0');
    return { ...result, warnings, complete: Boolean(result.date && result.jobType && result.to && result.weight > 0) };
  }
  function splitLine(line, separator) { return line.split(separator).map((part) => part.trim()); }
  function parseDelimited(raw) {
    const lines = text(raw).split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
    if (!lines.length) return [];
    const separator = lines.some((line) => line.includes('\t')) ? '\t' : ';';
    const first = splitLine(lines[0], separator);
    const header = first.some((value) => /datum|jobbtyp|kvittotid|vikt/i.test(value));
    const canonical = ['datum','kvittotid','anläggning','materialKod','vikt','jobbtyp','fran','till','troligAta'];
    const old = ['datum','jobbtyp','fran','till','vikt'];
    const headers = header ? first : (first.length >= 9 ? canonical : old);
    return lines.slice(header ? 1 : 0).map((line) => {
      const parts = splitLine(line, separator); const row = {};
      headers.forEach((key, index) => { row[key] = parts[index] || ''; });
      return row;
    });
  }
  function read(raw, context = {}) {
    const source = typeof raw === 'string' ? raw : '';
    if (new TextEncoder().encode(source).length > MAX_IMPORT_BYTES) throw new Error('Importfilen är för stor. Ingen data har ändrats.');
    if (!source.trim()) return [];
    let rows; let batchId = text(context.batchId);
    try {
      const parsed = JSON.parse(source);
      if (Array.isArray(parsed)) rows = parsed;
      else if (plain(parsed) && Array.isArray(parsed.rows)) { rows = parsed.rows; batchId = text(parsed.batchId || parsed.batch); }
    } catch (_) {}
    if (!rows) rows = parseDelimited(source);
    return rows.filter(plain).map((row) => normalize(row, { ...context, batchId }));
  }
  function key(row) {
    return [row.date,row.receiptTime,row.facility,row.materialCode,row.jobType,row.from,row.to,Number(row.weight || 0).toFixed(2)].map(fold).join('|');
  }
  function historyKey(row) {
    const completed = text(row && row.completedAt); const d = completed.slice(0, 10); const t = completed.slice(11, 16);
    return [d,t,text(row && row.material && row.material.facilityPlaceName),text(row && row.material && row.material.code),text(row && (row.jobTypeName || row.jobType)),text(row && (row.fromPlaceName || row.from)),text(row && (row.destinationPlaceName || row.destination)),Number(row && row.totalWeight || 0).toFixed(2)].map(fold).join('|');
  }
  function prepare(rows, existing = [], history = []) {
    const known = new Set(existing.map(key)); const historyKnown = new Set(history.map(historyKey));
    return rows.map((row, index) => { const duplicate = known.has(key(row)) || historyKnown.has(key(row)); known.add(key(row)); return { ...row, pendingId: `pending-${index}`, possibleDuplicate: duplicate, selected: row.complete && !duplicate }; });
  }
  function windowFor(row, estimateMinutes = 0) {
    const mins = minutes(row.estimatedMinutes || estimateMinutes);
    if (!row.date || !row.receiptTime || !mins) return null;
    const midpoint = new Date(`${row.date}T${row.receiptTime}:00`); if (!Number.isFinite(midpoint.getTime())) return null;
    return { midpoint: midpoint.toISOString(), start: new Date(midpoint.getTime() - mins * 30000).toISOString(), end: new Date(midpoint.getTime() + mins * 30000).toISOString(), minutes: mins };
  }
  function commit(rows, now = new Date().toISOString()) {
    return rows.map((row, index) => ({ ...row, id: text(row.id) || `receipt-${Date.now().toString(36)}-${index}`, importedAt: now, createdAt: text(row.createdAt) || now, warnings: undefined, complete: undefined, selected: undefined, possibleDuplicate: undefined, pendingId: undefined }));
  }
  function projection(row, estimateMinutes = 0) {
    const timeWindow = windowFor(row, estimateMinutes); const fallback = row.date && row.receiptTime ? `${row.date}T${row.receiptTime}:00` : `${row.date || '1970-01-01'}T12:00:00`;
    return {
      id: `receipt-history-${row.id}`, jobId: `receipt-history-${row.id}`, receiptRowId: row.id, receiptImported: true, source: 'receipt_import',
      jobTypeName: row.jobType || 'Kvitto', fromPlaceName: row.from || 'Okänd', destinationPlaceName: row.to || 'Till saknas',
      startedAt: timeWindow ? timeWindow.start : fallback, completedAt: timeWindow ? timeWindow.end : fallback,
      estimatedTimeWindow: timeWindow, receiptTime: row.receiptTime, receiptDate: row.date, facility: row.facility, likelyAta: row.likelyAta,
      material: { code: row.materialCode, facilityPlaceName: row.facility }, loads: row.weight > 0 ? [{ weight: row.weight }] : [], totalWeight: row.weight || 0,
      weightOutcome: row.weight > 0 ? 'registered' : 'missing-confirmed', status: 'completed', distanceMeters: 0,
      excludeFromEstimateLearning: true, excludeFromPhaseLearning: true, excludeFromGpsLearning: true, learningExcludedReason: 'receipt_import',
      note: 'Kvittoimporterad. Eventuell Start/Slut är uppskattad från Kvittotid och snittid och används inte för tidsinlärning.'
    };
  }
  function store(value) { return Array.isArray(value) ? value.filter(plain).map((row) => normalize(row, { batchId: row.sourceBatchId, fileName: row.sourceFileName })).map((row, i) => ({ ...row, id: text(value[i] && value[i].id) || `receipt-restored-${i}`, importedAt: text(value[i] && value[i].importedAt), createdAt: text(value[i] && value[i].createdAt) })) : []; }
  window.StadslassReceiptImport = Object.freeze({ STORE_KEY, MAX_IMPORT_BYTES, date, receiptTime, weight, minutes, likelyAta, normalize, read, key, prepare, windowFor, commit, projection, store });
})();
