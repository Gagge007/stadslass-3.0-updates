(() => {
  'use strict';

  const PACKAGE_VERSION = 203;
  const LEGACY_RECOVERY_OWNER = 194; // Existing P194 journal contract; not runtime version.
  const NATIVE_STORAGE_API_VERSION = 1;
  const STORAGE_SCHEMA_VERSION = 1;
  const STAGING_API_VERSION = 1;
  const MIGRATION_SCHEMA_VERSION = 1;
  const MIGRATION_KEY = 'nativeStorageMigrationV1';
  const CATEGORIES = Object.freeze(['history', 'registries', 'learning', 'sync-history', 'trash', 'persistent-user-data']);
  const REGISTRY_KEYS = Object.freeze([
    'editableJobTypeRegistryV1', 'editablePlaceRegistryV1', 'editableBeachRegistryV1', 'quickChoiceRegistryV1', 'machines'
  ]);
  const SYNC_KEYS = Object.freeze([
    'driftHandshakeV1', 'syncV63', 'mailboxV1', 'historySyncV1', 'pendingRegistryPackage', 'acceptedMobileAssignmentsV1'
  ]);
  const TECHNICAL_KEYS = Object.freeze([
    'settingsSchemaVersion', 'settingsUpdatedByPackageVersion', MIGRATION_KEY, 'p194DataRecoveryV1', 'p194MigrationV1', 'p194RestoreV1', 'p196RegistryRecoveryV1'
  ]);
  const SECRET_KEYS = Object.freeze([
    'googleServiceV1', 'googleServiceSettingsV1', 'syncV63ConfigurationV1', 'syncConfigurationV1', 'githubToken', 'apiKey', 'privateKey'
  ]);
  const RECEIPT_STORE_KEY = 'receiptStoreV1';
  const SYNC_OUTBOX_STORE = 'syncOutbox';
  const HISTORY_STORE = 'history';
  const SETTINGS_STORE = 'settings';

  const clone = (value) => value == null ? value : JSON.parse(JSON.stringify(value));
  const plain = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const text = (value, fallback = '') => { const normalized = typeof value === 'string' ? value.trim() : ''; return normalized || fallback; };
  const array = (value) => Array.isArray(value) ? value : [];

  let migrationSnapshot = null;
  let active = false;
  let observedHistory = null, observedReceipts = null;
  let lastError = null;
  let diagnosticsState = {
    schemaVersion: 1,
    packageVersion: PACKAGE_VERSION,
    nativeStorageApiVersion: NATIVE_STORAGE_API_VERSION,
    storageSchemaVersion: STORAGE_SCHEMA_VERSION,
    stagingApiVersion: STAGING_API_VERSION,
    adapterStatus: 'not-started',
    migration: {},
    syncPausedByMigration: true,
    syncReactivatedAt: '',
    staging: { transfers: [], lastError: null },
    lastError: null
  };

  function host() {
    if (!window.StadslassHost || typeof window.StadslassHost !== 'object') throw new Error('Host24-bryggan saknas.');
    return window.StadslassHost;
  }

  function parseResult(raw, label) {
    let value;
    try { value = JSON.parse(String(raw || '')); } catch (_) { throw new Error(`${label} gav ogiltig JSON.`); }
    if (!plain(value) || value.ok !== true) {
      const code = text(value && value.code, 'unknown_error');
      const message = text(value && value.message, `${label} misslyckades.`);
      const error = new Error(`${message} [${code}]`);
      error.code = code;
      error.step = text(value && value.step);
      throw error;
    }
    return value;
  }

  function nativeRequest(operation, body = {}) {
    const bridge = host();
    if (typeof bridge.requestNativeStorage !== 'function') throw new Error('Host24 native storage-brygga saknas.');
    const request = {
      nativeStorageApiVersion: NATIVE_STORAGE_API_VERSION,
      storageSchemaVersion: STORAGE_SCHEMA_VERSION,
      operation,
      ...body
    };
    return parseResult(bridge.requestNativeStorage(JSON.stringify(request)), `Native storage ${operation}`);
  }

  function stagingRequest(operation, body = {}) {
    const bridge = host();
    if (typeof bridge.requestStaging !== 'function') throw new Error('Host24 staging-brygga saknas.');
    const request = { stagingApiVersion: STAGING_API_VERSION, operation, ...body };
    try {
      const result = parseResult(bridge.requestStaging(JSON.stringify(request)), `Staging ${operation}`);
      diagnosticsState.staging.lastError = null;
      return result;
    } catch (error) {
      diagnosticsState.staging.lastError = { code: text(error.code), step: operation, message: text(error.message), at: new Date().toISOString() };
      throw error;
    }
  }

  function assertCapabilities(hostInfo) {
    const info = plain(hostInfo) ? hostInfo : {};
    if (Number(info.hostVersionCode) < 35 || typeof host().requestHostData !== 'function') throw new Error('Host35 krävs för P194:s lagring.');
    if (Number(info.nativeStorageApiVersion) !== NATIVE_STORAGE_API_VERSION) throw new Error('Host24 nativeStorageApiVersion 1 krävs.');
    if (Number(info.storageSchemaVersion) !== STORAGE_SCHEMA_VERSION) throw new Error('Host24 storageSchemaVersion 1 krävs.');
    if (Number(info.stagingApiVersion) !== STAGING_API_VERSION) throw new Error('Host24 stagingApiVersion 1 krävs.');
    if (typeof host().requestNativeStorage !== 'function' || typeof host().requestStaging !== 'function') throw new Error('Host24:s trusted native bridge är ofullständig.');
    const storage = nativeRequest('STATUS');
    const staging = stagingRequest('STATUS');
    if (Number(storage.nativeStorageApiVersion) !== 1 || Number(storage.storageSchemaVersion) !== 1) throw new Error('Host24 native storage-status är inkompatibel.');
    if (Number(staging.stagingApiVersion) !== 1) throw new Error('Host24 staging-status är inkompatibel.');
    diagnosticsState.adapterStatus = 'host-verified';
    diagnosticsState.staging.transfers = array(staging.transfers).map(clone);
    return { storage, staging };
  }

  function readLegacyStore(name, fallback) {
    const raw = host().readStore(name);
    if (!raw) return clone(fallback);
    try { return JSON.parse(raw); } catch (_) { throw new Error(`${name}-lagret innehåller ogiltig JSON.`); }
  }

  function writeLegacyStore(name, value) {
    const ok = host().writeStore(name, JSON.stringify(value));
    if (ok !== true) throw new Error((typeof host().getLastError === 'function' && host().getLastError()) || `${name}-lagret kunde inte sparas.`);
    return true;
  }

  function safeToken(value, fallback = 'item') {
    const raw = text(value) || fallback;
    const encoded = encodeURIComponent(raw).replace(/%/g, '-').replace(/[^A-Za-z0-9._:@+-]/g, '_');
    return (encoded || fallback).slice(0, 210);
  }

  function businessId(record, fallback = 'record') {
    const source = plain(record) ? record : {};
    return text(source.id) || text(source.jobId) || text(source.sourceJobId) || text(source.archiveSourceId) || fallback;
  }

  function historyEnvelopeId(kind, record, index = 0) {
    if (kind === 'receipt') return `receipt:${safeToken(record && record.id, `row-${index}`)}`;
    if (kind === 'archive') return `archive:${safeToken((record && (record.archiveSourceId || record.id || record.jobId)), `row-${index}`)}`;
    return `history:${safeToken(businessId(record, `row-${index}`))}`;
  }

  function learningId(kind, record, index = 0) {
    return `learning:${kind}:${safeToken(businessId(record, `row-${index}`))}`;
  }

  function stripLearning(record) {
    const copy = clone(plain(record) ? record : {});
    const learning = {};
    if (plain(copy.p121Learning)) learning.p121Learning = clone(copy.p121Learning);
    if (plain(copy.p116Learning)) learning.p116Learning = clone(copy.p116Learning);
    delete copy.p121Learning;
    delete copy.p116Learning;
    return { record: copy, learning: Object.keys(learning).length ? learning : null };
  }

  function isTrashed(record) {
    const state = plain(record && record.trashState) ? record.trashState : {};
    return text(state.status) === 'trashed' || Boolean(text(state.trashedAt));
  }

  function settingRecord(key, value) {
    return { id: `setting:${safeToken(key, 'setting')}`, payload: { settingKey: key, value: clone(value) } };
  }

  function classifySettings(settings) {
    const source = plain(settings) ? settings : {};
    const registries = [];
    const sync = [];
    const persistent = [];
    const technical = {};
    Object.keys(source).forEach((key) => {
      const value = source[key];
      if (key === RECEIPT_STORE_KEY) return;
      if (SECRET_KEYS.includes(key) || TECHNICAL_KEYS.includes(key)) { technical[key] = clone(value); return; }
      if (REGISTRY_KEYS.includes(key)) { registries.push(settingRecord(key, value)); return; }
      if (SYNC_KEYS.includes(key)) { sync.push(settingRecord(key, value)); return; }
      persistent.push(settingRecord(key, value));
    });
    return { registries, sync, persistent, technical };
  }

  function normalizeHistorySources(historyRecords, receiptRows, archiveRecords) {
    const history = [];
    const trash = [];
    const learning = [];
    array(historyRecords).filter(plain).forEach((item, index) => {
      const split = stripLearning(item);
      const id = historyEnvelopeId('history', split.record, index);
      const envelope = { kind: 'history', record: split.record };
      (isTrashed(split.record) ? trash : history).push({ id, payload: envelope });
      if (split.learning) learning.push({ id: learningId('history', split.record, index), payload: { sourceKind: 'history', sourceId: id, ...split.learning } });
    });
    array(receiptRows).filter(plain).forEach((row, index) => {
      const id = historyEnvelopeId('receipt', row, index);
      history.push({ id, payload: { kind: 'receipt', receiptRow: clone(row) } });
    });
    array(archiveRecords).filter(plain).forEach((item, index) => {
      const split = stripLearning(item);
      const id = historyEnvelopeId('archive', split.record, index);
      history.push({ id, payload: { kind: 'archive', record: split.record } });
      if (split.learning) learning.push({ id: learningId('archive', split.record, index), payload: { sourceKind: 'archive', sourceId: id, ...split.learning } });
    });
    return { history, trash, learning };
  }

  function syncOutboxRecords(value) {
    return array(value).filter(plain).map((item, index) => ({
      id: `sync-outbox:${safeToken(text(item.id) || text(item.requestId) || text(item.letterId), `row-${index}`)}`,
      payload: { kind: 'sync-outbox', value: clone(item), order: index }
    }));
  }

  function canonicalJson(value) {
    if (value === null || typeof value === 'undefined') return 'null';
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
    if (plain(value)) return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
    return JSON.stringify(value);
  }

  // P196: only the outer history collection is unordered. Full records,
  // including event/load arrays and attached learning, keep canonical order.
  function historyCollectionJson(records) {
    if (!Array.isArray(records)) throw new Error('Historiken saknar en giltig lista.');
    const identities = new Set();
    const envelopes = new Set();
    const rows = records.map((record) => {
      const id = plain(record) ? businessId(record, '') : '';
      if (!id) throw new Error('Historikpost saknar stabil identitet.');
      const envelope = historyEnvelopeId('history', record);
      if (identities.has(id) || envelopes.has(envelope)) throw new Error('Historiken innehåller dubbla eller kolliderande postidentiteter.');
      identities.add(id); envelopes.add(envelope);
      return { id, record };
    });
    rows.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    return canonicalJson(rows.map((row) => row.record));
  }

  function uint32(value) {
    const out = new Uint8Array(4); new DataView(out.buffer).setUint32(0, value, false); return out;
  }
  function uint64(value) {
    const out = new Uint8Array(8); const view = new DataView(out.buffer); const n = BigInt(value); view.setUint32(0, Number((n >> 32n) & 0xffffffffn), false); view.setUint32(4, Number(n & 0xffffffffn), false); return out;
  }
  function concatBytes(parts) {
    const total = parts.reduce((sum, part) => sum + part.length, 0); const out = new Uint8Array(total); let offset = 0; parts.forEach((part) => { out.set(part, offset); offset += part.length; }); return out;
  }
  function digestString(value) {
    const bytes = new TextEncoder().encode(value); return concatBytes([uint32(bytes.length), bytes]);
  }
  async function sha256Bytes(bytes) {
    const digest = await crypto.subtle.digest('SHA-256', bytes); return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  async function sha256Text(value) { return sha256Bytes(new TextEncoder().encode(String(value))); }

  async function expectedIntegrity(category, records) {
    const ordered = array(records).map(clone).sort((a, b) => text(a.id).localeCompare(text(b.id), 'en'));
    const pieces = [digestString(`schema:${STORAGE_SCHEMA_VERSION}`), digestString(`category:${category}`)];
    let payloadBytes = 0;
    for (const row of ordered) {
      const payload = new TextEncoder().encode(canonicalJson(row.payload));
      payloadBytes += payload.length;
      pieces.push(digestString(`id:${row.id}`), uint64(payload.length), payload);
    }
    return { recordCount: ordered.length, payloadBytes, sha256: await sha256Bytes(concatBytes(pieces)) };
  }

  function listCategory(category) {
    const records = [];
    let cursor = '';
    for (;;) {
      const result = nativeRequest('LIST', { category, cursor, limit: 500 });
      array(result.records).forEach((row) => records.push({ id: text(row.id), payload: clone(row.payload), updatedAtEpochMs: Number(row.updatedAtEpochMs) || 0 }));
      if (result.hasMore !== true) break;
      cursor = text(result.nextCursor);
      if (!cursor) throw new Error(`Native ${category}: pagineringen saknar cursor.`);
    }
    return records;
  }

  function yieldToBrowser() {
    return new Promise((resolve) => {
      if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(() => resolve());
      else window.setTimeout(resolve, 0);
    });
  }

  async function listCategoryWithProgress(category, state, onProgress) {
    const records = [];
    let cursor = '';
    for (;;) {
      const result = nativeRequest('LIST', { category, cursor, limit: 40 });
      array(result.records).forEach((row) => records.push({ id: text(row.id), payload: clone(row.payload), updatedAtEpochMs: Number(row.updatedAtEpochMs) || 0 }));
      state.loaded += array(result.records).length;
      if (typeof onProgress === 'function') onProgress({ loaded: state.loaded, total: state.total, category });
      if (result.hasMore !== true) break;
      cursor = text(result.nextCursor);
      if (!cursor) throw new Error(`Native ${category}: pagineringen saknar cursor.`);
      await yieldToBrowser();
    }
    return records;
  }

  function normalizeImportRecords(category, records) {
    const byId = new Map();
    for (const row of array(records)) {
      const id = text(row && row.id);
      if (!id || !row || !Object.prototype.hasOwnProperty.call(row, 'payload')) throw new Error(`Källdatan för ${category} innehåller en ogiltig post.`);
      if(byId.has(id))throw new Error(`Dubblett-ID i ${category}: ${id}. Källdatan bevaras.`);
      byId.set(id, { id, payload: clone(row.payload) });
    }
    return Array.from(byId.values());
  }

  function verifyCategoryRecords(category, expectedRecords) {
    const expected = new Map(normalizeImportRecords(category, expectedRecords).map((row) => [row.id, canonicalJson(row.payload)]));
    const actual = listCategory(category);
    if (actual.length !== expected.size) return false;
    const ids = new Set();
    for (const row of actual) {
      if (!expected.has(row.id) || ids.has(row.id) || canonicalJson(row.payload) !== expected.get(row.id)) return false;
      ids.add(row.id);
    }
    return ids.size === expected.size;
  }

  async function importCategory(category, records, migrationState) {
    records = normalizeImportRecords(category, records);
    const entry = migrationState[category];
    if (!entry || !text(entry.importId)) throw new Error('Beständigt import-ID saknas.');
    let status = nativeRequest('IMPORT_STATUS', { category, importId: entry.importId });
    if (status.found && status.state === 'committed') {
      if (!verifyCategoryRecords(category, records)) throw new Error('Avslutad import stämmer inte med källan.');
      return { status: 'verified', after: records.length, importId: entry.importId };
    }
    if (!status.found) nativeRequest('IMPORT_BEGIN', { category, importId: entry.importId });
    else if (status.state !== 'active') throw new Error('Importsessionen kan inte återupptas.');
    for (let i=0;i<records.length;i+=100) nativeRequest('IMPORT_PUT',{ category,importId:entry.importId,records:records.slice(i,i+100) });
    const shadow=nativeRequest('IMPORT_STATUS',{category,importId:entry.importId});
    if(shadow.state!=='active'||shadow.recordCount!==records.length)throw new Error('Shadowimporten är ofullständig.');
    try { nativeRequest('IMPORT_COMMIT',{category,importId:entry.importId}); }
    catch(error) { status=nativeRequest('IMPORT_STATUS',{category,importId:entry.importId});if(status.state!=='committed')throw error; }
    status=nativeRequest('IMPORT_STATUS',{category,importId:entry.importId});
    if(status.state!=='committed'||!verifyCategoryRecords(category,records))throw new Error('Importresultatet kunde inte verifieras.');
    return {status:'verified',after:records.length,importId:entry.importId};
  }

  async function stageLegacyPendingHistorySync(settings) {
    if (!plain(settings) || !plain(settings.historySyncV1)) return settings;
    const state = clone(settings.historySyncV1);
    let changed = false;
    const now = new Date().toISOString();
    if (plain(state.pendingPackage) && plain(state.pendingPackage.payload) && Array.isArray(state.pendingPackage.payload.records)) {
      const transferId = `legacy-history-${safeToken(text(state.pendingPackage.packageId) || Date.now().toString(36))}`.slice(0, 120);
      const legacyPackage = {
        protocol: 'stadslass.mailbox.v1', packageProtocol: 'stadslass.history.v1', kind: 'history-package',
        packageId: text(state.pendingPackage.packageId) || transferId, requestId: text(state.pendingPackage.requestId),
        from: text(state.pendingPackage.from), payload: clone(state.pendingPackage.payload)
      };
      const contentUtf8 = JSON.stringify(legacyPackage);
      const bytes = new TextEncoder().encode(contentUtf8);
      const sha = await sha256Bytes(bytes);
      stagingRequest('CREATE', { transferId });
      stagingRequest('PUT_PART', { transferId, partId: 'part-0', contentUtf8, expectedBytes: bytes.length, expectedSha256: sha });
      state.pendingPackage = {
        packageId: text(state.pendingPackage.packageId) || transferId,
        requestId: text(state.pendingPackage.requestId), from: text(state.pendingPackage.from), receivedAt: text(state.pendingPackage.receivedAt) || now,
        stagingTransferId: transferId, partCount: 1, totalRecordCount: state.pendingPackage.payload.records.length,
        stagingPartIds: ['part-0'], legacyMigratedToStaging: true
      };
      changed = true;
    }
    if (plain(state.pendingTransfer) && plain(state.pendingTransfer.parts)) {
      const source = state.pendingTransfer;
      const transferId = safeToken(text(source.transferId) || `legacy-transfer-${Date.now().toString(36)}`).slice(0, 120);
      stagingRequest('CREATE', { transferId });
      const partIds = [];
      const keys = Object.keys(source.parts).sort((a, b) => Number(a) - Number(b));
      for (const key of keys) {
        const part = source.parts[key];
        if (!plain(part) || !Array.isArray(part.records)) continue;
        const payload = {
          schemaVersion: Number(source.schemaVersion) || 2,
          exportedAt: text(source.exportedAt), sourceUnit: text(source.sourceUnit), scope: text(source.scope) || 'all-history',
          transferId, partIndex: Number(key), partCount: Number(source.partCount), totalRecordCount: Number(source.totalRecordCount), records: clone(part.records)
        };
        const legacyPackage = { protocol: 'stadslass.mailbox.v1', packageProtocol: 'stadslass.history.v1', kind: 'history-package', packageId: text(part.packageId) || `${transferId}-part-${Number(key) + 1}`, requestId: text(source.requestId), from: text(source.from), payload };
        const contentUtf8 = JSON.stringify(legacyPackage); const bytes = new TextEncoder().encode(contentUtf8); const sha = await sha256Bytes(bytes); const partId = `part-${Number(key)}`;
        stagingRequest('PUT_PART', { transferId, partId, contentUtf8, expectedBytes: bytes.length, expectedSha256: sha });
        partIds.push(partId);
      }
      state.pendingTransfer = {
        transferId, requestId: text(source.requestId), from: text(source.from), partCount: Number(source.partCount) || partIds.length,
        totalRecordCount: Number(source.totalRecordCount) || 0, receivedPartIds: partIds, receivedAt: text(source.receivedAt) || now,
        exportedAt: text(source.exportedAt), sourceUnit: text(source.sourceUnit), scope: text(source.scope) || 'all-history', legacyMigratedToStaging: true
      };
      changed = true;
    }
    if (!changed) return settings;
    return { ...settings, historySyncV1: state, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
  }

  function dataRequest(operation,body={}) { return parseResult(host().requestHostData(JSON.stringify({operation,...body})),operation); }
  function saveTechnical(key,value) { const settings=readLegacyStore(SETTINGS_STORE,{});if(value===null)delete settings[key];else settings[key]=clone(value);writeLegacyStore(SETTINGS_STORE,settings); }
  function validateNativeCategory(category) {
    const rows=listCategory(category), integrity=nativeRequest('INTEGRITY',{category});
    if(rows.length!==integrity.recordCount||new Set(rows.map(r=>r.id)).size!==rows.length)throw new Error(`Native ${category} är skadad.`);
    return rows;
  }
  function verifyBusinessInvariants(){
    const historyIds=new Set(listCategory('history').map(r=>r.id));
    if(listCategory('trash').some(r=>historyIds.has(r.id)))throw new Error('Samma record-ID finns i både Historik och Papperskorg. Data bevaras för kontrollerad återhämtning.');
  }
  async function migrate({ archiveRecords = [] } = {}) {
    active=false;diagnosticsState.adapterStatus='migrating';diagnosticsState.syncPausedByMigration=true;
    let state=dataRequest('STATUS'),settings=readLegacyStore(SETTINGS_STORE,{});
    const prior=settings[MIGRATION_KEY]||{};
    let journal=settings.p194MigrationV1;
    if(state.state==='PENDING'&&(state.packageVersion!==PACKAGE_VERSION||state.moduleId!=='stadslass.core-mail-sync-reader'))throw new Error('Pending recovery tillhör en annan version.');
    if(state.activeDataContractVersion===2 && state.state!=='PENDING') {
      for(const category of CATEGORIES){if(!dataRequest('CATEGORY_AUTHORITY',{category}).initialized)throw new Error(`Auktoritet saknas för ${category}.`);validateNativeCategory(category);}
    } else {
      if(!journal){
        settings=await stageLegacyPendingHistorySync(settings);
        writeLegacyStore(SETTINGS_STORE,settings);
        journal={owner:LEGACY_RECOVERY_OWNER,operationId:'p194-migrate-'+Date.now().toString(36),categories:{}};
        saveTechnical('p194MigrationV1',journal);
      }
      if(journal.owner!==LEGACY_RECOVERY_OWNER)throw new Error('Fel migrationsägare.');
      state=dataRequest('BEGIN_TRANSITION',{operationId:journal.operationId,fromVersion:1,targetVersion:2});
      if(state.state!=='PENDING'||state.operationId!==journal.operationId)throw new Error('Transitionen kunde inte verifieras.');
      const legacyHistory=readLegacyStore(HISTORY_STORE,[]),legacyOutbox=readLegacyStore(SYNC_OUTBOX_STORE,[]);
      if(!Array.isArray(legacyHistory)||!Array.isArray(legacyOutbox))throw new Error('Ogiltigt legacyformat.');
      const classified=classifySettings(settings),hist=normalizeHistorySources(legacyHistory,array(settings[RECEIPT_STORE_KEY]),archiveRecords);
      const source={history:hist.history,trash:hist.trash,learning:hist.learning,registries:classified.registries,'sync-history':[...classified.sync,...syncOutboxRecords(legacyOutbox)],'persistent-user-data':classified.persistent};
      for(const category of CATEGORIES){
        const authority=dataRequest('CATEGORY_AUTHORITY',{category});validateNativeCategory(category);
        if(!authority.initialized){
          const provenance=prior.schemaVersion===1&&prior.categories&&prior.categories[category]&&prior.categories[category].status==='verified';
          if(provenance) dataRequest('ADOPT_CATEGORY',{category});
          else {
            // Nonempty uninitialised data can only be adopted when it agrees
            // exactly with the retained source; counts never prove authority.
            const current=listCategory(category);
            if(current.length && !verifyCategoryRecords(category,source[category]))throw new Error(`Oklar native-auktoritet i ${category}; data bevaras.`);
            if(verifyCategoryRecords(category,source[category])) dataRequest('ADOPT_CATEGORY',{category});
            else {
              journal.categories[category]=journal.categories[category]||{importId:journal.operationId+'-'+category};saveTechnical('p194MigrationV1',journal);
              await importCategory(category,source[category],journal.categories);
            }
          }
        }
        if(!dataRequest('CATEGORY_AUTHORITY',{category}).initialized)throw new Error(`Auktoritet saknas efter ${category}.`);
        validateNativeCategory(category);journal.categories[category]={...journal.categories[category],status:'verified'};saveTechnical('p194MigrationV1',journal);
      }
      verifyBusinessInvariants();
      state=dataRequest('COMMIT_TRANSITION',{operationId:journal.operationId,targetVersion:2});
      if(state.state!=='COMMITTED'||state.activeDataContractVersion!==2)throw new Error('Migrationens commit kunde inte verifieras.');
    }
    verifyBusinessInvariants();
    // Clean legacy projections only after all six authorities and the transition
    // are durable. Partial cleanup is repeatable, with no reimport on restart.
    settings=readLegacyStore(SETTINGS_STORE,{});
    const technical=classifySettings(settings).technical;
    technical[MIGRATION_KEY]={schemaVersion:1,packageVersion:194,complete:true,categories:Object.fromEntries(CATEGORIES.map(c=>[c,{status:'verified',legacySourceRetained:false}]))};
    technical.settingsSchemaVersion=1;technical.settingsUpdatedByPackageVersion=PACKAGE_VERSION;
    writeLegacyStore(SETTINGS_STORE,technical);writeLegacyStore(HISTORY_STORE,[]);writeLegacyStore(SYNC_OUTBOX_STORE,[]);
    await window.StadslassDataTransactions.recoverBeforeReady();
    await resumeRestore(true);
    diagnosticsState.adapterStatus='ready';diagnosticsState.syncPausedByMigration=false;active=true;
    return clone(technical[MIGRATION_KEY]);
  }

  function loadLearningMap() {
    const rows = listCategory('learning');
    const result = new Map();
    rows.forEach((row) => { if (plain(row.payload) && text(row.payload.sourceId)) result.set(text(row.payload.sourceId), clone(row.payload)); });
    return result;
  }

  function historyProjections() {
    const historyRows = listCategory('history');
    const trashRows = listCategory('trash');
    const learningMap = loadLearningMap();
    const ordinary = [];
    const receipts = [];
    const archive = [];
    const trash = [];
    const attachLearning = (row, envelope) => {
      const record = clone(envelope.record || {}); const learn = learningMap.get(row.id) || learningMap.get(`learning:${text(envelope.kind)}:${safeToken(businessId(record))}`);
      if (plain(learn && learn.p121Learning)) record.p121Learning = clone(learn.p121Learning);
      if (plain(learn && learn.p116Learning)) record.p116Learning = clone(learn.p116Learning);
      return record;
    };
    historyRows.forEach((row) => {
      const envelope = plain(row.payload) ? row.payload : {};
      if (envelope.kind === 'receipt' && plain(envelope.receiptRow)) receipts.push(clone(envelope.receiptRow));
      else if (envelope.kind === 'archive' && plain(envelope.record)) archive.push(attachLearning(row, envelope));
      else if (envelope.kind === 'history' && plain(envelope.record)) ordinary.push(attachLearning(row, envelope));
    });
    trashRows.forEach((row) => { const envelope = plain(row.payload) ? row.payload : {}; if (plain(envelope.record)) trash.push(attachLearning(row, envelope)); });
    return { ordinary, receipts, archive, trash, combinedHistory: [...ordinary, ...trash] };
  }

  async function historyBundleWithProgress(onProgress) {
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    const categories = ['history', 'trash', 'learning'];
    const total = categories.reduce((sum, category) => sum + Math.max(0, Number(nativeRequest('COUNT', { category }).recordCount) || 0), 0);
    const state = { loaded: 0, total };
    if (typeof onProgress === 'function') onProgress({ loaded: 0, total, category: 'start' });
    await yieldToBrowser();
    const historyRows = await listCategoryWithProgress('history', state, onProgress);
    const trashRows = await listCategoryWithProgress('trash', state, onProgress);
    const learningRows = await listCategoryWithProgress('learning', state, onProgress);
    const learningMap = new Map();
    learningRows.forEach((row) => { if (plain(row.payload) && text(row.payload.sourceId)) learningMap.set(text(row.payload.sourceId), clone(row.payload)); });
    const ordinary = [], receipts = [], archive = [], trash = [];
    const attachLearning = (row, envelope) => {
      const record = clone(envelope.record || {}); const learn = learningMap.get(row.id) || learningMap.get(`learning:${text(envelope.kind)}:${safeToken(businessId(record))}`);
      if (plain(learn && learn.p121Learning)) record.p121Learning = clone(learn.p121Learning);
      if (plain(learn && learn.p116Learning)) record.p116Learning = clone(learn.p116Learning);
      return record;
    };
    historyRows.forEach((row) => {
      const envelope = plain(row.payload) ? row.payload : {};
      if (envelope.kind === 'receipt' && plain(envelope.receiptRow)) receipts.push(clone(envelope.receiptRow));
      else if (envelope.kind === 'archive' && plain(envelope.record)) archive.push(attachLearning(row, envelope));
      else if (envelope.kind === 'history' && plain(envelope.record)) ordinary.push(attachLearning(row, envelope));
    });
    trashRows.forEach((row) => { const envelope = plain(row.payload) ? row.payload : {}; if (plain(envelope.record)) trash.push(attachLearning(row, envelope)); });
    if (typeof onProgress === 'function') onProgress({ loaded: total, total, category: 'complete' });
    observedHistory=canonicalJson([...ordinary,...trash]);observedReceipts=canonicalJson(receipts);
    return { ordinary, receipts, archive, trash, combinedHistory: [...ordinary, ...trash] };
  }

  function settingsProjection() {
    const technical = readLegacyStore(SETTINGS_STORE, {});
    const next = plain(technical) ? clone(technical) : {};
    for (const category of ['registries', 'sync-history', 'persistent-user-data']) {
      const rows = listCategory(category);
      rows.forEach((row) => {
        const payload = plain(row.payload) ? row.payload : {};
        if (text(payload.settingKey)) next[payload.settingKey] = clone(payload.value);
      });
    }
    const hp = historyProjections();
    next[RECEIPT_STORE_KEY] = hp.receipts;
    next.settingsSchemaVersion = 1;
    next.settingsUpdatedByPackageVersion = PACKAGE_VERSION;
    return next;
  }

  function writeSettingCategory(category, settings) {
    const classified = classifySettings(settings);
    const desired = category === 'registries' ? classified.registries : (category === 'sync-history' ? classified.sync : classified.persistent);
    const current = listCategory(category);
    const settingCurrentIds = current.filter((row) => plain(row.payload) && text(row.payload.settingKey)).map((row) => row.id);
    const desiredIds = new Set(desired.map((row) => row.id));
    if (desired.length) nativeRequest('BATCH_PUT', { category, records: desired });
    const remove = settingCurrentIds.filter((id) => !desiredIds.has(id));
    if (remove.length) nativeRequest('BATCH_DELETE', { category, ids: remove });
  }

  function writeSettingsProjection(settings) {
    if (window.StadslassRegistrySave) window.StadslassRegistrySave.assertIdle();
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    if(window.StadslassDataTransactions.isBusy()||window.StadslassDataTransactions.hasPending()||readLegacyStore(SETTINGS_STORE,{}).p194RestoreV1)throw new Error('Lagringsåterhämtning pågår.');
    writeSettingCategory('registries', settings);
    writeSettingCategory('sync-history', settings);
    writeSettingCategory('persistent-user-data', settings);
    const classified = classifySettings(settings);
    const technical = { ...classified.technical, settingsSchemaVersion: 1, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    SECRET_KEYS.forEach((key) => { if (Object.prototype.hasOwnProperty.call(settings, key)) technical[key] = clone(settings[key]); });
    const prior = readLegacyStore(SETTINGS_STORE, {});
    for(const key of ['p194DataRecoveryV1','p194MigrationV1','p194RestoreV1']){if(prior[key])technical[key]=clone(prior[key]);else delete technical[key];}
    if (plain(prior[MIGRATION_KEY])) technical[MIGRATION_KEY] = clone(prior[MIGRATION_KEY]);
    writeLegacyStore(SETTINGS_STORE, technical);
    return true;
  }

  async function writeHistoryProjection(records, receipts, expectedHistory, expectedReceipts) {
    if(!active)throw new Error('Native lagringsadaptern är inte redo.');
    const current=historyProjections();
    const historyBaseline=expectedHistory===undefined?(observedHistory===null?null:historyCollectionJson(JSON.parse(observedHistory))):historyCollectionJson(expectedHistory);
    const receiptBaseline=expectedReceipts===undefined?observedReceipts:canonicalJson(expectedReceipts);
    if(historyBaseline!==null&&historyCollectionJson(current.combinedHistory)!==historyBaseline)throw new Error('Historiken har ändrats. Läs om före nytt försök.');
    if(receipts!==undefined&&receiptBaseline!==null&&canonicalJson(current.receipts)!==receiptBaseline)throw new Error('Kvittohistoriken har ändrats. Läs om före nytt försök.');
    historyCollectionJson(records); // Reject ambiguous desired identities before any mutation.
    const desired=normalizeHistorySources(array(records),receipts===undefined?[]:receipts,[]);
    const retained=listCategory('history').filter(r=>!['history',...(receipts===undefined?[]:['receipt'])].includes(r.payload.kind));
    const retainedLearning=listCategory('learning').filter(r=>r.payload.sourceKind!=='history');
    await window.StadslassDataTransactions.mutate({history:[...retained,...desired.history],trash:desired.trash,learning:[...retainedLearning,...desired.learning]});
    observedHistory=canonicalJson(historyProjections().combinedHistory);if(receipts!==undefined)observedReceipts=canonicalJson(historyProjections().receipts);return true;
  }
  async function writeReceiptRows(rows, expectedReceipts) {
    if(!active)throw new Error('Native lagringsadaptern är inte redo.');
    const baseline=expectedReceipts===undefined?observedReceipts:canonicalJson(expectedReceipts);
    if(baseline!==null&&canonicalJson(historyProjections().receipts)!==baseline)throw new Error('Kvittohistoriken har ändrats. Läs om före nytt försök.');
    const retained=listCategory('history').filter(r=>r.payload.kind!=='receipt');
    const desired=normalizeHistorySources([],array(rows),[]).history;
    await window.StadslassDataTransactions.mutate({history:[...retained,...desired]});observedReceipts=canonicalJson(historyProjections().receipts);return true;
  }

  function archiveRecords() { return historyProjections().archive; }
  function historyDocument() { const rows=historyProjections().combinedHistory;observedHistory=canonicalJson(rows);return rows; }
  function receiptRows() { const rows=historyProjections().receipts;observedReceipts=canonicalJson(rows);return rows; }

  function syncOutboxRows() {
    return listCategory('sync-history')
      .filter((row) => plain(row.payload) && row.payload.kind === 'sync-outbox' && plain(row.payload.value))
      .sort((a, b) => Number(a.payload.order) - Number(b.payload.order))
      .map((row) => clone(row.payload.value));
  }

  function mergeLegacySyncOutbox(rows) {
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    const incoming = syncOutboxRecords(rows);
    if (incoming.length) nativeRequest('BATCH_PUT', { category: 'sync-history', records: incoming });
    return true;
  }

  async function stageHistoryPackage(pkg) {
    if (!plain(pkg) || !plain(pkg.payload) || !Array.isArray(pkg.payload.records)) throw new Error('Historikpaketet är ogiltigt.');
    const payload = clone(pkg.payload);
    const transferId = safeToken(text(payload.transferId) || text(pkg.packageId), `history-${Date.now().toString(36)}`).slice(0, 120);
    const partCount = Math.max(1, Number(payload.partCount) || 1);
    const partIndex = partCount > 1 ? Number(payload.partIndex) : 0;
    if (!Number.isInteger(partIndex) || partIndex < 0 || partIndex >= partCount) throw new Error('Historikpaketets partIndex är ogiltigt.');
    const totalRecordCount = Number(payload.totalRecordCount);
    if (partCount > 1 && (!Number.isInteger(totalRecordCount) || totalRecordCount < 0)) throw new Error('Historikpaketets totalRecordCount är ogiltigt.');
    if (text(payload.transferId) && text(payload.transferId) !== transferId) throw new Error('Historikpaketets transferId är ogiltigt.');
    const expectedMultipartPackageId = partCount > 1 ? `${transferId}-part-${partIndex + 1}` : '';
    if (expectedMultipartPackageId && text(pkg.packageId) && text(pkg.packageId) !== expectedMultipartPackageId) throw new Error('Historikpaketets packageId matchar inte transfer/del.');
    if (text(pkg.kind) && text(pkg.kind) !== 'history-package') throw new Error('Historikpaketets kind är ogiltigt.');
    if (text(pkg.packageProtocol) && text(pkg.packageProtocol) !== 'stadslass.history.v1') throw new Error('Historikpaketets protokoll är ogiltigt.');
    const partId = `part-${partIndex}`;
    const contentUtf8 = JSON.stringify(pkg);
    const bytes = new TextEncoder().encode(contentUtf8);
    const sha = await sha256Bytes(bytes);
    stagingRequest('CREATE', { transferId });
    const written = stagingRequest('PUT_PART', { transferId, partId, contentUtf8, expectedBytes: bytes.length, expectedSha256: sha });
    const listing = stagingRequest('LIST', { transferId });
    if (text(listing.integrityStatus) && text(listing.integrityStatus) !== 'ok') throw new Error(`Stagingtransfern har integritetsstatus ${text(listing.integrityStatus)}.`);
    const statusAfterWrite = stagingRequest('STATUS');
    diagnosticsState.staging.transfers = array(statusAfterWrite.transfers).map((row) => {
      const copy = clone(row);
      if (text(copy.transferId) === transferId) {
        copy.receivedPartCount = Number(copy.partCount) || 0;
        copy.expectedPartCount = partCount;
        copy.totalRecordCount = Number.isInteger(totalRecordCount) ? totalRecordCount : null;
      }
      return copy;
    });
    const parts = array(listing.parts);
    const receivedIndices = parts.map((part) => Number(String(part.partId || '').replace(/^part-/, ''))).filter(Number.isInteger).sort((a, b) => a - b);
    const complete = receivedIndices.length === partCount && receivedIndices.every((value, index) => value === index);
    return {
      transferId, partId, partIndex, partCount, totalRecordCount: Number.isInteger(totalRecordCount) ? totalRecordCount : null,
      duplicate: written.duplicate === true, complete, receivedPartIds: parts.map((part) => text(part.partId)).filter(Boolean),
      totalBytes: Number(listing.totalBytes) || 0, integrityStatus: text(listing.integrityStatus), packageId: text(pkg.packageId), requestId: text(pkg.requestId), from: text(pkg.from)
    };
  }

  function readStagedHistoryPayload(meta) {
    const transferId = text(meta && meta.stagingTransferId, text(meta && meta.transferId));
    const partCount = Math.max(1, Number(meta && meta.partCount) || 1);
    if (!transferId) throw new Error('Historikens stagingtransfer saknar ID.');
    const listing = stagingRequest('LIST', { transferId });
    if (text(listing.integrityStatus) !== 'ok') throw new Error(`Historikens stagingtransfer är inte verifierad (${text(listing.integrityStatus, 'okänd')}).`);
    if (array(listing.parts).length !== partCount) throw new Error('Historikens stagingtransfer har fel antal delar.');
    const records = [];
    let first = null;
    for (let index = 0; index < partCount; index += 1) {
      const partId = `part-${index}`;
      const result = stagingRequest('READ_PART', { transferId, partId });
      let decoded;
      try { decoded = JSON.parse(result.contentUtf8); } catch (_) { throw new Error(`Historikdel ${partId} innehåller ogiltig JSON.`); }
      const wrapper = plain(decoded) && plain(decoded.payload) ? decoded : null;
      const payload = wrapper ? wrapper.payload : decoded;
      if (!plain(payload) || !Array.isArray(payload.records)) throw new Error(`Historikdel ${partId} har fel format.`);
      if (wrapper) {
        if (text(wrapper.kind, 'history-package') !== 'history-package' || text(wrapper.packageProtocol, 'stadslass.history.v1') !== 'stadslass.history.v1') throw new Error(`Historikdel ${partId} har fel paketprotokoll.`);
        const expectedPackageId = partCount > 1 ? `${transferId}-part-${index + 1}` : text(meta && meta.packageId);
        if (expectedPackageId && text(wrapper.packageId) && text(wrapper.packageId) !== expectedPackageId) throw new Error(`Historikdel ${partId} har fel packageId.`);
        if (text(meta && meta.requestId) && text(wrapper.requestId) && text(wrapper.requestId) !== text(meta.requestId)) throw new Error(`Historikdel ${partId} har fel requestId.`);
        if (text(meta && meta.from) && text(wrapper.from) && text(wrapper.from) !== text(meta.from)) throw new Error(`Historikdel ${partId} har fel avsändare.`);
      }
      const payloadTransferId = text(payload.transferId) || transferId;
      if (payloadTransferId !== transferId) throw new Error(`Historikdel ${partId} tillhör fel transfer.`);
      const declaredCount = Math.max(1, Number(payload.partCount) || 1);
      const declaredIndex = declaredCount > 1 ? Number(payload.partIndex) : 0;
      if (declaredCount !== partCount || declaredIndex !== index) throw new Error(`Historikdel ${partId} har fel delidentitet.`);
      if (!first) first = payload;
      records.push(...payload.records.map(clone));
    }
    const expectedTotal = Number(meta && meta.totalRecordCount);
    if (Number.isInteger(expectedTotal) && expectedTotal >= 0 && records.length !== expectedTotal) throw new Error('Stagingdelarna ger fel totalt antal historikposter.');
    return {
      schemaVersion: Number(first && first.schemaVersion) || 2,
      exportedAt: text(first && first.exportedAt), sourceUnit: text(first && first.sourceUnit), scope: text(first && first.scope) || 'all-history',
      transferId, partCount, totalRecordCount: records.length, records
    };
  }

  function deleteStagedTransfer(transferId) {
    if (!text(transferId)) return false;
    stagingRequest('DELETE_TRANSFER', { transferId: text(transferId) });
    const statusAfterDelete = stagingRequest('STATUS');
    diagnosticsState.staging.transfers = array(statusAfterDelete.transfers).map(clone);
    return true;
  }

  function exportCategoriesForBackup() {
    const result = {};
    for (const category of CATEGORIES) result[category] = listCategory(category).map((row) => ({ id: row.id, payload: clone(row.payload) }));
    // transient transfer state cannot be restored without staging files; strip only the temporary pending transfer/package bodies/refs.
    result['sync-history'] = result['sync-history'].map((row) => {
      if (!plain(row.payload) || row.payload.settingKey !== 'historySyncV1' || !plain(row.payload.value)) return row;
      const value = clone(row.payload.value);
      delete value.pendingTransfer;
      delete value.pendingPackage;
      return { ...row, payload: { ...row.payload, value } };
    });
    return result;
  }

  const SECRET_FIELD_NAMES = Object.freeze(new Set([
    ...SECRET_KEYS.map((key) => key.replace(/[^A-Za-z0-9]/g, '').toLocaleLowerCase('en-US')),
    'token', 'accesstoken', 'refreshtoken', 'apikey', 'privatekey', 'password', 'secret', 'credentials', 'credential', 'pem', 'jks'
  ]));

  function secretKeyName(value) {
    const key = text(value).replace(/[^A-Za-z0-9]/g, '').toLocaleLowerCase('en-US');
    return SECRET_FIELD_NAMES.has(key);
  }

  function assertNoSecrets(value, path = 'backup') {
    if (typeof value === 'string') {
      if (/AIza[0-9A-Za-z_-]{20,100}|github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9]+|-----BEGIN [^-]*PRIVATE KEY-----/.test(value)) {
        throw new Error(`Backup innehåller secret-liknande värde: ${path}`);
      }
      return;
    }
    if (Array.isArray(value)) { value.forEach((item, index) => assertNoSecrets(item, `${path}[${index}]`)); return; }
    if (!plain(value)) return;
    if (secretKeyName(value.settingKey) && value.value != null && String(value.value).trim() !== '') {
      throw new Error(`Backup innehåller förbjuden secretinställning: ${path}.${text(value.settingKey)}`);
    }
    Object.keys(value).forEach((key) => {
      if (secretKeyName(key) && value[key] != null && String(value[key]).trim() !== '') throw new Error(`Backup innehåller förbjudet secretfält: ${path}.${key}`);
      assertNoSecrets(value[key], `${path}.${key}`);
    });
  }

  async function createBackup() {
    if (window.StadslassRegistrySave) window.StadslassRegistrySave.assertIdle();
    if(!active)throw new Error('Lagringsåterhämtning pågår.');
    if(window.StadslassDataTransactions.isBusy()||window.StadslassDataTransactions.hasPending()||readLegacyStore(SETTINGS_STORE,{}).p194RestoreV1)throw new Error('Backup väntar på lagringsåterhämtning.');
    const categories = exportCategoriesForBackup();
    const backup = {
      schemaVersion: 2,
      format: 'stadslass-backup',
      source: { app: 'Stadslass 3.0', exportedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION, storageSchemaVersion: STORAGE_SCHEMA_VERSION },
      data: { nativeCategories: categories }
    };
    assertNoSecrets(backup);
    return backup;
  }

  function validateBackupV2(value) {
    if (!plain(value) || value.format !== 'stadslass-backup' || Number(value.schemaVersion) !== 2 || !plain(value.data) || !plain(value.data.nativeCategories)) throw new Error('Backupfilen har fel P158-format.');
    const categories = value.data.nativeCategories;
    const unknown = Object.keys(categories).filter((category) => !CATEGORIES.includes(category));
    if (unknown.length) throw new Error(`Backup innehåller okända native kategorier: ${unknown.join(', ')}.`);
    CATEGORIES.forEach((category) => {
      if (!Array.isArray(categories[category])) throw new Error(`Backup saknar obligatorisk kategori: ${category}.`);
      const ids = new Set();
      categories[category].forEach((row) => {
        if (!plain(row) || !text(row.id) || !Object.prototype.hasOwnProperty.call(row, 'payload')) throw new Error(`Backupkategorin ${category} innehåller en ogiltig post.`);
        if (ids.has(row.id)) throw new Error(`Backupkategorin ${category} innehåller dubblett-ID.`);
        ids.add(row.id);
      });
    });
    assertNoSecrets(value);
    return clone(categories);
  }

  async function readRestoreIntent() {
    const marker=readLegacyStore(SETTINGS_STORE,{}).p194RestoreV1;
    if(!marker)return null;
    if(marker.owner!==LEGACY_RECOVERY_OWNER)throw new Error('Backupåterhämtning kräver rätt version.');
    const part=stagingRequest('READ_PART',{transferId:marker.transferId,partId:'backup'});
    if(part.sha256!==marker.sha256||await sha256Text(part.contentUtf8)!==marker.sha256)throw new Error('Backupens recoveryunderlag är skadat.');
    return {marker,categories:validateBackupV2(JSON.parse(part.contentUtf8))};
  }
  async function resumeRestore(beforeReady=false) {
    const intent=await readRestoreIntent();if(!intent)return false;
    const {marker,categories}=intent;
    if(!['history','trash','learning'].every(c=>verifyCategoryRecords(c,categories[c]))){
      if(beforeReady)return true;
      if(window.StadslassDataTransactions.hasPending())await window.StadslassDataTransactions.recover();
      if(!['history','trash','learning'].every(c=>verifyCategoryRecords(c,categories[c]))) {
        await window.StadslassDataTransactions.mutate(Object.fromEntries(['history','trash','learning'].map(c=>[c,categories[c]])));
      }
    }
    if(window.StadslassDataTransactions.hasPending()) {
      if(!beforeReady)await window.StadslassDataTransactions.recover();
    }
    for(const category of ['registries','sync-history','persistent-user-data']) {
      await importCategory(category,categories[category],Object.fromEntries(CATEGORIES.map(c=>[c,{importId:marker.transferId+'-'+c}])));
    }
    for(const category of CATEGORIES)if(!verifyCategoryRecords(category,categories[category]))throw new Error(`Backup ${category} är inte exakt återställd.`);
    if(beforeReady&&window.StadslassDataTransactions.hasPending())return true;
    saveTechnical('p194RestoreV1',null);
    try{stagingRequest('DELETE_TRANSFER',{transferId:marker.transferId});}catch(_){/* Only an orphaned technical copy remains. */}
    return false;
  }
  async function restoreBackupV2(value) {
    if (window.StadslassRegistrySave) window.StadslassRegistrySave.assertIdle();
    validateBackupV2(value);
    if(readLegacyStore(SETTINGS_STORE,{}).p194RestoreV1||window.StadslassDataTransactions.hasPending()||window.StadslassDataTransactions.isBusy())throw new Error('En tidigare lagringsoperation måste återhämtas först.');
    active=false;diagnosticsState.adapterStatus='restoring';
    try{
    const transferId='p194-restore-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);
    const contentUtf8=JSON.stringify(value),sha256=await sha256Text(contentUtf8),expectedBytes=new TextEncoder().encode(contentUtf8).length;
    stagingRequest('CREATE',{transferId});stagingRequest('PUT_PART',{transferId,partId:'backup',contentUtf8,expectedBytes,expectedSha256:sha256});
    const check=stagingRequest('READ_PART',{transferId,partId:'backup'});
    if(check.sha256!==sha256||check.contentUtf8!==contentUtf8)throw new Error('Backupens recoveryunderlag kunde inte verifieras.');
    saveTechnical('p194RestoreV1',{owner:LEGACY_RECOVERY_OWNER,transferId,sha256});
    await resumeRestore();
    active=true;diagnosticsState.adapterStatus='ready';
    return {ok:true,categories:Object.fromEntries(CATEGORIES.map(c=>[c,value.data.nativeCategories[c].length]))};
    }finally{if(!readLegacyStore(SETTINGS_STORE,{}).p194RestoreV1){active=true;diagnosticsState.adapterStatus='ready';}}
  }

  async function finishRecoveryAfterReady(){
    active=false;
    await window.StadslassDataTransactions.recover();
    const restored=Boolean(readLegacyStore(SETTINGS_STORE,{}).p194RestoreV1);
    await resumeRestore();active=true;return {restored};
  }

  function pendingHistoryTransferMeta() {
    try {
      const row = listCategory('sync-history').find((item) => plain(item.payload) && item.payload.settingKey === 'historySyncV1' && plain(item.payload.value));
      const state = row && row.payload ? row.payload.value : null;
      const pending = plain(state && state.pendingTransfer) ? state.pendingTransfer : (plain(state && state.pendingPackage) ? state.pendingPackage : null);
      if (!pending) return null;
      return {
        transferId: text(pending.stagingTransferId, text(pending.transferId)),
        expectedPartCount: Math.max(1, Number(pending.partCount) || 1),
        totalRecordCount: Number.isFinite(Number(pending.totalRecordCount)) ? Number(pending.totalRecordCount) : null
      };
    } catch (_) { return null; }
  }

  async function refreshDiagnostics() {
    const storage = nativeRequest('STATUS');
    const staging = stagingRequest('STATUS');
    const pending = pendingHistoryTransferMeta();
    diagnosticsState.staging.transfers = array(staging.transfers).map((row) => {
      const copy = clone(row);
      copy.receivedPartCount = Number(copy.partCount) || 0;
      if (pending && text(copy.transferId) === pending.transferId) {
        copy.expectedPartCount = pending.expectedPartCount;
        copy.totalRecordCount = pending.totalRecordCount;
      } else {
        copy.expectedPartCount = Number(copy.partCount) || 0;
      }
      return copy;
    });
    diagnosticsState.nativeCategories = array(storage.categories).map(clone);
    return diagnostics();
  }

  function diagnostics() {
    return clone({ ...diagnosticsState, lastError: diagnosticsState.lastError || (lastError ? { message: text(lastError.message) } : null), sourceCounts: migrationSnapshot && migrationSnapshot.sourceCounts ? clone(migrationSnapshot.sourceCounts) : {} });
  }

  window.StadslassNativeStorage = Object.freeze({
    PACKAGE_VERSION, NATIVE_STORAGE_API_VERSION, STORAGE_SCHEMA_VERSION, STAGING_API_VERSION, MIGRATION_KEY, CATEGORIES,
    assertCapabilities, migrate, isActive: () => active, setActive: (value) => { active = value === true; },
    settingsProjection, writeSettingsProjection, historyDocument, historyBundleWithProgress, writeHistoryProjection, receiptRows, writeReceiptRows, archiveRecords, syncOutboxRows, mergeLegacySyncOutbox,
    listCategory, expectedIntegrity, nativeRequest, stagingRequest,
    stageHistoryPackage, readStagedHistoryPayload, deleteStagedTransfer,
    createBackup, validateBackupV2, restoreBackupV2, exportCategoriesForBackup, finishRecoveryAfterReady,
    diagnostics, refreshDiagnostics, classifySettings, normalizeHistorySources, assertNoSecrets,
    _test: Object.freeze({ canonicalJson, historyEnvelopeId, safeToken, stripLearning, isTrashed, settingRecord })
  });
})();
