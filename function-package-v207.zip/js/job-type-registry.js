(() => {
  'use strict';

  const SETTINGS_KEY = 'editableJobTypeRegistryV1';
  const SCHEMA_VERSION = 7;
  const LEGACY_SCHEMA_VERSIONS = Object.freeze([1, 2, 3, 4, 5, 6]);
  const SPECIAL_ROLES = Object.freeze(['none', 'other-activity', 'havstang', 'machine-transport']);
  const USER_SELECTABLE_SPECIAL_ROLES = Object.freeze(['none', 'havstang']);
  const SYSTEM_CANONICAL_IDS = Object.freeze(['JT-1001', 'JT-1011']);
  const MANUAL_ID_PATTERN = /^JT3-[0-9a-f]{32}$/;
  const CANONICAL_ID_PATTERN = /^JT-[0-9]{4}$/;
  const PROTECTED_ROLE_CANONICAL_IDS = Object.freeze({
    'other-activity': 'JT-1001',
    'machine-transport': 'JT-1011',
    'havstang': 'JT-1010'
  });

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function isSystemDefinition(item) {
    return SYSTEM_CANONICAL_IDS.includes(text(item && item.canonicalTypeId));
  }

  function normalizedName(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function nameKey(value) {
    return normalizedName(value).toLocaleLowerCase('sv-SE');
  }

  function referenceFields(reference) {
    if (typeof reference === 'string') {
      return { id: text(reference), canonicalId: '', name: '' };
    }
    const value = isPlainObject(reference) ? reference : {};
    return {
      id: text(value.jobTypeId, text(value.id)),
      canonicalId: text(value.jobTypeCanonicalId, text(value.canonicalTypeId, text(value.legacyId))),
      name: normalizedName(value.jobTypeName || value.name || value.jobType)
    };
  }

  function resolveReference(reference, items = []) {
    const typeList = Array.isArray(items) ? items : [];
    const fields = referenceFields(reference);
    const exactId = fields.id
      ? typeList.find((item) => item && text(item.id) === fields.id)
      : null;
    if (exactId) return { status: 'resolved', match: exactId, mode: 'stable-id' };

    const canonicalCandidates = [fields.canonicalId, fields.id].filter(Boolean);
    for (const canonicalId of canonicalCandidates) {
      const exactCanonical = typeList.find((item) => item && text(item.canonicalTypeId) === canonicalId);
      if (exactCanonical) return { status: 'resolved', match: exactCanonical, mode: 'canonical-id' };
    }

    const nameCandidates = [fields.name];
    if (fields.id && !MANUAL_ID_PATTERN.test(fields.id) && !CANONICAL_ID_PATTERN.test(fields.id)) {
      nameCandidates.push(normalizedName(fields.id));
    }
    const keys = Array.from(new Set(nameCandidates.map(nameKey).filter(Boolean)));
    if (keys.length === 0) return { status: 'missing', match: null, mode: '' };
    const matches = typeList.filter((item) => {
      const names = [item && item.name].concat(Array.isArray(item && item.aliases) ? item.aliases : []);
      return names.some((candidate) => keys.includes(nameKey(candidate)));
    });
    if (matches.length === 1) return { status: 'resolved', match: matches[0], mode: 'exact-name-or-alias' };
    if (matches.length > 1) return { status: 'ambiguous', match: null, mode: 'exact-name-or-alias' };
    return { status: 'missing', match: null, mode: '' };
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function emptyRegistry() {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      removedDefaultIds: [],
      items: []
    };
  }

  function randomBytes() {
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(bytes);
      return bytes;
    }
    const seed = `${Date.now()}-${Math.random()}-${Math.random()}`;
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = seed.charCodeAt(index % seed.length) ^ Math.floor(Math.random() * 256);
    }
    return bytes;
  }

  function generateStableId(items = []) {
    const existing = new Set(items.map((item) => text(item && item.id)));
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const hex = Array.from(randomBytes(), (value) => value.toString(16).padStart(2, '0')).join('');
      const id = `JT3-${hex}`;
      if (!existing.has(id)) return id;
    }
    throw new Error('Ett unikt jobbtyps-ID kunde inte skapas.');
  }

  function technicalFields(source) {
    const value = isPlainObject(source) ? source : {};
    const result = {};
    [
      'canonicalTypeId', 'defaultDefinition', 'aliases', 'phaseModel', 'timeReportingScope',
      'vehicleUsage', 'requiresRoute', 'supportsReturn', 'supportsMultiLoad', 'supportsWeight',
      'usesGps', 'defaultDestinationPlaceId'
    ].forEach((field) => {
      if (Object.prototype.hasOwnProperty.call(value, field)) result[field] = clone(value[field]);
    });
    return result;
  }

  function defaultToRegistryItem(item, timestamp) {
    if (!isPlainObject(item)) throw new Error('En standardjobbtyp har fel format.');
    const canonicalTypeId = text(item.canonicalTypeId) || text(item.id);
    const id = text(item.registryId);
    if (!CANONICAL_ID_PATTERN.test(canonicalTypeId) || !MANUAL_ID_PATTERN.test(id)) {
      throw new Error('En standardjobbtyp saknar stabilt register- eller kompatibilitets-ID.');
    }
    return {
      id,
      name: normalizedName(item.name),
      specialRole: text(item.specialRole) || 'none',
      createdAt: timestamp,
      updatedAt: timestamp,
      ...technicalFields({ ...item, canonicalTypeId, defaultDefinition: true })
    };
  }

  function validateItem(item, { schemaVersion = SCHEMA_VERSION } = {}) {
    if (!isPlainObject(item)) throw new Error('En jobbtyp har fel format.');
    if (!MANUAL_ID_PATTERN.test(text(item.id))) throw new Error('En jobbtyp saknar ett giltigt stabilt ID.');
    if (!normalizedName(item.name)) throw new Error('Jobbtypens namn saknas.');
    if (normalizedName(item.name).length > 100) throw new Error('Jobbtypens namn får vara högst 100 tecken.');
    if (schemaVersion === 1 && typeof item.active !== 'boolean') throw new Error('Jobbtypens äldre aktiv-status är ogiltig.');
    if (schemaVersion !== 1 && Object.prototype.hasOwnProperty.call(item, 'active')) throw new Error('Jobbtypen innehåller en inaktuell aktiv-status.');
    if (schemaVersion <= 3) {
      if (!['required', 'optional', 'not-used'].includes(text(item.weightMode))) throw new Error('Jobbtypens äldre viktinställning är ogiltig.');
    } else if (Object.prototype.hasOwnProperty.call(item, 'weightMode')) {
      throw new Error('Jobbtypen innehåller ett inaktuellt viktfält.');
    }
    if (schemaVersion < 3) {
      if (typeof item.supportsReturn !== 'boolean') throw new Error('Jobbtypens äldre returinställning är ogiltig.');
      if (typeof item.supportsMultiLoad !== 'boolean') throw new Error('Jobbtypens äldre flerlassinställning är ogiltig.');
    }
    if (!SPECIAL_ROLES.includes(text(item.specialRole))) throw new Error('Jobbtypens specialtyp är ogiltig.');
    if (!text(item.createdAt) || !text(item.updatedAt)) throw new Error('Jobbtypens tidsstämplar saknas.');
    if (text(item.canonicalTypeId) && !CANONICAL_ID_PATTERN.test(text(item.canonicalTypeId))) {
      throw new Error('Jobbtypens kompatibilitets-ID är ogiltigt.');
    }
    if (Object.prototype.hasOwnProperty.call(item, 'aliases') && !Array.isArray(item.aliases)) {
      throw new Error('Jobbtypens alias har fel format.');
    }
    if (Object.prototype.hasOwnProperty.call(item, 'ataEnabled') && typeof item.ataEnabled !== 'boolean') {
      throw new Error('Jobbtypens ÄTA-inställning är ogiltig.');
    }
    if (Object.prototype.hasOwnProperty.call(item, 'ataRecipient') && item.ataRecipient !== null && !isPlainObject(item.ataRecipient)) {
      throw new Error('Jobbtypens ÄTA-mottagare har fel format.');
    }
    if (text(item.canonicalTypeId) === 'JT-1014' && item.ataEnabled === true) {
      throw new Error('Den särskilda manuella jobbtypen kan bara välja ÄTA per uppdrag.');
    }
    return true;
  }

  function validateItems(items, { schemaVersion = SCHEMA_VERSION } = {}) {
    if (!Array.isArray(items)) throw new Error('Jobbtypsregistret saknar en giltig lista.');
    const ids = new Set();
    const canonicalIds = new Set();
    const names = new Set();
    const specialRoles = new Set();
    items.forEach((item) => {
      validateItem(item, { schemaVersion });
      const id = text(item.id);
      const key = nameKey(item.name);
      const canonical = text(item.canonicalTypeId);
      if (ids.has(id)) throw new Error('Jobbtypsregistret innehåller dubbla ID:n.');
      if (names.has(key)) throw new Error('Det finns redan en jobbtyp med samma namn.');
      if (canonical && canonicalIds.has(canonical)) throw new Error('Jobbtypsregistret innehåller dubbla kompatibilitets-ID:n.');
      ids.add(id);
      names.add(key);
      if (canonical) canonicalIds.add(canonical);
      if ((schemaVersion !== 1 || item.active) && item.specialRole !== 'none') {
        if (specialRoles.has(item.specialRole)) throw new Error('Det kan bara finnas en jobbtyp per skyddad specialtyp.');
        specialRoles.add(item.specialRole);
      }
    });
    return true;
  }

  function validateRegistry(registry) {
    if (!isPlainObject(registry)) throw new Error('Jobbtypsregistret har fel format.');
    if (registry.schemaVersion !== SCHEMA_VERSION) throw new Error('Jobbtypsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Jobbtypsregistret har en ogiltig revision.');
    if (!Array.isArray(registry.removedDefaultIds)) throw new Error('Jobbtypsregistrets borttagningsspår har fel format.');
    registry.removedDefaultIds.forEach((id) => {
      if (!CANONICAL_ID_PATTERN.test(text(id))) throw new Error('Jobbtypsregistrets borttagningsspår innehåller ett ogiltigt ID.');
    });
    validateItems(registry.items);
    return true;
  }

  function normalizedInput(input) {
    const value = isPlainObject(input) ? input : {};
    return {
      name: normalizedName(value.name),
      specialRole: text(value.specialRole) || 'none',
      ataEnabled: value.ataEnabled === true,
      ataRecipient: isPlainObject(value.ataRecipient) ? clone(value.ataRecipient) : null,
      ataRecipientSpecified: Object.prototype.hasOwnProperty.call(value, 'ataRecipient')
    };
  }

  function createItem(input, existingItems = [], timestamp = new Date().toISOString()) {
    const normalized = normalizedInput(input);
    if (!USER_SELECTABLE_SPECIAL_ROLES.includes(normalized.specialRole)) throw new Error('Den valda specialtypen får inte skapas manuellt.');
    const item = {
      id: generateStableId(existingItems),
      name: normalized.name,
      specialRole: normalized.specialRole,
      createdAt: timestamp,
      updatedAt: timestamp,
      aliases: [],
      defaultDefinition: false,
      ataEnabled: normalized.ataEnabled,
      ataRecipient: normalized.ataRecipient
    };
    validateItems(existingItems.concat(item));
    return item;
  }

  function updateItem(current, input, existingItems = [], timestamp = new Date().toISOString()) {
    validateItem(current);
    const normalized = normalizedInput(input);
    const protectedDefault = current.defaultDefinition === true;
    const specialRole = protectedDefault ? current.specialRole : normalized.specialRole;
    if (!SPECIAL_ROLES.includes(specialRole) || (!protectedDefault && !USER_SELECTABLE_SPECIAL_ROLES.includes(specialRole))) {
      throw new Error('Jobbtypens specialtyp är ogiltig.');
    }
    const preservedAliases = Array.isArray(current.aliases) ? current.aliases.slice() : [];
    if (nameKey(current.name) !== nameKey(normalized.name) && !preservedAliases.some((alias) => nameKey(alias) === nameKey(current.name))) {
      preservedAliases.push(current.name);
    }
    const updated = {
      ...current,
      name: normalized.name,
      specialRole,
      ataEnabled: text(current.canonicalTypeId) === 'JT-1014' ? false : normalized.ataEnabled,
      ataRecipient: normalized.ataRecipientSpecified ? normalized.ataRecipient : (isPlainObject(current.ataRecipient) ? clone(current.ataRecipient) : null),
      aliases: preservedAliases,
      updatedAt: timestamp
    };
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Jobbtypen som skulle redigeras saknas.');
    validateItems(nextItems);
    return updated;
  }

  function removeItem(current, existingItems = []) {
    validateItem(current);
    if (!existingItems.some((item) => item.id === current.id)) throw new Error('Jobbtypen som skulle tas bort saknas.');
    const nextItems = existingItems.filter((item) => item.id !== current.id);
    validateItems(nextItems);
    return nextItems;
  }

  function legacyToSchemaFive(registry, timestamp) {
    if (!LEGACY_SCHEMA_VERSIONS.includes(registry.schemaVersion)) throw new Error('Jobbtypsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Jobbtypsregistret har en ogiltig revision.');
    validateItems(registry.items, { schemaVersion: registry.schemaVersion });
    const items = registry.items.map((item) => {
      const {
        active: _discardedActiveStatus,
        weightMode: _discardedWeightMode,
        supportsReturn: _discardedReturnSetting,
        supportsMultiLoad: _discardedMultiLoadSetting,
        ...preserved
      } = item;
      return {
        ...preserved,
        aliases: Array.isArray(preserved.aliases) ? preserved.aliases.slice() : [],
        defaultDefinition: preserved.defaultDefinition === true
      };
    });
    return {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      removedDefaultIds: Array.isArray(registry.removedDefaultIds) ? registry.removedDefaultIds.slice() : [],
      items
    };
  }

  // P108: Äldre installationer kan innehålla flera varianter av en skyddad
  // specialtyp. Behåll samtliga poster och stabila ID:n, men låt endast den
  // kanoniska/defaulta posten bära den skyddade rollen före valideringen.
  function normalizeProtectedRoleDuplicates(registry) {
    if (!isPlainObject(registry) || !Array.isArray(registry.items)) return { registry, changed: false };
    const items = registry.items.map((item) => isPlainObject(item) ? { ...item } : item);
    let changed = false;
    Object.entries(PROTECTED_ROLE_CANONICAL_IDS).forEach(([role, canonicalId]) => {
      const candidates = items
        .map((item, index) => ({ item, index }))
        .filter(({ item }) => isPlainObject(item) && text(item.specialRole) === role);
      if (candidates.length < 2) return;
      const preferred = candidates.find(({ item }) => text(item.canonicalTypeId) === canonicalId)
        || candidates.find(({ item }) => item.defaultDefinition === true)
        || candidates[0];
      candidates.forEach(({ item, index }) => {
        if (index === preferred.index) return;
        items[index] = { ...item, specialRole: 'none' };
        changed = true;
      });
    });
    return { registry: changed ? { ...registry, items } : registry, changed };
  }

  function exactDefaultMatch(items, definition) {
    const canonical = text(definition.canonicalTypeId) || text(definition.id);
    const stable = text(definition.registryId);
    return items.find((item) => text(item.id) === stable || text(item.canonicalTypeId) === canonical) || null;
  }

  function exactUniqueNameMatch(items, definition, claimedIds) {
    const candidates = [definition.name].concat(Array.isArray(definition.aliases) ? definition.aliases : []).map(nameKey).filter(Boolean);
    const matches = items.filter((item) => !claimedIds.has(item.id) && [item.name].concat(Array.isArray(item.aliases) ? item.aliases : []).some((candidate) => candidates.includes(nameKey(candidate))));
    return matches.length === 1 ? matches[0] : null;
  }

  function mergeDefaultIntoItem(current, definition, timestamp) {
    const canonicalTypeId = text(definition.canonicalTypeId) || text(definition.id);
    return {
      ...current,
      ...technicalFields({ ...definition, canonicalTypeId, defaultDefinition: true }),
      id: current.id,
      name: current.name,
      specialRole: text(definition.specialRole) || text(current.specialRole) || 'none',
      createdAt: text(current.createdAt) || timestamp,
      updatedAt: text(current.updatedAt) || timestamp
    };
  }

  function migrateAndMergeRegistry(stored, defaultItems = [], timestamp = new Date().toISOString()) {
    let registry;
    let migrated = false;
    const normalizedStored = normalizeProtectedRoleDuplicates(stored);
    if (typeof stored === 'undefined' || stored === null) {
      registry = emptyRegistry();
      migrated = true;
    } else if (isPlainObject(normalizedStored.registry) && normalizedStored.registry.schemaVersion === SCHEMA_VERSION) {
      validateRegistry(normalizedStored.registry);
      registry = clone(normalizedStored.registry);
      migrated = normalizedStored.changed;
    } else {
      registry = legacyToSchemaFive(normalizedStored.registry, timestamp);
      migrated = true;
    }

    const removed = new Set(registry.removedDefaultIds.map(text));
    // Systemjobbtyper kan aldrig döljas av äldre importerade borttagningsmarkeringar.
    SYSTEM_CANONICAL_IDS.forEach((id) => removed.delete(id));
    const items = registry.items.map((item) => ({ ...item, aliases: Array.isArray(item.aliases) ? item.aliases.slice() : [] }));
    const claimedIds = new Set();
    let changed = false;

    defaultItems.forEach((definition) => {
      const canonical = text(definition.canonicalTypeId) || text(definition.id);
      if (!CANONICAL_ID_PATTERN.test(canonical) || (removed.has(canonical) && !SYSTEM_CANONICAL_IDS.includes(canonical))) return;
      let match = exactDefaultMatch(items, definition);
      if (!match) match = exactUniqueNameMatch(items, definition, claimedIds);
      if (match) {
        const index = items.findIndex((item) => item.id === match.id);
        const enriched = mergeDefaultIntoItem(match, definition, timestamp);
        if (JSON.stringify(enriched) !== JSON.stringify(match)) changed = true;
        items[index] = enriched;
        claimedIds.add(enriched.id);
        return;
      }
      const created = defaultToRegistryItem(definition, timestamp);
      if (items.some((item) => item.id === created.id)) throw new Error('En standardjobbtyp krockar med ett befintligt stabilt ID.');
      items.push(created);
      claimedIds.add(created.id);
      changed = true;
    });

    // P109: Standardsammanslagningen kan introducera en skyddad roll från en
    // äldre post med ett annat namn. Normalisera därför även den färdiga
    // sammanslagningen innan den slutliga valideringen. Äldre poster och deras
    // stabila ID:n bevaras; endast den dubbla rollen tas bort.
    const normalizedMerged = normalizeProtectedRoleDuplicates({ ...registry, items });
    if (normalizedMerged.changed) changed = true;
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: changed || migrated ? registry.revision + 1 : registry.revision,
      updatedAt: changed || migrated ? timestamp : registry.updatedAt,
      removedDefaultIds: Array.from(removed).sort(),
      items: normalizedMerged.registry.items
    };
    validateRegistry(next);
    return { registry: next, migrated: migrated || changed };
  }

  function migrateRegistry(registry, timestamp = new Date().toISOString()) {
    return migrateAndMergeRegistry(registry, [], timestamp);
  }

  function withItems(registry, items, timestamp = new Date().toISOString(), options = {}) {
    validateRegistry(registry);
    validateItems(items);
    const removed = new Set(registry.removedDefaultIds.map(text));
    const previousById = new Map(registry.items.map((item) => [item.id, item]));
    registry.items.forEach((item) => {
      if (items.some((candidate) => candidate.id === item.id)) return;
      if (item.defaultDefinition === true && text(item.canonicalTypeId) && !isSystemDefinition(item)) removed.add(text(item.canonicalTypeId));
    });
    if (Array.isArray(options.restoreDefaultIds)) options.restoreDefaultIds.forEach((id) => removed.delete(text(id)));
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      removedDefaultIds: Array.from(removed).sort(),
      items: items.map((item) => ({ ...item, createdAt: text(item.createdAt) || text(previousById.get(item.id) && previousById.get(item.id).createdAt) || timestamp }))
    };
    validateRegistry(next);
    return next;
  }

  function removeFromRegistry(registry, current, timestamp = new Date().toISOString()) {
    const items = removeItem(current, registry.items);
    return withItems(registry, items, timestamp);
  }

  function lookupItems(registry) {
    validateRegistry(registry);
    return registry.items.map((item) => ({ ...item }));
  }

  window.StadslassJobTypeRegistry = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    SPECIAL_ROLES,
    USER_SELECTABLE_SPECIAL_ROLES,
    SYSTEM_CANONICAL_IDS,
    isSystemDefinition,
    normalizeProtectedRoleDuplicates,
    emptyRegistry,
    validateItem,
    validateRegistry,
    createItem,
    updateItem,
    removeItem,
    removeFromRegistry,
    migrateRegistry,
    migrateAndMergeRegistry,
    withItems,
    lookupItems,
    resolveReference
  });
})();
