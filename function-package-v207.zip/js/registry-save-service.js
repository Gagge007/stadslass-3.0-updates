(() => {
  'use strict';
  // Narrow transaction coordinator for Jobbtyp/Snabbval/Materialkod editor saves only.
  const KEY = 'p196RegistryRecoveryV1', OWNER = 196;
  // P206 compatibility: Materialkoder were already persisted as persistent-user-data in P204.
  // Do not move existing rows between native categories without an explicit migration.
  const KEYS = Object.freeze({ editableJobTypeRegistryV1: 'registries', quickChoiceRegistryV1: 'registries', materialCodeRegistryV1: 'persistent-user-data', ataNotificationSettingsV1: 'persistent-user-data' });
  const REGISTRY_DOMAINS = Object.freeze(new Set(['editableJobTypeRegistryV1','quickChoiceRegistryV1','materialCodeRegistryV1']));
  const copy = value => JSON.parse(JSON.stringify(value));
  const canonical = value => window.StadslassDataTransactions.canonical(value);
  const host = () => window.StadslassHost;
  let busy = false, unresolved = false;
  function result(raw) { const value = JSON.parse(raw || '{}'); if (value.ok !== true) throw new Error(value.message || value.code || 'Registerlagringen svarade inte.'); return value; }
  function native(operation, body) { return result(host().requestNativeStorage(JSON.stringify({nativeStorageApiVersion:1,storageSchemaVersion:1,operation,...body}))); }
  function stage(operation, body) { return result(host().requestStaging(JSON.stringify({stagingApiVersion:1,operation,...body}))); }
  function settings() { const raw=host().readStore('settings'); if (!raw) throw new Error('Återhämtningsstatus kunde inte läsas.'); return JSON.parse(raw); }
  function marker() { return settings()[KEY] || null; }
  function setMarker(value) { const doc=settings(); if(value)doc[KEY]=value;else delete doc[KEY]; host().writeStore('settings',JSON.stringify(doc)); const actual=marker();if(canonical(actual)!==canonical(value))throw new Error('Registeråterhämtningen kunde inte verifieras.'); }
  const hash = async text => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),b=>b.toString(16).padStart(2,'0')).join('');
  function row(key) { const r=native('GET',{category:KEYS[key],recordId:'setting:'+key});return r.found?r.payload:null; }
  function matches(a,b) { return canonical(a)===canonical(b); }
  function pendingError(error) { const e=new Error('Registersparningen väntar på säker återhämtning. Starta om appen. '+(error.message||''));e.registryPending=true;return e; }
  function validate(plan) {
    if(!plan||plan.owner!==OWNER||!Array.isArray(plan.rows)||!plan.rows.length||plan.rows.length>4)throw new Error('Ogiltigt registerunderlag.');
    const ids=new Set();for(const op of plan.rows){if(!Object.hasOwn(KEYS,op.key)||ids.has(op.key)||!op.after||op.after.settingKey!==op.key||!Object.hasOwn(op.after,'value')||(op.before!==null&&(!op.before||op.before.settingKey!==op.key)))throw new Error('Otillåtet registerunderlag.');ids.add(op.key);}
    if(!plan.rows.some(r=>REGISTRY_DOMAINS.has(r.key)))throw new Error('Registeroperation saknas.');
  }
  function check(plan) { for(const op of plan.rows){const actual=row(op.key);if(!matches(actual,op.before)&&!matches(actual,op.after))throw new Error('Registret har ändrats utanför den väntande sparningen.');} }
  function execute(plan) {
    validate(plan);check(plan);
    for(const category of ['persistent-user-data','registries']){
      check(plan);
      const records=plan.rows.filter(op=>KEYS[op.key]===category&&!matches(row(op.key),op.after)).map(op=>({id:'setting:'+op.key,payload:op.after}));
      if(records.length)native('BATCH_PUT',{category,records});
    }
    for(const op of plan.rows)if(!matches(row(op.key),op.after))throw new Error('Registrets efterläge kunde inte verifieras.');
    setMarker(null);
    // Cleanup is not part of the business result: no marker references the copy.
    try{stage('DELETE_TRANSFER',{transferId:plan.id});}catch(_){/* orphan only */}
    return true;
  }
  async function load() {
    const m=marker();if(!m)return null;
    if(m.owner!==OWNER||typeof m.id!=='string'||!m.id.startsWith('p196-reg-')||!/^[a-f0-9]{64}$/.test(m.sha256))throw new Error('Fel ägare för registeråterhämtning.');
    const part=stage('READ_PART',{transferId:m.id,partId:'intent'});
    if(part.sha256!==m.sha256||await hash(part.contentUtf8)!==m.sha256)throw new Error('Registeråterhämtningen är skadad.');
    const plan=JSON.parse(part.contentUtf8);validate(plan);if(plan.id!==m.id)throw new Error('Fel identitet för registeråterhämtning.');return plan;
  }
  async function recover() {
    if(busy)throw new Error('Registersparning pågår.');busy=true;
    try{const plan=await load();if(plan)execute(plan);unresolved=false;return true;}catch(error){unresolved=true;throw pendingError(error);}finally{busy=false;}
  }
  async function save(beforeDocument, changes) {
    if(busy||unresolved||marker())throw pendingError(new Error('En tidigare registersparning behöver slutföras.'));
    if(!window.StadslassNativeStorage.isActive()||settings().p194RestoreV1)throw new Error('Lagringsåterhämtning pågår. Registret har inte ändrats.');
    busy=true;let intentPublished=false, executionStarted=false;
    try{
      const rows=Object.keys(changes).map(key=>{
        if(!Object.hasOwn(KEYS,key))throw new Error('Otillåten registerinställning.');
        const before=Object.hasOwn(beforeDocument,key)?{settingKey:key,value:copy(beforeDocument[key])}:null;
        const after={settingKey:key,value:copy(changes[key])};
        if(!matches(row(key),before))throw new Error('Registret har ändrats. Läs om före nytt försök.');
        return {key,before,after};
      });
      const plan={owner:OWNER,id:'p196-reg-'+crypto.randomUUID(),rows};validate(plan);
      const contentUtf8=JSON.stringify(plan),sha256=await hash(contentUtf8);
      stage('CREATE',{transferId:plan.id});stage('PUT_PART',{transferId:plan.id,partId:'intent',contentUtf8,expectedBytes:new TextEncoder().encode(contentUtf8).length,expectedSha256:sha256});
      const part=stage('READ_PART',{transferId:plan.id,partId:'intent'});if(part.contentUtf8!==contentUtf8||part.sha256!==sha256)throw new Error('Registerunderlaget kunde inte verifieras.');
      // A lost marker-write response is treated as pending if readback finds it.
      intentPublished=true;setMarker({owner:OWNER,id:plan.id,sha256});
      executionStarted=true;execute(plan);return true;
    }catch(error){
      if(executionStarted){unresolved=true;throw pendingError(error);}
      if(intentPublished){try{if(marker()){unresolved=true;throw pendingError(error);}}catch(readError){unresolved=true;throw readError.registryPending?readError:pendingError(error);}}
      throw error;
    }finally{busy=false;}
  }
  window.StadslassRegistrySave=Object.freeze({KEY,save,recover,isBusy:()=>busy,hasPending:()=>unresolved||Boolean(marker()),assertIdle:()=>{if(busy||unresolved||marker())throw pendingError(new Error('Inställningar är spärrade tills registersparningen är verifierad.'));}});
})();
