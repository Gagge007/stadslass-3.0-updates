(() => {
  'use strict';

  // Shared policy for package 59. It deliberately owns no storage: Jobbtyp,
  // Snabbval, the existing ÄTA address book and job.ata remain the sources.
  const SCHEMA_VERSION = 1;
  const PACKAGE_VERSION = 191;
  const MANUAL_CANONICAL_ID = 'JT-1014';
  const OTHER_ACTIVITY_CANONICAL_ID = 'JT-1001';
  const RECIPIENT_SOURCES = Object.freeze(['job-type', 'quick-choice', 'manual-job-choice', 'queue-edit', 'syncimport', 'legacy-migrated']);

  const object = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const emailKey = (value) => text(value).toLocaleLowerCase('en-US');
  const validEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(value));
  const own = (value, key) => object(value) && Object.prototype.hasOwnProperty.call(value, key);

  function canonicalId(jobType) {
    return text(jobType && jobType.canonicalTypeId, text(jobType && jobType.id));
  }

  function isManualJobType(jobType) {
    return canonicalId(jobType) === MANUAL_CANONICAL_ID;
  }

  function isOtherActivity(jobType) {
    return canonicalId(jobType) === OTHER_ACTIVITY_CANONICAL_ID || text(jobType && jobType.specialRole) === 'other-activity';
  }

  function normalizeRecipient(raw, fallbackSource = 'manual-job-choice', timestamp = '') {
    const source = object(raw) ? raw : {};
    const email = text(source.email);
    const sourceName = RECIPIENT_SOURCES.includes(text(source.source)) ? text(source.source) : fallbackSource;
    const recipient = {
      schemaVersion: SCHEMA_VERSION,
      contactId: text(source.contactId, text(source.id)) || null,
      name: text(source.name),
      email,
      emailKey: emailKey(email),
      source: sourceName,
      snapshotAt: text(source.snapshotAt, timestamp),
      ...(text(source.editedAt) ? { editedAt: text(source.editedAt) } : {})
    };
    if (!email && !recipient.name) return null;
    if (!email || !recipient.name || !validEmail(email)) return { ...recipient, invalid: true };
    return recipient;
  }

  function assertRecipient(raw, fallbackSource, timestamp) {
    const recipient = normalizeRecipient(raw, fallbackSource, timestamp);
    if (!recipient) return null;
    if (recipient.invalid) {
      if (recipient.name && !recipient.email) throw new Error('Skriv en mailadress eller rensa mottagaren.');
      if (recipient.email && !recipient.name) throw new Error('Skriv mottagarens namn eller rensa mottagaren.');
      throw new Error('Skriv en giltig mailadress eller rensa mottagaren.');
    }
    return recipient;
  }

  function canonicalContact(contacts, email) {
    const key = emailKey(email);
    return (Array.isArray(contacts) ? contacts : [])
      .filter((contact) => contact && validEmail(contact.email) && emailKey(contact.email) === key)
      .sort((a, b) => {
        const at = new Date(text(a.createdAt)).getTime();
        const bt = new Date(text(b.createdAt)).getTime();
        return (Number.isFinite(at) ? at : Number.MAX_SAFE_INTEGER) - (Number.isFinite(bt) ? bt : Number.MAX_SAFE_INTEGER)
          || text(a.id).localeCompare(text(b.id), 'sv-SE');
      })[0] || null;
  }

  function recipientFromContact(contact, source, timestamp) {
    return contact ? normalizeRecipient({ contactId: contact.id, name: contact.name, email: contact.email, source, snapshotAt: timestamp }, source, timestamp) : null;
  }

  function recipientForSave(input, contacts, source, timestamp) {
    const recipient = assertRecipient(input, source, timestamp);
    if (!recipient) return { recipient: null, contact: null };
    const existing = canonicalContact(contacts, recipient.email);
    if (existing) return { recipient: { ...recipient, contactId: existing.id }, contact: null };
    return { recipient, contact: { name: recipient.name, email: recipient.email } };
  }

  function defaultRecipient(jobType) {
    return normalizeRecipient(jobType && jobType.ataRecipient, 'job-type');
  }

  function jobTypeEnabled(jobType) {
    return !isManualJobType(jobType) && !isOtherActivity(jobType) && jobType && jobType.ataEnabled === true;
  }

  function choiceMode(jobType, quickChoice) {
    if (quickChoice && quickChoice.ataNeedsCorrection === true) return quickChoice.ataLegacyDefault === true;
    if (isManualJobType(jobType)) return quickChoice && quickChoice.ataManual === true;
    return jobTypeEnabled(jobType);
  }

  function recipientPriority(jobType, quickChoice, source, timestamp) {
    const ownRecipient = normalizeRecipient(quickChoice && quickChoice.ataRecipient, 'quick-choice', timestamp);
    return ownRecipient && !ownRecipient.invalid ? ownRecipient : defaultRecipient(jobType);
  }

  function jobAtaSnapshot({ enabled, source, quickChoiceId = null, recipient = null, timestamp = new Date().toISOString(), existing = null }) {
    const previous = object(existing) ? existing : {};
    const normalizedRecipient = enabled ? normalizeRecipient(recipient, source, timestamp) : null;
    return {
      ...previous,
      schemaVersion: 2,
      enabled: enabled === true,
      source: text(source, 'manual-job-choice'),
      quickChoiceId: text(quickChoiceId) || null,
      updatedAt: timestamp,
      ...(normalizedRecipient && !normalizedRecipient.invalid ? { recipient: normalizedRecipient } : {})
    };
  }

  function formState(jobType, currentAta, fallbackRecipient) {
    const manual = isManualJobType(jobType);
    const fixedEnabled = jobTypeEnabled(jobType);
    const enabled = manual ? currentAta === true : fixedEnabled;
    return { showToggle: manual || fixedEnabled, toggleLocked: fixedEnabled, enabled, recipient: enabled ? (fallbackRecipient || defaultRecipient(jobType)) : null };
  }

  function propagateRecipient(records, updatedContact, predicate) {
    return (Array.isArray(records) ? records : []).map((record) => {
      if (!object(record) || !object(record.ata) || !object(record.ata.recipient) || (predicate && !predicate(record))) return record;
      const recipient = record.ata.recipient;
      const matches = text(recipient.contactId) === text(updatedContact.id)
        || (emailKey(recipient.email) && emailKey(recipient.email) === emailKey(updatedContact.previousEmail || updatedContact.email));
      return matches ? { ...record, ata: { ...record.ata, recipient: { ...recipient, contactId: updatedContact.id, name: updatedContact.name, email: updatedContact.email, emailKey: emailKey(updatedContact.email), source: recipient.source, snapshotAt: recipient.snapshotAt } } } : record;
    });
  }

  window.StadslassAtaRouting = Object.freeze({
    SCHEMA_VERSION, PACKAGE_VERSION, MANUAL_CANONICAL_ID, OTHER_ACTIVITY_CANONICAL_ID,
    text, emailKey, validEmail, canonicalId, isManualJobType, isOtherActivity,
    normalizeRecipient, assertRecipient, canonicalContact, recipientFromContact,
    recipientForSave, defaultRecipient, jobTypeEnabled, choiceMode, recipientPriority,
    jobAtaSnapshot, formState, propagateRecipient
  });
})();
