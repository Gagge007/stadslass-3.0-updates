(() => {
  'use strict';

  const PACKAGE_VERSION = 80;
  const PROTOCOL = 'stadslass3.handshake.v1';
  // Tillfälligt felsökningsbeslut: behåll 60 sekunder tills separat beslut tas.
  const INTERVAL_MS = 60 * 1000;
  const PRESENCE_TIMEOUT_MS = 10 * 60 * 1000;
  const FUTURE_SKEW_MS = 2 * 60 * 1000;
  const MAX_DIAGNOSTICS = 80;
  const MAX_PENDING = 12;
  const TERMINAL_SUCCESS = new Set(['succeeded', 'success', 'completed']);
  const TERMINAL_FAILURE = new Set(['failed', 'error', 'cancelled', 'canceled', 'superseded']);
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const now = () => new Date().toISOString();
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const parse = (value, fallback = null) => { try { return JSON.parse(value); } catch (_) { return fallback; } };
  const validPath = (value) => /^[A-Za-z0-9._/-]{1,512}$/.test(text(value)) && !text(value).includes('..') && !text(value).includes('//');
  const validIdentity = (value) => /^[A-Za-z0-9._:-]{8,160}$/.test(text(value));
  const resultObject = (value) => isObject(value) ? value : parse(value, {});
  const terminal = (status) => TERMINAL_SUCCESS.has(text(status)) || TERMINAL_FAILURE.has(text(status));

  function paths(syncRoot) {
    const root = text(syncRoot, 'stadslass-3-sync');
    if (!validPath(root) || root.includes('/')) throw new Error('HANDSHAKE_TRANSPORT_UNAVAILABLE');
    // Filnamnet computer.json behålls för kompatibilitet med redan publicerad handshake-v1.
    return Object.freeze({ vehicle: `${root}/handshake/vehicle-189.json`, planning: `${root}/handshake/computer.json`, computer: `${root}/handshake/computer.json` });
  }

  function emptyState() {
    return {
      schemaVersion: 1, packageVersion: PACKAGE_VERSION, enabled: true, statusCode: 'HANDSHAKE_NO_PEER_PRESENT',
      state: 'no_peer_present', lastSuccessAt: '', lastCheckAt: '', lastErrorAt: '', lastErrorCode: '', lastErrorDetail: '',
      latestSequence: 0, latestReplyToSequence: 0, latestVehicleSequence: 0, lastRequestAt: '', lastRequestSeenAt: '',
      lastVehicleRequestAt: '', lastVehicleHasActiveJob: null, lastResponseAt: '', lastValidReplyAt: '',
      peerInstallationId: '', lastPlanningResponseSequence: 0, lastStaleAt: '', lastStaleCode: '',
      lastLocalRequestId: '', lastHostRequestId: '', pendingRequests: [], diagnostics: []
    };
  }

  function normalizePending(raw) {
    if (!Array.isArray(raw)) return [];
    return raw.filter(isObject).map((item) => ({
      hostRequestId: text(item.hostRequestId || item.requestId),
      localRequestId: text(item.localRequestId || item.requestId),
      intent: text(item.intent), operation: text(item.operation), path: text(item.path), at: text(item.at),
      sequence: Math.max(0, Number(item.sequence) || 0)
    })).filter((item) => item.hostRequestId && item.intent && item.operation && item.path).slice(-MAX_PENDING);
  }

  function normalizeState(raw) {
    const base = emptyState();
    const value = isObject(raw) ? raw : {};
    return {
      ...base, ...value, enabled: true, packageVersion: PACKAGE_VERSION,
      latestSequence: Math.max(0, Number(value.latestSequence) || 0),
      latestReplyToSequence: Math.max(0, Number(value.latestReplyToSequence) || 0),
      latestVehicleSequence: Math.max(0, Number(value.latestVehicleSequence) || 0),
      lastPlanningResponseSequence: Math.max(0, Number(value.lastPlanningResponseSequence || value.lastComputerResponseSequence) || 0),
      lastVehicleHasActiveJob: null,
      pendingRequests: normalizePending(value.pendingRequests),
      diagnostics: Array.isArray(value.diagnostics) ? value.diagnostics.slice(-MAX_DIAGNOSTICS) : []
    };
  }

  function timestampMs(value) {
    const ms = Date.parse(text(value));
    if (!Number.isFinite(ms)) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (ms > Date.now() + FUTURE_SKEW_MS) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    return ms;
  }

  function assertFresh(value) {
    const ms = timestampMs(value);
    if (Date.now() - ms > PRESENCE_TIMEOUT_MS) throw new Error('HANDSHAKE_STALE_PAYLOAD');
    return ms;
  }

  function validateVehicleRequest(value) {
    if (!isObject(value) || Number(value.schemaVersion) !== 1) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (text(value.protocol) !== PROTOCOL) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    if (text(value.vehicleId) !== '189' || text(value.senderRole) !== 'vehicle_189' || !validIdentity(value.senderInstallationId)
      || !Number.isInteger(Number(value.sequence)) || Number(value.sequence) < 1 || !text(value.sentAt)) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (Number(value.packageVersion) < 74) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    assertFresh(value.sentAt);
    return {
      schemaVersion: 1, protocol: PROTOCOL, vehicleId: '189', senderRole: 'vehicle_189', senderInstallationId: text(value.senderInstallationId),
      sequence: Number(value.sequence), sentAt: text(value.sentAt), packageVersion: Number(value.packageVersion)
    };
  }

  function validatePlanningResponse(value) {
    if (!isObject(value) || Number(value.schemaVersion) !== 1) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (text(value.protocol) !== PROTOCOL) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    const responderRole = text(value.responderRole);
    if (text(value.vehicleId) !== '189' || !['planning_unit', 'computer'].includes(responderRole) || !validIdentity(value.responderInstallationId)
      || !Number.isInteger(Number(value.replyToSequence)) || Number(value.replyToSequence) < 1
      || !text(value.requestSeenAt) || !text(value.respondedAt)) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (Number(value.packageVersion) < 74) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    assertFresh(value.requestSeenAt);
    assertFresh(value.respondedAt);
    return {
      schemaVersion: 1, protocol: PROTOCOL, vehicleId: '189', responderRole,
      responderInstallationId: text(value.responderInstallationId), replyToSequence: Number(value.replyToSequence),
      requestSeenAt: text(value.requestSeenAt), respondedAt: text(value.respondedAt), packageVersion: Number(value.packageVersion)
    };
  }

  function stateWith(state, patch, diagnostic) {
    const next = { ...state, ...patch, lastCheckAt: now() };
    if (diagnostic) next.diagnostics = [...state.diagnostics, { at: now(), packageVersion: PACKAGE_VERSION, component: 'Närvaro och handskakning', ...diagnostic }].slice(-MAX_DIAGNOSTICS);
    return next;
  }

  function create(environment) {
    if (!isObject(environment) || typeof environment.host !== 'function' || typeof environment.getConfig !== 'function'
      || typeof environment.getIdentity !== 'function' || typeof environment.loadState !== 'function' || typeof environment.saveState !== 'function') {
      throw new Error('Handskakningstjänsten saknar säker miljöadapter.');
    }
    let state = normalizeState(environment.loadState());
    const pending = new Map();
    state.pendingRequests.forEach((item) => pending.set(item.hostRequestId, { ...item }));

    function persist(next) { state = normalizeState(next); environment.saveState(clone(state)); return state; }
    function syncPendingState(extraPatch = {}) {
      return persist({ ...state, ...extraPatch, pendingRequests: [...pending.values()].slice(-MAX_PENDING) });
    }
    function record(patch, diagnostic) { return persist(stateWith(state, patch, diagnostic)); }
    function configuration() {
      const value = environment.getConfig() || {};
      return {
        configured: value.configured === true, syncRoot: text(value.syncRoot, 'stadslass-3-sync'),
        explicitlyDisabled: value.explicitlyDisabled === true, hostAvailable: value.hostAvailable === true,
        configurationStatus: text(value.configurationStatus), configurationErrorCode: text(value.configurationErrorCode)
      };
    }
    function identity() {
      const value = environment.getIdentity() || {};
      return { installationId: text(value.installationId), role: text(value.role) };
    }
    function actualRequestId(accepted, fallback) {
      return text(accepted.requestId || accepted.existingRequestId || accepted.pendingRequestId || accepted.duplicateRequestId, fallback);
    }
    function enqueue(intent, operation, path, body = '', meta = {}) {
      const host = environment.host();
      if (!host || typeof host.enqueueSyncRequest !== 'function') throw new Error('HANDSHAKE_TRANSPORT_UNAVAILABLE');
      const localRequestId = `handshake-${intent}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      const seq = Math.max(0, Number(meta.sequence) || 0);
      const coalesceKey = seq > 0 && operation === 'PUT' ? `handshake/${intent}/${seq}` : `handshake/${intent}`;
      const request = { requestId: localRequestId, operation, path, priority: 'fast_lane', channel: `v${PACKAGE_VERSION}/handshake/${intent}`, createdAt: now(), body, expectedSha: '', coalesceKey };
      const accepted = resultObject(host.enqueueSyncRequest(JSON.stringify(request)));
      if (accepted.ok !== true && !['accepted', 'duplicate', 'duplicate_pending'].includes(text(accepted.status))) {
        const error = new Error(text(accepted.errorCode, 'HANDSHAKE_TRANSPORT_UNAVAILABLE')); error.detail = text(accepted.error || accepted.message); throw error;
      }
      const hostRequestId = actualRequestId(accepted, localRequestId);
      pending.set(hostRequestId, { hostRequestId, localRequestId, intent, operation, path, at: now(), sequence: seq });
      syncPendingState({ lastLocalRequestId: localRequestId, lastHostRequestId: hostRequestId });
      if (hostRequestId !== localRequestId) {
        record({}, { state: 'pending', statusCode: 'HANDSHAKE_REQUEST_ID_REUSED', operation: intent, localRequestId, hostRequestId, detail: 'Hostens befintliga request-ID följs efter duplicate/duplicate_pending.' });
      }
      return hostRequestId;
    }
    function failFor(intent, error) {
      const base = text(error && error.message, 'HANDSHAKE_TRANSPORT_UNAVAILABLE');
      const code = base.startsWith('HANDSHAKE_') || base.startsWith('GITHUB_') || base.startsWith('HOST_') ? base
        : intent.includes('request-write') ? 'HANDSHAKE_REQUEST_WRITE_FAILED'
          : intent.includes('request-read') ? 'HANDSHAKE_REQUEST_READ_FAILED'
            : intent.includes('response-write') ? 'HANDSHAKE_RESPONSE_WRITE_FAILED' : 'HANDSHAKE_RESPONSE_READ_FAILED';
      return record({ state: 'error', statusCode: code, lastErrorCode: code, lastErrorAt: now(), lastErrorDetail: text(error && (error.detail || error.message), code) },
        { state: 'error', statusCode: code, operation: intent, direction: intent.includes('planning') ? 'planning_unit' : 'vehicle', detail: text(error && (error.detail || error.message), code) });
    }
    function staleFor(intent, detail) {
      return record({ state: 'no_peer_present', statusCode: 'HANDSHAKE_NO_PEER_PRESENT', lastStaleAt: now(), lastStaleCode: 'HANDSHAKE_STALE_PAYLOAD', lastErrorCode: '', lastErrorDetail: '' },
        { state: 'stale', statusCode: 'HANDSHAKE_STALE_PAYLOAD', operation: intent, detail: text(detail, 'Gammal handskakning ignorerades.') });
    }
    function availabilityFailure(config, device) {
      if (config.explicitlyDisabled === true) return 'HANDSHAKE_EXPLICITLY_DISABLED';
      if (config.hostAvailable !== true) return 'HANDSHAKE_HOST_API_MISSING';
      if (config.configured !== true) return config.configurationErrorCode === 'credential_unavailable' ? 'HANDSHAKE_CREDENTIAL_MISSING' : 'HANDSHAKE_CONFIGURATION_MISSING';
      if (!validIdentity(device.installationId)) return 'HANDSHAKE_INSTALLATION_ID_MISSING';
      if (!['vehicle_189', 'planning_unit'].includes(device.role)) return 'HANDSHAKE_ROLE_UNSUPPORTED';
      return '';
    }
    function canRun() {
      const config = configuration(); const device = identity();
      const failureCode = availabilityFailure(config, device);
      if (failureCode) {
        if (failureCode === 'HANDSHAKE_EXPLICITLY_DISABLED') {
          record({ state: 'disabled', statusCode: failureCode, lastErrorCode: '', lastErrorDetail: '' },
            { state: 'disabled', statusCode: failureCode, operation: 'availability-check', role: device.role });
          return null;
        }
        const detail = failureCode === 'HANDSHAKE_CONFIGURATION_MISSING' || failureCode === 'HANDSHAKE_CREDENTIAL_MISSING'
          ? 'Säker synckonfiguration eller återanvändbar credential saknas på enheten.'
          : 'Handskakningen kunde inte starta med verifierad host, konfiguration, roll och enhetsidentitet.';
        record({ state: 'error', statusCode: failureCode, lastErrorCode: failureCode, lastErrorAt: now(), lastErrorDetail: detail },
          { state: 'error', statusCode: failureCode, operation: 'availability-check', role: device.role });
        return null;
      }
      return { config, device, paths: paths(config.syncRoot) };
    }
    function vehicleRequest() {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      const sequence = state.latestSequence + 1;
      const body = { schemaVersion: 1, protocol: PROTOCOL, vehicleId: '189', senderRole: 'vehicle_189', senderInstallationId: ready.device.installationId,
        sequence, sentAt: now(), packageVersion: PACKAGE_VERSION };
      try {
        const requestId = enqueue('vehicle-request-write', 'PUT', ready.paths.vehicle, JSON.stringify(body), { sequence });
        record({ latestSequence: sequence, lastRequestAt: body.sentAt, state: 'waiting_for_reply', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', lastErrorCode: '', lastErrorDetail: '' },
          { state: 'waiting', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', operation: 'vehicle-request-write', direction: '189→Planeringsenhet', sequence, requestId });
        return { ok: true, requestId, sequence };
      } catch (error) { failFor('vehicle-request-write', error); return { ok: false, status: state.statusCode }; }
    }
    function vehicleReadResponse() {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      try { return { ok: true, requestId: enqueue('vehicle-response-read', 'GET', ready.paths.planning) }; }
      catch (error) { failFor('vehicle-response-read', error); return { ok: false, status: state.statusCode }; }
    }
    function planningReadRequest() {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      try { return { ok: true, requestId: enqueue('planning-request-read', 'GET', ready.paths.vehicle) }; }
      catch (error) { failFor('planning-request-read', error); return { ok: false, status: state.statusCode }; }
    }
    function planningWriteResponse(request) {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      const sequence = Number(request.sequence);
      if (sequence === Number(state.lastPlanningResponseSequence)) return { ok: true, duplicate: true };
      for (const item of pending.values()) if (item.intent === 'planning-response-write' && Number(item.sequence) === sequence) return { ok: true, duplicate: true, pending: true, requestId: item.hostRequestId };
      const body = { schemaVersion: 1, protocol: PROTOCOL, vehicleId: '189', responderRole: 'planning_unit', responderInstallationId: ready.device.installationId,
        replyToSequence: sequence, requestSeenAt: now(), respondedAt: now(), packageVersion: PACKAGE_VERSION };
      try {
        const requestId = enqueue('planning-response-write', 'PUT', ready.paths.planning, JSON.stringify(body), { sequence });
        record({ lastRequestSeenAt: body.requestSeenAt, lastResponseAt: body.respondedAt, peerInstallationId: request.senderInstallationId,
          state: 'waiting_for_write', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', lastErrorCode: '', lastErrorDetail: '' },
          { state: 'waiting', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', operation: 'planning-response-write', direction: 'Planeringsenhet→189', sequence, replyToSequence: sequence, requestId });
        return { ok: true, requestId };
      } catch (error) { failFor('planning-response-write', error); return { ok: false, status: state.statusCode }; }
    }
    function normalNoPeer() {
      const requestAge = state.lastRequestAt ? Date.now() - Date.parse(state.lastRequestAt) : Infinity;
      const code = state.latestSequence > state.latestReplyToSequence && requestAge < PRESENCE_TIMEOUT_MS ? 'HANDSHAKE_WAITING_FOR_REPLY' : 'HANDSHAKE_NO_PEER_PRESENT';
      return record({ state: code === 'HANDSHAKE_WAITING_FOR_REPLY' ? 'waiting_for_reply' : 'no_peer_present', statusCode: code, lastErrorCode: '', lastErrorDetail: '' },
        { state: 'no_peer', statusCode: code, operation: 'presence-check', sequence: state.latestSequence, replyToSequence: state.latestReplyToSequence });
    }
    function findPending(requestId) {
      const key = text(requestId);
      if (pending.has(key)) return [key, pending.get(key)];
      for (const [hostId, item] of pending.entries()) if (item.localRequestId === key) return [hostId, item];
      return ['', null];
    }
    function processResult(requestId, options = {}) {
      const [hostRequestId, pendingItem] = findPending(requestId);
      if (!pendingItem) return false;
      const host = environment.host(); let result = {};
      try { result = resultObject(host && typeof host.getSyncRequestStatus === 'function' ? host.getSyncRequestStatus(hostRequestId) : {}); }
      catch (error) { failFor(pendingItem.intent, error); return true; }
      const status = text(result.status);
      const body = text(result.body);
      if (!terminal(status)) {
        if (options.recovery === true) record({}, { state: 'pending', statusCode: 'HANDSHAKE_PENDING_RECOVERED', operation: pendingItem.intent, requestId: hostRequestId, detail: `Request kvar i hoststatus ${status || 'unknown'}.` });
        return true;
      }
      pending.delete(hostRequestId); syncPendingState();
      if (!TERMINAL_SUCCESS.has(status)) {
        if ((Number(result.httpStatus) === 404 || !body) && pendingItem.operation === 'GET') {
          normalNoPeer();
          if (pendingItem.intent === 'vehicle-response-read') vehicleRequest();
          return true;
        }
        const error = new Error(text(result.errorCode, 'HANDSHAKE_TRANSPORT_UNAVAILABLE'));
        error.detail = text(result.error || result.message || `HTTP ${Number(result.httpStatus) || 0}`);
        failFor(pendingItem.intent, error); return true;
      }
      try {
        if (pendingItem.intent === 'planning-request-read') {
          if (!body) { normalNoPeer(); return true; }
          let request;
          try { request = validateVehicleRequest(parse(body, null)); }
          catch (error) { if (text(error.message) === 'HANDSHAKE_STALE_PAYLOAD') { staleFor(pendingItem.intent); return true; } throw error; }
          record({ latestVehicleSequence: request.sequence, lastRequestSeenAt: now(), lastVehicleRequestAt: request.sentAt,
            lastVehicleHasActiveJob: null, peerInstallationId: request.senderInstallationId, lastStaleCode: '' },
            { state: 'received', statusCode: 'HANDSHAKE_OK', operation: 'planning-request-read', direction: '189→Planeringsenhet', sequence: request.sequence });
          planningWriteResponse(request); return true;
        }
        if (pendingItem.intent === 'vehicle-response-read') {
          if (!body) { normalNoPeer(); vehicleRequest(); return true; }
          let response;
          try { response = validatePlanningResponse(parse(body, null)); }
          catch (error) { if (text(error.message) === 'HANDSHAKE_STALE_PAYLOAD') { staleFor(pendingItem.intent); vehicleRequest(); return true; } throw error; }
          if (response.replyToSequence < state.latestSequence) {
            record({ statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', state: 'waiting_for_reply' },
              { state: 'stale_sequence', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', operation: 'vehicle-response-read', replyToSequence: response.replyToSequence, sequence: state.latestSequence, detail: 'Svar på äldre sequence ignorerades.' });
            return true;
          }
          if (response.replyToSequence > state.latestSequence) throw new Error('HANDSHAKE_WRONG_SEQUENCE');
          record({ latestReplyToSequence: response.replyToSequence, lastValidReplyAt: now(), lastResponseAt: response.respondedAt, peerInstallationId: response.responderInstallationId,
            state: 'ok', statusCode: 'HANDSHAKE_OK', lastSuccessAt: now(), lastErrorCode: '', lastErrorDetail: '', lastStaleCode: '' },
            { state: 'ok', statusCode: 'HANDSHAKE_OK', operation: 'vehicle-response-read', direction: 'Planeringsenhet→189', sequence: state.latestSequence, replyToSequence: response.replyToSequence });
          vehicleRequest(); return true;
        }
        if (pendingItem.intent === 'planning-response-write') {
          record({ lastPlanningResponseSequence: pendingItem.sequence, state: 'ok', statusCode: 'HANDSHAKE_OK', lastSuccessAt: now(), lastErrorCode: '', lastErrorDetail: '' },
            { state: 'ok', statusCode: 'HANDSHAKE_OK', operation: 'planning-response-write', direction: 'Planeringsenhet→189', sequence: pendingItem.sequence, replyToSequence: pendingItem.sequence });
          return true;
        }
        if (pendingItem.intent === 'vehicle-request-write') return true;
        return true;
      } catch (error) { failFor(pendingItem.intent, error); return true; }
    }
    function recoverPending() {
      let count = 0;
      for (const requestId of [...pending.keys()].slice(0, 4)) {
        processResult(requestId, { recovery: true }); count += 1;
      }
      return count;
    }
    function tick(reason = 'timer') {
      recoverPending();
      const device = identity();
      if (!['vehicle_189', 'planning_unit'].includes(device.role)) {
        canRun(); return { ok: false, status: state.statusCode, reason };
      }
      // Undvik att skapa samma typ av request medan hosten redan arbetar med den.
      const hasPending = (intent) => [...pending.values()].some((item) => item.intent === intent);
      if (device.role === 'vehicle_189') {
        if (state.latestSequence > 0) return hasPending('vehicle-response-read') ? { ok: true, pending: true } : vehicleReadResponse();
        return hasPending('vehicle-request-write') ? { ok: true, pending: true } : vehicleRequest();
      }
      if (device.role === 'planning_unit') return hasPending('planning-request-read') ? { ok: true, pending: true } : planningReadRequest();
      return { ok: false, status: state.statusCode, reason };
    }
    function status() { return clone(state); }
    return Object.freeze({ tick, handleResult: processResult, recoverPending, status, paths, validateVehicleRequest, validatePlanningResponse,
      validateComputerResponse: validatePlanningResponse, intervalMs: INTERVAL_MS, presenceTimeoutMs: PRESENCE_TIMEOUT_MS });
  }

  window.StadslassDriftsyncHandshake = Object.freeze({ PACKAGE_VERSION, PROTOCOL, INTERVAL_MS, PRESENCE_TIMEOUT_MS, paths, validateVehicleRequest,
    validatePlanningResponse, validateComputerResponse: validatePlanningResponse, normalizeState, create });
})();
