(() => {
  'use strict';

  const SCHEMA_VERSION = 1;
  const PACKAGE_VERSION = 60;
  const SETTINGS_KEY = 'ataNotificationSettingsV1';
  const TEMPLATE_FIELDS = Object.freeze([
    'jobType', 'fromPlace', 'toPlace', 'returnPlace', 'date', 'startedAt',
    'completedAt', 'billableTime', 'loadCount', 'totalWeight', 'note', 'truck189'
  ]);

  const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const validTimestamp = (value, fallback = '') => Number.isFinite(new Date(text(value)).getTime()) ? text(value) : fallback;
  const normalizeEmail = (value) => text(value).toLocaleLowerCase('en-US');
  const validEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(value));
  const defaultTemplate = () => ({ fields: Object.fromEntries(TEMPLATE_FIELDS.map((field) => [field, true])), closingText: '' });

  function createId(prefix = 'ata-contact') {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') window.crypto.getRandomValues(bytes);
    else for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(Math.random() * 256);
    return `${prefix}-${Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('')}`;
  }

  function normalizeContact(raw, fallbackTimestamp = '') {
    const source = isObject(raw) ? raw : {};
    const email = text(source.email);
    const createdAt = validTimestamp(source.createdAt, fallbackTimestamp);
    return {
      ...source,
      id: text(source.id) || createId(),
      name: text(source.name),
      email,
      emailKey: normalizeEmail(email),
      source: text(source.source) === 'sync' ? 'sync' : 'manual',
      createdAt,
      updatedAt: validTimestamp(source.updatedAt, createdAt)
    };
  }

  function normalizeTemplate(raw) {
    const source = isObject(raw) ? raw : {};
    const fields = isObject(source.fields) ? source.fields : {};
    return { ...source, fields: Object.fromEntries(TEMPLATE_FIELDS.map((field) => [field, fields[field] !== false])), closingText: typeof source.closingText === 'string' ? source.closingText : '' };
  }

  function normalizeSettings(raw) {
    const source = isObject(raw) ? raw : {};
    const supervisor = isObject(source.supervisor) ? source.supervisor : {};
    return {
      ...source,
      schemaVersion: SCHEMA_VERSION,
      supervisor: text(supervisor.name) && validEmail(supervisor.email) ? { ...supervisor, name: text(supervisor.name), email: text(supervisor.email), emailKey: normalizeEmail(supervisor.email) } : null,
      contacts: Array.isArray(source.contacts) ? source.contacts.map((contact) => normalizeContact(contact)) : [],
      template: normalizeTemplate(source.template)
    };
  }

  function settingsFromDocument(documentValue) {
    const document = isObject(documentValue) ? documentValue : {};
    return normalizeSettings(document[SETTINGS_KEY]);
  }

  function documentWithSettings(documentValue, settings) {
    return { ...(isObject(documentValue) ? documentValue : {}), [SETTINGS_KEY]: normalizeSettings(settings) };
  }

  function contactSort(a, b) {
    const name = a.name.localeCompare(b.name, 'sv-SE', { sensitivity: 'base' });
    return name || a.email.localeCompare(b.email, 'sv-SE', { sensitivity: 'base' }) || a.id.localeCompare(b.id, 'sv-SE');
  }

  function canonicalSort(a, b) {
    const aCreated = Number.isFinite(new Date(a.createdAt).getTime()) ? new Date(a.createdAt).getTime() : Number.MAX_SAFE_INTEGER;
    const bCreated = Number.isFinite(new Date(b.createdAt).getTime()) ? new Date(b.createdAt).getTime() : Number.MAX_SAFE_INTEGER;
    return aCreated - bCreated || a.id.localeCompare(b.id, 'sv-SE');
  }

  function contactsForDisplay(settings) { return normalizeSettings(settings).contacts.filter((contact) => contact.name && validEmail(contact.email)).sort(contactSort); }
  function matchesByEmail(settings, email, excludeId = '') { const key = normalizeEmail(email); return normalizeSettings(settings).contacts.filter((contact) => validEmail(contact.email) && contact.emailKey === key && contact.id !== excludeId).sort(contactSort); }
  function canonicalMatch(settings, email) { return matchesByEmail(settings, email).sort(canonicalSort)[0] || null; }

  function contactInput(input, existing = null, timestamp = new Date().toISOString()) {
    const name = text(input && input.name);
    const email = text(input && input.email);
    if (!name) throw new Error('Namn måste fyllas i.');
    if (!validEmail(email)) throw new Error('Skriv en giltig mailadress.');
    return normalizeContact({ ...(existing || {}), name, email, id: existing ? existing.id : createId(), source: existing ? existing.source : 'manual', createdAt: existing ? existing.createdAt : timestamp, updatedAt: timestamp });
  }

  function saveContact(settings, input, timestamp = new Date().toISOString()) {
    const current = normalizeSettings(settings);
    const editId = text(input && input.id);
    const existing = editId ? current.contacts.find((contact) => contact.id === editId) : null;
    if (editId && !existing) throw new Error('Mottagaren som skulle ändras saknas.');
    const contact = contactInput(input, existing, timestamp);
    const duplicates = matchesByEmail(current, contact.email, contact.id);
    return { settings: current, contact, duplicates, requiresConfirmation: duplicates.length > 0, isEdit: Boolean(existing) };
  }

  function commitContact(settings, contact) {
    const current = normalizeSettings(settings);
    const index = current.contacts.findIndex((item) => item.id === contact.id);
    const contacts = current.contacts.slice();
    if (index >= 0) contacts[index] = contact; else contacts.push(contact);
    return { ...current, contacts };
  }


  function removeContact(settings, id) {
    const current = normalizeSettings(settings);
    const contact = current.contacts.find((item) => item.id === text(id));
    if (!contact) throw new Error('Mottagaren saknas.');
    return { settings: { ...current, contacts: current.contacts.filter((item) => item.id !== contact.id) }, removed: contact };
  }

  function updateSupervisor(settings, input, timestamp = new Date().toISOString()) {
    const name = text(input && input.name); const email = text(input && input.email);
    if (!name) throw new Error('Namn måste fyllas i.');
    if (!validEmail(email)) throw new Error('Skriv en giltig mailadress.');
    return { ...normalizeSettings(settings), supervisor: { name, email, emailKey: normalizeEmail(email), updatedAt: timestamp } };
  }

  function updateTemplate(settings, input) {
    const current = normalizeSettings(settings);
    const fields = isObject(input && input.fields) ? input.fields : {};
    return { ...current, template: { ...current.template, fields: Object.fromEntries(TEMPLATE_FIELDS.map((field) => [field, fields[field] !== false])), closingText: typeof (input && input.closingText) === 'string' ? input.closingText : '' } };
  }

  function applyIncoming(settings, incoming, timestamp = new Date().toISOString()) {
    const current = normalizeSettings(settings); const email = text(incoming && incoming.email);
    if (!validEmail(email)) throw new Error('Inkommande beställare saknar giltig mailadress.');
    const existing = canonicalMatch(current, email);
    if (existing) return { settings: current, contactId: existing.id, created: false };
    const contact = contactInput({ name: text(incoming && incoming.name) || email, email }, null, timestamp);
    contact.source = 'sync';
    return { settings: commitContact(current, contact), contactId: contact.id, created: true };
  }

  window.StadslassAtaNotificationSettings = Object.freeze({ SCHEMA_VERSION, PACKAGE_VERSION, SETTINGS_KEY, TEMPLATE_FIELDS, defaultTemplate, normalizeEmail, validEmail, normalizeSettings, settingsFromDocument, documentWithSettings, contactsForDisplay, matchesByEmail, canonicalMatch, saveContact, commitContact, removeContact, updateSupervisor, updateTemplate, applyIncoming });
})();
