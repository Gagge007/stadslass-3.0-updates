#!/usr/bin/env python3
import asyncio
import json
from integration_app import async_playwright, new_page, app_click, wait_eval

async def run():
    if async_playwright is None:
        print(json.dumps({'status':'EJ_KORBAR_I_INTERN_MILJO','reason':'Playwright saknas'}, ensure_ascii=False))
        return
    from playwright.async_api import async_playwright as ap
    async with ap() as p:
        browser = await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
        context, page, errors = await new_page(browser, {})
        await app_click(page.locator('button[data-target="settings"]'))
        await app_click(page.get_by_role('button', name='Vanliga åtgärder'))
        await app_click(page.get_by_role('button', name='ÄTA avisering'))
        await page.locator('#ata-notification-settings-card').wait_for(state='visible')

        # Email fields share the full-width 3.0 layout.
        for selector in ['#ata-notification-supervisor-email', '#ata-notification-contact-email']:
            metrics = await page.locator(selector).evaluate("e => ({width:e.getBoundingClientRect().width, parent:e.parentElement.getBoundingClientRect().width, box:getComputedStyle(e).boxSizing, height:e.getBoundingClientRect().height})")
            assert metrics['box'] == 'border-box', metrics
            assert metrics['width'] <= metrics['parent'] + 0.5 and metrics['width'] > metrics['parent'] * 0.9, metrics
            assert metrics['height'] >= 52, metrics

        # Contact UI has no active/inactive controls.
        contact_list = page.locator('#ata-notification-contact-list')
        assert await contact_list.get_by_role('button', name='Inaktivera').count() == 0
        assert await contact_list.get_by_role('button', name='Aktivera').count() == 0

        # Add first contact.
        await page.locator('#ata-notification-contact-name').fill('Första')
        await page.locator('#ata-notification-contact-email').fill('Andreas.Skyttman@gmail.com')
        await app_click(page.locator('#ata-notification-contact-submit'))
        await wait_eval(page, "() => window.__hostState.stores.settings.ataNotificationSettingsV1.contacts.length === 1")

        # Duplicate warning is adjacent to the contact form and no write occurs first.
        await page.locator('#ata-notification-contact-name').fill('Dubblett')
        await page.locator('#ata-notification-contact-email').fill(' andreas.skyttman@GMAIL.COM ')
        writes_before = await page.evaluate("window.__hostState.writes.length")
        await app_click(page.locator('#ata-notification-contact-submit'))
        await page.locator('#ata-notification-confirm').wait_for(state='visible')
        assert await page.locator('#ata-notification-contact-status + #ata-notification-confirm').count() == 1
        assert 'Första' in await page.locator('#ata-notification-confirm-text').inner_text()
        assert await page.evaluate("window.__hostState.writes.length") == writes_before
        await app_click(page.locator('#ata-notification-confirm-cancel'))
        assert await page.evaluate("window.__hostState.stores.settings.ataNotificationSettingsV1.contacts.length") == 1

        # Confirm duplicate exactly once.
        await app_click(page.locator('#ata-notification-contact-submit'))
        await app_click(page.get_by_role('button', name='Spara ändå'))
        await wait_eval(page, "() => window.__hostState.stores.settings.ataNotificationSettingsV1.contacts.length === 2")
        assert errors == [], errors
        await context.close(); await browser.close()
    print(json.dumps({'status':'PASS','tests':['email-layout','duplicate-warning-adjacent','save-anyway-once']}, ensure_ascii=False))

if __name__ == '__main__':
    asyncio.run(run())
