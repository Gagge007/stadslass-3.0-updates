(() => {
  'use strict';
  const PACKAGE_VERSION = 98;
  const MAX_EVENTS = 300;
  const now = () => new Date().toISOString();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value);
  const clean = (value, key = '') => {
    if (/token|authorization|password|secret|private|signature|credential/i.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => clean(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, clean(item, name)]));
    if (typeof value === 'string') return value.length > 500 ? `${value.slice(0, 500)}…` : value;
    return value;
  };
  function create(options = {}) {
    const state = { startedAt: '', stoppedAt: '', active: false, events: [], loopTimer: null, lastLoopAt: 0, observer: null, exportSequence: 0 };
    const context = typeof options.context === 'function' ? options.context : () => ({});
    function observe(kind, details = {}) {
      const item = clean({ at: now(), kind: text(kind), ...context(), ...details });
      state.events.push(item);
      if (state.events.length > MAX_EVENTS) state.events.shift();
      return item;
    }
    function start(options = {}) {
      if (state.active) return false;
      if (options && options.reset === true) { state.startedAt = ''; state.stoppedAt = ''; state.events = []; state.exportSequence = 0; }
      state.active = true; state.startedAt = now(); state.stoppedAt = ''; state.lastLoopAt = Date.now();
      observe('monitor-started', { order: 'first-package-action', packageVersion: PACKAGE_VERSION });
      if (typeof PerformanceObserver === 'function') {
        try {
          state.observer = new PerformanceObserver((list) => list.getEntries().forEach((entry) => observe('long-task', { durationMs: Math.round(entry.duration) })));
          state.observer.observe({ type: 'longtask', buffered: true });
        } catch (_) { state.observer = null; }
      }
      state.loopTimer = setInterval(() => {
        const current = Date.now(); const delay = current - state.lastLoopAt - 1000; state.lastLoopAt = current;
        if (delay >= 250) observe('event-loop-delay', { durationMs: delay });
      }, 1000);
      return true;
    }
    function stop(reason = 'manual-stop') {
      if (!state.active) return false;
      observe('monitor-stopped', { reason }); state.active = false; state.stoppedAt = now();
      if (state.loopTimer !== null) clearInterval(state.loopTimer); state.loopTimer = null;
      if (state.observer) state.observer.disconnect(); state.observer = null;
      return true;
    }
    function snapshotReport(options = {}) {
      state.exportSequence += 1;
      const reportId = text(options.reportId, `performance-v73-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`);
      const generatedAt = now();
      const lines = ['STADSLASS PRESTANDARAPPORT', `Rapport-ID: ${reportId}`, `Genererad: ${generatedAt}`, `Exportsekvens: ${state.exportSequence}`, `Start: ${state.startedAt || 'Inte startad'}`, `Slut: ${state.stoppedAt || generatedAt}`, `Funktionspaket: ${PACKAGE_VERSION}`, `Händelser: ${state.events.length}`, '', 'HÄNDELSER'];
      state.events.forEach((item) => lines.push(JSON.stringify(item)));
      return { reportType: 'performance', content: lines.join('\n'), reportId, generatedAt, exportSequence: state.exportSequence, eventCount: state.events.length };
    }
    function report(options = {}) { return snapshotReport(options).content; }
    return Object.freeze({ start, stop, observe, report, snapshotReport, state: () => clean({ ...state, loopTimer: undefined, observer: undefined, events: state.events.slice() }) });
  }
  window.StadslassPerformanceMonitor = Object.freeze({ PACKAGE_VERSION, create });
})();
