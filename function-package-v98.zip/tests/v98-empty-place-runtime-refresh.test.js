const assert = require('assert');
const fs = require('fs');
const path = require('path');

const app = fs.readFileSync(path.join(__dirname, '..', 'js', 'app.js'), 'utf8');
assert.ok(app.includes('let placeModelInitialized = false;'));
assert.ok(app.includes('if (!placeModelInitialized) {\n      jobModel.initializePlaces(effective);\n      placeModelInitialized = true;\n    } else {\n      jobModel.replacePlaces(effective);\n    }'));
assert.ok(!app.includes('if (placeItems.length === 0) jobModel.initializePlaces(effective);'));
console.log('PASS v98-empty-place-runtime-refresh.test.js');
