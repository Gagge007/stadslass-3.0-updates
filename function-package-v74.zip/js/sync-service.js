(() => {
  'use strict';

  // Paket 63:s enda transporttjänst. Den äger inte arbetsdata: appen skickar
  // in och sparar settings, queue, activeJob, history och syncOutbox själv.
  const API_VERSION = 1;
  const PACKAGE_VERSION = 73;
  // Paket 73: befintlig driftsync mellan arbets-/planeringsenheter är centralt avstängd.
  // Uppdateringssystem och läsande diagnostik ligger utanför denna transporttjänst.
  const OPERATIONAL_SYNC_ENABLED = false;
  const MAX_REQUEST_BODY = 900 * 1024;
  const MAX_RESPONSE_BODY = 2 * 1024 * 1024;
  const MAX_PATH = 512;
  const MAX_MERGE_ATTEMPTS = 3;
  const COMMAND_RETENTION_DAYS = 30;
  const SYNC_RUNTIME_POLICY_V63 = Object.freeze({
    foregroundMirrorMs: 30000,
    activePublishDebounceMs: 250,
    queuePublishDebounceMs: 750,
    commandConfirmStartMs: 3000,
    commandConfirmMaxMs: 60000,
    staleActiveMs: 120000,
    maxMergeAttempts: MAX_MERGE_ATTEMPTS
  });
  const PRIORITIES = Object.freeze({ active: 'active_work', queue: 'shared_queue', low: 'on_demand' });
  const PROTOCOLS = Object.freeze({
    active: 'stadslass3.active-status.v1', queue: 'stadslass3.shared-queue.v1', commands: 'stadslass3.planning-commands.v1',
    results: 'stadslass3.command-results.v1', register: 'stadslass3.register-snapshot.v1', onDemand: 'stadslass3.on-demand.v1', lease: 'stadslass3.work-lease.v1'
  });

  const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const now = () => new Date().toISOString();
  const bytes = (value) => new TextEncoder().encode(String(value)).length;
  const safeId = (prefix) => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  const validVehicleId = (value) => /^[A-Za-z0-9_-]{1,40}$/.test(text(value));
  const validInstallationId = (value) => /^[A-Za-z0-9._:-]{8,160}$/.test(text(value));
  const validPath = (value) => typeof value === 'string' && value.length > 0 && value.length <= MAX_PATH
    && /^[A-Za-z0-9._/-]+$/.test(value) && !value.startsWith('/') && !value.endsWith('/')
    && !value.includes('..') && !value.includes('//') && !value.includes('\\');

  function parse(raw, fallback = null) {
    if (isObject(raw) || Array.isArray(raw)) return raw;
    try { return JSON.parse(raw); } catch (_) { return fallback; }
  }

  function hostResult(raw) {
    const value = parse(raw, {});
    return isObject(value) ? value : {};
  }

  function hostCapabilities(hostInfo) {
    return Boolean(isObject(hostInfo)
      && Number(hostInfo.syncTransportApiVersion) === API_VERSION
      && Number(hostInfo.deviceIdentityApiVersion) === API_VERSION
      && Number(hostInfo.syncCredentialApiVersion) === API_VERSION);
  }

  function rootFor(settings) {
    const requested = text(settings && settings.syncV63 && settings.syncV63.syncRoot, 'stadslass-3-sync');
    return validPath(requested) && !requested.includes('/') ? requested : 'stadslass-3-sync';
  }

  function pathFor(settings, vehicleId, leaf) {
    if (!validVehicleId(vehicleId)) throw new Error('Fordons-ID för sync är ogiltigt.');
    const path = `${rootFor(settings)}/vehicles/${vehicleId}/${leaf}`;
    if (!validPath(path)) throw new Error('Syncsökvägen är ogiltig.');
    return path;
  }

  function makeEnvelope(protocol, vehicleId, installationId, body = {}) {
    if (!validVehicleId(vehicleId) || !validInstallationId(installationId)) throw new Error('Syncidentiteten är ogiltig.');
    return { schemaVersion: 1, protocol, vehicleId, packageVersion: PACKAGE_VERSION, sourceInstallationId: installationId, publishedAt: now(), ...clone(body) };
  }

  function activeStatus(activeJob, vehicleId, installationId, sequence, workLease) {
    const source = isObject(activeJob) ? activeJob : {};
    const allow = ['id', 'jobId', 'sourceQueueItemId', 'jobTypeId', 'jobTypeName', 'fromPlaceId', 'fromPlaceName', 'destinationPlaceId', 'destinationPlaceName', 'returnPlaceId', 'returnPlaceName', 'phase', 'phaseCode', 'status', 'startedAt', 'pausedAt', 'updatedAt', 'weightEntries', 'loads', 'loadCycles', 'multiLoad', 'returnRequired', 'noEmptying', 'note', 'plannedDate', 'plannedTime', 'ata'];
    const job = {};
    allow.forEach((key) => { if (source[key] !== undefined) job[key] = clone(source[key]); });
    if (job.ata && isObject(job.ata)) job.ata = { enabled: job.ata.enabled === true };
    const hasActive = Boolean(text(job.id) && ['active', 'paused', 'completing'].includes(text(job.status)));
    return makeEnvelope(PROTOCOLS.active, vehicleId, installationId, {
      sequence: Math.max(1, Number(sequence) || 1), hasActiveJob: hasActive, activeJob: hasActive ? job : null,
      workLease: isObject(workLease) ? { workSessionId: text(workLease.workSessionId), leaseUpdatedAt: text(workLease.leaseUpdatedAt), leaseExpiresAt: text(workLease.leaseExpiresAt), role: 'vehicle_189' } : null
    });
  }

  function sharedQueue(queue, vehicleId, installationId, revision) {
    const items = (Array.isArray(queue) ? queue : []).map((item) => {
      const copy = clone(item);
      delete copy.temporaryGoogleDiagnostics;
      return copy;
    });
    return makeEnvelope(PROTOCOLS.queue, vehicleId, installationId, { queueRevision: Math.max(1, Number(revision) || 1), items });
  }

  function workLease(vehicleId, installationId, workSessionId, hasActiveJob, expiresAt) {
    return makeEnvelope(PROTOCOLS.lease, vehicleId, installationId, {
      workSessionId: text(workSessionId), role: 'vehicle_189', hasActiveJob: hasActiveJob === true,
      leaseUpdatedAt: now(), leaseExpiresAt: text(expiresAt)
    });
  }

  function command(commandType, sourceInstallationId, vehicleId, job, expectedJobRevision = 0, commandId = '') {
    if (!['create', 'edit', 'delete'].includes(commandType)) throw new Error('Okänd planeringsåtgärd.');
    const jobId = text(job && (job.jobId || job.id));
    if (!jobId || !validInstallationId(sourceInstallationId) || !validVehicleId(vehicleId)) throw new Error('Planeringsuppdraget saknar giltig identitet.');
    return {
      schemaVersion: 1, protocol: PROTOCOLS.commands, commandId: text(commandId) || safeId('cmd'), commandType, jobId,
      jobRevision: Math.max(1, Number(job && job.jobRevision) || 1), expectedJobRevision: Math.max(0, Number(expectedJobRevision) || 0),
      sourceInstallationId, sourceRole: 'mobile', targetVehicleId: vehicleId, createdAt: now(), packageVersion: PACKAGE_VERSION,
      job: commandType === 'delete' ? undefined : clone(job)
    };
  }

  function onDemandRequest(requestType, sourceInstallationId, vehicleId, criteria = {}, requestId = '') {
    if (!['register', 'today', 'history', 'statistics'].includes(requestType) || !validInstallationId(sourceInstallationId) || !validVehicleId(vehicleId)) throw new Error('Ogiltig begäran om läsunderlag.');
    return { schemaVersion: 1, protocol: PROTOCOLS.onDemand, onDemandRequestId: text(requestId) || safeId('demand'), requestType,
      vehicleId, sourceInstallationId, sourceRole: 'mobile', createdAt: now(), packageVersion: PACKAGE_VERSION, criteria: clone(criteria) };
  }

  function validateEnvelope(documentValue, protocol, vehicleId) {
    if (!isObject(documentValue) || Number(documentValue.schemaVersion) !== 1 || text(documentValue.protocol) !== protocol
      || text(documentValue.vehicleId) !== vehicleId || !validInstallationId(documentValue.sourceInstallationId)) throw new Error('Syncdokumentet har fel schema, källa eller fordon.');
    if (Number(documentValue.packageVersion) < 1 || Number(documentValue.packageVersion) > PACKAGE_VERSION) throw new Error('Syncdokumentet har en okänd paketversion.');
    return documentValue;
  }

  function sanitizeText(value, max = 280) { return text(value).replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, max); }

  function commandResult(commandValue, status, message, extra = {}) {
    return { commandId: text(commandValue.commandId), jobId: text(commandValue.jobId), commandType: text(commandValue.commandType), status,
      vehicleId: text(commandValue.targetVehicleId), sourceInstallationId: text(extra.sourceInstallationId), processedAt: now(),
      queueRevision: Number(extra.queueRevision) || 0, jobRevision: Number(extra.jobRevision) || 0,
      errorCode: sanitizeText(extra.errorCode, 80), message: sanitizeText(message, 280) };
  }

  function applyCommand(queue, activeJob, commandValue, vehicleId, vehicleInstallationId, knownCommandIds = new Set()) {
    const current = Array.isArray(queue) ? queue : [];
    try {
      const cmd = commandValue;
      if (!isObject(cmd) || text(cmd.protocol) !== PROTOCOLS.commands || text(cmd.sourceRole) !== 'mobile'
        || text(cmd.targetVehicleId) !== vehicleId || !validInstallationId(cmd.sourceInstallationId) || !text(cmd.commandId)
        || !['create', 'edit', 'delete'].includes(text(cmd.commandType))) throw new Error('Ogiltigt planeringskommando.');
      if (knownCommandIds.has(text(cmd.commandId))) return { queue: current, result: commandResult(cmd, 'already-present', 'Kommandot är redan behandlat.', { sourceInstallationId: vehicleInstallationId }) };
      const index = current.findIndex((item) => text(item && (item.jobId || item.id)) === text(cmd.jobId));
      const activeId = text(activeJob && (activeJob.sourceQueueItemId || activeJob.jobId || activeJob.id));
      if (text(cmd.commandType) === 'create') {
        if (!isObject(cmd.job) || text(cmd.job.jobId || cmd.job.id) !== text(cmd.jobId)) throw new Error('Create-kommandot saknar ett giltigt uppdrag.');
        if (index >= 0) return { queue: current, result: commandResult(cmd, 'already-present', 'Uppdraget finns redan i 189:s kö.', { sourceInstallationId: vehicleInstallationId }) };
        const imported = { ...clone(cmd.job), id: text(cmd.job.id, cmd.jobId), jobId: cmd.jobId, status: 'queued', jobRevision: Math.max(1, Number(cmd.jobRevision) || 1),
          source: 'mobile-github-sync', receivedAt: now(), sync: { ...(isObject(cmd.job.sync) ? cmd.job.sync : {}), commandId: cmd.commandId, sourceInstallationId: cmd.sourceInstallationId } };
        return { queue: [...current, imported], changed: true, result: commandResult(cmd, 'applied', 'Mottaget i 189:s kö.', { sourceInstallationId: vehicleInstallationId, queueRevision: 1, jobRevision: imported.jobRevision }), notification: true };
      }
      if (index < 0) return { queue: current, result: commandResult(cmd, 'rejected', 'Kan inte ändras – uppdraget finns inte längre i kön.', { sourceInstallationId: vehicleInstallationId, errorCode: 'job_missing' }) };
      const existing = current[index];
      if (activeId && (activeId === text(existing.id) || activeId === text(existing.jobId))) return { queue: current, result: commandResult(cmd, 'rejected', cmd.commandType === 'delete' ? 'Kan inte tas bort – uppdraget är aktivt på 189.' : 'Kan inte ändras – uppdraget har startats.', { sourceInstallationId: vehicleInstallationId, errorCode: 'job_active' }) };
      const revision = Math.max(1, Number(existing.jobRevision) || 1);
      if (Number(cmd.expectedJobRevision) !== revision) return { queue: current, result: commandResult(cmd, 'rejected', 'Kan inte ändras – uppdraget har en nyare version på 189.', { sourceInstallationId: vehicleInstallationId, errorCode: 'revision_conflict', jobRevision: revision }) };
      if (cmd.commandType === 'delete') return { queue: current.filter((_, i) => i !== index), changed: true, result: commandResult(cmd, 'applied', 'Uppdraget är borttaget från 189:s kö.', { sourceInstallationId: vehicleInstallationId }) };
      if (!isObject(cmd.job) || text(cmd.job.jobId || cmd.job.id) !== text(cmd.jobId)) throw new Error('Edit-kommandot saknar en giltig uppdragsversion.');
      const updated = { ...existing, ...clone(cmd.job), id: existing.id, jobId: existing.jobId, jobRevision: revision + 1, updatedAt: now(), sync: { ...(isObject(existing.sync) ? existing.sync : {}), commandId: cmd.commandId, sourceInstallationId: cmd.sourceInstallationId } };
      const next = current.slice(); next[index] = updated;
      return { queue: next, changed: true, result: commandResult(cmd, 'applied', 'Ändringen är sparad i 189:s kö.', { sourceInstallationId: vehicleInstallationId, jobRevision: updated.jobRevision }) };
    } catch (error) {
      return { queue: current, result: commandResult(commandValue || {}, 'rejected', error.message || 'Planeringskommandot avvisades.', { sourceInstallationId: vehicleInstallationId, errorCode: 'invalid_command' }) };
    }
  }

  function request(operation, path, priority, channel, body = '', expectedSha = '', coalesceKey = '', requestId = '') {
    if (!['GET', 'PUT'].includes(operation) || !validPath(path) || !Object.values(PRIORITIES).includes(priority)) throw new Error('Syncrequestet är ogiltigt.');
    if (bytes(body) > MAX_REQUEST_BODY) throw new Error('Syncdatan är för stor för säker transport.');
    return { requestId: text(requestId) || safeId('sync'), operation, path, priority, channel: sanitizeText(channel, 120), createdAt: now(), body: String(body), expectedSha: text(expectedSha), coalesceKey: sanitizeText(coalesceKey, 180) };
  }

  const ACTIVE_REQUEST_STATES = Object.freeze(['pending', 'running', 'accepted', 'failed_retryable', 'retryable']);
  const TERMINAL_JOURNAL_KIND = 'sync-v69-terminal-journal';
  const RESOURCE_STATE_KIND = 'sync-v69-resource-state';
  const MAX_TERMINAL_JOURNAL = 50;

  function terminal(status) { return ['succeeded', 'failed_permanent', 'conflict', 'superseded'].includes(text(status)); }
  function activeRequest(entry) {
    return isObject(entry) && entry.kind === 'sync-v63-request' && ACTIVE_REQUEST_STATES.includes(text(entry.state));
  }
  function compactTerminal(entry) {
    const requestValue = isObject(entry && entry.request) ? entry.request : {};
    const resultValue = isObject(entry && entry.result) ? entry.result : {};
    return {
      requestId: text(entry && entry.requestId), intent: text(entry && entry.intent), operation: text(requestValue.operation),
      path: text(requestValue.path), coalesceKey: text(requestValue.coalesceKey), state: text(entry && entry.state),
      httpStatus: Number(resultValue.httpStatus) || 0, errorCode: text(resultValue.errorCode),
      createdAt: text(entry && entry.createdAt), completedAt: text(resultValue.completedAt || entry && entry.updatedAt),
      packageVersion: Number(entry && entry.packageVersion) || 0
    };
  }
  function terminalJournal(entries) {
    return (Array.isArray(entries) ? entries : []).find((entry) => isObject(entry) && entry.kind === TERMINAL_JOURNAL_KIND) || null;
  }
  function migrateOutbox(entries) {
    const input = Array.isArray(entries) ? entries : [];
    const existing = terminalJournal(input);
    const moved = input.filter((entry) => isObject(entry) && entry.kind === 'sync-v63-request' && terminal(entry.state));
    if (!moved.length) return { entries: input, moved: 0, changed: false };
    const retained = input.filter((entry) => !(isObject(entry) && entry.kind === 'sync-v63-request' && terminal(entry.state)) && !(isObject(entry) && entry.kind === TERMINAL_JOURNAL_KIND));
    const history = [...(existing && Array.isArray(existing.items) ? existing.items : []), ...moved.map(compactTerminal)].slice(-MAX_TERMINAL_JOURNAL);
    retained.push({ id: TERMINAL_JOURNAL_KIND, kind: TERMINAL_JOURNAL_KIND, items: history, updatedAt: now(), packageVersion: PACKAGE_VERSION });
    return { entries: retained, moved: moved.length, changed: true };
  }
  function consumeTerminal(entries, requestId, result) {
    const input = Array.isArray(entries) ? entries : [];
    const target = input.find((entry) => isObject(entry) && entry.kind === 'sync-v63-request' && text(entry.requestId) === text(requestId));
    if (!target) return { entries: input, consumed: false };
    const existing = terminalJournal(input);
    const completed = { ...target, state: text(result && result.status, target.state), result: clone(result || {}), updatedAt: now() };
    const retained = input.filter((entry) => entry !== target && !(isObject(entry) && entry.kind === TERMINAL_JOURNAL_KIND));
    const history = [...(existing && Array.isArray(existing.items) ? existing.items : []), compactTerminal(completed)].slice(-MAX_TERMINAL_JOURNAL);
    retained.push({ id: TERMINAL_JOURNAL_KIND, kind: TERMINAL_JOURNAL_KIND, items: history, updatedAt: now(), packageVersion: PACKAGE_VERSION });
    return { entries: retained, consumed: true, entry: completed };
  }
  function resourceState(entries, path) {
    return (Array.isArray(entries) ? entries : []).find((entry) => isObject(entry) && entry.kind === RESOURCE_STATE_KIND && text(entry.path) === text(path)) || null;
  }
  function setResourceState(entries, path, patch = {}) {
    const input = Array.isArray(entries) ? entries : [];
    const next = input.filter((entry) => !(isObject(entry) && entry.kind === RESOURCE_STATE_KIND && text(entry.path) === text(path)));
    next.push({ id: `${RESOURCE_STATE_KIND}:${text(path)}`, kind: RESOURCE_STATE_KIND, path: text(path), ...clone(patch), updatedAt: now(), packageVersion: PACKAGE_VERSION });
    return next;
  }
  function counts(entries) {
    const input = Array.isArray(entries) ? entries : [];
    return {
      total: input.length,
      activeRequests: input.filter(activeRequest).length,
      terminalRequests: input.filter((entry) => isObject(entry) && entry.kind === 'sync-v63-request' && terminal(entry.state)).length,
      retryableRequests: input.filter((entry) => isObject(entry) && entry.kind === 'sync-v63-request' && ['failed_retryable', 'retryable'].includes(text(entry.state))).length,
      realWork: input.filter((entry) => {
        if (!isObject(entry)) return false;
        if (['queue-transfer', 'queue-receipt'].includes(text(entry.kind))) return !['acknowledged', 'accepted', 'completed', 'rejected', 'cancelled'].includes(text(entry.state));
        if (entry.kind === 'sync-v63-command') return ['waiting_ledger', 'waiting_send', 'waiting_result', 'failed_retryable', 'sync_conflict'].includes(text(entry.state));
        if (entry.kind === 'sync-v63-on-demand') return ['waiting_ledger', 'waiting_send', 'waiting_result', 'failed_retryable', 'sync_conflict'].includes(text(entry.state));
        return false;
      }).length,
      journalItems: input.filter((entry) => isObject(entry) && entry.kind === TERMINAL_JOURNAL_KIND).reduce((sum, entry) => sum + (Array.isArray(entry.items) ? entry.items.length : 0), 0)
    };
  }

  function create(environment) {
    if (!isObject(environment) || typeof environment.readOutbox !== 'function' || typeof environment.saveOutbox !== 'function') throw new Error('Synctjänsten saknar säker lagringsadapter.');
    const env = environment;
    function enqueue(intent, operation, path, priority, body = '', expectedSha = '', coalesceKey = '') {
      if (!OPERATIONAL_SYNC_ENABLED) return { ok: false, status: 'operational_sync_disabled', disabled: true };
      const capabilities = hostCapabilities(env.getHostInfo());
      if (!capabilities) return { ok: false, status: 'host_v12_required' };
      const host = env.host();
      if (!host || typeof host.enqueueSyncRequest !== 'function') return { ok: false, status: 'host_v12_required' };
      const outbox = env.readOutbox();
      const duplicate = text(coalesceKey) && outbox.find((entry) => activeRequest(entry) && text(entry.request && entry.request.coalesceKey) === text(coalesceKey));
      if (duplicate) return { ok: true, status: 'duplicate_pending', requestId: text(duplicate.requestId), duplicate: true };
      const known = resourceState(outbox, path);
      const resolvedSha = operation === 'PUT' ? (text(expectedSha) || text(known && known.sha)) : text(expectedSha);
      const value = request(operation, path, priority, `v73/${intent}`, body, resolvedSha, coalesceKey);
      const accepted = hostResult(host.enqueueSyncRequest(JSON.stringify(value)));
      const entry = { id: `sync-v63-${value.requestId}`, kind: 'sync-v63-request', requestId: value.requestId, intent, request: value,
        state: text(accepted.status, accepted.ok ? 'pending' : 'failed_permanent'), createdAt: now(), updatedAt: now(), packageVersion: PACKAGE_VERSION };
      if (!env.saveOutbox([...outbox, entry])) return { ok: false, status: 'local_save_failed' };
      return { ok: accepted.ok === true || ['accepted', 'duplicate', 'duplicate_pending'].includes(text(accepted.status)), status: text(accepted.status), requestId: value.requestId };
    }
    function recover(requestId) {
      if (!OPERATIONAL_SYNC_ENABLED) return { ok: false, status: 'operational_sync_disabled', disabled: true };
      const host = env.host(); if (!host || typeof host.getSyncRequestStatus !== 'function') return null;
      return hostResult(host.getSyncRequestStatus(requestId));
    }
    function recordResult(requestId, result) {
      if (!OPERATIONAL_SYNC_ENABLED) return null;
      const entries = env.readOutbox(); const index = entries.findIndex((entry) => text(entry.requestId) === text(requestId));
      if (index < 0) return null;
      const next = entries.slice(); next[index] = { ...next[index], state: text(result.status, 'unknown'), result: clone(result), updatedAt: now() };
      if (!env.saveOutbox(next)) return null;
      return next[index];
    }
    return Object.freeze({ apiVersion: API_VERSION, operationalSyncEnabled: OPERATIONAL_SYNC_ENABLED, policy: SYNC_RUNTIME_POLICY_V63, capabilities: () => hostCapabilities(env.getHostInfo()), enqueue, recover, recordResult,
      request, pathFor, activeStatus, sharedQueue, workLease, command, validateEnvelope, applyCommand, commandResult, terminal, activeRequest,
      migrateOutbox, consumeTerminal, resourceState, setResourceState, counts, protocols: PROTOCOLS, priorities: PRIORITIES,
      maxResponseBody: MAX_RESPONSE_BODY, retentionDays: COMMAND_RETENTION_DAYS, terminalJournalKind: TERMINAL_JOURNAL_KIND, resourceStateKind: RESOURCE_STATE_KIND });
  }

  window.StadslassSyncService = Object.freeze({ API_VERSION, PACKAGE_VERSION, OPERATIONAL_SYNC_ENABLED, SYNC_RUNTIME_POLICY_V63, PRIORITIES, PROTOCOLS, hostCapabilities, pathFor, activeStatus, sharedQueue, workLease, command, onDemandRequest, validateEnvelope, applyCommand, commandResult, request, terminal, activeRequest, migrateOutbox, consumeTerminal, resourceState, setResourceState, counts, create, sanitizeText, bytes });
})();
