#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
app=(ROOT/'js/app.js').read_text(encoding='utf-8')
svc=(ROOT/'js/sync-service.js').read_text(encoding='utf-8')
def req(v,m):
    if not v: raise AssertionError(m)
req('const DRIFT_SYNC_ENABLED = Boolean(syncServiceApi && syncServiceApi.OPERATIONAL_SYNC_ENABLED === true);' in app,'app gate missing')
req("if (!DRIFT_SYNC_ENABLED) {\n      syncDiagnosticObserve('sync-request-blocked'" in app,'enqueue gate missing')
req("if (!DRIFT_SYNC_ENABLED) {\n      syncDiagnosticObserve('sync-result-ignored'" in app,'late result gate missing')
req('sync-outbox-readonly-preserved' in app,'raw outbox preservation missing')
req("window.addEventListener('focus', () => { if (syncV63OperationallyEnabled()) syncV63SyncNow(); });" in app,'focus still starts drift sync')
req("else if (syncV63OperationallyEnabled()) window.setTimeout(syncV63SyncNow, 0);" in app,'startup still starts drift sync')
req("syncV63OperationallyEnabled() ? 'Skicka till 189' : 'Förbered överföring till 189'" in app,'reserve transfer routing not restored while disabled')
req('const OPERATIONAL_SYNC_ENABLED = false;' in svc,'service switch missing')
req("if (!OPERATIONAL_SYNC_ENABLED) return { ok: false, status: 'operational_sync_disabled', disabled: true };" in svc,'hard gate missing')
req('enqueueSyncRequest' not in app,'app bypasses central service')
print('PASS drift-sync-stop-v73.test.py')
