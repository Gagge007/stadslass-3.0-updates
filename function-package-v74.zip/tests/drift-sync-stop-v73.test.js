const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const code = fs.readFileSync(require('path').join(__dirname, '..', 'js', 'sync-service.js'), 'utf8');
const context = { window: {}, TextEncoder, console };
vm.createContext(context); vm.runInContext(code, context);
const api = context.window.StadslassSyncService;
assert.strictEqual(api.PACKAGE_VERSION, 73);
assert.strictEqual(api.OPERATIONAL_SYNC_ENABLED, false);
let hostCalls = 0, saves = 0, reads = 0;
const service = api.create({
  host: () => ({ enqueueSyncRequest(){ hostCalls++; throw new Error('host transport must not be called'); }, getSyncRequestStatus(){ hostCalls++; throw new Error('host status must not be called'); } }),
  getHostInfo: () => ({ syncTransportApiVersion:1, deviceIdentityApiVersion:1, syncCredentialApiVersion:1 }),
  readOutbox: () => { reads++; return [{id:'keep-me',kind:'sync-v63-request',state:'accepted'}]; },
  saveOutbox: () => { saves++; return true; }
});
for (const c of [
  ['put-active','PUT','stadslass-3-sync/vehicles/189/active-status.json','active_work','{}'],
  ['put-queue','PUT','stadslass-3-sync/vehicles/189/shared-queue.json','shared_queue','{}'],
  ['get-active','GET','stadslass-3-sync/vehicles/189/active-status.json','active_work',''],
  ['get-queue','GET','stadslass-3-sync/vehicles/189/shared-queue.json','shared_queue',''],
  ['get-commands','GET','stadslass-3-sync/vehicles/189/planning-commands.json','shared_queue',''],
  ['get-results','GET','stadslass-3-sync/vehicles/189/command-results.json','shared_queue',''],
  ['get-planning-ledger','GET','stadslass-3-sync/vehicles/189/planning-commands.json','shared_queue',''],
  ['put-planning-ledger','PUT','stadslass-3-sync/vehicles/189/planning-commands.json','shared_queue','{}'],
  ['put-results','PUT','stadslass-3-sync/vehicles/189/command-results.json','shared_queue','{}'],
  ['get-on-demand-requests','GET','stadslass-3-sync/vehicles/189/on-demand-requests.json','on_demand',''],
  ['get-on-demand-ledger','GET','stadslass-3-sync/vehicles/189/on-demand-requests.json','on_demand',''],
  ['put-on-demand-ledger','PUT','stadslass-3-sync/vehicles/189/on-demand-requests.json','on_demand','{}'],
  ['get-on-demand-index','GET','stadslass-3-sync/vehicles/189/on-demand-index.json','on_demand',''],
  ['put-on-demand-index','PUT','stadslass-3-sync/vehicles/189/on-demand-index.json','on_demand','{}'],
  ['connection-check','GET','stadslass-3-sync/vehicles/189/active-status.json','active_work','']
]) {
  const r = service.enqueue(c[0],c[1],c[2],c[3],c[4],'',c[0]);
  assert.strictEqual(r.ok,false); assert.strictEqual(r.status,'operational_sync_disabled'); assert.strictEqual(r.disabled,true);
}
const recovered = service.recover('old-request');
assert.strictEqual(recovered.status,'operational_sync_disabled');
assert.strictEqual(service.recordResult('old-request',{status:'succeeded'}),null);
assert.strictEqual(hostCalls,0); assert.strictEqual(saves,0); assert.strictEqual(reads,0);
console.log('PASS drift-sync-stop-v73.test.js');
