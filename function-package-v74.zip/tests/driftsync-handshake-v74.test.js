'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const code = fs.readFileSync(path.join(__dirname, '..', 'js', 'driftsync-handshake-service.js'), 'utf8');
const context = { window: {}, TextEncoder, console, Date, Math, JSON, Object, Array, String, Number, RegExp, Error, Infinity };
vm.createContext(context); vm.runInContext(code, context);
const api = context.window.StadslassDriftsyncHandshake;
assert.strictEqual(api.PACKAGE_VERSION, 74);
assert.strictEqual(api.INTERVAL_MS, 300000);
assert.strictEqual(api.PROTOCOL, 'stadslass3.handshake.v1');
const remote = {};
function node(role, id) {
  let state = {};
  const statuses = new Map();
  const host = {
    enqueueSyncRequest(raw) {
      const request = JSON.parse(raw); statuses.set(request.requestId, { status: 'succeeded', operation: request.operation, path: request.path, body: request.operation === 'GET' ? (remote[request.path] || '') : '' });
      if (request.operation === 'PUT') remote[request.path] = request.body;
      return JSON.stringify({ ok: true, status: 'accepted' });
    },
    getSyncRequestStatus(requestId) { return JSON.stringify(statuses.get(requestId) || { status: 'failed_permanent', httpStatus: 404 }); }
  };
  return api.create({ host: () => host, getConfig: () => ({ configured: true, syncRoot: 'stadslass-3-sync' }), getIdentity: () => ({ role, installationId: id }), getActiveStatus: () => ({ hasActiveJob: true, activeJobId: 'job-123' }), loadState: () => state, saveState: (next) => { state = next; } });
}
const vehicle = node('vehicle_189', 'vehicle-189-test');
const computer = node('computer', 'computer-01-test');
const first = vehicle.tick('startup');
assert.strictEqual(first.ok, true);
assert.strictEqual(vehicle.handleResult(first.requestId), true);
const vehicleRequest = JSON.parse(remote['stadslass-3-sync/handshake/vehicle-189.json']);
assert.strictEqual(vehicleRequest.sequence, 1);
assert.strictEqual(vehicleRequest.hasActiveJob, true);
assert.strictEqual(vehicleRequest.activeJobId, 'job-123');
const readByComputer = computer.tick('startup');
assert.strictEqual(readByComputer.ok, true);
computer.handleResult(readByComputer.requestId);
const response = JSON.parse(remote['stadslass-3-sync/handshake/computer.json']);
assert.strictEqual(response.replyToSequence, 1);
const readByVehicle = vehicle.tick('timer');
assert.strictEqual(readByVehicle.ok, true);
vehicle.handleResult(readByVehicle.requestId);
assert.strictEqual(vehicle.status().latestReplyToSequence, 1);
assert.strictEqual(vehicle.status().statusCode, 'HANDSHAKE_WAITING_FOR_REPLY');
assert.strictEqual(vehicle.status().latestSequence, 2);
const stale = { ...response, replyToSequence: 1 };
remote['stadslass-3-sync/handshake/computer.json'] = JSON.stringify(stale);
const staleRead = vehicle.tick('timer'); vehicle.handleResult(staleRead.requestId);
assert.strictEqual(vehicle.status().latestReplyToSequence, 1);
assert.strictEqual(vehicle.status().statusCode, 'HANDSHAKE_WAITING_FOR_REPLY');
assert.throws(() => api.validateVehicleRequest({ protocol: api.PROTOCOL }), /HANDSHAKE_INVALID_PAYLOAD/);
assert.throws(() => api.validateComputerResponse({ schemaVersion: 1, protocol: 'wrong' }), /HANDSHAKE_PROTOCOL_MISMATCH/);
console.log('PASS driftsync-handshake-v74.test.js');
