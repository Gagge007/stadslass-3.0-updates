(function () {
  'use strict';
  const PING_LOG_KIND = 'sync-v89-ping-log';
  const text = (value) => typeof value === 'string' ? value : (value === undefined || value === null ? '' : String(value));
  const dateMs = (value) => {
    const parsed = Date.parse(text(value));
    return Number.isFinite(parsed) ? parsed : 0;
  };
  function pingView(entry, nowMs) {
    const createdAt = text(entry && entry.createdAt);
    return {
      key: text(entry && entry.id), id: text(entry && entry.id), channel: text(entry && entry.channel) || 'ping', sequence: Number(entry && entry.sequence), direction: text(entry && entry.direction),
      state: text(entry && entry.state), createdAt,
      ageSeconds: createdAt ? Math.max(0, Math.floor((nowMs - dateMs(createdAt)) / 1000)) : 0
    };
  }
  function isPingEntry(entry) { return Boolean(entry && entry.kind === PING_LOG_KIND && (!entry.channel || text(entry.channel) === 'ping')); }
  function inspect(entries, nowMs = Date.now()) {
    const records = (Array.isArray(entries) ? entries : []).filter(isPingEntry).map((entry) => pingView(entry, nowMs));
    records.sort((a, b) => dateMs(a.createdAt) - dateMs(b.createdAt));
    return { records, matched: records.filter((record) => record.state === 'matched') };
  }
  function clearStuck(entries, nowMs = Date.now()) {
    const inspected = inspect(entries, nowMs);
    return { next: (Array.isArray(entries) ? entries : []).filter((entry) => !isPingEntry(entry)), removed: inspected.records.length, inspected };
  }
  window.StadslassSyncQueueControls = Object.freeze({ inspect, clearStuck, PING_LOG_KIND });
})();
