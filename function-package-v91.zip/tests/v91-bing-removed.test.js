const fs = require('fs');
const assert = require('assert');
const path = require('path');
const app = fs.readFileSync(path.join(__dirname, '..', 'js', 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const controls = fs.readFileSync(path.join(__dirname, '..', 'js', 'sync-queue-controls.js'), 'utf8');
for (const marker of [
  'function syncV90SendBing()', 'function syncV90ReadBing()', 'syncV90AppendBing', 'syncV90MatchBing',
  'stadslass3.drift-bing.v1', 'stadslass3.drift-bong.v1', 'v90-put-bing', 'v90-get-bing',
  'v90-put-bing-reply', 'v90-get-bing-reply', 'planning-bing.json', 'vehicle-189-bing-reply.json',
  "every('bing'", 'v90Bing'
]) assert.ok(!app.includes(marker), `Bing runtime remains: ${marker}`);
assert.ok(!html.includes('Ping- och Binglogg'));
assert.ok(!html.includes('Rensa Ping- och Binglogg'));
assert.ok(html.includes('Pinglogg'));
assert.ok(html.includes('Rensa Pinglogg'));
assert.ok(app.includes('function syncV85SendPing()'));
assert.ok(app.includes('function syncV85ReadPing()'));
assert.ok(app.includes('function syncV89ReadEchoForWrite()'));
assert.ok(app.includes("syncV89AppendPing(sequence, 'ping', 'sent')"));
assert.ok(app.includes('syncV89MatchPing(repliedTo)'));
assert.ok(app.includes('stadslass3.drift-ping.v1'));
assert.ok(app.includes('stadslass3.drift-pong.v1'));
assert.ok(app.includes('vehicle-189-ping.json'));
assert.ok(app.includes('planning-reply.json'));
assert.ok(app.includes("every('ping', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs, syncV85SendPing);"));
assert.ok(controls.includes("text(entry.channel) === 'ping'"));
console.log('PASS v91-bing-removed.test.js');
