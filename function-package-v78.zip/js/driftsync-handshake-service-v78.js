(() => {
  'use strict';

  const PACKAGE_VERSION = 78;
  const PROTOCOL = 'stadslass3.handshake.v1';
  const INTERVAL_MS = 60 * 1000;
  const PRESENCE_TIMEOUT_MS = 3 * INTERVAL_MS;
  const MAX_DIAGNOSTICS = 80;
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const now = () => new Date().toISOString();
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const parse = (value, fallback = null) => { try { return JSON.parse(value); } catch (_) { return fallback; } };
  const validPath = (value) => /^[A-Za-z0-9._/-]{1,512}$/.test(text(value)) && !text(value).includes('..') && !text(value).includes('//');
  const validIdentity = (value) => /^[A-Za-z0-9._:-]{8,160}$/.test(text(value));
  const resultObject = (value) => isObject(value) ? value : parse(value, {});

  function paths(syncRoot) {
    const root = text(syncRoot, 'stadslass-3-sync');
    if (!validPath(root) || root.includes('/')) throw new Error('HANDSHAKE_TRANSPORT_UNAVAILABLE');
    return Object.freeze({ vehicle: `${root}/handshake/vehicle-189.json`, computer: `${root}/handshake/computer.json` });
  }

  function emptyState() {
    return {
      schemaVersion: 1, packageVersion: PACKAGE_VERSION, enabled: true, statusCode: 'HANDSHAKE_NO_PEER_PRESENT',
      state: 'no_peer_present', lastSuccessAt: '', lastCheckAt: '', lastErrorAt: '', lastErrorCode: '', lastErrorDetail: '',
      latestSequence: 0, latestReplyToSequence: 0, latestVehicleSequence: 0, lastRequestAt: '', lastRequestSeenAt: '',
      lastVehicleRequestAt: '', lastVehicleHasActiveJob: null, lastResponseAt: '', lastValidReplyAt: '',
      peerInstallationId: '', diagnostics: []
    };
  }

  function normalizeState(raw) {
    const base = emptyState();
    const value = isObject(raw) ? raw : {};
    return {
      ...base, ...value, enabled: true, packageVersion: PACKAGE_VERSION,
      latestSequence: Math.max(0, Number(value.latestSequence) || 0),
      latestReplyToSequence: Math.max(0, Number(value.latestReplyToSequence) || 0),
      latestVehicleSequence: Math.max(0, Number(value.latestVehicleSequence) || 0),
      lastVehicleHasActiveJob: null,
      diagnostics: Array.isArray(value.diagnostics) ? value.diagnostics.slice(-MAX_DIAGNOSTICS) : []
    };
  }

  function validateVehicleRequest(value) {
    if (!isObject(value) || Number(value.schemaVersion) !== 1) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (text(value.protocol) !== PROTOCOL) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    if (text(value.vehicleId) !== '189' || text(value.senderRole) !== 'vehicle_189' || !validIdentity(value.senderInstallationId) || !Number.isInteger(Number(value.sequence)) || Number(value.sequence) < 1
      || !text(value.sentAt)) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (Number(value.packageVersion) < 74) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    const allowed = { schemaVersion: value.schemaVersion, protocol: value.protocol, vehicleId: value.vehicleId, senderRole: value.senderRole,
      senderInstallationId: value.senderInstallationId, sequence: Number(value.sequence), sentAt: value.sentAt,
      packageVersion: Number(value.packageVersion) };
    return allowed;
  }

  function validateComputerResponse(value) {
    if (!isObject(value) || Number(value.schemaVersion) !== 1) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (text(value.protocol) !== PROTOCOL) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    if (text(value.vehicleId) !== '189' || text(value.responderRole) !== 'computer' || !validIdentity(value.responderInstallationId) || !Number.isInteger(Number(value.replyToSequence))
      || Number(value.replyToSequence) < 1 || !text(value.requestSeenAt) || !text(value.respondedAt)) throw new Error('HANDSHAKE_INVALID_PAYLOAD');
    if (Number(value.packageVersion) < 74) throw new Error('HANDSHAKE_PROTOCOL_MISMATCH');
    return { schemaVersion: value.schemaVersion, protocol: value.protocol, vehicleId: value.vehicleId, responderRole: value.responderRole,
      responderInstallationId: value.responderInstallationId, replyToSequence: Number(value.replyToSequence), requestSeenAt: value.requestSeenAt,
      respondedAt: value.respondedAt, packageVersion: Number(value.packageVersion) };
  }

  function stateWith(state, patch, diagnostic) {
    const next = { ...state, ...patch, lastCheckAt: now() };
    if (diagnostic) next.diagnostics = [...state.diagnostics, { at: now(), packageVersion: PACKAGE_VERSION, component: 'Närvaro och handskakning', ...diagnostic }].slice(-MAX_DIAGNOSTICS);
    return next;
  }

  function create(environment) {
    if (!isObject(environment) || typeof environment.host !== 'function' || typeof environment.getConfig !== 'function'
      || typeof environment.getIdentity !== 'function' || typeof environment.loadState !== 'function' || typeof environment.saveState !== 'function') {
      throw new Error('Handskakningstjänsten saknar säker miljöadapter.');
    }
    let state = normalizeState(environment.loadState());
    const pending = new Map();
    function persist(next) { state = normalizeState(next); environment.saveState(clone(state)); return state; }
    function record(patch, diagnostic) { return persist(stateWith(state, patch, diagnostic)); }
    function configuration() {
      const value = environment.getConfig() || {};
      return {
        configured: value.configured === true,
        syncRoot: text(value.syncRoot, 'stadslass-3-sync'),
        explicitlyDisabled: value.explicitlyDisabled === true,
        hostAvailable: value.hostAvailable === true
      };
    }
    function identity() {
      const value = environment.getIdentity() || {};
      return { installationId: text(value.installationId), role: text(value.role) };
    }
    function enqueue(intent, operation, path, body = '') {
      const host = environment.host();
      if (!host || typeof host.enqueueSyncRequest !== 'function') throw new Error('HANDSHAKE_TRANSPORT_UNAVAILABLE');
      const requestId = `handshake-${intent}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      const request = { requestId, operation, path, priority: 'fast_lane', channel: `v${PACKAGE_VERSION}/handshake/${intent}`, createdAt: now(), body, expectedSha: '', coalesceKey: `handshake/${intent}` };
      const accepted = resultObject(host.enqueueSyncRequest(JSON.stringify(request)));
      if (accepted.ok !== true && !['accepted', 'duplicate', 'duplicate_pending'].includes(text(accepted.status))) {
        const error = new Error(text(accepted.errorCode, 'HANDSHAKE_TRANSPORT_UNAVAILABLE')); error.detail = text(accepted.error || accepted.message); throw error;
      }
      pending.set(requestId, { intent, operation, path, body, at: now() });
      return requestId;
    }
    function failFor(intent, error) {
      const base = text(error && error.message, 'HANDSHAKE_TRANSPORT_UNAVAILABLE');
      const code = base.startsWith('HANDSHAKE_') || base.startsWith('GITHUB_') || base.startsWith('HOST_') ? base
        : intent.includes('request-write') ? 'HANDSHAKE_REQUEST_WRITE_FAILED'
          : intent.includes('request-read') ? 'HANDSHAKE_REQUEST_READ_FAILED'
            : intent.includes('response-write') ? 'HANDSHAKE_RESPONSE_WRITE_FAILED' : 'HANDSHAKE_RESPONSE_READ_FAILED';
      return record({ state: 'error', statusCode: code, lastErrorCode: code, lastErrorAt: now(), lastErrorDetail: text(error && (error.detail || error.message), code) },
        { state: 'error', statusCode: code, operation: intent, direction: intent.includes('computer') ? 'computer' : 'vehicle', detail: text(error && (error.detail || error.message), code) });
    }
    function availabilityFailure(config, device) {
      if (config.explicitlyDisabled === true) return 'HANDSHAKE_EXPLICITLY_DISABLED';
      if (config.hostAvailable !== true) return 'HANDSHAKE_HOST_API_MISSING';
      if (config.configured !== true) return 'HANDSHAKE_CONFIGURATION_MISSING';
      if (!validIdentity(device.installationId)) return 'HANDSHAKE_INSTALLATION_ID_MISSING';
      if (!['vehicle_189', 'computer'].includes(device.role)) return 'HANDSHAKE_ROLE_UNSUPPORTED';
      return '';
    }
    function canRun() {
      const config = configuration(); const device = identity();
      const failureCode = availabilityFailure(config, device);
      if (failureCode) {
        if (failureCode === 'HANDSHAKE_EXPLICITLY_DISABLED') {
          record({ state: 'disabled', statusCode: failureCode, lastErrorCode: '', lastErrorDetail: '' },
            { state: 'disabled', statusCode: failureCode, operation: 'availability-check', role: device.role });
          return null;
        }
        record({ state: 'error', statusCode: failureCode, lastErrorCode: failureCode, lastErrorAt: now(), lastErrorDetail: 'Handskakningen kunde inte starta med verifierad host, konfiguration, roll och enhetsidentitet.' },
          { state: 'error', statusCode: failureCode, operation: 'availability-check', role: device.role });
        return null;
      }
      return { config, device, paths: paths(config.syncRoot) };
    }
    function vehicleRequest() {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      const sequence = state.latestSequence + 1;
      const body = { schemaVersion: 1, protocol: PROTOCOL, vehicleId: '189', senderRole: 'vehicle_189', senderInstallationId: ready.device.installationId,
        sequence, sentAt: now(), packageVersion: PACKAGE_VERSION };
      try {
        const requestId = enqueue('vehicle-request-write', 'PUT', ready.paths.vehicle, JSON.stringify(body));
        record({ latestSequence: sequence, lastRequestAt: body.sentAt, state: 'waiting_for_reply', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', lastErrorCode: '', lastErrorDetail: '' },
          { state: 'waiting', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', operation: 'vehicle-request-write', direction: '189→dator', sequence });
        return { ok: true, requestId, sequence };
      } catch (error) { failFor('vehicle-request-write', error); return { ok: false, status: state.statusCode }; }
    }
    function vehicleReadResponse() {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      try { return { ok: true, requestId: enqueue('vehicle-response-read', 'GET', ready.paths.computer) }; }
      catch (error) { failFor('vehicle-response-read', error); return { ok: false, status: state.statusCode }; }
    }
    function computerReadRequest() {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      try { return { ok: true, requestId: enqueue('computer-request-read', 'GET', ready.paths.vehicle) }; }
      catch (error) { failFor('computer-request-read', error); return { ok: false, status: state.statusCode }; }
    }
    function computerWriteResponse(request) {
      const ready = canRun(); if (!ready) return { ok: false, status: state.statusCode };
      if (Number(request.sequence) === Number(state.lastComputerResponseSequence)) return { ok: true, duplicate: true };
      const body = { schemaVersion: 1, protocol: PROTOCOL, vehicleId: '189', responderRole: 'computer', responderInstallationId: ready.device.installationId,
        replyToSequence: Number(request.sequence), requestSeenAt: now(), respondedAt: now(), packageVersion: PACKAGE_VERSION };
      try {
        const requestId = enqueue('computer-response-write', 'PUT', ready.paths.computer, JSON.stringify(body));
        record({ lastComputerResponseSequence: body.replyToSequence, lastRequestSeenAt: body.requestSeenAt, lastResponseAt: body.respondedAt, peerInstallationId: request.senderInstallationId,
          state: 'ok', statusCode: 'HANDSHAKE_OK', lastSuccessAt: now(), lastErrorCode: '', lastErrorDetail: '' },
          { state: 'ok', statusCode: 'HANDSHAKE_OK', operation: 'computer-response-write', direction: 'dator→189', sequence: Number(request.sequence), replyToSequence: body.replyToSequence });
        return { ok: true, requestId };
      } catch (error) { failFor('computer-response-write', error); return { ok: false, status: state.statusCode }; }
    }
    function normalNoPeer() {
      const requestAge = state.lastRequestAt ? Date.now() - Date.parse(state.lastRequestAt) : Infinity;
      const code = state.latestSequence > state.latestReplyToSequence && requestAge < PRESENCE_TIMEOUT_MS ? 'HANDSHAKE_WAITING_FOR_REPLY' : 'HANDSHAKE_NO_PEER_PRESENT';
      return record({ state: code === 'HANDSHAKE_WAITING_FOR_REPLY' ? 'waiting_for_reply' : 'no_peer_present', statusCode: code, lastErrorCode: '', lastErrorDetail: '' },
        { state: 'normal', statusCode: code, operation: 'presence-check', sequence: state.latestSequence, replyToSequence: state.latestReplyToSequence });
    }
    function handleResult(requestId) {
      const pendingItem = pending.get(text(requestId)); if (!pendingItem) return false;
      pending.delete(text(requestId));
      const host = environment.host(); let result = {};
      try { result = resultObject(host && typeof host.getSyncRequestStatus === 'function' ? host.getSyncRequestStatus(requestId) : {}); }
      catch (error) { failFor(pendingItem.intent, error); return true; }
      const status = text(result.status);
      const body = text(result.body);
      if (!['succeeded', 'success', 'completed'].includes(status)) {
        if ((Number(result.httpStatus) === 404 || !body) && pendingItem.operation === 'GET') { normalNoPeer(); if (pendingItem.intent === 'vehicle-response-read') vehicleRequest(); return true; }
        const error = new Error(text(result.errorCode, 'HANDSHAKE_TRANSPORT_UNAVAILABLE')); error.detail = text(result.error || result.message || `HTTP ${Number(result.httpStatus) || 0}`); failFor(pendingItem.intent, error); return true;
      }
      try {
        if (pendingItem.intent === 'computer-request-read') {
          if (!body) { normalNoPeer(); return true; }
          const request = validateVehicleRequest(parse(body, null));
          record({ latestVehicleSequence: request.sequence, lastRequestSeenAt: now(), lastVehicleRequestAt: request.sentAt,
            lastVehicleHasActiveJob: null, peerInstallationId: request.senderInstallationId },
            { state: 'received', statusCode: 'HANDSHAKE_OK', operation: 'computer-request-read', direction: '189→dator',
              sequence: request.sequence });
          computerWriteResponse(request); return true;
        }
        if (pendingItem.intent === 'vehicle-response-read') {
          if (!body) { normalNoPeer(); vehicleRequest(); return true; }
          const response = validateComputerResponse(parse(body, null));
          if (response.replyToSequence < state.latestSequence) { record({ statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', state: 'waiting_for_reply' }, { state: 'normal', statusCode: 'HANDSHAKE_WAITING_FOR_REPLY', operation: 'vehicle-response-read', replyToSequence: response.replyToSequence, sequence: state.latestSequence, detail: 'Gammalt svar ignorerades.' }); return true; }
          if (response.replyToSequence > state.latestSequence) throw new Error('HANDSHAKE_WRONG_SEQUENCE');
          record({ latestReplyToSequence: response.replyToSequence, lastValidReplyAt: now(), lastResponseAt: response.respondedAt, peerInstallationId: response.responderInstallationId,
            state: 'ok', statusCode: 'HANDSHAKE_OK', lastSuccessAt: now(), lastErrorCode: '', lastErrorDetail: '' },
            { state: 'ok', statusCode: 'HANDSHAKE_OK', operation: 'vehicle-response-read', direction: 'dator→189', sequence: state.latestSequence, replyToSequence: response.replyToSequence });
          vehicleRequest(); return true;
        }
        if (pendingItem.intent === 'vehicle-request-write') return true;
        return true;
      } catch (error) { failFor(pendingItem.intent, error); return true; }
    }
    function tick(reason = 'timer') {
      const device = identity();
      if (!['vehicle_189', 'computer'].includes(device.role)) {
        canRun();
        return { ok: false, status: state.statusCode, reason };
      }
      if (device.role === 'vehicle_189') return state.latestSequence > 0 ? vehicleReadResponse() : vehicleRequest();
      if (device.role === 'computer') return computerReadRequest();
      return { ok: false, status: state.statusCode, reason };
    }
    function status() { return clone(state); }
    return Object.freeze({ tick, handleResult, status, paths, validateVehicleRequest, validateComputerResponse, intervalMs: INTERVAL_MS, presenceTimeoutMs: PRESENCE_TIMEOUT_MS });
  }
  window.StadslassDriftsyncHandshake = Object.freeze({ PACKAGE_VERSION, PROTOCOL, INTERVAL_MS, PRESENCE_TIMEOUT_MS, paths, validateVehicleRequest, validateComputerResponse, normalizeState, create });
})();
