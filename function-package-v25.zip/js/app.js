(() => {
  'use strict';

  const PACKAGE_VERSION = 25;
  const JOB_MODEL_VERSION = 2;
  const MINIMUM_HOST_VERSION = 5;
  const SETTINGS_STORE = 'settings';
  const QUEUE_STORE = 'queue';
  const ACTIVE_JOB_STORE = 'activeJob';
  const HISTORY_STORE = 'history';
  const SYNC_OUTBOX_STORE = 'syncOutbox';
  const UI_SETTINGS_KEY = 'uiPreferencesV1';
  const PAGE_TITLES = Object.freeze({ home: 'Start', queue: 'Kö', active: 'Aktivt jobb', today: 'Idag', history: 'Historik', trash: 'Papperskorg', statistics: 'Sammanställning', sync: 'Överföring', settings: 'Inställningar' });
  const ACTIVE_STATUSES = Object.freeze(['active', 'paused', 'completing']);
  const ACTIVE_PHASES = Object.freeze(['loading', 'transport', 'unloading', 'returning', 'return_unloading', 'other_activity']);
  const watchdog = window.StadslassWatchdog || null;
  const syncProtocol = window.StadslassSyncProtocol || null;
  const registries = window.StadslassRegistries || null;
  const jobTypeItems = registries && registries.jobTypes && Array.isArray(registries.jobTypes.items) ? registries.jobTypes.items : [];
  const placeItems = registries && registries.places && Array.isArray(registries.places.items) ? registries.places.items : [];
  const materialConditionalRules = registries && registries.jobTypes && Array.isArray(registries.jobTypes.conditionalRules) ? registries.jobTypes.conditionalRules : [];

  let hostInfo = null;
  let settingsDocument = {};
  let queueDocument = [];
  let queueLoaded = false;
  let pendingQueueDeleteId = '';
  let editingQueueId = '';
  let activeJobDocument = {};
  let activeJobLoaded = false;
  let pendingActiveReset = false;
  let pendingActiveComplete = false;
  let pendingWeightlessCompletion = false;
  let historyDocument = [];
  let historyLoaded = false;
  let pendingHistoryTrashId = '';
  let pendingTrashPermanentDeleteId = '';
  let syncOutboxDocument = [];
  let syncOutboxLoaded = false;
  let validatedInboundTransfer = null;
  let updatePollTimer = null;

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function parseObject(raw, fallback = {}) {
    try {
      const value = JSON.parse(raw);
      return isPlainObject(value) ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }


  const jobModel = window.StadslassJobModel || null;
  const findJobTypeById = (...args) => jobModel.findJobTypeById(...args);
  const findPlaceById = (...args) => jobModel.findPlaceById(...args);
  const deriveMaterial = (...args) => jobModel.deriveMaterial(...args);
  const stableJobId = (...args) => jobModel.stableJobId(...args);
  const normalizeJobRecord = (...args) => jobModel.normalizeJobRecord(...args);
  const isOtherActivityJobType = (...args) => jobModel.isOtherActivityJobType(...args);

  function isOtherActivity(documentValue) {
    return isPlainObject(documentValue) && isOtherActivityJobType(text(documentValue.jobTypeId));
  }

  function validateRegistries() {
    if (!jobModel) throw new Error('Uppdragsmodellens kodmodul saknas.');
    const result = jobModel.validateRegistries();
    watchdog.step('runtime.registry.validated', `${result.jobTypeCount} jobbtyper och ${result.placeCount} platser verifierades.`);
  }

  function populateSelect(selectId, items, emptyLabel, role = '') {
    const select = byId(selectId);
    select.replaceChildren();
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = emptyLabel;
    select.appendChild(empty);
    items.filter((item) => !role || !Array.isArray(item.roles) || item.roles.includes(role)).forEach((item) => {
      const option = document.createElement('option');
      option.value = text(item.id);
      option.textContent = text(item.name);
      select.appendChild(option);
    });
  }

  function populateRegistryForms() {
    populateSelect('job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('job-from', placeItems, 'Välj Från', 'from');
    populateSelect('job-destination', placeItems, 'Välj Till', 'destination');
    populateSelect('job-return', placeItems, 'Ingen returplats', 'return');
    populateSelect('active-job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('active-job-from', placeItems, 'Välj Från', 'from');
    populateSelect('active-job-destination', placeItems, 'Välj Till', 'destination');
    populateSelect('active-job-return', placeItems, 'Ingen returplats', 'return');
  }

  function placesForJobType(jobTypeId) {
    if (text(jobTypeId) === 'JT-1010') {
      return placeItems.filter((item) => item.category === 'badplats' || ['PL-1001', 'PL-1005', 'PL-1007'].includes(text(item.id)));
    }
    return placeItems.filter((item) => item.category !== 'badplats');
  }

  function refreshPlaceFormsForJobType(prefix) {
    const jobTypeId = byId(`${prefix}job-type`).value;
    const allowed = placesForJobType(jobTypeId);
    const ids = [`${prefix}job-from`, `${prefix}job-destination`, `${prefix}job-return`];
    const values = ids.map((id) => byId(id).value);
    populateSelect(ids[0], allowed, 'Välj Från', 'from');
    populateSelect(ids[1], allowed, 'Välj Till', 'destination');
    populateSelect(ids[2], allowed, 'Ingen returplats', 'return');
    ids.forEach((id, index) => {
      if (Array.from(byId(id).options).some((option) => option.value === values[index])) byId(id).value = values[index];
    });
  }

  function applySuggestedDestination(prefix) {
    const jobTypeId = byId(`${prefix}job-type`).value;
    const fromPlaceId = byId(`${prefix}job-from`).value;
    const destination = byId(`${prefix}job-destination`);
    const suggested = jobModel.suggestedDestination(jobTypeId, fromPlaceId);
    if (suggested && !destination.value) destination.value = suggested;
  }

  function updateMaterialPanel(prefix) {
    const material = deriveMaterial(byId(`${prefix}job-type`).value, byId(`${prefix}job-from`).value, byId(`${prefix}job-destination`).value);
    byId(`${prefix}job-material-code`).textContent = material.code || 'Ej aktuell';
    byId(`${prefix}job-material-facility`).textContent = material.facilityPlaceName || 'Ej fastställd';
  }

  function migrateArrayStore(storeName, value, detail) {
    const normalized = value.map((item, index) => normalizeJobRecord(item, `${storeName}-${index}`));
    if (JSON.stringify(normalized) === JSON.stringify(value)) return normalized;
    const saved = window.StadslassHost.writeStore(storeName, JSON.stringify(normalized));
    watchdog.step(saved ? `runtime.store.${storeName}.migrated` : `runtime.store.${storeName}.migration-pending`, saved ? detail : 'Migreringen kunde inte skrivas; ursprungsdata är orörd och används i minnet.', saved ? 'info' : 'warning');
    return normalized;
  }

  function migrateObjectStore(storeName, value, detail) {
    if (!isPlainObject(value) || Object.keys(value).length === 0) return value;
    const normalized = normalizeJobRecord(value, storeName);
    if (JSON.stringify(normalized) === JSON.stringify(value)) return normalized;
    const saved = window.StadslassHost.writeStore(storeName, JSON.stringify(normalized));
    watchdog.step(saved ? `runtime.store.${storeName}.migrated` : `runtime.store.${storeName}.migration-pending`, saved ? detail : 'Migreringen kunde inte skrivas; ursprungsdata är orörd och används i minnet.', saved ? 'info' : 'warning');
    return normalized;
  }

  function readSettingsDocument() {
    watchdog.step('runtime.store.settings.read', 'Inställningslagret läses.');
    const raw = window.StadslassHost.readStore(SETTINGS_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Inställningslagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Inställningslagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!isPlainObject(value)) {
      throw new Error('Inställningslagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.settings.validated', 'Inställningslagrets JSON-schema är användbart.');
    return value;
  }

  function readQueueDocument() {
    watchdog.step('runtime.store.queue.read', 'Kölagret läses först när kövyn öppnas.');
    const raw = window.StadslassHost.readStore(QUEUE_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Kölagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Kölagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Kölagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.queue.validated', 'Kölagret är en JSON-lista.');
    return migrateArrayStore(QUEUE_STORE, value, 'Kölagret migrerades till gemensam uppdragsmodell v2.');
  }

  function readActiveJobDocument() {
    watchdog.step('runtime.store.active.read', 'Aktivt-jobb-lagret läses först när vyn öppnas.');
    const raw = window.StadslassHost.readStore(ACTIVE_JOB_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Lagret för aktivt jobb kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Lagret för aktivt jobb innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!isPlainObject(value)) {
      throw new Error('Lagret för aktivt jobb har fel format och har inte ändrats.');
    }
    if (Object.keys(value).length === 0) {
      watchdog.step('runtime.store.active.validated', 'Aktivt-jobb-lagret är tomt och giltigt.');
      return value;
    }
    const id = text(value.id);
    const status = text(value.status);
    const phase = text(value.phase);
    if (!id || !ACTIVE_STATUSES.includes(status) || !ACTIVE_PHASES.includes(phase)) {
      throw new Error('Lagret för aktivt jobb har en okänd struktur och har inte ändrats.');
    }
    watchdog.step('runtime.store.active.validated', 'Aktivt-jobb-lagrets grundschema är giltigt.');
    return migrateObjectStore(ACTIVE_JOB_STORE, value, 'Aktivt jobb migrerades till gemensam uppdragsmodell v2.');
  }

  function readHistoryDocument() {
    watchdog.step('runtime.store.history.read', 'Historiklagret läses först när Idag, Historik eller avslut används.');
    const raw = window.StadslassHost.readStore(HISTORY_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Historiklagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Historiklagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Historiklagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.history.validated', 'Historiklagret är en JSON-lista.');
    return migrateArrayStore(HISTORY_STORE, value, 'Historiklagret migrerades till gemensam uppdragsmodell v2.');
  }

  function readSyncOutboxDocument() {
    watchdog.step('runtime.store.syncOutbox.read', 'Synkutkö läses först när Överföring eller en uttrycklig överföringsåtgärd används.');
    const raw = window.StadslassHost.readStore(SYNC_OUTBOX_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Synkutkö kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Synkutkö innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Synkutkö har fel format och har inte ändrats.');
    }
    const valid = value.every((entry) => isPlainObject(entry) && text(entry.id));
    if (!valid) {
      throw new Error('Synkutkö innehåller en okänd post och har inte ändrats.');
    }
    watchdog.step('runtime.store.syncOutbox.validated', 'Synkutkö är en giltig JSON-lista.');
    return value;
  }

  function normalizedUiPreferences(documentValue) {
    const value = parseObject(JSON.stringify(documentValue[UI_SETTINGS_KEY] || {}), {});
    return {
      largeText: value.largeText === true,
      showTechnicalInfo: value.showTechnicalInfo === true
    };
  }

  function applyUiPreferences(preferences) {
    document.documentElement.classList.toggle('large-text', preferences.largeText);
    byId('large-text').checked = preferences.largeText;
    byId('show-technical').checked = preferences.showTechnicalInfo;
    byId('technical-panel').hidden = !preferences.showTechnicalInfo;
  }

  function showStatus(elementId, message, isError = false) {
    const element = byId(elementId);
    element.textContent = message;
    element.classList.toggle('is-error', isError);
  }

  function currentScrollY() {
    return Math.max(0, Number(window.scrollY) || Number(document.documentElement.scrollTop) || 0);
  }

  function preserveScrollAfterRender(previousScrollY) {
    const safeScrollY = Math.max(0, Number(previousScrollY) || 0);
    window.requestAnimationFrame(() => {
      window.scrollTo(0, safeScrollY);
      window.requestAnimationFrame(() => window.scrollTo(0, safeScrollY));
    });
  }

  function revealInlineControl(selector, previousScrollY) {
    const safeScrollY = Math.max(0, Number(previousScrollY) || 0);
    window.requestAnimationFrame(() => {
      window.scrollTo(0, safeScrollY);
      window.requestAnimationFrame(() => {
        const element = document.querySelector(selector);
        if (!element || element.hidden) return;
        const nav = document.querySelector('.bottom-nav');
        const navRect = nav ? nav.getBoundingClientRect() : { height: 0 };
        const visibleBottom = Math.max(0, window.innerHeight - Math.max(0, Number(navRect.height) || 0) - 12);
        const rect = element.getBoundingClientRect();
        const currentY = currentScrollY();
        const requiredDown = Math.max(0, rect.bottom - visibleBottom);
        window.scrollTo(0, Math.max(safeScrollY, currentY + requiredDown));
      });
    });
  }

  function showView(target) {
    if (!Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) {
      return;
    }
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.hidden = view.dataset.view !== target;
    });
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      const active = button.dataset.target === target;
      button.classList.toggle('is-active', active);
      if (active) {
        button.setAttribute('aria-current', 'page');
      } else {
        button.removeAttribute('aria-current');
      }
    });
    byId('page-title').textContent = PAGE_TITLES[target];
    byId('main-content').focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function isMobileRole() {
    return hostInfo && hostInfo.role === 'mobile';
  }

  function isVehicleRole() {
    return hostInfo && hostInfo.role === 'vehicle_189';
  }

  function canUseQueue() {
    return isMobileRole() || isVehicleRole();
  }

  function canUseActiveJob() {
    return isVehicleRole();
  }

  function renderQueueRoleCopy() {
    if (isMobileRole()) {
      byId('queue-heading').textContent = 'Mobilens planeringskö';
      byId('queue-summary-text').textContent = 'Planeringskön laddas endast i denna vy och sparas lokalt på mobilen.';
      byId('queue-form-heading').textContent = 'Lägg till planerat uppdrag';
      byId('queue-form-intro').textContent = 'Planera lokalt och förbered sedan en kontrollerad överföring till 189. Uppdraget lämnar inte mobilen utan en uttrycklig åtgärd.';
      byId('queue-submit-button').textContent = 'Lägg i planeringskö';
      byId('queue-list-heading').textContent = 'Planerad kö';
    } else if (isVehicleRole()) {
      byId('queue-heading').textContent = '189:s operativa kö';
      byId('queue-summary-text').textContent = 'Den operativa kön är lokal på 189 och hålls åtskild från Mobilens planeringskö.';
      byId('queue-form-heading').textContent = 'Lägg till mottaget testuppdrag';
      byId('queue-form-intro').textContent = 'Manuell lokal inmatning finns kvar. Överföringar från Mobil importeras separat efter kontroll och bekräftelse.';
      byId('queue-submit-button').textContent = 'Lägg i operativ kö';
      byId('queue-list-heading').textContent = 'Operativ kö';
    }
  }

  function applyRoleBoundaries() {
    const queueAllowed = canUseQueue();
    const activeAllowed = canUseActiveJob();
    byId('open-queue').hidden = !queueAllowed;
    byId('open-active-job').hidden = !activeAllowed;
    byId('open-today').hidden = !activeAllowed;
    byId('open-history').hidden = !activeAllowed;
    byId('open-trash').hidden = !activeAllowed;
    byId('open-statistics').hidden = !activeAllowed;
    byId('open-sync').hidden = false;
    document.querySelector('.nav-button[data-target="queue"]').hidden = !queueAllowed;
    document.querySelector('.nav-button[data-target="active"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="today"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="history"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="trash"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="statistics"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="sync"]').hidden = false;
    renderQueueRoleCopy();
    document.documentElement.classList.toggle('vehicle-role', isVehicleRole());

    if (isMobileRole()) {
      byId('home-heading').textContent = 'Planeringskö på Mobil';
      byId('home-module-summary').textContent = 'Mobilens planeringskö kan nu skapa kontrollerade överföringar till 189 utan att tyst ändra någon mottagande kö.';
      byId('home-store-title').textContent = 'Inställningar + planeringskö + synkutkö';
      byId('home-store-text').textContent = 'Planeringskö och synkutkö läses var för sig först när respektive funktion används. Aktivt jobb läses inte på Mobil.';
      byId('role-boundary-note').textContent = 'Aktivt jobb på 189 är avsiktligt dolt och blockerat på denna roll.';
      byId('active-role-note').textContent = 'Aktivt jobb är blockerat på Mobil i detta steg.';
    } else if (isVehicleRole()) {
      byId('home-heading').textContent = 'Operativ kö och aktivt jobb på 189';
      byId('home-module-summary').textContent = '189 kan validera en överföring från Mobil, bekräfta import till operativ kö och lämna ett mottagningskvitto.';
      byId('home-store-title').textContent = 'Inställningar + kö + aktivt jobb + historik + synkutkö';
      byId('home-store-text').textContent = 'Kö, Aktivt jobb, Historik och synkutkö läses var för sig först när respektive funktion används.';
      byId('role-boundary-note').textContent = 'Mobilens planeringskö läses inte. Den visade kön är 189:s lokala operativa kö.';
      byId('active-role-note').textContent = 'Aktivt jobb är tillgängligt på denna 189 / Surfplatta.';
    }
  }

  function activateView(target) {
    if (target === 'queue' && !canUseQueue()) {
      showView('home');
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if ((target === 'active' || target === 'today' || target === 'history' || target === 'trash' || target === 'statistics') && !canUseActiveJob()) {
      showView('home');
      showStatus('role-boundary-note', 'Driftvyn är blockerad på denna enhetsroll.', true);
      return;
    }
    showView(target);
    if (target === 'queue') {
      loadQueueIfNeeded();
    } else if (target === 'active') {
      loadActiveJobIfNeeded();
    } else if (target === 'today' || target === 'history' || target === 'trash' || target === 'statistics') {
      loadHistoryIfNeeded(target);
    } else if (target === 'sync') {
      loadSyncOutboxIfNeeded();
      renderSyncRoleView();
    }
  }

  function renderHostInfo() {
    const role = hostInfo.roleLabel || hostInfo.role || 'Okänd roll';
    byId('role-chip').textContent = role;
    byId('host-version').textContent = `${hostInfo.hostVersionName} (${hostInfo.hostVersionCode})`;
    byId('package-version').textContent = String(hostInfo.packageVersion);
    byId('technical-role').textContent = role;
    byId('device-id').textContent = hostInfo.deviceId || 'Saknas';
    byId('watchdog-state').textContent = watchdog.getStatus();
    byId('watchdog-phase').textContent = watchdog.getLastPhase();
  }

  function renderPreservedTestValue() {
    const testValue = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    byId('module-test-value').textContent = String(testValue);
  }

  function saveSettings(event) {
    event.preventDefault();
    const nextPreferences = {
      largeText: byId('large-text').checked,
      showTechnicalInfo: byId('show-technical').checked
    };
    const nextDocument = {
      ...settingsDocument,
      [UI_SETTINGS_KEY]: nextPreferences,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('save-status', window.StadslassHost.getLastError() || 'Inställningarna kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    applyUiPreferences(nextPreferences);
    showStatus('save-status', 'Inställningarna är sparade.');
  }

  function incrementPreservedTestValue() {
    const current = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    const nextDocument = { ...settingsDocument, moduleTestValue: current + 1 };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('storage-status', window.StadslassHost.getLastError() || 'Testvärdet kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    renderPreservedTestValue();
    showStatus('storage-status', 'Testvärdet är sparat i inställningslagret.');
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return '';
    }
    const parts = value.split('-').map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return new Intl.DateTimeFormat('sv-SE', { year: 'numeric', month: 'short', day: 'numeric' }).format(date);
  }

  function formatTimestamp(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return 'Saknas';
    }
    return new Intl.DateTimeFormat('sv-SE', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    }).format(date);
  }

  function createLocalId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(random);
    } else {
      random[0] = Math.floor(Math.random() * 0xffffffff);
      random[1] = Math.floor(Math.random() * 0xffffffff);
    }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function displayQueueItem(item, index) {
    const source = normalizeJobRecord(isPlainObject(item) ? item : {}, `queue-display-${index}`);
    return {
      id: text(source.id, `legacy-${index}`),
      jobId: text(source.jobId, text(source.id, `legacy-${index}`)),
      jobTypeId: text(source.jobTypeId),
      jobType: text(source.jobTypeName, text(source.jobType, 'Uppdrag')),
      otherActivity: isOtherActivity(source),
      fromPlaceId: text(source.fromPlaceId),
      from: text(source.fromPlaceName, text(source.from, 'Från saknas')),
      destinationPlaceId: text(source.destinationPlaceId),
      destination: text(source.destinationPlaceName, text(source.destination, 'Till saknas')),
      returnPlaceId: text(source.returnPlaceId),
      returnPlaceName: text(source.returnPlaceName),
      returnRequired: source.returnRequired === true || Boolean(text(source.returnPlaceId)),
      material: isPlainObject(source.material) ? source.material : {},
      note: text(source.note),
      plannedDate: text(source.plannedDate),
      plannedTime: text(source.plannedTime),
      source: text(source.source),
      multiLoad: source.multiLoad === true,
      modelVersion: Number(source.jobModelVersion) || 1,
      pausedFromActive: source.pausedFromActive === true && text(source.status) === 'paused',
      pausedPhase: text(source.phase)
    };
  }

  function queueMetaChip(label, extraClass = '') {
    const chip = document.createElement('span');
    chip.className = `meta-chip${extraClass ? ` ${extraClass}` : ''}`;
    chip.textContent = label;
    return chip;
  }

  function queueItemIndexById(id) {
    return queueDocument.findIndex((candidate, index) => displayQueueItem(candidate, index).id === id);
  }

  function queueItemById(id) {
    const index = queueItemIndexById(id);
    return index >= 0 ? { index, raw: queueDocument[index], display: displayQueueItem(queueDocument[index], index) } : null;
  }

  function activeJobMatchesQueueItem(id) {
    return activeJobLoaded && activeJobExists() && text(activeJobDocument.sourceQueueItemId) === id;
  }

  function renderQueue() {
    const list = byId('queue-list');
    list.replaceChildren();
    byId('queue-count').textContent = String(queueDocument.length);

    if (queueDocument.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Kön är tom.';
      list.appendChild(empty);
      return;
    }

    const today = localDateKey(new Date());
    queueDocument.forEach((rawItem, index) => {
      const item = displayQueueItem(rawItem, index);
      const card = document.createElement('article');
      card.className = 'queue-card';
      card.dataset.queueId = item.id;

      const header = document.createElement('div');
      header.className = 'queue-card-header';
      const heading = document.createElement('h3');
      heading.textContent = item.jobType;
      header.appendChild(heading);
      card.appendChild(header);

      const route = document.createElement('p');
      route.className = 'queue-route';
      route.textContent = item.otherActivity ? 'Användarens tidsrapportering' : `${item.from} → ${item.destination}`;
      card.appendChild(route);

      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      if (item.plannedDate) {
        meta.appendChild(queueMetaChip(formatDate(item.plannedDate) || item.plannedDate));
        if (item.plannedDate > today) {
          meta.appendChild(queueMetaChip('Framtida uppdrag', 'future'));
        }
      } else {
        meta.appendChild(queueMetaChip('Datum saknas'));
      }
      if (item.plannedTime) {
        meta.appendChild(queueMetaChip(`Kl. ${item.plannedTime}`));
      }
      meta.appendChild(queueMetaChip(`Modell v${item.modelVersion}`, 'model-chip'));
      if (item.pausedFromActive) meta.appendChild(queueMetaChip(`Pausat · ${phaseLabel(item.pausedPhase)}`, 'paused-chip'));
      if (item.returnRequired) meta.appendChild(queueMetaChip(`Retur: ${item.returnPlaceName || item.from}`));
      if (item.multiLoad) meta.appendChild(queueMetaChip('Flerlass', 'model-chip'));
      const materialText = [text(item.material.code), text(item.material.facilityPlaceName)].filter(Boolean).join(' · ');
      if (materialText) meta.appendChild(queueMetaChip(`Mtrl: ${materialText}`));
      const outgoing = isMobileRole() ? latestOutgoingForJob(item.jobId) : null;
      if (outgoing) {
        meta.appendChild(queueMetaChip(outgoing.state === 'acknowledged' ? 'Mottaget på 189' : 'Överföring förberedd', outgoing.state === 'acknowledged' ? 'transfer-state-acknowledged' : 'transfer-state-prepared'));
      }
      if (isVehicleRole() && isPlainObject(rawItem.sync) && text(rawItem.sync.transferId)) {
        meta.appendChild(queueMetaChip('Överförd från Mobil', 'transfer-state-acknowledged'));
      }
      card.appendChild(meta);
      if (item.note) {
        const note = document.createElement('p');
        note.className = 'queue-note';
        note.textContent = item.note;
        card.appendChild(note);
      }

      if (isMobileRole()) {
        const transferButton = document.createElement('button');
        transferButton.type = 'button';
        transferButton.className = 'primary-button queue-start-button';
        transferButton.dataset.prepareQueueTransfer = item.id;
        transferButton.textContent = outgoing ? 'Visa överföring' : 'Förbered överföring till 189';
        card.appendChild(transferButton);
      }

      if (isVehicleRole()) {
        const startButton = document.createElement('button');
        startButton.type = 'button';
        startButton.className = 'primary-button queue-start-button';
        startButton.dataset.startQueueItem = item.id;
        if (activeJobMatchesQueueItem(item.id)) {
          startButton.textContent = 'Slutför flytt till Aktivt jobb';
        } else if (activeJobLoaded && activeJobExists() && !(isOtherActivity(activeJobDocument) && !item.otherActivity && activeJobDocument.status !== 'completing')) {
          startButton.textContent = 'Aktivt jobb pågår';
          startButton.disabled = true;
        } else if (activeJobLoaded && isOtherActivity(activeJobDocument) && !item.otherActivity) {
          startButton.textContent = item.pausedFromActive ? 'Fortsätt – ÖV pausas automatiskt' : 'Starta – ÖV pausas automatiskt';
        } else {
          startButton.textContent = item.pausedFromActive ? 'Fortsätt uppdrag' : 'Starta som Aktivt jobb';
        }
        card.appendChild(startButton);
      }

      const editButton = document.createElement('button');
      editButton.type = 'button';
      editButton.className = 'secondary-button queue-edit-button';
      editButton.dataset.editQueueItem = item.id;
      editButton.textContent = 'Redigera uppdrag';
      card.appendChild(editButton);

      if (pendingQueueDeleteId === item.id) {
        const confirm = document.createElement('div');
        confirm.className = 'inline-confirm confirm-actions';
        const message = document.createElement('p');
        message.textContent = `Ta bort ${item.jobType}: ${item.otherActivity ? 'användarens tidsrapportering' : `${item.from} → ${item.destination}`} från kön? Åtgärden påverkar inte Aktivt jobb, Historik eller synkutkö.`;
        const accept = document.createElement('button');
        accept.type = 'button';
        accept.className = 'danger-button is-solid';
        accept.dataset.confirmQueueDelete = item.id;
        accept.textContent = 'Bekräfta borttagning';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.dataset.cancelQueueDelete = item.id;
        cancel.textContent = 'Avbryt';
        confirm.append(message, accept, cancel);
        card.appendChild(confirm);
      } else {
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'danger-button';
        remove.dataset.requestQueueDelete = item.id;
        remove.textContent = 'Ta bort från kö';
        card.appendChild(remove);
      }
      list.appendChild(card);
    });
  }

  function loadQueueIfNeeded() {
    if (!canUseQueue()) {
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (queueLoaded) {
      return;
    }
    try {
      queueDocument = readQueueDocument();
      queueLoaded = true;
      renderQueue();
      showStatus('queue-load-status', 'Kön är lokalt inläst.');
    } catch (error) {
      watchdog.step('runtime.store.queue.invalid', error.message || 'Kön kunde inte läsas.', 'warning');
      showStatus('queue-load-status', error.message || 'Kön kunde inte läsas.', true);
    }
  }

  function persistQueue(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('queue-form-status', window.StadslassHost.getLastError() || 'Kön kunde inte sparas.', true);
      return false;
    }
    queueDocument = nextDocument;
    queueLoaded = true;
    pendingQueueDeleteId = '';
    renderQueue();
    showStatus('queue-form-status', successMessage);
    return true;
  }

  function syncJobModeControls(scope, changedMode = '') {
    const prefix = scope === 'active' ? 'active-job-' : 'job-';
    const otherActivity = isOtherActivityJobType(byId(`${prefix}type`).value);
    const transportFields = byId(`${prefix}transport-fields`);
    const returnToggle = byId(`${prefix}return-required`);
    const multiToggle = byId(`${prefix}multi-load`);
    const returnWrap = byId(`${prefix}return-wrap`);
    const returnSelect = byId(`${prefix}return`);
    const fromSelect = byId(`${prefix}from`);
    const destinationSelect = byId(`${prefix}destination`);
    transportFields.hidden = otherActivity;
    fromSelect.required = !otherActivity;
    destinationSelect.required = !otherActivity;
    if (otherActivity) {
      fromSelect.value = '';
      destinationSelect.value = '';
      returnSelect.value = '';
      returnToggle.checked = false;
      multiToggle.checked = false;
    }
    if (changedMode === 'return' && returnToggle.checked) multiToggle.checked = false;
    if (changedMode === 'multi' && multiToggle.checked) returnToggle.checked = false;
    returnWrap.hidden = otherActivity || !returnToggle.checked;
    if (returnToggle.checked && !returnSelect.value && fromSelect.value) returnSelect.value = fromSelect.value;
  }

  function resetQueueForm() {
    editingQueueId = '';
    byId('queue-form').reset();
    byId('queue-form-heading').textContent = isVehicleRole() ? 'Lägg till mottaget testuppdrag' : 'Lägg till planerat uppdrag';
    byId('queue-submit-button').textContent = isVehicleRole() ? 'Lägg i operativ kö' : 'Lägg i planeringskö';
    byId('queue-cancel-edit').hidden = true;
    syncJobModeControls('queue');
    updateMaterialPanel('');
  }

  function editQueueItem(id) {
    if (!canUseQueue() || !queueLoaded) {
      showStatus('queue-form-status', 'Kön måste vara lokalt inläst innan ett uppdrag kan redigeras.', true);
      return;
    }
    const selected = queueItemById(id);
    if (!selected) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    if (isMobileRole()) {
      if (!loadSyncOutboxIfNeeded()) {
        showStatus('queue-form-status', 'Synkutkö kunde inte läsas. Uppdraget har inte öppnats för redigering eftersom dess överföringsstatus inte kan säkerställas.', true);
        return;
      }
      if (latestOutgoingForJob(selected.display.jobId)) {
        showStatus('queue-form-status', 'Uppdraget har redan förberetts eller kvitterats för överföring och kan därför inte redigeras. Överföringstexten ska fortsätta motsvara uppdraget som skickades.', true);
        return;
      }
    }
    const item = selected.display;
    editingQueueId = item.id;
    byId('job-type').value = item.jobTypeId;
    refreshPlaceFormsForJobType('');
    byId('job-from').value = item.fromPlaceId;
    byId('job-destination').value = item.destinationPlaceId;
    byId('job-return').value = item.returnPlaceId;
    byId('job-return-required').checked = item.returnRequired;
    byId('job-multi-load').checked = item.multiLoad;
    syncJobModeControls('queue');
    byId('job-note').value = item.note;
    byId('planned-date').value = item.plannedDate;
    byId('planned-time').value = item.plannedTime;
    byId('queue-form-heading').textContent = 'Redigera köuppdrag';
    byId('queue-submit-button').textContent = 'Spara ändringar';
    byId('queue-cancel-edit').hidden = false;
    updateMaterialPanel('');
    byId('queue-form-heading').scrollIntoView({ block: 'start' });
    showStatus('queue-form-status', 'Ändra uppgifterna och tryck Spara ändringar. Jobb-ID och okända fält bevaras.');
  }

  function cancelQueueEdit() {
    if (!editingQueueId) return;
    resetQueueForm();
    showStatus('queue-form-status', 'Redigeringen avbröts. Kön är oförändrad.');
  }

  function createQueueItem(event) {
    event.preventDefault();
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('queue-form-status', 'Kön måste kunna läsas innan ett uppdrag kan sparas.', true);
      return;
    }
    const jobType = findJobTypeById(byId('job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const fromPlace = otherActivity ? null : findPlaceById(byId('job-from').value);
    const destinationPlace = otherActivity ? null : findPlaceById(byId('job-destination').value);
    const returnRequired = !otherActivity && byId('job-return-required').checked;
    const returnPlace = returnRequired ? (findPlaceById(byId('job-return').value) || fromPlace) : null;
    if (!jobType || (!otherActivity && (!fromPlace || !destinationPlace))) {
      showStatus('queue-form-status', otherActivity ? 'Välj jobbtyp.' : 'Välj jobbtyp, Från och Till.', true);
      return;
    }
    const now = new Date().toISOString();
    const selected = editingQueueId ? queueItemById(editingQueueId) : null;
    if (editingQueueId && !selected) {
      showStatus('queue-form-status', 'Köposten som skulle redigeras finns inte längre. Kön är oförändrad.', true);
      return;
    }
    const jobId = selected ? selected.display.jobId : createLocalId('job');
    const material = deriveMaterial(jobType.id, text(fromPlace && fromPlace.id), text(destinationPlace && destinationPlace.id));
    const item = normalizeJobRecord({
      ...(selected ? selected.raw : {}),
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: selected ? selected.display.id : jobId,
      jobId,
      status: 'queued',
      source: isVehicleRole() ? 'manual-vehicle-received' : 'manual-mobile-planning',
      jobTypeId: jobType.id,
      jobTypeName: jobType.name,
      fromPlaceId: text(fromPlace && fromPlace.id),
      fromPlaceName: text(fromPlace && fromPlace.name),
      destinationPlaceId: text(destinationPlace && destinationPlace.id),
      destinationPlaceName: text(destinationPlace && destinationPlace.name),
      returnPlaceId: returnPlace ? returnPlace.id : '',
      returnPlaceName: returnPlace ? returnPlace.name : '',
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : byId('job-multi-load').checked,
      material,
      plannedDate: text(byId('planned-date').value),
      plannedTime: text(byId('planned-time').value),
      note: text(byId('job-note').value),
      createdAt: selected ? text(selected.raw.createdAt, now) : now,
      createdByPackageVersion: selected ? selected.raw.createdByPackageVersion : PACKAGE_VERSION,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: { ...(selected && isPlainObject(selected.raw.metadata) ? selected.raw.metadata : {}), createdRole: text(selected && selected.raw.metadata && selected.raw.metadata.createdRole, text(hostInfo.role)), createdRoleLabel: text(selected && selected.raw.metadata && selected.raw.metadata.createdRoleLabel, text(hostInfo.roleLabel)), createdDeviceId: text(selected && selected.raw.metadata && selected.raw.metadata.createdDeviceId, text(hostInfo.deviceId)), modelVersion: JOB_MODEL_VERSION }
    }, 'job');
    const successMessage = selected ? 'Ändringarna är sparade i den lokala kön.' : (isVehicleRole() ? 'Uppdraget är sparat i 189:s lokala operativa kö.' : 'Uppdraget är sparat i Mobilens lokala planeringskö.');
    const nextDocument = selected ? queueDocument.map((entry, index) => index === selected.index ? item : entry) : [...queueDocument, item];
    if (persistQueue(nextDocument, successMessage)) {
      resetQueueForm();
      showStatus('queue-form-status', successMessage);
    }
  }

  function requestQueueDelete(id) {
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded || queueItemIndexById(id) < 0) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    pendingQueueDeleteId = id;
    renderQueue();
    revealInlineControl('#queue-list .inline-confirm', previousScrollY);
    showStatus('queue-form-status', 'Bekräfta borttagningen eller avbryt.');
  }

  function cancelQueueDelete(id) {
    if (pendingQueueDeleteId !== id) {
      return;
    }
    const previousScrollY = currentScrollY();
    pendingQueueDeleteId = '';
    renderQueue();
    preserveScrollAfterRender(previousScrollY);
    showStatus('queue-form-status', 'Borttagningen avbröts. Kön är oförändrad.');
  }

  function confirmQueueDelete(id) {
    if (!canUseQueue() || pendingQueueDeleteId !== id) {
      showStatus('queue-form-status', 'Borttagningen kunde inte bekräftas och kön är oförändrad.', true);
      return;
    }
    const index = queueItemIndexById(id);
    if (index < 0) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    if (activeJobMatchesQueueItem(id)) {
      pendingQueueDeleteId = '';
      renderQueue();
      showStatus('queue-form-status', 'Köposten hör ihop med det aktiva jobbet och kan inte tas bort här. Aktivt jobb och kön är oförändrade.', true);
      return;
    }
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    persistQueue(nextDocument, 'Uppdraget är borttaget från kön.');
  }

  function removeQueueItemByIndex(index, successMessage) {
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    return persistQueue(nextDocument, successMessage);
  }

  function startQueueItem(id) {
    if (!isVehicleRole()) {
      showStatus('queue-form-status', 'Endast 189 / Surfplatta får starta ett uppdrag från den operativa kön.', true);
      return;
    }
    if (!queueLoaded) {
      loadQueueIfNeeded();
    }
    const selected = queueItemById(id);
    if (!queueLoaded || !selected) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    if (!activeJobLoaded) {
      loadActiveJobIfNeeded();
    }
    if (!activeJobLoaded) {
      showStatus('queue-form-status', 'Aktivt-jobb-lagret måste kunna läsas innan uppdraget startas.', true);
      return;
    }

    const item = selected.display;
    const now = new Date().toISOString();
    let otherActivityToPark = null;
    if (activeJobExists()) {
      if (text(activeJobDocument.sourceQueueItemId) === id) {
        if (removeQueueItemByIndex(selected.index, 'Köposten togs bort. Uppdraget var redan säkert sparat som Aktivt jobb.')) {
          activateView('active');
          showStatus('active-load-status', 'Uppdraget är aktivt och den kvarvarande köposten har städats bort.');
        }
      } else if (isOtherActivity(activeJobDocument) && !item.otherActivity && activeJobDocument.status !== 'completing') {
        otherActivityToPark = pauseOtherActivityAutomatically(activeJobDocument, now, item.jobId);
      } else {
        renderQueue();
        showStatus('queue-form-status', 'Ett annat aktivt jobb pågår. Köuppdraget har inte ändrats.', true);
        return;
      }
      if (!otherActivityToPark) return;
    }

    let nextActiveJob;
    if (item.pausedFromActive) {
      const {
        parkedOtherActivity: _staleParkedActivity,
        sourceQueueSnapshot: _previousQueueSnapshot,
        ...pausedSnapshot
      } = selected.raw;
      const pausedFrom = text(pausedSnapshot.pausedAt);
      const pausePeriods = Array.isArray(pausedSnapshot.pausePeriods) ? pausedSnapshot.pausePeriods.filter(isPlainObject) : [];
      const completedPause = pausedFrom ? { from: pausedFrom, to: now, mode: 'queued' } : null;
      const completedPauseMs = completedPause ? Math.max(0, new Date(now).getTime() - new Date(pausedFrom).getTime()) : 0;
      const resumedSegments = resumeWorkSegment(pausedSnapshot, now);
      nextActiveJob = normalizeJobRecord({
        ...pausedSnapshot,
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: item.jobId,
        jobId: item.jobId,
        status: 'active',
        pausedAt: '',
        pausedFromActive: false,
        resumedFromQueueAt: now,
        sourceQueueItemId: item.id,
        sourceQueueSnapshot: pausedSnapshot,
        ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
        pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
        pausedTotalMs: (Number(pausedSnapshot.pausedTotalMs) || 0) + completedPauseMs,
        workSegments: resumedSegments,
        continuationCount: Math.max(0, resumedSegments.length - 1),
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: appendActiveEvent(pausedSnapshot, 'job_resumed', now, 'queue-resume', { fromPausedQueue: true })
      }, 'active');
    } else {
      nextActiveJob = normalizeJobRecord({
        ...selected.raw,
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: item.jobId,
        jobId: item.jobId,
        status: 'active',
        phase: item.otherActivity ? 'other_activity' : 'loading',
        source: 'vehicle-queue',
        sourceQueueItemId: item.id,
        sourceQueueSnapshot: selected.raw,
        returnRequired: item.otherActivity ? false : item.returnRequired === true,
        multiLoad: item.otherActivity ? false : item.multiLoad === true,
        ...(item.otherActivity ? {} : {
          currentLoadNumber: 1,
          loadCycles: [{ loadNumber: 1, loadingStartedAt: now, outcome: 'open' }]
        }),
        ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
        startedAt: now,
        workSegments: [{ segmentNumber: 1, startedAt: now, endedAt: '', endReason: '', note: text(item.note) }],
        continuationCount: 0,
        updatedAt: now,
        createdByPackageVersion: PACKAGE_VERSION,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: [{ type: item.otherActivity ? 'other_activity_started_from_queue' : 'job_started_from_queue', at: now, source: 'vehicle-queue', packageVersion: PACKAGE_VERSION }]
      }, 'active');
    }

    const activeSaveMessage = item.pausedFromActive
      ? (otherActivityToPark ? 'ÖV pausades automatiskt och det pausade uppdraget fortsätter från sparad fas.' : 'Det pausade uppdraget fortsätter från sparad fas.')
      : (otherActivityToPark ? 'ÖV pausades automatiskt och köuppdraget sparades som Aktivt jobb.' : 'Köuppdraget sparades först som Aktivt jobb.');
    if (!persistActiveJob(nextActiveJob, activeSaveMessage)) {
      showStatus('queue-form-status', 'Aktivt jobb kunde inte sparas. Köposten är oförändrad.', true);
      return;
    }

    if (!removeQueueItemByIndex(selected.index, 'Uppdraget flyttades från 189:s operativa kö till Aktivt jobb.')) {
      renderQueue();
      showStatus('queue-form-status', 'Aktivt jobb är säkert sparat, men köposten kunde inte tas bort. Tryck på startknappen igen för att slutföra flytten.', true);
      return;
    }

    activateView('active');
    showStatus('active-load-status', item.pausedFromActive
      ? (otherActivityToPark ? 'Det pausade uppdraget fortsätter från sparad fas. ÖV är säkert automatiskt pausad bakom uppdraget.' : 'Det pausade uppdraget fortsätter från sparad fas.')
      : (otherActivityToPark ? 'Uppdraget startades från 189:s operativa kö. ÖV är säkert automatiskt pausad bakom uppdraget.' : 'Uppdraget startades från 189:s operativa kö.'));
  }

  function loadSyncOutboxIfNeeded() {
    if (syncOutboxLoaded) return true;
    try {
      syncOutboxDocument = readSyncOutboxDocument();
      syncOutboxLoaded = true;
      renderSyncRoleView();
      showStatus('sync-load-status', 'Synkutkö är lokalt inläst.');
      return true;
    } catch (error) {
      watchdog.step('runtime.store.syncOutbox.invalid', error.message || 'Synkutkö kunde inte läsas.', 'warning');
      showStatus('sync-load-status', error.message || 'Synkutkö kunde inte läsas.', true);
      return false;
    }
  }

  function persistSyncOutbox(nextDocument, statusElementId, successMessage) {
    const saved = window.StadslassHost.writeStore(SYNC_OUTBOX_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus(statusElementId, window.StadslassHost.getLastError() || 'Synkutkö kunde inte sparas.', true);
      return false;
    }
    syncOutboxDocument = nextDocument;
    syncOutboxLoaded = true;
    renderSyncRoleView();
    if (queueLoaded) renderQueue();
    showStatus(statusElementId, successMessage);
    return true;
  }

  function transferEntries() {
    return syncOutboxDocument.filter((entry) => isPlainObject(entry) && entry.kind === 'queue-transfer' && entry.direction === 'outgoing');
  }

  function receiptEntries() {
    return syncOutboxDocument.filter((entry) => isPlainObject(entry) && entry.kind === 'queue-receipt' && entry.direction === 'outgoing');
  }

  function latestOutgoingForJob(jobId) {
    if (!syncOutboxLoaded) return null;
    return transferEntries()
      .filter((entry) => Array.isArray(entry.jobIds) && entry.jobIds.includes(jobId))
      .sort((a, b) => text(b.updatedAt).localeCompare(text(a.updatedAt)))[0] || null;
  }

  function transferJobSnapshot(rawItem, fallback) {
    const item = normalizeJobRecord(isPlainObject(rawItem) ? rawItem : {}, fallback);
    return normalizeJobRecord({
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: stableJobId(item, fallback),
      jobId: stableJobId(item, fallback),
      status: 'queued',
      source: 'mobile-controlled-transfer',
      jobTypeId: text(item.jobTypeId),
      jobTypeName: text(item.jobTypeName),
      fromPlaceId: text(item.fromPlaceId),
      fromPlaceName: text(item.fromPlaceName),
      destinationPlaceId: text(item.destinationPlaceId),
      destinationPlaceName: text(item.destinationPlaceName),
      returnPlaceId: text(item.returnPlaceId),
      returnPlaceName: text(item.returnPlaceName),
      returnRequired: item.returnRequired === true,
      multiLoad: item.multiLoad === true,
      material: isPlainObject(item.material) ? item.material : {},
      plannedDate: text(item.plannedDate),
      plannedTime: text(item.plannedTime),
      note: text(item.note),
      createdAt: text(item.createdAt),
      metadata: {
        createdRole: text(item.metadata && item.metadata.createdRole, 'mobile'),
        createdRoleLabel: text(item.metadata && item.metadata.createdRoleLabel, 'Mobil'),
        createdDeviceId: text(item.metadata && item.metadata.createdDeviceId, text(hostInfo.deviceId)),
        modelVersion: JOB_MODEL_VERSION
      }
    }, fallback);
  }

  function renderSyncRoleView() {
    if (!hostInfo) return;
    const mobilePanel = byId('sync-mobile-panel');
    const vehiclePanel = byId('sync-vehicle-panel');
    mobilePanel.hidden = !isMobileRole();
    vehiclePanel.hidden = !isVehicleRole();
    byId('sync-role-intro').textContent = isMobileRole()
      ? 'Mobil förbereder överföringar och registrerar mottagningskvitton utan att automatiskt ta bort planeringsdata.'
      : '189 validerar och bekräftar import till den operativa kön och skapar ett mottagningskvitto.';
    byId('sync-count').textContent = String(isMobileRole() ? transferEntries().length : receiptEntries().length);
    if (isMobileRole()) renderSyncOutbox();
  }

  function renderSyncOutbox() {
    const list = byId('sync-outbox-list');
    list.replaceChildren();
    const entries = transferEntries().sort((a, b) => text(b.createdAt).localeCompare(text(a.createdAt)));
    if (entries.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga överföringar är förberedda. Öppna planeringskön och välj ett uppdrag.';
      list.appendChild(empty);
      return;
    }
    entries.forEach((entry) => {
      const card = document.createElement('article');
      card.className = 'queue-card sync-outbox-card';
      const heading = document.createElement('h3');
      heading.textContent = entry.state === 'acknowledged' ? 'Mottaget på 189' : 'Förberedd för 189';
      card.appendChild(heading);
      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      meta.appendChild(queueMetaChip(formatTimestamp(entry.createdAt)));
      meta.appendChild(queueMetaChip(`${Array.isArray(entry.jobIds) ? entry.jobIds.length : 0} uppdrag`));
      meta.appendChild(queueMetaChip(entry.state === 'acknowledged' ? 'Kvitterad' : 'Väntar på kvitto', entry.state === 'acknowledged' ? 'transfer-state-acknowledged' : 'transfer-state-prepared'));
      card.appendChild(meta);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'secondary-button';
      button.dataset.showTransferEntry = text(entry.id);
      button.textContent = 'Visa överföringstext';
      card.appendChild(button);
      list.appendChild(card);
    });
  }

  function showTransferEntry(entry) {
    if (!entry || !text(entry.payloadText)) {
      showStatus('sync-export-status', 'Överföringstexten saknas.', true);
      return;
    }
    byId('sync-export-card').hidden = false;
    byId('sync-export-text').value = entry.payloadText;
    byId('sync-export-summary').textContent = entry.state === 'acknowledged'
      ? `Överföring ${entry.transferId} är kvitterad som mottagen på 189.`
      : `Överföring ${entry.transferId} väntar på import och mottagningskvitto.`;
    showStatus('sync-export-status', 'Texten är redo att kopieras och föras till 189.');
    byId('sync-export-card').scrollIntoView({ block: 'start' });
  }

  async function copyTextareaValue(textareaId, statusId) {
    const textarea = byId(textareaId);
    const value = textarea.value;
    if (!value) {
      showStatus(statusId, 'Det finns ingen text att kopiera.', true);
      return;
    }
    try {
      if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') throw new Error('Urklipps-API saknas.');
      await navigator.clipboard.writeText(value);
      showStatus(statusId, 'Texten är kopierad.');
    } catch (_) {
      textarea.focus();
      textarea.select();
      textarea.setSelectionRange(0, value.length);
      showStatus(statusId, 'Texten är markerad. Välj Kopiera i enhetens meny.');
    }
  }

  function prepareQueueTransfer(id) {
    if (!isMobileRole()) {
      showStatus('queue-form-status', 'Endast Mobil kan förbereda en planeringsöverföring.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    const selected = queueItemById(id);
    if (!selected || !loadSyncOutboxIfNeeded()) {
      showStatus('queue-form-status', 'Uppdraget eller synkutkö kunde inte läsas.', true);
      return;
    }
    const existing = latestOutgoingForJob(selected.display.jobId);
    if (existing) {
      activateView('sync');
      showTransferEntry(existing);
      return;
    }
    try {
      const createdAt = new Date().toISOString();
      const transferId = createLocalId('transfer');
      const result = syncProtocol.createTransfer({
        transferId,
        createdAt,
        packageVersion: PACKAGE_VERSION,
        sourceRoleLabel: text(hostInfo.roleLabel, 'Mobil'),
        sourceDeviceId: text(hostInfo.deviceId),
        jobs: [transferJobSnapshot(selected.raw, selected.display.jobId)]
      });
      const entry = {
        id: `out-${transferId}`,
        schemaVersion: 1,
        kind: 'queue-transfer',
        direction: 'outgoing',
        state: 'prepared',
        transferId,
        jobIds: result.envelope.jobs.map((job) => text(job.jobId)),
        createdAt,
        updatedAt: createdAt,
        payloadText: result.text,
        payloadChecksum: result.envelope.checksum,
        sourceDeviceId: text(hostInfo.deviceId),
        targetRole: 'vehicle_189',
        packageVersion: PACKAGE_VERSION
      };
      if (!persistSyncOutbox([...syncOutboxDocument, entry], 'queue-form-status', 'Överföringen är förberedd i separat synkutkö.')) return;
      watchdog.step('runtime.sync.transfer.prepared', 'Mobil förberedde en kontrollerad kööverföring.');
      activateView('sync');
      showTransferEntry(entry);
    } catch (error) {
      showStatus('queue-form-status', error.message || 'Överföringen kunde inte skapas.', true);
    }
  }

  function validateInboundTransfer() {
    if (!isVehicleRole()) {
      showStatus('sync-import-status', 'Endast 189 får importera planeringsöverföringar.', true);
      return;
    }
    validatedInboundTransfer = null;
    byId('sync-import-preview').hidden = true;
    try {
      const envelope = syncProtocol.parseTransfer(byId('sync-transfer-input').value);
      const normalizedJobs = envelope.jobs.map((job, index) => normalizeJobRecord(job, `transfer-${envelope.transferId}-${index}`));
      if (normalizedJobs.some((job) => !text(job.jobId) || !findJobTypeById(job.jobTypeId) || !findPlaceById(job.fromPlaceId) || !findPlaceById(job.destinationPlaceId))) {
        throw new Error('Ett uppdrag saknar giltigt jobb-ID, jobbtyp, Från eller Till.');
      }
      const previousScrollY = currentScrollY();
      validatedInboundTransfer = { envelope, jobs: normalizedJobs };
      renderInboundTransferPreview();
      byId('sync-import-preview').hidden = false;
      revealInlineControl('#sync-import-preview .inline-confirm', previousScrollY);
      showStatus('sync-import-status', 'Överföringen är validerad. Ingen ködata har ändrats ännu.');
      watchdog.step('runtime.sync.transfer.validated', '189 validerade en kontrollerad kööverföring utan att skriva ködata.');
    } catch (error) {
      watchdog.step('runtime.sync.transfer.rejected', error.message || 'Överföringen avvisades.', 'warning');
      showStatus('sync-import-status', error.message || 'Överföringen kunde inte valideras.', true);
    }
  }

  function renderInboundTransferPreview() {
    const container = byId('sync-preview-content');
    container.replaceChildren();
    if (!validatedInboundTransfer) return;
    const summary = document.createElement('p');
    summary.className = 'section-intro';
    summary.textContent = `Överföring ${validatedInboundTransfer.envelope.transferId} från Mobil innehåller ${validatedInboundTransfer.jobs.length} uppdrag.`;
    container.appendChild(summary);
    validatedInboundTransfer.jobs.forEach((job) => {
      const card = document.createElement('div');
      card.className = 'sync-preview-job';
      const heading = document.createElement('strong');
      heading.textContent = text(job.jobTypeName, 'Uppdrag');
      const route = document.createElement('span');
      route.textContent = `${text(job.fromPlaceName, 'Från saknas')} → ${text(job.destinationPlaceName, 'Till saknas')}`;
      card.append(heading, route);
      container.appendChild(card);
    });
  }

  function cancelInboundTransfer() {
    const previousScrollY = currentScrollY();
    validatedInboundTransfer = null;
    byId('sync-import-preview').hidden = true;
    preserveScrollAfterRender(previousScrollY);
    showStatus('sync-import-status', 'Importen avbröts. Den operativa kön är oförändrad.');
  }

  function createReceiptResult(envelope, status) {
    const now = new Date().toISOString();
    return syncProtocol.createReceipt({
      receiptId: createLocalId('receipt'),
      transferId: envelope.transferId,
      receivedAt: now,
      packageVersion: PACKAGE_VERSION,
      status,
      receivedByDeviceId: text(hostInfo.deviceId),
      targetDeviceId: text(envelope.source && envelope.source.deviceId),
      jobIds: envelope.jobs.map((job) => text(job.jobId))
    });
  }

  function showReceiptResult(result, statusText) {
    byId('sync-receipt-card').hidden = false;
    byId('sync-receipt-output').value = result.text;
    byId('sync-receipt-summary').textContent = statusText;
    showStatus('sync-receipt-copy-status', 'Kvittot är redo att kopieras tillbaka till Mobil.');
    byId('sync-receipt-card').scrollIntoView({ block: 'start' });
  }

  function confirmInboundTransfer() {
    if (!isVehicleRole() || !validatedInboundTransfer) {
      showStatus('sync-import-status', 'Det finns ingen validerad överföring att importera.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('sync-import-status', 'Den operativa kön kunde inte läsas. Ingen import har gjorts.', true);
      return;
    }
    const { envelope, jobs } = validatedInboundTransfer;
    const existingIds = new Set(queueDocument.map((item, index) => displayQueueItem(item, index).jobId));
    const newJobs = jobs.filter((job) => !existingIds.has(text(job.jobId))).map((job) => normalizeJobRecord({
      ...job,
      id: text(job.jobId),
      jobId: text(job.jobId),
      status: 'queued',
      source: 'mobile-controlled-transfer',
      receivedAt: new Date().toISOString(),
      receivedByPackageVersion: PACKAGE_VERSION,
      sync: {
        protocol: envelope.protocol,
        transferId: envelope.transferId,
        sourceDeviceId: text(envelope.source.deviceId),
        importedByDeviceId: text(hostInfo.deviceId)
      },
      metadata: {
        ...(isPlainObject(job.metadata) ? job.metadata : {}),
        transferredFromRole: 'mobile',
        transferredFromDeviceId: text(envelope.source.deviceId),
        importedByRole: 'vehicle_189',
        importedByDeviceId: text(hostInfo.deviceId)
      }
    }, `import-${envelope.transferId}`));

    if (newJobs.length > 0) {
      const nextQueue = [...queueDocument, ...newJobs];
      const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextQueue));
      if (!saved) {
        showStatus('sync-import-status', window.StadslassHost.getLastError() || 'Den operativa kön kunde inte sparas. Ingen import har gjorts.', true);
        return;
      }
      queueDocument = nextQueue;
      queueLoaded = true;
      renderQueue();
    }

    const receiptStatus = newJobs.length === 0 ? 'already-present' : 'accepted';
    let result;
    try {
      result = createReceiptResult(envelope, receiptStatus);
    } catch (error) {
      showStatus('sync-import-status', `Uppdraget är säkert sparat i kön, men kvittot kunde inte skapas: ${error.message}`, true);
      validatedInboundTransfer = null;
      byId('sync-import-preview').hidden = true;
      return;
    }
    if (!loadSyncOutboxIfNeeded()) {
      showReceiptResult(result, 'Uppdraget är sparat i operativ kö. Synkutkö kunde inte läsas, men kvittot kan kopieras nu.');
    } else {
      const now = new Date().toISOString();
      const receiptEntry = {
        id: `receipt-${result.envelope.receiptId}`,
        schemaVersion: 1,
        kind: 'queue-receipt',
        direction: 'outgoing',
        state: 'prepared',
        transferId: envelope.transferId,
        receiptId: result.envelope.receiptId,
        jobIds: result.envelope.jobIds,
        createdAt: now,
        updatedAt: now,
        payloadText: result.text,
        payloadChecksum: result.envelope.checksum,
        sourceDeviceId: text(hostInfo.deviceId),
        targetDeviceId: text(envelope.source.deviceId),
        packageVersion: PACKAGE_VERSION
      };
      const saved = window.StadslassHost.writeStore(SYNC_OUTBOX_STORE, JSON.stringify([...syncOutboxDocument, receiptEntry]));
      if (saved) {
        syncOutboxDocument = [...syncOutboxDocument, receiptEntry];
        syncOutboxLoaded = true;
        renderSyncRoleView();
      }
      showReceiptResult(result, newJobs.length > 0
        ? `${newJobs.length} uppdrag importerades till 189:s operativa kö.`
        : 'Uppdragen fanns redan i den operativa kön. Inga dubbletter skapades.');
      if (!saved) showStatus('sync-receipt-copy-status', 'Kön är säker och kvittot kan kopieras, men synkutkö kunde inte spara kvittot.', true);
    }
    watchdog.step('runtime.sync.transfer.imported', newJobs.length > 0 ? 'Validerad överföring importerades till 189:s operativa kö.' : 'Överföringen var redan importerad; dubblett blockerades och nytt kvitto skapades.');
    validatedInboundTransfer = null;
    byId('sync-import-preview').hidden = true;
    showStatus('sync-import-status', newJobs.length > 0 ? 'Importen är klar.' : 'Ingen dubblett skapades. Ett nytt kvitto är klart.');
  }

  function registerReceiptOnMobile() {
    if (!isMobileRole()) {
      showStatus('sync-receipt-status', 'Endast Mobil kan registrera mottagningskvitto.', true);
      return;
    }
    if (!loadSyncOutboxIfNeeded()) return;
    try {
      const receipt = syncProtocol.parseReceipt(byId('sync-receipt-input').value);
      if (text(receipt.target.deviceId) && text(receipt.target.deviceId) !== text(hostInfo.deviceId)) throw new Error('Kvittot är adresserat till en annan Mobil-enhet.');
      const index = syncOutboxDocument.findIndex((entry) => entry.kind === 'queue-transfer' && entry.transferId === receipt.transferId);
      if (index < 0) throw new Error('Motsvarande utgående överföring finns inte i denna Mobils synkutkö.');
      const entry = syncOutboxDocument[index];
      const expected = new Set(Array.isArray(entry.jobIds) ? entry.jobIds : []);
      if (receipt.jobIds.some((jobId) => !expected.has(jobId))) throw new Error('Kvittots jobb-ID stämmer inte med den utgående överföringen.');
      const next = [...syncOutboxDocument];
      next[index] = {
        ...entry,
        state: 'acknowledged',
        updatedAt: new Date().toISOString(),
        acknowledgedAt: receipt.receivedAt,
        receiptId: receipt.receiptId,
        receiptStatus: receipt.status,
        receivedByDeviceId: text(receipt.source.deviceId),
        receiptChecksum: receipt.checksum
      };
      if (!persistSyncOutbox(next, 'sync-receipt-status', 'Överföringen är mottagen och kvitterad av 189. Planeringsuppdraget ligger kvar tills du själv tar bort det.')) return;
      byId('sync-receipt-input').value = '';
      watchdog.step('runtime.sync.receipt.acknowledged', 'Mobil registrerade ett giltigt mottagningskvitto från 189.');
    } catch (error) {
      watchdog.step('runtime.sync.receipt.rejected', error.message || 'Kvittot avvisades.', 'warning');
      showStatus('sync-receipt-status', error.message || 'Kvittot kunde inte registreras.', true);
    }
  }

  function activeJobExists() {
    return isPlainObject(activeJobDocument) && Boolean(text(activeJobDocument.id));
  }

  function activeEvents(documentValue) {
    return Array.isArray(documentValue.events) ? documentValue.events.filter(isPlainObject) : [];
  }

  function activeWorkSegments(documentValue = activeJobDocument) {
    const stored = Array.isArray(documentValue.workSegments) ? documentValue.workSegments.filter(isPlainObject) : [];
    if (stored.length > 0) return stored;
    const startedAt = text(documentValue.startedAt);
    return startedAt ? [{ segmentNumber: 1, startedAt, endedAt: '', endReason: '', note: text(documentValue.note) }] : [];
  }

  function closeOpenWorkSegment(documentValue, endedAt, endReason) {
    const segments = activeWorkSegments(documentValue);
    const openIndex = segments.findIndex((segment) => !text(segment.endedAt));
    if (openIndex < 0) return segments;
    return segments.map((segment, index) => index === openIndex ? { ...segment, endedAt, endReason } : segment);
  }

  function resumeWorkSegment(documentValue, startedAt) {
    const segments = activeWorkSegments(documentValue);
    if (segments.some((segment) => !text(segment.endedAt))) return segments;
    return [...segments, { segmentNumber: segments.length + 1, startedAt, endedAt: '', endReason: '', note: text(documentValue.note) }];
  }

  function parkedOtherActivity(documentValue = activeJobDocument) {
    return isPlainObject(documentValue.parkedOtherActivity) && isOtherActivity(documentValue.parkedOtherActivity)
      ? documentValue.parkedOtherActivity
      : null;
  }

  function pauseOtherActivityAutomatically(documentValue, pausedAt, forJobId) {
    if (!isOtherActivity(documentValue)) return null;
    if (text(documentValue.status) !== 'active') {
      return {
        ...documentValue,
        pauseMode: text(documentValue.pauseMode, 'manual'),
        autoResumeEligible: false,
        parkedForJobId: text(forJobId),
        parkedAt: pausedAt
      };
    }
    return {
      ...documentValue,
      status: 'paused',
      pausedAt,
      pauseMode: 'automatic',
      autoResumeEligible: true,
      autoPausedForJobId: text(forJobId),
      parkedForJobId: text(forJobId),
      parkedAt: pausedAt,
      workSegments: closeOpenWorkSegment(documentValue, pausedAt, 'auto-paused-for-job'),
      updatedAt: pausedAt,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(documentValue, 'other_activity_auto_paused', pausedAt, 'automatic', { forJobId: text(forJobId) })
    };
  }

  function resumeOtherActivityAutomatically(documentValue, resumedAt, afterJobId) {
    if (!isOtherActivity(documentValue)) return null;
    if (text(documentValue.status) === 'active') return documentValue;
    if (text(documentValue.status) !== 'paused' || text(documentValue.pauseMode) !== 'automatic' || documentValue.autoResumeEligible !== true) {
      return documentValue;
    }
    const pausePeriods = Array.isArray(documentValue.pausePeriods) ? documentValue.pausePeriods.filter(isPlainObject) : [];
    const pausedFrom = text(documentValue.pausedAt);
    const completedPause = pausedFrom ? { from: pausedFrom, to: resumedAt, mode: 'automatic' } : null;
    const completedPauseMs = completedPause ? Math.max(0, new Date(resumedAt).getTime() - new Date(pausedFrom).getTime()) : 0;
    const nextSegments = resumeWorkSegment(documentValue, resumedAt);
    return {
      ...documentValue,
      status: 'active',
      pausedAt: '',
      pauseMode: '',
      autoResumeEligible: false,
      autoPausedForJobId: '',
      parkedForJobId: text(afterJobId),
      pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
      pausedTotalMs: (Number(documentValue.pausedTotalMs) || 0) + completedPauseMs,
      workSegments: nextSegments,
      continuationCount: Math.max(0, nextSegments.length - 1),
      updatedAt: resumedAt,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(documentValue, 'other_activity_auto_resumed', resumedAt, 'automatic', { afterJobId: text(afterJobId) })
    };
  }

  function restoreOtherActivityAfterJob(documentValue, restoredAt) {
    const parked = parkedOtherActivity(documentValue);
    if (!parked) return null;
    const resumed = resumeOtherActivityAutomatically(parked, restoredAt, stableJobId(documentValue, 'completed-job'));
    return {
      ...resumed,
      parkedForJobId: '',
      parkedAt: '',
      restoredAfterJobAt: restoredAt
    };
  }

  function phaseLabel(phase) {
    if (phase === 'other_activity') return 'Övrig verksamhet';
    if (phase === 'transport') return 'Transport';
    if (phase === 'unloading') return 'Lossning';
    if (phase === 'returning') return 'Retur pågår';
    if (phase === 'return_unloading') return 'Vid returplats';
    return 'Lastning / start';
  }

  function statusLabel(status) {
    if (status === 'paused') return 'Pausat';
    if (status === 'completing') return 'Avslut väntar';
    return 'Aktivt';
  }

  function activeLoads(documentValue = activeJobDocument) {
    return Array.isArray(documentValue.loads) ? documentValue.loads.filter((value) => Number.isFinite(Number(value)) && Number(value) >= 0).map(Number) : [];
  }

  function activeTotalWeight(documentValue = activeJobDocument) {
    return activeLoads(documentValue).reduce((sum, value) => sum + value, 0);
  }

  function activeLoadCycles(documentValue = activeJobDocument) {
    const stored = Array.isArray(documentValue.loadCycles) ? documentValue.loadCycles.filter(isPlainObject) : [];
    if (stored.length > 0) return stored;
    const entries = Array.isArray(documentValue.weightEntries) ? documentValue.weightEntries.filter(isPlainObject) : [];
    if (entries.length > 0) {
      return entries.map((entry, index) => ({
        loadNumber: index + 1,
        loadingStartedAt: text(documentValue.startedAt),
        unloadingStartedAt: text(documentValue.unloadingStartedAt),
        completedAt: text(entry.at),
        weight: Number(entry.weight),
        outcome: 'registered'
      }));
    }
    return [{ loadNumber: 1, loadingStartedAt: text(documentValue.startedAt), outcome: documentValue.noEmptying === true ? 'no-emptying' : 'open' }];
  }

  function currentLoadNumber(documentValue = activeJobDocument) {
    return Math.max(1, Number(documentValue.currentLoadNumber) || activeLoadCycles(documentValue).length || 1);
  }

  function currentLoadCycle(documentValue = activeJobDocument) {
    const number = currentLoadNumber(documentValue);
    return activeLoadCycles(documentValue).find((cycle) => Number(cycle.loadNumber) === number) || null;
  }

  function currentLoadHasOutcome(documentValue = activeJobDocument) {
    const cycle = currentLoadCycle(documentValue);
    return Boolean(cycle && (cycle.outcome === 'registered' || cycle.outcome === 'no-emptying' || cycle.outcome === 'missing-confirmed'));
  }

  function updateCurrentLoadCycle(documentValue, updates) {
    const number = currentLoadNumber(documentValue);
    const cycles = activeLoadCycles(documentValue);
    const index = cycles.findIndex((cycle) => Number(cycle.loadNumber) === number);
    if (index < 0) return [...cycles, { loadNumber: number, loadingStartedAt: text(documentValue.startedAt), outcome: 'open', ...updates }];
    return cycles.map((cycle, cycleIndex) => cycleIndex === index ? { ...cycle, ...updates, loadNumber: number } : cycle);
  }

  function isSeaweedToBeach(documentValue) {
    if (text(documentValue.jobTypeId) !== 'JT-1010') return false;
    const place = findPlaceById(documentValue.destinationPlaceId);
    const roles = place && Array.isArray(place.roles) ? place.roles : [];
    return Boolean(place && (place.category === 'badplats' || roles.includes('beach')));
  }

  function seaweedFlowType(documentValue) {
    if (text(documentValue.jobTypeId) !== 'JT-1010') return '';
    const from = findPlaceById(documentValue.fromPlaceId);
    const destination = findPlaceById(documentValue.destinationPlaceId);
    if (text(documentValue.destinationPlaceId) === 'PL-1007') return 'till_bioanlaggning';
    if (destination && destination.category === 'badplats') return from && from.category === 'badplats' ? 'mellan_badplatser' : 'till_badplats';
    return 'ovrig_havstang';
  }

  function seaweedFlowLabel(documentValue) {
    const flow = seaweedFlowType(documentValue);
    if (flow === 'till_bioanlaggning') return 'Inkörning till Bio · kod 611 · verklig Bioanläggningsvikt';
    if (flow === 'mellan_badplatser') return 'Mellan badplatser · vikt valfri och märks mellankörningsvikt';
    if (flow === 'till_badplats') return 'Utkörning till badplats · vikt valfri';
    return flow ? 'Övrigt Havstångsflöde' : '';
  }

  function seaweedWeightMetadata(documentValue) {
    const flowType = seaweedFlowType(documentValue);
    if (!flowType) return {};
    const role = flowType === 'till_bioanlaggning' ? 'verklig_bioanlaggning' : 'mellankorningsvikt';
    return {
      role,
      roleLabel: role === 'verklig_bioanlaggning' ? 'Verklig/invägd Bioanläggningsvikt' : 'Mellankörningsvikt / aktuell flakvikt',
      flowType,
      materialCode: flowType === 'till_bioanlaggning' ? '611' : ''
    };
  }

  function weightPolicy(documentValue) {
    const jobTypeId = text(documentValue.jobTypeId);
    if (jobTypeId === 'JT-1001' || jobTypeId === 'JT-1011') return { mode: 'not-required', label: 'Vikt behövs inte för denna jobbtyp.' };
    if (isSeaweedToBeach(documentValue)) return { mode: 'not-required', label: 'Havstång till badplats får avslutas utan vikt.' };
    if (jobTypeId === 'JT-1013' || jobTypeId === 'JT-1014') return { mode: 'optional', label: 'Vikt är valfri för denna jobbtyp.' };
    return { mode: 'required', label: 'Registrera vikt eller välj Ingen tömning före Klart.' };
  }

  function weightOutcome(documentValue) {
    const loads = activeLoads(documentValue);
    if (loads.length > 0) return 'registered';
    if (documentValue.noEmptying === true) return 'no-emptying';
    if (documentValue.weightMissingConfirmed === true) return 'missing-confirmed';
    return 'missing';
  }

  function weightStatusLabel(documentValue) {
    const outcome = weightOutcome(documentValue);
    if (outcome === 'registered') return `${activeTotalWeight(documentValue).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    if (outcome === 'no-emptying') return 'Ingen tömning';
    if (outcome === 'missing-confirmed') return 'Avslutat utan vikt';
    return weightPolicy(documentValue).mode === 'required' ? 'Vikt saknas' : 'Vikt ej obligatorisk';
  }

  function parseWeightInput(value) {
    const raw = String(value || '').trim().replace(',', '.');
    if (!/^\d+(?:\.\d{0,3})?$/.test(raw)) return NaN;
    return Number(raw);
  }

  function noteWithoutNoEmptyingMarker(value) {
    return text(value)
      .replace(/\s*[–-]\s*Ej behov av tömning/giu, '')
      .replace(/Ej behov av tömning\s*[–-]\s*/giu, '')
      .replace(/^Ej behov av tömning$/giu, '')
      .trim();
  }

  function registerActiveWeight() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att registrera vikt på.', true);
      return false;
    }
    const input = byId('active-weight-input');
    if (!String(input.value || '').trim()) {
      input.focus();
      showStatus('active-weight-status', 'Skriv vikten i ton. 0 är tillåtet för tomtransport eller tomt flak.', true);
      return false;
    }
    const weight = parseWeightInput(input.value);
    if (!Number.isFinite(weight) || weight < 0) {
      input.focus();
      showStatus('active-weight-status', 'Skriv en giltig vikt i ton. Använd exempelvis 12,5. 0 är tillåtet.', true);
      return false;
    }
    const now = new Date().toISOString();
    const loadNumber = currentLoadNumber(activeJobDocument);
    const currentCycle = currentLoadCycle(activeJobDocument);
    if (currentCycle && currentCycle.outcome === 'registered') {
      showStatus('active-weight-status', `Lass ${loadNumber} har redan en registrerad vikt. Registrera nästa lastning innan nästa lass vägs.`, true);
      return false;
    }
    const loads = [...activeLoads(activeJobDocument), weight];
    const entries = Array.isArray(activeJobDocument.weightEntries) ? activeJobDocument.weightEntries.filter(isPlainObject) : [];
    const seaweedWeight = seaweedWeightMetadata(activeJobDocument);
    const nextDocument = {
      ...activeJobDocument,
      loads,
      totalWeight: loads.reduce((sum, value) => sum + value, 0),
      weightEntries: [...entries, { weight, at: now, phase: text(activeJobDocument.phase, 'loading'), loadNumber, source: 'manual', ...seaweedWeight }],
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { weight, completedAt: now, outcome: 'registered', weightRole: text(seaweedWeight.role), flowType: text(seaweedWeight.flowType) }),
      ...(text(seaweedWeight.role) ? { havstangFlowType: seaweedWeight.flowType, havstangWeightRole: seaweedWeight.role, havstangWeightRoleLabel: seaweedWeight.roleLabel, havstangWeightIsFinal: seaweedWeight.role === 'verklig_bioanlaggning' } : {}),
      noEmptying: false,
      weightMissingConfirmed: false,
      weightOutcome: 'registered',
      note: noteWithoutNoEmptyingMarker(activeJobDocument.note),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'weight_registered', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber } : entry)
    };
    pendingWeightlessCompletion = false;
    if (persistActiveJob(nextDocument, `Vikt ${weight.toLocaleString('sv-SE', { maximumFractionDigits: 3 })} ton registrerades och sparades lokalt.`)) {
      input.value = '';
      showStatus('active-weight-status', `Vikten är registrerad för lass ${loadNumber}.`);
      return true;
    }
    return false;
  }

  function markActiveNoEmptying() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att markera.', true);
      return;
    }
    if (currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-weight-status', `Lass ${currentLoadNumber(activeJobDocument)} har redan ett registrerat utfall.`, true);
      return;
    }
    const now = new Date().toISOString();
    const marker = 'Ej behov av tömning';
    const note = text(activeJobDocument.note);
    const nextNote = note.toLocaleLowerCase('sv-SE').includes(marker.toLocaleLowerCase('sv-SE')) ? note : (note ? `${note} – ${marker}` : marker);
    const nextDocument = {
      ...activeJobDocument,
      noEmptying: true,
      noEmptyingAt: now,
      weightMissingConfirmed: false,
      weightOutcome: 'no-emptying',
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { completedAt: now, outcome: 'no-emptying' }),
      excludeFromTimeEstimate: true,
      excludeFromEstimateLearning: true,
      learningExcludedReason: marker,
      note: nextNote,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'no_emptying', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber: currentLoadNumber(activeJobDocument) } : entry)
    };
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, 'Ingen tömning är registrerad. Uppdraget undantas från framtida tidsinlärning.');
  }

  function renderActiveJob() {
    const emptyCard = byId('active-empty-card');
    const jobCard = byId('active-job-card');
    const pill = byId('active-status-pill');
    emptyCard.hidden = true;
    jobCard.hidden = true;
    pill.classList.remove('is-active', 'is-paused', 'is-completing');

    if (!activeJobLoaded) {
      pill.textContent = 'Ej laddat';
      return;
    }
    if (!activeJobExists()) {
      pendingActiveReset = false;
      pendingActiveComplete = false;
      pendingWeightlessCompletion = false;
      pill.textContent = 'Inget jobb';
      emptyCard.hidden = false;
      return;
    }

    const status = text(activeJobDocument.status, 'active');
    const phase = text(activeJobDocument.phase, 'loading');
    const otherActivity = isOtherActivity(activeJobDocument);
    const parkedActivity = parkedOtherActivity(activeJobDocument);
    pill.textContent = statusLabel(status);
    pill.classList.add(status === 'paused' ? 'is-paused' : (status === 'completing' ? 'is-completing' : 'is-active'));
    byId('active-display-type').textContent = text(activeJobDocument.jobType, 'Uppdrag');
    const returnRequired = !otherActivity && activeJobDocument.returnRequired === true;
    byId('active-route').hidden = otherActivity;
    byId('active-route').textContent = returnRequired
      ? `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')} → ${text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Returplats saknas'))}`
      : (otherActivity ? 'Användarens tidsrapportering' : `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')}`);
    const parkedStatus = byId('active-other-activity-status');
    parkedStatus.hidden = !parkedActivity;
    parkedStatus.textContent = !parkedActivity
      ? ''
      : (parkedActivity.status === 'active'
        ? 'Övrig verksamhet pågår automatiskt medan detta uppdrag är pausat.'
        : (parkedActivity.autoResumeEligible === true
          ? 'Övrig verksamhet är automatiskt pausad bakom detta uppdrag.'
          : 'Övrig verksamhet är manuellt pausad bakom detta uppdrag och återstartas inte automatiskt.'));
    byId('active-display-status').textContent = statusLabel(status);
    byId('active-display-phase').textContent = isSeaweedToBeach(activeJobDocument) && phase === 'unloading' ? 'Framme vid badplats' : phaseLabel(phase);
    byId('active-display-started').textContent = formatTimestamp(activeJobDocument.startedAt);
    byId('active-display-paused').textContent = status === 'paused' ? formatTimestamp(activeJobDocument.pausedAt) : 'Inte pausat';
    byId('active-event-count').textContent = String(activeEvents(activeJobDocument).length);
    byId('active-display-return').textContent = returnRequired ? text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Från-plats')) : 'Ingen';
    const activeMaterial = isPlainObject(activeJobDocument.material) ? activeJobDocument.material : {};
    byId('active-display-material').textContent = [text(activeMaterial.code), text(activeMaterial.facilityPlaceName)].filter(Boolean).join(' · ') || 'Ej aktuellt';
    byId('active-display-loads').textContent = String(activeLoads(activeJobDocument).length);
    byId('active-display-current-load').textContent = activeJobDocument.multiLoad === true ? String(currentLoadNumber(activeJobDocument)) : 'Enkellass';
    byId('active-display-weight').textContent = `${activeTotalWeight(activeJobDocument).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    byId('active-display-weight-status').textContent = weightStatusLabel(activeJobDocument);
    ['active-return-row', 'active-material-row', 'active-loads-row', 'active-current-load-row', 'active-weight-row', 'active-weight-status-row'].forEach((id) => {
      byId(id).hidden = otherActivity;
    });
    const seaweedLabel = seaweedFlowLabel(activeJobDocument);
    byId('active-seaweed-row').hidden = !seaweedLabel;
    byId('active-display-seaweed').textContent = seaweedLabel || '–';
    byId('active-weight-rule').textContent = weightPolicy(activeJobDocument).label;
    byId('active-weight-panel').hidden = otherActivity;
    const activeNote = text(activeJobDocument.note);
    byId('active-display-note').hidden = !activeNote;
    byId('active-display-note').textContent = activeNote ? `Anteckning: ${activeNote}` : '';
    const phaseAction = byId('active-phase-action');
    phaseAction.hidden = otherActivity || status !== 'active' || !['loading', 'transport'].includes(phase);
    phaseAction.textContent = isSeaweedToBeach(activeJobDocument)
      ? (phase === 'transport' ? 'Framme vid badplats' : 'Transport mot badplats påbörjas')
      : (phase === 'transport' ? 'Lossning påbörjas' : 'Transport påbörjas');
    const nextLoadButton = byId('active-next-load');
    nextLoadButton.hidden = !(activeJobDocument.multiLoad === true && !returnRequired && phase === 'unloading' && status === 'active' && currentLoadHasOutcome(activeJobDocument));
    nextLoadButton.textContent = `Registrera nästa lastning (lass ${currentLoadNumber(activeJobDocument) + 1})`;
    const returnStartButton = byId('active-return-start');
    const returnReady = weightPolicy(activeJobDocument).mode !== 'required' || currentLoadHasOutcome(activeJobDocument);
    returnStartButton.hidden = !(returnRequired && phase === 'unloading' && status === 'active' && returnReady);
    returnStartButton.textContent = `Påbörja retur till ${text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'returplats'))}`;
    const returnArrivedButton = byId('active-return-arrived');
    returnArrivedButton.hidden = !(returnRequired && phase === 'returning' && status === 'active');
    returnArrivedButton.textContent = `${text(activeJobDocument.returnPlaceName, 'Returplats')} nådd`;
    byId('active-pause-action').hidden = status === 'completing';
    byId('active-pause-action').textContent = status === 'paused'
      ? (otherActivity ? 'Fortsätt' : 'Flytta pausat uppdrag till kö')
      : 'Pausa';
    const completionPhase = otherActivity ? 'other_activity' : (returnRequired ? 'return_unloading' : 'unloading');
    byId('active-complete-request').hidden = !(phase === completionPhase && (status === 'active' || status === 'completing')) || pendingActiveComplete || pendingWeightlessCompletion;
    byId('active-complete-request').textContent = status === 'completing' ? 'Slutför avslut' : 'Klart';
    byId('active-complete-confirm').hidden = !pendingActiveComplete;
    byId('active-complete-without-weight').hidden = !pendingWeightlessCompletion;
    byId('active-reset-request').hidden = pendingActiveReset || status === 'completing';
    byId('active-reset-confirm').hidden = !pendingActiveReset;
    byId('active-reset-message').textContent = isPlainObject(activeJobDocument.sourceQueueSnapshot)
      ? 'Uppdraget återställs först i 189:s operativa kö och tas därefter bort från Aktivt jobb. Det förs inte till Historik.'
      : (otherActivity
        ? 'Övrig verksamhet tas bort ur Aktivt jobb och förs inte till Historik.'
        : 'Det manuellt startade uppdraget tas bort ur Aktivt jobb och förs inte till Historik.');
    byId('active-flow-boundary').textContent = otherActivity
      ? 'Övrig verksamhet mäter användarens aktiva arbetstid. 189 kan användas som verktyg, men ingen transport, vikt, GPS, ETA eller transportinlärning kopplas till posten.'
      : 'Uppdraget följer grundfaserna Lastning / start, Transport och Lossning. Vikt är alltid en manuell verklighetshändelse. GPS, ETA och automatisk internettransport är ännu inte inkopplade.';
    jobCard.hidden = false;
  }

  function loadActiveJobIfNeeded() {
    if (!canUseActiveJob()) {
      showStatus('active-role-note', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (activeJobLoaded) {
      return;
    }
    try {
      activeJobDocument = readActiveJobDocument();
      activeJobLoaded = true;
      renderActiveJob();
      showStatus('active-load-status', activeJobExists() ? 'Aktivt jobb är lokalt inläst.' : 'Inget aktivt jobb finns.');
    } catch (error) {
      watchdog.step('runtime.store.active.invalid', error.message || 'Aktivt jobb kunde inte läsas.', 'warning');
      renderActiveJob();
      showStatus('active-load-status', error.message || 'Aktivt jobb kunde inte läsas.', true);
    }
  }

  function persistActiveJob(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(ACTIVE_JOB_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('active-action-status', window.StadslassHost.getLastError() || 'Aktivt jobb kunde inte sparas.', true);
      return false;
    }
    activeJobDocument = nextDocument;
    activeJobLoaded = true;
    pendingActiveReset = false;
    renderActiveJob();
    if (queueLoaded) renderQueue();
    showStatus('active-action-status', successMessage);
    return true;
  }

  function appendActiveEvent(documentValue, type, at, source = 'manual', extra = {}) {
    return [...activeEvents(documentValue), { type, at, source, packageVersion: PACKAGE_VERSION, ...extra }];
  }

  function createActiveJob(event) {
    event.preventDefault();
    if (!canUseActiveJob()) {
      showStatus('active-form-status', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (!activeJobLoaded) loadActiveJobIfNeeded();
    if (!activeJobLoaded) {
      showStatus('active-form-status', 'Lagret måste kunna läsas innan ett uppdrag kan startas.', true);
      return;
    }
    const jobType = findJobTypeById(byId('active-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    if (!jobType) {
      showStatus('active-form-status', 'Välj jobbtyp.', true);
      return;
    }
    if (activeJobExists() && !(isOtherActivity(activeJobDocument) && !otherActivity && activeJobDocument.status !== 'completing')) {
      showStatus('active-form-status', 'Ett aktivt jobb finns redan och har inte ersatts.', true);
      return;
    }
    const fromPlace = otherActivity ? null : findPlaceById(byId('active-job-from').value);
    const destinationPlace = otherActivity ? null : findPlaceById(byId('active-job-destination').value);
    const returnRequired = !otherActivity && byId('active-job-return-required').checked;
    const returnPlace = returnRequired ? (findPlaceById(byId('active-job-return').value) || fromPlace) : null;
    if (!otherActivity && (!fromPlace || !destinationPlace)) {
      showStatus('active-form-status', 'Välj jobbtyp, Från och Till.', true);
      return;
    }
    const now = new Date().toISOString();
    const jobId = createLocalId('job');
    const otherActivityToPark = activeJobExists() ? pauseOtherActivityAutomatically(activeJobDocument, now, jobId) : null;
    const nextDocument = normalizeJobRecord({
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: jobId,
      jobId,
      status: 'active',
      phase: otherActivity ? 'other_activity' : 'loading',
      source: 'manual-local',
      jobTypeId: jobType.id,
      jobTypeName: jobType.name,
      fromPlaceId: text(fromPlace && fromPlace.id),
      fromPlaceName: text(fromPlace && fromPlace.name),
      destinationPlaceId: text(destinationPlace && destinationPlace.id),
      destinationPlaceName: text(destinationPlace && destinationPlace.name),
      returnPlaceId: returnPlace ? returnPlace.id : '',
      returnPlaceName: returnPlace ? returnPlace.name : '',
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : byId('active-job-multi-load').checked,
      ...(otherActivity ? {} : {
        currentLoadNumber: 1,
        loadCycles: [{ loadNumber: 1, loadingStartedAt: now, outcome: 'open' }]
      }),
      ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
      material: deriveMaterial(jobType.id, text(fromPlace && fromPlace.id), text(destinationPlace && destinationPlace.id)),
      note: text(byId('active-job-note').value),
      startedAt: now,
      workSegments: [{ segmentNumber: 1, startedAt: now, endedAt: '', endReason: '', note: text(byId('active-job-note').value) }],
      continuationCount: 0,
      updatedAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: { createdRole: text(hostInfo.role), createdRoleLabel: text(hostInfo.roleLabel), createdDeviceId: text(hostInfo.deviceId), modelVersion: JOB_MODEL_VERSION },
      events: [{ type: otherActivity ? 'other_activity_started' : 'job_started', at: now, source: 'manual', packageVersion: PACKAGE_VERSION }]
    }, 'active');
    if (persistActiveJob(nextDocument, otherActivity
      ? 'Övrig verksamhet startades som användarens tidsrapportering och sparades lokalt.'
      : (otherActivityToPark ? 'ÖV pausades automatiskt och uppdraget startades lokalt.' : 'Uppdraget startades med gemensam uppdragsmodell och sparades lokalt.'))) {
      byId('active-form').reset();
      syncJobModeControls('active');
      updateMaterialPanel('active-');
    }
  }

  function advanceActivePhase() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Fasen kan bara ändras när uppdraget är aktivt.', true);
      return;
    }
    const phase = text(activeJobDocument.phase, 'loading');
    if (phase === 'unloading') {
      showStatus('active-action-status', 'Uppdraget är redan i lossningsfas.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextPhase = phase === 'loading' ? 'transport' : 'unloading';
    const cycleUpdates = nextPhase === 'transport' ? { transportStartedAt: now } : { unloadingStartedAt: now };
    const nextDocument = {
      ...activeJobDocument,
      phase: nextPhase,
      loadCycles: updateCurrentLoadCycle(activeJobDocument, cycleUpdates),
      ...(nextPhase === 'transport' ? { transportStartedAt: now } : { unloadingStartedAt: now }),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, nextPhase === 'transport' ? 'transport_started' : (isSeaweedToBeach(activeJobDocument) ? 'beach_arrived_manual' : 'unloading_started'), now)
    };
    persistActiveJob(nextDocument, nextPhase === 'transport'
      ? 'Transport påbörjades och sparades lokalt.'
      : (isSeaweedToBeach(activeJobDocument) ? 'Framme vid badplats registrerades manuellt och sparades lokalt.' : 'Lossning påbörjades och sparades lokalt.'));
  }

  function startNextActiveLoad() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.multiLoad !== true) {
      showStatus('active-action-status', 'Uppdraget är inte markerat som Flerlass.', true);
      return;
    }
    if (activeJobDocument.returnRequired === true) {
      showStatus('active-action-status', 'Retur och Flerlass kan inte vara aktiva samtidigt i detta flöde.', true);
      return;
    }
    if (activeJobDocument.status !== 'active' || activeJobDocument.phase !== 'unloading') {
      showStatus('active-action-status', 'Nästa lastning kan registreras efter lossningsfasen.', true);
      return;
    }
    if (!currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-action-status', 'Registrera vikt eller Ingen tömning för aktuellt lass innan nästa lastning.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextNumber = currentLoadNumber(activeJobDocument) + 1;
    const cycles = activeLoadCycles(activeJobDocument);
    const nextDocument = {
      ...activeJobDocument,
      phase: 'loading',
      currentLoadNumber: nextNumber,
      loadCycles: [...cycles, { loadNumber: nextNumber, loadingStartedAt: now, outcome: 'open' }],
      noEmptying: false,
      noEmptyingAt: '',
      weightMissingConfirmed: false,
      weightOutcome: activeLoads(activeJobDocument).length > 0 ? 'registered' : 'missing',
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'next_loading_registered', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber: nextNumber } : entry)
    };
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, `Ny lastning är registrerad. Lass ${nextNumber} har påbörjats manuellt.`);
  }

  function startActiveReturn() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.returnRequired !== true || activeJobDocument.phase !== 'unloading' || activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Returen kan påbörjas först efter lossningen i ett returuppdrag.', true);
      return;
    }
    if (weightPolicy(activeJobDocument).mode === 'required' && !currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-action-status', 'Registrera vikt eller Ingen tömning innan returen påbörjas.', true);
      return;
    }
    const now = new Date().toISOString();
    const returnPlaceName = text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Från-plats'));
    const nextDocument = {
      ...activeJobDocument,
      phase: 'returning',
      returnStartedAt: now,
      returnLeg: { fromPlaceId: text(activeJobDocument.destinationPlaceId), fromPlaceName: text(activeJobDocument.destinationPlaceName), destinationPlaceId: text(activeJobDocument.returnPlaceId, text(activeJobDocument.fromPlaceId)), destinationPlaceName: returnPlaceName, startedAt: now, status: 'returning' },
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'return_started', now)
    };
    persistActiveJob(nextDocument, `Retur till ${returnPlaceName} påbörjades manuellt.`);
  }

  function markActiveReturnArrived() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.returnRequired !== true || activeJobDocument.phase !== 'returning' || activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Aktivt jobb väntar inte på ankomst till en returplats.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextDocument = {
      ...activeJobDocument,
      phase: 'return_unloading',
      returnArrivedAt: now,
      returnLeg: { ...(isPlainObject(activeJobDocument.returnLeg) ? activeJobDocument.returnLeg : {}), arrivedAt: now, status: 'arrived' },
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'return_arrived', now)
    };
    persistActiveJob(nextDocument, `${text(activeJobDocument.returnPlaceName, 'Returplats')} är manuellt registrerad som nådd.`);
  }

  function pauseOrdinaryJobToQueue() {
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('active-action-status', 'Den operativa kön kunde inte läsas. Pausen stoppades och Aktivt jobb är oförändrat.', true);
      return;
    }

    const now = new Date().toISOString();
    const wasAlreadyPaused = text(activeJobDocument.status) === 'paused';
    const jobId = stableJobId(activeJobDocument, 'paused-job');
    const queueId = text(activeJobDocument.sourceQueueItemId, jobId);
    const pausedSegments = closeOpenWorkSegment(activeJobDocument, now, 'paused-to-queue');
    const { parkedOtherActivity: _parkedActivity, ...ordinaryJob } = activeJobDocument;
    const pausedQueueItem = normalizeJobRecord({
      ...ordinaryJob,
      id: queueId,
      jobId,
      status: 'paused',
      pausedAt: wasAlreadyPaused ? text(activeJobDocument.pausedAt, now) : now,
      pausedFromActive: true,
      pausedIntoQueueAt: now,
      workSegments: pausedSegments,
      continuationCount: Math.max(0, pausedSegments.length - 1),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(ordinaryJob, wasAlreadyPaused ? 'paused_job_moved_to_queue' : 'job_paused', now, 'manual', { movedToQueue: true })
    }, 'queue-active-pause');
    const nextQueue = [
      pausedQueueItem,
      ...queueDocument.filter((item, index) => displayQueueItem(item, index).jobId !== jobId)
    ];

    if (!persistQueue(nextQueue, 'Det pausade uppdraget placerades överst i 189:s operativa kö.')) {
      showStatus('active-action-status', 'Uppdraget kunde inte sparas i kön. Pausen stoppades och Aktivt jobb är oförändrat.', true);
      return;
    }

    const restoredOtherActivity = restoreOtherActivityAfterJob(activeJobDocument, now);
    if (!persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Uppdraget pausades till kön och Övrig verksamhet är nu synligt aktiv.'
        : 'Uppdraget pausades till kön. Manuellt pausad Övrig verksamhet är synligt bevarad utan automatisk återstart.')
      : 'Uppdraget pausades och flyttades överst i kön.')) {
      showStatus('active-action-status', 'Kökopian är säkert sparad, men Aktivt jobb kunde inte växlas. Tryck Pausa igen för att slutföra flytten utan dubblett.', true);
      return;
    }

    showStatus('active-load-status', restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Övrig verksamhet fortsätter synligt. Det pausade uppdraget ligger överst i kön.'
        : 'Övrig verksamhet är fortsatt manuellt pausad. Det pausade uppdraget ligger överst i kön.')
      : 'Inget aktivt jobb finns. Det pausade uppdraget ligger överst i kön och ett annat uppdrag kan startas.');
  }

  function toggleActivePause() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status === 'completing') {
      showStatus('active-action-status', 'Ett väntande avslut kan inte pausas eller fortsättas.', true);
      return;
    }
    if (!isOtherActivity(activeJobDocument) && ['active', 'paused'].includes(activeJobDocument.status)) {
      pauseOrdinaryJobToQueue();
      return;
    }
    const nextStatus = activeJobDocument.status === 'paused' ? 'active' : 'paused';
    const now = new Date().toISOString();
    const pausePeriods = Array.isArray(activeJobDocument.pausePeriods) ? activeJobDocument.pausePeriods.filter(isPlainObject) : [];
    const pausedFrom = text(activeJobDocument.pausedAt);
    const completedPause = nextStatus === 'active' && pausedFrom ? { from: pausedFrom, to: now } : null;
    const pausedTotalMs = Number(activeJobDocument.pausedTotalMs) || 0;
    const completedPauseMs = completedPause ? Math.max(0, new Date(now).getTime() - new Date(pausedFrom).getTime()) : 0;
    const nextWorkSegments = nextStatus === 'paused'
      ? closeOpenWorkSegment(activeJobDocument, now, 'paused')
      : resumeWorkSegment(activeJobDocument, now);
    const otherActivity = isOtherActivity(activeJobDocument);
    const parkedActivity = parkedOtherActivity(activeJobDocument);
    const nextParkedActivity = parkedActivity
      ? (nextStatus === 'paused'
        ? resumeOtherActivityAutomatically(parkedActivity, now, stableJobId(activeJobDocument, 'paused-job'))
        : pauseOtherActivityAutomatically(parkedActivity, now, stableJobId(activeJobDocument, 'resumed-job')))
      : null;
    const nextDocument = {
      ...activeJobDocument,
      status: nextStatus,
      pausedAt: nextStatus === 'paused' ? now : '',
      ...(otherActivity ? {
        pauseMode: nextStatus === 'paused' ? 'manual' : '',
        autoResumeEligible: false,
        autoPausedForJobId: ''
      } : {}),
      ...(nextParkedActivity ? { parkedOtherActivity: nextParkedActivity } : {}),
      pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
      pausedTotalMs: pausedTotalMs + completedPauseMs,
      workSegments: nextWorkSegments,
      continuationCount: Math.max(0, nextWorkSegments.length - 1),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, nextStatus === 'paused' ? 'job_paused' : 'job_resumed', now)
    };
    persistActiveJob(nextDocument, nextStatus === 'paused'
      ? (nextParkedActivity && nextParkedActivity.status === 'active'
        ? 'Uppdraget pausades och Övrig verksamhet återupptogs automatiskt.'
        : (otherActivity ? 'Övrig verksamhet pausades manuellt och återstartas inte automatiskt.' : 'Uppdraget pausades och sparades lokalt.'))
      : (nextParkedActivity && nextParkedActivity.status === 'paused' && nextParkedActivity.autoResumeEligible === true
        ? 'Uppdraget fortsätter och Övrig verksamhet pausades automatiskt.'
        : (otherActivity ? 'Övrig verksamhet fortsätter och sparades lokalt.' : 'Uppdraget fortsätter och sparades lokalt.')));
  }

  function requestActiveReset() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      return;
    }
    const previousScrollY = currentScrollY();
    pendingActiveReset = true;
    renderActiveJob();
    revealInlineControl('#active-reset-confirm', previousScrollY);
    showStatus('active-action-status', 'Bekräfta avbrottet eller avbryt.');
  }

  function cancelActiveReset() {
    const previousScrollY = currentScrollY();
    pendingActiveReset = false;
    renderActiveJob();
    preserveScrollAfterRender(previousScrollY);
    showStatus('active-action-status', 'Avbrottet avbröts. Aktivt jobb är oförändrat.');
  }

  function confirmActiveReset() {
    if (!pendingActiveReset || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avbrottet kunde inte bekräftas.', true);
      return;
    }
    const queueSnapshot = isPlainObject(activeJobDocument.sourceQueueSnapshot) ? activeJobDocument.sourceQueueSnapshot : null;
    const restoredAt = new Date().toISOString();
    if (queueSnapshot) {
      if (!queueLoaded) loadQueueIfNeeded();
      if (!queueLoaded) {
        pendingActiveReset = false;
        renderActiveJob();
        showStatus('active-action-status', 'Den operativa kön kunde inte läsas. Avbrottet stoppades och Aktivt jobb är bevarat.', true);
        return;
      }
      const jobId = stableJobId(activeJobDocument, 'active-abort');
      const alreadyRestored = queueDocument.some((item, index) => displayQueueItem(item, index).jobId === jobId);
      if (!alreadyRestored) {
        const restored = normalizeJobRecord({
          ...queueSnapshot,
          id: text(activeJobDocument.sourceQueueItemId, text(queueSnapshot.id, jobId)),
          jobId,
          status: 'queued',
          restoredFromActiveAbortAt: restoredAt,
          restoredByPackageVersion: PACKAGE_VERSION
        }, 'queue-abort-restore');
        if (!persistQueue([...queueDocument, restored], 'Det avbrutna uppdraget återställdes i 189:s operativa kö.')) {
          pendingActiveReset = false;
          renderActiveJob();
          showStatus('active-action-status', 'Uppdraget kunde inte återställas i kön. Avbrottet stoppades och Aktivt jobb är bevarat.', true);
          return;
        }
      }
    }
    const restoredOtherActivity = restoreOtherActivityAfterJob(activeJobDocument, restoredAt);
    if (persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? 'Uppdraget avbröts och Övrig verksamhet återställdes säkert.'
      : (queueSnapshot ? 'Uppdraget avbröts och är återställt i 189:s operativa kö.' : 'Det manuellt startade uppdraget avbröts. Ingen historik ändrades.'))) {
      showStatus('active-load-status', restoredOtherActivity
        ? (restoredOtherActivity.status === 'active' ? 'Övrig verksamhet fortsätter efter avbrottet.' : 'Övrig verksamhet är fortsatt manuellt pausad efter avbrottet.')
        : (queueSnapshot ? 'Inget aktivt jobb finns. Uppdraget ligger åter i 189:s operativa kö.' : 'Det manuellt startade uppdraget avbröts. Inget aktivt jobb finns.'));
    }
  }

  function historyItemDisplay(rawItem, index) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    return {
      id: text(item.id, `history-${index}`),
      jobId: text(item.jobId, text(item.sourceJobId, text(item.id))),
      jobTypeId: text(item.jobTypeId),
      jobType: text(item.jobTypeName, text(item.jobType, 'Uppdrag')),
      otherActivity: isOtherActivity(item),
      from: text(item.fromPlaceName, text(item.from, 'Från saknas')),
      destination: text(item.destinationPlaceName, text(item.destination, 'Till saknas')),
      destinationPlaceId: text(item.destinationPlaceId),
      returnPlaceName: text(item.returnPlaceName),
      returnRequired: item.returnRequired === true,
      material: isPlainObject(item.material) ? item.material : {},
      note: text(item.note),
      modelVersion: Number(item.jobModelVersion) || 1,
      startedAt: text(item.startedAt),
      completedAt: text(item.completedAt),
      status: text(item.status, 'completed'),
      loads: Array.isArray(item.loads) ? item.loads : [],
      totalWeight: Number(item.totalWeight) || 0,
      weightOutcome: text(item.weightOutcome),
      multiLoad: item.multiLoad === true,
      loadCycles: Array.isArray(item.loadCycles) ? item.loadCycles.filter(isPlainObject) : [],
      workSegments: Array.isArray(item.workSegments) ? item.workSegments.filter(isPlainObject) : [],
      continuationCount: Number(item.continuationCount) || 0,
      trashState: isPlainObject(item.trashState) ? item.trashState : {}
    };
  }

  function isHistoryItemTrashed(item) {
    return isPlainObject(item)
      && isPlainObject(item.trashState)
      && text(item.trashState.status) === 'trashed';
  }

  function activeHistoryEntries() {
    return historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => !isHistoryItemTrashed(item));
  }

  function trashedHistoryEntries() {
    return historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => isHistoryItemTrashed(item))
      .sort((a, b) => new Date(text(b.item.trashState.trashedAt)).getTime() - new Date(text(a.item.trashState.trashedAt)).getTime());
  }

  function historyRouteText(item) {
    if (item.otherActivity) return 'Användarens tidsrapportering';
    return item.returnRequired
      ? `${item.from} → ${item.destination} → ${item.returnPlaceName || item.from}`
      : `${item.from} → ${item.destination}`;
  }

  function durationText(startedAt, completedAt) {
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return 'Tid saknas';
    const minutes = Math.max(0, Math.round((end - start) / 60000));
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    return hours > 0 ? `${hours} h ${rest} min` : `${rest} min`;
  }

  function durationMinutes(startedAt, completedAt) {
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    return Number.isFinite(start) && Number.isFinite(end) && end >= start ? Math.max(0, Math.round((end - start) / 60000)) : 0;
  }

  function workMinutes(item) {
    if (!item.workSegments.length) return durationMinutes(item.startedAt, item.completedAt);
    return item.workSegments.reduce((sum, segment) => sum + durationMinutes(segment.startedAt, segment.endedAt || item.completedAt), 0);
  }

  function formatMinutes(minutes) {
    return minutes >= 60 ? `${Math.floor(minutes / 60)} h ${minutes % 60} min` : `${minutes} min`;
  }

  function statisticsMetrics(displayed) {
    return {
      jobs: displayed.length,
      loads: displayed.reduce((sum, item) => sum + item.loads.length, 0),
      weight: displayed.reduce((sum, item) => sum + item.totalWeight, 0),
      minutes: displayed.reduce((sum, item) => sum + workMinutes(item), 0)
    };
  }

  function renderSummaryMetrics(prefix, metrics) {
    byId(`${prefix}-summary-jobs`).textContent = String(metrics.jobs);
    byId(`${prefix}-summary-loads`).textContent = String(metrics.loads);
    byId(`${prefix}-summary-weight`).textContent = `${metrics.weight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    byId(`${prefix}-summary-time`).textContent = formatMinutes(metrics.minutes);
  }

  function historySummary(items, prefix) {
    const displayed = items.map(({ item, index }) => historyItemDisplay(item, index));
    renderSummaryMetrics(prefix, statisticsMetrics(displayed));
  }

  function historySearchText(item) {
    return [item.jobType, item.from, item.destination, item.returnPlaceName, item.note, item.material.code, item.material.facilityPlaceName]
      .filter(Boolean).join(' ').toLocaleLowerCase('sv-SE');
  }

  function localDateFromTimestamp(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : localDateKey(date);
  }

  function createHistoryCard(rawItem, index, options = {}) {
    const item = historyItemDisplay(rawItem, index);
    const trashMode = options.mode === 'trash';
    const card = document.createElement('article');
    card.className = `queue-card history-card${trashMode ? ' trash-card' : ''}`;
    const heading = document.createElement('h3');
    heading.textContent = item.jobType;
    const route = document.createElement('p');
    route.className = 'queue-route';
    route.textContent = historyRouteText(item);
    const meta = document.createElement('div');
    meta.className = 'queue-meta';
    if (trashMode) {
      meta.appendChild(queueMetaChip(`Raderad: ${formatTimestamp(text(item.trashState.trashedAt))}`, 'trash-chip'));
    }
    meta.appendChild(queueMetaChip(formatTimestamp(item.completedAt)));
    meta.appendChild(queueMetaChip(durationText(item.startedAt, item.completedAt)));
    meta.appendChild(queueMetaChip(`Modell v${item.modelVersion}`, 'model-chip'));
    if (item.returnPlaceName) meta.appendChild(queueMetaChip(`Retur: ${item.returnPlaceName}`));
    const historyMaterial = [text(item.material.code), text(item.material.facilityPlaceName)].filter(Boolean).join(' · ');
    if (historyMaterial) meta.appendChild(queueMetaChip(`Mtrl: ${historyMaterial}`));
    if (item.jobTypeId === 'JT-1010') {
      const roleLabel = text(rawItem && rawItem.havstangWeightRoleLabel);
      meta.appendChild(queueMetaChip(item.destinationPlaceId === 'PL-1007' ? 'Havstång: Inkörning till Bio' : 'Havstång: Badplats/mellankörning', 'model-chip'));
      if (roleLabel && item.loads.length > 0) meta.appendChild(queueMetaChip(roleLabel));
    }
    if (item.multiLoad) meta.appendChild(queueMetaChip(`Flerlass: ${item.loads.length} lass`, 'model-chip'));
    if (item.continuationCount > 0) meta.appendChild(queueMetaChip(`Fortsättning: ${item.continuationCount}`, 'model-chip'));
    if (item.loads.length > 0) meta.appendChild(queueMetaChip(`Vikt: ${item.totalWeight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`));
    else if (item.weightOutcome === 'no-emptying') meta.appendChild(queueMetaChip('Ingen tömning'));
    else if (item.weightOutcome === 'missing-confirmed') meta.appendChild(queueMetaChip('Utan vikt'));
    card.append(heading, route, meta);
    if (item.note) { const note = document.createElement('p'); note.className = 'queue-note'; note.textContent = item.note; card.appendChild(note); }
    const details = document.createElement('details');
    details.className = 'history-details';
    const summary = document.createElement('summary');
    summary.textContent = 'Visa detaljer';
    const detailGrid = document.createElement('div');
    detailGrid.className = 'history-detail-grid';
    const detailRows = [
      ['Start', formatTimestamp(item.startedAt)],
      ['Avslut', formatTimestamp(item.completedAt)],
      ['Total tid', durationText(item.startedAt, item.completedAt)],
      ['Arbetstid', formatMinutes(workMinutes(item))],
      ['Lass', String(item.loads.length)],
      ['Fortsättningar', String(item.continuationCount)]
    ];
    detailRows.forEach(([label, value]) => {
      const row = document.createElement('span');
      const strong = document.createElement('strong');
      strong.textContent = `${label}: `;
      row.append(strong, document.createTextNode(value));
      detailGrid.appendChild(row);
    });
    details.append(summary, detailGrid);
    if (item.loads.length > 0) {
      const loadList = document.createElement('ol');
      loadList.className = 'history-load-list';
      item.loads.forEach((load, loadIndex) => {
        const row = document.createElement('li');
        const value = Number(isPlainObject(load) ? load.weight : load);
        row.textContent = `Lass ${loadIndex + 1}: ${Number.isFinite(value) ? value.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 }) : 'vikt saknas'}${Number.isFinite(value) ? ' ton' : ''}`;
        loadList.appendChild(row);
      });
      details.appendChild(loadList);
    }
    card.appendChild(details);

    const actions = document.createElement('div');
    actions.className = 'history-actions';
    if (trashMode) {
      const restore = document.createElement('button');
      restore.type = 'button';
      restore.className = 'primary-button';
      restore.textContent = 'Återställ';
      restore.dataset.restoreHistoryTrash = item.id;
      actions.appendChild(restore);

      if (pendingTrashPermanentDeleteId !== item.id) {
        const requestPermanentDelete = document.createElement('button');
        requestPermanentDelete.type = 'button';
        requestPermanentDelete.className = 'danger-button';
        requestPermanentDelete.textContent = 'Ta bort permanent';
        requestPermanentDelete.dataset.requestHistoryPermanentDelete = item.id;
        actions.appendChild(requestPermanentDelete);
      }
      card.appendChild(actions);

      if (pendingTrashPermanentDeleteId === item.id) {
        const confirmation = document.createElement('div');
        confirmation.className = 'inline-confirm';
        const message = document.createElement('p');
        message.textContent = `Ta bort ${item.jobType}: ${historyRouteText(item)} permanent? Hela uppdraget, inklusive eventuell GPS-, fas- och tidsdata i posten, försvinner och kan inte återställas.`;
        const confirm = document.createElement('button');
        confirm.type = 'button';
        confirm.className = 'danger-button is-solid';
        confirm.textContent = 'Bekräfta permanent radering';
        confirm.dataset.confirmHistoryPermanentDelete = item.id;
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.textContent = 'Avbryt';
        cancel.dataset.cancelHistoryPermanentDelete = item.id;
        confirmation.append(message, confirm, cancel);
        card.appendChild(confirmation);
      }
    } else if (pendingHistoryTrashId === item.id) {
      const confirmation = document.createElement('div');
      confirmation.className = 'inline-confirm';
      const message = document.createElement('p');
      message.textContent = `Flytta ${item.jobType}: ${historyRouteText(item)} till Papperskorgen? Jobbet tas bort från Idag, Historik och Sammanställning men kan återställas.`;
      const confirm = document.createElement('button');
      confirm.type = 'button';
      confirm.className = 'danger-button is-solid';
      confirm.textContent = 'Bekräfta flytt';
      confirm.dataset.confirmHistoryTrash = item.id;
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'secondary-button';
      cancel.textContent = 'Avbryt';
      cancel.dataset.cancelHistoryTrash = item.id;
      confirmation.append(message, confirm, cancel);
      card.appendChild(confirmation);
    } else {
      const requestTrash = document.createElement('button');
      requestTrash.type = 'button';
      requestTrash.className = 'danger-button';
      requestTrash.textContent = 'Flytta till Papperskorgen';
      requestTrash.dataset.requestHistoryTrash = item.id;
      actions.appendChild(requestTrash);
      card.appendChild(actions);
    }
    return card;
  }

  function renderHistoryGroups(items, container) {
    let currentDate = '';
    items.forEach(({ item, index }) => {
      const dateKey = localDateFromTimestamp(historyItemDisplay(item, index).completedAt) || 'Datum saknas';
      if (dateKey !== currentDate) {
        currentDate = dateKey;
        const heading = document.createElement('h3');
        heading.className = 'history-day-heading';
        const parsed = new Date(`${dateKey}T12:00:00`);
        heading.textContent = Number.isNaN(parsed.getTime()) ? dateKey : parsed.toLocaleDateString('sv-SE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        container.appendChild(heading);
      }
      container.appendChild(createHistoryCard(item, index));
    });
  }

  function addStatisticsGroup(groups, key, label, item) {
    if (!groups.has(key)) groups.set(key, { key, label, items: [] });
    groups.get(key).items.push(item);
  }

  function renderStatisticsTable(bodyId, groups, compare) {
    const body = byId(bodyId);
    body.replaceChildren();
    const rows = Array.from(groups.values()).sort(compare);
    if (rows.length === 0) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 5;
      cell.className = 'statistics-empty';
      cell.textContent = 'Inga poster i perioden.';
      row.appendChild(cell);
      body.appendChild(row);
      return;
    }
    rows.forEach((group) => {
      const metrics = statisticsMetrics(group.items);
      const row = document.createElement('tr');
      [
        group.label,
        String(metrics.jobs),
        String(metrics.loads),
        `${metrics.weight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`,
        formatMinutes(metrics.minutes)
      ].forEach((value) => {
        const cell = document.createElement('td');
        cell.textContent = value;
        row.appendChild(cell);
      });
      body.appendChild(row);
    });
  }

  function renderStatisticsView() {
    const dateFrom = text(byId('statistics-date-from').value);
    const dateTo = text(byId('statistics-date-to').value);
    const all = activeHistoryEntries().map(({ item, index }) => historyItemDisplay(item, index));
    const displayed = all.filter((item) => {
      const dateKey = localDateFromTimestamp(item.completedAt);
      return (!dateFrom || dateKey >= dateFrom) && (!dateTo || dateKey <= dateTo);
    });
    byId('statistics-count').textContent = displayed.length === all.length ? String(all.length) : `${displayed.length}/${all.length}`;
    renderSummaryMetrics('statistics', statisticsMetrics(displayed));

    const dayGroups = new Map();
    const jobTypeGroups = new Map();
    const placeGroups = new Map();
    displayed.forEach((item) => {
      const dateKey = localDateFromTimestamp(item.completedAt) || 'Datum saknas';
      addStatisticsGroup(dayGroups, dateKey, formatDate(dateKey) || dateKey, item);
      const jobType = item.jobType || 'Jobbtyp saknas';
      addStatisticsGroup(jobTypeGroups, jobType.toLocaleLowerCase('sv-SE'), jobType, item);
      const placeNames = new Set([item.from, item.destination, item.returnRequired ? item.returnPlaceName : '']
        .filter((name) => name && name !== 'Från saknas' && name !== 'Till saknas'));
      if (placeNames.size === 0) placeNames.add('Plats saknas');
      placeNames.forEach((placeName) => addStatisticsGroup(placeGroups, placeName.toLocaleLowerCase('sv-SE'), placeName, item));
    });

    renderStatisticsTable('statistics-day-body', dayGroups, (a, b) => b.key.localeCompare(a.key, 'sv-SE'));
    renderStatisticsTable('statistics-job-type-body', jobTypeGroups, (a, b) => a.label.localeCompare(b.label, 'sv-SE'));
    renderStatisticsTable('statistics-place-body', placeGroups, (a, b) => a.label.localeCompare(b.label, 'sv-SE'));
  }

  function renderHistoryViews() {
    const todayList = byId('today-list');
    const historyList = byId('history-list');
    todayList.replaceChildren();
    historyList.replaceChildren();
    const sorted = activeHistoryEntries()
      .sort((a, b) => new Date(historyItemDisplay(b.item, b.index).completedAt).getTime() - new Date(historyItemDisplay(a.item, a.index).completedAt).getTime());
    const todayKey = localDateKey(new Date());
    const todayItems = sorted.filter(({ item, index }) => localDateFromTimestamp(historyItemDisplay(item, index).completedAt) === todayKey);
    const query = text(byId('history-search').value).toLocaleLowerCase('sv-SE');
    const dateFrom = text(byId('history-date-from').value);
    const dateTo = text(byId('history-date-to').value);
    const filtered = sorted.filter(({ item, index }) => {
      const displayed = historyItemDisplay(item, index);
      const dateKey = localDateFromTimestamp(displayed.completedAt);
      return (!query || historySearchText(displayed).includes(query)) && (!dateFrom || dateKey >= dateFrom) && (!dateTo || dateKey <= dateTo);
    });
    byId('today-count').textContent = String(todayItems.length);
    byId('history-count').textContent = filtered.length === sorted.length ? String(sorted.length) : `${filtered.length}/${sorted.length}`;
    historySummary(todayItems, 'today');
    historySummary(filtered, 'history');

    if (todayItems.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga avslutade jobb idag.';
      todayList.appendChild(empty);
    } else {
      renderHistoryGroups(todayItems, todayList);
    }

    if (filtered.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = sorted.length === 0 ? 'Historiken är tom.' : 'Inga historikposter matchar filtret.';
      historyList.appendChild(empty);
    } else {
      renderHistoryGroups(filtered, historyList);
    }
    renderTrashView();
    renderStatisticsView();
  }

  function renderTrashView() {
    const trashList = byId('trash-list');
    const trashed = trashedHistoryEntries();
    trashList.replaceChildren();
    byId('trash-count').textContent = String(trashed.length);
    if (trashed.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Papperskorgen är tom.';
      trashList.appendChild(empty);
      return;
    }
    trashed.forEach(({ item, index }) => trashList.appendChild(createHistoryCard(item, index, { mode: 'trash' })));
  }

  function historyItemIndexById(id) {
    const key = text(id);
    return historyDocument.findIndex((item, index) => historyItemDisplay(item, index).id === key);
  }

  function currentHistoryActionStatusId() {
    if (!byId('view-today').hidden) return 'today-load-status';
    if (!byId('view-statistics').hidden) return 'statistics-load-status';
    if (!byId('view-trash').hidden) return 'trash-load-status';
    return 'history-load-status';
  }

  function requestHistoryTrash(id) {
    const index = historyItemIndexById(id);
    if (!canUseActiveJob() || index < 0 || isHistoryItemTrashed(historyDocument[index])) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = historyItemDisplay(historyDocument[index], index).id;
    renderHistoryViews();
    revealInlineControl(byId('view-today').hidden ? '#history-list .inline-confirm' : '#today-list .inline-confirm', previousScrollY);
  }

  function cancelHistoryTrash(id) {
    if (pendingHistoryTrashId !== text(id)) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus(currentHistoryActionStatusId(), 'Flytten till Papperskorgen avbröts. Historiken är oförändrad.');
  }

  function confirmHistoryTrash(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || pendingHistoryTrashId !== key || index < 0 || isHistoryItemTrashed(historyDocument[index])) return;
    const now = new Date().toISOString();
    const nextDocument = historyDocument.map((item, itemIndex) => itemIndex === index
      ? {
          ...item,
          trashState: {
            status: 'trashed',
            source: 'completed-job',
            trashedAt: now,
            trashedByPackageVersion: PACKAGE_VERSION
          }
        }
      : item);
    const statusId = currentHistoryActionStatusId();
    pendingHistoryTrashId = '';
    if (!persistHistory(nextDocument, 'Uppdraget flyttades till Papperskorgen.', statusId)) {
      pendingHistoryTrashId = key;
      renderHistoryViews();
    }
  }

  function restoreHistoryTrash(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const nextDocument = historyDocument.map((item, itemIndex) => {
      if (itemIndex !== index) return item;
      const restored = { ...item };
      delete restored.trashState;
      return restored;
    });
    pendingTrashPermanentDeleteId = '';
    persistHistory(nextDocument, 'Uppdraget återställdes till Idag och Historik.', 'trash-load-status');
  }

  function requestHistoryPermanentDelete(id) {
    const index = historyItemIndexById(id);
    if (!canUseActiveJob() || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const previousScrollY = currentScrollY();
    pendingTrashPermanentDeleteId = historyItemDisplay(historyDocument[index], index).id;
    renderHistoryViews();
    revealInlineControl('#trash-list .inline-confirm', previousScrollY);
  }

  function cancelHistoryPermanentDelete(id) {
    if (pendingTrashPermanentDeleteId !== text(id)) return;
    const previousScrollY = currentScrollY();
    pendingTrashPermanentDeleteId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus('trash-load-status', 'Den permanenta raderingen avbröts. Uppdraget finns kvar i Papperskorgen.');
  }

  function confirmHistoryPermanentDelete(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || pendingTrashPermanentDeleteId !== key || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const nextDocument = historyDocument.filter((_, itemIndex) => itemIndex !== index);
    pendingTrashPermanentDeleteId = '';
    if (!persistHistory(nextDocument, 'Uppdraget och all data i posten togs bort permanent.', 'trash-load-status')) {
      pendingTrashPermanentDeleteId = key;
      renderHistoryViews();
    }
  }

  function historyStatusId(target) {
    if (target === 'today') return 'today-load-status';
    if (target === 'statistics') return 'statistics-load-status';
    if (target === 'trash') return 'trash-load-status';
    return 'history-load-status';
  }

  function loadHistoryIfNeeded(target = 'history') {
    if (!canUseActiveJob()) {
      showStatus('role-boundary-note', 'Historik är blockerad på denna enhetsroll.', true);
      return false;
    }
    if (!historyLoaded) {
      try {
        historyDocument = readHistoryDocument();
        historyLoaded = true;
        renderHistoryViews();
      } catch (error) {
        watchdog.step('runtime.store.history.invalid', error.message || 'Historiken kunde inte läsas.', 'warning');
        showStatus(historyStatusId(target), error.message || 'Historiken kunde inte läsas.', true);
        return false;
      }
    }
    showStatus(historyStatusId(target), target === 'trash' ? 'Papperskorgen är lokalt inläst från Historiklagret.' : 'Historiken är lokalt inläst.');
    return true;
  }

  function persistHistory(nextDocument, successMessage, statusId = 'active-action-status') {
    const saved = window.StadslassHost.writeStore(HISTORY_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus(statusId, window.StadslassHost.getLastError() || 'Historiken kunde inte sparas.', true);
      return false;
    }
    historyDocument = nextDocument;
    historyLoaded = true;
    renderHistoryViews();
    showStatus(statusId, successMessage);
    return true;
  }

  function activeCompletionPhase(documentValue = activeJobDocument) {
    if (isOtherActivity(documentValue)) return 'other_activity';
    return documentValue.returnRequired === true ? 'return_unloading' : 'unloading';
  }

  function requestActiveComplete() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.phase !== activeCompletionPhase(activeJobDocument)) {
      showStatus('active-action-status', activeJobDocument.returnRequired === true ? 'Returuppdraget kan avslutas först när Returplats nådd har registrerats.' : 'Uppdraget kan avslutas först i lossningsfas.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    const policy = weightPolicy(activeJobDocument);
    const missingRequiredOutcome = activeJobDocument.multiLoad === true ? !currentLoadHasOutcome(activeJobDocument) : weightOutcome(activeJobDocument) === 'missing';
    if (policy.mode === 'required' && missingRequiredOutcome) {
      pendingWeightlessCompletion = true;
      renderActiveJob();
      revealInlineControl('#active-complete-without-weight', previousScrollY);
      showStatus('active-action-status', 'Vikt saknas. Registrera verklig vikt, välj Ingen tömning eller välj uttryckligen Avsluta ändå utan vikt.', true);
      return;
    }
    pendingWeightlessCompletion = false;
    pendingActiveComplete = true;
    renderActiveJob();
    revealInlineControl('#active-complete-confirm', previousScrollY);
    showStatus('active-action-status', activeJobDocument.status === 'completing'
      ? 'Bekräfta att det väntande avslutet ska slutföras.'
      : 'Bekräfta avslutet eller avbryt.');
  }

  function cancelActiveComplete() {
    const previousScrollY = currentScrollY();
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    renderActiveJob();
    preserveScrollAfterRender(previousScrollY);
    showStatus('active-action-status', 'Avslutet avbröts. Aktivt jobb är oförändrat.');
  }

  function allowActiveCompleteWithoutWeight() {
    if (!pendingWeightlessCompletion || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avslut utan vikt kunde inte bekräftas.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    const now = new Date().toISOString();
    const nextDocument = {
      ...activeJobDocument,
      weightMissingConfirmed: true,
      weightMissingConfirmedAt: now,
      weightOutcome: 'missing-confirmed',
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { completedAt: now, outcome: 'missing-confirmed' }),
      excludeFromTimeEstimate: true,
      excludeFromEstimateLearning: true,
      learningExcludedReason: 'Avslutat utan registrerad vikt',
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'weight_missing_confirmed', now)
    };
    pendingWeightlessCompletion = false;
    if (!persistActiveJob(nextDocument, 'Avslut utan vikt är uttryckligen markerat och undantas från framtida tidsinlärning.')) return;
    pendingActiveComplete = true;
    renderActiveJob();
    revealInlineControl('#active-complete-confirm', previousScrollY);
    showStatus('active-action-status', 'Bekräfta nu att uppdraget ska avslutas och sparas i Idag och Historik.');
  }

  function completionRecordFromActive(documentValue, historyId, completedAt) {
    const completedSegments = closeOpenWorkSegment(documentValue, completedAt, 'completed');
    const { parkedOtherActivity: _parkedOtherActivity, ...historySource } = documentValue;
    return normalizeJobRecord({
      ...historySource,
      workSegments: completedSegments,
      continuationCount: Math.max(0, completedSegments.length - 1),
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: historyId,
      jobId: stableJobId(documentValue, 'history'),
      status: 'completed',
      sourceJobId: stableJobId(documentValue, 'history'),
      source: text(documentValue.source, 'local'),
      sourceQueueItemId: text(documentValue.sourceQueueItemId),
      sourceQueueSnapshot: isPlainObject(documentValue.sourceQueueSnapshot) ? documentValue.sourceQueueSnapshot : undefined,
      startedAt: text(documentValue.startedAt),
      transportStartedAt: text(documentValue.transportStartedAt),
      unloadingStartedAt: text(documentValue.unloadingStartedAt),
      completedAt,
      events: activeEvents(historySource),
      completedByPackageVersion: PACKAGE_VERSION
    }, 'history');
  }

  function confirmActiveComplete() {
    if (!pendingActiveComplete || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avslutet kunde inte bekräftas.', true);
      return;
    }
    if (activeJobDocument.phase !== activeCompletionPhase(activeJobDocument)) {
      showStatus('active-action-status', 'Uppdraget är inte i sin manuella avslutningsfas och har inte avslutats.', true);
      return;
    }

    const now = new Date().toISOString();
    const historyId = text(activeJobDocument.completionHistoryId, `history-${text(activeJobDocument.id)}`);
    const completedAt = text(activeJobDocument.completedAt, now);
    let completingDocument = activeJobDocument;
    if (activeJobDocument.status !== 'completing' || !text(activeJobDocument.completionHistoryId)) {
      completingDocument = {
        ...activeJobDocument,
        status: 'completing',
        completionHistoryId: historyId,
        completedAt,
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: appendActiveEvent(activeJobDocument, 'job_completion_started', now)
      };
      if (!persistActiveJob(completingDocument, 'Avslutet markerades säkert före historikskrivningen.')) return;
      pendingActiveComplete = true;
    }

    if (!loadHistoryIfNeeded('history')) {
      renderActiveJob();
      showStatus('active-action-status', 'Avslutet väntar. Historiklagret kunde inte läsas och Aktivt jobb är bevarat.', true);
      return;
    }

    const existingIndex = historyDocument.findIndex((item) => isPlainObject(item) && text(item.id) === historyId);
    if (existingIndex < 0) {
      const record = completionRecordFromActive(completingDocument, historyId, completedAt);
      if (!persistHistory([...historyDocument, record], 'Det avslutade jobbet sparades i Historik.')) {
        renderActiveJob();
        showStatus('active-action-status', 'Avslutet väntar. Aktivt jobb är bevarat och kan slutföras igen.', true);
        return;
      }
    }

    const restoredOtherActivity = restoreOtherActivityAfterJob(completingDocument, completedAt);
    if (!persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Uppdraget är avslutat och Övrig verksamhet har återupptagits automatiskt.'
        : 'Uppdraget är avslutat. Manuellt pausad Övrig verksamhet är bevarad utan automatisk återstart.')
      : 'Uppdraget är avslutat och Aktivt jobb är tömt.')) {
      renderActiveJob();
      showStatus('active-action-status', 'Historiken är sparad, men Aktivt jobb kunde inte växlas säkert. Tryck Slutför avslut igen.', true);
      return;
    }
    pendingActiveComplete = false;
    if (restoredOtherActivity) {
      activateView('active');
      showStatus('active-load-status', restoredOtherActivity.status === 'active'
        ? 'Uppdraget sparades i Historik och Övrig verksamhet fortsätter automatiskt.'
        : 'Uppdraget sparades i Historik. Övrig verksamhet är fortsatt manuellt pausad.');
    } else {
      showStatus('active-load-status', 'Uppdraget avslutades och sparades i Idag och Historik.');
      activateView('today');
    }
  }

  function refreshUpdateStatus() {
    if (!bridgeAvailable()) {
      return;
    }
    const textValue = window.StadslassHost.getUpdateStatus();
    byId('update-status').textContent = textValue || hostInfo.updateStatus || 'Ingen uppdateringsstatus tillgänglig.';
  }

  function requestUpdateCheck() {
    byId('update-status').textContent = 'Söker efter funktionsuppdatering…';
    window.StadslassHost.requestUpdateCheck();
    window.setTimeout(refreshUpdateStatus, 250);
  }

  function installEventHandlers() {
    byId('open-queue').addEventListener('click', () => activateView('queue'));
    byId('open-active-job').addEventListener('click', () => activateView('active'));
    byId('open-today').addEventListener('click', () => activateView('today'));
    byId('open-history').addEventListener('click', () => activateView('history'));
    byId('open-trash').addEventListener('click', () => activateView('trash'));
    byId('open-statistics').addEventListener('click', () => activateView('statistics'));
    byId('history-search').addEventListener('input', renderHistoryViews);
    byId('history-date-from').addEventListener('change', renderHistoryViews);
    byId('history-date-to').addEventListener('change', renderHistoryViews);
    byId('history-clear-filters').addEventListener('click', () => {
      byId('history-search').value = '';
      byId('history-date-from').value = '';
      byId('history-date-to').value = '';
      renderHistoryViews();
    });
    byId('statistics-date-from').addEventListener('change', renderStatisticsView);
    byId('statistics-date-to').addEventListener('change', renderStatisticsView);
    byId('statistics-clear-filters').addEventListener('click', () => {
      byId('statistics-date-from').value = '';
      byId('statistics-date-to').value = '';
      renderStatisticsView();
    });
    const handleHistoryAction = (event) => {
      const requestTrash = event.target.closest('button[data-request-history-trash]');
      const confirmTrash = event.target.closest('button[data-confirm-history-trash]');
      const cancelTrash = event.target.closest('button[data-cancel-history-trash]');
      const restoreTrash = event.target.closest('button[data-restore-history-trash]');
      const requestPermanentDelete = event.target.closest('button[data-request-history-permanent-delete]');
      const confirmPermanentDelete = event.target.closest('button[data-confirm-history-permanent-delete]');
      const cancelPermanentDelete = event.target.closest('button[data-cancel-history-permanent-delete]');
      if (requestTrash) {
        requestHistoryTrash(requestTrash.dataset.requestHistoryTrash || '');
      } else if (confirmTrash) {
        confirmHistoryTrash(confirmTrash.dataset.confirmHistoryTrash || '');
      } else if (cancelTrash) {
        cancelHistoryTrash(cancelTrash.dataset.cancelHistoryTrash || '');
      } else if (restoreTrash) {
        restoreHistoryTrash(restoreTrash.dataset.restoreHistoryTrash || '');
      } else if (requestPermanentDelete) {
        requestHistoryPermanentDelete(requestPermanentDelete.dataset.requestHistoryPermanentDelete || '');
      } else if (confirmPermanentDelete) {
        confirmHistoryPermanentDelete(confirmPermanentDelete.dataset.confirmHistoryPermanentDelete || '');
      } else if (cancelPermanentDelete) {
        cancelHistoryPermanentDelete(cancelPermanentDelete.dataset.cancelHistoryPermanentDelete || '');
      }
    };
    byId('today-list').addEventListener('click', handleHistoryAction);
    byId('history-list').addEventListener('click', handleHistoryAction);
    byId('trash-list').addEventListener('click', handleHistoryAction);
    byId('open-sync').addEventListener('click', () => activateView('sync'));
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      button.addEventListener('click', () => activateView(button.dataset.target));
    });
    byId('settings-form').addEventListener('submit', saveSettings);
    byId('increment-test').addEventListener('click', incrementPreservedTestValue);
    byId('check-update').addEventListener('click', requestUpdateCheck);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());
    byId('copy-watchdog').addEventListener('click', () => watchdog.copyReport(byId('watchdog-copy-status')));
    byId('queue-form').addEventListener('submit', createQueueItem);
    byId('queue-cancel-edit').addEventListener('click', cancelQueueEdit);
    byId('job-type').addEventListener('change', () => { refreshPlaceFormsForJobType(''); applySuggestedDestination(''); updateMaterialPanel(''); syncJobModeControls('queue'); });
    byId('job-from').addEventListener('change', () => { applySuggestedDestination(''); updateMaterialPanel(''); syncJobModeControls('queue'); });
    byId('job-destination').addEventListener('change', () => updateMaterialPanel(''));
    byId('job-return-required').addEventListener('change', () => syncJobModeControls('queue', 'return'));
    byId('job-multi-load').addEventListener('change', () => syncJobModeControls('queue', 'multi'));
    byId('active-job-type').addEventListener('change', () => { refreshPlaceFormsForJobType('active-'); applySuggestedDestination('active-'); updateMaterialPanel('active-'); syncJobModeControls('active'); });
    byId('active-job-from').addEventListener('change', () => { applySuggestedDestination('active-'); updateMaterialPanel('active-'); syncJobModeControls('active'); });
    byId('active-job-destination').addEventListener('change', () => updateMaterialPanel('active-'));
    byId('active-job-return-required').addEventListener('change', () => syncJobModeControls('active', 'return'));
    byId('active-job-multi-load').addEventListener('change', () => syncJobModeControls('active', 'multi'));
    byId('queue-list').addEventListener('click', (event) => {
      const transferButton = event.target.closest('button[data-prepare-queue-transfer]');
      const startButton = event.target.closest('button[data-start-queue-item]');
      const editButton = event.target.closest('button[data-edit-queue-item]');
      const requestButton = event.target.closest('button[data-request-queue-delete]');
      const confirmButton = event.target.closest('button[data-confirm-queue-delete]');
      const cancelButton = event.target.closest('button[data-cancel-queue-delete]');
      if (transferButton) {
        prepareQueueTransfer(transferButton.dataset.prepareQueueTransfer || '');
      } else if (startButton) {
        startQueueItem(startButton.dataset.startQueueItem || '');
      } else if (editButton) {
        editQueueItem(editButton.dataset.editQueueItem || '');
      } else if (requestButton) {
        requestQueueDelete(requestButton.dataset.requestQueueDelete || '');
      } else if (confirmButton) {
        confirmQueueDelete(confirmButton.dataset.confirmQueueDelete || '');
      } else if (cancelButton) {
        cancelQueueDelete(cancelButton.dataset.cancelQueueDelete || '');
      }
    });
    byId('sync-outbox-list').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-show-transfer-entry]');
      if (!button) return;
      const entry = syncOutboxDocument.find((candidate) => text(candidate.id) === text(button.dataset.showTransferEntry));
      showTransferEntry(entry);
    });
    byId('sync-copy-export').addEventListener('click', () => copyTextareaValue('sync-export-text', 'sync-export-status'));
    byId('sync-import-receipt').addEventListener('click', registerReceiptOnMobile);
    byId('sync-validate-transfer').addEventListener('click', validateInboundTransfer);
    byId('sync-confirm-import').addEventListener('click', confirmInboundTransfer);
    byId('sync-cancel-import').addEventListener('click', cancelInboundTransfer);
    byId('sync-copy-receipt').addEventListener('click', () => copyTextareaValue('sync-receipt-output', 'sync-receipt-copy-status'));
    byId('active-form').addEventListener('submit', createActiveJob);
    byId('active-phase-action').addEventListener('click', advanceActivePhase);
    byId('active-next-load').addEventListener('click', startNextActiveLoad);
    byId('active-return-start').addEventListener('click', startActiveReturn);
    byId('active-return-arrived').addEventListener('click', markActiveReturnArrived);
    byId('active-pause-action').addEventListener('click', toggleActivePause);
    byId('active-weight-submit').addEventListener('click', registerActiveWeight);
    byId('active-no-emptying').addEventListener('click', markActiveNoEmptying);
    byId('active-weight-input').addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === 'NumpadEnter') {
        event.preventDefault();
        if (registerActiveWeight()) {
          event.currentTarget.blur();
        }
      }
    });
    byId('active-complete-request').addEventListener('click', requestActiveComplete);
    byId('active-complete-without-weight').addEventListener('click', allowActiveCompleteWithoutWeight);
    byId('active-complete-cancel').addEventListener('click', cancelActiveComplete);
    byId('active-complete-confirm-button').addEventListener('click', confirmActiveComplete);
    byId('active-reset-request').addEventListener('click', requestActiveReset);
    byId('active-reset-cancel').addEventListener('click', cancelActiveReset);
    byId('active-reset-confirm-button').addEventListener('click', confirmActiveReset);
  }

  function verifyRuntime() {
    if (!watchdog) {
      throw new Error('Runtime-Watchdog saknas.');
    }
    watchdog.step('runtime.bootstrap.verify', 'Värdbrygga, CSS och versionskontrakt verifieras.');
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    if (!syncProtocol || typeof syncProtocol.createTransfer !== 'function' || typeof syncProtocol.parseReceipt !== 'function') {
      throw new Error('Modulen för kontrollerad överföring saknas.');
    }
    const styleReady = getComputedStyle(document.documentElement).getPropertyValue('--module-style-ready').trim();
    if (styleReady !== '1') {
      throw new Error('Modulens CSS kunde inte verifieras.');
    }
    hostInfo = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!hostInfo) {
      throw new Error('Värdinformationen kunde inte läsas.');
    }
    if (Number(hostInfo.hostVersionCode) < MINIMUM_HOST_VERSION) {
      throw new Error('Värdappen är för gammal för funktionspaket 25.');
    }
    if (Number(hostInfo.packageVersion) !== PACKAGE_VERSION) {
      throw new Error('Paketversionen i värdbryggan stämmer inte.');
    }
    if (Number(hostInfo.watchdogApiVersion) < 1) {
      throw new Error('Värdappens Watchdog-brygga saknas eller är för gammal.');
    }
    watchdog.setContext(hostInfo);
  }

  function start() {
    try {
      if (!watchdog) {
        throw new Error('Runtime-Watchdog kunde inte laddas.');
      }
      watchdog.step('runtime.bootstrap.start', 'Funktionspaket 25 startar.');
      verifyRuntime();
      validateRegistries();
      watchdog.step('runtime.sync.protocol.validated', 'Kööverföringsprotokoll och kontrollsummafunktion verifierades.');
      populateRegistryForms();
      refreshPlaceFormsForJobType('');
      refreshPlaceFormsForJobType('active-');
      syncJobModeControls('queue');
      syncJobModeControls('active');
      updateMaterialPanel('');
      updateMaterialPanel('active-');
      settingsDocument = readSettingsDocument();
      watchdog.step('runtime.ui.preferences', 'Sparade UI-inställningar tillämpas utan automatisk skrivning.');
      applyUiPreferences(normalizedUiPreferences(settingsDocument));
      renderHostInfo();
      applyRoleBoundaries();
      renderPreservedTestValue();
      installEventHandlers();
      refreshUpdateStatus();
      updatePollTimer = window.setInterval(refreshUpdateStatus, 2500);
      watchdog.ready();
      byId('watchdog-state').textContent = watchdog.getStatus();
      byId('watchdog-phase').textContent = watchdog.getLastPhase();
      window.StadslassHost.markReady(PACKAGE_VERSION);
    } catch (error) {
      if (watchdog) {
        watchdog.fail(error, 'runtime.bootstrap.failed');
      } else {
        const main = document.createElement('main');
        main.className = 'content';
        const heading = document.createElement('h1');
        heading.textContent = 'Modulen kunde inte starta';
        const body = document.createElement('p');
        body.textContent = error && error.message ? error.message : 'Okänt startfel.';
        main.append(heading, body);
        document.body.replaceChildren(main);
      }
    }
  }

  window.addEventListener('beforeunload', () => {
    if (updatePollTimer !== null) {
      window.clearInterval(updatePollTimer);
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
