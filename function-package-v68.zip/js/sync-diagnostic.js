(() => {
  'use strict';

  const PACKAGE_VERSION = 68;
  const SECRET = /token|authorization|password|secret|private|signature|credential/i;
  const STATUS = ['pending', 'running', 'succeeded', 'superseded', 'failed_permanent', 'failed_retryable', 'retryable', 'terminal'];
  const now = () => new Date().toISOString();
  const mono = () => typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value);
  const bytes = (value) => new TextEncoder().encode(typeof value === 'string' ? value : JSON.stringify(value || null)).length;
  const safeJson = (value) => { try { return JSON.parse(value); } catch (_) { return value; } };
  const compact = (value, limit = 2000) => { const valueText = text(value); return valueText.length > limit ? `${valueText.slice(0, limit)}… [avkortat]` : valueText; };
  const mask = (value, key = '') => {
    if (SECRET.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.map((item) => mask(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, mask(item, name)]));
    return typeof value === 'string' ? compact(value) : value;
  };
  const hash = (value) => {
    const source = text(value); let state = 2166136261;
    for (let index = 0; index < source.length; index += 1) { state ^= source.charCodeAt(index); state = Math.imul(state, 16777619); }
    return `fnv1a-${(state >>> 0).toString(16).padStart(8, '0')}`;
  };
  function create(environment) {
    const state = { startedAt: now(), firstRoleViewAt: '', inventoryStartedAt: '', inventoryFinishedAt: '', inventoryRunning: false, inventoryCount: 0, entryCount: 0, context: {}, events: [], registers: [], limitations: [], observed: 0 };
    const addLimitation = (value) => { const message = compact(value, 500); if (message && !state.limitations.includes(message)) state.limitations.push(message); };
    const event = (kind, details = {}) => {
      const value = mask({ at: now(), kind, ...details });
      state.events.push(value); state.observed += 1;
      if (state.events.length > 1000) state.events.shift();
      return value;
    };
    function register(name, raw, durationMs, source = 'package') {
      const parsed = typeof raw === 'string' ? safeJson(raw) : raw;
      const item = { name, source, available: raw !== undefined && raw !== null, durationMs: Math.round(durationMs), byteLength: bytes(raw || ''), hash: hash(raw || ''), value: mask(parsed) };
      state.registers = state.registers.filter((current) => current.name !== name);
      state.registers.push(item);
      return item;
    }
    function readStore(name) {
      const started = mono();
      try { return register(name, environment.readStore(name), mono() - started, 'host-store'); }
      catch (error) { addLimitation(`${name} kunde inte läsas: ${text(error && error.message, 'okänt fel')}`); return register(name, null, mono() - started, 'host-store'); }
    }
    function hostRead(name) {
      const host = environment.host();
      if (!host || typeof host[name] !== 'function') return false;
      const started = mono();
      try { register(`host.${name}`, host[name](), mono() - started, 'host-diagnostic'); return true; }
      catch (error) { addLimitation(`${name} kunde inte läsas: ${text(error && error.message, 'okänt fel')}`); return true; }
    }
    function extractRequests(value, found = [], seen = new Set()) {
      if (!value || typeof value !== 'object' || seen.has(value)) return found;
      seen.add(value);
      if (value.requestId || value.id && /sync|request/i.test(text(value.kind))) found.push(value);
      Object.values(value).forEach((item) => { if (item && typeof item === 'object') extractRequests(item, found, seen); });
      return found;
    }
    function requestStatuses() {
      const host = environment.host();
      if (!host || typeof host.getSyncRequestStatus !== 'function') { addLimitation('Värdappens läsande statusfunktion för enskilda synkposter saknas.'); return; }
      const outbox = state.registers.find((item) => item.name === 'syncOutbox');
      const candidates = extractRequests(outbox && outbox.value).filter((item, index, list) => item.requestId && list.findIndex((other) => other.requestId === item.requestId) === index);
      candidates.forEach((entry) => {
        const started = mono();
        try { register(`request.${entry.requestId}`, host.getSyncRequestStatus(text(entry.requestId)), mono() - started, 'host-request-status'); }
        catch (error) { addLimitation(`Status för ${text(entry.requestId)} kunde inte läsas: ${text(error && error.message, 'okänt fel')}`); }
      });
    }
    function inventory() {
      if (state.inventoryRunning) return { ok: false, status: 'already_running' };
      state.inventoryRunning = true; state.inventoryStartedAt = now(); state.inventoryCount += 1;
      const started = mono();
      try {
        ['syncOutbox', 'settings', 'queue', 'activeJob', 'history'].forEach((name) => readStore(name));
        // These are optional, explicitly read-only host diagnostics. Missing APIs are reported, never emulated.
        const supported = ['getSyncDiagnosticSnapshot', 'getSyncTransportSnapshot', 'getSyncQueueSnapshot', 'listSyncRequests', 'getSyncJournalSnapshot'];
        const readAny = supported.map(hostRead).some(Boolean);
        if (!readAny) addLimitation('Värdapp v16 exponerade ingen full läsande synkinventering. Rapporten innehåller därför de register och poststatusar som funktionspaketet kan läsa utan förändring.');
        requestStatuses();
        const outbox = state.registers.find((item) => item.name === 'syncOutbox');
        state.entryCount = extractRequests(outbox && outbox.value).length;
        event('inventory-complete', { registers: state.registers.length, entries: state.entryCount, durationMs: Math.round(mono() - started) });
        return { ok: true, status: 'completed' };
      } finally { state.inventoryFinishedAt = now(); state.inventoryRunning = false; }
    }
    function firstRoleView(context = {}) { state.context = mask({ ...state.context, ...context }); state.firstRoleViewAt = now(); event('role-view-ready', { role: text(context.role), order: 'before-inventory' }); setTimeout(inventory, 0); }
    function observe(kind, details = {}) { return event(kind, details); }
    function summary() {
      const entries = state.registers.flatMap((registerValue) => extractRequests(registerValue.value));
      const by = (field) => Object.entries(entries.reduce((result, entry) => { const key = text(entry[field], 'saknas'); result[key] = (result[key] || 0) + 1; return result; }, {}));
      return { entries, by };
    }
    function report() {
      const grouped = summary(); const lines = [];
      const add = (value = '') => lines.push(value);
      add('STADSLASS SYNKDIAGNOSRAPPORT'); add('Rapporttyp: Tillfällig läsande synkdiagnos'); add('');
      add('A. IDENTITET'); add(`Start: ${state.startedAt}`); add(`Slut: ${now()}`); add(`Värdapp: ${text(state.context.hostVersion, 'Saknas')}`); add(`Funktionspaket: ${PACKAGE_VERSION}`); add(`Roll: ${text(state.context.role, 'Saknas')}`); add(`Installations-ID: ${text(state.context.installationId, 'Saknas')}`); add(`Enhets-ID: ${text(state.context.deviceId, 'Saknas')}`); add(`Synkkonfiguration: ${JSON.stringify(mask(state.context.syncConfiguration || {}))}`); add('');
      add('B. SAMMANFATTNING'); add(`Inventerade register: ${state.registers.length}`); add(`Inventerade synkposter: ${grouped.entries.length}`); add(`Observerade trafikhändelser: ${state.observed}`); add(`Första rollvy: ${text(state.firstRoleViewAt, 'Saknas')}`); add(`Inventering: ${text(state.inventoryStartedAt, 'Inte startad')} → ${text(state.inventoryFinishedAt, 'Pågår')}`);
      [['intent', 'Intent'], ['operation', 'Operation'], ['status', 'Status'], ['priority', 'Priority'], ['coalesceKey', 'CoalesceKey'], ['path', 'Målfil'], ['createdRole', 'Skapande roll'], ['createdDeviceId', 'Skapande enhet']].forEach(([field, label]) => { add(`${label}: ${grouped.by(field).map(([key, count]) => `${key}=${count}`).join(', ') || 'Saknas'}`); }); add('');
      add('C. TRAFIK UNDER SESSIONEN'); state.events.forEach((item) => add(JSON.stringify(item))); add('');
      add('D. FULLSTÄNDIG POSTLISTA'); state.registers.forEach((item) => { add(`REGISTER: ${item.name} | Källa: ${item.source} | ${item.byteLength} byte | ${item.durationMs} ms | ${item.hash}`); add(JSON.stringify(item.value, null, 2)); add(''); });
      add('E. GRUPPERAD ANALYS'); const duplicateKeys = grouped.entries.reduce((result, entry) => { const key = [entry.operation, entry.path, entry.coalesceKey].map((value) => text(value, '-')).join('|'); (result[key] ||= []).push(entry); return result; }, {}); Object.entries(duplicateKeys).filter(([, values]) => values.length > 1).forEach(([key, values]) => add(`Dubblett: ${key} (${values.length})`)); grouped.entries.filter((entry) => text(entry.status) === 'superseded').forEach((entry) => add(`Superseded: ${text(entry.requestId)} ersatt av ${text(entry.supersededBy || entry.replacedBy, 'okänt')}`)); grouped.entries.filter((entry) => text(entry.status) === 'failed_permanent').forEach((entry) => add(`Failed permanent: ${text(entry.requestId)} | ${text(entry.errorCode)} | ${text(entry.error || entry.message)}`)); add('');
      add('F. TEKNISKA TIDSMÄTNINGAR'); state.registers.forEach((item) => add(`${item.name}: ${item.durationMs} ms`)); state.events.filter((item) => Number(item.durationMs) > 0).forEach((item) => add(`${item.kind}: ${item.durationMs} ms`)); add('');
      add('G. BEGRÄNSNINGAR'); if (!state.limitations.length) add('Inga kända läsbegränsningar.'); else state.limitations.forEach((item) => add(`- ${item}`));
      return lines.join('\n') + '\n';
    }
    return Object.freeze({ observe, inventory, firstRoleView, report, state: () => JSON.parse(JSON.stringify(mask(state))), entries: () => state.registers.slice(), mask });
  }
  window.StadslassSyncDiagnostic = Object.freeze({ create, mask, bytes, PACKAGE_VERSION });
})();
