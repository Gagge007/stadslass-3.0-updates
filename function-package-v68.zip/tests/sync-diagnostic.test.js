'use strict';
const assert = require('assert');
const { TextEncoder } = require('util');
global.TextEncoder = TextEncoder;
global.performance = { now: () => Date.now() };
global.setTimeout = (callback) => { callback(); return 1; };
global.window = { setTimeout: global.setTimeout };

const stores = {
  syncOutbox: JSON.stringify([
    { id: 'sync-v63-a', kind: 'sync-v63-request', requestId: 'a', intent: 'get-results', operation: 'GET', path: 'stadslass/command-results.json', priority: 2, state: 'pending', coalesceKey: 'get-results/189', token: 'must-not-leak' },
    { id: 'sync-v63-b', kind: 'sync-v63-request', requestId: 'b', intent: 'put-queue', operation: 'PUT', path: 'stadslass/shared-queue.json', priority: 1, state: 'superseded', replacedBy: 'c', authorization: 'must-not-leak' }
  ]),
  settings: JSON.stringify({ syncV63: { enabled: true, token: 'must-not-leak' } }), queue: '[]', activeJob: '{}', history: '[]'
};
const calls = [];
const host = {
  getSyncRequestStatus(requestId) { calls.push(`status:${requestId}`); return JSON.stringify({ requestId, status: requestId === 'a' ? 'failed_permanent' : 'superseded', errorCode: requestId === 'a' ? 'timeout' : '', token: 'must-not-leak' }); },
  getSyncTransportSnapshot() { calls.push('snapshot'); return JSON.stringify({ terminal: [{ requestId: 'terminal-1', status: 'succeeded', operation: 'PUT' }] }); },
  writeStore() { calls.push('WRITE'); throw new Error('diagnostic must not write'); }
};
require('../js/sync-diagnostic.js');
const diagnostic = window.StadslassSyncDiagnostic.create({ host: () => host, readStore: (name) => { calls.push(`read:${name}`); return stores[name]; } });
diagnostic.firstRoleView({ hostVersion: 'v16', role: 'mobile', installationId: 'install-1', deviceId: 'device-1', syncConfiguration: { token: 'must-not-leak', repository: 'Lastbils-app' } });
const state = diagnostic.state();
assert.strictEqual(state.inventoryRunning, false);
assert(state.registers.length >= 7, 'all readable stores and host snapshots must be recorded');
assert(calls.includes('read:syncOutbox'));
assert(calls.includes('status:a') && calls.includes('status:b'));
assert(!calls.includes('WRITE'), 'diagnostic must never write a sync store');
const report = diagnostic.report();
assert(report.includes('STADSLASS SYNKDIAGNOSRAPPORT'));
assert(report.includes('A. IDENTITET') && report.includes('G. BEGRÄNSNINGAR'));
assert(!report.includes('STADSLASS PRESTANDARAPPORT'));
assert(!report.includes('must-not-leak'), 'secrets must be masked in every report section');
assert.strictEqual(diagnostic.inventory().ok, true);
console.log('PASS sync-diagnostic.test.js (11 assertions)');
