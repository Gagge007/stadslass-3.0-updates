#!/usr/bin/env python3
import asyncio
import json
import re
import shutil
from integration_app import async_playwright, new_page, app_click, wait_eval

ACTIVE_REQUEST = {
    'id': 'request-active-v72',
    'kind': 'sync-v63-request',
    'requestId': 'request-active-v72',
    'intent': 'get-active',
    'state': 'accepted',
    'createdAt': '2026-08-03T03:40:00.000Z',
    'updatedAt': '2026-08-03T03:41:00.000Z',
    'request': {
        'operation': 'GET',
        'path': 'stadslass-3-sync/vehicles/189/active-status.json',
        'coalesceKey': 'get-active/189'
    }
}

async def open_sync_settings(page):
    await app_click(page.locator('button[data-target="settings"]'))
    await app_click(page.locator('button[data-settings-group="import-extra"]'))
    await app_click(page.locator('button[data-settings-function="sync"]'))

async def run():
    if async_playwright is None:
        print(json.dumps({'status':'EJ_KORBAR_I_INTERN_MILJO','reason':'Python Playwright saknas.'}, ensure_ascii=False))
        return
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, executable_path=shutil.which('chromium'), args=['--no-sandbox'])
        context, page, errors = await new_page(browser, {}, sync_outbox=[ACTIVE_REQUEST])
        await page.set_viewport_size({'width': 390, 'height': 844})
        await open_sync_settings(page)

        # Before a completed test, report fields exist but are empty and report actions are disabled.
        assert await page.locator('#performance-report-text').input_value() == ''
        assert await page.locator('#sync-report-textarea').input_value() == ''
        for selector in ['#performance-report-copy','#performance-report-download','#performance-report-mail','#performance-report-clear','#sync-report-copy','#sync-report-download','#sync-report-mail','#sync-report-clear']:
            assert await page.locator(selector).is_disabled(), selector

        await page.locator('#report-mail-email').fill('rapport@example.se')
        await app_click(page.locator('#report-mail-save'))
        assert (await page.locator('#report-mail-status').inner_text()) == 'Rapportmottagaren är sparad lokalt.'

        outbox_before = await page.evaluate('JSON.stringify(window.__hostState.stores.syncOutbox)')
        await app_click(page.locator('#sync-diagnostic-rerun'))
        await wait_eval(page, "() => document.getElementById('sync-report-textarea').value.startsWith('STADSLASS SYNKVERIFIERINGSRAPPORT')")
        sync_text = await page.locator('#sync-report-textarea').input_value()
        assert 'Funktionspaket: 97' in sync_text
        assert 'STADSLASS PRESTANDARAPPORT' not in sync_text
        assert await page.evaluate("Boolean(window.__hostState.stores.settings.syncReportSnapshotV1)")
        assert await page.evaluate('JSON.stringify(window.__hostState.stores.syncOutbox)') == outbox_before

        await app_click(page.locator('#sync-report-copy'))
        sync_copy = (await page.evaluate('window.__hostState.copies'))[-1]
        assert sync_copy['text'] == sync_text

        await app_click(page.locator('#sync-report-download'))
        sync_export = (await page.evaluate('window.__hostState.textExports'))[-1]
        assert re.fullmatch(r'synkrapport_v73_\d{4}-\d{2}-\d{2}_\d{6}\.txt', sync_export['fileName']), sync_export['fileName']
        assert sync_export['contentUtf8'] == sync_text
        await page.evaluate("requestId => window.dispatchEvent(new CustomEvent('stadslass:text-export-result',{detail:{requestId,status:'saved'}}))", sync_export['requestId'])
        assert (await page.locator('#sync-diagnostic-status').inner_text()) == 'Synkrapport sparad.'

        await app_click(page.locator('#sync-report-mail'))
        sync_mail = (await page.evaluate('window.__hostState.emailDrafts'))[-1]
        assert sync_mail['recipient'] == 'rapport@example.se'
        assert sync_mail['attachment']['fileName'] == sync_export['fileName']
        assert sync_mail['attachment']['mimeType'] == 'text/plain'
        assert sync_mail['attachment']['contentUtf8'] == sync_text
        assert sync_text not in sync_mail['body']

        # The automatically started performance test creates its report only when stopped.
        await app_click(page.locator('#performance-monitor-stop'))
        await wait_eval(page, "() => document.getElementById('performance-report-text').value.startsWith('STADSLASS PRESTANDARAPPORT')")
        performance_text = await page.locator('#performance-report-text').input_value()
        assert 'Funktionspaket: 97' in performance_text
        assert 'STADSLASS SYNKVERIFIERINGSRAPPORT' not in performance_text
        assert await page.evaluate("Boolean(window.__hostState.stores.settings.performanceReportSnapshotV1)")

        await app_click(page.locator('#performance-report-download'))
        perf_export = (await page.evaluate('window.__hostState.textExports'))[-1]
        assert re.fullmatch(r'prestandarapport_v73_\d{4}-\d{2}-\d{2}_\d{6}\.txt', perf_export['fileName']), perf_export['fileName']
        assert perf_export['contentUtf8'] == performance_text
        await page.evaluate("requestId => window.dispatchEvent(new CustomEvent('stadslass:text-export-result',{detail:{requestId,status:'saved'}}))", perf_export['requestId'])
        assert (await page.locator('#performance-report-status').inner_text()) == 'Prestandarapport sparad.'

        await app_click(page.locator('#performance-report-mail'))
        perf_mail = (await page.evaluate('window.__hostState.emailDrafts'))[-1]
        assert perf_mail['attachment']['fileName'] == perf_export['fileName']
        assert perf_mail['attachment']['contentUtf8'] == performance_text
        assert performance_text not in perf_mail['body']

        stored_settings = await page.evaluate('JSON.parse(JSON.stringify(window.__hostState.stores.settings))')
        assert errors == [], errors
        await context.close()

        # Both independent reports survive a full app restart and are restored into their text areas.
        context, page, errors = await new_page(browser, {}, settings=stored_settings, sync_outbox=[ACTIVE_REQUEST])
        await page.set_viewport_size({'width': 390, 'height': 844})
        await open_sync_settings(page)
        assert await page.locator('#sync-report-textarea').input_value() == sync_text
        assert await page.locator('#performance-report-text').input_value() == performance_text
        assert await page.locator('#report-mail-email').input_value() == 'rapport@example.se'

        # A failed save dialog does not recreate or lose the already completed report.
        await page.evaluate("() => { window.StadslassHost.requestTextFileExport = raw => { const value=JSON.parse(raw); window.__hostState.failedExport=value; return JSON.stringify({ok:false,status:'dialog_error',requestId:value.requestId}); }; }")
        await app_click(page.locator('#performance-report-download'))
        assert await page.locator('#performance-report-text').input_value() == performance_text
        assert await page.evaluate("Boolean(window.__hostState.stores.settings.performanceReportSnapshotV1)")
        assert 'Rapporten finns kvar' in await page.locator('#performance-report-status').inner_text()

        # Clearing one report view only removes that report snapshot.
        await app_click(page.locator('#sync-report-clear'))
        assert await page.locator('#sync-report-textarea').input_value() == ''
        assert await page.locator('#performance-report-text').input_value() == performance_text
        assert not await page.evaluate("Boolean(window.__hostState.stores.settings.syncReportSnapshotV1)")
        assert await page.evaluate("Boolean(window.__hostState.stores.settings.performanceReportSnapshotV1)")
        assert await page.evaluate('JSON.stringify(window.__hostState.stores.syncOutbox)') == outbox_before

        await page.evaluate("document.getElementById('sync-diagnostic-summary').textContent='X'.repeat(1200)")
        width = await page.evaluate("({inner:window.innerWidth, html:document.documentElement.scrollWidth, body:document.body.scrollWidth})")
        assert width['html'] <= width['inner'], width
        assert width['body'] <= width['inner'], width
        assert errors == [], errors
        await context.close()
        await browser.close()
    print(json.dumps({'status':'PASS','tests':['empty-before-test','sync-test-to-readonly-report','separate-copy-download-mail','real-txt-mail-attachment','persistent-after-restart','failed-export-preserves-report','independent-clear','read-only-sync-data','mobile-width']}, ensure_ascii=False))

if __name__ == '__main__':
    asyncio.run(run())
