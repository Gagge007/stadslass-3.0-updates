const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const context = {
  window: {
    StadslassRegistries: {
      jobSchema: { jobModelVersion: 4 },
      jobTypes: { conditionalRules: [{ id: 'MR-REMOVED', jobTypeId: 'JT-A', fromPlaceId: 'PL-REMOVED', facilityPlaceId: 'PL-FACILITY' }] }
    }
  },
  Object, Array, Set, String, Boolean, RegExp, Error, Date, Uint32Array
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', 'job-model.js'), 'utf8'), context);
const model = context.window.StadslassJobModel;
model.initializeJobTypes([{ id: 'JT-A', canonicalTypeId: 'JT-A', name: 'Test' }]);
model.initializePlaces([{ id: 'PL-FACILITY', name: 'Kvarvarande plats' }]);
assert.doesNotThrow(() => model.validateRegistries());
assert.strictEqual(model.conditionalRuleAvailable(model.conditionalRules[0]), false);
assert.strictEqual(model.suggestedDestination('JT-A', 'PL-REMOVED'), '');
assert.strictEqual(JSON.stringify(model.deriveMaterial('JT-A', 'PL-REMOVED', '')), JSON.stringify({ code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' }));
console.log('PASS v96-removed-place-material-rule.test.js');
