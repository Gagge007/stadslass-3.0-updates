(() => {
  'use strict';

  const PACKAGE_VERSION = 113;
  const JOB_MODEL_VERSION = 4;
  const MINIMUM_HOST_VERSION = 20;
  const SETTINGS_STORE = 'settings';
  const QUEUE_STORE = 'queue';
  const ACTIVE_JOB_STORE = 'activeJob';
  const HISTORY_STORE = 'history';
  const SYNC_OUTBOX_STORE = 'syncOutbox';
  const UI_SETTINGS_KEY = 'uiPreferencesV1';
  const PHASE_COLOR_SETTINGS_KEY = 'phaseColorsV1';
  const PERFORMANCE_REPORT_SNAPSHOT_KEY = 'performanceReportSnapshotV1';
  const SYNC_REPORT_SNAPSHOT_KEY = 'syncReportSnapshotV1';
  const REPORT_SNAPSHOT_SCHEMA_VERSION = 1;
  const PAGE_TITLES = Object.freeze({ home: 'Start', queue: 'Kö', quickChoices: 'Snabbval', active: 'Aktivt jobb', today: 'Idag', history: 'Historik', trash: 'Papperskorg', statistics: 'Sammanställning', sync: 'Syncstatus', settings: 'Inställningar' });
  const ACTIVE_STATUSES = Object.freeze(['active', 'paused', 'completing']);
  const ACTIVE_PHASES = Object.freeze(['start_route', 'loading', 'transport', 'unloading', 'load_registered', 'return_transport', 'return_unloading', 'ready_to_complete', 'other_activity', 'returning']);
  const watchdog = window.StadslassWatchdog || null;
  const syncProtocol = window.StadslassSyncProtocol || null;
  const syncServiceApi = window.StadslassSyncService || null;
  const DRIFT_SYNC_ENABLED = Boolean(syncServiceApi && syncServiceApi.OPERATIONAL_SYNC_ENABLED === true);
  const mailService = window.StadslassMailService || null;
  const syncDiagnosticApi = window.StadslassSyncDiagnostic || null;
  const performanceMonitorApi = window.StadslassPerformanceMonitor || null;
  const editableJobTypeApi = window.StadslassJobTypeRegistry || null;
  const googleService = window.StadslassGoogleService || null;
  const editablePlaceApi = window.StadslassPlaceRegistry || null;
  const editableBeachApi = window.StadslassBeachRegistry || null;
  const gpsService = window.StadslassGpsService || null;
  const geofenceService = window.StadslassGeofenceService || null;
  const phaseService = window.StadslassPhaseService || null;
  const phaseActionService = window.StadslassPhaseActionService || null;
  const phaseVisualService = window.StadslassPhaseVisualService || null;
  const temporaryPlaceService = window.StadslassTemporaryPlaceService || null;
  const ataApi = window.StadslassAta || null;
  const ataBillingApi = window.StadslassAtaBilling || null;
  const ataNotificationApi = window.StadslassAtaNotificationSettings || null;
  const ataRouting = window.StadslassAtaRouting || null;
  const ataMailApi = window.StadslassAtaMailUnderlag || null;
  const registries = window.StadslassRegistries || null;
  const quickChoiceApi = window.StadslassQuickChoiceRegistry || null;
  const backupApi = window.StadslassBackupService || null;
  const baselineJobTypeItems = registries && registries.jobTypes && Array.isArray(registries.jobTypes.items) ? registries.jobTypes.items : [];
  let jobTypeItems = [];
  let jobTypeModelInitialized = false;
  const basePlaceItems = registries && registries.places && Array.isArray(registries.places.items) ? registries.places.items : [];
  let placeItems = [];
  const materialConditionalRules = registries && registries.jobTypes && Array.isArray(registries.jobTypes.conditionalRules) ? registries.jobTypes.conditionalRules : [];

  let hostInfo = null;
  let settingsDocument = {};
  let placeModelInitialized = false;
  let googleSettings = null;
  let googleDiagnostics = null;
  let editableJobTypeRegistry = null;
  let editableJobTypeRegistryError = '';
  let editingEditableJobTypeId = '';
  let editablePlaceRegistry = null;
  let editablePlaceRegistryError = '';
  let editingEditablePlaceId = '';
  let editableBeachRegistry = null;
  let editableBeachRegistryError = '';
  let editableBeachRegistryReadOnly = false;
  let editingEditableBeachId = '';
  let quickChoiceRegistry = null;
  let quickChoiceRegistryError = '';
  let editingQuickChoiceId = '';
  let pendingQuickChoiceFallbackItem = null;
  let pendingQuickChoiceFallbackId = '';
  let quickChoiceActionInProgress = false;
  let quickChoiceActionLockedUntil = 0;
  let quickChoiceLastActionKey = '';
  let queueDocument = [];
  let queueLoaded = false;
  let pendingQueueDeleteId = '';
  let editingQueueId = '';
  let activeJobDocument = {};
  let activeJobLoaded = false;
  let pendingActiveReset = false;
  let pendingActiveComplete = false;
  let pendingWeightlessCompletion = false;
  let completionCandidateAt = '';
  let ataBillingDialogOpen = false;
  let ataBillingDraft = null;
  let ataBillingActionInProgress = false;
  let ataBillingBackGuardActive = false;
  let ataBillingBackGuardClosing = false;
  let ataMailDialogContext = null;
  let ataMailActionInProgress = false;
  let ataNotificationPendingAction = null;
  let ataNotificationTemplateTimer = null;
  let loadRegisteredTimer = null;
  let loadRegisteredTimerJobId = '';
  let loadRegisteredTimerUntil = '';
  let historyDocument = [];
  let historyLoaded = false;
  let pendingHistoryTrashId = '';
  let editingHistoryBillingId = '';
  let historyBillingOperationId = '';
  let pendingTrashPermanentDeleteId = '';
  let historySelectedMonth = '';
  let historySelectedDate = '';
  let syncOutboxDocument = [];
  let syncOutboxLoaded = false;
  let syncV63 = null;
  let syncDiagnostic = null;
  let performanceMonitor = null;
  let performanceReportSnapshot = null;
  let syncReportSnapshot = null;
  const liveReportExports = new Map();
  let syncV69CycleRunning = false;
  let syncV69CycleQueued = false;
  let syncV66LastRunAt = 0;
  let syncV87ManualSyncRunning = false;
  let syncV87ClearConfirmationOpen = false;
  let syncV66RoleRefreshTimer = null;
  let syncV65LastConfigDiagnostic = null;
  let syncV63Timer = null;
  let syncV63PollTimer = null;
  const syncV85Timers = new Map();
  let syncV85HandshakeSequence = 0;
  let syncV85HandshakeState = { lastPingAt: '', lastReplyAt: '', lastPingSequence: 0, lastReplySequence: 0, lastError: '', contactConfirmed: false };
  let syncV92BingSequence = 0;
  let pendingBackupPreview = null;
  let syncV92BingState = { lastBingAt: '', lastBingSequence: 0, lastReplyAt: '', lastReplySequence: 0, lastError: '', contactConfirmed: false };
  let syncV63ActiveSequence = 0;
  let syncV63QueueRevision = 0;
  let syncV63LastActiveSequence = 0;
  let validatedInboundTransfer = null;
  let updatePollTimer = null;
  let runtimeDisposed = false;
  let runtimeFailed = false;
  let historyTrashOperationId = '';
  let bottomNavResizeObserver = null;
  let bottomNavLayoutFrame = null;
  let activeSettingsGroup = '';
  let activeSettingsFunction = '';
  let currentView = 'home';
  let unsubscribeGpsSnapshot = null;
  let unsubscribeGeofenceEvents = null;
  let handlingGeofenceEvent = false;
  let activeJobStartInProgress = false;
  let gpsRuntimeReady = false;
  let geofenceRuntimeReady = false;
  let temporaryPlaceFormStates = null;
  const PRESS_DELAY_MS = 500;
  const pendingPressActions = new Map();

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function parseObject(raw, fallback = {}) {
    try {
      const value = JSON.parse(raw);
      return isPlainObject(value) ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }


  const jobModel = window.StadslassJobModel || null;
  const findJobTypeById = (...args) => jobModel.findJobTypeById(...args);
  const findPlaceById = (...args) => jobModel.findPlaceById(...args);
  const deriveMaterial = (...args) => jobModel.deriveMaterial(...args);
  const stableJobId = (...args) => jobModel.stableJobId(...args);
  const normalizeJobRecord = (...args) => jobModel.normalizeJobRecord(...args);
  const isOtherActivityJobType = (...args) => jobModel.isOtherActivityJobType(...args);
  const canonicalJobTypeId = (...args) => jobModel.canonicalJobTypeId(...args);
  const systemJobPolicy = window.StadslassSystemJobPolicy || null;

  function isOtherActivity(documentValue) {
    return isPlainObject(documentValue) && isOtherActivityJobType(text(documentValue.jobTypeId));
  }

  function isMachineTransportJobType(value) {
    const type = typeof value === 'string' ? findJobTypeById(value) : value;
    return (systemJobPolicy && systemJobPolicy.isMachineTransport(type)) || canonicalJobTypeId(type) === 'JT-1011';
  }

  function normalizedMachineItems() {
    const items = Array.isArray(settingsDocument && settingsDocument.machines) ? settingsDocument.machines : [];
    return items.filter(isPlainObject).map((item, index) => ({
      id: text(item.id, `machine-${index}`), name: text(item.name), workshopPlaceId: text(item.workshopPlaceId), weight: Number(item.weight)
    })).filter((item) => item.id && item.name);
  }

  function machineSnapshot(id) {
    const machine = normalizedMachineItems().find((item) => item.id === text(id));
    return machine ? { id: machine.id, name: machine.name, workshopPlaceId: machine.workshopPlaceId, weight: Number.isFinite(machine.weight) && machine.weight >= 0 ? machine.weight : null } : null;
  }

  function refreshMachineSelect(scope) {
    const prefix = scope === 'active' ? 'active-job-' : 'job-';
    const select = byId(`${prefix}machine`); const panel = byId(`${prefix}machine-panel`);
    if (!select || !panel) return;
    const selectedType = findJobTypeById(byId(`${prefix}type`).value);
    const previous = select.value;
    panel.hidden = !isMachineTransportJobType(selectedType);
    select.replaceChildren();
    const none = document.createElement('option'); none.value = ''; none.textContent = 'Ingen maskin'; select.appendChild(none);
    normalizedMachineItems().forEach((machine) => { const option = document.createElement('option'); option.value = machine.id; option.textContent = machine.name; select.appendChild(option); });
    if (Array.from(select.options).some((option) => option.value === previous)) select.value = previous;
  }

  function applyEffectiveJobTypeRegistry(items) {
    jobTypeItems = (Array.isArray(items) ? items : []).map((item) => systemJobPolicy && systemJobPolicy.apply ? systemJobPolicy.apply(item) : item).slice().sort((a, b) => text(a && a.name).localeCompare(text(b && b.name), 'sv-SE', { sensitivity: 'base' }));
    if (!jobTypeModelInitialized) {
      jobModel.initializeJobTypes(jobTypeItems);
      jobTypeModelInitialized = true;
    } else {
      jobModel.replaceJobTypes(jobTypeItems);
    }
  }

  function refreshRuntimeJobTypeSelects() {
    const ids = ['job-type', 'active-job-type'];
    const values = ids.map((id) => byId(id).value);
    populateSelect('job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('active-job-type', jobTypeItems, 'Välj jobbtyp');
    ids.forEach((id, index) => {
      if (Array.from(byId(id).options).some((option) => option.value === values[index])) byId(id).value = values[index];
    });
    refreshMachineSelect('queue');
    refreshMachineSelect('active');
  }

  function refreshQuickChoiceJobTypeSelect() {
    const select = byId('quick-choice-registry-job-type');
    if (!select) return;
    const previous = select.value;
    populateSelect('quick-choice-registry-job-type', jobTypeItems, 'Välj Jobbtyp');
    if (selectContainsValue(select, previous)) select.value = previous;
    populateQuickChoicePlaceOptions();
    syncQuickChoiceFormControls();
    renderQuickChoiceRegistry();
    renderQuickChoices();
  }

  function validateRegistries() {
    if (!jobModel
      || typeof jobModel.initializeJobTypes !== 'function'
      || typeof jobModel.replaceJobTypes !== 'function'
      || typeof jobModel.canonicalJobTypeId !== 'function'
      || typeof jobModel.initializePlaces !== 'function'
      || typeof jobModel.replacePlaces !== 'function'
      || typeof jobModel.getPlaceItems !== 'function'
      || typeof jobModel.validateRegistries !== 'function') {
      throw new Error('Uppdragsmodellens kodmodul saknas eller stöder inte den effektiva platslistan.');
    }
    const result = jobModel.validateRegistries();
    watchdog.step('runtime.registry.validated', `${result.jobTypeCount} jobbtyper och ${result.placeCount} platser verifierades.`);
  }

  function populateSelect(selectId, items, emptyLabel, role = '') {
    const select = byId(selectId);
    select.replaceChildren();
    const empty = document.createElement('option');
    empty.value = '';
    empty.textContent = emptyLabel;
    select.appendChild(empty);
    items.filter((item) => item && item.active !== false && item.hidden !== true)
      .filter((item) => !role || !Array.isArray(item.roles) || item.roles.includes(role)).forEach((item) => {
      const option = document.createElement('option');
      option.value = text(item.id);
      option.textContent = text(item.name);
      select.appendChild(option);
    });
  }

  function activeSortedPlaces() {
    return placeItems
      .filter((item) => item && item.active !== false && item.hidden !== true)
      .slice()
      .sort((a, b) => text(a && a.name).localeCompare(text(b && b.name), 'sv-SE', { sensitivity: 'base' }));
  }

  function isBeachPlace(item) {
    const roles = item && Array.isArray(item.roles) ? item.roles : [];
    return Boolean(item && (item.category === 'badplats' || roles.includes('beach')));
  }

  function jobTypeIdentityIds(jobTypeId) {
    const identities = new Set();
    const rawId = text(jobTypeId);
    if (rawId) identities.add(rawId);
    const item = findJobTypeById(rawId);
    if (item) {
      identities.add(text(item.id));
      identities.add(text(item.canonicalTypeId));
    }
    identities.delete('');
    return identities;
  }

  function placeSupportsJobTypeRole(item, jobTypeId, role) {
    const jobType = findJobTypeById(jobTypeId);
    if (!item || !jobType || isOtherActivityJobType(jobType)) return false;
    const canonical = canonicalJobTypeId(jobType);
    if (isBeachPlace(item)) {
      const allowedIds = Array.isArray(item.allowedJobTypeIds) ? item.allowedJobTypeIds : [];
      const allowedForHavstang = allowedIds.length === 0 || allowedIds.includes('JT-1010') || allowedIds.includes(text(jobType.id));
      return canonical === 'JT-1010' && allowedForHavstang && (role === 'from' || role === 'destination');
    }
    const identities = jobTypeIdentityIds(jobType.id);
    const linkedIds = role === 'from'
      ? (Array.isArray(item.jobTypeFromIds) ? item.jobTypeFromIds : [])
      : (Array.isArray(item.jobTypeToIds) ? item.jobTypeToIds : []);
    return linkedIds.some((id) => identities.has(text(id)));
  }

  function placesForJobType(jobTypeId, role) {
    if (role !== 'from' && role !== 'destination') return [];
    return activeSortedPlaces().filter((item) => placeSupportsJobTypeRole(item, jobTypeId, role));
  }

  const MACHINE_TRANSPORT_ALWAYS_AVAILABLE_PLACE_IDS = new Set(['PL-1001', 'PL-1005']);

  function machineTransportPlacesForMachine(jobType, role, machineId) {
    const places = placesForJobType(jobType.id, role);
    if (!isMachineTransportJobType(jobType)) return places;
    const machine = machineSnapshot(machineId);
    if (!machine || !machine.workshopPlaceId) return places;
    const allowedIds = new Set([...MACHINE_TRANSPORT_ALWAYS_AVAILABLE_PLACE_IDS, machine.workshopPlaceId]);
    return places.filter((place) => allowedIds.has(text(place.id)));
  }

  function returnPlaces() {
    return activeSortedPlaces().filter((item) => {
      const roles = Array.isArray(item.roles) ? item.roles : [];
      return item.canBeReturnPlace === true || roles.includes('return');
    });
  }

  function selectContainsValue(select, value) {
    return Boolean(value) && Array.from(select.options).some((option) => option.value === value);
  }

  function populateRegistryForms() {
    populateSelect('job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('job-from', [], 'Välj jobbtyp först');
    populateSelect('job-destination', [], 'Välj jobbtyp först');
    populateSelect('job-return', returnPlaces(), 'Ingen returplats', 'return');
    populateSelect('active-job-type', jobTypeItems, 'Välj jobbtyp');
    populateSelect('active-job-from', [], 'Välj jobbtyp först');
    populateSelect('active-job-destination', [], 'Välj jobbtyp först');
    populateSelect('active-job-return', returnPlaces(), 'Ingen returplats', 'return');
  }

  function refreshPlaceFormsForJobType(prefix) {
    const jobTypeId = byId(`${prefix}job-type`).value;
    const jobType = findJobTypeById(jobTypeId);
    const routeEnabled = Boolean(jobType && !isOtherActivityJobType(jobType));
    const machineId = byId(`${prefix}job-machine`).value;
    const fromPlaces = routeEnabled ? machineTransportPlacesForMachine(jobType, 'from', machineId) : [];
    const destinationPlaces = routeEnabled ? machineTransportPlacesForMachine(jobType, 'destination', machineId) : [];
    const fromSelect = byId(`${prefix}job-from`);
    const destinationSelect = byId(`${prefix}job-destination`);
    const returnSelect = byId(`${prefix}job-return`);
    const previousFrom = fromSelect.value;
    const previousDestination = destinationSelect.value;
    const previousReturn = returnSelect.value;
    const fromLabel = !routeEnabled ? 'Välj jobbtyp först' : 'Välj Från';
    const destinationLabel = !routeEnabled ? 'Välj jobbtyp först' : 'Välj Till';
    populateSelect(fromSelect.id, fromPlaces, fromLabel, 'from');
    populateSelect(destinationSelect.id, destinationPlaces, destinationLabel, 'destination');
    if (routeEnabled) {
      appendTemporaryPlaceOption(fromSelect, 'from');
      appendTemporaryPlaceOption(destinationSelect, 'destination');
    }
    populateSelect(returnSelect.id, returnPlaces(), 'Ingen returplats', 'return');
    fromSelect.disabled = !routeEnabled;
    destinationSelect.disabled = !routeEnabled;
    if (selectContainsValue(fromSelect, previousFrom)) fromSelect.value = previousFrom;
    if (selectContainsValue(destinationSelect, previousDestination)) destinationSelect.value = previousDestination;
    if (selectContainsValue(returnSelect, previousReturn)) returnSelect.value = previousReturn;
    syncTemporaryPlacePanels(prefix === 'active-' ? 'active' : 'queue');
  }

  function applySuggestedDestination(prefix) {
    const jobTypeId = byId(`${prefix}job-type`).value;
    const fromPlaceId = byId(`${prefix}job-from`).value;
    const destination = byId(`${prefix}job-destination`);
    const suggested = jobModel.suggestedDestination(jobTypeId, fromPlaceId);
    if (suggested && !destination.value) destination.value = suggested;
  }

  function updateMaterialPanel(prefix) {
    const scope = prefix === 'active-' ? 'active' : 'queue';
    const fromPlace = resolveFormPlaceSelection(scope, 'from');
    const destinationPlace = resolveFormPlaceSelection(scope, 'destination');
    const material = deriveMaterialForSelections(byId(`${prefix}job-type`).value, fromPlace, destinationPlace);
    byId(`${prefix}job-material-code`).textContent = material.code || 'Ej aktuell';
    byId(`${prefix}job-material-facility`).textContent = material.facilityPlaceName || 'Ej fastställd';
  }


  function temporaryScope(scope) {
    return scope === 'active' ? 'active' : 'queue';
  }

  function temporaryPrefix(scope) {
    return temporaryScope(scope) === 'active' ? 'active-job' : 'job';
  }

  function ensureTemporaryPlaceFormStates() {
    if (temporaryPlaceFormStates) return temporaryPlaceFormStates;
    temporaryPlaceFormStates = {
      queue: {
        from: { place: temporaryPlaceService.emptyPlace('from'), checking: false, requestToken: 0 },
        destination: { place: temporaryPlaceService.emptyPlace('destination'), checking: false, requestToken: 0 }
      },
      active: {
        from: { place: temporaryPlaceService.emptyPlace('from'), checking: false, requestToken: 0 },
        destination: { place: temporaryPlaceService.emptyPlace('destination'), checking: false, requestToken: 0 }
      }
    };
    return temporaryPlaceFormStates;
  }

  function temporaryFormState(scope, role) {
    const states = ensureTemporaryPlaceFormStates();
    return states[temporaryScope(scope)][role === 'destination' ? 'destination' : 'from'];
  }

  function temporaryFormElements(scope, role) {
    const prefix = temporaryPrefix(scope);
    const roleKey = role === 'destination' ? 'destination' : 'from';
    return {
      select: byId(`${prefix}-${roleKey}`),
      panel: byId(`${prefix}-temporary-${roleKey}-panel`),
      name: byId(`${prefix}-temporary-${roleKey}-name`),
      address: byId(`${prefix}-temporary-${roleKey}-address`),
      status: byId(`${prefix}-temporary-${roleKey}-status`),
      check: byId(`${prefix}-temporary-${roleKey}-check`),
      clear: byId(`${prefix}-temporary-${roleKey}-clear`)
    };
  }

  function temporarySelectionActive(scope, role) {
    const elements = temporaryFormElements(scope, role);
    return Boolean(elements.select && temporaryPlaceService.isTemporarySelection(elements.select.value, role));
  }

  function renderTemporaryPlaceStatus(scope, role, message = '', isError = false) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (!elements.status || !elements.panel) return;
    const place = temporaryPlaceService.normalizePlace(state.place, role);
    let detail = text(message);
    let error = isError;
    if (!detail) {
      if (place.coordinateValid) {
        detail = `${place.normalizedAddress} · Tillfälligt geofence 80 meter är klart.`;
      } else if (place.errorMessage) {
        detail = place.errorMessage;
        error = true;
      } else if (place.addressOrPlusCode) {
        detail = 'Adressen är inte kontrollerad. Tryck Kontrollera adress/Plus Code för att aktivera geofence.';
      } else {
        detail = 'Ingen adresskontroll har gjorts.';
      }
    }
    elements.status.textContent = detail;
    elements.status.classList.toggle('is-error', error);
    elements.panel.classList.toggle('is-resolved', place.coordinateValid);
    elements.panel.classList.toggle('is-invalidated', !place.coordinateValid && Boolean(place.addressOrPlusCode));
  }

  function syncTemporaryPlaceStateFromInputs(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (!elements.name || !elements.address) return state.place;
    let place = temporaryPlaceService.withName(state.place, elements.name.value, new Date().toISOString());
    if (text(elements.address.value) !== text(place.addressOrPlusCode)) {
      state.requestToken += 1;
      state.checking = false;
      place = temporaryPlaceService.invalidatePlace(place, elements.address.value, new Date().toISOString());
    }
    state.place = place;
    return place;
  }

  function syncTemporaryPlacePanel(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (!elements.panel) return;
    const visible = temporarySelectionActive(scope, role);
    elements.panel.hidden = !visible;
    if (!visible) return;
    const place = temporaryPlaceService.normalizePlace(state.place, role);
    state.place = place;
    elements.name.value = place.temporaryPlaceName;
    elements.address.value = place.addressOrPlusCode;
    elements.check.disabled = state.checking;
    renderTemporaryPlaceStatus(scope, role);
  }

  function syncTemporaryPlacePanels(scope) {
    syncTemporaryPlacePanel(scope, 'from');
    syncTemporaryPlacePanel(scope, 'destination');
  }

  function resetTemporaryPlaceForm(scope) {
    const states = ensureTemporaryPlaceFormStates()[temporaryScope(scope)];
    for (const role of ['from', 'destination']) {
      states[role].requestToken += 1;
      states[role].checking = false;
      states[role].place = temporaryPlaceService.emptyPlace(role);
      const elements = temporaryFormElements(scope, role);
      if (elements.name) elements.name.value = '';
      if (elements.address) elements.address.value = '';
      if (elements.check) elements.check.disabled = false;
      if (elements.status) {
        elements.status.textContent = 'Ingen adresskontroll har gjorts.';
        elements.status.classList.remove('is-error');
      }
      if (elements.panel) {
        elements.panel.classList.remove('is-resolved', 'is-invalidated');
      }
    }
    syncTemporaryPlacePanels(scope);
  }

  function loadTemporaryPlaceForm(scope, documentValue) {
    const normalized = temporaryPlaceService.normalizeCollection(documentValue && documentValue.temporaryPlaces);
    const states = ensureTemporaryPlaceFormStates()[temporaryScope(scope)];
    for (const role of ['from', 'destination']) {
      states[role].requestToken += 1;
      states[role].checking = false;
      states[role].place = normalized[role]
        ? temporaryPlaceService.normalizePlace(normalized[role], role)
        : temporaryPlaceService.emptyPlace(role);
    }
    syncTemporaryPlacePanels(scope);
  }

  function appendTemporaryPlaceOption(select, role) {
    if (!select || selectContainsValue(select, temporaryPlaceService.selectionId(role))) return;
    const option = document.createElement('option');
    option.value = temporaryPlaceService.selectionId(role);
    option.textContent = temporaryPlaceService.selectionLabel(role);
    option.dataset.temporaryOtherPlace = 'true';
    select.appendChild(option);
  }

  function collectTemporaryPlaces(scope) {
    const result = {};
    for (const role of ['from', 'destination']) {
      if (!temporarySelectionActive(scope, role)) continue;
      const place = syncTemporaryPlaceStateFromInputs(scope, role);
      result[role] = temporaryPlaceService.normalizePlace(place, role);
    }
    return result;
  }

  function resolveFormPlaceSelection(scope, role) {
    const elements = temporaryFormElements(scope, role);
    if (!elements.select) return null;
    if (temporaryPlaceService.isTemporarySelection(elements.select.value, role)) {
      const place = syncTemporaryPlaceStateFromInputs(scope, role);
      return temporaryPlaceService.runtimePlace(place, role);
    }
    return findPlaceById(elements.select.value);
  }

  function resolveJobPlace(documentValue, role) {
    const temporaryPlace = temporaryPlaceService.placeForJobRole(documentValue, role);
    if (temporaryPlace) return temporaryPlace;
    if (role === 'from') return findPlaceById(documentValue && documentValue.fromPlaceId);
    if (role === 'destination') return findPlaceById(documentValue && documentValue.destinationPlaceId);
    if (role === 'return') return findPlaceById(text(documentValue && documentValue.returnPlaceId, text(documentValue && documentValue.fromPlaceId)));
    return null;
  }

  function deriveMaterialForSelections(jobTypeId, fromPlace, destinationPlace) {
    const fromId = fromPlace && fromPlace.temporaryOtherPlace === true ? '' : text(fromPlace && fromPlace.id);
    const destinationId = destinationPlace && destinationPlace.temporaryOtherPlace === true ? '' : text(destinationPlace && destinationPlace.id);
    const material = deriveMaterial(jobTypeId, fromId, destinationId);
    if (!destinationPlace || destinationPlace.temporaryOtherPlace !== true) return material;
    return {
      ...material,
      facilityPlaceId: '',
      facilityPlaceName: text(destinationPlace.name),
      ruleId: text(material.ruleId)
    };
  }

  function clearTemporaryPlace(scope, role) {
    const state = temporaryFormState(scope, role);
    state.requestToken += 1;
    state.checking = false;
    state.place = temporaryPlaceService.emptyPlace(role);
    const elements = temporaryFormElements(scope, role);
    elements.name.value = '';
    elements.address.value = '';
    elements.check.disabled = false;
    renderTemporaryPlaceStatus(scope, role, 'Den tillfälliga platsen är rensad.');
  }

  function temporaryPlaceAddressChanged(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    state.requestToken += 1;
    state.checking = false;
    state.place = temporaryPlaceService.invalidatePlace(state.place, elements.address.value, new Date().toISOString());
    elements.check.disabled = false;
    renderTemporaryPlaceStatus(scope, role, text(elements.address.value)
      ? 'Adressen har ändrats. Tidigare koordinat och geofence är ogiltiga tills adressen kontrolleras igen.'
      : 'Adressen är rensad. Uppdraget kan sparas utan geofence.');
  }

  function temporaryPlaceNameChanged(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    state.place = temporaryPlaceService.withName(state.place, elements.name.value, new Date().toISOString());
    renderTemporaryPlaceStatus(scope, role);
  }

  async function checkTemporaryPlace(scope, role) {
    const state = temporaryFormState(scope, role);
    const elements = temporaryFormElements(scope, role);
    if (state.checking) return;
    const reference = text(elements.address.value);
    state.place = temporaryPlaceService.withName(state.place, elements.name.value, new Date().toISOString());
    if (!reference) {
      state.place = temporaryPlaceService.failedPlace(state.place, '', { code: 'EMPTY_QUERY', message: 'Skriv en adress eller Plus Code för att kontrollera platsen.' }, 'invalid-input');
      renderTemporaryPlaceStatus(scope, role, state.place.errorMessage, true);
      return;
    }
    state.requestToken += 1;
    const requestToken = state.requestToken;
    state.checking = true;
    state.place = temporaryPlaceService.invalidatePlace(state.place, reference, new Date().toISOString());
    elements.check.disabled = true;
    renderTemporaryPlaceStatus(scope, role, 'Google kontrollerar adressen och söker närmaste gata…');
    try {
      const forward = await googleService.geocode(reference, googleSettings && googleSettings.apiKey);
      if (requestToken !== state.requestToken || text(elements.address.value) !== reference) return;
      const reverse = await googleService.reverseGeocode(forward.latitude, forward.longitude, googleSettings && googleSettings.apiKey);
      if (requestToken !== state.requestToken || text(elements.address.value) !== reference) return;
      state.place = temporaryPlaceService.resolvedPlace(state.place, {
        ...reverse,
        latitude: forward.latitude,
        longitude: forward.longitude
      }, reference, new Date().toISOString());
      elements.address.value = state.place.normalizedAddress;
      renderTemporaryPlaceStatus(scope, role, `${state.place.normalizedAddress} · Adressen är kontrollerad och tillfälligt geofence 80 meter är klart.`);
      watchdog.step('runtime.temporary-place.geocoding.resolved', `${temporaryPlaceService.selectionLabel(role)} kontrollerades med den gemensamma Google-tjänsten och fick ett uppdragsbundet 80-metersunderlag.`);
    } catch (error) {
      if (requestToken !== state.requestToken) return;
      const status = googleService.errorStatus(error);
      const userMessage = googleService.userMessageForError(error);
      state.place = temporaryPlaceService.failedPlace(state.place, reference, {
        code: error && error.code,
        message: userMessage
      }, status, new Date().toISOString());
      const diagnostic = googleService.diagnosticFromError(error, {
        flow: 'temporary-place',
        itemId: `${temporaryScope(scope)}-${role}`,
        apiKey: googleSettings && googleSettings.apiKey,
        query: reference,
        at: state.place.updatedAt
      });
      persistGoogleDiagnostic(diagnostic);
      renderTemporaryPlaceStatus(scope, role, `${userMessage} Uppdraget kan fortfarande sparas utan geofence.`, true);
      watchdog.step('runtime.temporary-place.geocoding.failed', `${diagnostic.errorCode || 'RUNTIME_ERROR'} vid ${temporaryPlaceService.selectionLabel(role)}.`, 'warning');
    } finally {
      if (requestToken === state.requestToken) {
        state.checking = false;
        elements.check.disabled = false;
      }
    }
  }

  function migrateArrayStore(storeName, value, detail) {
    const normalized = value.map((item, index) => normalizeJobRecord(item, `${storeName}-${index}`));
    if (JSON.stringify(normalized) === JSON.stringify(value)) return normalized;
    const saved = window.StadslassHost.writeStore(storeName, JSON.stringify(normalized));
    watchdog.step(saved ? `runtime.store.${storeName}.migrated` : `runtime.store.${storeName}.migration-pending`, saved ? detail : 'Migreringen kunde inte skrivas; ursprungsdata är orörd och används i minnet.', saved ? 'info' : 'warning');
    return normalized;
  }

  function migrateObjectStore(storeName, value, detail) {
    if (!isPlainObject(value) || Object.keys(value).length === 0) return value;
    const normalized = normalizeJobRecord(value, storeName);
    if (JSON.stringify(normalized) === JSON.stringify(value)) return normalized;
    const saved = window.StadslassHost.writeStore(storeName, JSON.stringify(normalized));
    watchdog.step(saved ? `runtime.store.${storeName}.migrated` : `runtime.store.${storeName}.migration-pending`, saved ? detail : 'Migreringen kunde inte skrivas; ursprungsdata är orörd och används i minnet.', saved ? 'info' : 'warning');
    return normalized;
  }

  function readSettingsDocument() {
    watchdog.step('runtime.store.settings.read', 'Inställningslagret läses.');
    const raw = window.StadslassHost.readStore(SETTINGS_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Inställningslagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Inställningslagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!isPlainObject(value)) {
      throw new Error('Inställningslagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.settings.validated', 'Inställningslagrets JSON-schema är användbart.');
    return value;
  }

  function readQueueDocument() {
    watchdog.step('runtime.store.queue.read', 'Kölagret läses först när kövyn öppnas.');
    const raw = window.StadslassHost.readStore(QUEUE_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Kölagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Kölagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Kölagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.queue.validated', 'Kölagret är en JSON-lista.');
    return migrateArrayStore(QUEUE_STORE, value, 'Kölagret migrerades till uppdragsmodell v3 med bevarade pausade faser.');
  }

  function readActiveJobDocument() {
    watchdog.step('runtime.store.active.read', 'Aktivt-jobb-lagret läses från den gemensamma lagringen.');
    const raw = window.StadslassHost.readStore(ACTIVE_JOB_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Lagret för aktivt jobb kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Lagret för aktivt jobb innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!isPlainObject(value)) {
      throw new Error('Lagret för aktivt jobb har fel format och har inte ändrats.');
    }
    if (Object.keys(value).length === 0) {
      watchdog.step('runtime.store.active.validated', 'Aktivt-jobb-lagret är tomt och giltigt.');
      return value;
    }
    const id = text(value.id);
    const status = text(value.status);
    const phase = text(value.phase);
    if (!id || !ACTIVE_STATUSES.includes(status) || !phaseService.isKnownPhase(phase, true)) {
      throw new Error('Lagret för aktivt jobb har en okänd struktur och har inte ändrats.');
    }
    watchdog.step('runtime.store.active.validated', 'Aktivt-jobb-lagrets grundschema är giltigt.');
    return migrateObjectStore(ACTIVE_JOB_STORE, value, 'Aktivt jobb migrerades till uppdragsmodell v3 med bevarad fas utan fabricerade fastider.');
  }

  function readHistoryDocument() {
    watchdog.step('runtime.store.history.read', 'Historiklagret läses först när Idag, Historik eller avslut används.');
    const raw = window.StadslassHost.readStore(HISTORY_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Historiklagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Historiklagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Historiklagret har fel format och har inte ändrats.');
    }
    watchdog.step('runtime.store.history.validated', 'Historiklagret är en JSON-lista.');
    return migrateArrayStore(HISTORY_STORE, value, 'Historiklagret migrerades till gemensam uppdragsmodell v2.');
  }

  function readSyncOutboxDocument() {
    const startedAt = Date.now();
    watchdog.step('runtime.store.syncOutbox.read', 'Synkutkö läses först när Överföring eller en uttrycklig överföringsåtgärd används.');
    const raw = window.StadslassHost.readStore(SYNC_OUTBOX_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Synkutkö kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Synkutkö innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Synkutkö har fel format och har inte ändrats.');
    }
    const valid = value.every((entry) => isPlainObject(entry) && text(entry.id));
    if (!valid) {
      throw new Error('Synkutkö innehåller en okänd post och har inte ändrats.');
    }
    watchdog.step('runtime.store.syncOutbox.validated', 'Synkutkö är en giltig JSON-lista.');
    syncDiagnosticObserve('sync-outbox-read', { register: SYNC_OUTBOX_STORE, recordsRead: value.length, byteLength: raw.length, durationMs: Date.now() - startedAt });
    return value;
  }

  // v63 använder endast syncOutbox för tekniska requests, status och begränsad
  // läskopia. Queue, activeJob och history förblir separata sanningskällor.
  function syncV63HostAvailable() {
    return Boolean(syncServiceApi && hostInfo && syncServiceApi.hostCapabilities(hostInfo));
  }

  function syncV63Configuration() {
    const current = isPlainObject(settingsDocument.syncV63) ? settingsDocument.syncV63 : {};
    return { owner: 'Gagge007', repository: 'Lastbils-app', branch: 'main', syncRoot: 'stadslass-3-sync', ...current };
  }

  function syncV65SafeTechnicalText(value, maxLength = 240) {
    return text(value).replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, maxLength);
  }

  function syncV65HostLastError() {
    if (!bridgeAvailable() || typeof window.StadslassHost.getLastError !== 'function') return '';
    try { return syncV65SafeTechnicalText(window.StadslassHost.getLastError()); }
    catch (_) { return ''; }
  }

  function syncV65NormalizeToken(value) {
    let normalized = typeof value === 'string' ? value : '';
    normalized = normalized.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();
    if ((normalized.startsWith('"') && normalized.endsWith('"')) || (normalized.startsWith("'") && normalized.endsWith("'"))) normalized = normalized.slice(1, -1).trim();
    return normalized.replace(/\s+/g, '');
  }

  function syncV65MaskedToken(value) {
    return /^[•●·*.]+$/.test(text(value));
  }

  function syncV65Diagnostic(result = {}, hostError = '') {
    return {
      at: new Date().toISOString(),
      status: syncV65SafeTechnicalText(result.status, 80) || 'unknown',
      errorCode: syncV65SafeTechnicalText(result.errorCode, 120),
      configured: result.configured === true,
      hostError: syncV65SafeTechnicalText(hostError)
    };
  }

  function syncV65RememberDiagnostic(diagnostic, persist = true) {
    syncV65LastConfigDiagnostic = diagnostic;
    if (!persist) return false;
    return syncV63UpdateSettings({ lastConfigurationAttempt: diagnostic });
  }

  function syncV65ConfigurationStatus() {
    if (!syncV63HostAvailable() || typeof window.StadslassHost.getSyncConfigurationStatus !== 'function') return {};
    try { return parseObject(window.StadslassHost.getSyncConfigurationStatus(), {}); }
    catch (_) { return {}; }
  }

  function syncV65ConfigurationErrorMessage(result = {}) {
    const code = text(result.errorCode);
    const status = text(result.status);
    if (code === 'invalid_owner') return 'GitHub-ägaren har ett ogiltigt format.';
    if (code === 'invalid_repository') return 'Repositorynamnet har ett ogiltigt format.';
    if (code === 'invalid_branch') return 'Grennamnet har ett ogiltigt format.';
    if (code === 'invalid_token') return 'GitHub-token kunde inte godkännas. Klistra in den verkliga token och försök igen.';
    if (code === 'unexpected_field' || code === 'invalid_json') return 'Syncuppgifterna hade ett ogiltigt format och sparades inte.';
    if (code === 'configuration_write_failed') return 'Syncinställningarna kunde inte sparas säkert på enheten.';
    if (code === 'credential_unavailable') return 'Den säkert sparade token kunde inte läsas på den här enheten.';
    if (status === 'origin_denied') return 'Den säkra syncbryggan blockerade sparningen. Ingen inställning sparades.';
    if (status === 'host_error') return 'Syncinställningarna kunde inte sparas säkert på enheten.';
    return 'Syncinställningarna kunde inte sparas. Teknisk information visar felorsaken.';
  }

  function syncV63Configured() {
    const config = syncV63Configuration();
    return syncV63HostAvailable() && config.enabled === true && text(config.owner) && text(config.repository) && text(config.branch);
  }

  function syncV63OperationallyEnabled() {
    return DRIFT_SYNC_ENABLED && syncV63Configured();
  }

  function syncV63Identity() {
    if (!syncV63HostAvailable() || !bridgeAvailable() || typeof window.StadslassHost.getDeviceIdentity !== 'function') return null;
    const identity = parseObject(window.StadslassHost.getDeviceIdentity(), null);
    return identity && identity.ok === true && text(identity.installationId) ? identity : null;
  }

  function syncV63Outbox() {
    if (!syncOutboxLoaded) loadSyncOutboxIfNeeded();
    return syncOutboxLoaded ? syncOutboxDocument : [];
  }

  function syncV63SaveOutbox(next) {
    const startedAt = Date.now();
    const before = syncOutboxLoaded ? syncOutboxDocument.length : null;
    const saved = window.StadslassHost.writeStore(SYNC_OUTBOX_STORE, JSON.stringify(next));
    syncDiagnosticObserve('sync-outbox-write', { register: SYNC_OUTBOX_STORE, recordsBefore: before, recordsAfter: Array.isArray(next) ? next.length : null, byteLength: JSON.stringify(next).length, result: saved ? 'saved' : 'write_failed', durationMs: Date.now() - startedAt });
    if (!saved) return false;
    syncOutboxDocument = next;
    syncOutboxLoaded = true;
    return true;
  }

  function performanceContext() {
    const identity = syncV63Identity();
    const counts = syncOutboxLoaded && syncServiceApi && typeof syncServiceApi.counts === 'function' ? syncServiceApi.counts(syncOutboxDocument) : { activeRequests: 0, realWork: 0, journalItems: 0 };
    return {
      packageVersion: PACKAGE_VERSION,
      hostVersion: text(hostInfo && hostInfo.hostVersionName),
      role: text(hostInfo && hostInfo.role, 'unknown'),
      device: text(identity && identity.installationId, text(hostInfo && hostInfo.deviceId, 'local')).slice(0, 24),
      queueCount: queueLoaded ? queueDocument.length : 0,
      activeRequests: counts.activeRequests || 0,
      waitingWork: counts.realWork || 0,
      terminalJournal: counts.journalItems || 0
    };
  }

  function performanceEnsure() {
    if (performanceMonitor || !performanceMonitorApi) return performanceMonitor;
    performanceMonitor = performanceMonitorApi.create({ context: performanceContext });
    return performanceMonitor;
  }

  function performanceObserve(kind, details = {}) {
    const monitor = performanceEnsure();
    if (monitor) monitor.observe(kind, details);
  }

  function scheduleRoleRefresh() {
    if (!syncV63OperationallyEnabled() || syncV66RoleRefreshTimer !== null) return;
    syncV66RoleRefreshTimer = window.setTimeout(() => {
      syncV66RoleRefreshTimer = null;
      syncV63SyncNow({ roleTransition: true });
    }, 0);
  }

  function syncDiagnosticEnsure() {
    if (syncDiagnostic || !syncDiagnosticApi) return syncDiagnostic;
    syncDiagnostic = syncDiagnosticApi.create({
      host: () => window.StadslassHost,
      readStore: (name) => {
        if (!bridgeAvailable() || typeof window.StadslassHost.readStore !== 'function') throw new Error('Värdbryggans läsning saknas.');
        return window.StadslassHost.readStore(name);
      },
      getRequestStatus: (requestId) => {
        if (!bridgeAvailable() || typeof window.StadslassHost.getSyncRequestStatus !== 'function') return null;
        return parseObject(window.StadslassHost.getSyncRequestStatus(requestId), null);
      }
    });
    return syncDiagnostic;
  }

  function syncDiagnosticObserve(kind, details = {}) {
    const diagnostic = syncDiagnosticEnsure();
    if (diagnostic) diagnostic.observe(kind, details);
    if (/^sync-|^host-retry/.test(String(kind))) performanceObserve(kind, details);
  }

  function syncV63EnsureService() {
    if (!syncV63HostAvailable()) return null;
    if (syncV63) return syncV63;
    syncV63 = syncServiceApi.create({
      host: () => window.StadslassHost,
      getHostInfo: () => hostInfo,
      readOutbox: () => syncV63Outbox(),
      saveOutbox: (next) => syncV63SaveOutbox(next)
    });
    return syncV63;
  }

  function syncV63UpdateSettings(patch) {
    const next = { ...settingsDocument, syncV63: { ...syncV63Configuration(), ...patch }, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(next));
    if (saved) settingsDocument = next;
    return saved;
  }

  function syncV63Path(leaf) {
    const identity = syncV63Identity();
    if (!identity) throw new Error('Enhetens syncidentitet saknas.');
    return syncServiceApi.pathFor(settingsDocument, '189', leaf);
  }

  function syncV63Enqueue(intent, operation, path, priority, body = '', expectedSha = '', coalesceKey = '') {
    const startedAt = Date.now();
    const pendingBefore = syncOutboxLoaded ? syncOutboxDocument.length : null;
    if (!DRIFT_SYNC_ENABLED) {
      syncDiagnosticObserve('sync-request-blocked', { intent, operation, priority, path, coalesceKey, pendingBefore, pendingAfter: pendingBefore, result: 'operational_sync_disabled', durationMs: Date.now() - startedAt });
      return { ok: false, status: 'operational_sync_disabled', disabled: true };
    }
    const service = syncV63EnsureService();
    if (!service || !syncV63Configured()) {
      syncDiagnosticObserve('sync-request', { intent, operation, priority, path, coalesceKey, pendingBefore, pendingAfter: pendingBefore, result: 'configuration_missing', durationMs: Date.now() - startedAt });
      return { ok: false, status: 'configuration_missing' };
    }
    const result = service.enqueue(intent, operation, path, priority, body, expectedSha, coalesceKey);
    syncDiagnosticObserve('sync-request', { intent, operation, priority, path, requestId: result.requestId, coalesceKey, pendingBefore, pendingAfter: syncOutboxLoaded ? syncOutboxDocument.length : null, byteLength: syncServiceApi.bytes(body), result: result.status, durationMs: Date.now() - startedAt, payload: body || undefined });
    if (!result.ok) watchdog.step(`runtime.sync.v63.${intent}.pending`, `Syncåtgärden väntar eller kunde inte köas: ${result.status}.`, 'warning');
    return result;
  }

  // v86: värdappen kan ha hunnit avsluta ett request medan appen varit stängd.
  // Läs då bara dess lokala värdstatus och konsumera enbart terminala tekniska
  // requests. Kö, aktivt jobb och historik berörs aldrig.
  function syncV86ReconcileTerminalRequests() {
    if (!syncV63OperationallyEnabled()) return 0;
    const service = syncV63EnsureService();
    if (!service) return 0;
    const candidates = syncV63Outbox().filter((entry) => entry && entry.kind === 'sync-v63-request' && syncServiceApi.activeRequest(entry));
    let reconciled = 0;
    candidates.forEach((candidate) => {
      let result = null;
      try { result = service.recover(text(candidate.requestId)); } catch (_) { result = null; }
      if (!result || !syncServiceApi.terminal(text(result.status))) return;
      syncDiagnosticObserve('sync-terminal-reconcile', { requestId: text(candidate.requestId), intent: text(candidate.intent), status: text(result.status) });
      syncV63HandleResult(text(candidate.requestId), result);
      reconciled += 1;
    });
    return reconciled;
  }

  function syncV63PublishActive(documentValue, terminal = false, completedJob = null) {
    if (!isVehicleRole() || !syncV63OperationallyEnabled()) return;
    const identity = syncV63Identity();
    if (!identity) return;
    const config = syncV63Configuration();
    const workSessionId = text(config.workSessionId, `work-${identity.installationId.slice(0, 12)}`);
    const lease = syncServiceApi.workLease('189', identity.installationId, workSessionId, Boolean(documentValue && text(documentValue.id)), new Date(Date.now() + 120000).toISOString());
    const status = syncServiceApi.activeStatus(documentValue, '189', identity.installationId, ++syncV63ActiveSequence, lease);
    if (terminal && completedJob && text(completedJob.id || completedJob.jobId)) {
      status.lastCompletedJob = {
        id: text(completedJob.id), jobId: text(completedJob.jobId, text(completedJob.id)), sourceQueueItemId: text(completedJob.sourceQueueItemId),
        status: 'completed', completedAt: text(completedJob.completedAt), jobTypeName: text(completedJob.jobTypeName)
      };
    }
    const body = JSON.stringify(status);
    const result = syncV63Enqueue(terminal ? 'put-active-terminal' : 'put-active', 'PUT', syncV63Path('active-status.json'), syncServiceApi.PRIORITIES.active, body, '', `active_work/189${terminal ? '/terminal' : ''}`);
    if (result.ok) syncV63UpdateSettings({ lastActivePublishedAt: status.publishedAt, workSessionId });
  }

  function syncV63PublishQueue(documentValue) {
    if (!isVehicleRole() || !syncV63OperationallyEnabled()) return;
    const identity = syncV63Identity();
    if (!identity) return;
    const status = syncServiceApi.sharedQueue(documentValue, '189', identity.installationId, ++syncV63QueueRevision);
    const result = syncV63Enqueue('put-queue', 'PUT', syncV63Path('shared-queue.json'), syncServiceApi.PRIORITIES.queue, JSON.stringify(status), '', 'shared_queue/189');
    if (result.ok) syncV63UpdateSettings({ lastQueuePublishedAt: status.publishedAt });
  }

  function syncV63MirrorEntry(kind) {
    return syncV63Outbox().filter((entry) => entry && entry.kind === kind).sort((a, b) => text(b.updatedAt).localeCompare(text(a.updatedAt)))[0] || null;
  }

  function syncV63CacheMirror(kind, value) {
    const entries = syncV63Outbox().filter((entry) => entry && entry.kind !== kind);
    return syncV63SaveOutbox([...entries, { id: `${kind}-189`, kind, value, updatedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION }]);
  }

  function syncV63RequestReads(scheduledFunction = '') {
    if (!syncV63OperationallyEnabled()) return;
    if (isMobileRole()) {
      if (!scheduledFunction || scheduledFunction === 'active') syncV63Enqueue('get-active', 'GET', syncV63Path('active-status.json'), syncServiceApi.PRIORITIES.active, '', '', 'get-active/189');
      if (!scheduledFunction || scheduledFunction === 'queue') syncV63Enqueue('get-queue', 'GET', syncV63Path('shared-queue.json'), syncServiceApi.PRIORITIES.queue, '', '', 'get-queue/189');
      if ((!scheduledFunction || scheduledFunction === 'commands') && syncV63Outbox().some((entry) => entry && entry.kind === 'sync-v63-command' && text(entry.state) === 'waiting_result')) syncV63Enqueue('get-results', 'GET', syncV63Path('command-results.json'), syncServiceApi.PRIORITIES.queue, '', '', 'get-results/189');
      if ((!scheduledFunction || scheduledFunction === 'on-demand') && syncV63Outbox().some((entry) => entry && entry.kind === 'sync-v63-on-demand' && ['waiting_ledger', 'waiting_send'].includes(text(entry.state)))) syncV63Enqueue('get-on-demand-ledger', 'GET', syncV63Path('on-demand-requests.json'), syncServiceApi.PRIORITIES.low, '', '', 'get-on-demand-ledger/189');
      if ((!scheduledFunction || scheduledFunction === 'on-demand') && syncV63Outbox().some((entry) => entry && entry.kind === 'sync-v63-on-demand')) syncV63Enqueue('get-on-demand-index', 'GET', syncV63Path('on-demand-index.json'), syncServiceApi.PRIORITIES.low, '', '', 'get-on-demand-index/189');
    } else if (isVehicleRole()) {
      if (!scheduledFunction || scheduledFunction === 'commands') syncV63Enqueue('get-commands', 'GET', syncV63Path('planning-commands.json'), syncServiceApi.PRIORITIES.queue, '', '', 'get-commands/189');
      if (!scheduledFunction || scheduledFunction === 'on-demand') syncV63Enqueue('get-on-demand-requests', 'GET', syncV63Path('on-demand-requests.json'), syncServiceApi.PRIORITIES.low, '', '', 'get-on-demand-requests/189');
    }
  }

  // Närvaron använder samma transport som Driftsync, men dess egen lokala
  // pinglogg. Arbetsdata och tekniska requests visas aldrig i pingloggen.
  const SYNC_V89_PING_LOG_KIND = 'sync-v89-ping-log';
  function syncV85HandshakePath(leaf) { return syncV63Path(`presence/${leaf}`); }
  // Ekolodet använder 189:s befintliga Ping n. Den tekniska transporten
  // kan fortfarande behöva läsa returfilen för GitHubs skrivning, men detta
  // visas aldrig som kölogik.
  function syncV89ReadEchoForWrite() {
    if (!isMobileRole() || !syncV63OperationallyEnabled()) return;
    syncV63Enqueue('v89-get-echo', 'GET', syncV85HandshakePath('planning-reply.json'), syncServiceApi.PRIORITIES.active, '', '', 'v89/echo/189');
  }
  function syncV89AppendSignal(channel, sequence, direction, state) {
    const id = `${SYNC_V89_PING_LOG_KIND}:${channel}:${direction}:${Number(sequence)}`;
    const entries = syncV63Outbox().filter((entry) => text(entry && entry.id) !== id);
    return syncV63SaveOutbox([...entries, { id, kind: SYNC_V89_PING_LOG_KIND, channel, sequence: Number(sequence), direction, state, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION }]);
  }
  function syncV89AppendPing(sequence, direction, state) { return syncV89AppendSignal('ping', sequence, direction, state); }
  function syncV92AppendBing(sequence, direction, state) { return syncV89AppendSignal('bing', sequence, direction, state); }
  function syncV89MatchSignal(channel, sequence) {
    const target = Number(sequence);
    const entries = syncV63Outbox().map((entry) => entry && entry.kind === SYNC_V89_PING_LOG_KIND && (text(entry.channel) || 'ping') === channel && Number(entry.sequence) === target
      ? { ...entry, state: 'matched', updatedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION } : entry);
    const replyId = `${SYNC_V89_PING_LOG_KIND}:${channel}:reply:${target}`;
    if (!entries.some((entry) => text(entry && entry.id) === replyId)) entries.push({ id: replyId, kind: SYNC_V89_PING_LOG_KIND, channel, sequence: target, direction: 'reply', state: 'matched', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION });
    return syncV63SaveOutbox(entries);
  }
  function syncV89MatchPing(sequence) { return syncV89MatchSignal('ping', sequence); }
  function syncV92MatchBing(sequence) { return syncV89MatchSignal('bing', sequence); }
  function syncV85HandshakeSave(patch) {
    syncV85HandshakeState = { ...syncV85HandshakeState, ...patch };
    syncV63UpdateSettings({ v85Handshake: syncV85HandshakeState });
    renderSyncV63();
  }
  function syncV92BingSave(patch) {
    syncV92BingState = { ...syncV92BingState, ...patch };
    syncV63UpdateSettings({ bingHandshake: syncV92BingState });
    renderSyncV63();
  }
  function syncV92ReadBingEchoForWrite() {
    if (!isMobileRole() || !syncV63OperationallyEnabled()) return;
    syncV63Enqueue('v92-get-bing-reply', 'GET', syncV85HandshakePath('vehicle-189-bing-echo.json'), syncServiceApi.PRIORITIES.active, '', '', 'v92/bing-reply/189');
  }
  function syncV92SendBing() {
    if (!isMobileRole() || !syncV63OperationallyEnabled()) return;
    const identity = syncV63Identity(); if (!identity) return;
    const sequence = Math.max(syncV92BingSequence + 1, Number(syncV92BingState.lastBingSequence) + 1, 1);
    syncV92BingSequence = sequence;
    const sentAt = new Date().toISOString();
    const body = JSON.stringify({ schemaVersion: 1, protocol: 'stadslass3.drift-bing.v2', vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: identity.installationId, sequence, sentAt });
    const queued = syncV63Enqueue('v92-put-bing', 'PUT', syncV85HandshakePath('planning-bing-signal.json'), syncServiceApi.PRIORITIES.active, body, '', 'v92/bing/189');
    if (queued.ok) syncV92AppendBing(sequence, 'bing', 'sent');
    syncV92BingSave({ lastBingAt: sentAt, lastBingSequence: sequence, lastError: queued.ok ? '' : text(queued.status) });
  }
  function syncV92ReadBing() {
    if (!isVehicleRole() || !syncV63OperationallyEnabled()) return;
    syncV63Enqueue('v92-get-bing', 'GET', syncV85HandshakePath('planning-bing-signal.json'), syncServiceApi.PRIORITIES.active, '', '', 'v92/bing/189');
  }
  function syncV85SendPing() {
    if (!isVehicleRole() || !syncV63OperationallyEnabled()) return;
    const identity = syncV63Identity(); if (!identity) return;
    const sequence = Math.max(syncV85HandshakeSequence + 1, Number(syncV85HandshakeState.lastPingSequence) + 1, 1);
    syncV85HandshakeSequence = sequence;
    const sentAt = new Date().toISOString();
    const body = JSON.stringify({ schemaVersion: 1, protocol: 'stadslass3.drift-ping.v1', vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: identity.installationId, sequence, sentAt });
    const queued = syncV63Enqueue('v85-put-ping', 'PUT', syncV85HandshakePath('vehicle-189-ping.json'), syncServiceApi.PRIORITIES.active, body, '', 'v85/ping/189');
    if (queued.ok) syncV89AppendPing(sequence, 'ping', 'sent');
    syncV85HandshakeSave({ lastPingAt: sentAt, lastPingSequence: sequence, lastError: queued.ok ? '' : text(queued.status) });
  }
  function syncV85ReadPing() {
    if (!isMobileRole() || !syncV63OperationallyEnabled()) return;
    syncV89ReadEchoForWrite();
    syncV63Enqueue('v85-get-ping', 'GET', syncV85HandshakePath('vehicle-189-ping.json'), syncServiceApi.PRIORITIES.active, '', '', 'v85/ping/189');
  }
  function syncV85StartTimers() {
    if (!syncV63OperationallyEnabled()) return;
    const every = (name, ms, action) => { if (!syncV85Timers.has(name)) syncV85Timers.set(name, window.setInterval(action, ms)); };
    const ordinary = syncServiceApi.SYNC_RUNTIME_POLICY_V63.ordinaryIntervalMs;
    // Ingen första automatisk körning: varje ordinarie del väntar sina 60 minuter.
    every('active', ordinary, () => syncV63SyncNow({ scheduledFunction: 'active' }));
    every('queue', ordinary, () => syncV63SyncNow({ scheduledFunction: 'queue' }));
    every('commands', ordinary, () => syncV63SyncNow({ scheduledFunction: 'commands' }));
    every('on-demand', ordinary, () => syncV63SyncNow({ scheduledFunction: 'on-demand' }));
    every('ping', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs, syncV85SendPing);
    every('reply-read', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs, () => {
      if (isVehicleRole()) syncV63Enqueue('v85-get-reply', 'GET', syncV85HandshakePath('planning-reply.json'), syncServiceApi.PRIORITIES.active, '', '', 'v85/reply/189');
      else syncV85ReadPing();
    });
    every('bing', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs, syncV92SendBing);
    every('bing-read', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs, () => {
      if (isVehicleRole()) syncV92ReadBing();
      else syncV92ReadBingEchoForWrite();
    });
  }

  function latestV63CommandForJob(jobId) {
    return syncV63Outbox().filter((entry) => entry && entry.kind === 'sync-v63-command' && text(entry.jobId) === text(jobId))
      .sort((a, b) => text(b.updatedAt).localeCompare(text(a.updatedAt)))[0] || null;
  }

  function syncV63QueuePlanningCommand(commandValue) {
    if (!isMobileRole() || !syncV63OperationallyEnabled()) return false;
    const entry = { id: `sync-v63-command-${commandValue.commandId}`, kind: 'sync-v63-command', commandId: commandValue.commandId,
      jobId: commandValue.jobId, commandType: commandValue.commandType, command: commandValue, state: 'waiting_ledger', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), mergeAttempts: 0 };
    if (!syncV63SaveOutbox([...syncV63Outbox(), entry])) return false;
    const result = syncV63Enqueue('get-planning-ledger', 'GET', syncV63Path('planning-commands.json'), syncServiceApi.PRIORITIES.queue, '', '', 'get-planning-ledger/189');
    if (!result.ok) return false;
    return true;
  }

  function syncV63CreatePlanningCommand(job, commandType = 'create', expectedRevision = 0) {
    if (!syncV63OperationallyEnabled()) {
      showStatus('queue-form-status', 'Driftsyncen mellan enheterna är tillfälligt avstängd. Använd lokal planering eller reservöverföring.', true);
      return false;
    }
    const identity = syncV63Identity();
    if (!identity) { showStatus('queue-form-status', 'Enhetens syncidentitet saknas.', true); return false; }
    const cmd = syncServiceApi.command(commandType, identity.installationId, '189', job, expectedRevision);
    const queued = syncV63QueuePlanningCommand(cmd);
    if (queued) {
      showStatus('queue-form-status', commandType === 'create' ? 'Uppdraget skickas till 189. Mottaget visas först när 189 har sparat det i sin kö.' : commandType === 'edit' ? 'Ändringen skickas till 189 för kontroll.' : 'Borttagningen skickas till 189 för kontroll.');
      renderQueue(); renderSyncV63();
    }
    return queued;
  }

  function syncV63MergePlanningLedger(result) {
    const response = text(result && result.body);
    let remote = parseObject(response, null);
    if (!remote) remote = { schemaVersion: 1, protocol: syncServiceApi.PROTOCOLS.commands, vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: text(syncV63Identity() && syncV63Identity().installationId), publishedAt: new Date().toISOString(), revision: 0, commands: [] };
    syncServiceApi.validateEnvelope(remote, syncServiceApi.PROTOCOLS.commands, '189');
    const commands = Array.isArray(remote.commands) ? remote.commands.filter(isPlainObject) : [];
    const byId = new Map(commands.map((cmd) => [text(cmd.commandId), cmd]));
    const pending = syncV63Outbox().filter((entry) => entry && entry.kind === 'sync-v63-command' && ['waiting_ledger', 'waiting_send', 'failed_retryable'].includes(text(entry.state)));
    pending.forEach((entry) => byId.set(text(entry.commandId), entry.command));
    const ledger = { ...remote, packageVersion: PACKAGE_VERSION, publishedAt: new Date().toISOString(), revision: (Number(remote.revision) || 0) + 1, commands: Array.from(byId.values()) };
    const body = JSON.stringify(ledger);
    if (syncServiceApi.bytes(body) > 900 * 1024) throw new Error('Planeringsloggen är för stor och måste först behandlas på 189.');
    const next = syncV63Outbox().map((entry) => pending.some((candidate) => candidate.id === entry.id) ? { ...entry, state: 'waiting_send', updatedAt: new Date().toISOString() } : entry);
    if (!syncV63SaveOutbox(next)) throw new Error('Planeringskommandot kunde inte sparas lokalt.');
    return syncV63Enqueue('put-planning-ledger', 'PUT', syncV63Path('planning-commands.json'), syncServiceApi.PRIORITIES.queue, body, text(result && (result.sha || result.responseSha)), 'planning-ledger/189');
  }

  function syncV63RequestOnDemand(requestType) {
    if (!DRIFT_SYNC_ENABLED) { showStatus('sync-v63-demand-status', 'Driftsyncen mellan enheterna är tillfälligt avstängd.', true); return; }
    if (!isMobileRole() || !syncV63Configured()) { showStatus('sync-v63-demand-status', 'Spara syncinställningarna först.', true); return; }
    const identity = syncV63Identity();
    if (!identity) { showStatus('sync-v63-demand-status', 'Enhetens syncidentitet saknas.', true); return; }
    const requestValue = syncServiceApi.onDemandRequest(requestType, identity.installationId, '189', { requestedAt: new Date().toISOString() });
    const entry = { id: `sync-v63-demand-${requestValue.onDemandRequestId}`, kind: 'sync-v63-on-demand', requestId: requestValue.onDemandRequestId, requestType, request: requestValue, state: 'waiting_ledger', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    if (!syncV63SaveOutbox([...syncV63Outbox(), entry])) { showStatus('sync-v63-demand-status', 'Begäran kunde inte sparas lokalt.', true); return; }
    const queued = syncV63Enqueue('get-on-demand-ledger', 'GET', syncV63Path('on-demand-requests.json'), syncServiceApi.PRIORITIES.low, '', '', 'get-on-demand-ledger/189');
    showStatus('sync-v63-demand-status', queued.ok ? 'Begäran skickas till 189.' : 'Begäran väntar på sync.', !queued.ok);
  }

  function syncV63MergeOnDemandLedger(result) {
    let remote = parseObject(text(result && result.body), null);
    if (!remote) remote = { schemaVersion: 1, protocol: syncServiceApi.PROTOCOLS.onDemand, vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: text(syncV63Identity() && syncV63Identity().installationId), publishedAt: new Date().toISOString(), revision: 0, requests: [] };
    syncServiceApi.validateEnvelope(remote, syncServiceApi.PROTOCOLS.onDemand, '189');
    const byId = new Map((Array.isArray(remote.requests) ? remote.requests : []).filter(isPlainObject).map((item) => [text(item.onDemandRequestId), item]));
    const pending = syncV63Outbox().filter((entry) => entry && entry.kind === 'sync-v63-on-demand' && ['waiting_ledger', 'waiting_send'].includes(text(entry.state)));
    pending.forEach((entry) => byId.set(text(entry.requestId), entry.request));
    const ledger = { ...remote, packageVersion: PACKAGE_VERSION, publishedAt: new Date().toISOString(), revision: (Number(remote.revision) || 0) + 1, requests: Array.from(byId.values()) };
    const next = syncV63Outbox().map((entry) => pending.some((candidate) => candidate.id === entry.id) ? { ...entry, state: 'waiting_send', updatedAt: new Date().toISOString() } : entry);
    if (!syncV63SaveOutbox(next)) throw new Error('Begäran kunde inte sparas lokalt.');
    return syncV63Enqueue('put-on-demand-ledger', 'PUT', syncV63Path('on-demand-requests.json'), syncServiceApi.PRIORITIES.low, JSON.stringify(ledger), text(result && (result.sha || result.responseSha)), 'on-demand-ledger/189');
  }

  function syncV63SyncNow(options = {}) {
    const currentTime = Date.now();
    if (!DRIFT_SYNC_ENABLED) {
      showStatus('sync-v63-status', 'Driftsyncen mellan 189, Mobil och Dator är tillfälligt avstängd. Lokalt arbete, uppdateringar och rapporter fungerar fortsatt.');
      syncDiagnosticObserve('sync-cycle-blocked', { roleTransition: options.roleTransition === true, pendingBefore: syncOutboxLoaded ? syncOutboxDocument.length : null, pendingAfter: syncOutboxLoaded ? syncOutboxDocument.length : null, result: 'operational_sync_disabled', durationMs: 0 });
      return;
    }
    if (syncV69CycleRunning) {
      syncV69CycleQueued = true;
      syncDiagnosticObserve('sync-cycle-coalesced', { reason: 'cycle-running', pendingBefore: syncOutboxLoaded ? syncOutboxDocument.length : null });
      return;
    }
    if (currentTime - syncV66LastRunAt < 900 && options.roleTransition !== true && options.manual !== true) {
      syncDiagnosticObserve('sync-cycle-coalesced', { reason: 'recent-request', pendingBefore: syncOutboxLoaded ? syncOutboxDocument.length : null });
      return;
    }
    syncV69CycleRunning = true;
    syncV66LastRunAt = currentTime;
    const pendingBefore = syncOutboxLoaded ? syncOutboxDocument.length : null;
    try {
      if (!syncV63Configured()) {
        showStatus('sync-v63-status', syncV63HostAvailable() ? 'Spara och kontrollera syncinställningarna först.' : 'Säker internetsync stöds inte av den här installationen.', true);
        syncDiagnosticObserve('sync-cycle', { roleTransition: options.roleTransition === true, pendingBefore, pendingAfter: pendingBefore, result: 'configuration_missing', durationMs: Date.now() - currentTime });
        return;
      }
      const localCounts = syncServiceApi.counts(syncV63Outbox());
      if (localCounts.retryableRequests > 0 && typeof window.StadslassHost.retryPendingSyncRequests === 'function') {
        const retryStartedAt = Date.now();
        window.StadslassHost.retryPendingSyncRequests();
        syncDiagnosticObserve('host-retry-pending', { retryableRequests: localCounts.retryableRequests, pendingBefore, pendingAfter: syncOutboxLoaded ? syncOutboxDocument.length : null, durationMs: Date.now() - retryStartedAt });
      }
      if (isVehicleRole()) {
        if (!activeJobLoaded) loadActiveJobIfNeeded();
        if (!queueLoaded) loadQueueIfNeeded();
        if (!options.scheduledFunction || options.scheduledFunction === 'active') syncV63PublishActive(activeJobDocument, false);
        if (!options.scheduledFunction || options.scheduledFunction === 'queue') syncV63PublishQueue(queueDocument);
      }
      syncV63RequestReads(text(options.scheduledFunction));
      showStatus('sync-v63-status', 'Synkningen har startats. Lokalt arbete fortsätter oavsett anslutning.');
      syncDiagnosticObserve('sync-cycle', { roleTransition: options.roleTransition === true, pendingBefore, pendingAfter: syncOutboxLoaded ? syncOutboxDocument.length : null, result: 'started', durationMs: Date.now() - currentTime });
      renderSyncV63();
    } finally {
      syncV69CycleRunning = false;
      if (syncV69CycleQueued) {
        syncV69CycleQueued = false;
        window.setTimeout(() => syncV63SyncNow({ coalesced: true }), 0);
      }
    }
  }

  const SYNC_V69_OPTIONAL_GET_INTENTS = new Set(['connection-check', 'get-active', 'get-queue', 'get-results', 'get-commands', 'get-planning-ledger', 'get-on-demand-ledger', 'get-on-demand-index', 'get-on-demand-requests', 'v85-get-ping', 'v85-get-reply', 'v89-get-echo', 'v92-get-bing', 'v92-get-bing-reply']);

  function syncV69IsOptionalGet(intent) {
    return SYNC_V69_OPTIONAL_GET_INTENTS.has(text(intent)) || text(intent).startsWith('get-on-demand-part:') || text(intent).startsWith('resolve-put:');
  }

  function syncV69SchedulePutResolution(entry) {
    const requestValue = entry && entry.request;
    if (!requestValue || text(requestValue.operation) !== 'PUT' || !text(requestValue.path)) return false;
    const attempt = Math.max(0, Number(entry.retryAttempt) || 0);
    if (text(entry.intent) === 'put-planning-ledger') {
      const next = syncV63Outbox().map((item) => item && item.kind === 'sync-v63-command' && ['waiting_send', 'failed_retryable'].includes(text(item.state)) ? { ...item, state: attempt + 1 >= 2 ? 'sync_conflict' : 'waiting_ledger', mergeAttempts: attempt + 1, updatedAt: new Date().toISOString() } : item);
      syncV63SaveOutbox(next);
      if (attempt + 1 < 2) return syncV63Enqueue('get-planning-ledger', 'GET', syncV63Path('planning-commands.json'), syncServiceApi.PRIORITIES.queue, '', '', 'get-planning-ledger/189').ok === true;
      return false;
    }
    if (text(entry.intent) === 'put-on-demand-ledger') {
      const next = syncV63Outbox().map((item) => item && item.kind === 'sync-v63-on-demand' && ['waiting_send', 'failed_retryable'].includes(text(item.state)) ? { ...item, state: attempt + 1 >= 2 ? 'sync_conflict' : 'waiting_ledger', mergeAttempts: attempt + 1, updatedAt: new Date().toISOString() } : item);
      syncV63SaveOutbox(next);
      if (attempt + 1 < 2) return syncV63Enqueue('get-on-demand-ledger', 'GET', syncV63Path('on-demand-requests.json'), syncServiceApi.PRIORITIES.low, '', '', 'get-on-demand-ledger/189').ok === true;
      return false;
    }
    if (attempt >= 2) return false;
    const retryId = `sync-v69-put-retry-${text(entry.requestId)}`;
    const existing = syncV63Outbox().find((item) => item && item.id === retryId);
    if (!existing) {
      const control = { id: retryId, kind: 'sync-v69-put-retry', originalRequestId: text(entry.requestId), intent: text(entry.intent), request: { ...requestValue, body: text(requestValue.body) }, attempt: attempt + 1, state: 'waiting_remote_sha', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION };
      if (!syncV63SaveOutbox([...syncV63Outbox(), control])) return false;
    }
    const queued = syncV63Enqueue(`resolve-put:${text(entry.requestId)}`, 'GET', text(requestValue.path), text(requestValue.priority, syncServiceApi.PRIORITIES.queue), '', '', `resolve-put/${text(requestValue.path)}`);
    syncDiagnosticObserve('sync-put-conflict-resolution', { originalRequestId: text(entry.requestId), path: text(requestValue.path), queued: queued.ok === true, attempt: attempt + 1 });
    syncV63UpdateSettings({ lastConflictRetryAt: new Date().toISOString(), lastConflictRetryPath: text(requestValue.path), lastConflictRetryAttempt: attempt + 1 });
    return queued.ok === true;
  }

  function syncV69HandlePutResolution(entry, result) {
    const originalRequestId = text(entry.intent).slice('resolve-put:'.length);
    const control = syncV63Outbox().find((item) => item && item.kind === 'sync-v69-put-retry' && text(item.originalRequestId) === originalRequestId);
    if (!control || !control.request) return;
    const currentSha = text(result && (result.sha || result.responseSha));
    const queued = syncV63Enqueue(control.intent, 'PUT', text(control.request.path), text(control.request.priority, syncServiceApi.PRIORITIES.queue), text(control.request.body), currentSha, text(control.request.coalesceKey));
    let next = syncV63Outbox().filter((item) => item !== control);
    if (queued.ok) next = next.map((item) => item && item.kind === 'sync-v63-request' && text(item.requestId) === text(queued.requestId) ? { ...item, retryAttempt: Number(control.attempt) || 1, updatedAt: new Date().toISOString() } : item);
    if (queued.ok) syncV63SaveOutbox(next);
    else syncV63SaveOutbox(next.concat({ ...control, state: 'sync_conflict', updatedAt: new Date().toISOString(), errorCode: text(queued.status) }));
    syncDiagnosticObserve('sync-put-conflict-retry', { originalRequestId, path: text(control.request.path), currentShaPresent: Boolean(currentSha), result: text(queued.status) });
  }

  function syncV63HandleResult(requestId, eventResult = {}) {
    if (!DRIFT_SYNC_ENABLED) {
      syncDiagnosticObserve('sync-result-ignored', { requestId: text(requestId), result: 'operational_sync_disabled' });
      return;
    }
    const startedAt = Date.now();
    const pendingBefore = syncOutboxLoaded ? syncOutboxDocument.length : null;
    const service = syncV63EnsureService();
    if (!service || !text(requestId)) return;
    let result = service.recover(requestId);
    // Värdappen kan lämna den färdiga GitHub-body i resultathändelsen innan
    // statusuppslaget hunnit lämna pending. Använd den endast för samma request.
    // Host 18 kan lämna läsdata i olika fält beroende på om den kom från
    // händelsen eller statusuppslaget. Ekolodet läser samma innehåll utan att
    // skapa fler användarsynliga tekniska tillstånd.
    const resultBody = (value) => text(value && (value.body || value.responseBody || value.content || value.responseContent || (isPlainObject(value.data) && (value.data.body || value.data.content)) || (value.result && (value.result.body || value.result.content))));
    const eventBody = resultBody(eventResult);
    const eventStatus = text(eventResult && eventResult.status);
    if (eventBody || (eventStatus && !syncServiceApi.terminal(text(result && result.status)))) {
      result = { ...(result || {}), ...(eventResult || {}), requestId, status: eventStatus || text(result && result.status), body: eventBody || text(result && result.body) };
    }
    if (!text(result && result.body)) result = { ...(result || {}), body: resultBody(result) };
    syncDiagnosticObserve('sync-result-received', { requestId, operation: result && result.operation, path: result && result.path, status: text(result && result.status), byteLength: syncServiceApi.bytes(text(result && result.body)), pendingBefore, response: result && result.body ? result.body : undefined });
    const pendingEntry = syncV63Outbox().find((item) => item && item.kind === 'sync-v63-request' && text(item.requestId) === text(requestId));
    if (pendingEntry && text(result && result.status) === 'failed_permanent' && Number(result && result.httpStatus) === 404 && syncV69IsOptionalGet(pendingEntry.intent)) {
      result = { ...result, ok: true, status: 'succeeded', body: '', sha: '', responseSha: '', errorCode: '', emptyChannel: true, normalizedFromHttpStatus: 404 };
      syncDiagnosticObserve('sync-optional-channel-empty', { requestId, intent: text(pendingEntry.intent), path: text(pendingEntry.request && pendingEntry.request.path) });
      syncV63UpdateSettings({ lastEmptyRemoteAt: new Date().toISOString(), lastEmptyRemoteIntent: text(pendingEntry.intent), lastEmptyRemotePath: text(pendingEntry.request && pendingEntry.request.path) });
    }
    const entry = service.recordResult(requestId, result);
    if (!entry || !syncServiceApi.terminal(result.status)) { syncDiagnosticObserve('sync-result', { requestId, result: text(result && result.status, 'pending'), pendingBefore, pendingAfter: syncOutboxLoaded ? syncOutboxDocument.length : null, durationMs: Date.now() - startedAt }); return; }
    const resourcePath = text(entry.request && entry.request.path);
    const resourceSha = text(result && (result.sha || result.responseSha));
    if (text(result.status) === 'succeeded' && resourcePath && resourceSha) syncV63SaveOutbox(syncServiceApi.setResourceState(syncV63Outbox(), resourcePath, { sha: resourceSha, lastSuccessAt: new Date().toISOString(), operation: text(entry.request && entry.request.operation) }));
    try {
      if (text(entry.intent).startsWith('resolve-put:') && text(result.status) === 'succeeded') syncV69HandlePutResolution(entry, result);
      if (text(result.status) === 'failed_permanent' && Number(result.httpStatus) === 422 && text(entry.request && entry.request.operation) === 'PUT') {
        const scheduled = syncV69SchedulePutResolution(entry);
        if (!scheduled && !['put-planning-ledger', 'put-on-demand-ledger'].includes(text(entry.intent))) {
          const conflictId = `sync-v69-put-conflict-${text(entry.requestId)}`;
          if (!syncV63Outbox().some((item) => item && item.id === conflictId)) syncV63SaveOutbox([...syncV63Outbox(), { id: conflictId, kind: 'sync-v69-put-retry', originalRequestId: text(entry.requestId), intent: text(entry.intent), path: text(entry.request && entry.request.path), state: 'sync_conflict', attempt: Math.max(2, Number(entry.retryAttempt) || 0), updatedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION }]);
        }
      }
      if (text(result.status) === 'succeeded' && entry.intent === 'v85-get-ping') {
        const ping = parseObject(text(result.body), null);
        const identity = syncV63Identity();
        if (!ping || text(ping.protocol) !== 'stadslass3.drift-ping.v1' || !identity || Number(ping.sequence) < 1) throw new Error('Närvarosignalen från 189 är ogiltig.');
        const replyAt = new Date().toISOString();
        const reply = { schemaVersion: 1, protocol: 'stadslass3.drift-pong.v1', vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: identity.installationId, replyToSequence: Number(ping.sequence), pingSentAt: text(ping.sentAt), repliedAt: replyAt };
        const queued = syncV63Enqueue('v85-put-reply', 'PUT', syncV85HandshakePath('planning-reply.json'), syncServiceApi.PRIORITIES.active, JSON.stringify(reply), '', 'v85/reply/189');
        if (queued.ok) { syncV89AppendPing(Number(ping.sequence), 'ping', 'received'); syncV89AppendPing(Number(ping.sequence), 'reply', 'sent'); }
        syncV85HandshakeSave({ lastPingSequence: Number(ping.sequence), lastPingAt: text(ping.sentAt), lastReplyAt: queued.ok ? replyAt : '', lastError: queued.ok ? '' : text(queued.status) });
      } else if (text(result.status) === 'succeeded' && entry.intent === 'v85-get-reply') {
        const reply = parseObject(text(result.body), null);
        const repliedTo = Number(reply && reply.replyToSequence);
        if (!reply || text(reply.protocol) !== 'stadslass3.drift-pong.v1' || repliedTo < 1) {
          syncV85HandshakeSave({ lastError: 'Svar saknas eller är ogiltigt.' });
        } else {
          syncV89MatchPing(repliedTo);
          syncV85HandshakeSave({ lastReplyAt: text(reply.repliedAt, new Date().toISOString()), lastReplySequence: repliedTo, lastError: '', contactConfirmed: true });
        }
      } else if (text(result.status) === 'succeeded' && entry.intent === 'v92-get-bing') {
        const bing = parseObject(text(result.body), null);
        const identity = syncV63Identity();
        if (!bing || text(bing.protocol) !== 'stadslass3.drift-bing.v2' || !identity || Number(bing.sequence) < 1) throw new Error('Bing-signalen från planeringsenheten är ogiltig.');
        const repliedAt = new Date().toISOString();
        const echo = { schemaVersion: 1, protocol: 'stadslass3.drift-bong.v2', vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: identity.installationId, replyToSequence: Number(bing.sequence), bingSentAt: text(bing.sentAt), repliedAt };
        const queued = syncV63Enqueue('v92-put-bing-reply', 'PUT', syncV85HandshakePath('vehicle-189-bing-echo.json'), syncServiceApi.PRIORITIES.active, JSON.stringify(echo), '', 'v92/bing-reply/189');
        if (queued.ok) { syncV92AppendBing(Number(bing.sequence), 'bing', 'received'); syncV92AppendBing(Number(bing.sequence), 'reply', 'sent'); }
        syncV92BingSave({ lastBingAt: text(bing.sentAt), lastBingSequence: Number(bing.sequence), lastReplyAt: queued.ok ? repliedAt : '', lastError: queued.ok ? '' : text(queued.status) });
      } else if (text(result.status) === 'succeeded' && entry.intent === 'v92-get-bing-reply') {
        const echo = parseObject(text(result.body), null);
        const repliedTo = Number(echo && echo.replyToSequence);
        if (!echo || text(echo.protocol) !== 'stadslass3.drift-bong.v2' || repliedTo < 1) {
          syncV92BingSave({ lastError: 'Svar saknas eller är ogiltigt.' });
        } else {
          syncV92MatchBing(repliedTo);
          syncV92BingSave({ lastReplyAt: text(echo.repliedAt, new Date().toISOString()), lastReplySequence: repliedTo, lastError: '', contactConfirmed: true });
        }
      } else if (text(result.status) === 'succeeded' && (['get-active', 'get-queue', 'get-results', 'get-commands', 'get-planning-ledger', 'get-on-demand-ledger', 'get-on-demand-index', 'get-on-demand-requests'].includes(text(entry.intent)) || text(entry.intent).startsWith('get-on-demand-part:'))) {
        const body = text(result.body);
        if (syncServiceApi.bytes(body) > service.maxResponseBody) throw new Error('Synksvaret är för stort.');
        const value = parseObject(body, null);
        if (!value && body) throw new Error('Synksvaret innehåller ogiltig JSON.');
        if (entry.intent === 'get-planning-ledger') {
          syncV63MergePlanningLedger(result);
        } else if (entry.intent === 'get-on-demand-ledger') {
          syncV63MergeOnDemandLedger(result);
        } else if (entry.intent === 'get-active' && value) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.active, '189');
          if (Number(value.sequence) >= syncV63LastActiveSequence) {
            syncV63LastActiveSequence = Number(value.sequence) || 0;
            syncV63CacheMirror('sync-v63-mirror-active', value);
          }
        } else if (entry.intent === 'get-queue' && value) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.queue, '189');
          syncV63CacheMirror('sync-v63-mirror-queue', value);
        } else if (entry.intent === 'get-results' && value) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.results, '189');
          syncV63CacheMirror('sync-v63-command-results', value);
          const resultById = new Map((Array.isArray(value.results) ? value.results : []).map((item) => [text(item.commandId), item]));
          const next = syncV63Outbox().map((item) => {
            if (!item || item.kind !== 'sync-v63-command' || !resultById.has(text(item.commandId))) return item;
            const commandResult = resultById.get(text(item.commandId));
            return { ...item, state: text(commandResult.status), commandResult, updatedAt: new Date().toISOString() };
          });
          syncV63SaveOutbox(next);
        } else if (entry.intent === 'get-on-demand-index' && value) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.onDemand, '189');
          syncV63CacheMirror('sync-v63-on-demand-index', value);
          const resultById = new Map((Array.isArray(value.results) ? value.results : []).map((item) => [text(item.onDemandRequestId), item]));
          syncV63SaveOutbox(syncV63Outbox().map((item) => item && item.kind === 'sync-v63-on-demand' && resultById.has(text(item.requestId)) ? { ...item, state: text(resultById.get(text(item.requestId)).status, 'completed'), result: resultById.get(text(item.requestId)), updatedAt: new Date().toISOString() } : item));
          (Array.isArray(value.results) ? value.results : []).filter((item) => text(item.status) === 'completed' && text(item.partPath)).forEach((item) => syncV63Enqueue(`get-on-demand-part:${text(item.onDemandRequestId)}`, 'GET', text(item.partPath), syncServiceApi.PRIORITIES.low, '', '', `get-on-demand-part/${text(item.onDemandRequestId)}`));
        } else if (text(entry.intent).startsWith('get-on-demand-part:') && value) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.onDemand, '189');
          syncV63CacheMirror(`sync-v63-on-demand-data-${text(value.onDemandRequestId)}`, value);
        } else if (entry.intent === 'get-commands' && value && isVehicleRole()) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.commands, '189');
          if (!queueLoaded) loadQueueIfNeeded();
          if (!activeJobLoaded) loadActiveJobIfNeeded();
          const identity = syncV63Identity();
          const seen = new Set(syncV63Outbox().filter((item) => item && item.kind === 'sync-v63-command-processed').map((item) => text(item.commandId)));
          const commands = Array.isArray(value.commands) ? value.commands : [];
          const results = [];
          let workingQueue = queueDocument;
          commands.forEach((cmd) => {
            const applied = syncServiceApi.applyCommand(workingQueue, activeJobDocument, cmd, '189', text(identity && identity.installationId), seen);
            workingQueue = applied.queue; results.push(applied.result); seen.add(text(cmd.commandId));
          });
          if (JSON.stringify(workingQueue) !== JSON.stringify(queueDocument)) {
            if (!persistQueue(workingQueue, 'Nya planeringsuppdrag har lagts i 189:s kö.')) throw new Error('189:s kö kunde inte sparas.');
            syncV63PublishQueue(workingQueue);
          }
          const audit = syncV63Outbox().filter((item) => item && item.kind !== 'sync-v63-command-processed');
          syncV63SaveOutbox([...audit, ...results.map((item) => ({ id: `sync-v63-command-${item.commandId}`, kind: 'sync-v63-command-processed', commandId: item.commandId, result: item, updatedAt: new Date().toISOString() }))]);
          const resultDoc = syncServiceApi.activeStatus({}, '189', text(identity && identity.installationId), 1, null);
          resultDoc.protocol = syncServiceApi.PROTOCOLS.results; resultDoc.results = results; resultDoc.publishedAt = new Date().toISOString();
          syncV63Enqueue('put-results', 'PUT', syncV63Path('command-results.json'), syncServiceApi.PRIORITIES.queue, JSON.stringify(resultDoc), '', 'command-results/189');
        } else if (entry.intent === 'get-on-demand-requests' && value && isVehicleRole()) {
          syncServiceApi.validateEnvelope(value, syncServiceApi.PROTOCOLS.onDemand, '189');
          const requests = Array.isArray(value.requests) ? value.requests.filter(isPlainObject) : [];
          const processed = syncV63Outbox().filter((item) => item && item.kind === 'sync-v63-on-demand-processed').map((item) => text(item.requestId));
          const results = [];
          requests.filter((item) => !processed.includes(text(item.onDemandRequestId))).forEach((requestValue) => {
            const type = text(requestValue.requestType);
            if (!['register', 'today', 'history', 'statistics'].includes(type) || text(requestValue.sourceRole) !== 'mobile') return;
            let payload = {};
            if (type === 'register') payload = { jobTypes: jobTypeItems, places: placeItems, quickChoices: quickChoiceRegistry && quickChoiceRegistry.items ? quickChoiceRegistry.items : [] };
            else {
              if (!historyLoaded) loadHistoryIfNeeded('history');
              const all = Array.isArray(historyDocument) ? historyDocument.filter((record) => text(record.trashState) !== 'trashed') : [];
              payload = { records: type === 'today' ? all.filter((record) => localDateKey(new Date(text(record.completedAt || record.updatedAt || Date.now()))) === localDateKey(new Date())) : all };
            }
            const serialized = JSON.stringify(payload);
            const partPath = syncV63Path(`on-demand/${text(requestValue.onDemandRequestId)}-1.json`);
            const tooLarge = syncServiceApi.bytes(serialized) > 800 * 1024;
            if (!tooLarge) {
              const identity = syncV63Identity();
              const responseDocument = { schemaVersion: 1, protocol: syncServiceApi.PROTOCOLS.onDemand, vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: text(identity && identity.installationId), publishedAt: new Date().toISOString(), onDemandRequestId: requestValue.onDemandRequestId, part: 1, totalParts: 1, payload };
              syncV63Enqueue(`put-on-demand-part:${text(requestValue.onDemandRequestId)}`, 'PUT', partPath, syncServiceApi.PRIORITIES.low, JSON.stringify(responseDocument), '', `on-demand/${text(requestValue.onDemandRequestId)}`);
            }
            results.push({ onDemandRequestId: requestValue.onDemandRequestId, requestType: type, status: tooLarge ? 'failed' : 'completed', generatedAt: new Date().toISOString(), itemCount: Array.isArray(payload.records) ? payload.records.length : 0, partPath: tooLarge ? '' : partPath, partCount: tooLarge ? 0 : 1, message: tooLarge ? 'Underlaget är för stort och behöver delas i fler delar.' : 'Läsunderlaget är klart.' });
          });
          if (results.length) {
            syncV63SaveOutbox([...syncV63Outbox(), ...results.map((item) => ({ id: `sync-v63-demand-processed-${item.onDemandRequestId}`, kind: 'sync-v63-on-demand-processed', requestId: item.onDemandRequestId, result: item, updatedAt: new Date().toISOString() }))]);
            const identity = syncV63Identity();
            const index = { schemaVersion: 1, protocol: syncServiceApi.PROTOCOLS.onDemand, vehicleId: '189', packageVersion: PACKAGE_VERSION, sourceInstallationId: text(identity && identity.installationId), publishedAt: new Date().toISOString(), results };
            syncV63Enqueue('put-on-demand-index', 'PUT', syncV63Path('on-demand-index.json'), syncServiceApi.PRIORITIES.low, JSON.stringify(index), '', 'on-demand-index/189');
          }
        }
      }
      if (text(result.status) === 'succeeded' && text(entry.intent) === 'put-planning-ledger') {
        syncV63SaveOutbox(syncV63Outbox().map((item) => item && item.kind === 'sync-v63-command' && text(item.state) === 'waiting_send' ? { ...item, state: 'waiting_result', updatedAt: new Date().toISOString() } : item));
      }
      if (text(result.status) === 'succeeded' && text(entry.intent) === 'put-on-demand-ledger') {
        syncV63SaveOutbox(syncV63Outbox().map((item) => item && item.kind === 'sync-v63-on-demand' && text(item.state) === 'waiting_send' ? { ...item, state: 'waiting_result', updatedAt: new Date().toISOString() } : item));
      }
      if (text(result.status) === 'conflict' && text(entry.intent) === 'put-planning-ledger') {
        const next = syncV63Outbox().map((item) => item && item.kind === 'sync-v63-command' && ['waiting_send', 'failed_retryable'].includes(text(item.state)) ? { ...item, state: (Number(item.mergeAttempts) || 0) + 1 >= syncServiceApi.SYNC_RUNTIME_POLICY_V63.maxMergeAttempts ? 'sync_conflict' : 'waiting_ledger', mergeAttempts: (Number(item.mergeAttempts) || 0) + 1, updatedAt: new Date().toISOString() } : item);
        syncV63SaveOutbox(next);
        if (next.some((item) => item && item.kind === 'sync-v63-command' && text(item.state) === 'waiting_ledger')) syncV63Enqueue('get-planning-ledger', 'GET', syncV63Path('planning-commands.json'), syncServiceApi.PRIORITIES.queue, '', '', 'get-planning-ledger/189');
      }
      if (typeof window.StadslassHost.acknowledgeSyncResult === 'function') window.StadslassHost.acknowledgeSyncResult(requestId);
      const consumed = syncServiceApi.consumeTerminal(syncV63Outbox(), requestId, result);
      if (consumed.consumed) syncV63SaveOutbox(consumed.entries);
    } catch (error) {
      syncDiagnosticObserve('sync-result-error', { requestId, errorCode: text(error && error.message, 'invalid-result'), durationMs: Date.now() - startedAt });
      watchdog.step('runtime.sync.v63.result.invalid', error.message || 'Synksvaret kunde inte tillämpas.', 'warning');
    }
    syncDiagnosticObserve('sync-result', { requestId, intent: text(entry.intent), operation: text(result.operation), path: text(result.path), result: text(result.status), pendingBefore, pendingAfter: syncOutboxLoaded ? syncOutboxDocument.length : null, durationMs: Date.now() - startedAt, errorCode: text(result.errorCode), error: text(result.error || result.message), supersededBy: text(result.supersededBy || result.replacedBy) });
    syncV63UpdateSettings({ lastSyncAt: new Date().toISOString(), lastSyncStatus: text(result.status) });
    renderSyncV63();
  }

  function renderSyncV63() {
    const intro = byId('sync-v63-intro');
    if (!intro) return;
    const available = syncV63HostAvailable();
    const configured = syncV63Configured();
    const configStatus = syncV65ConfigurationStatus();
    const tokenPresent = configured && configStatus.configured === true;
    const tokenLamp = byId('sync-v85-token-lamp'); const tokenStatus = byId('sync-v85-token-status');
    if (tokenLamp) tokenLamp.textContent = tokenPresent ? '🟢' : '🔴';
    if (tokenStatus) tokenStatus.textContent = tokenPresent ? 'Sparad' : 'Saknas';
    const handshake = isPlainObject(syncV63Configuration().v85Handshake) ? syncV63Configuration().v85Handshake : syncV85HandshakeState;
    const bingHandshake = isPlainObject(syncV63Configuration().bingHandshake) ? syncV63Configuration().bingHandshake : syncV92BingState;
    const handshakeOk = handshake.contactConfirmed === true;
    const pingLamp = byId('sync-v85-ping-lamp'); const pingStatus = byId('sync-v85-ping-status');
    const presenceRow = pingLamp && pingLamp.closest ? pingLamp.closest('p') : null;
    if (presenceRow) presenceRow.hidden = false;
    if (isVehicleRole() && pingLamp) pingLamp.textContent = handshakeOk ? '🟢' : '🔴';
    if (isVehicleRole() && pingStatus) pingStatus.textContent = handshakeOk ? `Kontakt bekräftad med Ping ${Number(handshake.lastReplySequence)}-1` : text(handshake.lastError, 'Väntar på första returnerade Ping.');
    if (isMobileRole() && pingLamp) pingLamp.textContent = bingHandshake.contactConfirmed === true ? '🟢' : '🔴';
    if (isMobileRole() && pingStatus) pingStatus.textContent = bingHandshake.contactConfirmed === true ? `Kontakt bekräftad med Bing ${Number(bingHandshake.lastReplySequence)}-1` : text(bingHandshake.lastError, 'Väntar på första returnerade Bing.');
    intro.textContent = !available ? 'Säker internetsync stöds inte av den här installationen. Appen fungerar fortsatt lokalt och reservöverföringen finns kvar.'
      : !DRIFT_SYNC_ENABLED ? 'Driftsync mellan 189, Mobil och Dator är tillfälligt avstängd. Lokalt arbete, uppdateringar och rapporter fungerar fortsatt.'
        : !configured ? 'Spara GitHub-inställningarna för att aktivera säker sync.'
          : 'Ansluten sync används för mobilens planering och läsande spegling av 189.';
    ['sync-v63-owner', 'sync-v63-repository', 'sync-v63-branch', 'sync-v63-token', 'sync-v63-save', 'sync-v63-clear'].forEach((id) => { const element = byId(id); if (element) element.disabled = !available; });
    ['sync-v63-check'].forEach((id) => { const element = byId(id); if (element) element.disabled = !available || !DRIFT_SYNC_ENABLED; });
    const syncNowButton = byId('sync-v63-now');
    if (syncNowButton) { syncNowButton.disabled = !available || !DRIFT_SYNC_ENABLED || syncV87ManualSyncRunning || syncV69CycleRunning; syncNowButton.textContent = syncV87ManualSyncRunning ? 'Synkar…' : 'Synka nu'; }
    document.querySelectorAll('button[data-sync-v63-demand]').forEach((element) => { element.disabled = !available || !DRIFT_SYNC_ENABLED; });
    const config = syncV63Configuration();
    if (byId('sync-v63-owner') && document.activeElement !== byId('sync-v63-owner')) byId('sync-v63-owner').value = text(config.owner);
    if (byId('sync-v63-repository') && document.activeElement !== byId('sync-v63-repository')) byId('sync-v63-repository').value = text(config.repository);
    if (byId('sync-v63-branch') && document.activeElement !== byId('sync-v63-branch')) byId('sync-v63-branch').value = text(config.branch, 'main');
    byId('sync-v63-mobile-mirror').hidden = !isMobileRole();
    byId('sync-v63-on-demand-panel').hidden = !isMobileRole();
    byId('sync-v63-diagnostics').hidden = !settingsTechnicalInfoEnabled();
    const active = syncV63MirrorEntry('sync-v63-mirror-active');
    const activeValue = active && active.value;
    const activeJob = activeValue && activeValue.activeJob;
    byId('sync-v63-active-mirror').textContent = !activeValue ? 'Ingen status från 189 har hämtats ännu.' : activeValue.hasActiveJob !== true ? `189 har inget aktivt arbete. Status publicerad ${formatTimestamp(activeValue.publishedAt)}.` : `${text(activeJob.jobTypeName, 'Uppdrag')} · ${text(activeJob.fromPlaceName, 'Från saknas')} → ${text(activeJob.destinationPlaceName, 'Till saknas')} · ${phaseLabel(text(activeJob.phase))}${text(activeJob.status) === 'paused' ? ' · Pausat' : ''}`;
    const list = byId('sync-v63-queue-mirror');
    if (list) {
      list.replaceChildren(); const mirror = syncV63MirrorEntry('sync-v63-mirror-queue'); const items = mirror && mirror.value && Array.isArray(mirror.value.items) ? mirror.value.items : [];
      if (!mirror) { const empty = document.createElement('div'); empty.className = 'empty-state'; empty.textContent = 'Ingen kö från 189 har hämtats ännu.'; list.appendChild(empty); }
      items.forEach((item) => { const card = document.createElement('article'); card.className = 'queue-card'; const title = document.createElement('h3'); title.textContent = text(item.jobTypeName, 'Uppdrag'); const route = document.createElement('p'); route.className = 'queue-route'; route.textContent = `${text(item.fromPlaceName, 'Från saknas')} → ${text(item.destinationPlaceName, 'Till saknas')}`; card.append(title, route); list.appendChild(card); });
    }
    byId('sync-v63-last-sync').textContent = formatTimestamp(config.lastSyncAt);
    byId('sync-v63-pending').textContent = String((syncServiceApi && syncServiceApi.counts(syncV63Outbox()).activeRequests) || 0);
    byId('sync-v63-active-published').textContent = formatTimestamp(config.lastActivePublishedAt);
    byId('sync-v63-queue-published').textContent = formatTimestamp(config.lastQueuePublishedAt);
    const hostConfiguration = syncV65ConfigurationStatus();
    const diagnostic = syncV65LastConfigDiagnostic || (isPlainObject(config.lastConfigurationAttempt) ? config.lastConfigurationAttempt : {});
    const outboxCounts = syncServiceApi && typeof syncServiceApi.counts === 'function' ? syncServiceApi.counts(syncV63Outbox()) : { activeRequests: 0, realWork: 0, journalItems: 0 };
    const knownKinds = new Set(['queue-transfer', 'queue-receipt', 'sync-v63-command', 'sync-v63-on-demand', 'sync-v63-request', 'sync-v69-terminal-journal', 'sync-v69-resource-state', 'sync-v69-put-retry', 'sync-v63-mirror-active', 'sync-v63-mirror-queue', 'sync-v63-command-results', 'sync-v63-on-demand-index', 'sync-v63-command-processed', 'sync-v63-on-demand-processed', SYNC_V89_PING_LOG_KIND]);
    const unknownPreserved = syncV63Outbox().filter((entry) => entry && !knownKinds.has(text(entry.kind)) && !text(entry.kind).startsWith('sync-v63-on-demand-data-')).length;
    const technicalValues = {
      'sync-v69-real-work': String(outboxCounts.realWork || 0),
      'sync-v69-terminal-journal': String(outboxCounts.journalItems || 0),
      'sync-v69-unknown': String(unknownPreserved),
      'sync-v69-empty-remote': config.lastEmptyRemoteAt ? `${text(config.lastEmptyRemoteIntent)} · ${formatTimestamp(config.lastEmptyRemoteAt)}` : 'Saknas',
      'sync-v69-conflict-retry': config.lastConflictRetryAt ? `${text(config.lastConflictRetryPath)} · försök ${Number(config.lastConflictRetryAttempt) || 1}` : 'Saknas',
      'sync-v65-host-version': hostInfo ? `${text(hostInfo.hostVersionName, 'Saknas')} (${Number(hostInfo.hostVersionCode) || 0})` : 'Saknas',
      'sync-v65-package-version': String(PACKAGE_VERSION),
      'sync-v65-transport-api': hostInfo ? String(Number(hostInfo.syncTransportApiVersion) || 0) : 'Saknas',
      'sync-v65-identity-api': hostInfo ? String(Number(hostInfo.deviceIdentityApiVersion) || 0) : 'Saknas',
      'sync-v65-credential-api': hostInfo ? String(Number(hostInfo.syncCredentialApiVersion) || 0) : 'Saknas',
      'sync-v65-configured': hostConfiguration.configured === true ? 'Konfigurerad' : (text(hostConfiguration.status, 'Saknas')),
      'sync-v65-config-status': text(diagnostic.status, 'Saknas'),
      'sync-v65-config-error': text(diagnostic.errorCode, text(hostConfiguration.errorCode, 'Saknas')),
      'sync-v65-host-error': text(diagnostic.hostError, 'Saknas')
    };
    Object.entries(technicalValues).forEach(([id, value]) => { const element = byId(id); if (element) element.textContent = value; });
    const lastDemand = syncV63Outbox().filter((entry) => entry && entry.kind === 'sync-v63-on-demand').sort((a, b) => text(b.updatedAt).localeCompare(text(a.updatedAt)))[0];
    if (byId('sync-v63-demand-status') && lastDemand && lastDemand.result) byId('sync-v63-demand-status').textContent = text(lastDemand.result.message, 'Läsunderlag är klart.');
    renderSyncV87QueueControls();
    renderSyncDiagnostic();
  }

  function syncV87QueueControls() { return window.StadslassSyncQueueControls || null; }
  function syncV87FormatAge(seconds) { return seconds < 60 ? `${seconds} sek` : `${Math.floor(seconds / 60)} min`; }
  function syncV87RecordLabel(record) { const label = record.channel === 'bing' ? 'Bing' : 'Ping'; return record.direction === 'reply' ? `${label} ${Number(record.sequence)}-1` : `${label} ${Number(record.sequence)}`; }
  function renderSyncV87QueueControls() {
    const controls = syncV87QueueControls(); const list = byId('sync-v87-queue-list');
    if (!controls || !list || !syncOutboxLoaded) return;
    const inspected = controls.inspect(syncV63Outbox(), Date.now());
    const lamp = byId('sync-v87-queue-lamp'); const summary = byId('sync-v87-queue-summary');
    if (lamp) lamp.textContent = inspected.matched.length ? '🟢' : '🔴';
    if (summary) summary.textContent = !inspected.records.length ? 'Tom' : `${inspected.records.length} signaler${inspected.matched.length ? ` – ${inspected.matched.length} bekräftade` : ''}`;
    list.replaceChildren();
    if (!inspected.records.length) { const empty = document.createElement('p'); empty.className = 'field-help'; empty.textContent = 'Ping- och Bingloggen är tom.'; list.appendChild(empty); }
    inspected.records.forEach((record) => {
      const card = document.createElement('article'); card.className = `sync-v87-queue-record${record.state === 'matched' ? ' is-matched' : ''}`;
      const title = document.createElement('strong'); title.textContent = syncV87RecordLabel(record);
      const details = document.createElement('p'); details.textContent = `${record.state === 'matched' ? 'Matchad' : (record.state === 'received' ? 'Mottagen' : 'Skickad')} · ${syncV87FormatAge(record.ageSeconds)}`;
      card.append(title, details);
      list.appendChild(card);
    });
    const clear = byId('sync-v87-clear'); if (clear) clear.disabled = !inspected.records.length;
    const confirm = byId('sync-v87-clear-confirm'); if (confirm) confirm.hidden = !syncV87ClearConfirmationOpen;
    if (syncV87ClearConfirmationOpen && byId('sync-v87-clear-confirm-text')) byId('sync-v87-clear-confirm-text').textContent = `Detta tar bort ${inspected.records.length} Ping- och Bingposter. Lokal kö, aktivt jobb, historik och inställningar påverkas inte.`;
  }
  function requestSyncV87Clear() {
    const controls = syncV87QueueControls(); if (!controls || !syncOutboxLoaded) return;
    const inspected = controls.inspect(syncV63Outbox(), Date.now());
    if (!inspected.records.length) { showStatus('sync-v87-queue-status', 'Det finns inga Ping- eller Bingposter att rensa.'); return; }
    syncV87ClearConfirmationOpen = true; renderSyncV87QueueControls();
  }
  function cancelSyncV87Clear() { syncV87ClearConfirmationOpen = false; renderSyncV87QueueControls(); showStatus('sync-v87-queue-status', 'Rensningen avbröts. Ping- och Bingloggen är oförändrad.'); }
  function confirmSyncV87Clear() {
    const controls = syncV87QueueControls(); if (!controls || !syncOutboxLoaded || !syncV87ClearConfirmationOpen) return;
    const cleared = controls.clearStuck(syncV63Outbox(), Date.now());
    if (!cleared.removed) { syncV87ClearConfirmationOpen = false; renderSyncV87QueueControls(); return; }
    if (!syncV63SaveOutbox(cleared.next)) { showStatus('sync-v87-queue-status', 'Synkkön kunde inte rensas. Inga poster har tagits bort.', true); return; }
    syncV85HandshakeSave({ contactConfirmed: false, lastReplySequence: 0, lastReplyAt: '', lastError: '' });
    syncV92BingSave({ contactConfirmed: false, lastReplySequence: 0, lastReplyAt: '', lastError: '' });
    syncV87ClearConfirmationOpen = false;
    showStatus('sync-v87-queue-status', `${cleared.removed} Ping- och Bingposter rensades.`);
    syncDiagnosticObserve('sync-queue-cleared', { removed: cleared.removed }); renderSyncV63();
  }
  function syncV87ManualSyncNow() {
    if (syncV87ManualSyncRunning || syncV69CycleRunning) { showStatus('sync-v63-status', 'Synkning pågår redan.'); return; }
    syncV87ManualSyncRunning = true; showStatus('sync-v63-status', 'Synkar…'); renderSyncV63();
    window.setTimeout(() => {
      try { syncV63SyncNow({ manual: true }); showStatus('sync-v63-status', 'Delvis klart – synkbegäran är skickad och inväntar resultat.'); }
      catch (error) { showStatus('sync-v63-status', `Synkningen kunde inte startas: ${text(error && error.message, 'okänt fel')}`, true); }
      finally { syncV87ManualSyncRunning = false; renderSyncV63(); }
    }, 0);
  }

  function liveReportStamp(value = new Date().toISOString()) {
    return text(value).replace(/[-:]/g, '').replace('T', '_').replace('Z', '').replace('.', '_');
  }

  function reportFileStamp(value = new Date().toISOString()) {
    const date = new Date(value);
    const safe = Number.isNaN(date.getTime()) ? new Date() : date;
    const part = (number) => String(number).padStart(2, '0');
    return `${safe.getFullYear()}-${part(safe.getMonth() + 1)}-${part(safe.getDate())}_${part(safe.getHours())}${part(safe.getMinutes())}${part(safe.getSeconds())}`;
  }

  function reportTypeConfig(type) {
    return type === 'performance'
      ? { key: PERFORMANCE_REPORT_SNAPSHOT_KEY, label: 'Prestandarapport', expectedType: 'performance', header: 'STADSLASS PRESTANDARAPPORT', textId: 'performance-report-text', summaryId: 'performance-report-summary', statusId: 'performance-report-status', filePrefix: 'prestandarapport' }
      : { key: SYNC_REPORT_SNAPSHOT_KEY, label: 'Synkrapport', expectedType: 'sync-verification', header: 'STADSLASS SYNKVERIFIERINGSRAPPORT', textId: 'sync-report-textarea', summaryId: 'sync-report-summary', statusId: 'sync-diagnostic-status', filePrefix: 'synkrapport' };
  }

  function currentReportSnapshot(type) {
    return type === 'performance' ? performanceReportSnapshot : syncReportSnapshot;
  }

  function setCurrentReportSnapshot(type, snapshot) {
    if (type === 'performance') performanceReportSnapshot = snapshot;
    else syncReportSnapshot = snapshot;
  }

  function normalizeReportSnapshot(type, raw) {
    const config = reportTypeConfig(type);
    if (!isPlainObject(raw)) return null;
    const content = text(raw.content);
    const reportId = text(raw.reportId);
    const generatedAt = text(raw.generatedAt);
    if (Number(raw.schemaVersion) !== REPORT_SNAPSHOT_SCHEMA_VERSION || text(raw.reportType) !== config.expectedType || !content.startsWith(config.header) || !reportId || !generatedAt) return null;
    const fileName = `${config.filePrefix}_v73_${reportFileStamp(generatedAt)}.txt`;
    return { schemaVersion: REPORT_SNAPSHOT_SCHEMA_VERSION, reportType: config.expectedType, reportId, generatedAt, packageVersion: Number(raw.packageVersion) || PACKAGE_VERSION, fileName, summary: text(raw.summary), content, eventCount: Math.max(0, Number(raw.eventCount) || 0), counts: isPlainObject(raw.counts) ? { ...raw.counts } : {} };
  }

  function loadStoredReportSnapshots() {
    performanceReportSnapshot = normalizeReportSnapshot('performance', settingsDocument[PERFORMANCE_REPORT_SNAPSHOT_KEY]);
    syncReportSnapshot = normalizeReportSnapshot('sync', settingsDocument[SYNC_REPORT_SNAPSHOT_KEY]);
  }

  function persistReportSnapshot(type, raw) {
    const config = reportTypeConfig(type);
    const snapshot = normalizeReportSnapshot(type, raw);
    if (!snapshot) throw new Error(`${config.label}en kunde inte verifieras och sparades inte.`);
    setCurrentReportSnapshot(type, snapshot);
    const next = { ...settingsDocument, [config.key]: snapshot, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(next))) throw new Error(window.StadslassHost.getLastError() || `${config.label}en skapades och visas, men kunde inte sparas lokalt.`);
    settingsDocument = next;
    return snapshot;
  }

  function clearStoredReportSnapshot(type) {
    const config = reportTypeConfig(type);
    const next = { ...settingsDocument, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    delete next[config.key];
    if (!window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(next))) throw new Error(window.StadslassHost.getLastError() || 'Rapportvyn kunde inte rensas.');
    settingsDocument = next;
    setCurrentReportSnapshot(type, null);
  }

  function reportSnapshotSummary(type, snapshot) {
    if (!snapshot) return type === 'performance' ? 'Ingen färdig prestandarapport finns.' : 'Ingen färdig synkrapport finns.';
    const created = formatTimestamp(snapshot.generatedAt);
    if (type === 'performance') return `${snapshot.eventCount} händelser · skapad ${created} · ligger kvar efter omstart.`;
    return `${Number(snapshot.counts.activeRequests) || 0} aktiva requests · ${snapshot.eventCount} trafikhändelser · skapad ${created} · ligger kvar efter omstart.`;
  }

  function renderReportSnapshot(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    const textarea = byId(config.textId);
    const summary = byId(config.summaryId);
    if (textarea) textarea.value = snapshot ? snapshot.content : '';
    if (summary) summary.textContent = reportSnapshotSummary(type, snapshot);
    const prefix = type === 'performance' ? 'performance-report' : 'sync-report';
    ['copy', 'download', 'mail', 'clear'].forEach((action) => { const button = byId(`${prefix}-${action}`); if (button) button.disabled = !snapshot; });
  }

  function renderReportViews() {
    renderReportSnapshot('performance');
    renderReportSnapshot('sync');
  }

  function renderReportMailProfile() {
    const input = byId('report-mail-email');
    const profile = syncReportProfile();
    if (input && document.activeElement !== input) input.value = text(profile.email);
  }

  function saveReportMailRecipient() {
    const email = text(byId('report-mail-email') && byId('report-mail-email').value);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showStatus('report-mail-status', 'Skriv en giltig mailadress.', true); return; }
    const current = syncReportProfile();
    const profile = { ...current, email };
    const next = { ...settingsDocument, syncReportMail: profile, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    if (!window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(next))) { showStatus('report-mail-status', window.StadslassHost.getLastError() || 'Rapportmottagaren kunde inte sparas.', true); return; }
    settingsDocument = next;
    showStatus('report-mail-status', 'Rapportmottagaren är sparad lokalt.');
  }

  function liveReportExportBusy() {
    return liveReportExports.size > 0;
  }

  function renderLiveReportExportState() {
    const busy = liveReportExportBusy();
    ['performance-report-download', 'sync-report-download'].forEach((id) => {
      const button = byId(id);
      if (button) button.disabled = busy || !currentReportSnapshot(id.startsWith('performance') ? 'performance' : 'sync');
    });
  }

  function validateLiveReportSnapshot(type, snapshot, expectedReportId) {
    const config = reportTypeConfig(type);
    const content = text(snapshot && snapshot.content);
    const reportType = text(snapshot && snapshot.reportType);
    const forbiddenHeader = type === 'performance' ? reportTypeConfig('sync').header : reportTypeConfig('performance').header;
    if (reportType !== config.expectedType || !content.startsWith(config.header) || content.startsWith(forbiddenHeader)) throw new Error('Rapporttypen kunde inte verifieras. Ingen fil skickades till spardialogen.');
    if (!content.includes(`Rapport-ID: ${expectedReportId}`) || !content.includes(`Funktionspaket: ${PACKAGE_VERSION}`)) throw new Error('Rapportens identitet kunde inte verifieras. Ingen fil skickades till spardialogen.');
    return content;
  }

  function beginLiveReportExport(type, snapshot, fileName) {
    if (liveReportExportBusy()) throw new Error('En rapportexport pågår redan. Slutför eller avbryt den först.');
    const reportId = text(snapshot && snapshot.reportId);
    const contentUtf8 = validateLiveReportSnapshot(type, snapshot, reportId);
    const requestId = `${type === 'performance' ? 'performance-report' : 'sync-report'}-export-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    liveReportExports.set(requestId, { type, fileName, reportId });
    renderLiveReportExportState();
    try {
      const result = parseObject(window.StadslassHost.requestTextFileExport(JSON.stringify({ schemaVersion: 1, requestId, fileName, mimeType: 'text/plain', contentUtf8 })), {});
      if (result.ok !== true) throw new Error('Rapporten finns kvar, men spardialogen kunde inte öppnas.');
      return requestId;
    } catch (error) {
      liveReportExports.delete(requestId);
      renderLiveReportExportState();
      throw error;
    }
  }

  function renderPerformanceDiagnostic() {
    const monitor = performanceEnsure();
    const summary = byId('performance-diagnostic-summary');
    if (!monitor || !summary || typeof monitor.state !== 'function') return;
    const value = monitor.state();
    const eventCount = Array.isArray(value.events) ? value.events.length : 0;
    const oldReport = Boolean(performanceReportSnapshot);
    summary.textContent = value.active
      ? `Prestandatest pågår · ${eventCount} händelser registrerade.${oldReport ? ' Rapportfältet visar senaste färdiga rapport.' : ''}`
      : `Prestandatest stoppat · ${eventCount} händelser registrerade.`;
    const stopButton = byId('performance-monitor-stop');
    const startButton = byId('performance-monitor-start-new');
    if (stopButton) stopButton.disabled = !value.active;
    if (startButton) startButton.disabled = value.active;
    renderReportSnapshot('performance');
  }

  function createPerformanceReportSnapshot() {
    const monitor = performanceEnsure();
    if (!monitor) throw new Error('Prestandaövervakningen saknas.');
    const reportId = `performance-v73-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const raw = monitor.snapshotReport({ reportId });
    return persistReportSnapshot('performance', { ...raw, schemaVersion: REPORT_SNAPSHOT_SCHEMA_VERSION, packageVersion: PACKAGE_VERSION, summary: `${raw.eventCount} prestandahändelser` });
  }

  function startNewPerformanceTest() {
    try {
      const monitor = performanceEnsure();
      if (!monitor) throw new Error('Prestandaövervakningen saknas.');
      if (monitor.state().active) throw new Error('Ett prestandatest pågår redan.');
      monitor.start({ reset: true });
      renderPerformanceDiagnostic();
      showStatus('performance-report-status', 'Nytt prestandatest startat. Den senaste färdiga rapporten ligger kvar tills en ny rapport skapas eller rapportvyn rensas.');
    } catch (error) { showStatus('performance-report-status', error.message || 'Prestandatestet kunde inte startas.', true); }
  }

  function stopPerformanceMonitor() {
    try {
      const monitor = performanceEnsure();
      if (!monitor || !monitor.state().active) throw new Error('Inget prestandatest pågår.');
      monitor.stop('manual-stop-and-create-report');
      const snapshot = createPerformanceReportSnapshot();
      renderPerformanceDiagnostic();
      showStatus('performance-report-status', `Prestandatestet är klart. ${snapshot.eventCount} händelser finns i rapportfältet och rapporten är sparad lokalt.`);
    } catch (error) { renderPerformanceDiagnostic(); showStatus('performance-report-status', error.message || 'Prestandarapporten kunde inte skapas.', true); }
  }

  function syncDiagnosticContext() {
    const identity = syncV63Identity() || {};
    const configuration = syncV63Configuration();
    const installationId = text(identity.installationId);
    const hostDeviceId = text(hostInfo && hostInfo.deviceId);
    return {
      hostVersion: text(hostInfo && hostInfo.hostVersionName),
      role: text(hostInfo && hostInfo.role),
      installationId,
      deviceId: hostDeviceId,
      identityTypesMatch: Boolean(installationId && hostDeviceId && installationId === hostDeviceId),
      syncConfiguration: { enabled: configuration.enabled === true, owner: text(configuration.owner), repository: text(configuration.repository), branch: text(configuration.branch), syncRoot: text(configuration.syncRoot) }
    };
  }

  function renderSyncDiagnostic() {
    const diagnostic = syncDiagnosticEnsure();
    const summary = byId('sync-diagnostic-summary');
    if (!diagnostic || !summary) return;
    const value = diagnostic.state();
    const counts = value.counts || {};
    summary.textContent = value.inventoryRunning ? 'Läsande synktest pågår. Synk- och arbetsdata ändras inte.' : value.inventoryFinishedAt ? `Senaste läsande synktest klart · ${value.observed} trafikhändelser · ${value.registers.length} register · ${value.entryCount} poster · ${Number(counts.activeRequests) || 0} aktiva requests.` : 'Kör ett läsande synktest för att skapa en rapport. Synk- och arbetsdata ändras inte.';
    byId('sync-diagnostic-events').textContent = String(value.observed);
    byId('sync-diagnostic-registers').textContent = String(value.registers.length);
    byId('sync-diagnostic-posts').textContent = String(value.entryCount);
    const activeElement = byId('sync-diagnostic-active-requests');
    const oldestElement = byId('sync-diagnostic-oldest-active');
    if (activeElement) activeElement.textContent = String(Number(counts.activeRequests) || 0);
    if (oldestElement) oldestElement.textContent = counts.activeRequests ? `${Number(counts.oldestActiveAgeSeconds) || 0} s` : 'Ingen';
    byId('sync-diagnostic-rerun').disabled = value.inventoryRunning;
    renderReportSnapshot('sync');
    renderPerformanceDiagnostic();
    renderLiveReportExportState();
  }

  function createSyncReportSnapshot() {
    const diagnostic = syncDiagnosticEnsure();
    if (!diagnostic) throw new Error('Synkdiagnostiken saknas.');
    const reportId = `sync-v73-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const monitor = performanceEnsure();
    const performanceState = monitor && typeof monitor.state === 'function' ? monitor.state() : {};
    const raw = diagnostic.snapshotReport({ reportId, performanceState });
    return persistReportSnapshot('sync', { ...raw, schemaVersion: REPORT_SNAPSHOT_SCHEMA_VERSION, packageVersion: PACKAGE_VERSION, summary: `${raw.eventCount} synchändelser` });
  }

  function runSyncDiagnosticInventory() {
    try {
      const diagnostic = syncDiagnosticEnsure();
      if (!diagnostic) throw new Error('Synkdiagnostiken saknas.');
      const result = diagnostic.inventory({ reason: 'manual-test' });
      if (!result.ok) throw new Error('Ett läsande synktest kör redan.');
      const snapshot = createSyncReportSnapshot();
      renderSyncDiagnostic();
      showStatus('sync-diagnostic-status', `Läsande synktest klart. Rapporten visas och är sparad lokalt. ${Number(snapshot.counts.activeRequests) || 0} aktiva requests hittades. Ingen synkpost har ändrats.`);
    } catch (error) { renderSyncDiagnostic(); showStatus('sync-diagnostic-status', error.message || 'Synktestet kunde inte slutföras.', true); }
  }

  function copyStoredReport(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    if (!snapshot) { showStatus(config.statusId, 'Ingen färdig rapport finns att kopiera.', true); return; }
    try {
      hostCopyText(config.label, snapshot.content);
      showStatus(config.statusId, `${config.label}en är kopierad. Fil och mail är säkrare för mycket långa rapporter.`);
    } catch (error) { showStatus(config.statusId, error.message || 'Rapporten kunde inte kopieras.', true); }
  }

  function downloadStoredReport(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    if (!snapshot) { showStatus(config.statusId, 'Ingen färdig rapport finns att ladda ner.', true); return; }
    try {
      if (!hostInfo || Number(hostInfo.textFileExportApiVersion) < 1 || typeof window.StadslassHost.requestTextFileExport !== 'function') throw new Error('Den här installationen saknar stöd för rapportfil.');
      beginLiveReportExport(type, snapshot, snapshot.fileName);
      showStatus(config.statusId, 'Välj var den redan färdiga rapporten ska sparas. Rapporten ligger kvar efter avbruten eller misslyckad sparning.');
    } catch (error) { showStatus(config.statusId, error.message || 'Spardialogen kunde inte öppnas. Rapporten ligger kvar.', true); }
  }

  function mailStoredReport(type) {
    const config = reportTypeConfig(type);
    const snapshot = currentReportSnapshot(type);
    try {
      if (!snapshot) throw new Error('Ingen färdig rapport finns att skicka.');
      const profile = syncReportProfile();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(profile.email))) throw new Error('Spara en giltig rapportmottagare först.');
      if (!mailService) throw new Error('Appens inbyggda mailtjänst saknas.');
      mailService.open({
        mailType: type === 'performance' ? 'performance-report' : 'sync-report',
        recipient: profile.email,
        subject: type === 'performance' ? `Prestandarapport v${PACKAGE_VERSION}` : `Synkrapport v${PACKAGE_VERSION}`,
        body: type === 'performance' ? 'Prestandarapporten finns bifogad som textfil.' : 'Synkrapporten finns bifogad som textfil.',
        attachment: { fileName: snapshot.fileName, mimeType: 'text/plain', contentUtf8: snapshot.content }
      }, hostInfo);
      showStatus(config.statusId, `${config.label}en har öppnats i mailappen med hela textfilen bifogad. Rapporten ligger kvar i Stadslass.`);
    } catch (error) { showStatus(config.statusId, error.message || 'Mailutkastet kunde inte öppnas. Rapporten ligger kvar.', true); }
  }

  function clearReportView(type) {
    const config = reportTypeConfig(type);
    try {
      clearStoredReportSnapshot(type);
      renderReportSnapshot(type);
      showStatus(config.statusId, 'Rapportvyn är rensad. Testhändelser, synkdata och arbetsdata är oförändrade.');
    } catch (error) { showStatus(config.statusId, error.message || 'Rapportvyn kunde inte rensas.', true); }
  }

  function syncReportProfile() {
    return isPlainObject(settingsDocument.syncReportMail) ? settingsDocument.syncReportMail : { name: '', email: '', subjectPrefix: 'Stadslass syncrapport', body: '' };
  }

  function saveSyncV63Configuration(event) {
    event.preventDefault();
    if (!syncV63HostAvailable() || typeof window.StadslassHost.setSyncConfiguration !== 'function') {
      const diagnostic = syncV65Diagnostic({ status: 'host_capability_missing', errorCode: 'sync_credential_api_missing' }, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Säker lagring av syncinställningar stöds inte av den här installationen.', true); renderSyncV63(); return;
    }
    const rawToken = byId('sync-v63-token').value;
    if (syncV65MaskedToken(rawToken)) {
      const diagnostic = syncV65Diagnostic({ status: 'invalid_request', errorCode: 'masked_token' });
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Klistra in den verkliga GitHub-token. Maskerade punkter kan inte användas.', true); renderSyncV63(); return;
    }
    const config = { owner: text(byId('sync-v63-owner').value), repository: text(byId('sync-v63-repository').value), branch: text(byId('sync-v63-branch').value), token: syncV65NormalizeToken(rawToken) };
    if (!config.owner || !config.repository || !config.branch || !config.token) {
      const diagnostic = syncV65Diagnostic({ status: 'invalid_request', errorCode: 'missing_field' });
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Fyll i ägare, repository, gren och GitHub-token.', true); renderSyncV63(); return;
    }
    let result = {};
    try { result = parseObject(window.StadslassHost.setSyncConfiguration(JSON.stringify(config)), {}); }
    catch (_) { result = { ok: false, status: 'host_error', errorCode: 'bridge_exception' }; }
    const hostError = syncV65HostLastError();
    if (result.ok !== true) {
      const diagnostic = syncV65Diagnostic(result, hostError);
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', syncV65ConfigurationErrorMessage(result), true); renderSyncV63(); return;
    }
    const confirmed = syncV65ConfigurationStatus();
    if (confirmed.ok !== true || confirmed.configured !== true) {
      const failed = { ...confirmed, ok: false, status: text(confirmed.status, 'configuration_missing'), errorCode: text(confirmed.errorCode, 'configuration_not_confirmed') };
      const diagnostic = syncV65Diagnostic(failed, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', syncV65ConfigurationErrorMessage(failed), true); renderSyncV63(); return;
    }
    const diagnostic = syncV65Diagnostic({ ...confirmed, status: 'configured', errorCode: '' }, '');
    syncV65LastConfigDiagnostic = diagnostic;
    // Token lämnar endast formuläret till den säkra hostbryggan och sparas aldrig i settings eller syncOutbox.
    byId('sync-v63-token').value = '';
    if (!syncV63UpdateSettings({ enabled: true, owner: config.owner, repository: config.repository, branch: config.branch, syncRoot: text(syncV63Configuration().syncRoot, 'stadslass-3-sync'), lastConfigurationAttempt: diagnostic })) {
      showStatus('sync-v63-status', 'Inställningarnas syncmetadata kunde inte sparas lokalt.', true); renderSyncV63(); return;
    }
    showStatus('sync-v63-status', 'Syncinställningarna är sparade säkert. Kontrollera anslutningen.');
    renderSyncV63();
  }

  function checkSyncV63Connection() {
    if (!DRIFT_SYNC_ENABLED) {
      showStatus('sync-v63-status', 'Driftsyncen mellan 189, Mobil och Dator är tillfälligt avstängd.');
      return;
    }
    if (!syncV63HostAvailable() || typeof window.StadslassHost.getSyncConfigurationStatus !== 'function') {
      showStatus('sync-v63-status', 'Säker anslutningskontroll stöds inte av den här installationen.', true); return;
    }
    const status = syncV65ConfigurationStatus();
    if (status.ok !== true || status.configured !== true) {
      const diagnostic = syncV65Diagnostic(status, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Ingen komplett säker synckonfiguration finns på enheten.', true); renderSyncV63(); return;
    }
    const result = syncV63Enqueue('connection-check', 'GET', syncV63Path('active-status.json'), syncServiceApi.PRIORITIES.active, '', '', 'connection-check/189');
    showStatus('sync-v63-status', result.ok ? 'Anslutningen kontrolleras säkert. Status visas när GitHub-läsningen är klar.' : 'Anslutningskontrollen kunde inte startas.', !result.ok);
  }

  function clearSyncV63Configuration() {
    if (!syncV63HostAvailable() || typeof window.StadslassHost.clearSyncConfiguration !== 'function') {
      showStatus('sync-v63-status', 'Säker radering av syncinställningar stöds inte av den här installationen.', true); return;
    }
    if (!window.confirm('Radera de säkra GitHub-syncinställningarna från denna enhet? Lokala uppdrag påverkas inte.')) return;
    const result = parseObject(window.StadslassHost.clearSyncConfiguration(), {});
    if (result.ok !== true) {
      const diagnostic = syncV65Diagnostic(result, syncV65HostLastError());
      syncV65RememberDiagnostic(diagnostic);
      showStatus('sync-v63-status', 'Syncinställningarna kunde inte raderas. Teknisk information visar felorsaken.', true); renderSyncV63(); return;
    }
    const diagnostic = syncV65Diagnostic({ status: 'cleared', errorCode: '', configured: false }, '');
    syncV65LastConfigDiagnostic = diagnostic;
    syncV63UpdateSettings({ enabled: false, owner: '', repository: '', branch: '', lastSyncStatus: 'configuration_cleared', lastConfigurationAttempt: diagnostic });
    showStatus('sync-v63-status', 'Syncinställningarna är raderade. Lokala uppdrag är oförändrade.');
    renderSyncV63();
  }

  function normalizedUiPreferences(documentValue) {
    const value = parseObject(JSON.stringify(documentValue[UI_SETTINGS_KEY] || {}), {});
    return {
      largeText: value.largeText === true,
      showTechnicalInfo: value.showTechnicalInfo === true
    };
  }

  function updateBottomNavReservedSpace() {
    if (bottomNavLayoutFrame !== null) {
      window.cancelAnimationFrame(bottomNavLayoutFrame);
    }
    bottomNavLayoutFrame = window.requestAnimationFrame(() => {
      bottomNavLayoutFrame = null;
      const nav = document.querySelector('.bottom-nav');
      const renderedHeight = nav ? Math.ceil(nav.getBoundingClientRect().height) : 0;
      const reservedHeight = Math.max(96, renderedHeight + 16);
      document.documentElement.style.setProperty('--bottom-nav-reserved-space', `${reservedHeight}px`);
    });
  }

  function installBottomNavLayoutGuard() {
    const nav = document.querySelector('.bottom-nav');
    updateBottomNavReservedSpace();
    window.addEventListener('resize', updateBottomNavReservedSpace);
    window.addEventListener('orientationchange', updateBottomNavReservedSpace);
    if (nav && typeof window.ResizeObserver === 'function') {
      bottomNavResizeObserver = new window.ResizeObserver(updateBottomNavReservedSpace);
      bottomNavResizeObserver.observe(nav);
    }
  }

  function phaseColorSettings(documentValue = settingsDocument) {
    return phaseVisualService.normalizeColors(isPlainObject(documentValue) ? documentValue[PHASE_COLOR_SETTINGS_KEY] : {});
  }

  function renderPhaseColorSettings() {
    const colors = phaseColorSettings();
    const controls = {
      start_route: 'phase-color-start-route',
      loading: 'phase-color-loading',
      transport: 'phase-color-transport',
      unloading: 'phase-color-unloading',
      load_registered: 'phase-color-load-registered',
      return_unloading: 'phase-color-return-unloading',
      ready_to_complete: 'phase-color-ready'
    };
    Object.entries(controls).forEach(([phase, id]) => {
      const control = byId(id);
      if (control) control.value = colors[phase];
    });
  }

  function readPhaseColorForm() {
    return phaseVisualService.normalizeColors({
      start_route: byId('phase-color-start-route').value,
      loading: byId('phase-color-loading').value,
      transport: byId('phase-color-transport').value,
      unloading: byId('phase-color-unloading').value,
      load_registered: byId('phase-color-load-registered').value,
      return_unloading: byId('phase-color-return-unloading').value,
      ready_to_complete: byId('phase-color-ready').value
    });
  }

  function syncActivePhaseBackdropVisibility() {
    const visible = currentView === 'active'
      && activeJobExists()
      && !isOtherActivity(activeJobDocument);
    document.documentElement.classList.toggle('phase-active-view', visible);
  }

  function clearActivePhaseVisuals() {
    const phaseBottom = byId('active-phase-bottom');
    const phaseAction = byId('active-phase-action');
    const rootStyle = document.documentElement.style;
    document.documentElement.classList.remove('phase-active-view');
    [
      '--active-phase-color',
      '--active-phase-button-color',
      '--active-phase-button-light',
      '--active-phase-text-color',
      '--active-phase-border-color',
      '--active-phase-backdrop-top',
      '--active-phase-backdrop-middle',
      '--active-phase-backdrop-bottom'
    ].forEach((property) => rootStyle.removeProperty(property));
    if (phaseBottom) {
      phaseBottom.classList.remove('has-phase-background');
      phaseBottom.style.removeProperty('--active-phase-color');
      phaseBottom.style.removeProperty('--active-phase-text-color');
    }
    if (phaseAction) {
      phaseAction.style.removeProperty('--active-phase-color');
      phaseAction.style.removeProperty('--active-phase-button-color');
      phaseAction.style.removeProperty('--active-phase-button-light');
      phaseAction.style.removeProperty('--active-phase-text-color');
      phaseAction.style.removeProperty('--active-phase-border-color');
    }
  }

  function applyActivePhaseVisuals(phase, otherActivity) {
    const phaseBottom = byId('active-phase-bottom');
    const phaseAction = byId('active-phase-action');
    if (!phaseBottom || !phaseAction || otherActivity) {
      clearActivePhaseVisuals();
      return;
    }
    const color = phaseVisualService.resolveColor(phase, settingsDocument[PHASE_COLOR_SETTINGS_KEY], phaseService);
    const palette = phaseVisualService.softPalette(color);
    const rootStyle = document.documentElement.style;
    rootStyle.setProperty('--active-phase-color', palette.base);
    rootStyle.setProperty('--active-phase-button-color', palette.button);
    rootStyle.setProperty('--active-phase-button-light', palette.buttonLight);
    rootStyle.setProperty('--active-phase-text-color', palette.text);
    rootStyle.setProperty('--active-phase-border-color', palette.border);
    rootStyle.setProperty('--active-phase-backdrop-top', palette.backdropTop);
    rootStyle.setProperty('--active-phase-backdrop-middle', palette.backdropMiddle);
    rootStyle.setProperty('--active-phase-backdrop-bottom', palette.backdropBottom);
    phaseBottom.classList.add('has-phase-background');
    phaseBottom.style.setProperty('--active-phase-color', palette.base);
    phaseBottom.style.setProperty('--active-phase-text-color', palette.text);
    phaseAction.style.setProperty('--active-phase-color', palette.base);
    phaseAction.style.setProperty('--active-phase-button-color', palette.button);
    phaseAction.style.setProperty('--active-phase-button-light', palette.buttonLight);
    phaseAction.style.setProperty('--active-phase-text-color', palette.text);
    phaseAction.style.setProperty('--active-phase-border-color', palette.border);
    syncActivePhaseBackdropVisibility();
  }

  function applyUiPreferences(preferences) {
    document.documentElement.classList.toggle('large-text', preferences.largeText);
    byId('large-text').checked = preferences.largeText;
    byId('show-technical').checked = preferences.showTechnicalInfo;
    renderPhaseColorSettings();
    renderSettingsWorkspace(false);
    if (activeJobLoaded && activeJobExists()) renderActiveJob();
    updateBottomNavReservedSpace();
  }

  function settingsTechnicalInfoEnabled() {
    return normalizedUiPreferences(settingsDocument).showTechnicalInfo;
  }

  function scrollSettingsContentIntoView(element) {
    if (!element || element.hidden) return;
    window.requestAnimationFrame(() => {
      const topbar = document.querySelector('.topbar');
      const topbarHeight = topbar ? Math.ceil(topbar.getBoundingClientRect().height) : 0;
      const targetTop = currentScrollY() + element.getBoundingClientRect().top - topbarHeight - 12;
      window.scrollTo({ top: Math.max(0, targetTop), behavior: 'auto' });
    });
  }

  function ataNotificationSettings() {
    return ataNotificationApi.settingsFromDocument(settingsDocument);
  }

  function persistAtaNotificationSettings(nextSettings, statusId, successMessage) {
    const nextDocument = ataNotificationApi.documentWithSettings(settingsDocument, nextSettings);
    nextDocument.settingsSchemaVersion = 1;
    nextDocument.settingsUpdatedByPackageVersion = PACKAGE_VERSION;
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus(statusId, window.StadslassHost.getLastError() || 'Uppgifterna kunde inte sparas lokalt.', true);
      return false;
    }
    settingsDocument = nextDocument;
    if (successMessage) showStatus(statusId, successMessage);
    return true;
  }

  function ataRecipientIds(scope) {
    const prefix = scope === 'quick' ? 'quick-choice-registry' : (scope === 'jobtype' ? 'job-type-registry' : (scope === 'active' ? 'active-job' : 'job'));
    return { prefix, panel: `${prefix}-ata-recipient-panel`, contact: `${prefix}-ata-contact`, name: `${prefix}-ata-recipient-name`, email: `${prefix}-ata-recipient-email`, clear: `${prefix}-ata-recipient-clear`, toggle: scope === 'quick' ? 'quick-choice-registry-ata-default' : (scope === 'jobtype' ? 'job-type-registry-ata-enabled' : `${prefix}-ata`) };
  }

  function ataRecipientInput(scope) {
    const ids = ataRecipientIds(scope);
    return { name: text(byId(ids.name) && byId(ids.name).value), email: text(byId(ids.email) && byId(ids.email).value), contactId: text(byId(ids.contact) && byId(ids.contact).value) || null };
  }

  function writeAtaRecipientInput(scope, recipient) {
    const ids = ataRecipientIds(scope);
    const value = recipient || {};
    if (byId(ids.name)) byId(ids.name).value = text(value.name);
    if (byId(ids.email)) byId(ids.email).value = text(value.email);
    if (byId(ids.contact)) byId(ids.contact).value = text(value.contactId);
  }

  function renderAtaRecipientContacts(scope, selected = null) {
    const ids = ataRecipientIds(scope);
    const select = byId(ids.contact);
    if (!select || !ataNotificationApi) return;
    const previous = text(selected && selected.contactId, select.value);
    select.replaceChildren();
    const empty = document.createElement('option'); empty.value = ''; empty.textContent = 'Ingen sparad mottagare'; select.appendChild(empty);
    ataNotificationApi.contactsForDisplay(ataNotificationSettings()).forEach((contact) => {
      const option = document.createElement('option'); option.value = contact.id; option.textContent = ataNotificationApi.recipientListLabel(contact); select.appendChild(option);
    });
    if (selectContainsValue(select, previous)) select.value = previous;
  }

  function selectAtaRecipientContact(scope) {
    const ids = ataRecipientIds(scope);
    const contact = ataNotificationApi && ataNotificationApi.contactsForDisplay(ataNotificationSettings()).find((item) => item.id === text(byId(ids.contact).value));
    if (contact) writeAtaRecipientInput(scope, { contactId: contact.id, name: contact.name, email: contact.email });
  }

  function clearAtaRecipient(scope) {
    writeAtaRecipientInput(scope, null);
    renderAtaRecipientContacts(scope, null);
  }

  function ensureAtaRecipientContact(rawRecipient, source, statusId) {
    const result = ataRouting.recipientForSave(rawRecipient, ataNotificationSettings().contacts, source, new Date().toISOString());
    if (!result.recipient) return null;
    if (result.contact) {
      const proposal = ataNotificationApi.saveContact(ataNotificationSettings(), result.contact);
      const next = ataNotificationApi.commitContact(proposal.settings, proposal.contact);
      if (!persistAtaNotificationSettings(next, statusId, 'Mottagaren är sparad i den lokala ÄTA-adressboken.')) throw new Error('Mottagaren kunde inte sparas i den lokala ÄTA-adressboken.');
      return { ...result.recipient, contactId: proposal.contact.id };
    }
    return result.recipient;
  }

  function syncAtaForm(scope, resetForJobType = false) {
    const ids = ataRecipientIds(scope);
    const typeId = scope === 'quick' ? byId('quick-choice-registry-job-type').value : (scope === 'jobtype' ? editingEditableJobTypeId : byId(scope === 'active' ? 'active-job-type' : 'job-type').value);
    const jobType = findJobTypeById(typeId);
    const toggle = byId(ids.toggle);
    const choice = toggle && toggle.closest('.choice-row');
    if (!toggle || !ataRouting) return;
    const isManual = ataRouting.isManualJobType(jobType);
    const isFixedAta = ataRouting.jobTypeEnabled(jobType);
    if (scope === 'jobtype') {
      const manualNote = byId('job-type-registry-ata-manual-note');
      if (choice) choice.hidden = isManual;
      if (manualNote) manualNote.hidden = !isManual;
      toggle.disabled = isManual;
      if (resetForJobType) toggle.checked = isManual ? false : isFixedAta;
      byId(ids.panel).hidden = !(isManual || toggle.checked);
      renderAtaRecipientContacts(scope, ataRecipientInput(scope));
      return;
    }
    const showToggle = isManual || isFixedAta;
    if (choice) choice.hidden = !showToggle;
    toggle.disabled = false;
    if (resetForJobType) toggle.checked = isFixedAta;
    // A historic queue job keeps its own saved ÄTA truth even if its current
    // Jobbtyp would not expose a manual checkbox in package 59.
    const enabled = toggle.checked === true;
    byId(ids.panel).hidden = !enabled;
    if (enabled && resetForJobType && !ataRecipientInput(scope).email) writeAtaRecipientInput(scope, ataRouting.defaultRecipient(jobType));
    renderAtaRecipientContacts(scope, ataRecipientInput(scope));
  }

  function ataNotificationTemplateInput() {
    const fields = {};
    ataNotificationApi.TEMPLATE_FIELDS.forEach((field) => {
      const input = byId(`ata-notification-template-${field}`);
      fields[field] = !input || input.checked;
    });
    return { fields, closingText: byId('ata-notification-template-closing').value };
  }

  function flushAtaNotificationTemplate() {
    if (ataNotificationTemplateTimer !== null) {
      window.clearTimeout(ataNotificationTemplateTimer);
      ataNotificationTemplateTimer = null;
    }
    const panel = byId('ata-notification-settings-card');
    if (!panel || panel.hidden || !ataNotificationApi) return;
    const next = ataNotificationApi.updateTemplate(ataNotificationSettings(), ataNotificationTemplateInput());
    const active = Object.values(next.template.fields).filter(Boolean).length;
    persistAtaNotificationSettings(next, 'ata-notification-template-status', `Mailmall sparad lokalt. ${active} av 12 standardfält är aktiva.`);
  }

  function scheduleAtaNotificationTemplateSave() {
    if (ataNotificationTemplateTimer !== null) window.clearTimeout(ataNotificationTemplateTimer);
    ataNotificationTemplateTimer = window.setTimeout(flushAtaNotificationTemplate, 350);
  }

  function renderAtaNotificationSettings() {
    if (!ataNotificationApi) return;
    const settings = ataNotificationSettings();
    const supervisor = settings.supervisor || {};
    const supervisorName = byId('ata-notification-supervisor-name');
    const supervisorEmail = byId('ata-notification-supervisor-email');
    if (supervisorName && document.activeElement !== supervisorName) supervisorName.value = supervisor.name || '';
    if (supervisorEmail && document.activeElement !== supervisorEmail) supervisorEmail.value = supervisor.email || '';
    const templateLabels = { jobType: 'Jobbtyp', fromPlace: 'Från-plats', toPlace: 'Till-plats', returnPlace: 'Returplats', date: 'Datum', startedAt: 'Starttid', completedAt: 'Sluttid', billableTime: 'Debiterbar tid', loadCount: 'Antal lass', totalWeight: 'Total vikt', note: 'Kommentar', truck189: 'Lastbil 189' };
    const fields = byId('ata-notification-template-fields');
    if (fields && !fields.childElementCount) {
      ataNotificationApi.TEMPLATE_FIELDS.forEach((field) => {
        const label = document.createElement('label'); label.className = 'choice-row compact-choice-row'; label.htmlFor = `ata-notification-template-${field}`;
        const input = document.createElement('input'); input.id = `ata-notification-template-${field}`; input.type = 'checkbox';
        const span = document.createElement('span'); const strong = document.createElement('strong'); strong.textContent = templateLabels[field]; span.append(strong);
        label.append(input, span); fields.append(label);
      });
    }
    ataNotificationApi.TEMPLATE_FIELDS.forEach((field) => { const input = byId(`ata-notification-template-${field}`); if (input && document.activeElement !== input) input.checked = settings.template.fields[field] !== false; });
    const closing = byId('ata-notification-template-closing');
    if (closing && document.activeElement !== closing) closing.value = settings.template.closingText || '';
    const list = byId('ata-notification-contact-list');
    if (!list) return;
    list.replaceChildren();
    const contacts = ataNotificationApi.contactsForDisplay(settings);
    if (!contacts.length) { const empty = document.createElement('p'); empty.className = 'empty-state'; empty.textContent = 'Inga mottagare är sparade.'; list.append(empty); return; }
    contacts.forEach((contact) => {
      const card = document.createElement('article'); card.className = 'registry-card';
      const header = document.createElement('div'); header.className = 'registry-card-header';
      const title = document.createElement('h4'); title.textContent = ataNotificationApi.recipientListLabel(contact);
      header.append(title);
      const email = document.createElement('p'); email.className = 'queue-meta'; email.textContent = contact.email;
      const actions = document.createElement('div'); actions.className = 'registry-actions';
      const edit = document.createElement('button'); edit.type = 'button'; edit.className = 'secondary-button'; edit.dataset.ataNotificationEdit = contact.id; edit.textContent = 'Redigera';
      const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'danger-button'; remove.dataset.ataNotificationRemove = contact.id; remove.textContent = 'Ta bort';
      actions.append(edit, remove); card.append(header, email, actions); list.append(card);
    });
  }

  function resetAtaNotificationContactForm(message = '') {
    byId('ata-notification-contact-id').value = '';
    byId('ata-notification-contact-name').value = '';
    byId('ata-notification-contact-email').value = '';
    byId('ata-notification-contact-submit').textContent = 'Spara mottagare';
    if (message) showStatus('ata-notification-contact-status', message);
  }

  function setAtaNotificationConfirmation(message, acceptLabel, action, anchorId = '') {
    ataNotificationPendingAction = action;
    const confirmation = byId('ata-notification-confirm');
    const anchor = anchorId ? byId(anchorId) : null;
    if (!confirmation) return;
    if (anchor && anchor.parentNode) anchor.insertAdjacentElement('afterend', confirmation);
    byId('ata-notification-confirm-text').textContent = message;
    byId('ata-notification-confirm-accept').textContent = acceptLabel;
    confirmation.hidden = false;
    scrollSettingsContentIntoView(confirmation);
  }

  function clearAtaNotificationConfirmation() {
    ataNotificationPendingAction = null;
    byId('ata-notification-confirm').hidden = true;
  }

  function editAtaNotificationContact(id) {
    const contact = ataNotificationSettings().contacts.find((item) => item.id === id);
    if (!contact) return showStatus('ata-notification-contact-status', 'Mottagaren saknas.', true);
    byId('ata-notification-contact-id').value = contact.id;
    byId('ata-notification-contact-name').value = contact.name;
    byId('ata-notification-contact-email').value = contact.email;
    byId('ata-notification-contact-submit').textContent = 'Spara ändringar';
    showStatus('ata-notification-contact-status', `Redigerar ${contact.name}.`);
    scrollSettingsContentIntoView(byId('ata-notification-contact-form'));
    window.setTimeout(() => { const input = byId('ata-notification-contact-name'); if (input) input.focus({ preventScroll: true }); }, 0);
  }

  function saveAtaNotificationContact(event) {
    event.preventDefault();
    try {
      const input = { id: byId('ata-notification-contact-id').value, name: byId('ata-notification-contact-name').value, email: byId('ata-notification-contact-email').value };
      const result = ataNotificationApi.saveContact(ataNotificationSettings(), input);
      const previous = result.isEdit ? ataNotificationSettings().contacts.find((contact) => contact.id === result.contact.id) : null;
      const commit = () => {
        if (!persistAtaNotificationSettings(ataNotificationApi.commitContact(result.settings, result.contact), 'ata-notification-contact-status', 'Mottagare sparad lokalt.')) return;
        if (previous) propagateAtaContactToPlanningData(previous, result.contact);
        resetAtaNotificationContactForm(); renderAtaNotificationSettings(); clearAtaNotificationConfirmation();
      };
      if (result.requiresConfirmation) {
        const existing = result.duplicates[0];
        setAtaNotificationConfirmation(`${existing.name} använder redan ${existing.email}. Spara ändå?`, 'Spara ändå', commit, 'ata-notification-contact-status');
        return;
      }
      commit();
    } catch (error) { showStatus('ata-notification-contact-status', error.message || 'Mottagaren kunde inte sparas.', true); }
  }

  function propagateAtaContactToPlanningData(previous, contact) {
    const updatedContact = { ...contact, previousEmail: previous.email };
    let changedSettings = false;
    let nextJobTypes = editableJobTypeRegistry;
    let nextQuickChoices = quickChoiceRegistry;
    if (editableJobTypeRegistry) {
      const items = editableJobTypeRegistry.items.map((item) => {
        const recipient = item.ataRecipient;
        const matches = recipient && (recipient.contactId === contact.id || ataRouting.emailKey(recipient.email) === ataRouting.emailKey(previous.email));
        if (!matches) return item;
        changedSettings = true;
        return { ...item, ataRecipient: { ...recipient, contactId: contact.id, name: contact.name, email: contact.email, emailKey: ataRouting.emailKey(contact.email) } };
      });
      if (changedSettings) nextJobTypes = editableJobTypeApi.withItems(editableJobTypeRegistry, items, new Date().toISOString());
    }
    if (quickChoiceRegistry) {
      const items = ataRouting.propagateRecipient(quickChoiceRegistry.items.map((item) => item.ataRecipient ? { ...item, ata: { recipient: item.ataRecipient } } : item), updatedContact)
        .map((item) => item.ata ? { ...item, ataRecipient: item.ata.recipient, ata: undefined } : item);
      if (JSON.stringify(items) !== JSON.stringify(quickChoiceRegistry.items)) { nextQuickChoices = quickChoiceApi.withItems(quickChoiceRegistry, items, new Date().toISOString()); changedSettings = true; }
    }
    if (changedSettings) {
      const nextDocument = { ...settingsDocument, [editableJobTypeApi.SETTINGS_KEY]: nextJobTypes, [quickChoiceApi.SETTINGS_KEY]: nextQuickChoices, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
      if (window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument))) { settingsDocument = nextDocument; editableJobTypeRegistry = nextJobTypes; quickChoiceRegistry = nextQuickChoices; applyEffectiveJobTypeRegistry(nextJobTypes.items); }
    }
    if (queueLoaded) {
      const nextQueue = ataRouting.propagateRecipient(queueDocument, updatedContact, (job) => text(job.status) === 'queued' && job.pausedFromActive !== true);
      if (JSON.stringify(nextQueue) !== JSON.stringify(queueDocument) && window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextQueue))) { queueDocument = nextQueue; renderQueue(); }
    }
  }

  function handleAtaNotificationContactList(event) {
    const edit = event.target.closest('button[data-ata-notification-edit]');
    const remove = event.target.closest('button[data-ata-notification-remove]');
    if (edit) return editAtaNotificationContact(edit.dataset.ataNotificationEdit || '');
    if (remove) {
      const contact = ataNotificationSettings().contacts.find((item) => item.id === remove.dataset.ataNotificationRemove);
      if (!contact) return;
      setAtaNotificationConfirmation(`Ta bort ${contact.name}, ${contact.email} från ÄTA-adressboken?`, 'Bekräfta borttagning', () => { try { const result = ataNotificationApi.removeContact(ataNotificationSettings(), contact.id); if (persistAtaNotificationSettings(result.settings, 'ata-notification-contact-status', 'Mottagaren har tagits bort.')) { if (byId('ata-notification-contact-id').value === contact.id) resetAtaNotificationContactForm(); renderAtaNotificationSettings(); clearAtaNotificationConfirmation(); } } catch (error) { showStatus('ata-notification-contact-status', error.message, true); clearAtaNotificationConfirmation(); } }, 'ata-notification-contact-status');
    }
  }

  function renderSettingsWorkspace(shouldScroll = false) {
    if (activeSettingsFunction !== 'ata-notification') flushAtaNotificationTemplate();
    const workspace = byId('settings-workspace');
    if (!workspace) return;

    document.querySelectorAll('.settings-group-button[data-settings-group]').forEach((button) => {
      const active = button.dataset.settingsGroup === activeSettingsGroup;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-expanded', active ? 'true' : 'false');
    });

    document.querySelectorAll('[data-settings-group-view]').forEach((view) => {
      view.hidden = view.dataset.settingsGroupView !== activeSettingsGroup;
    });

    const hasOpenGroup = Boolean(activeSettingsGroup);
    workspace.hidden = !hasOpenGroup;

    let activePanel = null;
    document.querySelectorAll('.settings-function-button[data-settings-function]').forEach((button) => {
      const active = button.dataset.settingsGroupOwner === activeSettingsGroup
        && button.dataset.settingsFunction === activeSettingsFunction;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-expanded', active ? 'true' : 'false');
    });

    document.querySelectorAll('[data-settings-function-panel]').forEach((panel) => {
      const active = panel.dataset.settingsGroupOwner === activeSettingsGroup
        && panel.dataset.settingsFunctionPanel === activeSettingsFunction;
      panel.hidden = !active;
      if (active) activePanel = panel;
    });

    document.querySelectorAll('[data-settings-function-workspace]').forEach((functionWorkspace) => {
      functionWorkspace.hidden = functionWorkspace.dataset.settingsFunctionWorkspace !== activeSettingsGroup
        || !activeSettingsFunction;
    });

    const technicalPanel = byId('technical-panel');
    const technicalDisabledNote = byId('technical-disabled-note');
    const technicalGroupOpen = activeSettingsGroup === 'control-troubleshooting';
    const technicalEnabled = settingsTechnicalInfoEnabled();
    if (technicalPanel) technicalPanel.hidden = !(technicalGroupOpen && technicalEnabled);
    if (technicalDisabledNote) technicalDisabledNote.hidden = !(technicalGroupOpen && !technicalEnabled);

    if (!shouldScroll || !hasOpenGroup) return;
    const groupView = Array.from(document.querySelectorAll('[data-settings-group-view]'))
      .find((view) => view.dataset.settingsGroupView === activeSettingsGroup) || null;
    scrollSettingsContentIntoView(activePanel || groupView || workspace);
    if (activePanel && activeSettingsFunction === 'ata-notification') renderAtaNotificationSettings();
  }

  function formatGpsCoordinate(value) {
    return Number.isFinite(value) ? value.toFixed(6) : '–';
  }

  function formatGpsAge(age) {
    if (!Number.isFinite(age)) return '–';
    const seconds = Math.max(0, Math.floor(age / 1000));
    if (seconds < 60) return `${seconds} s`;
    const minutes = Math.floor(seconds / 60);
    const remainder = seconds % 60;
    return `${minutes} min ${remainder} s`;
  }

  function formatGpsTimestamp(value) {
    if (!Number.isFinite(value)) return '–';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '–' : date.toLocaleString('sv-SE');
  }

  function renderGpsSnapshot(snapshot) {
    if (runtimeDisposed || runtimeFailed || !snapshot || !byId('gps-current-status')) return;
    byId('gps-current-status').textContent = snapshot.status;
    byId('gps-latitude').textContent = formatGpsCoordinate(snapshot.latitude);
    byId('gps-longitude').textContent = formatGpsCoordinate(snapshot.longitude);
    byId('gps-accuracy').textContent = Number.isFinite(snapshot.accuracy)
      ? `${Math.round(snapshot.accuracy)} m`
      : '–';
    byId('gps-timestamp').textContent = formatGpsTimestamp(snapshot.timestamp);
    byId('gps-age').textContent = formatGpsAge(snapshot.age);
    byId('gps-fresh').textContent = snapshot.isFresh ? 'Ja' : 'Nej';
    byId('gps-low-accuracy').textContent = snapshot.hasLowAccuracy ? 'Ja' : 'Nej';
    byId('gps-usable').textContent = snapshot.isUsable ? 'Ja' : 'Nej';
    byId('gps-watching').textContent = snapshot.isWatching ? 'Körs' : 'Stoppad';
    byId('gps-reasons').textContent = snapshot.activeReasons.length > 0
      ? snapshot.activeReasons.join(', ')
      : 'Ingen behovskälla';
    byId('gps-app-state').textContent = snapshot.appState === 'bakgrund' ? 'Bakgrund' : 'Förgrund';
    byId('gps-error-code').textContent = snapshot.errorCode === null ? '–' : String(snapshot.errorCode);
    byId('gps-latest-error').textContent = snapshot.latestError || '–';
    byId('gps-consumer-count').textContent = String(snapshot.activeConsumers.length);

    const permanentDenied = snapshot.status === 'Behörighet permanent nekad';
    byId('gps-permission-guidance').hidden = !permanentDenied;
    const retryStatuses = new Set([
      'Behörighet nekad',
      'Behörighet permanent nekad',
      'Behörighet återkallad',
      'Positionstjänst avstängd eller otillgänglig',
      'Position kunde inte hämtas',
      'GPS-fel'
    ]);
    byId('gps-retry').hidden = !(snapshot.activeConsumers.length > 0 && retryStatuses.has(snapshot.status));
  }

  function gpsDiagnosticsIsOpen() {
    return currentView === 'settings'
      && activeSettingsGroup === 'control-troubleshooting'
      && activeSettingsFunction === 'gps-status';
  }

  function syncGpsDiagnosticsConsumer() {
    if (!gpsService || !gpsRuntimeReady) return;
    gpsService.setConsumer('gpsDiagnostics', gpsDiagnosticsIsOpen(), 'GPS-status');
  }

  function activeJobNeedsGps(documentValue = activeJobDocument) {
    return activeJobLoaded
      && activeJobExists()
      && !isOtherActivity(documentValue)
      && ['active', 'completing'].includes(text(documentValue.status));
  }

  function syncActiveJobGpsConsumer() {
    if (!gpsService || !gpsRuntimeReady) return;
    gpsService.setConsumer('activeJob', activeJobNeedsGps(), 'Aktivt jobb');
  }

  function activeGeofenceContext(documentValue = activeJobDocument) {
    if (!activeJobLoaded || !activeJobExists() || isOtherActivity(documentValue) || text(documentValue.status) !== 'active') return null;
    const phase = phaseService.normalizePhase(text(documentValue.phase));
    let placeRole = '';
    let placeId = '';
    if (phase === phaseService.PHASES.START_ROUTE || phase === phaseService.PHASES.LOADING) {
      placeRole = 'from';
      placeId = text(documentValue.fromPlaceId);
    } else if (phase === phaseService.PHASES.TRANSPORT || phase === phaseService.PHASES.UNLOADING) {
      placeRole = 'destination';
      placeId = text(documentValue.destinationPlaceId);
    } else if (phase === phaseService.PHASES.RETURN_TRANSPORT || phase === phaseService.PHASES.RETURN_UNLOADING) {
      placeRole = 'return';
      placeId = text(documentValue.returnPlaceId, text(documentValue.fromPlaceId));
    }
    if (!placeId) return null;
    const place = resolveJobPlace(documentValue, placeRole);
    if (!place || text(place.id) !== placeId || !place.geofence || place.geofence.enabled !== true) return null;
    return { active: true, jobId: stableJobId(documentValue, 'active'), placeId, placeRole, geofence: place.geofence, dynamicCurrentLocation: false };
  }

  function syncActiveGeofenceContext() {
    if (!geofenceService || !geofenceRuntimeReady) return;
    geofenceService.setActiveContext(activeGeofenceContext());
  }

  function currentGpsSnapshot() {
    return gpsService && typeof gpsService.getSnapshot === 'function' ? gpsService.getSnapshot() : null;
  }

  function determineInitialPhaseFromSnapshot(place, snapshot) {
    if (!phaseService || !geofenceService) {
      return { phase: 'loading', source: 'safe-fallback', reason: 'phase_service_missing' };
    }
    return phaseService.determineInitialPhase(
      snapshot,
      place && place.geofence,
      geofenceService.classifyPosition
    );
  }

  function initialPhaseNeedsGps(place) {
    return Boolean(place && place.geofence && place.geofence.enabled === true);
  }

  function waitForInitialGpsSnapshot(timeoutMs = 10000) {
    if (!gpsService || typeof gpsService.subscribe !== 'function' || typeof gpsService.setConsumer !== 'function') {
      return Promise.resolve(currentGpsSnapshot());
    }
    const immediate = currentGpsSnapshot();
    if (immediate && immediate.isUsable === true) return Promise.resolve(immediate);

    gpsService.setConsumer('phaseStart', true, 'Startposition');
    return new Promise((resolve) => {
      let finished = false;
      let unsubscribe = null;
      let timer = null;
      const finish = (snapshot) => {
        if (finished) return;
        finished = true;
        if (timer !== null) window.clearTimeout(timer);
        if (unsubscribe) unsubscribe();
        if (!runtimeDisposed && !runtimeFailed) gpsService.setConsumer('phaseStart', false, 'Startposition');
        resolve(snapshot || currentGpsSnapshot());
      };
      timer = window.setTimeout(() => finish(currentGpsSnapshot()), timeoutMs);
      unsubscribe = gpsService.subscribe((snapshot) => {
        if (snapshot && snapshot.isUsable === true) finish(snapshot);
      });
      if (finished && unsubscribe) unsubscribe();
    });
  }

  async function determineInitialPhaseForPlace(place) {
    const immediate = currentGpsSnapshot();
    if (!initialPhaseNeedsGps(place) || (immediate && immediate.isUsable === true)) {
      return determineInitialPhaseFromSnapshot(place, immediate);
    }
    const snapshot = await waitForInitialGpsSnapshot();
    return determineInitialPhaseFromSnapshot(place, snapshot);
  }

  function phaseEventType(nextPhase) {
    const phase = phaseService.normalizePhase(nextPhase);
    if (phase === phaseService.PHASES.START_ROUTE) return 'start_route_started';
    if (phase === phaseService.PHASES.LOADING) return 'loading_started';
    if (phase === phaseService.PHASES.TRANSPORT) return 'transport_started';
    if (phase === phaseService.PHASES.UNLOADING) return 'unloading_started';
    if (phase === phaseService.PHASES.LOAD_REGISTERED) return 'load_registered';
    if (phase === phaseService.PHASES.RETURN_TRANSPORT) return 'return_transport_started';
    if (phase === phaseService.PHASES.RETURN_UNLOADING) return 'return_unloading_started';
    if (phase === phaseService.PHASES.READY_TO_COMPLETE) return 'ready_to_complete';
    return 'phase_changed';
  }

  function buildPhaseTransitionDocument(documentValue, nextPhase, at, reason, source, extra = {}) {
    const previousPhase = phaseService.normalizePhase(text(documentValue.phase));
    const targetPhase = phaseService.normalizePhase(nextPhase);
    let nextDocument = phaseService.transitionRecord(documentValue, targetPhase, at, reason, source, extra);
    if (previousPhase === targetPhase) return nextDocument;

    if (targetPhase === phaseService.PHASES.LOADING) {
      nextDocument = {
        ...nextDocument,
        loadingStartedAt: text(nextDocument.loadingStartedAt, at),
        loadCycles: updateCurrentLoadCycle(nextDocument, { loadingStartedAt: at })
      };
    } else if (targetPhase === phaseService.PHASES.TRANSPORT) {
      nextDocument = {
        ...nextDocument,
        transportStartedAt: at,
        loadCycles: updateCurrentLoadCycle(nextDocument, { transportStartedAt: at })
      };
    } else if (targetPhase === phaseService.PHASES.UNLOADING) {
      nextDocument = {
        ...nextDocument,
        unloadingStartedAt: at,
        loadCycles: updateCurrentLoadCycle(nextDocument, { unloadingStartedAt: at })
      };
    } else if (targetPhase === phaseService.PHASES.RETURN_TRANSPORT) {
      const returnPlaceName = text(nextDocument.returnPlaceName, text(nextDocument.from, 'Från-plats'));
      nextDocument = {
        ...nextDocument,
        returnStartedAt: at,
        returnLeg: {
          ...(isPlainObject(nextDocument.returnLeg) ? nextDocument.returnLeg : {}),
          fromPlaceId: text(nextDocument.destinationPlaceId),
          fromPlaceName: text(nextDocument.destinationPlaceName),
          destinationPlaceId: text(nextDocument.returnPlaceId, text(nextDocument.fromPlaceId)),
          destinationPlaceName: returnPlaceName,
          startedAt: at,
          status: 'returning'
        }
      };
    } else if (targetPhase === phaseService.PHASES.RETURN_UNLOADING) {
      nextDocument = {
        ...nextDocument,
        returnArrivedAt: at,
        returnLeg: {
          ...(isPlainObject(nextDocument.returnLeg) ? nextDocument.returnLeg : {}),
          arrivedAt: at,
          status: 'arrived'
        }
      };
    } else if (targetPhase === phaseService.PHASES.READY_TO_COMPLETE) {
      nextDocument = { ...nextDocument, readyToCompleteAt: at };
    }

    if (previousPhase === phaseService.PHASES.LOAD_REGISTERED && targetPhase !== phaseService.PHASES.LOAD_REGISTERED) {
      nextDocument = phaseVisualService.clearLoadRegistered(nextDocument);
    }

    return {
      ...nextDocument,
      updatedAt: at,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(nextDocument, phaseEventType(targetPhase), at, source, {
        fromPhase: previousPhase,
        toPhase: targetPhase,
        transitionReason: reason,
        ...extra
      })
    };
  }

  function renderActivePhaseTrack(documentValue) {
    const track = byId('active-phase-track');
    if (!track) return;
    const otherActivity = isOtherActivity(documentValue);
    track.hidden = otherActivity;
    track.replaceChildren();
    if (otherActivity) return;
    const currentPhase = phaseService.normalizePhase(text(documentValue.phase));
    const phases = phaseService.flow(documentValue.returnRequired === true);
    const currentIndex = phases.indexOf(currentPhase);
    phases.forEach((phase, index) => {
      const item = document.createElement('li');
      item.className = 'phase-track-item';
      if (index < currentIndex) item.classList.add('is-complete');
      if (phase === currentPhase) {
        item.classList.add('is-current');
        item.setAttribute('aria-current', 'step');
      }
      item.textContent = phaseService.label(phase);
      track.appendChild(item);
    });
  }

  function geofencePlaceForEvent(event) {
    const placeId = text(event && event.placeId);
    const role = text(event && event.placeRoleCode);
    if (!placeId) return null;
    const place = role ? resolveJobPlace(activeJobDocument, role) : findPlaceById(placeId);
    return place && text(place.id) === placeId ? place : null;
  }

  function handleGeofenceEvent(event) {
    if (runtimeDisposed || runtimeFailed) return;
    if (handlingGeofenceEvent || !activeJobLoaded || !activeJobExists() || text(activeJobDocument.status) !== 'active') return;
    const activeJobId = stableJobId(activeJobDocument, 'active');
    if (!event || text(event.jobId) !== activeJobId) return;

    const phase = phaseService.normalizePhase(text(activeJobDocument.phase));
    const direction = text(event.direction);
    const place = geofencePlaceForEvent(event);
    if (!place) return;
    const at = text(event.timestamp, new Date().toISOString());
    let targetPhase = '';
    let reason = '';

    if (phase === phaseService.PHASES.START_ROUTE
      && direction === 'ENTER'
      && text(event.placeId) === text(activeJobDocument.fromPlaceId)) {
      targetPhase = phaseService.PHASES.LOADING;
      reason = 'entered_from_geofence';
    } else if (phase === phaseService.PHASES.LOADING
      && direction === 'EXIT'
      && text(event.placeId) === text(activeJobDocument.fromPlaceId)
      && !(place.geofence && place.geofence.visualLoadingLock === true)) {
      targetPhase = phaseService.PHASES.TRANSPORT;
      reason = 'left_from_geofence_without_loading_lock';
    } else if (phase === phaseService.PHASES.TRANSPORT
      && direction === 'ENTER'
      && text(event.placeId) === text(activeJobDocument.destinationPlaceId)) {
      targetPhase = phaseService.PHASES.UNLOADING;
      reason = 'entered_destination_geofence';
    } else if (phase === phaseService.PHASES.UNLOADING
      && direction === 'EXIT'
      && text(event.placeId) === text(activeJobDocument.destinationPlaceId)
      && !(place.geofence && place.geofence.visualUnloadingLock === true)) {
      targetPhase = activeJobDocument.returnRequired === true
        ? phaseService.PHASES.RETURN_TRANSPORT
        : phaseService.PHASES.READY_TO_COMPLETE;
      reason = 'left_destination_geofence_without_unloading_lock';
    } else if (phase === phaseService.PHASES.RETURN_TRANSPORT
      && direction === 'ENTER'
      && text(event.placeId) === text(activeJobDocument.returnPlaceId, text(activeJobDocument.fromPlaceId))) {
      targetPhase = phaseService.PHASES.RETURN_UNLOADING;
      reason = 'entered_return_geofence';
    } else if (phase === phaseService.PHASES.RETURN_UNLOADING
      && direction === 'EXIT'
      && text(event.placeId) === text(activeJobDocument.returnPlaceId, text(activeJobDocument.fromPlaceId))
      && !(place.geofence && place.geofence.visualUnloadingLock === true)) {
      targetPhase = phaseService.PHASES.READY_TO_COMPLETE;
      reason = 'left_return_geofence_without_unloading_lock';
    }

    if (!targetPhase) return;
    handlingGeofenceEvent = true;
    try {
      const nextDocument = buildPhaseTransitionDocument(activeJobDocument, targetPhase, at, reason, 'gps-geofence', {
        placeId: text(event.placeId),
        direction
      });
      persistActiveJob(nextDocument, '', { silent: true });
      watchdog.step('runtime.phase.geofence-transition', `${phaseService.label(phase)} → ${phaseService.label(targetPhase)}.`);
    } finally {
      handlingGeofenceEvent = false;
    }
  }

  function handleVisibilityChange() {
    if (runtimeDisposed || runtimeFailed) return;
    if (gpsService && gpsRuntimeReady) gpsService.setForeground(document.visibilityState !== 'hidden');
    if (document.visibilityState !== 'hidden') {
      if (gpsService && gpsRuntimeReady) {
        syncGpsDiagnosticsConsumer();
        syncActiveJobGpsConsumer();
        syncActiveGeofenceContext();
      }
      if (activeJobLoaded && activeJobExists()) renderActiveJob();
      if (syncV63OperationallyEnabled()) syncV63SyncNow();
    }
  }

  function toggleSettingsGroup(groupId) {
    const requested = text(groupId);
    if (!requested) return;
    if (activeSettingsGroup === requested) {
      activeSettingsGroup = '';
      activeSettingsFunction = '';
      renderSettingsWorkspace(false);
      syncGpsDiagnosticsConsumer();
      return;
    }
    activeSettingsGroup = requested;
    activeSettingsFunction = '';
    renderSettingsWorkspace(true);
    syncGpsDiagnosticsConsumer();
  }

  function prepareSettingsFunction(functionId) {
    if (functionId === 'quick-choices') {
      renderQuickChoiceRegistry();
      return true;
    }
    if (functionId === 'history' || functionId === 'trash' || functionId === 'statistics') {
      return loadHistoryIfNeeded(functionId);
    }
    if (functionId === 'sync') {
      const loaded = loadSyncOutboxIfNeeded();
      renderSyncRoleView();
      return loaded;
    }
    return true;
  }

  function openSyncStatus() {
    showView('settings');
    activeSettingsGroup = 'import-extra';
    activeSettingsFunction = 'sync';
    prepareSettingsFunction('sync');
    renderSettingsWorkspace(true);
    syncDiagnosticObserve('sync-status-opened', { role: text(hostInfo && hostInfo.role) });
  }

  function backupStoreJson(name, fallback) {
    try { const raw = window.StadslassHost.readStore(name); return raw ? JSON.parse(raw) : fallback; } catch (_) { return fallback; }
  }
  function backupState() {
    return { packageVersion: PACKAGE_VERSION, settings: settingsDocument, jobTypes: editableJobTypeRegistry ? editableJobTypeRegistry.items : [], places: editablePlaceRegistry ? editablePlaceRegistry.items : [], beaches: editableBeachRegistry ? editableBeachRegistry.items : [], quickChoices: quickChoiceRegistry ? quickChoiceRegistry.items : [], ataContacts: ataNotificationSettings().contacts || [], machines: settingsDocument.machines || [], queue: backupStoreJson(QUEUE_STORE, []), activeJob: backupStoreJson(ACTIVE_JOB_STORE, {}), history: backupStoreJson(HISTORY_STORE, []), syncOutbox: backupStoreJson(SYNC_OUTBOX_STORE, []) };
  }
  function backupExport() {
    try {
      const backup = backupApi.createBackup(backupState()); const content = JSON.stringify(backup, null, 2); const requestId = `backup-${Date.now().toString(36)}`;
      const response = JSON.parse(window.StadslassHost.requestTextFileExport(JSON.stringify({schemaVersion:1,requestId,fileName:`stadslass-3.0-backup-${new Date().toISOString().slice(0,10)}.json`,mimeType:'text/plain',contentUtf8:content})));
      showStatus('backup-status', response && response.ok ? 'Välj var backupfilen ska sparas.' : 'Backupfilen kunde inte öppnas för sparning.', !response || !response.ok);
    } catch (error) { showStatus('backup-status', error.message || 'Backup kunde inte skapas.', true); }
  }
  function renderBackupPreview(preview) {
    byId('backup-preview').hidden = false;
    byId('backup-preview-summary').textContent = `${preview.kind}-backup analyserad. ${Object.values(preview.counts).reduce((sum,value)=>sum+value.add,0)} poster importeras, ${Object.values(preview.counts).reduce((sum,value)=>sum+value.same,0)} exakta dubbletter hoppas över och ${preview.conflicts.length} poster kräver ett importval.`;
    const inventory=byId('backup-inventory'); inventory.replaceChildren();
    const statusLabel={import:'Importeras',skip:'Hoppas över – exakt dubblett',conflict:'Kräver importval',empty:'Ingen post'};
    preview.details.forEach((section)=>{ const card=document.createElement('article'); card.className='queue-card'; const title=document.createElement('strong'); title.textContent=`${section.label} (${section.entries.length})`; const entries=document.createElement('ul'); entries.className='compact-list'; if(section.entries.length) section.entries.forEach((entry)=>{const row=document.createElement('li'); row.textContent=`${entry.name}: ${statusLabel[entry.status]||entry.status}`; entries.appendChild(row);}); else { const row=document.createElement('li'); row.textContent='Inga poster i backupen.'; entries.appendChild(row); } card.append(title,entries); inventory.appendChild(card); });
    const manualItems=byId('backup-manual-items'); const manualHeading=byId('backup-manual-heading'); manualItems.replaceChildren(); const notes=Array.isArray(preview.importNotes)?preview.importNotes:[]; manualHeading.hidden=!notes.length;
    notes.forEach((note)=>{const card=document.createElement('article'); card.className='queue-card'; card.textContent=note; manualItems.appendChild(card);});
    const list = byId('backup-conflicts'); list.replaceChildren();
    preview.conflicts.forEach((conflict) => { const card=document.createElement('article'); card.className='queue-card'; const title=document.createElement('strong'); title.textContent=`${conflict.label}: ${conflict.name}`; const select=document.createElement('select'); select.dataset.backupConflict=`${conflict.key}:${conflict.id}`; (conflict.key==='activeJob'?['keep','replace']:['keep','replace','new']).forEach((value)=>{const option=document.createElement('option');option.value=value;option.textContent=value==='keep'?'Behåll befintlig':value==='replace'?'Ersätt befintlig':'Importera som ny'; if(value==='keep')option.selected=true;select.appendChild(option);}); card.append(title,select); list.appendChild(card); });
    if (!preview.conflicts.length) list.textContent='Inga konfliktval behövs.';
  }
  function backupPickImport() {
    try { const requestId=`backup-import-${Date.now().toString(36)}`; window.StadslassHost.requestTextFileImport(JSON.stringify({schemaVersion:1,requestId})); showStatus('backup-status','Välj en backupfil. Inget har ändrats.'); } catch (error) { showStatus('backup-status','Filväljaren kunde inte öppnas.',true); }
  }
  function backupNameKey(value) { return text(value).replace(/\s+/g,' ').toLocaleLowerCase('sv-SE'); }
  function backupLegacyArray(value) { if (Array.isArray(value)) return value; if (value && Array.isArray(value.items)) return value.items; if (value && Array.isArray(value.history)) return value.history; if (value && Array.isArray(value.jobs)) return value.jobs; return []; }
  function backupLegacyGeofence(value) {
    if (!value || typeof value !== 'object') return { enabled:false,type:'circle',visualLoadingLock:false,visualUnloadingLock:false,latitude:null,longitude:null,radiusMeters:null,toleranceMeters:null,polygonPoints:[] };
    const polygon=value.type==='polygon'; const center=value.center||{};
    return { enabled:true,type:polygon?'polygon':'circle',visualLoadingLock:false,visualUnloadingLock:value.unloadingLock===true||value.unloadingLockUntilWeight===true,latitude:polygon?null:Number(center.lat),longitude:polygon?null:Number(center.lon),radiusMeters:polygon?null:Number(value.radiusMeters),toleranceMeters:Number.isFinite(Number(value.toleranceMeters))?Number(value.toleranceMeters):0,polygonPoints:polygon?(value.points||[]).map((point)=>({latitude:Number(point.lat??point.latitude),longitude:Number(point.lon??point.longitude)})):[] };
  }
  function backupLegacyToCurrent(parsed) {
    const legacy=parsed.value.legacyParts||{}; const placesPart=legacy.places||{}; const geofencePart=legacy.geofences||{}; const jobPart=legacy.jobTypes||{}; const quickPart=legacy.quickItems||{}; const machinePart=legacy.machines||{}; const timestamp=new Date().toISOString(); const notes=[];
    let jobItems=editableJobTypeRegistry.items.slice(); const byJobName=()=>new Map(jobItems.map((item)=>[backupNameKey(item.name),item])); const meta=jobPart.jobTypeMeta||{};
    (jobPart.jobTypes||[]).forEach((name)=>{ const key=backupNameKey(name); if (!key||byJobName().has(key)) return; const legacyMeta=meta[name]||{}; const role=/havstång/i.test(name)?'havstang':(/maskintransport/i.test(name)?'machine-transport':'none'); let created;
      try { created=editableJobTypeApi.createItem({name,specialRole:role},jobItems,timestamp); } catch (_) { created=editableJobTypeApi.createItem({name,specialRole:'none'},jobItems,timestamp); notes.push(`Jobbtypen ${name} importerades utan skyddad specialroll eftersom den redan används.`); }
      jobItems.push({...created,ataEnabled:legacyMeta.ataJob===true||/\(ÄTA\)/i.test(name),materialCode:text(legacyMeta.materialCode),supportsReturn:legacyMeta.returnRequired===true,supportsMultiLoad:legacyMeta.multiLoad===true});
    });
    const jobByName=byJobName(); const mapJobIds=(names)=>Array.from(new Set((Array.isArray(names)?names:[]).map((name)=>jobByName.get(backupNameKey(name))).filter(Boolean).map((item)=>item.id)));
    let placeItems=editablePlaceRegistry.items.slice(); let beachItems=editableBeachRegistry.items.slice(); const labels=placesPart.placeLabels||{}; const addresses=placesPart.placeAddresses||{}; const configs=placesPart.placeConfigs||{}; const coordinates=placesPart.placeCoordinates||{}; const custom=Array.isArray(placesPart.customPlaces)?placesPart.customPlaces:[];
    const customByKey=new Map(custom.map((item)=>[text(item.key),item])); const keys=Array.from(new Set(Object.keys(addresses).concat(custom.map((item)=>text(item.key))).filter(Boolean)));
    const placeByName=()=>new Map(placeItems.map((item)=>[backupNameKey(item.name),item])); const beachByName=()=>new Map(beachItems.filter((item)=>!item.hidden).map((item)=>[backupNameKey(item.name),item]));
    keys.forEach((key)=>{ const customItem=customByKey.get(key)||{}; const name=text(labels[key])||text(customItem.label)||key; const config=configs[key]||configs[name]||{}; const coordinate=coordinates[key]||coordinates[name]||{}; const legacyFence=(geofencePart.placeGeofences||{})[key]||(geofencePart.placeGeofences||{})[name]||(geofencePart.disabledPlaceGeofences||{})[key]||(geofencePart.disabledPlaceGeofences||{})[name]; const geofence=backupLegacyGeofence(legacyFence); const input={name,addressOrPlusCode:text(addresses[key])||text(addresses[name]),placeRequirements:text((placesPart.placeRequirements||{})[key]??(placesPart.placeRequirements||{})[name]),openingHours:text((placesPart.placeOpeningHours||{})[key]??(placesPart.placeOpeningHours||{})[name]),canBeReturnPlace:(placesPart.placeReturnEligibility||{})[key]===true||(placesPart.placeReturnEligibility||{})[name]===true,jobTypeFromIds:mapJobIds(config.fromJobTypes),jobTypeToIds:mapJobIds(config.toJobTypes),geofence,latitude:Number(coordinate.lat),longitude:Number(coordinate.lon)};
      if (customItem.category==='badplats'||key.startsWith('beach_')) { const current=beachByName().get(backupNameKey(name)); if (current) beachItems=beachItems.map((item)=>item.id===current.id?editableBeachApi.updateItem(current,input,beachItems,timestamp):item); else beachItems.push(editableBeachApi.createItem(input,beachItems,timestamp)); }
      else { const current=placeByName().get(backupNameKey(name)); if (current) placeItems=placeItems.map((item)=>item.id===current.id?editablePlaceApi.updateItem(current,input,placeItems,new Set(jobItems.map((item)=>item.id)),timestamp):item); else placeItems.push(editablePlaceApi.createItem(input,placeItems,new Set(jobItems.map((item)=>item.id)),timestamp)); }
    });
    const placeIdByName=new Map(placeItems.concat(beachItems.filter((item)=>!item.hidden)).map((item)=>[backupNameKey(item.name),item.id])); let quickItems=quickChoiceRegistry.items.slice();
    (quickPart.quickItems||[]).forEach((legacyQuick)=>{ const job=jobByName.get(backupNameKey(legacyQuick.type))||jobItems.find((item)=>item.id===text(legacyQuick.jobTypeId)); const from=placeIdByName.get(backupNameKey(legacyQuick.place||legacyQuick.group)); const to=placeIdByName.get(backupNameKey(legacyQuick.dest)); if (!job||!from) { notes.push(`Snabbvalet ${text(legacyQuick.label)||text(legacyQuick.id)} hoppades över eftersom jobbtyp eller Från-plats saknas.`); return; } const rawItem={quickChoiceId:text(legacyQuick.id),buttonName:text(legacyQuick.label)||job.name,jobTypeId:job.id,jobTypeName:job.name,fromPlaceId:from,toPlaceId:to||'',returnRequired:false,multiLoad:false,comment:text(legacyQuick.comment),ataManual:false}; const same=quickItems.some((item)=>item.quickChoiceId===rawItem.quickChoiceId); if (!same) quickItems.push(quickChoiceApi.createItem(rawItem,quickItems,timestamp)); });
    const machineItems=Array.isArray(machinePart.machines)?machinePart.machines:backupLegacyArray(machinePart); const history=backupLegacyArray(legacy.history); const contacts=backupLegacyArray(legacy.ataContacts); if (!history.length && legacy.history && typeof legacy.history==='object') notes.push('Historikdelen saknar ett känt listformat och ändrades inte.');
    return {schemaVersion:1,format:'stadslass-backup',source:{app:'Stadslass 2.0',exportedAt:parsed.value.source.exportedAt},data:{settings:{},jobTypes:jobItems,places:placeItems,beaches:beachItems,quickChoices:quickItems,ataContacts:contacts,machines:machineItems,queue:[],activeJob:{},history,syncOutbox:[]},importNotes:notes};
  }
  function backupPrepareImport(raw) { try { const parsed=backupApi.parse(raw); const normalized=parsed.legacy?backupLegacyToCurrent(parsed):parsed.value; pendingBackupPreview=backupApi.preview(normalized,backupState()); pendingBackupPreview.importNotes=normalized.importNotes||[]; renderBackupPreview(pendingBackupPreview); showStatus('backup-status','Importen är kontrollerad. Läs innehåll, importval och eventuella manuella kompletteringar innan du bekräftar.'); } catch(error) { pendingBackupPreview=null; showStatus('backup-status',error.message||'Backupfilen kunde inte läsas.',true); } }
  function backupConfirmImport() {
    if (!pendingBackupPreview) return; const incoming=pendingBackupPreview.backup.data; const actions={}; document.querySelectorAll('select[data-backup-conflict]').forEach((select)=>{actions[select.dataset.backupConflict]=select.value;});
    try {
      const timestamp=new Date().toISOString();
      const nextJobTypes=editableJobTypeApi.withItems(editableJobTypeRegistry, backupApi.mergeList(editableJobTypeRegistry.items,incoming.jobTypes,'jobTypes',actions),timestamp);
      const nextJobTypeIds=new Set(nextJobTypes.items.map((item)=>item.id));
      const nextPlaces=editablePlaceApi.withItems(editablePlaceRegistry, backupApi.mergeList(editablePlaceRegistry.items,incoming.places,'places',actions),nextJobTypeIds,timestamp);
      const nextBeaches=editableBeachApi.withItems(editableBeachRegistry, backupApi.mergeList(editableBeachRegistry.items,incoming.beaches,'beaches',actions),timestamp);
      const nextQuick=quickChoiceApi.withItems(quickChoiceRegistry, backupApi.mergeList(quickChoiceRegistry.items,incoming.quickChoices,'quickChoices',actions),timestamp);
      let nextSettings={...settingsDocument,[editableJobTypeApi.SETTINGS_KEY]:nextJobTypes,[editablePlaceApi.SETTINGS_KEY]:nextPlaces,[editableBeachApi.SETTINGS_KEY]:nextBeaches,[quickChoiceApi.SETTINGS_KEY]:nextQuick,machines:backupApi.mergeList(settingsDocument.machines||[],incoming.machines,'machines',actions),settingsUpdatedByPackageVersion:PACKAGE_VERSION};
      const contacts=backupApi.mergeList(ataNotificationSettings().contacts||[],incoming.ataContacts,'ataContacts',actions); nextSettings=ataNotificationApi.documentWithSettings(nextSettings,{...ataNotificationSettings(),contacts});
      if (!window.StadslassHost.writeStore(SETTINGS_STORE,JSON.stringify(nextSettings))) throw new Error(window.StadslassHost.getLastError()||'Inställningslagret kunde inte sparas.');
      const activeCurrent=backupStoreJson(ACTIVE_JOB_STORE,{}); const activeId=text(incoming.activeJob && (incoming.activeJob.id||incoming.activeJob.jobId),'active-job-0'); const activeAction=text(actions[`activeJob:${activeId}`],'keep');
      const activeNext=!incoming.activeJob||Object.keys(incoming.activeJob).length===0?activeCurrent:(!activeCurrent||Object.keys(activeCurrent).length===0||JSON.stringify(activeCurrent)===JSON.stringify(incoming.activeJob)||activeAction==='replace'?incoming.activeJob:activeCurrent);
      const storeValues={queue:backupApi.mergeList(backupStoreJson(QUEUE_STORE,[]),incoming.queue,'queue',actions),activeJob:activeNext,history:backupApi.mergeList(backupStoreJson(HISTORY_STORE,[]),incoming.history,'history',actions),syncOutbox:backupApi.mergeList(backupStoreJson(SYNC_OUTBOX_STORE,[]),incoming.syncOutbox,'syncOutbox',actions)};
      [['queue',QUEUE_STORE],['activeJob',ACTIVE_JOB_STORE],['history',HISTORY_STORE],['syncOutbox',SYNC_OUTBOX_STORE]].forEach(([key,store])=>{ if(typeof storeValues[key]!=='undefined'&&!window.StadslassHost.writeStore(store,JSON.stringify(storeValues[key]))) throw new Error(`${store} kunde inte sparas.`); });
      settingsDocument=nextSettings; editableJobTypeRegistry=nextJobTypes; editablePlaceRegistry=nextPlaces; editableBeachRegistry=nextBeaches; quickChoiceRegistry=nextQuick; applyEffectiveJobTypeRegistry(nextJobTypes.items); buildEffectivePlaceRegistry(); pendingBackupPreview=null; byId('backup-preview').hidden=true; showStatus('backup-status','Importen är klar. ÄTA-kontakter är importerade fristående och har inte kopplats automatiskt.');
    } catch(error) { showStatus('backup-status',error.message||'Importen kunde inte sparas.',true); }
  }

  function toggleSettingsFunction(groupId, functionId) {
    const requestedGroup = text(groupId);
    const requestedFunction = text(functionId);
    if (!requestedGroup || !requestedFunction || activeSettingsGroup !== requestedGroup) return;
    if ((requestedFunction === 'history' || requestedFunction === 'trash' || requestedFunction === 'statistics') && !canUseActiveJob()) {
      return;
    }
    const opening = activeSettingsFunction !== requestedFunction;
    activeSettingsFunction = opening ? requestedFunction : '';
    if (opening) prepareSettingsFunction(requestedFunction);
    renderSettingsWorkspace(opening);
    syncGpsDiagnosticsConsumer();
  }

  function showStatus(elementId, message, isError = false) {
    const element = byId(elementId);
    if (!element || runtimeDisposed) return false;
    element.textContent = message;
    element.classList.toggle('is-error', isError);
    if (element.dataset.hideWhenEmpty === 'true') element.hidden = !text(message);
    return true;
  }

  function ataMailSettings() {
    return ataNotificationApi ? ataNotificationApi.settingsFromDocument(settingsDocument) : { supervisor: null, template: { fields: {}, closingText: '' } };
  }

  function ataMailWatchdog(step, detail) {
    if (watchdog && typeof watchdog.step === 'function') watchdog.step(step, detail, 'warning');
  }

  function updateAtaMailStatus(id, action, hostResult = '') {
    const index = historyItemIndexById(id);
    if (index < 0 || !ataMailApi || !ataMailApi.isEligible(historyDocument[index])) return false;
    const nextDocument = historyDocument.map((job, itemIndex) => itemIndex === index
      ? ataMailApi.withStatus(job, action, hostResult) : job);
    return persistHistory(nextDocument, '', currentView === 'today' ? 'today-load-status' : 'history-load-status');
  }

  function hostEmailDraft(recipient, subject, body) {
    if (!mailService) throw new Error('Den gemensamma mailtjänsten saknas.');
    return mailService.open({ mailType: 'ata', recipient, subject, body, attachment: null }, hostInfo);
  }

  function hostCopyText(label, value) {
    if (!bridgeAvailable() || typeof window.StadslassHost.copyText !== 'function') throw new Error('Kopiering stöds inte av den här installationen.');
    if (window.StadslassHost.copyText(label, value) !== true) throw new Error('Underlaget kunde inte kopieras.');
    return true;
  }

  function closeAtaMailDialog() {
    const dialog = byId('ata-mail-dialog');
    if (dialog) { dialog.hidden = true; dialog.setAttribute('aria-hidden', 'true'); }
    document.body.classList.remove('ata-mail-dialog-open');
    ataMailDialogContext = null;
    ataMailActionInProgress = false;
  }

  function finishAtaMailDialog() {
    const context = ataMailDialogContext;
    if (!context || ataMailActionInProgress) return;
    const returnToToday = context.mode === 'completion';
    closeAtaMailDialog();
    if (returnToToday) activateView('today');
  }

  function renderAtaMailDialogActions() {
    const context = ataMailDialogContext;
    if (!context) return;
    const historical = context.mode === 'history';
    const daily = context.mode === 'daily';
    const opened = context.draftOpened === true;
    const openButton = byId('ata-mail-open');
    const skipButton = byId('ata-mail-skip');
    openButton.hidden = historical;
    openButton.textContent = opened ? 'Klar – fortsätt i Stadslass' : 'Öppna mailutkast';
    openButton.disabled = !opened && daily && !context.underlag.recipient.valid;
    skipButton.hidden = historical || daily || opened;
    byId('ata-mail-copy').textContent = daily ? 'Kopiera dagsunderlag' : 'Kopiera underlag';
  }

  function openAtaMailDialog(context) {
    if (!context || !context.underlag) return;
    const dialog = byId('ata-mail-dialog');
    if (!dialog) return;
    ataMailDialogContext = { ...context, draftOpened: false };
    ataMailActionInProgress = false;
    const historical = context.mode === 'history';
    const daily = context.mode === 'daily';
    byId('ata-mail-heading').textContent = daily ? 'ÄTA-dagsmail' : 'ÄTA-underlag';
    byId('ata-mail-description').textContent = historical
      ? 'Färdigt underlag för historiskt ÄTA-uppdrag. Mailutkast öppnas inte här.'
      : (daily ? 'Samlat dagsunderlag till arbetsledaren.' : 'Färdigt ÄTA-underlag. Stadslass öppnar bara ett mailutkast – kontrollera och skicka själv.');
    byId('ata-mail-recipient').textContent = `Till: ${ataMailApi.recipientText(context.underlag.recipient)}`;
    byId('ata-mail-subject').textContent = `Ämne: ${context.underlag.subject}`;
    byId('ata-mail-preview').textContent = context.underlag.body;
    renderAtaMailDialogActions();
    showStatus('ata-mail-status', daily && !context.underlag.recipient.valid ? 'Arbetsledare saknas eller har ogiltig mailadress. Du kan fortfarande kopiera dagsunderlaget.' : '');
    dialog.hidden = false; dialog.setAttribute('aria-hidden', 'false'); document.body.classList.add('ata-mail-dialog-open');
    window.setTimeout(() => byId('ata-mail-close').focus({ preventScroll: true }), 0);
  }

  function openIndividualUnderlag(id, mode = 'today') {
    const index = historyItemIndexById(id); if (index < 0 || !ataMailApi || !ataMailApi.isEligible(historyDocument[index])) return;
    openAtaMailDialog({ mode, jobId: historyDocument[index].id, underlag: ataMailApi.individual(historyDocument[index], ataMailSettings().template) });
  }

  function openDailyUnderlag(day) {
    if (!ataMailApi) return;
    const underlag = ataMailApi.daily(activeHistoryEntries().map(({ item }) => item), day, ataMailSettings().supervisor);
    if (!underlag.jobs.length) return;
    openAtaMailDialog({ mode: 'daily', day, underlag });
  }

  function handleAtaMailOpen() {
    const context = ataMailDialogContext; if (!context || context.mode === 'history' || ataMailActionInProgress) return;
    if (context.draftOpened === true) { finishAtaMailDialog(); return; }
    if (context.mode === 'daily' && !context.underlag.recipient.valid) { showStatus('ata-mail-status', 'Spara en giltig arbetsledare i ÄTA avisering innan dagsmailet öppnas.', true); return; }
    ataMailActionInProgress = true;
    try {
      // V419 copies the prepared body as a reserve before the mail client opens. A successful
      // draft still records only the action that Stadslass actually knows: draft opened.
      try { hostCopyText('ÄTA-underlag', context.underlag.body); } catch (copyError) { ataMailWatchdog('runtime.ata.mail.reserve-copy-failed', 'Reservkopiering inför mailutkast misslyckades.'); }
      hostEmailDraft(context.underlag.recipient.valid ? context.underlag.recipient.email : '', context.underlag.subject, context.underlag.body);
      context.draftOpened = true;
      renderAtaMailDialogActions();
      if (context.mode !== 'daily' && !updateAtaMailStatus(context.jobId, ataMailApi.ACTIONS.OPENED, 'opened')) throw new Error('Mailutkastet öppnades men statusen kunde inte sparas.');
      showStatus('ata-mail-status', 'Mailutkast öppnat. Stadslass kan inte se om mailet skickas.');
    } catch (error) { ataMailWatchdog('runtime.ata.mail.open-failed', 'Mailutkast kunde inte öppnas.'); showStatus('ata-mail-status', error.message || 'Mailutkast kunde inte öppnas.', true); }
    finally { ataMailActionInProgress = false; }
  }

  function handleAtaMailCopy() {
    const context = ataMailDialogContext; if (!context || ataMailActionInProgress) return;
    ataMailActionInProgress = true;
    try {
      hostCopyText(context.mode === 'daily' ? 'ÄTA-dagsunderlag' : 'ÄTA-underlag', context.underlag.body);
      // Kopiering är en reservåtgärd och får inte ändra uppdragets mailstatus eller tidsstämplar.
      showStatus('ata-mail-status', 'Underlaget är kopierat.');
    } catch (error) { ataMailWatchdog('runtime.ata.mail.copy-failed', 'Underlaget kunde inte kopieras.'); showStatus('ata-mail-status', error.message || 'Underlaget kunde inte kopieras.', true); }
    finally { ataMailActionInProgress = false; }
  }

  function handleAtaMailSkip() {
    const context = ataMailDialogContext; if (!context || context.draftOpened === true || context.mode !== 'today' && context.mode !== 'completion' || ataMailActionInProgress) return;
    ataMailActionInProgress = true;
    if (updateAtaMailStatus(context.jobId, ataMailApi.ACTIONS.SKIPPED, 'skipped')) closeAtaMailDialog();
    else showStatus('ata-mail-status', 'Valet kunde inte sparas.', true);
    ataMailActionInProgress = false;
  }

  function currentScrollY() {
    return Math.max(0, Number(window.scrollY) || Number(document.documentElement.scrollTop) || 0);
  }

  function preserveScrollAfterRender(previousScrollY) {
    const safeScrollY = Math.max(0, Number(previousScrollY) || 0);
    window.requestAnimationFrame(() => {
      window.scrollTo(0, safeScrollY);
      window.requestAnimationFrame(() => window.scrollTo(0, safeScrollY));
    });
  }

  function revealInlineControl(selector, previousScrollY) {
    const safeScrollY = Math.max(0, Number(previousScrollY) || 0);
    window.requestAnimationFrame(() => {
      window.scrollTo(0, safeScrollY);
      window.requestAnimationFrame(() => {
        const element = document.querySelector(selector);
        if (!element || element.hidden) return;
        const nav = document.querySelector('.bottom-nav');
        const navRect = nav ? nav.getBoundingClientRect() : { height: 0 };
        const visibleBottom = Math.max(0, window.innerHeight - Math.max(0, Number(navRect.height) || 0) - 12);
        const rect = element.getBoundingClientRect();
        const currentY = currentScrollY();
        const requiredDown = Math.max(0, rect.bottom - visibleBottom);
        window.scrollTo(0, Math.max(safeScrollY, currentY + requiredDown));
      });
    });
  }

  function isPressFeedbackExcluded(element) {
    return Boolean(element && element.closest([
      '#view-quick-choices',
      '#quick-choice-registry-card',
      '[data-target="quickChoices"]',
      '[data-settings-function="quick-choices"]'
    ].join(',')));
  }

  function clearPressFeedback(element) {
    if (!element) return;
    element.classList.remove('is-press-feedback');
    element.removeAttribute('aria-busy');
  }

  function cancelPendingPressActions() {
    pendingPressActions.forEach((timer, element) => {
      window.clearTimeout(timer);
      clearPressFeedback(element);
    });
    pendingPressActions.clear();
  }

  function pressTarget(event) {
    const target = event.target && event.target.closest
      ? event.target.closest('button, a[href], [role="button"], input[type="button"], input[type="submit"], input[type="reset"]')
      : null;
    if (!target || isPressFeedbackExcluded(target)) return null;
    if (target.disabled || target.getAttribute('aria-disabled') === 'true') return null;
    return target;
  }

  function installPressFeedback() {
    document.addEventListener('pointerdown', (event) => {
      if (runtimeDisposed || runtimeFailed || event.button !== 0) return;
      const element = pressTarget(event);
      if (element) element.classList.add('is-press-feedback');
    }, true);
    document.addEventListener('pointercancel', (event) => {
      if (runtimeDisposed || runtimeFailed) return;
      const element = pressTarget(event);
      if (element && !pendingPressActions.has(element)) clearPressFeedback(element);
    }, true);
    document.addEventListener('pointerout', (event) => {
      if (runtimeDisposed || runtimeFailed) return;
      const element = pressTarget(event);
      if (!element || pendingPressActions.has(element)) return;
      if (event.relatedTarget && element.contains(event.relatedTarget)) return;
      clearPressFeedback(element);
    }, true);
    document.addEventListener('click', (event) => {
      if (runtimeDisposed || runtimeFailed) return;
      const element = pressTarget(event);
      if (!element) return;
      if (element.dataset.pressFeedbackReplay === '1') {
        delete element.dataset.pressFeedbackReplay;
        return;
      }
      if (pendingPressActions.has(element)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      event.preventDefault();
      event.stopImmediatePropagation();
      element.classList.add('is-press-feedback');
      element.setAttribute('aria-busy', 'true');
      const timer = window.setTimeout(() => {
        pendingPressActions.delete(element);
        if (!element.isConnected || element.disabled || element.getAttribute('aria-disabled') === 'true') {
          clearPressFeedback(element);
          return;
        }
        clearPressFeedback(element);
        element.dataset.pressFeedbackReplay = '1';
        element.click();
      }, PRESS_DELAY_MS);
      pendingPressActions.set(element, timer);
    }, true);
  }

  function showView(target) {
    if (!Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) {
      return;
    }
    cancelPendingPressActions();
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.hidden = view.dataset.view !== target;
    });
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      const active = button.dataset.target === target;
      button.classList.toggle('is-active', active);
      if (active) {
        button.setAttribute('aria-current', 'page');
      } else {
        button.removeAttribute('aria-current');
      }
    });
    byId('page-title').textContent = PAGE_TITLES[target];
    currentView = target;
    syncActivePhaseBackdropVisibility();
    syncGpsDiagnosticsConsumer();
    byId('main-content').focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function isMobileRole() {
    return hostInfo && hostInfo.role === 'mobile';
  }

  function isVehicleRole() {
    return hostInfo && hostInfo.role === 'vehicle_189';
  }

  function canUseQueue() {
    return isMobileRole() || isVehicleRole();
  }

  function canUseActiveJob() {
    return isVehicleRole();
  }

  function syncQueueFormVisibility() {
    const formCard = byId('queue-form').closest('.section-card');
    if (!formCard) return;
    formCard.hidden = isVehicleRole() && !editingQueueId;
  }

  function renderQueueRoleCopy() {
    if (isMobileRole()) {
      byId('queue-heading').textContent = 'Mobilens planeringskö';
      byId('queue-summary-text').textContent = 'Här visas uppdragen du har planerat på mobilen.';
      byId('queue-form-heading').textContent = 'Lägg till planerat uppdrag';
      byId('queue-form-intro').textContent = 'Lägg till ett uppdrag och överför det till 189 när det är klart.';
      byId('queue-submit-button').textContent = 'Lägg i planeringskö';
      byId('queue-list-heading').textContent = 'Planerad kö';
    } else if (isVehicleRole()) {
      byId('queue-heading').textContent = '189:s operativa kö';
      byId('queue-summary-text').textContent = 'Här visas uppdragen som finns på 189.';
      byId('queue-list-heading').textContent = 'Operativ kö';
    }
    syncQueueFormVisibility();
  }

  function applyRoleBoundaries() {
    const queueAllowed = canUseQueue();
    const activeAllowed = canUseActiveJob();
    byId('open-queue').hidden = !queueAllowed;
    byId('open-active-job').hidden = !activeAllowed;
    byId('open-today').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="queue"]').hidden = !queueAllowed;
    document.querySelector('.nav-button[data-target="quickChoices"]').hidden = !queueAllowed;
    document.querySelector('.nav-button[data-target="active"]').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="today"]').hidden = !activeAllowed;
    document.querySelectorAll('.settings-function-button[data-requires-vehicle="true"]').forEach((button) => {
      button.hidden = !activeAllowed;
    });
    renderSettingsWorkspace(false);
    renderQueueRoleCopy();
    byId('quick-choice-mode-direct').disabled = !activeAllowed;
    if (!activeAllowed) byId('quick-choice-mode-queue').checked = true;
    byId('quick-choice-role-note').textContent = activeAllowed
      ? 'Lägg i kö är förvalt. Starta direkt är tillgängligt när inget annat vanligt uppdrag är aktivt; Övrig verksamhet följer sin befintliga parallella modell.'
      : 'På Mobil skapar Snabbval vanliga uppdrag i planeringskön. Starta direkt är endast tillgängligt på 189 / Surfplatta.';
    document.documentElement.classList.toggle('vehicle-role', isVehicleRole());
    updateBottomNavReservedSpace();

    if (isMobileRole()) {
      byId('role-boundary-note').textContent = 'Här visas mobilens planeringsfunktioner.';
      byId('active-role-note').textContent = 'Aktivt jobb används på 189.';
    } else if (isVehicleRole()) {
      byId('role-boundary-note').textContent = 'Här visas uppdragen som finns på 189. Planerade uppdrag från mobilen visas först efter överföring.';
      byId('active-role-note').textContent = '';
      byId('active-role-note').hidden = true;
    }
    const diagnostic = syncDiagnosticEnsure();
    if (diagnostic) diagnostic.firstRoleView(syncDiagnosticContext());
    performanceObserve('role-view-ready', { role: text(hostInfo && hostInfo.role), usable: true });
    // v86: rollvyn får aldrig starta en vanlig Driftsync vid appöppning.
  }

  function activateView(target) {
    if (currentView === 'quickChoices' && target !== 'quickChoices') {
      clearQuickChoiceFallbackState({ clearStatus: true });
    }
    if ((target === 'queue' || target === 'quickChoices') && !canUseQueue()) {
      showView('home');
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if ((target === 'active' || target === 'today' || target === 'history' || target === 'trash' || target === 'statistics') && !canUseActiveJob()) {
      showView('home');
      showStatus('role-boundary-note', 'Driftvyn är blockerad på denna enhetsroll.', true);
      return;
    }
    showView(target);
    if (target === 'queue') {
      loadQueueIfNeeded();
    } else if (target === 'quickChoices') {
      byId('quick-choice-mode-queue').checked = true;
      byId('quick-choice-mode-direct').checked = false;
      clearQuickChoiceFallbackState({ clearStatus: true });
      const activeReadable = refreshActiveJobForQuickChoice({ showError: false });
      renderQuickChoices();
      if (!activeReadable && isVehicleRole()) {
        showStatus('quick-choice-status', 'Aktivt jobb kunde inte kontrolleras. Lägg i kö kan användas säkert.', true);
      }
    } else if (target === 'active') {
      loadActiveJobIfNeeded();
    } else if (target === 'today' || target === 'history' || target === 'trash' || target === 'statistics') {
      loadHistoryIfNeeded(target);
    } else if (target === 'sync') {
      loadSyncOutboxIfNeeded();
      syncV86ReconcileTerminalRequests();
      renderSyncRoleView();
    }
  }

  function renderHostInfo() {
    const role = hostInfo.roleLabel || hostInfo.role || 'Okänd roll';
    byId('role-chip').textContent = role;
    byId('host-version').textContent = `${hostInfo.hostVersionName} (${hostInfo.hostVersionCode})`;
    byId('package-version').textContent = String(hostInfo.packageVersion);
    byId('technical-role').textContent = role;
    byId('device-id').textContent = hostInfo.deviceId || 'Saknas';
    byId('watchdog-state').textContent = watchdog.getStatus();
    byId('watchdog-phase').textContent = watchdog.getLastPhase();
  }

  function renderPreservedTestValue() {
    const testValue = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    byId('module-test-value').textContent = String(testValue);
  }

  function saveSettings(event) {
    event.preventDefault();
    const nextPreferences = {
      largeText: byId('large-text').checked,
      showTechnicalInfo: byId('show-technical').checked
    };
    const nextDocument = {
      ...settingsDocument,
      [UI_SETTINGS_KEY]: nextPreferences,
      [PHASE_COLOR_SETTINGS_KEY]: readPhaseColorForm(),
      settingsSchemaVersion: 2,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('save-status', window.StadslassHost.getLastError() || 'Inställningarna kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    applyUiPreferences(nextPreferences);
    showStatus('save-status', 'Inställningarna är sparade.');
  }

  function incrementPreservedTestValue() {
    const current = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    const nextDocument = { ...settingsDocument, moduleTestValue: current + 1 };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('storage-status', window.StadslassHost.getLastError() || 'Testvärdet kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    renderPreservedTestValue();
    showStatus('storage-status', 'Testvärdet är sparat i inställningslagret.');
  }

  function loadGoogleSettings() {
    const stored = settingsDocument[googleService.SETTINGS_KEY];
    googleDiagnostics = googleService.normalizeDiagnostics(settingsDocument[googleService.DIAGNOSTICS_KEY]);
    try {
      googleSettings = googleService.validateSettings(stored);
      watchdog.step('runtime.google.settings.validated', googleService.hasApiKey(googleSettings.apiKey)
        ? 'En maskerad lokal Google API-nyckel är tillgänglig för den gemensamma Google-tjänsten.'
        : 'Ingen Google API-nyckel är ännu sparad lokalt. Geokodning kommer inte att blockera platslagring.');
    } catch (error) {
      googleSettings = googleService.normalizeSettings({});
      watchdog.step('runtime.google.settings.invalid', `${error && error.message ? error.message : 'Google-inställningen kunde inte verifieras.'} Den ogiltiga nyckeln används inte och övriga inställningar är orörda.`, 'warning');
    }
  }

  function renderGoogleDiagnostics() {
    const element = byId('google-diagnostic-summary');
    if (!element) return;
    const entries = googleDiagnostics && Array.isArray(googleDiagnostics.entries) ? googleDiagnostics.entries : [];
    const latest = entries.length ? entries[entries.length - 1] : null;
    if (!latest) {
      element.textContent = 'Ingen geokodningsfelrapport är sparad.';
      element.classList.remove('is-error');
      return;
    }
    const flowLabel = latest.registerFlow || (latest.flow === 'beach' ? 'Badplatser' : (latest.flow === 'place' ? 'Platser' : 'Okänt register'));
    const googleStatus = latest.googleStatus || 'ingen Google-status';
    const errorName = latest.errorName || 'okänt JavaScript-fel';
    const pageContext = latest.pageOrigin || latest.pageProtocol || 'okänd origin';
    const onlineLabel = latest.navigatorOnline === true ? 'online' : (latest.navigatorOnline === false ? 'offline' : 'okänd nätstatus');
    element.textContent = `${flowLabel} · ${latest.errorCode || 'RUNTIME_ERROR'} · ${googleStatus} · ${errorName} · ${pageContext} · ${onlineLabel} · ${latest.at || 'okänd tid'}`;
    element.classList.add('is-error');
  }

  function renderGoogleSettings() {
    byId('google-api-key').value = '';
    byId('google-key-mask').textContent = googleService.maskApiKey(googleSettings && googleSettings.apiKey);
    byId('google-service-clear').disabled = !googleSettings || !googleService.hasApiKey(googleSettings.apiKey);
    renderGoogleDiagnostics();
  }

  function persistGoogleDiagnostic(diagnostic) {
    const nextDiagnostics = googleService.appendDiagnostic(googleDiagnostics, diagnostic, new Date().toISOString());
    const nextDocument = {
      ...settingsDocument,
      [googleService.DIAGNOSTICS_KEY]: nextDiagnostics,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      watchdog.step('runtime.google.diagnostic.write-failed', window.StadslassHost.getLastError() || 'Den maskerade Google-diagnostiken kunde inte sparas.', 'warning');
      return false;
    }
    settingsDocument = nextDocument;
    googleDiagnostics = nextDiagnostics;
    renderGoogleDiagnostics();
    watchdog.step('runtime.google.diagnostic.saved', `${diagnostic.flow || 'unknown'}: ${diagnostic.errorCode || 'RUNTIME_ERROR'} / ${diagnostic.googleStatus || 'NO_GOOGLE_STATUS'} / ${diagnostic.stage || 'unknown'}.`, 'warning');
    return true;
  }

  async function requestSharedRegistryGeocoding(current, flow) {
    try {
      const result = await googleService.geocode(current.addressOrPlusCode, googleSettings && googleSettings.apiKey);
      const geocoding = googleService.resolvedGeocoding(current.geocoding, result, new Date().toISOString());
      watchdog.step(`runtime.google.geocoding.${flow}.resolved`, `Google Geocoding löste ${flow === 'beach' ? 'badplats' : 'plats'}-ID ${current.id} genom den gemensamma tjänsten.`);
      return {
        geocoding,
        isError: false,
        detail: `Koordinater hämtades. Identifierad plats: ${geocoding.formattedAddress || current.addressOrPlusCode}.`
      };
    } catch (error) {
      const status = googleService.errorStatus(error);
      const userMessage = googleService.userMessageForError(error);
      const geocoding = googleService.failedGeocoding(
        current.geocoding,
        current.addressOrPlusCode,
        error && error.code,
        userMessage,
        status,
        new Date().toISOString()
      );
      const diagnostic = googleService.diagnosticFromError(error, {
        flow,
        itemId: current.id,
        apiKey: googleSettings && googleSettings.apiKey,
        query: current.addressOrPlusCode,
        at: geocoding.lastAttemptAt
      });
      persistGoogleDiagnostic(diagnostic);
      watchdog.step(
        `runtime.google.geocoding.${flow}.failed`,
        `${current.id}: ${diagnostic.errorCode} / ${diagnostic.googleStatus || 'NO_GOOGLE_STATUS'} / ${diagnostic.errorName || 'NO_ERROR_NAME'} / ${diagnostic.pageProtocol || 'NO_PROTOCOL'} / ${diagnostic.navigatorOnline === true ? 'ONLINE' : (diagnostic.navigatorOnline === false ? 'OFFLINE' : 'ONLINE_UNKNOWN')} / ${diagnostic.category} / ${diagnostic.stage}.`,
        'warning'
      );
      return { geocoding, isError: true, detail: userMessage };
    }
  }

  function persistGoogleSettings(nextSettings) {
    const validated = googleService.validateSettings(nextSettings);
    const nextDocument = {
      ...settingsDocument,
      [googleService.SETTINGS_KEY]: validated,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('google-service-status', window.StadslassHost.getLastError() || 'Google API-nyckeln kunde inte sparas lokalt.', true);
      return false;
    }
    settingsDocument = nextDocument;
    googleSettings = validated;
    renderGoogleSettings();
    watchdog.step('runtime.google.settings.saved', googleService.hasApiKey(validated.apiKey)
      ? 'Google API-nyckeln sparades maskerad i det lokala inställningslagret.'
      : 'Den lokalt sparade Google API-nyckeln togs bort.');
    return true;
  }

  function saveGoogleSettings(event) {
    event.preventDefault();
    try {
      const apiKey = text(byId('google-api-key').value);
      if (!apiKey) throw new Error('Skriv in den befintliga Google API-nyckeln från Stadslass 2.0.');
      const nextSettings = {
        schemaVersion: googleService.SCHEMA_VERSION,
        apiKey,
        updatedAt: new Date().toISOString()
      };
      if (!persistGoogleSettings(nextSettings)) return;
      showStatus('google-service-status', 'Google API-nyckeln är sparad lokalt och visas nu maskerad. Inget Google-anrop gjordes.');
    } catch (error) {
      showStatus('google-service-status', error && error.message ? error.message : 'Google API-nyckeln kunde inte sparas.', true);
    }
  }

  function clearGoogleSettings() {
    const nextSettings = {
      schemaVersion: googleService.SCHEMA_VERSION,
      apiKey: '',
      updatedAt: new Date().toISOString()
    };
    if (!persistGoogleSettings(nextSettings)) return;
    showStatus('google-service-status', 'Den lokalt sparade Google API-nyckeln är borttagen. Platser kan fortfarande sparas utan geokodning.');
  }

  function loadEditableJobTypeRegistry() {
    const stored = settingsDocument[editableJobTypeApi.SETTINGS_KEY];
    const timestamp = new Date().toISOString();
    try {
      const migration = editableJobTypeApi.migrateAndMergeRegistry(stored, baselineJobTypeItems, timestamp);
      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [editableJobTypeApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
        if (!saved) throw new Error(window.StadslassHost.getLastError() || 'Det gemensamma Jobbtypsregistret kunde inte migreras atomiskt.');
        settingsDocument = nextDocument;
        watchdog.step('runtime.registry.editable-job-types.migrated', `${migration.registry.items.length} jobbtyper migrerades och förenades med standarddefinitionerna utan dubbletter.`);
      }
      editableJobTypeApi.validateRegistry(migration.registry);
      editableJobTypeRegistry = migration.registry;
      editableJobTypeRegistryError = '';
      applyEffectiveJobTypeRegistry(migration.registry.items);
      watchdog.step('runtime.registry.editable-job-types.validated', `${migration.registry.items.length} jobbtyper verifierades som appens gemensamma jobbtypskälla.`);
    } catch (error) {
      editableJobTypeRegistry = null;
      editableJobTypeRegistryError = error && error.message ? error.message : 'Jobbtypsregistret kunde inte verifieras.';
      const fallback = editableJobTypeApi.migrateAndMergeRegistry(undefined, baselineJobTypeItems, timestamp).registry;
      applyEffectiveJobTypeRegistry(fallback.items);
      watchdog.step('runtime.registry.editable-job-types.invalid', `${editableJobTypeRegistryError} Sparad registerdata är orörd; standarddefinitionerna används endast som skrivskyddad reserv i minnet.`, 'warning');
    }
  }

  function editableSpecialRoleLabel(role) {
    if (role === 'other-activity') return 'Övrig verksamhet';
    if (role === 'havstang') return 'Havstång';
    if (role === 'machine-transport') return 'Maskintransport';
    return '';
  }

  function resetEditableJobTypeEditor() {
    editingEditableJobTypeId = '';
    byId('job-type-registry-edit-id').value = '';
    byId('job-type-registry-name').value = '';
    byId('job-type-registry-special-role').disabled = false;
    byId('job-type-registry-special-role').value = 'none';
    byId('job-type-registry-submit').textContent = 'Lägg till jobbtyp';
    byId('job-type-registry-cancel').hidden = true;
    clearAtaRecipient('jobtype');
    syncAtaForm('jobtype', true);
  }

  function renderEditableJobTypeRegistry() {
    const list = byId('job-type-registry-list');
    list.replaceChildren();
    const disabled = !editableJobTypeRegistry;
    byId('job-type-registry-form').querySelectorAll('input, select, button').forEach((element) => {
      element.disabled = disabled;
    });

    if (disabled) {
      byId('job-type-registry-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editableJobTypeRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('job-type-registry-status', 'Jobbtypsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const items = editableJobTypeRegistry.items.filter((item) => !(systemJobPolicy && systemJobPolicy.isSystem && systemJobPolicy.isSystem(item))).slice().sort((a, b) => a.name.localeCompare(b.name, 'sv-SE'));
    byId('job-type-registry-count').textContent = String(items.length);

    if (items.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Jobbtypsregistret saknar valbara poster.';
      list.appendChild(empty);
      return;
    }

    items.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'registry-card';
      card.dataset.jobTypeRegistryId = item.id;

      const header = document.createElement('div');
      header.className = 'registry-card-header';
      const heading = document.createElement('h4');
      heading.textContent = item.name;
      header.append(heading);

      const metadata = document.createElement('div');
      metadata.className = 'queue-meta';
      const labels = [];
      const special = editableSpecialRoleLabel(item.specialRole);
      if (special) labels.push(`Specialtyp: ${special}`);
      if (item.ataEnabled === true) labels.push('ÄTA-jobb');
      if (item.ataRecipient && item.ataRecipient.email) labels.push(`ÄTA-mottagare: ${item.ataRecipient.name} · ${item.ataRecipient.email}`);
      labels.forEach((label) => {
        const chip = document.createElement('span');
        chip.className = 'meta-chip';
        chip.textContent = label;
        metadata.appendChild(chip);
      });

      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.className = 'secondary-button';
      edit.type = 'button';
      edit.dataset.editJobTypeRegistry = item.id;
      edit.textContent = 'Redigera';
      const remove = document.createElement('button');
      remove.className = 'danger-button';
      remove.type = 'button';
      remove.dataset.removeJobTypeRegistry = item.id;
      remove.textContent = 'Ta bort';
      remove.hidden = /^PL-[0-9]{4}$/.test(item.id);
      actions.append(edit, remove);

      card.appendChild(header);
      if (labels.length > 0) card.appendChild(metadata);
      card.appendChild(actions);
      list.appendChild(card);
    });
  }

  function editableJobTypeFormValue() {
    return {
      name: byId('job-type-registry-name').value,
      specialRole: byId('job-type-registry-special-role').value,
      ataEnabled: byId('job-type-registry-ata-enabled').checked,
      ataRecipient: ataRecipientInput('jobtype')
    };
  }

  function persistEditableJobTypeRegistry(nextRegistry) {
    editableJobTypeApi.validateRegistry(nextRegistry);
    const nextDocument = {
      ...settingsDocument,
      [editableJobTypeApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('job-type-registry-status', window.StadslassHost.getLastError() || 'Jobbtypsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    editableJobTypeRegistry = nextRegistry;
    editableJobTypeRegistryError = '';
    applyEffectiveJobTypeRegistry(nextRegistry.items);
    refreshRuntimeJobTypeSelects();
    refreshQuickChoiceJobTypeSelect();
    refreshPlaceFormsForJobType('');
    refreshPlaceFormsForJobType('active-');
    updateMaterialPanel('');
    updateMaterialPanel('active-');
    watchdog.step('runtime.registry.editable-job-types.saved', `Jobbtypsregistrets revision ${nextRegistry.revision} sparades atomiskt och blev omedelbart appens gemensamma jobbtypskälla.`);
    return true;
  }

  function resolveQuickChoiceAtaConflict(jobTypeId) {
    if (!quickChoiceRegistry) return;
    const affected = quickChoiceRegistry.items.filter((item) => item.jobTypeId === jobTypeId && item.ataNeedsCorrection === true);
    if (affected.length === 0) return;
    const nextItems = quickChoiceRegistry.items.map((item) => item.jobTypeId === jobTypeId
      ? { ...item, ataNeedsCorrection: false, ataLegacyDefault: false, ataDefault: false, ataMigrationV59: true }
      : item);
    const nextRegistry = quickChoiceApi.withItems(quickChoiceRegistry, nextItems, new Date().toISOString());
    persistQuickChoiceRegistry(nextRegistry);
  }

  function saveEditableJobType(event) {
    event.preventDefault();
    if (!editableJobTypeRegistry) {
      showStatus('job-type-registry-status', 'Jobbtypsregistret är skrivskyddat eftersom det inte kunde verifieras.', true);
      return;
    }
    try {
      const timestamp = new Date().toISOString();
      const items = editableJobTypeRegistry.items.slice();
      let nextItems;
      let message;
      if (editingEditableJobTypeId) {
        const current = items.find((item) => item.id === editingEditableJobTypeId);
        if (!current) throw new Error('Jobbtypen som skulle redigeras finns inte längre.');
        const formValue = editableJobTypeFormValue();
        formValue.ataRecipient = ensureAtaRecipientContact(formValue.ataRecipient, 'job-type', 'job-type-registry-status');
        const updated = editableJobTypeApi.updateItem(current, formValue, items, timestamp);
        nextItems = items.map((item) => item.id === current.id ? updated : item);
        message = `${updated.name} har uppdaterats. Det stabila ID:t är oförändrat.`;
      } else {
        const formValue = editableJobTypeFormValue();
        formValue.ataRecipient = ensureAtaRecipientContact(formValue.ataRecipient, 'job-type', 'job-type-registry-status');
        const created = editableJobTypeApi.createItem(formValue, items, timestamp);
        nextItems = items.concat(created);
        message = `${created.name} har lagts till.`;
      }
      const nextRegistry = editableJobTypeApi.withItems(editableJobTypeRegistry, nextItems, timestamp);
      if (!persistEditableJobTypeRegistry(nextRegistry)) return;
      if (editingEditableJobTypeId) resolveQuickChoiceAtaConflict(editingEditableJobTypeId);
      resetEditableJobTypeEditor();
      renderEditableJobTypeRegistry();
      renderEditablePlaceJobTypeChoices();
      showStatus('job-type-registry-status', message);
    } catch (error) {
      showStatus('job-type-registry-status', error && error.message ? error.message : 'Jobbtypen kunde inte sparas.', true);
    }
  }

  function editEditableJobType(id) {
    if (!editableJobTypeRegistry) return;
    const item = editableJobTypeRegistry.items.find((candidate) => candidate.id === id);
    if (!item) {
      showStatus('job-type-registry-status', 'Jobbtypen som skulle redigeras saknas.', true);
      return;
    }
    editingEditableJobTypeId = item.id;
    byId('job-type-registry-edit-id').value = item.id;
    byId('job-type-registry-name').value = item.name;
    byId('job-type-registry-special-role').value = item.specialRole;
    byId('job-type-registry-special-role').disabled = item.defaultDefinition === true;
    byId('job-type-registry-ata-enabled').checked = item.ataEnabled === true;
    writeAtaRecipientInput('jobtype', item.ataRecipient || null);
    renderAtaRecipientContacts('jobtype', item.ataRecipient || null);
    syncAtaForm('jobtype', false);
    byId('job-type-registry-submit').textContent = 'Spara ändringar';
    byId('job-type-registry-cancel').hidden = false;
    showStatus('job-type-registry-status', `Redigerar ${item.name}.`);
    scrollSettingsContentIntoView(byId('job-type-registry-form'));
  }

  function removeEditableJobType(id) {
    if (!editableJobTypeRegistry) return;
    try {
      const items = editableJobTypeRegistry.items.slice();
      const current = items.find((item) => item.id === id);
      if (!current) throw new Error('Jobbtypen som skulle tas bort saknas.');
      const timestamp = new Date().toISOString();
      if (!window.confirm('Ta bort ' + current.name + '? Jobbtypen tas bort och dess kopplingar till Platser, Badplatser och Snabbval rensas. Andra registerposter samt sparade uppdrag och historik behålls.')) return;
      const nextRegistry = editableJobTypeApi.removeFromRegistry(editableJobTypeRegistry, current, timestamp);
      const nextValidJobTypeIds = new Set(Array.from(editableJobTypeIds()).filter((value) => value !== current.id));
      const nextPlaces = editablePlaceRegistry ? editablePlaceApi.withItems(editablePlaceRegistry, editablePlaceRegistry.items.map((item) => ({ ...item, jobTypeFromIds: item.jobTypeFromIds.filter((value) => value !== current.id), jobTypeToIds: item.jobTypeToIds.filter((value) => value !== current.id) })), nextValidJobTypeIds, timestamp) : null;
      const nextBeaches = editableBeachRegistry ? editableBeachApi.withItems(editableBeachRegistry, editableBeachRegistry.items.map((item) => ({ ...item, allowedJobTypeIds: item.allowedJobTypeIds.filter((value) => value !== current.id) })), timestamp) : null;
      const nextQuickChoices = quickChoiceRegistry ? quickChoiceApi.withItems(quickChoiceRegistry, clearQuickChoiceReferences(quickChoiceRegistry.items, '', current.id), timestamp) : null;
      saveRegistryRemoval(nextRegistry, nextPlaces, nextBeaches, nextQuickChoices);
      if (editingEditableJobTypeId === current.id) resetEditableJobTypeEditor();
      renderEditableJobTypeRegistry();
      renderEditablePlaceJobTypeChoices();
      showStatus('job-type-registry-status', current.name + ' och dess kopplingar har tagits bort. Redan sparade uppdrag och historik är oförändrade.');
    } catch (error) {
      showStatus('job-type-registry-status', error && error.message ? error.message : 'Jobbtypen kunde inte tas bort.', true);
    }
  }

  function editableJobTypeIds() {
    return new Set(editableJobTypeRegistry ? editableJobTypeRegistry.items.map((item) => item.id) : []);
  }

  function editableJobTypeName(id) {
    const item = editableJobTypeRegistry && editableJobTypeRegistry.items.find((candidate) => candidate.id === id);
    return item ? item.name : id;
  }

  function loadEditablePlaceRegistry() {
    const stored = settingsDocument[editablePlaceApi.SETTINGS_KEY];
    try {
      const baseNormalPlaces = basePlaceItems.filter((place) => !editableBeachApi.isBeachPlace(place));
      const migration = editablePlaceApi.migrateRegistry(stored, baseNormalPlaces, editableJobTypeIds(), new Date().toISOString());
      editablePlaceApi.validateRegistry(migration.registry, editableJobTypeIds());
      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [editablePlaceApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
        if (!saved) throw new Error(window.StadslassHost.getLastError() || 'Platsregistret kunde inte migreras atomiskt.');
        settingsDocument = nextDocument;
        watchdog.step('runtime.registry.editable-places.migrated', `Platsregister schema ${migration.sourceSchemaVersion} migrerades atomiskt till schema ${editablePlaceApi.SCHEMA_VERSION} med integrerad geofence och ${migration.seededCount || 0} fasta platsseedningar.`);
      } else if (!migration.sourceExisted) {
        watchdog.step('runtime.registry.editable-places.validated', 'Platsregistret är giltigt och geofence ligger direkt i platsdata.');
      }
      editablePlaceRegistry = migration.registry;
      editablePlaceRegistryError = '';
      watchdog.step('runtime.registry.editable-places.validated', `${migration.registry.items.length} redigerbara platser verifierades med dold geokodnings- och geofencedata.`);
    } catch (error) {
      editablePlaceRegistry = null;
      editablePlaceRegistryError = error && error.message ? error.message : 'Platsregistret kunde inte verifieras.';
      watchdog.step('runtime.registry.editable-places.invalid', `${editablePlaceRegistryError} Ingen registerdata har ändrats.`, 'warning');
    }
  }

  function checkedRegistryIds(containerId) {
    return Array.from(byId(containerId).querySelectorAll('input[type="checkbox"]:checked'), (input) => input.value);
  }

  function renderEditablePlaceJobTypeChoices(selection = null) {
    const currentSelection = selection || {
      from: checkedRegistryIds('place-registry-job-types-from'),
      to: checkedRegistryIds('place-registry-job-types-to')
    };
    const selectedFrom = new Set(currentSelection.from || []);
    const selectedTo = new Set(currentSelection.to || []);
    const items = editableJobTypeRegistry
      ? editableJobTypeRegistry.items.slice().sort((a, b) => a.name.localeCompare(b.name, 'sv-SE'))
      : [];

    for (const definition of [
      { containerId: 'place-registry-job-types-from', selected: selectedFrom, prefix: 'place-from-' },
      { containerId: 'place-registry-job-types-to', selected: selectedTo, prefix: 'place-to-' }
    ]) {
      const container = byId(definition.containerId);
      container.replaceChildren();
      if (items.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.textContent = editableJobTypeRegistry
          ? 'Inga jobbtyper finns ännu. Tom koppling är tillåten.'
          : 'Jobbtypsregistret kunde inte läsas.';
        container.appendChild(empty);
        continue;
      }
      items.forEach((item) => {
        const label = document.createElement('label');
        label.className = 'choice-row';
        label.htmlFor = `${definition.prefix}${item.id}`;
        const input = document.createElement('input');
        input.id = `${definition.prefix}${item.id}`;
        input.type = 'checkbox';
        input.value = item.id;
        input.checked = definition.selected.has(item.id);
        input.disabled = !editablePlaceRegistry;
        const content = document.createElement('span');
        const name = document.createElement('strong');
        name.textContent = item.name;
        content.appendChild(name);
        label.append(input, content);
        container.appendChild(label);
      });
    }
  }

  function geocodingDisplay(value) {
    const geocoding = googleService.normalizeGeocoding(value);
    if (geocoding.status === 'resolved') {
      return {
        label: 'Koordinater hämtade',
        detail: geocoding.formattedAddress ? `Identifierad plats: ${geocoding.formattedAddress}` : 'Google returnerade giltiga dolda koordinater.',
        isError: false
      };
    }
    if (geocoding.status === 'pending') return { label: 'Väntar på geokodning', detail: 'Koordinater hämtas automatiskt vid Spara.', isError: false };
    if (geocoding.status === 'invalid-input') return { label: 'Adress behöver rättas', detail: geocoding.errorMessage || 'Adress / Plus Code kunde inte användas.', isError: true };
    if (geocoding.status === 'unavailable') return { label: 'Koordinater saknas', detail: geocoding.errorMessage || 'Google eller internet var inte tillgängligt.', isError: true };
    if (geocoding.status === 'failed') return { label: 'Koordinater kunde inte hämtas', detail: geocoding.errorMessage || 'Google kunde inte identifiera platsen.', isError: true };
    return { label: 'Ingen geokodning', detail: 'Spara en Adress / Plus Code för att hämta koordinater automatiskt.', isError: false };
  }

  function renderGeocodingNote(elementId, value) {
    const element = byId(elementId);
    const display = geocodingDisplay(value);
    element.textContent = `${display.label}. ${display.detail}`;
    element.classList.toggle('is-error', display.isError);
  }

  function updateEditablePlaceGeofenceVisibility() {
    const enabled = byId('place-registry-geofence-enabled').checked;
    const type = byId('place-registry-geofence-type').value === 'polygon' ? 'polygon' : 'circle';
    byId('place-registry-geofence-fields').hidden = !enabled;
    byId('place-registry-geofence-enabled').setAttribute('aria-expanded', String(enabled));
    byId('place-registry-circle-fields').hidden = type !== 'circle';
    byId('place-registry-polygon-fields').hidden = type !== 'polygon';
    byId('place-registry-radius').required = enabled && type === 'circle';
    byId('place-registry-polygon-points').required = enabled && type === 'polygon';
    byId('place-registry-tolerance').required = enabled;
  }

  function geofenceFormValue(prefix) {
    const type = byId(`${prefix}-geofence-type`).value === 'polygon' ? 'polygon' : 'circle';
    return {
      enabled: byId(`${prefix}-geofence-enabled`).checked,
      type,
      visualLoadingLock: byId(`${prefix}-loading-lock`).checked,
      visualUnloadingLock: byId(`${prefix}-unloading-lock`).checked,
      radiusMeters: type === 'circle' ? byId(`${prefix}-radius`).value : null,
      polygonPoints: type === 'polygon' ? geofenceService.parsePolygonPoints(byId(`${prefix}-polygon-points`).value) : [],
      toleranceMeters: byId(`${prefix}-tolerance`).value
    };
  }

  function setGeofenceForm(prefix, definition) {
    const value = geofenceService.normalizeDefinition(definition);
    byId(`${prefix}-geofence-enabled`).checked = value.enabled;
    byId(`${prefix}-geofence-type`).value = value.type;
    byId(`${prefix}-loading-lock`).checked = value.visualLoadingLock;
    byId(`${prefix}-unloading-lock`).checked = value.visualUnloadingLock;
    byId(`${prefix}-radius`).value = editablePlaceNumber(value.radiusMeters);
    byId(`${prefix}-polygon-points`).value = geofenceService.formatPolygonPoints(value.polygonPoints);
    byId(`${prefix}-tolerance`).value = value.toleranceMeters === null ? '0' : String(value.toleranceMeters);
  }

  function resetPlaceGeofenceForm() {
    setGeofenceForm('place-registry', { enabled: false, type: 'circle', toleranceMeters: 0 });
  }

  function resetEditablePlaceEditor() {
    editingEditablePlaceId = '';
    byId('place-registry-edit-id').value = '';
    byId('place-registry-name').value = '';
    byId('place-registry-address').value = '';
    renderGeocodingNote('place-registry-geocoding-note', null);
    byId('place-registry-requirements').value = '';
    byId('place-registry-opening-hours').value = '';
    byId('place-registry-return-place').checked = false;
    resetPlaceGeofenceForm();
    byId('place-registry-submit').textContent = 'Lägg till plats';
    byId('place-registry-cancel').hidden = true;
    renderEditablePlaceJobTypeChoices({ from: [], to: [] });
    updateEditablePlaceGeofenceVisibility();
  }

  function editablePlaceLabels(item) {
    const labels = [];
    if (item.canBeReturnPlace) labels.push('Returplats');
    if (item.jobTypeFromIds.length) labels.push(`Från: ${item.jobTypeFromIds.map(editableJobTypeName).join(', ')}`);
    if (item.jobTypeToIds.length) labels.push(`Till: ${item.jobTypeToIds.map(editableJobTypeName).join(', ')}`);
    if (item.geofence.enabled) labels.push(item.geofence.type === 'circle' ? `Geofence: Cirkel ${item.geofence.radiusMeters} m` : `Geofence: Polygon ${item.geofence.polygonPoints.length} punkter`);
    if (item.geofence.visualLoadingLock) labels.push('Lastningslås');
    if (item.geofence.visualUnloadingLock) labels.push('Lossningslås');
    labels.push(geocodingDisplay(item.geocoding).label);
    return labels;
  }

  function renderEditablePlaceRegistry() {
    const list = byId('place-registry-list');
    list.replaceChildren();
    const disabled = !editablePlaceRegistry;
    byId('place-registry-form').querySelectorAll('input, select, textarea, button').forEach((element) => {
      element.disabled = disabled;
    });
    renderEditablePlaceJobTypeChoices();

    if (disabled) {
      byId('place-registry-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editablePlaceRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('place-registry-status', 'Platsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const items = editablePlaceRegistry.items.slice().sort((a, b) => a.name.localeCompare(b.name, 'sv-SE'));
    byId('place-registry-count').textContent = String(items.length);
    if (items.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Platsregistret är tomt. Det är ett giltigt startläge.';
      list.appendChild(empty);
      return;
    }

    items.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'registry-card';
      card.dataset.placeRegistryId = item.id;

      const header = document.createElement('div');
      header.className = 'registry-card-header';
      const heading = document.createElement('h4');
      heading.textContent = item.name;
      header.appendChild(heading);

      if (item.addressOrPlusCode) {
        const address = document.createElement('p');
        address.className = 'queue-route';
        address.textContent = item.addressOrPlusCode;
        card.append(header, address);
      } else {
        card.appendChild(header);
      }
      if (item.geocoding && item.geocoding.status === 'resolved' && item.geocoding.formattedAddress) {
        const identified = document.createElement('p');
        identified.className = 'geocoding-card-detail';
        identified.textContent = `Identifierad plats: ${item.geocoding.formattedAddress}`;
        card.appendChild(identified);
      }

      const metadata = document.createElement('div');
      metadata.className = 'queue-meta';
      const labels = editablePlaceLabels(item);
      if (labels.length === 0) labels.push('Inga listkopplingar');
      labels.forEach((label) => {
        const chip = document.createElement('span');
        chip.className = 'meta-chip';
        chip.textContent = label;
        metadata.appendChild(chip);
      });

      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.className = 'secondary-button';
      edit.type = 'button';
      edit.dataset.editPlaceRegistry = item.id;
      edit.textContent = 'Redigera';
      const remove = document.createElement('button');
      remove.className = 'danger-button';
      remove.type = 'button';
      remove.dataset.removePlaceRegistry = item.id;
      remove.textContent = 'Ta bort';
      actions.append(edit, remove);

      card.append(metadata, actions);
      list.appendChild(card);
    });
  }

  function editablePlaceFormValue() {
    return {
      name: byId('place-registry-name').value,
      addressOrPlusCode: byId('place-registry-address').value,
      placeRequirements: byId('place-registry-requirements').value,
      openingHours: byId('place-registry-opening-hours').value,
      canBeReturnPlace: byId('place-registry-return-place').checked,
      jobTypeFromIds: checkedRegistryIds('place-registry-job-types-from'),
      jobTypeToIds: checkedRegistryIds('place-registry-job-types-to'),
      geofence: geofenceFormValue('place-registry')
    };
  }

  function persistEditablePlaceRegistry(nextRegistry) {
    editablePlaceApi.validateRegistry(nextRegistry, editableJobTypeIds());
    const nextDocument = {
      ...settingsDocument,
      [editablePlaceApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('place-registry-status', window.StadslassHost.getLastError() || 'Platsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    editablePlaceRegistry = nextRegistry;
    editablePlaceRegistryError = '';
    buildEffectivePlaceRegistry();
    validateRegistries();
    refreshPlaceFormsForJobType('');
    refreshPlaceFormsForJobType('active-');
    populateQuickChoicePlaceOptions();
    renderQuickChoiceRegistry();
    renderQuickChoices();
    updateMaterialPanel('');
    updateMaterialPanel('active-');
    watchdog.step('runtime.registry.editable-places.saved', `Platsregistrets revision ${nextRegistry.revision} sparades atomiskt och platsfiltren uppdaterades utan appomstart.`);
    return true;
  }

  async function applyPlaceGeocodingResult(itemId, baseMessage) {
    const current = editablePlaceRegistry && editablePlaceRegistry.items.find((item) => item.id === itemId);
    if (!current || !current.addressOrPlusCode || current.geocoding.status !== 'pending') {
      showStatus('place-registry-status', baseMessage);
      return;
    }
    watchdog.step('runtime.google.geocoding.place.started', `Geokodning startades för plats-ID ${current.id} genom den gemensamma registermetoden utan ny GPS-bevakning.`);
    const outcome = await requestSharedRegistryGeocoding(current, 'place');
    const geocoding = outcome.geocoding;
    const resultMessage = outcome.isError
      ? `${baseMessage} ${outcome.detail} Platsen är sparad och kan rättas eller sparas igen senare.`
      : `${baseMessage} ${outcome.detail}`;
    const isError = outcome.isError;
    const timestamp = new Date().toISOString();
    const items = editablePlaceRegistry.items.slice();
    const latest = items.find((item) => item.id === itemId);
    if (!latest) {
      showStatus('place-registry-status', `${baseMessage} Geokodningsresultatet kunde inte kopplas till platsen.`, true);
      return;
    }
    if (latest.geocoding.status !== 'pending' || latest.geocoding.query !== current.geocoding.query || latest.addressOrPlusCode !== current.addressOrPlusCode) {
      watchdog.step('runtime.google.geocoding.place.stale-result', `${current.id}: ett äldre geokodningsresultat ignorerades eftersom platsen ändrades under anropet.`, 'warning');
      showStatus('place-registry-status', `${baseMessage} Ett äldre geokodningsresultat ignorerades eftersom platsen hade ändrats.`);
      return;
    }
    const validJobTypeIds = editableJobTypeIds();
    const updated = editablePlaceApi.applyGeocoding(latest, geocoding, items, validJobTypeIds, timestamp);
    const nextItems = items.map((item) => item.id === itemId ? updated : item);
    const nextRegistry = editablePlaceApi.withItems(editablePlaceRegistry, nextItems, validJobTypeIds, timestamp);
    if (!persistEditablePlaceRegistry(nextRegistry)) {
      showStatus('place-registry-status', `${baseMessage} Platsen är sparad, men koordinaterna kunde inte sparas. Spara platsen igen senare.`, true);
      return;
    }
    renderEditablePlaceRegistry();
    showStatus('place-registry-status', resultMessage, isError);
  }

  async function saveEditablePlace(event) {
    event.preventDefault();
    if (!editablePlaceRegistry) {
      showStatus('place-registry-status', 'Platsregistret är skrivskyddat eftersom det inte kunde verifieras.', true);
      return;
    }
    const submitButton = byId('place-registry-submit');
    submitButton.disabled = true;
    try {
      const timestamp = new Date().toISOString();
      const items = editablePlaceRegistry.items.slice();
      const validJobTypeIds = editableJobTypeIds();
      let nextItems;
      let savedItem;
      let message;
      if (editingEditablePlaceId) {
        const current = items.find((item) => item.id === editingEditablePlaceId);
        if (!current) throw new Error('Platsen som skulle redigeras finns inte längre.');
        savedItem = editablePlaceApi.updateItem(current, editablePlaceFormValue(), items, validJobTypeIds, timestamp);
        nextItems = items.map((item) => item.id === current.id ? savedItem : item);
        message = `${savedItem.name} har uppdaterats. Det stabila ID:t är oförändrat.`;
      } else {
        savedItem = editablePlaceApi.createItem(editablePlaceFormValue(), items, validJobTypeIds, timestamp);
        nextItems = items.concat(savedItem);
        message = `${savedItem.name} har lagts till.`;
      }
      const nextRegistry = editablePlaceApi.withItems(editablePlaceRegistry, nextItems, validJobTypeIds, timestamp);
      if (!persistEditablePlaceRegistry(nextRegistry)) return;
      const savedItemId = savedItem.id;
      resetEditablePlaceEditor();
      renderEditablePlaceRegistry();
      if (savedItem.geocoding.status === 'pending' && savedItem.addressOrPlusCode) {
        showStatus('place-registry-status', `${message} Koordinater hämtas från Google…`);
        await applyPlaceGeocodingResult(savedItemId, message);
      } else {
        showStatus('place-registry-status', message);
      }
    } catch (error) {
      showStatus('place-registry-status', error && error.message ? error.message : 'Platsen kunde inte sparas.', true);
    } finally {
      submitButton.disabled = !editablePlaceRegistry;
    }
  }

  function editablePlaceNumber(value) {
    return value === null || typeof value === 'undefined' ? '' : String(value);
  }

  function editEditablePlace(id) {
    if (!editablePlaceRegistry) return;
    const item = editablePlaceRegistry.items.find((candidate) => candidate.id === id);
    if (!item) {
      showStatus('place-registry-status', 'Platsen som skulle redigeras saknas.', true);
      return;
    }
    editingEditablePlaceId = item.id;
    byId('place-registry-edit-id').value = item.id;
    byId('place-registry-name').value = item.name;
    byId('place-registry-address').value = item.addressOrPlusCode;
    renderGeocodingNote('place-registry-geocoding-note', item.geocoding);
    byId('place-registry-requirements').value = item.placeRequirements;
    byId('place-registry-opening-hours').value = item.openingHours;
    byId('place-registry-return-place').checked = item.canBeReturnPlace;
    setGeofenceForm('place-registry', item.geofence);
    renderEditablePlaceJobTypeChoices({ from: item.jobTypeFromIds, to: item.jobTypeToIds });
    updateEditablePlaceGeofenceVisibility();
    byId('place-registry-submit').textContent = 'Spara ändringar';
    byId('place-registry-cancel').hidden = false;
    showStatus('place-registry-status', `Redigerar ${item.name}.`);
    scrollSettingsContentIntoView(byId('place-registry-form'));
  }


  function saveRegistryRemoval(nextJobTypes, nextPlaces, nextBeaches, nextQuickChoices) {
    const nextDocument = {
      ...settingsDocument,
      ...(nextJobTypes ? { [editableJobTypeApi.SETTINGS_KEY]: nextJobTypes } : {}),
      ...(nextPlaces ? { [editablePlaceApi.SETTINGS_KEY]: nextPlaces } : {}),
      ...(nextBeaches ? { [editableBeachApi.SETTINGS_KEY]: nextBeaches } : {}),
      ...(nextQuickChoices ? { [quickChoiceApi.SETTINGS_KEY]: nextQuickChoices } : {}),
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    if (!window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument))) throw new Error(window.StadslassHost.getLastError() || 'Registerändringen kunde inte sparas.');
    settingsDocument = nextDocument;
    if (nextJobTypes) editableJobTypeRegistry = nextJobTypes;
    if (nextPlaces) editablePlaceRegistry = nextPlaces;
    if (nextBeaches) editableBeachRegistry = nextBeaches;
    if (nextQuickChoices) quickChoiceRegistry = nextQuickChoices;
    buildEffectivePlaceRegistry(); validateRegistries(); refreshPlaceFormsForJobType(''); refreshPlaceFormsForJobType('active-');
  }
  function clearQuickChoiceReferences(items, placeId = '', jobTypeId = '') {
    return items.map((item) => {
      const next = { ...item };
      if (placeId && next.fromPlaceId === placeId) next.fromPlaceId = '';
      if (placeId && next.toPlaceId === placeId) next.toPlaceId = '';
      if (placeId && next.returnPlaceId === placeId) next.returnPlaceId = '';
      if (jobTypeId && next.jobTypeId === jobTypeId) { next.jobTypeId = ''; next.jobTypeName = ''; }
      return next;
    });
  }
  function removeEditablePlace(id) {
    if (!editablePlaceRegistry) return;
    try {
      const items = editablePlaceRegistry.items.slice();
      const current = items.find((item) => item.id === id);
      if (!current) throw new Error('Platsen som skulle tas bort saknas.');
      if (!window.confirm('Ta bort ' + current.name + '? Platsen och dess geofence tas bort. Kopplingar från Jobbtyper och Snabbval rensas. Andra registerposter samt sparade uppdrag och historik behålls.')) return;
      const timestamp = new Date().toISOString();
      const validJobTypeIds = editableJobTypeIds();
      const nextRegistry = editablePlaceApi.removeFromRegistry(editablePlaceRegistry, current, validJobTypeIds, timestamp);
      const nextJobTypes = editableJobTypeRegistry ? editableJobTypeApi.withItems(editableJobTypeRegistry, editableJobTypeRegistry.items.map((item) => ({ ...item, ...(item.defaultDestinationPlaceId === current.id ? { defaultDestinationPlaceId: '' } : {}) })), timestamp) : null;
      const nextQuickChoices = quickChoiceRegistry ? quickChoiceApi.withItems(quickChoiceRegistry, clearQuickChoiceReferences(quickChoiceRegistry.items, current.id), timestamp) : null;
      saveRegistryRemoval(nextJobTypes, nextRegistry, null, nextQuickChoices);
      if (editingEditablePlaceId === current.id) resetEditablePlaceEditor();
      renderEditablePlaceRegistry();
      showStatus('place-registry-status', current.name + ' och dess kopplingar har tagits bort. Redan sparade uppdrag och historik är oförändrade.');
    } catch (error) {
      showStatus('place-registry-status', error && error.message ? error.message : 'Platsen kunde inte tas bort.', true);
    }
  }

  function loadEditableBeachRegistry() {
    const stored = settingsDocument[editableBeachApi.SETTINGS_KEY];
    const baseBeaches = basePlaceItems.filter((place) => editableBeachApi.isBeachPlace(place));
    editableBeachRegistryReadOnly = false;
    try {
      if (stored && Number(stored.schemaVersion) === 1) {
        watchdog.step('runtime.registry.editable-beaches.legacy-detected', 'Badplatsregister schema 1 upptäcktes och förbereds för atomisk migrering.');
      }
      const migration = editableBeachApi.migrateRegistry(stored, baseBeaches, new Date().toISOString());
      watchdog.step('runtime.registry.editable-beaches.migration-candidate', `Migreringskandidat skapades med ${migration.registry.items.length} poster.`);
      editableBeachApi.validateRegistry(migration.registry);
      watchdog.step('runtime.registry.editable-beaches.migration-validated', 'Migreringskandidaten verifierades utan skrivning.');

      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [editableBeachApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
        if (saved) {
          settingsDocument = nextDocument;
          watchdog.step('runtime.registry.editable-beaches.migrated', `Badplatsregister schema ${migration.sourceSchemaVersion} migrerades atomiskt till schema ${editableBeachApi.SCHEMA_VERSION}.`);
        } else {
          editableBeachRegistryReadOnly = true;
          editableBeachRegistryError = window.StadslassHost.getLastError() || 'Migreringen kunde inte sparas atomiskt.';
          watchdog.step('runtime.registry.editable-beaches.migration-pending', `${editableBeachRegistryError} Äldre data är orörd; verifierad kandidat används skrivskyddat i minnet.`, 'warning');
        }
      } else {
        watchdog.step('runtime.registry.editable-beaches.migration-not-needed', 'Badplatsregistret använder redan aktuellt schema och behöver inte skrivas om.');
      }

      migration.conflicts.forEach((conflict) => {
        watchdog.step('runtime.registry.editable-beaches.conflict', `${conflict.name}: äldre ID ${conflict.legacyId} bevaras dolt och pekar mot ${conflict.canonicalId}.`, 'warning');
      });
      if (migration.seededCount > 0) {
        watchdog.step('runtime.registry.editable-beaches.seeded', `${migration.seededCount} fasta badplatser infördes i det redigerbara registerlagret.`);
      }
      editableBeachRegistry = migration.registry;
      if (!editableBeachRegistryReadOnly) editableBeachRegistryError = '';
      const visible = migration.registry.items.filter((item) => item.hidden !== true);
      watchdog.step('runtime.registry.editable-beaches.validated', `${visible.length} synliga badplatser verifierades i registerschema ${editableBeachApi.SCHEMA_VERSION}.`);
    } catch (error) {
      editableBeachRegistry = null;
      editableBeachRegistryReadOnly = true;
      editableBeachRegistryError = error && error.message ? error.message : 'Badplatsregistret kunde inte verifieras.';
      watchdog.step('runtime.registry.editable-beaches.invalid', `${editableBeachRegistryError} Ingen registerdata har ändrats.`, 'warning');
    }
  }

  function buildEffectivePlaceRegistry() {
    if (!editablePlaceRegistry || !editableBeachRegistry) throw new Error('Den effektiva platslistan kan inte skapas utan verifierade platsregister.');
    const normalPlaces = editablePlaceApi.buildEffectivePlaces(editablePlaceRegistry);
    const effective = editableBeachApi.buildEffectivePlaces(normalPlaces, editableBeachRegistry);
    const fixedCount = effective.filter((item) => item.category !== 'badplats').length;
    const activeBeachCount = effective.filter((item) => item.category === 'badplats' && item.active !== false && item.hidden !== true).length;
    const inactiveBeachCount = effective.filter((item) => item.category === 'badplats' && item.active === false && item.hidden !== true).length;
    const hiddenBeachCount = effective.filter((item) => item.category === 'badplats' && item.hidden === true).length;
    watchdog.step('runtime.registry.effective-places.created', `${fixedCount} vanliga platser och ${activeBeachCount} aktiva badplatser skapades med integrerad geofencedata.`);
    if (hiddenBeachCount > 0) watchdog.step('runtime.registry.effective-places.legacy-aliases', `${hiddenBeachCount} äldre badplats-ID:n bevaras dolt för bakåtkompatibilitet.`);
    if (!placeModelInitialized) {
      jobModel.initializePlaces(effective);
      placeModelInitialized = true;
    } else {
      jobModel.replacePlaces(effective);
    }
    placeItems = jobModel.getPlaceItems();
    watchdog.step('runtime.registry.job-model.initialized', `${placeItems.length} effektiva platser kopplades till uppdragsmodellen; senare registerändringar kan ersätta samma runtime-lista utan omstart.`);
    if (new Set(placeItems.map((item) => item.id)).size !== placeItems.length) throw new Error('Den effektiva platslistan innehåller dubbla stabila ID:n.');
    watchdog.step('runtime.registry.seaweed-truth.validated', 'Havstångsregelsanningen verifierades mot kategori badplats, beach-roll och stabila plats-ID:n.');
  }

  function editableBeachNumber(value) {
    if (value === null || typeof value === 'undefined' || (typeof value === 'string' && !value.trim())) return '';
    return Number.isFinite(Number(value)) ? String(Number(value)) : '';
  }

  function updateEditableBeachGeofenceVisibility() {
    const enabled = byId('beach-registry-geofence-enabled').checked;
    const type = byId('beach-registry-geofence-type').value === 'polygon' ? 'polygon' : 'circle';
    byId('beach-registry-geofence-fields').hidden = !enabled;
    byId('beach-registry-geofence-enabled').setAttribute('aria-expanded', String(enabled));
    byId('beach-registry-circle-fields').hidden = type !== 'circle';
    byId('beach-registry-polygon-fields').hidden = type !== 'polygon';
    byId('beach-registry-radius').required = enabled && type === 'circle';
    byId('beach-registry-polygon-points').required = enabled && type === 'polygon';
    byId('beach-registry-tolerance').required = enabled;
    byId('beach-registry-save-geofence').disabled = !editableBeachRegistry || !editingEditableBeachId;
  }

  function resetBeachGeofenceForm() {
    setGeofenceForm('beach-registry', { enabled: false, type: 'circle', toleranceMeters: 0 });
  }

  function resetEditableBeachEditor() {
    editingEditableBeachId = '';
    byId('beach-registry-edit-id').value = '';
    byId('beach-registry-name').value = '';
    byId('beach-registry-address').value = '';
    renderGeocodingNote('beach-registry-geocoding-note', null);
    resetBeachGeofenceForm();
    byId('beach-registry-submit').textContent = 'Lägg till badplats';
    byId('beach-registry-cancel').hidden = true;
    updateEditableBeachGeofenceVisibility();
  }

  function renderEditableBeachRegistry() {
    const list = byId('beach-registry-list');
    list.replaceChildren();
    const disabled = !editableBeachRegistry || editableBeachRegistryReadOnly;
    byId('beach-registry-form').querySelectorAll('input, select, textarea, button').forEach((element) => {
      element.disabled = disabled;
    });
    if (!editableBeachRegistry) {
      byId('beach-registry-active-count').textContent = '–';
      byId('beach-registry-inactive-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editableBeachRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('beach-registry-status', 'Badplatsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const items = editableBeachRegistry.items
      .filter((item) => item.hidden !== true)
      .slice()
      .sort((a, b) => {
        if (a.active !== b.active) return a.active ? -1 : 1;
        return a.name.localeCompare(b.name, 'sv-SE');
      });
    const activeCount = items.filter((item) => item.active !== false).length;
    const inactiveCount = items.length - activeCount;
    byId('beach-registry-active-count').textContent = String(activeCount);
    byId('beach-registry-inactive-count').textContent = String(inactiveCount);

    if (editableBeachRegistryReadOnly) {
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${editableBeachRegistryError} Badplatserna visas, men kan inte ändras just nu.`;
      list.appendChild(error);
    }

    items.forEach((item) => {
      const card = document.createElement('article');
      card.className = 'registry-card';
      if (item.active === false) card.classList.add('is-inactive');
      card.dataset.beachRegistryId = item.id;

      const header = document.createElement('div');
      header.className = 'registry-card-header';
      const heading = document.createElement('h4');
      heading.textContent = item.name;
      const stateChip = document.createElement('span');
      stateChip.className = `meta-chip${item.active === false ? ' future' : ''}`;
      stateChip.textContent = item.active === false ? 'Inaktiv' : 'Aktiv';
      header.append(heading, stateChip);

      const details = document.createElement('dl');
      details.className = 'registry-detail-list';
      const beachGeocoding = geocodingDisplay(item.geocoding);
      const detailRows = [
        ['Adress / Plus Code', item.addressOrPlusCode || 'Saknas'],
        ['Geokodning', beachGeocoding.label],
        ...(item.geocoding && item.geocoding.status === 'resolved' && item.geocoding.formattedAddress
          ? [['Identifierad plats', item.geocoding.formattedAddress]]
          : []),
        ['Geofence', item.geofence.enabled ? (item.geofence.type === 'circle' ? `Cirkel ${item.geofence.radiusMeters} m` : `Polygon ${item.geofence.polygonPoints.length} punkter`) : 'Avstängd'],
        ['Tolerans', item.geofence.toleranceMeters === null ? 'Ej angiven' : `${item.geofence.toleranceMeters} m`],
        ...(item.geofence.visualLoadingLock ? [['Lastningslås', 'Ja']] : []),
        ...(item.geofence.visualUnloadingLock ? [['Lossningslås', 'Ja']] : []),
        ['Tekniskt ID', item.id]
      ];
      detailRows.forEach(([label, value]) => {
        const wrapper = document.createElement('div');
        const term = document.createElement('dt');
        term.textContent = label;
        const description = document.createElement('dd');
        description.textContent = value;
        wrapper.append(term, description);
        details.appendChild(wrapper);
      });

      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.className = 'secondary-button';
      edit.type = 'button';
      edit.dataset.editBeachRegistry = item.id;
      edit.textContent = 'Redigera';
      const toggle = document.createElement('button');
      toggle.className = item.active === false ? 'secondary-button' : 'danger-button';
      toggle.type = 'button';
      toggle.dataset.toggleBeachRegistry = item.id;
      toggle.textContent = item.active === false ? 'Återaktivera' : 'Inaktivera';
      const remove = document.createElement('button');
      remove.className = 'danger-button';
      remove.type = 'button';
      remove.dataset.removeBeachRegistry = item.id;
      remove.textContent = 'Ta bort';
      actions.append(edit, toggle, remove);
      card.append(header, details, actions);
      list.appendChild(card);
    });
  }

  function persistEditableBeachRegistry(nextRegistry) {
    if (editableBeachRegistryReadOnly) {
      showStatus('beach-registry-status', 'Badplatsregistret kan inte ändras just nu.', true);
      return false;
    }
    editableBeachApi.validateRegistry(nextRegistry);
    const nextDocument = {
      ...settingsDocument,
      [editableBeachApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('beach-registry-status', window.StadslassHost.getLastError() || 'Badplatsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    editableBeachRegistry = nextRegistry;
    editableBeachRegistryError = '';
    watchdog.step('runtime.registry.editable-beaches.saved', `Badplatsregistrets revision ${nextRegistry.revision} sparades atomiskt i inställningslagret.`);
    return true;
  }

  function editableBeachFormValue() {
    return {
      name: byId('beach-registry-name').value,
      addressOrPlusCode: byId('beach-registry-address').value,
      geofence: geofenceFormValue('beach-registry')
    };
  }

  async function applyBeachGeocodingResult(itemId, baseMessage) {
    const current = editableBeachRegistry && editableBeachRegistry.items.find((item) => item.id === itemId);
    if (!current || !current.addressOrPlusCode || current.geocoding.status !== 'pending') {
      showStatus('beach-registry-status', `${baseMessage} Nya platsval använder ändringen nästa gång appen startas.`);
      return;
    }
    watchdog.step('runtime.google.geocoding.beach.started', `Geokodning startades för badplats-ID ${current.id} genom den gemensamma registermetoden utan ny GPS-bevakning.`);
    const outcome = await requestSharedRegistryGeocoding(current, 'beach');
    const geocoding = outcome.geocoding;
    const resultMessage = outcome.isError
      ? `${baseMessage} ${outcome.detail} Badplatsen är sparad och kan rättas eller sparas igen senare.`
      : `${baseMessage} ${outcome.detail} Nya platsval använder ändringen nästa gång appen startas.`;
    const isError = outcome.isError;
    const timestamp = new Date().toISOString();
    const items = editableBeachRegistry.items.slice();
    const latest = items.find((item) => item.id === itemId);
    if (!latest) {
      showStatus('beach-registry-status', `${baseMessage} Geokodningsresultatet kunde inte kopplas till badplatsen.`, true);
      return;
    }
    if (latest.geocoding.status !== 'pending' || latest.geocoding.query !== current.geocoding.query || latest.addressOrPlusCode !== current.addressOrPlusCode) {
      watchdog.step('runtime.google.geocoding.beach.stale-result', `${current.id}: ett äldre geokodningsresultat ignorerades eftersom badplatsen ändrades under anropet.`, 'warning');
      showStatus('beach-registry-status', `${baseMessage} Ett äldre geokodningsresultat ignorerades eftersom badplatsen hade ändrats.`);
      return;
    }
    const updated = editableBeachApi.applyGeocoding(latest, geocoding, items, timestamp);
    const nextItems = items.map((item) => item.id === itemId ? updated : item);
    const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, nextItems, timestamp);
    if (!persistEditableBeachRegistry(nextRegistry)) {
      showStatus('beach-registry-status', `${baseMessage} Badplatsen är sparad, men koordinaterna kunde inte sparas. Spara badplatsen igen senare.`, true);
      return;
    }
    renderEditableBeachRegistry();
    showStatus('beach-registry-status', resultMessage, isError);
  }

  async function saveEditableBeach(event) {
    event.preventDefault();
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) {
      showStatus('beach-registry-status', 'Badplatsregistret är skrivskyddat eftersom det inte kunde verifieras eller sparas.', true);
      return;
    }
    const submitButton = byId('beach-registry-submit');
    submitButton.disabled = true;
    try {
      const items = editableBeachRegistry.items.slice();
      const timestamp = new Date().toISOString();
      let nextItems;
      let savedItem;
      let message;
      if (editingEditableBeachId) {
        const current = items.find((item) => item.id === editingEditableBeachId);
        if (!current) throw new Error('Badplatsen som skulle redigeras saknas.');
        savedItem = editableBeachApi.updateItem(current, editableBeachFormValue(), items, timestamp);
        nextItems = items.map((item) => item.id === current.id ? savedItem : item);
        message = `${savedItem.name} har uppdaterats.`;
      } else {
        savedItem = editableBeachApi.createItem(editableBeachFormValue(), items, timestamp);
        nextItems = items.concat(savedItem);
        message = `${savedItem.name} har lagts till.`;
      }
      const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, nextItems, timestamp);
      if (!persistEditableBeachRegistry(nextRegistry)) return;
      const savedItemId = savedItem.id;
      resetEditableBeachEditor();
      renderEditableBeachRegistry();
      if (savedItem.geocoding.status === 'pending' && savedItem.addressOrPlusCode) {
        showStatus('beach-registry-status', `${message} Koordinater hämtas från Google…`);
        await applyBeachGeocodingResult(savedItemId, message);
      } else {
        showStatus('beach-registry-status', `${message} Nya platsval använder ändringen nästa gång appen startas.`);
      }
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Badplatsen kunde inte sparas.', true);
    } finally {
      submitButton.disabled = !editableBeachRegistry || editableBeachRegistryReadOnly;
    }
  }

  function editEditableBeach(id) {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) return;
    const item = editableBeachRegistry.items.find((candidate) => candidate.id === id && candidate.hidden !== true);
    if (!item) {
      showStatus('beach-registry-status', 'Badplatsen som skulle redigeras saknas.', true);
      return;
    }
    editingEditableBeachId = item.id;
    byId('beach-registry-edit-id').value = item.id;
    byId('beach-registry-name').value = item.name;
    byId('beach-registry-address').value = item.addressOrPlusCode || '';
    renderGeocodingNote('beach-registry-geocoding-note', item.geocoding);
    setGeofenceForm('beach-registry', item.geofence);
    updateEditableBeachGeofenceVisibility();
    byId('beach-registry-submit').textContent = 'Spara ändringar';
    byId('beach-registry-cancel').hidden = false;
    showStatus('beach-registry-status', `Redigerar ${item.name}.`);
    scrollSettingsContentIntoView(byId('beach-registry-form'));
  }

  function saveEditableBeachGeofence() {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly || !editingEditableBeachId) {
      showStatus('beach-registry-status', 'Välj Redigera på en befintlig badplats innan geofence sparas separat.', true);
      return;
    }
    try {
      const items = editableBeachRegistry.items.slice();
      const current = items.find((item) => item.id === editingEditableBeachId);
      if (!current) throw new Error('Badplatsen som skulle få geofence saknas.');
      const timestamp = new Date().toISOString();
      const updated = editableBeachApi.updateGeofence(current, geofenceFormValue('beach-registry'), items, timestamp);
      const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, items.map((item) => item.id === current.id ? updated : item), timestamp);
      if (!persistEditableBeachRegistry(nextRegistry)) return;
      renderEditableBeachRegistry();
      editEditableBeach(updated.id);
      showStatus('beach-registry-status', `${updated.name}: geofence är sparat.`);
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Geofence kunde inte sparas.', true);
    }
  }

  function toggleEditableBeach(id) {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) return;
    try {
      const items = editableBeachRegistry.items.slice();
      const current = items.find((item) => item.id === id && item.hidden !== true);
      if (!current) throw new Error('Badplatsen som skulle ändras saknas.');
      const timestamp = new Date().toISOString();
      const updated = editableBeachApi.setActive(current, current.active === false, items, timestamp);
      const nextItems = items.map((item) => item.id === current.id ? updated : item);
      const nextRegistry = editableBeachApi.withItems(editableBeachRegistry, nextItems, timestamp);
      if (!persistEditableBeachRegistry(nextRegistry)) return;
      if (editingEditableBeachId === current.id) resetEditableBeachEditor();
      renderEditableBeachRegistry();
      showStatus('beach-registry-status', `${updated.name} är nu ${updated.active ? 'aktiv' : 'inaktiv'}. Nya platsval använder ändringen nästa gång appen startas.`);
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Badplatsens status kunde inte ändras.', true);
    }
  }
  function removeEditableBeach(id) {
    if (!editableBeachRegistry || editableBeachRegistryReadOnly) return;
    try {
      const current = editableBeachRegistry.items.find((item) => item.id === id && item.hidden !== true);
      if (!current) throw new Error('Badplatsen som skulle tas bort saknas.');
      if (!window.confirm('Ta bort ' + current.name + '? Badplatsen och dess geofence tas bort. Kopplingar från Jobbtyper och Snabbval rensas. Andra registerposter samt sparade uppdrag och historik behålls.')) return;
      const timestamp = new Date().toISOString();
      const nextRegistry = editableBeachApi.removeFromRegistry(editableBeachRegistry, current, timestamp);
      const nextJobTypes = editableJobTypeRegistry ? editableJobTypeApi.withItems(editableJobTypeRegistry, editableJobTypeRegistry.items.map((item) => ({ ...item, ...(item.defaultDestinationPlaceId === current.id ? { defaultDestinationPlaceId: '' } : {}) })), timestamp) : null;
      const nextQuickChoices = quickChoiceRegistry ? quickChoiceApi.withItems(quickChoiceRegistry, clearQuickChoiceReferences(quickChoiceRegistry.items, current.id), timestamp) : null;
      saveRegistryRemoval(nextJobTypes, null, nextRegistry, nextQuickChoices);
      if (editingEditableBeachId === current.id) resetEditableBeachEditor();
      renderEditableBeachRegistry();
      showStatus('beach-registry-status', current.name + ' och dess kopplingar har tagits bort. Redan sparade uppdrag och historik är oförändrade.');
    } catch (error) {
      showStatus('beach-registry-status', error && error.message ? error.message : 'Badplatsen kunde inte tas bort.', true);
    }
  }


  function effectiveQuickChoiceButtonName(item, status = null) {
    const resolved = status || quickChoiceApi.referenceStatus(item, jobTypeItems, placeItems, isOtherActivityJobType);
    if (item && item.buttonNameCustomized !== true && resolved.jobType && text(resolved.jobType.name)) {
      return text(resolved.jobType.name);
    }
    return text(item && item.buttonName, 'Snabbval');
  }

  function quickChoiceStatus(item) {
    const status = quickChoiceApi.referenceStatus(item, jobTypeItems, placeItems, isOtherActivityJobType);
    const issues = Array.isArray(status.issues) ? status.issues.slice() : [];
    const machineTransport = isMachineTransportJobType(status.jobType);
    // P110: Maskintransport är en generell uppdragsmall. Från och Till väljs
    // först när mallen öppnar Nytt uppdrag och ska därför inte göra snabbvalet
    // ogiltigt.
    if (machineTransport) {
      for (let index = issues.length - 1; index >= 0; index -= 1) {
        if (issues[index] === 'Från-plats saknas eller är inte tillgänglig' || issues[index] === 'Till-plats saknas eller är inte tillgänglig') issues.splice(index, 1);
      }
    }
    if (status.jobType && !status.otherActivity) {
      if (!machineTransport && status.fromPlace && !placeSupportsJobTypeRole(status.fromPlace, status.jobType.id, 'from')) {
        issues.push('Från-platsen är inte kopplad till Jobbtypen under Jobbtyper från');
      }
      if (!machineTransport && status.toPlace && !placeSupportsJobTypeRole(status.toPlace, status.jobType.id, 'destination')) {
        issues.push('Till-platsen är inte kopplad till Jobbtypen under Jobbtyper till');
      }
    }
    return { ...status, machineTransport, valid: issues.length === 0, issues, groupName: machineTransport ? 'Maskintransport' : status.groupName };
  }

  function migrateAtaDefaultsFromV58(registry, timestamp) {
    if (!editableJobTypeRegistry || !registry || !ataRouting) return { registry, jobTypes: editableJobTypeRegistry, changed: false };
    const quickItems = registry.items.map((item) => ({ ...item }));
    const grouped = new Map();
    quickItems.forEach((item) => {
      if (item.ataMigrationV59 === true) return;
      const key = text(item.jobTypeId);
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key).push(item);
    });
    let changed = false;
    let nextTypes = editableJobTypeRegistry.items.map((item) => ({ ...item }));
    nextTypes = nextTypes.map((type) => {
      const group = grouped.get(type.id) || [];
      if (group.length === 0 || (type.ataEnabled === true || type.ataEnabled === false)) return type;
      if (ataRouting.isManualJobType(type)) {
        group.forEach((item) => { item.ataManual = item.ataDefault === true; item.ataMigrationV59 = true; changed = true; });
        return { ...type, ataEnabled: false };
      }
      const values = group.map((item) => item.ataDefault === true);
      const uniform = values.every((value) => value === values[0]);
      if (uniform) {
        group.forEach((item) => { item.ataMigrationV59 = true; changed = true; });
        return { ...type, ataEnabled: values[0] };
      }
      group.forEach((item) => { item.ataNeedsCorrection = true; item.ataLegacyDefault = item.ataDefault === true; item.ataMigrationV59 = true; changed = true; });
      return { ...type, ataEnabled: false };
    });
    // Types without old quick choices get a deliberate ordinary default.
    nextTypes = nextTypes.map((type) => type.ataEnabled === true || type.ataEnabled === false ? type : { ...type, ataEnabled: false });
    if (!changed && JSON.stringify(nextTypes) === JSON.stringify(editableJobTypeRegistry.items)) return { registry, jobTypes: editableJobTypeRegistry, changed: false };
    const nextJobTypes = editableJobTypeApi.withItems(editableJobTypeRegistry, nextTypes, timestamp);
    const nextQuick = quickChoiceApi.withItems(registry, quickItems, timestamp);
    return { registry: nextQuick, jobTypes: nextJobTypes, changed: true };
  }

  function loadQuickChoiceRegistry() {
    const stored = settingsDocument[quickChoiceApi.SETTINGS_KEY];
    try {
      const migration = quickChoiceApi.migrateRegistry(stored, jobTypeItems, new Date().toISOString());
      if (migration.migrated) {
        const nextDocument = {
          ...settingsDocument,
          [quickChoiceApi.SETTINGS_KEY]: migration.registry,
          settingsSchemaVersion: 1,
          settingsUpdatedByPackageVersion: PACKAGE_VERSION
        };
        const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
        if (!saved) throw new Error(window.StadslassHost.getLastError() || 'Snabbvalsregistret kunde inte migreras atomiskt.');
        settingsDocument = nextDocument;
        watchdog.step('runtime.registry.quick-choices.migrated', `Snabbvalsregistret migrerades till schema ${quickChoiceApi.SCHEMA_VERSION}; ${migration.normalizedJobTypeCount || 0} jobbtypsreferenser normaliserades till stabilt register-ID utan att ändra kö, Aktivt jobb eller Historik.`);
      }
      const ataMigration = migrateAtaDefaultsFromV58(migration.registry, new Date().toISOString());
      if (ataMigration.changed) {
        const nextDocument = { ...settingsDocument, [editableJobTypeApi.SETTINGS_KEY]: ataMigration.jobTypes, [quickChoiceApi.SETTINGS_KEY]: ataMigration.registry, settingsSchemaVersion: 1, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
        if (!window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument))) throw new Error(window.StadslassHost.getLastError() || 'ÄTA-migreringen kunde inte sparas atomiskt.');
        settingsDocument = nextDocument;
        editableJobTypeRegistry = ataMigration.jobTypes;
        applyEffectiveJobTypeRegistry(ataMigration.jobTypes.items);
        migration.registry = ataMigration.registry;
        watchdog.step('runtime.ata.v59.migrated', 'Paket 58:s fria snabbvals-ÄTA migrerades säkert till Jobbtyp eller markerades Behöver rättas utan att befintliga uppdrag ändrades.');
      }
      quickChoiceApi.validateRegistry(migration.registry);
      quickChoiceRegistry = migration.registry;
      quickChoiceRegistryError = '';
      watchdog.step('runtime.registry.quick-choices.validated', `${migration.registry.items.length} snabbval verifierades med stabila registerreferenser.`);
    } catch (error) {
      quickChoiceRegistry = null;
      quickChoiceRegistryError = error && error.message ? error.message : 'Snabbvalsregistret kunde inte verifieras.';
      watchdog.step('runtime.registry.quick-choices.invalid', `${quickChoiceRegistryError} Ingen registerdata har ändrats.`, 'warning');
    }
  }

  function persistQuickChoiceRegistry(nextRegistry) {
    quickChoiceApi.validateRegistry(nextRegistry);
    const nextDocument = {
      ...settingsDocument,
      [quickChoiceApi.SETTINGS_KEY]: nextRegistry,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('quick-choice-registry-status', window.StadslassHost.getLastError() || 'Snabbvalsregistret kunde inte sparas.', true);
      return false;
    }
    settingsDocument = nextDocument;
    quickChoiceRegistry = nextRegistry;
    quickChoiceRegistryError = '';
    watchdog.step('runtime.registry.quick-choices.saved', `Snabbvalsregistrets revision ${nextRegistry.revision} sparades atomiskt i inställningslagret.`);
    renderQuickChoiceRegistry();
    renderQuickChoices();
    return true;
  }

  function populateQuickChoicePlaceOptions() {
    const jobTypeId = byId('quick-choice-registry-job-type').value;
    const jobType = findJobTypeById(jobTypeId);
    const routeEnabled = Boolean(jobType && !isOtherActivityJobType(jobType) && !isMachineTransportJobType(jobType));
    const fromPlaces = routeEnabled ? placesForJobType(jobType.id, 'from') : [];
    const destinationPlaces = routeEnabled ? placesForJobType(jobType.id, 'destination') : [];
    const fromSelect = byId('quick-choice-registry-from');
    const destinationSelect = byId('quick-choice-registry-to');
    const returnSelect = byId('quick-choice-registry-return');
    const previousFrom = fromSelect.value;
    const previousDestination = destinationSelect.value;
    const previousReturn = returnSelect.value;
    populateSelect(fromSelect.id, fromPlaces, !routeEnabled ? 'Välj jobbtyp först' : (fromPlaces.length ? 'Välj Från' : 'Ingen Från-plats kopplad'), 'from');
    populateSelect(destinationSelect.id, destinationPlaces, !routeEnabled ? 'Välj jobbtyp först' : (destinationPlaces.length ? 'Välj Till' : 'Ingen Till-plats kopplad'), 'destination');
    populateSelect(returnSelect.id, returnPlaces(), 'Välj Returplats', 'return');
    fromSelect.disabled = !routeEnabled || fromPlaces.length === 0;
    destinationSelect.disabled = !routeEnabled || destinationPlaces.length === 0;
    if (selectContainsValue(fromSelect, previousFrom)) fromSelect.value = previousFrom;
    if (selectContainsValue(destinationSelect, previousDestination)) destinationSelect.value = previousDestination;
    if (selectContainsValue(returnSelect, previousReturn)) returnSelect.value = previousReturn;
  }

  function syncQuickChoiceFormControls(changedMode = '') {
    const jobType = findJobTypeById(byId('quick-choice-registry-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const routeFields = byId('quick-choice-registry-route-fields');
    const from = byId('quick-choice-registry-from');
    const to = byId('quick-choice-registry-to');
    const returnToggle = byId('quick-choice-registry-return-required');
    const returnWrap = byId('quick-choice-registry-return-wrap');
    const returnPlace = byId('quick-choice-registry-return');
    const multiLoad = byId('quick-choice-registry-multi-load');
    routeFields.hidden = otherActivity || machineTransport;
    from.required = !otherActivity && !machineTransport;
    to.required = !otherActivity && !machineTransport;
    if (otherActivity || machineTransport) {
      from.value = '';
      to.value = '';
      returnToggle.checked = false;
      returnPlace.value = '';
      multiLoad.checked = false;
    }
    if (changedMode === 'return' && returnToggle.checked) multiLoad.checked = false;
    if (changedMode === 'multi' && multiLoad.checked) returnToggle.checked = false;
    returnWrap.hidden = otherActivity || machineTransport || !returnToggle.checked;
    if (returnToggle.checked && !returnPlace.value && from.value) returnPlace.value = from.value;
    const ataToggle = byId('quick-choice-registry-ata-default');
    const ataChoice = ataToggle.closest('.choice-row');
    const manual = ataRouting && ataRouting.isManualJobType(jobType);
    const inherited = ataRouting && ataRouting.jobTypeEnabled(jobType);
    ataChoice.hidden = !manual;
    if (!manual) ataToggle.checked = false;
    byId('quick-choice-registry-ata-from-jobtype').hidden = !inherited;
    byId('quick-choice-registry-ata-recipient-panel').hidden = !(manual ? ataToggle.checked : inherited);
    renderAtaRecipientContacts('quick', ataRecipientInput('quick'));
  }

  function resetQuickChoiceEditor() {
    editingQuickChoiceId = '';
    const form = byId('quick-choice-registry-form');
    form.reset();
    populateSelect('quick-choice-registry-job-type', jobTypeItems, 'Välj Jobbtyp');
    populateQuickChoicePlaceOptions();
    byId('quick-choice-registry-edit-id').value = '';
    byId('quick-choice-registry-button-name').dataset.autoSuggested = 'true';
    byId('quick-choice-registry-submit').textContent = 'Lägg till snabbval';
    byId('quick-choice-registry-cancel').hidden = true;
    syncQuickChoiceFormControls();
  }

  function quickChoiceFormValue() {
    const jobType = findJobTypeById(byId('quick-choice-registry-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const returnRequired = !otherActivity && !machineTransport && byId('quick-choice-registry-return-required').checked;
    return {
      buttonName: byId('quick-choice-registry-button-name').value,
      buttonNameCustomized: byId('quick-choice-registry-button-name').dataset.autoSuggested !== 'true',
      jobTypeId: text(jobType && jobType.id),
      jobTypeName: text(jobType && jobType.name),
      fromPlaceId: otherActivity || machineTransport ? '' : byId('quick-choice-registry-from').value,
      toPlaceId: otherActivity || machineTransport ? '' : byId('quick-choice-registry-to').value,
      returnRequired,
      returnPlaceId: returnRequired ? (byId('quick-choice-registry-return').value || byId('quick-choice-registry-from').value) : '',
      multiLoad: !otherActivity && !machineTransport && !returnRequired && byId('quick-choice-registry-multi-load').checked,
      comment: byId('quick-choice-registry-comment').value,
      ataManual: ataRouting && ataRouting.isManualJobType(jobType) ? byId('quick-choice-registry-ata-default').checked : false,
      ataRecipient: ataRecipientInput('quick')
    };
  }

  function renderQuickChoiceRegistry() {
    const list = byId('quick-choice-registry-list');
    if (!list) return;
    list.replaceChildren();
    const disabled = !quickChoiceRegistry;
    byId('quick-choice-registry-form').querySelectorAll('input, select, textarea, button').forEach((element) => {
      element.disabled = disabled;
    });
    if (disabled) {
      byId('quick-choice-registry-count').textContent = '–';
      byId('quick-choice-registry-invalid-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${quickChoiceRegistryError} Registret är skrivskyddat och övriga inställningar är orörda.`;
      list.appendChild(error);
      showStatus('quick-choice-registry-status', 'Snabbvalsregistret kunde inte läsas. Ingen data har skrivits över.', true);
      return;
    }

    const resolved = quickChoiceRegistry.items.map((item) => ({ item, status: quickChoiceStatus(item) }));
    resolved.sort((a, b) => {
      const groupCompare = a.status.groupName.localeCompare(b.status.groupName, 'sv-SE', { sensitivity: 'base' });
      if (groupCompare !== 0) return groupCompare;
      return effectiveQuickChoiceButtonName(a.item, a.status).localeCompare(effectiveQuickChoiceButtonName(b.item, b.status), 'sv-SE', { sensitivity: 'base' });
    });
    byId('quick-choice-registry-count').textContent = String(resolved.length);
    byId('quick-choice-registry-invalid-count').textContent = String(resolved.filter((entry) => !entry.status.valid).length);

    if (resolved.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Snabbvalsregistret är tomt. Lägg till de uppdrag som du använder ofta.';
      list.appendChild(empty);
      return;
    }

    resolved.forEach(({ item, status }) => {
      const card = document.createElement('article');
      card.className = `registry-card${status.valid ? '' : ' is-invalid'}`;
      card.dataset.quickChoiceRegistryId = item.quickChoiceId;
      const heading = document.createElement('h4');
      heading.textContent = effectiveQuickChoiceButtonName(item, status);
      card.appendChild(heading);

      const details = document.createElement('dl');
      details.className = 'registry-detail-list';
      const pairs = [
        ['Jobbtyp', text(status.jobType && status.jobType.name, 'Saknas')],
        ['Från', status.otherActivity ? 'Övrig verksamhet' : (status.machineTransport ? 'Väljs när uppdraget skapas' : text(status.fromPlace && status.fromPlace.name, 'Saknas'))],
        ['Till', status.otherActivity ? 'Ej aktuell' : (status.machineTransport ? 'Väljs när uppdraget skapas' : text(status.toPlace && status.toPlace.name, 'Saknas'))],
        ['Retur', status.machineTransport ? 'Väljs när uppdraget skapas' : (item.returnRequired ? text(status.returnPlace && status.returnPlace.name, 'Saknas') : 'Nej')],
        ['Flerlass', status.machineTransport ? 'Väljs när uppdraget skapas' : (item.multiLoad ? 'Ja' : 'Nej')],
        ['ÄTA', ataRouting && ataRouting.choiceMode(status.jobType, item) ? (ataRouting.isManualJobType(status.jobType) ? 'Ja, manuellt val' : 'Ja, från Jobbtyp') : 'Nej']
      ];
      pairs.forEach(([label, value]) => {
        const row = document.createElement('div');
        const dt = document.createElement('dt');
        const dd = document.createElement('dd');
        dt.textContent = label;
        dd.textContent = value;
        row.append(dt, dd);
        details.appendChild(row);
      });
      card.appendChild(details);
      if (item.comment) {
        const note = document.createElement('p');
        note.className = 'queue-note';
        note.textContent = item.comment;
        card.appendChild(note);
      }
      if (!status.valid) {
        const warning = document.createElement('p');
        warning.className = 'registry-warning';
        warning.textContent = `Behöver rättas: ${status.issues.join('. ')}.`;
        card.appendChild(warning);
      }
      if (item.ataNeedsCorrection === true) {
        const warning = document.createElement('p');
        warning.className = 'registry-warning';
        warning.textContent = 'Behöver rättas: äldre ÄTA-val för samma Jobbtyp var olika. Välj ÄTA-status på Jobbtypen och kontrollera sedan snabbvalet.';
        card.appendChild(warning);
      }
      const actions = document.createElement('div');
      actions.className = 'registry-actions';
      const edit = document.createElement('button');
      edit.type = 'button';
      edit.className = 'secondary-button';
      edit.dataset.editQuickChoice = item.quickChoiceId;
      edit.textContent = 'Redigera';
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'danger-button';
      remove.dataset.removeQuickChoice = item.quickChoiceId;
      remove.textContent = 'Ta bort';
      actions.append(edit, remove);
      card.appendChild(actions);
      list.appendChild(card);
    });
  }

  function saveQuickChoice(event) {
    event.preventDefault();
    if (!quickChoiceRegistry) {
      showStatus('quick-choice-registry-status', 'Snabbvalsregistret är skrivskyddat eftersom det inte kunde verifieras.', true);
      return;
    }
    try {
      const now = new Date().toISOString();
      const items = quickChoiceRegistry.items.slice();
      const current = editingQuickChoiceId ? items.find((item) => item.quickChoiceId === editingQuickChoiceId) : null;
      if (editingQuickChoiceId && !current) throw new Error('Snabbvalet som skulle redigeras finns inte längre.');
      const formValue = quickChoiceFormValue();
      formValue.ataRecipient = ensureAtaRecipientContact(formValue.ataRecipient, 'quick-choice', 'quick-choice-registry-status');
      const nextItem = current
        ? quickChoiceApi.updateItem(current, formValue, items, now)
        : quickChoiceApi.createItem(formValue, items, now);
      const status = quickChoiceStatus(nextItem);
      if (!status.valid) throw new Error(status.issues.join('. '));
      const nextItems = current ? items.map((item) => item.quickChoiceId === current.quickChoiceId ? nextItem : item) : items.concat(nextItem);
      const nextRegistry = quickChoiceApi.withItems(quickChoiceRegistry, nextItems, now);
      if (!persistQuickChoiceRegistry(nextRegistry)) return;
      const message = current ? `${effectiveQuickChoiceButtonName(nextItem, status)} har uppdaterats.` : `${effectiveQuickChoiceButtonName(nextItem, status)} har lagts till.`;
      resetQuickChoiceEditor();
      showStatus('quick-choice-registry-status', message);
    } catch (error) {
      showStatus('quick-choice-registry-status', error && error.message ? error.message : 'Snabbvalet kunde inte sparas.', true);
    }
  }

  function editQuickChoice(id) {
    if (!quickChoiceRegistry) return;
    const item = quickChoiceRegistry.items.find((candidate) => candidate.quickChoiceId === id);
    if (!item) {
      showStatus('quick-choice-registry-status', 'Snabbvalet som skulle redigeras saknas.', true);
      return;
    }
    const status = quickChoiceStatus(item);
    editingQuickChoiceId = item.quickChoiceId;
    byId('quick-choice-registry-edit-id').value = item.quickChoiceId;
    byId('quick-choice-registry-job-type').value = status.jobType ? status.jobType.id : '';
    populateQuickChoicePlaceOptions();
    byId('quick-choice-registry-button-name').value = effectiveQuickChoiceButtonName(item, status);
    byId('quick-choice-registry-button-name').dataset.autoSuggested = item.buttonNameCustomized === true ? 'false' : 'true';
    byId('quick-choice-registry-from').value = status.fromPlace ? status.fromPlace.id : '';
    byId('quick-choice-registry-to').value = status.toPlace ? status.toPlace.id : '';
    byId('quick-choice-registry-return-required').checked = item.returnRequired === true;
    byId('quick-choice-registry-return').value = status.returnPlace ? status.returnPlace.id : (status.fromPlace ? status.fromPlace.id : '');
    byId('quick-choice-registry-multi-load').checked = item.multiLoad === true;
    byId('quick-choice-registry-comment').value = item.comment;
    byId('quick-choice-registry-ata-default').checked = item.ataManual === true;
    writeAtaRecipientInput('quick', item.ataRecipient || null);
    renderAtaRecipientContacts('quick', item.ataRecipient || null);
    syncQuickChoiceFormControls();
    byId('quick-choice-registry-submit').textContent = 'Spara ändringar';
    byId('quick-choice-registry-cancel').hidden = false;
    byId('quick-choice-registry-card').scrollIntoView({ block: 'start' });
    showStatus('quick-choice-registry-status', status.valid ? 'Ändra uppgifterna och tryck Spara ändringar.' : `Rätta snabbvalet: ${status.issues.join('. ')}.` , !status.valid);
  }

  function removeQuickChoice(id) {
    if (!quickChoiceRegistry) return;
    try {
      const current = quickChoiceRegistry.items.find((item) => item.quickChoiceId === id);
      const nextItems = quickChoiceApi.removeItem(id, quickChoiceRegistry.items);
      const nextRegistry = quickChoiceApi.withItems(quickChoiceRegistry, nextItems, new Date().toISOString());
      if (!persistQuickChoiceRegistry(nextRegistry)) return;
      if (editingQuickChoiceId === id) resetQuickChoiceEditor();
      showStatus('quick-choice-registry-status', `${current ? effectiveQuickChoiceButtonName(current, quickChoiceStatus(current)) : 'Snabbvalet'} har tagits bort. Redan skapade uppdrag är oförändrade.`);
    } catch (error) {
      showStatus('quick-choice-registry-status', error && error.message ? error.message : 'Snabbvalet kunde inte tas bort.', true);
    }
  }

  function renderQuickChoices() {
    const container = byId('quick-choice-groups');
    if (!container) return;
    container.replaceChildren();
    clearQuickChoiceFallbackState();
    if (!quickChoiceRegistry) {
      byId('quick-choice-count').textContent = '–';
      const error = document.createElement('div');
      error.className = 'empty-state';
      error.textContent = `${quickChoiceRegistryError} Snabbval kan inte användas förrän registret har rättats.`;
      container.appendChild(error);
      return;
    }
    const resolved = quickChoiceRegistry.items.map((item) => ({ item, status: quickChoiceStatus(item) }));
    byId('quick-choice-count').textContent = String(resolved.length);
    if (resolved.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga snabbval är skapade. Öppna Inställningar → Vanliga åtgärder → Snabbval.';
      container.appendChild(empty);
      return;
    }
    const groups = new Map();
    resolved.forEach((entry) => {
      const key = entry.status.groupName;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(entry);
    });
    Array.from(groups.entries())
      .sort((a, b) => a[0].localeCompare(b[0], 'sv-SE', { sensitivity: 'base' }))
      .forEach(([groupName, entries]) => {
        entries.sort((a, b) => effectiveQuickChoiceButtonName(a.item, a.status).localeCompare(effectiveQuickChoiceButtonName(b.item, b.status), 'sv-SE', { sensitivity: 'base' }));
        const section = document.createElement('section');
        section.className = 'quick-choice-group';
        const heading = document.createElement('h3');
        heading.textContent = groupName;
        const grid = document.createElement('div');
        grid.className = 'quick-choice-button-grid';
        entries.forEach(({ item, status }) => {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = `quick-choice-button${status.valid ? '' : ' is-invalid'}`;
          button.dataset.useQuickChoice = item.quickChoiceId;
          button.disabled = !status.valid;
          const name = document.createElement('strong');
          name.textContent = effectiveQuickChoiceButtonName(item, status);
          const detail = document.createElement('small');
          if (!status.valid) {
            detail.textContent = `Behöver rättas: ${status.issues.join(', ')}`;
          } else if (status.otherActivity) {
            detail.textContent = `${item.ataDefault === true ? 'ÄTA · ' : ''}${item.comment || 'Användarens tidsrapportering'}`;
          } else if (status.machineTransport) {
            detail.textContent = 'Välj maskin, Från och Till';
          } else {
            const route = [];
            if (item.ataDefault === true) route.push('ÄTA');
            route.push(`Till ${status.toPlace.name}`);
            if (item.returnRequired) route.push(`retur ${status.returnPlace.name}`);
            if (item.multiLoad) route.push('flerlass');
            detail.textContent = route.join(' · ');
          }
          button.append(name, detail);
          grid.appendChild(button);
        });
        section.append(heading, grid);
        container.appendChild(section);
      });
  }

  function beginQuickChoiceAction(actionKey) {
    const now = Date.now();
    const key = text(actionKey, 'quick-choice-action');
    if (quickChoiceActionInProgress || (key === quickChoiceLastActionKey && now < quickChoiceActionLockedUntil)) return false;
    quickChoiceActionInProgress = true;
    quickChoiceLastActionKey = key;
    quickChoiceActionLockedUntil = now + PRESS_DELAY_MS;
    return true;
  }

  function endQuickChoiceAction() {
    quickChoiceActionInProgress = false;
  }

  function quickChoiceFallbackVisible() {
    const fallback = byId('quick-choice-queue-fallback');
    return Boolean(fallback && !fallback.hidden);
  }

  function clearQuickChoiceFallbackState(options = {}) {
    pendingQuickChoiceFallbackItem = null;
    pendingQuickChoiceFallbackId = '';
    const fallback = byId('quick-choice-queue-fallback');
    if (fallback) fallback.hidden = true;
    if (options.clearStatus && byId('quick-choice-status')) {
      showStatus('quick-choice-status', text(options.message));
    }
  }

  function refreshActiveJobForQuickChoice(options = {}) {
    if (!isVehicleRole()) return true;
    try {
      const nextDocument = readActiveJobDocument();
      const changed = JSON.stringify(nextDocument) !== JSON.stringify(activeJobDocument);
      activeJobDocument = nextDocument;
      activeJobLoaded = true;
      if (changed) {
        syncActiveJobGpsConsumer();
        syncActiveGeofenceContext();
        if (currentView === 'active') renderActiveJob();
      }
      return true;
    } catch (error) {
      activeJobLoaded = false;
      watchdog.step('runtime.quick-choice.active-job-refresh-failed', error && error.message ? error.message : 'Aktivt jobb kunde inte läsas inför Snabbval.', 'warning');
      if (options.showError !== false) {
        showStatus('quick-choice-status', 'Aktivt jobb kunde inte kontrolleras. Lägg i kö kan fortfarande användas utan att ett aktivt uppdrag skrivs över.', true);
      }
      return false;
    }
  }

  function quickChoiceConflictStatus(id) {
    if (!quickChoiceRegistry || !text(id)) return null;
    const item = quickChoiceRegistry.items.find((candidate) => candidate.quickChoiceId === id);
    if (!item) return null;
    const status = quickChoiceStatus(item);
    return status.valid ? { item, status } : null;
  }

  function activeJobBlocksQuickChoice(status) {
    if (!activeJobExists()) return false;
    const mayStartBesideOtherActivity = isOtherActivity(activeJobDocument)
      && !status.otherActivity
      && activeJobDocument.status !== 'completing';
    return !mayStartBesideOtherActivity;
  }

  function invalidateQuickChoiceFallbackForActiveJobChange() {
    const hadConflict = Boolean(pendingQuickChoiceFallbackItem) || quickChoiceFallbackVisible();
    if (!hadConflict) return;
    clearQuickChoiceFallbackState();
    if (currentView === 'quickChoices') {
      showStatus('quick-choice-status', 'Aktivt jobb har ändrats. Tryck på snabbvalet igen för att använda den aktuella statusen.');
    }
  }

  function selectedQuickChoiceMode() {
    const checked = document.querySelector('input[name="quickChoiceMode"]:checked');
    return checked && checked.value === 'direct' ? 'direct' : 'queue';
  }

  function buildQuickChoiceQueueItem(item, status) {
    const now = new Date().toISOString();
    const jobId = createLocalId('job');
    const returnPlace = item.returnRequired ? status.returnPlace : null;
    return normalizeJobRecord({
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: jobId,
      jobId,
      status: 'queued',
      source: isVehicleRole() ? 'manual-vehicle-received' : 'manual-mobile-planning',
      jobTypeId: status.jobType.id,
      jobTypeName: status.jobType.name,
      fromPlaceId: status.otherActivity ? '' : status.fromPlace.id,
      fromPlaceName: status.otherActivity ? '' : status.fromPlace.name,
      destinationPlaceId: status.otherActivity ? '' : status.toPlace.id,
      destinationPlaceName: status.otherActivity ? '' : status.toPlace.name,
      returnPlaceId: returnPlace ? returnPlace.id : '',
      returnPlaceName: returnPlace ? returnPlace.name : '',
      returnRequired: item.returnRequired === true,
      multiLoad: status.otherActivity || item.returnRequired ? false : item.multiLoad === true,
      material: status.otherActivity ? {} : deriveMaterial(status.jobType.id, status.fromPlace.id, status.toPlace.id),
      plannedDate: '',
      plannedTime: '',
      note: item.comment,
      ata: ataRouting.jobAtaSnapshot({
        enabled: ataRouting.choiceMode(status.jobType, item),
        source: ataRouting.isManualJobType(status.jobType) ? 'manual-job-choice' : 'quick-choice',
        quickChoiceId: item.quickChoiceId,
        recipient: ataRouting.recipientPriority(status.jobType, item, 'quick-choice', now),
        timestamp: now
      }),
      createdAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: {
        createdRole: text(hostInfo.role),
        createdRoleLabel: text(hostInfo.roleLabel),
        createdDeviceId: text(hostInfo.deviceId),
        modelVersion: JOB_MODEL_VERSION
      }
    }, 'job');
  }

  function appendQuickChoiceToQueue(queueItem, message) {
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('quick-choice-status', 'Kön måste kunna läsas innan uppdraget kan skapas.', true);
      return false;
    }
    const saved = persistQueue([...queueDocument, queueItem], message);
    if (saved) showStatus('quick-choice-status', message);
    return saved;
  }

  function openMachineTransportQuickChoice(item, status) {
    resetQueueForm();
    activateView('queue');
    byId('job-type').value = status.jobType.id;
    refreshPlaceFormsForJobType('');
    refreshMachineSelect('queue');
    byId('job-note').value = item.comment;
    byId('job-ata').checked = ataRouting && ataRouting.choiceMode(status.jobType, item);
    writeAtaRecipientInput('queue', ataRouting && ataRouting.recipientPriority(status.jobType, item, 'quick-choice', new Date().toISOString()));
    renderAtaRecipientContacts('queue', ataRecipientInput('queue'));
    syncJobModeControls('queue');
    updateMaterialPanel('');
    byId('queue-form-heading').scrollIntoView({ block: 'start' });
    showStatus('queue-form-status', 'Välj maskin, Från och Till. Retur eller flerlass väljs vid behov.', false);
  }

  async function useQuickChoice(id) {
    if (!quickChoiceRegistry || !canUseQueue() || !beginQuickChoiceAction(`use:${text(id)}`)) return;
    try {
      const item = quickChoiceRegistry.items.find((candidate) => candidate.quickChoiceId === id);
      if (!item) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Snabbvalet finns inte längre.', true);
        renderQuickChoices();
        return;
      }
      const status = quickChoiceStatus(item);
      if (!status.valid) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', `Snabbvalet måste rättas i Inställningar: ${status.issues.join('. ')}.`, true);
        renderQuickChoices();
        return;
      }
      if (status.machineTransport) {
        clearQuickChoiceFallbackState();
        openMachineTransportQuickChoice(item, status);
        return;
      }
      const queueItem = buildQuickChoiceQueueItem(item, status);
      const name = effectiveQuickChoiceButtonName(item, status);
      if (selectedQuickChoiceMode() === 'queue') {
        clearQuickChoiceFallbackState();
        appendQuickChoiceToQueue(queueItem, `${name} är skapat som ett vanligt uppdrag och lagt i kön.`);
        return;
      }
      if (!isVehicleRole()) {
        byId('quick-choice-mode-queue').checked = true;
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Starta direkt är endast tillgängligt på 189 / Surfplatta. Välj snabbvalet igen för att lägga det i planeringskön.', true);
        return;
      }
      if (!refreshActiveJobForQuickChoice()) return;
      if (activeJobBlocksQuickChoice(status)) {
        pendingQuickChoiceFallbackItem = queueItem;
        pendingQuickChoiceFallbackId = item.quickChoiceId;
        byId('quick-choice-queue-fallback').hidden = false;
        showStatus('quick-choice-status', 'Ett vanligt aktivt uppdrag pågår. Inget nytt uppdrag har startats och det aktiva uppdraget är oförändrat.', true);
        return;
      }
      clearQuickChoiceFallbackState();
      if (!appendQuickChoiceToQueue(queueItem, `${name} förbereds för direkt start som ett vanligt uppdrag.`)) return;
      if (!refreshActiveJobForQuickChoice()) {
        showStatus('quick-choice-status', `${name} ligger kvar i kön eftersom Aktivt jobb inte kunde kontrolleras på nytt.`, true);
        return;
      }
      if (activeJobBlocksQuickChoice(status)) {
        showStatus('quick-choice-status', `${name} ligger kvar i kön eftersom ett aktivt uppdrag hann ändras före direktstart.`, true);
        return;
      }
      await startQueueItem(queueItem.id);
      if (activeJobLoaded && activeJobExists() && text(activeJobDocument.jobId) === text(queueItem.jobId)) return;
      showStatus('quick-choice-status', `${name} kunde inte startas direkt och ligger kvar i kön.`, true);
    } finally {
      endQuickChoiceAction();
    }
  }

  function queuePendingQuickChoiceFallback() {
    if (!pendingQuickChoiceFallbackItem || !beginQuickChoiceAction('fallback-queue')) return;
    try {
      const pending = pendingQuickChoiceFallbackItem;
      const resolved = quickChoiceConflictStatus(pendingQuickChoiceFallbackId);
      if (!resolved) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Snabbvalet eller dess uppgifter har ändrats. Tryck på snabbvalet igen.', true);
        return;
      }
      const activeReadable = refreshActiveJobForQuickChoice({ showError: false });
      if (activeReadable && !activeJobBlocksQuickChoice(resolved.status)) {
        clearQuickChoiceFallbackState();
        showStatus('quick-choice-status', 'Aktivt jobb har ändrats. Tryck på snabbvalet igen för att använda den aktuella statusen.');
        return;
      }
      clearQuickChoiceFallbackState();
      appendQuickChoiceToQueue(pending, 'Uppdraget är skapat som ett vanligt uppdrag och lagt i kön. Det aktiva uppdraget är oförändrat.');
    } finally {
      endQuickChoiceAction();
    }
  }

  function cancelQuickChoiceFallback() {
    clearQuickChoiceFallbackState();
    showStatus('quick-choice-status', 'Åtgärden avbröts. Inget uppdrag skapades.');
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return '';
    }
    const parts = value.split('-').map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return new Intl.DateTimeFormat('sv-SE', { year: 'numeric', month: 'short', day: 'numeric' }).format(date);
  }

  function formatTimestamp(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return 'Saknas';
    }
    return new Intl.DateTimeFormat('sv-SE', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    }).format(date);
  }

  function createLocalId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(random);
    } else {
      random[0] = Math.floor(Math.random() * 0xffffffff);
      random[1] = Math.floor(Math.random() * 0xffffffff);
    }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function displayQueueItem(item, index) {
    const source = normalizeJobRecord(isPlainObject(item) ? item : {}, `queue-display-${index}`);
    return {
      id: text(source.id, `legacy-${index}`),
      jobId: text(source.jobId, text(source.id, `legacy-${index}`)),
      jobTypeId: text(source.jobTypeId),
      jobType: text(source.jobTypeName, text(source.jobType, 'Uppdrag')),
      otherActivity: isOtherActivity(source),
      fromPlaceId: text(source.fromPlaceId),
      from: text(source.fromPlaceName, text(source.from, 'Från saknas')),
      destinationPlaceId: text(source.destinationPlaceId),
      destination: text(source.destinationPlaceName, text(source.destination, 'Till saknas')),
      returnPlaceId: text(source.returnPlaceId),
      returnPlaceName: text(source.returnPlaceName),
      returnRequired: source.returnRequired === true || Boolean(text(source.returnPlaceId)),
      material: isPlainObject(source.material) ? source.material : {},
      note: text(source.note),
      plannedDate: text(source.plannedDate),
      plannedTime: text(source.plannedTime),
      source: text(source.source),
      multiLoad: source.multiLoad === true,
      modelVersion: Number(source.jobModelVersion) || 1,
      pausedFromActive: source.pausedFromActive === true && text(source.status) === 'paused',
      pausedPhase: text(source.phase),
      ataEnabled: ataApi.isEnabled(source),
      ataRecipient: source.ata && source.ata.recipient && source.ata.recipient.email ? source.ata.recipient : null
    };
  }

  function queueMetaChip(label, extraClass = '') {
    const chip = document.createElement('span');
    chip.className = `meta-chip${extraClass ? ` ${extraClass}` : ''}`;
    chip.textContent = label;
    return chip;
  }

  function queueItemIndexById(id) {
    return queueDocument.findIndex((candidate, index) => displayQueueItem(candidate, index).id === id);
  }

  function queueItemById(id) {
    const index = queueItemIndexById(id);
    return index >= 0 ? { index, raw: queueDocument[index], display: displayQueueItem(queueDocument[index], index) } : null;
  }

  function activeJobMatchesQueueItem(id) {
    return activeJobLoaded && activeJobExists() && text(activeJobDocument.sourceQueueItemId) === id;
  }

  function renderQueue() {
    const list = byId('queue-list');
    list.replaceChildren();
    byId('queue-count').textContent = String(queueDocument.length);

    if (queueDocument.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Kön är tom.';
      list.appendChild(empty);
      return;
    }

    const today = localDateKey(new Date());
    queueDocument.forEach((rawItem, index) => {
      const item = displayQueueItem(rawItem, index);
      const card = document.createElement('article');
      card.className = 'queue-card';
      card.dataset.queueId = item.id;

      const header = document.createElement('div');
      header.className = 'queue-card-header';
      const heading = document.createElement('h3');
      heading.textContent = item.jobType;
      header.appendChild(heading);
      card.appendChild(header);

      const route = document.createElement('p');
      route.className = 'queue-route';
      route.textContent = item.otherActivity ? 'Användarens tidsrapportering' : `${item.from} → ${item.destination}`;
      card.appendChild(route);

      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      if (item.ataEnabled) meta.appendChild(queueMetaChip('ÄTA', 'ata-chip'));
      if (item.plannedDate) {
        meta.appendChild(queueMetaChip(formatDate(item.plannedDate) || item.plannedDate));
        if (item.plannedDate > today) {
          meta.appendChild(queueMetaChip('Framtida uppdrag', 'future'));
        }
      } else {
        meta.appendChild(queueMetaChip('Datum saknas'));
      }
      if (item.plannedTime) {
        meta.appendChild(queueMetaChip(`Kl. ${item.plannedTime}`));
      }
      if (item.pausedFromActive) meta.appendChild(queueMetaChip(`Pausat · ${phaseLabel(item.pausedPhase)}`, 'paused-chip'));
      if (item.returnRequired) meta.appendChild(queueMetaChip(`Retur: ${item.returnPlaceName || item.from}`));
      if (item.multiLoad) meta.appendChild(queueMetaChip('Flerlass', 'model-chip'));
      const materialText = [text(item.material.code), text(item.material.facilityPlaceName)].filter(Boolean).join(' · ');
      if (materialText) meta.appendChild(queueMetaChip(`Mtrl: ${materialText}`));
      const outgoing = isMobileRole() ? latestOutgoingForJob(item.jobId) : null;
      const syncCommand = isMobileRole() ? latestV63CommandForJob(item.jobId) : null;
      if (syncCommand) {
        const labels = { waiting_ledger: 'Ej skickat', waiting_send: 'Väntar på bekräftelse', failed_retryable: 'Syncfel', applied: 'Mottaget', 'already-present': 'Mottaget', already_present: 'Mottaget', rejected: 'Syncfel', sync_conflict: 'Syncfel' };
        const activeMirror = syncV63MirrorEntry('sync-v63-mirror-active');
        const mirrored = activeMirror && activeMirror.value && activeMirror.value.activeJob;
        const completed = activeMirror && activeMirror.value && activeMirror.value.lastCompletedJob;
        const liveStatus = mirrored && text(mirrored.sourceQueueItemId || mirrored.jobId) === item.jobId ? 'Startat'
          : completed && text(completed.sourceQueueItemId || completed.jobId) === item.jobId ? 'Klart' : '';
        const label = liveStatus || labels[text(syncCommand.state)] || 'Väntar på bekräftelse';
        meta.appendChild(queueMetaChip(label, label === 'Syncfel' ? 'transfer-state-prepared' : 'transfer-state-acknowledged'));
      }
      if (outgoing) {
        meta.appendChild(queueMetaChip(outgoing.state === 'acknowledged' ? 'Mottaget på 189' : 'Överföring förberedd', outgoing.state === 'acknowledged' ? 'transfer-state-acknowledged' : 'transfer-state-prepared'));
      }
      if (isVehicleRole() && isPlainObject(rawItem.sync) && text(rawItem.sync.transferId)) {
        meta.appendChild(queueMetaChip('Överförd från Mobil', 'transfer-state-acknowledged'));
      }
      card.appendChild(meta);
      if (item.ataEnabled && item.ataRecipient) {
        const recipientLabel = ataNotificationApi.recipientQueueLabel(item.ataRecipient);
        if (recipientLabel) {
          const recipient = document.createElement('p');
          recipient.className = 'field-help';
          recipient.textContent = recipientLabel;
          card.appendChild(recipient);
        }
      }
      if (item.note) {
        const note = document.createElement('p');
        note.className = 'queue-note';
        note.textContent = item.note;
        card.appendChild(note);
      }

      if (isMobileRole()) {
        const transferButton = document.createElement('button');
        transferButton.type = 'button';
        transferButton.className = 'primary-button queue-start-button';
        transferButton.dataset.prepareQueueTransfer = item.id;
        transferButton.textContent = syncCommand ? 'Syncstatus' : (outgoing ? 'Visa överföring' : (syncV63OperationallyEnabled() ? 'Skicka till 189' : 'Förbered överföring till 189'));
        card.appendChild(transferButton);
      }

      if (isVehicleRole()) {
        const startButton = document.createElement('button');
        startButton.type = 'button';
        startButton.className = 'primary-button queue-start-button';
        startButton.dataset.startQueueItem = item.id;
        if (activeJobMatchesQueueItem(item.id)) {
          startButton.textContent = 'Slutför flytt till Aktivt jobb';
        } else if (activeJobLoaded && activeJobExists() && !(isOtherActivity(activeJobDocument) && !item.otherActivity && activeJobDocument.status !== 'completing')) {
          startButton.textContent = 'Aktivt jobb pågår';
          startButton.disabled = true;
        } else if (activeJobLoaded && isOtherActivity(activeJobDocument) && !item.otherActivity) {
          startButton.textContent = item.pausedFromActive ? 'Fortsätt – ÖV pausas automatiskt' : 'Starta – ÖV pausas automatiskt';
        } else {
          startButton.textContent = item.pausedFromActive ? 'Fortsätt uppdrag' : 'Starta som Aktivt jobb';
        }
        card.appendChild(startButton);
      }

      const editButton = document.createElement('button');
      editButton.type = 'button';
      editButton.className = 'secondary-button queue-edit-button';
      editButton.dataset.editQueueItem = item.id;
      editButton.textContent = 'Redigera uppdrag';
      card.appendChild(editButton);

      if (pendingQueueDeleteId === item.id) {
        const confirm = document.createElement('div');
        confirm.className = 'inline-confirm confirm-actions';
        const message = document.createElement('p');
        message.textContent = `Ta bort ${item.jobType}: ${item.otherActivity ? 'användarens tidsrapportering' : `${item.from} → ${item.destination}`} från kön? Aktivt jobb och Historik påverkas inte.`;
        const accept = document.createElement('button');
        accept.type = 'button';
        accept.className = 'danger-button is-solid';
        accept.dataset.confirmQueueDelete = item.id;
        accept.textContent = 'Bekräfta borttagning';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.dataset.cancelQueueDelete = item.id;
        cancel.textContent = 'Avbryt';
        confirm.append(message, accept, cancel);
        card.appendChild(confirm);
      } else {
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'danger-button';
        remove.dataset.requestQueueDelete = item.id;
        remove.textContent = 'Ta bort från kö';
        card.appendChild(remove);
      }
      list.appendChild(card);
    });
  }

  function loadQueueIfNeeded() {
    if (!canUseQueue()) {
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (queueLoaded) {
      return;
    }
    try {
      queueDocument = readQueueDocument();
      queueLoaded = true;
      renderQueue();
      showStatus('queue-load-status', '');
    } catch (error) {
      watchdog.step('runtime.store.queue.invalid', error.message || 'Kön kunde inte läsas.', 'warning');
      showStatus('queue-load-status', error.message || 'Kön kunde inte läsas.', true);
    }
  }

  function persistQueue(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('queue-form-status', window.StadslassHost.getLastError() || 'Kön kunde inte sparas.', true);
      return false;
    }
    queueDocument = nextDocument;
    queueLoaded = true;
    pendingQueueDeleteId = '';
    renderQueue();
    syncV63PublishQueue(nextDocument);
    showStatus('queue-form-status', successMessage);
    return true;
  }

  function syncJobModeControls(scope, changedMode = '') {
    const prefix = scope === 'active' ? 'active-job-' : 'job-';
    const otherActivity = isOtherActivityJobType(byId(`${prefix}type`).value);
    const machineTransport = isMachineTransportJobType(byId(`${prefix}type`).value);
    const transportFields = byId(`${prefix}transport-fields`);
    const returnToggle = byId(`${prefix}return-required`);
    const multiToggle = byId(`${prefix}multi-load`);
    const returnWrap = byId(`${prefix}return-wrap`);
    const returnSelect = byId(`${prefix}return`);
    const fromSelect = byId(`${prefix}from`);
    const destinationSelect = byId(`${prefix}destination`);
    transportFields.hidden = otherActivity;
    refreshMachineSelect(scope);
    fromSelect.required = !otherActivity;
    destinationSelect.required = !otherActivity;
    if (otherActivity) {
      fromSelect.value = '';
      destinationSelect.value = '';
      returnSelect.value = '';
      returnToggle.checked = false;
      multiToggle.checked = false;
    }
    if (machineTransport) {
      const materialPanel = byId(`${prefix === 'active-job-' ? 'active-' : 'job-'}material-panel`);
      if (materialPanel) materialPanel.hidden = true;
    }
    if (changedMode === 'return' && returnToggle.checked) multiToggle.checked = false;
    if (changedMode === 'multi' && multiToggle.checked) returnToggle.checked = false;
    returnWrap.hidden = otherActivity || !returnToggle.checked;
    if (returnToggle.checked && !returnSelect.value && fromSelect.value && selectContainsValue(returnSelect, fromSelect.value)) returnSelect.value = fromSelect.value;
    syncTemporaryPlacePanels(scope);
    syncAtaForm(scope, false);
  }

  function resetQueueForm() {
    editingQueueId = '';
    byId('queue-form').reset();
    resetTemporaryPlaceForm('queue');
    refreshPlaceFormsForJobType('');
    byId('queue-form-heading').textContent = 'Lägg till planerat uppdrag';
    byId('queue-submit-button').textContent = 'Lägg i planeringskö';
    byId('queue-cancel-edit').hidden = true;
    clearAtaRecipient('queue');
    syncJobModeControls('queue');
    syncAtaForm('queue', true);
    updateMaterialPanel('');
    syncQueueFormVisibility();
  }

  function renderMachineRegistry() {
    const list = byId('machine-registry-list'); if (!list) return;
    const workshop = byId('machine-registry-workshop');
    const previous = workshop.value; workshop.replaceChildren();
    const none = document.createElement('option'); none.value=''; none.textContent='Ingen verkstad'; workshop.appendChild(none);
    jobModel.getPlaceItems().forEach((place) => { const option=document.createElement('option'); option.value=place.id; option.textContent=place.name; workshop.appendChild(option); });
    if (selectContainsValue(workshop, previous)) workshop.value=previous;
    list.replaceChildren();
    normalizedMachineItems().forEach((machine) => {
      const card=document.createElement('article'); card.className='registry-card';
      const heading=document.createElement('h4'); heading.textContent=machine.name; card.appendChild(heading);
      const detail=document.createElement('p'); const place=findPlaceById(machine.workshopPlaceId); detail.textContent=[place ? `Verkstad: ${place.name}` : '', Number.isFinite(machine.weight) ? `Vikt: ${machine.weight} ton` : ''].filter(Boolean).join(' · ') || 'Ingen verkstad eller vikt angiven.'; card.appendChild(detail);
      const edit=document.createElement('button'); edit.type='button'; edit.className='secondary-button'; edit.textContent='Redigera'; edit.dataset.machineEdit=machine.id;
      const remove=document.createElement('button'); remove.type='button'; remove.className='danger-button'; remove.textContent='Ta bort'; remove.dataset.machineRemove=machine.id; card.append(edit,remove); list.appendChild(card);
    });
  }

  function saveMachineRegistry(event) {
    event.preventDefault();
    try {
      const id=text(byId('machine-registry-edit-id').value) || createLocalId('machine');
      const name=text(byId('machine-registry-name').value); if (!name) throw new Error('Skriv ett maskinnamn.');
      const rawWeight=text(byId('machine-registry-weight').value); const weight=rawWeight === '' ? null : Number(rawWeight.replace(',', '.'));
      if (weight !== null && (!Number.isFinite(weight) || weight < 0)) throw new Error('Maskinvikt måste vara ett positivt tal eller tomt.');
      const item={id,name,workshopPlaceId:text(byId('machine-registry-workshop').value),weight,updatedAt:new Date().toISOString()};
      const prior=normalizedMachineItems(); const existing=prior.find((candidate)=>candidate.id===id);
      const machines=existing ? prior.map((candidate)=>candidate.id===id?{...candidate,...item}:candidate) : prior.concat(item);
      const next={...settingsDocument,machines,settingsUpdatedByPackageVersion:PACKAGE_VERSION};
      if (!window.StadslassHost.writeStore(SETTINGS_STORE,JSON.stringify(next))) throw new Error(window.StadslassHost.getLastError() || 'Maskinregistret kunde inte sparas.');
      settingsDocument=next; byId('machine-registry-form').reset(); byId('machine-registry-edit-id').value=''; byId('machine-registry-cancel').hidden=true; renderMachineRegistry(); refreshMachineSelect('queue'); refreshMachineSelect('active'); showStatus('machine-registry-status', existing?'Maskinen är uppdaterad.':'Maskinen är sparad.');
    } catch(error) { showStatus('machine-registry-status', error.message || 'Maskinen kunde inte sparas.',true); }
  }

  function handleMachineRegistryAction(event) {
    const button=event.target.closest('button'); if (!button) return; const id=text(button.dataset.machineEdit || button.dataset.machineRemove); if (!id) return;
    const machine=normalizedMachineItems().find((item)=>item.id===id); if (!machine) return;
    if (button.dataset.machineRemove) {
      const next={...settingsDocument,machines:normalizedMachineItems().filter((item)=>item.id!==id),settingsUpdatedByPackageVersion:PACKAGE_VERSION};
      if (window.StadslassHost.writeStore(SETTINGS_STORE,JSON.stringify(next))) { settingsDocument=next; renderMachineRegistry(); refreshMachineSelect('queue'); refreshMachineSelect('active'); showStatus('machine-registry-status','Maskinen är borttagen. Sparade uppdrag behåller sin maskinbild.'); }
      return;
    }
    byId('machine-registry-edit-id').value=machine.id; byId('machine-registry-name').value=machine.name; byId('machine-registry-workshop').value=machine.workshopPlaceId; byId('machine-registry-weight').value=Number.isFinite(machine.weight)?String(machine.weight):''; byId('machine-registry-cancel').hidden=false;
  }

  function editQueueItem(id) {
    if (!canUseQueue() || !queueLoaded) {
      showStatus('queue-form-status', 'Öppna kön innan du redigerar ett uppdrag.', true);
      return;
    }
    const selected = queueItemById(id);
    if (!selected) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    if (isMobileRole()) {
      if (!loadSyncOutboxIfNeeded()) {
        showStatus('queue-form-status', 'Överföringsstatusen kunde inte kontrolleras. Uppdraget har inte öppnats för redigering.', true);
        return;
      }
      if (latestOutgoingForJob(selected.display.jobId)) {
        showStatus('queue-form-status', 'Uppdraget har redan förberetts eller kvitterats för överföring och kan därför inte redigeras. Överföringstexten ska fortsätta motsvara uppdraget som skickades.', true);
        return;
      }
    }
    const item = selected.display;
    editingQueueId = item.id;
    byId('job-type').value = item.jobTypeId;
    refreshPlaceFormsForJobType('');
    refreshMachineSelect('queue');
    byId('job-machine').value = text(selected.raw.machine && selected.raw.machine.id);
    byId('job-from').value = item.fromPlaceId;
    byId('job-destination').value = item.destinationPlaceId;
    byId('job-return').value = item.returnPlaceId;
    byId('job-return-required').checked = item.returnRequired;
    byId('job-multi-load').checked = item.multiLoad;
    loadTemporaryPlaceForm('queue', selected.raw);
    syncJobModeControls('queue');
    byId('job-note').value = item.note;
    byId('job-ata').checked = ataApi.isEnabled(selected.raw);
    writeAtaRecipientInput('queue', selected.raw.ata && selected.raw.ata.recipient);
    renderAtaRecipientContacts('queue', selected.raw.ata && selected.raw.ata.recipient);
    byId('planned-date').value = item.plannedDate;
    byId('planned-time').value = item.plannedTime;
    byId('queue-form-heading').textContent = 'Redigera köuppdrag';
    byId('queue-submit-button').textContent = 'Spara ändringar';
    byId('queue-cancel-edit').hidden = false;
    updateMaterialPanel('');
    syncQueueFormVisibility();
    byId('queue-form-heading').scrollIntoView({ block: 'start' });
    const routeNeedsCorrection = !isOtherActivityJobType(item.jobTypeId)
      && (!selectContainsValue(byId('job-from'), item.fromPlaceId) || !selectContainsValue(byId('job-destination'), item.destinationPlaceId));
    showStatus('queue-form-status', routeNeedsCorrection
      ? 'Uppdragets tidigare Från eller Till kan inte längre användas med jobbtypen. Välj giltiga platser innan du sparar eller startar.'
      : 'Ändra uppgifterna och tryck Spara ändringar.', routeNeedsCorrection);
  }

  function cancelQueueEdit() {
    if (!editingQueueId) return;
    resetQueueForm();
    showStatus('queue-form-status', 'Redigeringen avbröts. Kön är oförändrad.');
  }

  function createQueueItem(event) {
    event.preventDefault();
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (isVehicleRole() && !editingQueueId) {
      showStatus('queue-load-status', '189:s operativa kö tar emot uppdrag från Mobil och befintliga köuppdrag kan redigeras.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('queue-form-status', 'Kön måste kunna läsas innan ett uppdrag kan sparas.', true);
      return;
    }
    const jobType = findJobTypeById(byId('job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const machine = machineTransport ? machineSnapshot(byId('job-machine').value) : null;
    const fromPlace = otherActivity ? null : resolveFormPlaceSelection('queue', 'from');
    const destinationPlace = otherActivity ? null : resolveFormPlaceSelection('queue', 'destination');
    const returnRequired = !otherActivity && byId('job-return-required').checked;
    const selectedReturnPlace = returnRequired ? findPlaceById(byId('job-return').value) : null;
    const returnPlace = returnRequired ? (selectedReturnPlace || fromPlace) : null;
    if (!jobType || (!otherActivity && (!fromPlace || !destinationPlace))) {
      showStatus('queue-form-status', otherActivity ? 'Välj jobbtyp.' : 'Välj jobbtyp, Från och Till.', true);
      return;
    }
    if (!otherActivity && !machineTransport
      && ((fromPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(fromPlace, jobType.id, 'from'))
        || (destinationPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(destinationPlace, jobType.id, 'destination')))) {
      showStatus('queue-form-status', 'Från eller Till är inte kopplad till vald Jobbtyp i Platsregistret. Välj en giltig kombination.', true);
      return;
    }
    const now = new Date().toISOString();
    const selected = editingQueueId ? queueItemById(editingQueueId) : null;
    if (editingQueueId && !selected) {
      showStatus('queue-form-status', 'Köposten som skulle redigeras finns inte längre. Kön är oförändrad.', true);
      return;
    }
    const jobId = selected ? selected.display.jobId : createLocalId('job');
    const material = otherActivity ? {} : deriveMaterialForSelections(jobType.id, fromPlace, destinationPlace);
    const temporaryPlaces = otherActivity ? {} : collectTemporaryPlaces('queue');
    const rawItem = {
      ...(selected ? selected.raw : {}),
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: selected ? selected.display.id : jobId,
      jobId,
      status: 'queued',
      source: isVehicleRole() ? 'manual-vehicle-received' : 'manual-mobile-planning',
      jobTypeId: jobType.id,
      jobTypeName: jobType.name,
      fromPlaceId: text(fromPlace && fromPlace.id),
      fromPlaceName: text(fromPlace && fromPlace.name),
      destinationPlaceId: text(destinationPlace && destinationPlace.id),
      destinationPlaceName: text(destinationPlace && destinationPlace.name),
      returnPlaceId: returnPlace ? text(returnPlace.id) : '',
      returnPlaceName: returnPlace ? text(returnPlace.name) : '',
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : byId('job-multi-load').checked,
      ...(machineTransport ? { machine, machineLoads: machine ? [{ loadNumber: 1, machine }] : [] } : {}),
      material,
      plannedDate: text(byId('planned-date').value),
      plannedTime: text(byId('planned-time').value),
      note: text(byId('job-note').value),
      createdAt: selected ? text(selected.raw.createdAt, now) : now,
      createdByPackageVersion: selected ? selected.raw.createdByPackageVersion : PACKAGE_VERSION,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: { ...(selected && isPlainObject(selected.raw.metadata) ? selected.raw.metadata : {}), createdRole: text(selected && selected.raw.metadata && selected.raw.metadata.createdRole, text(hostInfo.role)), createdRoleLabel: text(selected && selected.raw.metadata && selected.raw.metadata.createdRoleLabel, text(hostInfo.roleLabel)), createdDeviceId: text(selected && selected.raw.metadata && selected.raw.metadata.createdDeviceId, text(hostInfo.deviceId)), modelVersion: JOB_MODEL_VERSION }
    };
    if (Object.keys(temporaryPlaces).length) rawItem.temporaryPlaces = temporaryPlaces;
    else delete rawItem.temporaryPlaces;
    const recipient = ensureAtaRecipientContact(ataRecipientInput('queue'), editingQueueId ? 'queue-edit' : 'manual-job-choice', 'queue-form-status');
    const ataSnapshot = ataRouting.jobAtaSnapshot({
      enabled: byId('job-ata').checked,
      source: editingQueueId ? 'queue-edit' : (ataRouting.isManualJobType(jobType) ? 'manual-job-choice' : (ataRouting.jobTypeEnabled(jobType) ? 'job-type' : 'manual-job-choice')),
      recipient: recipient || (byId('job-ata').checked ? ataRouting.defaultRecipient(jobType) : null),
      timestamp: now,
      existing: selected && selected.raw.ata
    });
    if (ataSnapshot) rawItem.ata = ataSnapshot;
    else delete rawItem.ata;
    const item = normalizeJobRecord(rawItem, 'job');
    const successMessage = selected ? 'Ändringarna är sparade i den lokala kön.' : (isVehicleRole() ? 'Uppdraget är sparat i 189:s lokala operativa kö.' : 'Uppdraget är sparat i Mobilens lokala planeringskö.');
    const nextDocument = selected ? queueDocument.map((entry, index) => index === selected.index ? item : entry) : [...queueDocument, item];
    if (persistQueue(nextDocument, successMessage)) {
      const previousSync = selected && isMobileRole() ? latestV63CommandForJob(selected.display.jobId) : null;
      if (selected && previousSync && ['applied', 'already_present'].includes(text(previousSync.state)) && syncV63OperationallyEnabled()) {
        syncV63CreatePlanningCommand(item, 'edit', Math.max(1, Number(selected.raw.jobRevision) || 1));
      }
      resetQueueForm();
      showStatus('queue-form-status', successMessage);
    }
  }

  function requestQueueDelete(id) {
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded || queueItemIndexById(id) < 0) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    pendingQueueDeleteId = id;
    renderQueue();
    revealInlineControl('#queue-list .inline-confirm', previousScrollY);
    showStatus('queue-form-status', 'Bekräfta borttagningen eller avbryt.');
  }

  function cancelQueueDelete(id) {
    if (pendingQueueDeleteId !== id) {
      return;
    }
    const previousScrollY = currentScrollY();
    pendingQueueDeleteId = '';
    renderQueue();
    preserveScrollAfterRender(previousScrollY);
    showStatus('queue-form-status', 'Borttagningen avbröts. Kön är oförändrad.');
  }

  function confirmQueueDelete(id) {
    if (!canUseQueue() || pendingQueueDeleteId !== id) {
      showStatus('queue-form-status', 'Borttagningen kunde inte bekräftas och kön är oförändrad.', true);
      return;
    }
    const index = queueItemIndexById(id);
    if (index < 0) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    if (activeJobMatchesQueueItem(id)) {
      pendingQueueDeleteId = '';
      renderQueue();
      showStatus('queue-form-status', 'Köposten hör ihop med det aktiva jobbet och kan inte tas bort här. Aktivt jobb och kön är oförändrade.', true);
      return;
    }
    const selected = queueItemById(id);
    const syncCommand = isMobileRole() && selected ? latestV63CommandForJob(selected.display.jobId) : null;
    if (syncCommand && ['applied', 'already_present'].includes(text(syncCommand.state)) && syncV63OperationallyEnabled()) {
      pendingQueueDeleteId = '';
      renderQueue();
      syncV63CreatePlanningCommand(selected.raw, 'delete', Math.max(1, Number(selected.raw.jobRevision) || 1));
      return;
    }
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    persistQueue(nextDocument, 'Uppdraget är borttaget från kön.');
  }

  function removeQueueItemByIndex(index, successMessage) {
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    return persistQueue(nextDocument, successMessage);
  }

  async function startQueueItem(id) {
    if (!isVehicleRole()) {
      showStatus('queue-form-status', 'Endast 189 / Surfplatta får starta ett uppdrag från den operativa kön.', true);
      return;
    }
    if (!queueLoaded) {
      loadQueueIfNeeded();
    }
    const selected = queueItemById(id);
    if (!queueLoaded || !selected) {
      showStatus('queue-form-status', 'Uppdraget finns inte längre i kön.', true);
      return;
    }
    if (!activeJobLoaded) {
      loadActiveJobIfNeeded();
    }
    if (!activeJobLoaded) {
      showStatus('queue-form-status', 'Aktivt jobb måste kunna kontrolleras innan uppdraget startas.', true);
      return;
    }

    const item = selected.display;
    const now = new Date().toISOString();
    let otherActivityToPark = null;
    if (activeJobExists()) {
      if (text(activeJobDocument.sourceQueueItemId) === id) {
        if (removeQueueItemByIndex(selected.index, 'Köposten togs bort. Uppdraget var redan säkert sparat som Aktivt jobb.')) {
          activateView('active');
          showStatus('active-load-status', 'Uppdraget är aktivt och den kvarvarande köposten har städats bort.');
        }
      } else if (isOtherActivity(activeJobDocument) && !item.otherActivity && activeJobDocument.status !== 'completing') {
        otherActivityToPark = pauseOtherActivityAutomatically(activeJobDocument, now, item.jobId);
      } else {
        renderQueue();
        showStatus('queue-form-status', 'Ett annat aktivt jobb pågår. Köuppdraget har inte ändrats.', true);
        return;
      }
      if (!otherActivityToPark) return;
    }

    if (activeJobStartInProgress) {
      showStatus('queue-form-status', 'Startpositionen fastställs redan för ett uppdrag.', true);
      return;
    }
    activeJobStartInProgress = true;
    const queueFromPlace = item.otherActivity ? null : resolveJobPlace(selected.raw, 'from');
    if (!item.otherActivity && initialPhaseNeedsGps(queueFromPlace)) {
      showStatus('queue-form-status', 'Appen fastställer startpositionen innan uppdraget startas.');
    }
    let queueInitialPhase;
    try {
      queueInitialPhase = item.otherActivity
        ? { phase: phaseService.PHASES.OTHER_ACTIVITY, source: 'queue-start', reason: 'other_activity_started_from_queue' }
        : await determineInitialPhaseForPlace(queueFromPlace);
    } finally {
      activeJobStartInProgress = false;
    }
    if (activeJobExists() && !otherActivityToPark) {
      showStatus('queue-form-status', 'Ett annat aktivt jobb blev tillgängligt medan startpositionen hämtades. Köuppdraget är oförändrat.', true);
      return;
    }

    let nextActiveJob;
    if (item.pausedFromActive) {
      const {
        parkedOtherActivity: _staleParkedActivity,
        sourceQueueSnapshot: _previousQueueSnapshot,
        ...pausedSnapshot
      } = selected.raw;
      const pausedFrom = text(pausedSnapshot.pausedAt);
      const pausePeriods = Array.isArray(pausedSnapshot.pausePeriods) ? pausedSnapshot.pausePeriods.filter(isPlainObject) : [];
      const completedPause = pausedFrom ? { from: pausedFrom, to: now, mode: 'queued' } : null;
      const completedPauseMs = completedPause ? Math.max(0, new Date(now).getTime() - new Date(pausedFrom).getTime()) : 0;
      const resumedSegments = resumeWorkSegment(pausedSnapshot, now);
      nextActiveJob = normalizeJobRecord({
        ...pausedSnapshot,
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: item.jobId,
        jobId: item.jobId,
        status: 'active',
        pausedAt: '',
        pausedFromActive: false,
        resumedFromQueueAt: now,
        sourceQueueItemId: item.id,
        sourceQueueSnapshot: pausedSnapshot,
        ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
        pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
        pausedTotalMs: (Number(pausedSnapshot.pausedTotalMs) || 0) + completedPauseMs,
        workSegments: resumedSegments,
        continuationCount: Math.max(0, resumedSegments.length - 1),
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: appendActiveEvent(pausedSnapshot, 'job_resumed', now, 'queue-resume', { fromPausedQueue: true })
      }, 'active');
    } else {
      nextActiveJob = normalizeJobRecord({
        ...selected.raw,
        schemaVersion: 2,
        jobModelVersion: JOB_MODEL_VERSION,
        id: item.jobId,
        jobId: item.jobId,
        status: 'active',
        phase: queueInitialPhase.phase,
        source: 'vehicle-queue',
        sourceQueueItemId: item.id,
        sourceQueueSnapshot: selected.raw,
        returnRequired: item.otherActivity ? false : item.returnRequired === true,
        multiLoad: item.otherActivity ? false : item.multiLoad === true,
        ...(item.otherActivity ? {} : {
          currentLoadNumber: 1,
          loadCycles: [{ loadNumber: 1, loadingStartedAt: queueInitialPhase.phase === phaseService.PHASES.LOADING ? now : '', outcome: 'open' }]
        }),
        ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
        startedAt: now,
        workSegments: [{ segmentNumber: 1, startedAt: now, endedAt: '', endReason: '', note: text(item.note) }],
        continuationCount: 0,
        updatedAt: now,
        createdByPackageVersion: PACKAGE_VERSION,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: [{ type: item.otherActivity ? 'other_activity_started_from_queue' : 'job_started_from_queue', at: now, source: 'vehicle-queue', packageVersion: PACKAGE_VERSION }]
      }, 'active');
      nextActiveJob = phaseService.initializeRecord(nextActiveJob, queueInitialPhase.phase, now, queueInitialPhase.reason, queueInitialPhase.source);
    }

    const activeSaveMessage = item.pausedFromActive
      ? (otherActivityToPark ? 'ÖV pausades automatiskt och det pausade uppdraget fortsätter från sparad fas.' : 'Det pausade uppdraget fortsätter från sparad fas.')
      : (otherActivityToPark ? 'ÖV pausades automatiskt och köuppdraget sparades som Aktivt jobb.' : 'Köuppdraget sparades först som Aktivt jobb.');
    if (!persistActiveJob(nextActiveJob, activeSaveMessage)) {
      showStatus('queue-form-status', 'Aktivt jobb kunde inte sparas. Köposten är oförändrad.', true);
      return;
    }

    if (!removeQueueItemByIndex(selected.index, 'Uppdraget flyttades från 189:s operativa kö till Aktivt jobb.')) {
      renderQueue();
      showStatus('queue-form-status', 'Aktivt jobb är säkert sparat, men köposten kunde inte tas bort. Tryck på startknappen igen för att slutföra flytten.', true);
      return;
    }

    activateView('active');
    showStatus('active-load-status', item.pausedFromActive
      ? (otherActivityToPark ? 'Det pausade uppdraget fortsätter från sparad fas. ÖV är säkert automatiskt pausad bakom uppdraget.' : 'Det pausade uppdraget fortsätter från sparad fas.')
      : (otherActivityToPark ? 'ÖV är säkert automatiskt pausad bakom uppdraget.' : ''));
  }

  function loadSyncOutboxIfNeeded() {
    if (syncOutboxLoaded) return true;
    try {
      const loadedOutbox = readSyncOutboxDocument();
      if (!DRIFT_SYNC_ENABLED) {
        syncOutboxDocument = loadedOutbox;
        syncOutboxLoaded = true;
        syncDiagnosticObserve('sync-outbox-readonly-preserved', { recordsRead: loadedOutbox.length, result: 'operational_sync_disabled' });
      } else {
        const migration = syncServiceApi && typeof syncServiceApi.migrateOutbox === 'function' ? syncServiceApi.migrateOutbox(loadedOutbox) : { entries: loadedOutbox, changed: false, moved: 0 };
        syncOutboxDocument = migration.entries;
        syncOutboxLoaded = true;
        if (migration.changed) {
          if (typeof window.StadslassHost.acknowledgeSyncResult === 'function') loadedOutbox.filter((entry) => entry && entry.kind === 'sync-v63-request' && syncServiceApi.terminal(entry.state)).forEach((entry) => { try { window.StadslassHost.acknowledgeSyncResult(text(entry.requestId)); } catch (_) {} });
          if (!window.StadslassHost.writeStore(SYNC_OUTBOX_STORE, JSON.stringify(syncOutboxDocument))) throw new Error('Terminalhistoriken kunde inte skiljas från den aktiva synkkön.');
          syncV63UpdateSettings({ terminalMigrationV69At: new Date().toISOString(), terminalMigrationV69Moved: migration.moved });
          syncDiagnosticObserve('sync-terminal-migration', { moved: migration.moved, retained: syncOutboxDocument.length });
        }
      }
      renderSyncRoleView();
      showStatus('sync-load-status', '');
      return true;
    } catch (error) {
      watchdog.step('runtime.store.syncOutbox.invalid', error.message || 'Synkutkö kunde inte läsas.', 'warning');
      showStatus('sync-load-status', 'Överföringarna kunde inte läsas.', true);
      return false;
    }
  }

  function persistSyncOutbox(nextDocument, statusElementId, successMessage) {
    const saved = window.StadslassHost.writeStore(SYNC_OUTBOX_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus(statusElementId, window.StadslassHost.getLastError() || 'Överföringen kunde inte sparas.', true);
      return false;
    }
    syncOutboxDocument = nextDocument;
    syncOutboxLoaded = true;
    renderSyncRoleView();
    if (queueLoaded) renderQueue();
    showStatus(statusElementId, successMessage);
    return true;
  }

  function transferEntries() {
    return syncOutboxDocument.filter((entry) => isPlainObject(entry) && entry.kind === 'queue-transfer' && entry.direction === 'outgoing');
  }

  function receiptEntries() {
    return syncOutboxDocument.filter((entry) => isPlainObject(entry) && entry.kind === 'queue-receipt' && entry.direction === 'outgoing');
  }

  function latestOutgoingForJob(jobId) {
    if (!syncOutboxLoaded) return null;
    return transferEntries()
      .filter((entry) => Array.isArray(entry.jobIds) && entry.jobIds.includes(jobId))
      .sort((a, b) => text(b.updatedAt).localeCompare(text(a.updatedAt)))[0] || null;
  }

  function transferJobSnapshot(rawItem, fallback) {
    const item = normalizeJobRecord(isPlainObject(rawItem) ? rawItem : {}, fallback);
    return normalizeJobRecord({
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: stableJobId(item, fallback),
      jobId: stableJobId(item, fallback),
      status: 'queued',
      source: 'mobile-controlled-transfer',
      jobTypeId: text(item.jobTypeId),
      jobTypeName: text(item.jobTypeName),
      fromPlaceId: text(item.fromPlaceId),
      fromPlaceName: text(item.fromPlaceName),
      destinationPlaceId: text(item.destinationPlaceId),
      destinationPlaceName: text(item.destinationPlaceName),
      returnPlaceId: text(item.returnPlaceId),
      returnPlaceName: text(item.returnPlaceName),
      returnRequired: item.returnRequired === true,
      multiLoad: item.multiLoad === true,
      material: isPlainObject(item.material) ? item.material : {},
      plannedDate: text(item.plannedDate),
      plannedTime: text(item.plannedTime),
      note: text(item.note),
      createdAt: text(item.createdAt),
      metadata: {
        createdRole: text(item.metadata && item.metadata.createdRole, 'mobile'),
        createdRoleLabel: text(item.metadata && item.metadata.createdRoleLabel, 'Mobil'),
        createdDeviceId: text(item.metadata && item.metadata.createdDeviceId, text(hostInfo.deviceId)),
        modelVersion: JOB_MODEL_VERSION
      }
    }, fallback);
  }

  function renderSyncRoleView() {
    if (!hostInfo) return;
    const mobilePanel = byId('sync-mobile-panel');
    const vehiclePanel = byId('sync-vehicle-panel');
    mobilePanel.hidden = !isMobileRole();
    vehiclePanel.hidden = !isVehicleRole();
    byId('sync-count').textContent = String(isMobileRole() ? transferEntries().length : receiptEntries().length);
    if (isMobileRole()) renderSyncOutbox();
    renderSyncV63();
  }

  function renderSyncOutbox() {
    const list = byId('sync-outbox-list');
    list.replaceChildren();
    const entries = transferEntries().sort((a, b) => text(b.createdAt).localeCompare(text(a.createdAt)));
    if (entries.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga överföringar är förberedda. Öppna planeringskön och välj ett uppdrag.';
      list.appendChild(empty);
      return;
    }
    entries.forEach((entry) => {
      const card = document.createElement('article');
      card.className = 'queue-card sync-outbox-card';
      const heading = document.createElement('h3');
      heading.textContent = entry.state === 'acknowledged' ? 'Mottaget på 189' : 'Förberedd för 189';
      card.appendChild(heading);
      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      meta.appendChild(queueMetaChip(formatTimestamp(entry.createdAt)));
      meta.appendChild(queueMetaChip(`${Array.isArray(entry.jobIds) ? entry.jobIds.length : 0} uppdrag`));
      meta.appendChild(queueMetaChip(entry.state === 'acknowledged' ? 'Kvitterad' : 'Väntar på kvitto', entry.state === 'acknowledged' ? 'transfer-state-acknowledged' : 'transfer-state-prepared'));
      card.appendChild(meta);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'secondary-button';
      button.dataset.showTransferEntry = text(entry.id);
      button.textContent = 'Visa överföringstext';
      card.appendChild(button);
      list.appendChild(card);
    });
  }

  function showTransferEntry(entry) {
    if (!entry || !text(entry.payloadText)) {
      showStatus('sync-export-status', 'Överföringstexten saknas.', true);
      return;
    }
    byId('sync-export-card').hidden = false;
    byId('sync-export-text').value = entry.payloadText;
    byId('sync-export-summary').textContent = entry.state === 'acknowledged'
      ? `Överföring ${entry.transferId} är kvitterad som mottagen på 189.`
      : `Överföring ${entry.transferId} väntar på import och mottagningskvitto.`;
    showStatus('sync-export-status', 'Texten är redo att kopieras och föras till 189.');
    byId('sync-export-card').scrollIntoView({ block: 'start' });
  }

  async function copyTextareaValue(textareaId, statusId) {
    const textarea = byId(textareaId);
    const value = textarea.value;
    if (!value) {
      showStatus(statusId, 'Det finns ingen text att kopiera.', true);
      return;
    }
    try {
      if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') throw new Error('Urklipps-API saknas.');
      await navigator.clipboard.writeText(value);
      showStatus(statusId, 'Texten är kopierad.');
    } catch (_) {
      textarea.focus();
      textarea.select();
      textarea.setSelectionRange(0, value.length);
      showStatus(statusId, 'Texten är markerad. Välj Kopiera i enhetens meny.');
    }
  }

  function prepareQueueTransfer(id) {
    if (!isMobileRole()) {
      showStatus('queue-form-status', 'Endast Mobil kan förbereda en planeringsöverföring.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    const selected = queueItemById(id);
    if (!selected || !loadSyncOutboxIfNeeded()) {
      showStatus('queue-form-status', 'Uppdraget eller överföringsinformationen kunde inte läsas.', true);
      return;
    }
    const existing = latestOutgoingForJob(selected.display.jobId);
    const existingSync = latestV63CommandForJob(selected.display.jobId);
    if (existingSync) {
      openSyncStatus();
      return;
    }
    if (syncV63OperationallyEnabled()) {
      syncV63CreatePlanningCommand(transferJobSnapshot(selected.raw, selected.display.jobId), 'create', 0);
      return;
    }
    if (existing) {
      openSyncStatus();
      showTransferEntry(existing);
      return;
    }
    try {
      const createdAt = new Date().toISOString();
      const transferId = createLocalId('transfer');
      const result = syncProtocol.createTransfer({
        transferId,
        createdAt,
        packageVersion: PACKAGE_VERSION,
        sourceRoleLabel: text(hostInfo.roleLabel, 'Mobil'),
        sourceDeviceId: text(hostInfo.deviceId),
        jobs: [transferJobSnapshot(selected.raw, selected.display.jobId)]
      });
      const entry = {
        id: `out-${transferId}`,
        schemaVersion: 1,
        kind: 'queue-transfer',
        direction: 'outgoing',
        state: 'prepared',
        transferId,
        jobIds: result.envelope.jobs.map((job) => text(job.jobId)),
        createdAt,
        updatedAt: createdAt,
        payloadText: result.text,
        payloadChecksum: result.envelope.checksum,
        sourceDeviceId: text(hostInfo.deviceId),
        targetRole: 'vehicle_189',
        packageVersion: PACKAGE_VERSION
      };
      if (!persistSyncOutbox([...syncOutboxDocument, entry], 'queue-form-status', 'Överföringen är förberedd.')) return;
      watchdog.step('runtime.sync.transfer.prepared', 'Mobil förberedde en kontrollerad kööverföring.');
      openSyncStatus();
      showTransferEntry(entry);
    } catch (error) {
      showStatus('queue-form-status', error.message || 'Överföringen kunde inte skapas.', true);
    }
  }

  function validateInboundTransfer() {
    if (!isVehicleRole()) {
      showStatus('sync-import-status', 'Endast 189 får importera planeringsöverföringar.', true);
      return;
    }
    validatedInboundTransfer = null;
    byId('sync-import-preview').hidden = true;
    try {
      const envelope = syncProtocol.parseTransfer(byId('sync-transfer-input').value);
      const normalizedJobs = envelope.jobs.map((job, index) => normalizeJobRecord(job, `transfer-${envelope.transferId}-${index}`));
      if (normalizedJobs.some((job) => !text(job.jobId) || !findJobTypeById(job.jobTypeId) || !findPlaceById(job.fromPlaceId) || !findPlaceById(job.destinationPlaceId))) {
        throw new Error('Ett uppdrag saknar jobbtyp, Från eller Till.');
      }
      const previousScrollY = currentScrollY();
      validatedInboundTransfer = { envelope, jobs: normalizedJobs };
      renderInboundTransferPreview();
      byId('sync-import-preview').hidden = false;
      revealInlineControl('#sync-import-preview .inline-confirm', previousScrollY);
      showStatus('sync-import-status', 'Överföringen är validerad. Ingen ködata har ändrats ännu.');
      watchdog.step('runtime.sync.transfer.validated', '189 validerade en kontrollerad kööverföring utan att skriva ködata.');
    } catch (error) {
      watchdog.step('runtime.sync.transfer.rejected', error.message || 'Överföringen avvisades.', 'warning');
      showStatus('sync-import-status', error.message || 'Överföringen kunde inte valideras.', true);
    }
  }

  function renderInboundTransferPreview() {
    const container = byId('sync-preview-content');
    container.replaceChildren();
    if (!validatedInboundTransfer) return;
    const summary = document.createElement('p');
    summary.className = 'section-intro';
    summary.textContent = `Överföring ${validatedInboundTransfer.envelope.transferId} från Mobil innehåller ${validatedInboundTransfer.jobs.length} uppdrag.`;
    container.appendChild(summary);
    validatedInboundTransfer.jobs.forEach((job) => {
      const card = document.createElement('div');
      card.className = 'sync-preview-job';
      const heading = document.createElement('strong');
      heading.textContent = text(job.jobTypeName, 'Uppdrag');
      const route = document.createElement('span');
      route.textContent = `${text(job.fromPlaceName, 'Från saknas')} → ${text(job.destinationPlaceName, 'Till saknas')}`;
      card.append(heading, route);
      container.appendChild(card);
    });
  }

  function cancelInboundTransfer() {
    const previousScrollY = currentScrollY();
    validatedInboundTransfer = null;
    byId('sync-import-preview').hidden = true;
    preserveScrollAfterRender(previousScrollY);
    showStatus('sync-import-status', 'Importen avbröts. Den operativa kön är oförändrad.');
  }

  function createReceiptResult(envelope, status) {
    const now = new Date().toISOString();
    return syncProtocol.createReceipt({
      receiptId: createLocalId('receipt'),
      transferId: envelope.transferId,
      receivedAt: now,
      packageVersion: PACKAGE_VERSION,
      status,
      receivedByDeviceId: text(hostInfo.deviceId),
      targetDeviceId: text(envelope.source && envelope.source.deviceId),
      jobIds: envelope.jobs.map((job) => text(job.jobId))
    });
  }

  function showReceiptResult(result, statusText) {
    byId('sync-receipt-card').hidden = false;
    byId('sync-receipt-output').value = result.text;
    byId('sync-receipt-summary').textContent = statusText;
    showStatus('sync-receipt-copy-status', 'Kvittot är redo att kopieras tillbaka till Mobil.');
    byId('sync-receipt-card').scrollIntoView({ block: 'start' });
  }

  function confirmInboundTransfer() {
    if (!isVehicleRole() || !validatedInboundTransfer) {
      showStatus('sync-import-status', 'Det finns ingen validerad överföring att importera.', true);
      return;
    }
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('sync-import-status', 'Den operativa kön kunde inte läsas. Ingen import har gjorts.', true);
      return;
    }
    const { envelope, jobs } = validatedInboundTransfer;
    const existingIds = new Set(queueDocument.map((item, index) => displayQueueItem(item, index).jobId));
    let newJobs = jobs.filter((job) => !existingIds.has(text(job.jobId))).map((job) => normalizeJobRecord({
      ...job,
      id: text(job.jobId),
      jobId: text(job.jobId),
      status: 'queued',
      source: 'mobile-controlled-transfer',
      receivedAt: new Date().toISOString(),
      receivedByPackageVersion: PACKAGE_VERSION,
      sync: {
        protocol: envelope.protocol,
        transferId: envelope.transferId,
        sourceDeviceId: text(envelope.source.deviceId),
        importedByDeviceId: text(hostInfo.deviceId)
      },
      metadata: {
        ...(isPlainObject(job.metadata) ? job.metadata : {}),
        transferredFromRole: 'mobile',
        transferredFromDeviceId: text(envelope.source.deviceId),
        importedByRole: 'vehicle_189',
        importedByDeviceId: text(hostInfo.deviceId)
      }
    }, `import-${envelope.transferId}`));

    // Import may enrich only the shared local address book. The transferred
    // job snapshot itself remains the incoming snapshot, including its name.
    let importedSettings = ataNotificationSettings();
    let importedContactChanged = false;
    newJobs = newJobs.map((job) => {
      const recipient = job.ata && ataRouting.normalizeRecipient({ ...(job.ata.recipient || {}), source: 'syncimport' }, 'syncimport');
      if (!recipient || recipient.invalid) {
        return recipient && recipient.invalid ? { ...job, sync: { ...(job.sync || {}), recipientImportStatus: 'invalid-recipient-not-added' } } : job;
      }
      const incoming = ataNotificationApi.applyIncoming(importedSettings, { name: recipient.name, email: recipient.email });
      importedSettings = incoming.settings;
      importedContactChanged = importedContactChanged || incoming.created;
      return { ...job, ata: { ...job.ata, recipient: { ...recipient, contactId: incoming.contactId, source: 'syncimport' } } };
    });
    if (importedContactChanged && !persistAtaNotificationSettings(importedSettings, 'sync-import-status', 'Saknad ÄTA-mottagare är sparad i den lokala adressboken.')) return;

    if (newJobs.length > 0) {
      const nextQueue = [...queueDocument, ...newJobs];
      const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextQueue));
      if (!saved) {
        showStatus('sync-import-status', window.StadslassHost.getLastError() || 'Den operativa kön kunde inte sparas. Ingen import har gjorts.', true);
        return;
      }
      queueDocument = nextQueue;
      queueLoaded = true;
      renderQueue();
    }

    const receiptStatus = newJobs.length === 0 ? 'already-present' : 'accepted';
    let result;
    try {
      result = createReceiptResult(envelope, receiptStatus);
    } catch (error) {
      showStatus('sync-import-status', `Uppdraget är säkert sparat i kön, men kvittot kunde inte skapas: ${error.message}`, true);
      validatedInboundTransfer = null;
      byId('sync-import-preview').hidden = true;
      return;
    }
    if (!loadSyncOutboxIfNeeded()) {
      showReceiptResult(result, 'Uppdraget är sparat i den operativa kön. Kvittot kan kopieras nu.');
    } else {
      const now = new Date().toISOString();
      const receiptEntry = {
        id: `receipt-${result.envelope.receiptId}`,
        schemaVersion: 1,
        kind: 'queue-receipt',
        direction: 'outgoing',
        state: 'prepared',
        transferId: envelope.transferId,
        receiptId: result.envelope.receiptId,
        jobIds: result.envelope.jobIds,
        createdAt: now,
        updatedAt: now,
        payloadText: result.text,
        payloadChecksum: result.envelope.checksum,
        sourceDeviceId: text(hostInfo.deviceId),
        targetDeviceId: text(envelope.source.deviceId),
        packageVersion: PACKAGE_VERSION
      };
      const saved = window.StadslassHost.writeStore(SYNC_OUTBOX_STORE, JSON.stringify([...syncOutboxDocument, receiptEntry]));
      if (saved) {
        syncOutboxDocument = [...syncOutboxDocument, receiptEntry];
        syncOutboxLoaded = true;
        renderSyncRoleView();
      }
      showReceiptResult(result, newJobs.length > 0
        ? `${newJobs.length} uppdrag importerades till 189:s operativa kö.`
        : 'Uppdragen fanns redan i den operativa kön. Inga dubbletter skapades.');
      if (!saved) showStatus('sync-receipt-copy-status', 'Uppdraget är sparat och kvittot kan kopieras, men kvittot kunde inte sparas i överföringslistan.', true);
    }
    watchdog.step('runtime.sync.transfer.imported', newJobs.length > 0 ? 'Validerad överföring importerades till 189:s operativa kö.' : 'Överföringen var redan importerad; dubblett blockerades och nytt kvitto skapades.');
    validatedInboundTransfer = null;
    byId('sync-import-preview').hidden = true;
    showStatus('sync-import-status', newJobs.length > 0 ? 'Importen är klar.' : 'Ingen dubblett skapades. Ett nytt kvitto är klart.');
  }

  function registerReceiptOnMobile() {
    if (!isMobileRole()) {
      showStatus('sync-receipt-status', 'Endast Mobil kan registrera mottagningskvitto.', true);
      return;
    }
    if (!loadSyncOutboxIfNeeded()) return;
    try {
      const receipt = syncProtocol.parseReceipt(byId('sync-receipt-input').value);
      if (text(receipt.target.deviceId) && text(receipt.target.deviceId) !== text(hostInfo.deviceId)) throw new Error('Kvittot är adresserat till en annan Mobil-enhet.');
      const index = syncOutboxDocument.findIndex((entry) => entry.kind === 'queue-transfer' && entry.transferId === receipt.transferId);
      if (index < 0) throw new Error('Den motsvarande överföringen finns inte längre på mobilen.');
      const entry = syncOutboxDocument[index];
      const expected = new Set(Array.isArray(entry.jobIds) ? entry.jobIds : []);
      if (receipt.jobIds.some((jobId) => !expected.has(jobId))) throw new Error('Kvittot stämmer inte med den skickade överföringen.');
      const next = [...syncOutboxDocument];
      next[index] = {
        ...entry,
        state: 'acknowledged',
        updatedAt: new Date().toISOString(),
        acknowledgedAt: receipt.receivedAt,
        receiptId: receipt.receiptId,
        receiptStatus: receipt.status,
        receivedByDeviceId: text(receipt.source.deviceId),
        receiptChecksum: receipt.checksum
      };
      if (!persistSyncOutbox(next, 'sync-receipt-status', 'Överföringen är mottagen och kvitterad av 189. Planeringsuppdraget ligger kvar tills du själv tar bort det.')) return;
      byId('sync-receipt-input').value = '';
      watchdog.step('runtime.sync.receipt.acknowledged', 'Mobil registrerade ett giltigt mottagningskvitto från 189.');
    } catch (error) {
      watchdog.step('runtime.sync.receipt.rejected', error.message || 'Kvittot avvisades.', 'warning');
      showStatus('sync-receipt-status', error.message || 'Kvittot kunde inte registreras.', true);
    }
  }

  function activeJobExists() {
    return isPlainObject(activeJobDocument) && Boolean(text(activeJobDocument.id));
  }

  function activeEvents(documentValue) {
    return Array.isArray(documentValue.events) ? documentValue.events.filter(isPlainObject) : [];
  }

  function activeWorkSegments(documentValue = activeJobDocument) {
    const stored = Array.isArray(documentValue.workSegments) ? documentValue.workSegments.filter(isPlainObject) : [];
    if (stored.length > 0) return stored;
    const startedAt = text(documentValue.startedAt);
    return startedAt ? [{ segmentNumber: 1, startedAt, endedAt: '', endReason: '', note: text(documentValue.note) }] : [];
  }

  function closeOpenWorkSegment(documentValue, endedAt, endReason) {
    const segments = activeWorkSegments(documentValue);
    const openIndex = segments.findIndex((segment) => !text(segment.endedAt));
    if (openIndex < 0) return segments;
    return segments.map((segment, index) => index === openIndex ? { ...segment, endedAt, endReason } : segment);
  }

  function resumeWorkSegment(documentValue, startedAt) {
    const segments = activeWorkSegments(documentValue);
    if (segments.some((segment) => !text(segment.endedAt))) return segments;
    return [...segments, { segmentNumber: segments.length + 1, startedAt, endedAt: '', endReason: '', note: text(documentValue.note) }];
  }

  function parkedOtherActivity(documentValue = activeJobDocument) {
    return isPlainObject(documentValue.parkedOtherActivity) && isOtherActivity(documentValue.parkedOtherActivity)
      ? documentValue.parkedOtherActivity
      : null;
  }

  function pauseOtherActivityAutomatically(documentValue, pausedAt, forJobId) {
    if (!isOtherActivity(documentValue)) return null;
    if (text(documentValue.status) !== 'active') {
      return {
        ...documentValue,
        pauseMode: text(documentValue.pauseMode, 'manual'),
        autoResumeEligible: false,
        parkedForJobId: text(forJobId),
        parkedAt: pausedAt
      };
    }
    return {
      ...documentValue,
      status: 'paused',
      pausedAt,
      pauseMode: 'automatic',
      autoResumeEligible: true,
      autoPausedForJobId: text(forJobId),
      parkedForJobId: text(forJobId),
      parkedAt: pausedAt,
      workSegments: closeOpenWorkSegment(documentValue, pausedAt, 'auto-paused-for-job'),
      updatedAt: pausedAt,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(documentValue, 'other_activity_auto_paused', pausedAt, 'automatic', { forJobId: text(forJobId) })
    };
  }

  function resumeOtherActivityAutomatically(documentValue, resumedAt, afterJobId) {
    if (!isOtherActivity(documentValue)) return null;
    if (text(documentValue.status) === 'active') return documentValue;
    if (text(documentValue.status) !== 'paused' || text(documentValue.pauseMode) !== 'automatic' || documentValue.autoResumeEligible !== true) {
      return documentValue;
    }
    const pausePeriods = Array.isArray(documentValue.pausePeriods) ? documentValue.pausePeriods.filter(isPlainObject) : [];
    const pausedFrom = text(documentValue.pausedAt);
    const completedPause = pausedFrom ? { from: pausedFrom, to: resumedAt, mode: 'automatic' } : null;
    const completedPauseMs = completedPause ? Math.max(0, new Date(resumedAt).getTime() - new Date(pausedFrom).getTime()) : 0;
    const nextSegments = resumeWorkSegment(documentValue, resumedAt);
    return {
      ...documentValue,
      status: 'active',
      pausedAt: '',
      pauseMode: '',
      autoResumeEligible: false,
      autoPausedForJobId: '',
      parkedForJobId: text(afterJobId),
      pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
      pausedTotalMs: (Number(documentValue.pausedTotalMs) || 0) + completedPauseMs,
      workSegments: nextSegments,
      continuationCount: Math.max(0, nextSegments.length - 1),
      updatedAt: resumedAt,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(documentValue, 'other_activity_auto_resumed', resumedAt, 'automatic', { afterJobId: text(afterJobId) })
    };
  }

  function restoreOtherActivityAfterJob(documentValue, restoredAt) {
    const parked = parkedOtherActivity(documentValue);
    if (!parked) return null;
    const resumed = resumeOtherActivityAutomatically(parked, restoredAt, stableJobId(documentValue, 'completed-job'));
    return {
      ...resumed,
      parkedForJobId: '',
      parkedAt: '',
      restoredAfterJobAt: restoredAt
    };
  }

  function phaseLabel(phase) {
    return phaseService ? phaseService.label(phase) : text(phase, 'Lastning');
  }

  function statusLabel(status) {
    if (status === 'paused') return 'Pausat';
    if (status === 'completing') return 'Avslut väntar';
    return 'Aktivt';
  }

  function activeLoads(documentValue = activeJobDocument) {
    return Array.isArray(documentValue.loads) ? documentValue.loads.filter((value) => Number.isFinite(Number(value)) && Number(value) >= 0).map(Number) : [];
  }

  function activeTotalWeight(documentValue = activeJobDocument) {
    return activeLoads(documentValue).reduce((sum, value) => sum + value, 0);
  }

  function activeLoadCycles(documentValue = activeJobDocument) {
    const stored = Array.isArray(documentValue.loadCycles) ? documentValue.loadCycles.filter(isPlainObject) : [];
    if (stored.length > 0) return stored;
    const entries = Array.isArray(documentValue.weightEntries) ? documentValue.weightEntries.filter(isPlainObject) : [];
    if (entries.length > 0) {
      return entries.map((entry, index) => ({
        loadNumber: index + 1,
        loadingStartedAt: text(documentValue.startedAt),
        unloadingStartedAt: text(documentValue.unloadingStartedAt),
        completedAt: text(entry.at),
        weight: Number(entry.weight),
        outcome: 'registered'
      }));
    }
    return [{ loadNumber: 1, loadingStartedAt: text(documentValue.startedAt), outcome: documentValue.noEmptying === true ? 'no-emptying' : 'open' }];
  }

  function currentLoadNumber(documentValue = activeJobDocument) {
    return Math.max(1, Number(documentValue.currentLoadNumber) || activeLoadCycles(documentValue).length || 1);
  }

  function currentLoadCycle(documentValue = activeJobDocument) {
    const number = currentLoadNumber(documentValue);
    return activeLoadCycles(documentValue).find((cycle) => Number(cycle.loadNumber) === number) || null;
  }

  function currentLoadHasOutcome(documentValue = activeJobDocument) {
    const cycle = currentLoadCycle(documentValue);
    return Boolean(cycle && (cycle.outcome === 'registered' || cycle.outcome === 'no-emptying' || cycle.outcome === 'missing-confirmed'));
  }

  function updateCurrentLoadCycle(documentValue, updates) {
    const number = currentLoadNumber(documentValue);
    const cycles = activeLoadCycles(documentValue);
    const index = cycles.findIndex((cycle) => Number(cycle.loadNumber) === number);
    if (index < 0) return [...cycles, { loadNumber: number, loadingStartedAt: text(documentValue.startedAt), outcome: 'open', ...updates }];
    return cycles.map((cycle, cycleIndex) => cycleIndex === index ? { ...cycle, ...updates, loadNumber: number } : cycle);
  }

  function isBeachPlaceRecord(place) {
    const roles = place && Array.isArray(place.roles) ? place.roles : [];
    return Boolean(place && (place.category === 'badplats' || roles.includes('beach')));
  }

  function isSeaweedToBeach(documentValue) {
    if (canonicalJobTypeId(documentValue.jobTypeId) !== 'JT-1010') return false;
    return isBeachPlaceRecord(findPlaceById(documentValue.destinationPlaceId));
  }

  function seaweedFlowType(documentValue) {
    if (canonicalJobTypeId(documentValue.jobTypeId) !== 'JT-1010') return '';
    const from = findPlaceById(documentValue.fromPlaceId);
    const destination = findPlaceById(documentValue.destinationPlaceId);
    if (text(documentValue.destinationPlaceId) === 'PL-1007') return 'till_bioanlaggning';
    if (isBeachPlaceRecord(destination)) return isBeachPlaceRecord(from) ? 'mellan_badplatser' : 'till_badplats';
    return 'ovrig_havstang';
  }

  function seaweedFlowLabel(documentValue) {
    const flow = seaweedFlowType(documentValue);
    if (flow === 'till_bioanlaggning') return 'Inkörning till Bio · kod 611 · verklig Bioanläggningsvikt';
    if (flow === 'mellan_badplatser') return 'Mellan badplatser · vikt valfri och märks mellankörningsvikt';
    if (flow === 'till_badplats') return 'Utkörning till badplats · vikt valfri';
    return flow ? 'Övrigt Havstångsflöde' : '';
  }

  function seaweedWeightMetadata(documentValue) {
    const flowType = seaweedFlowType(documentValue);
    if (!flowType) return {};
    const role = flowType === 'till_bioanlaggning' ? 'verklig_bioanlaggning' : 'mellankorningsvikt';
    return {
      role,
      roleLabel: role === 'verklig_bioanlaggning' ? 'Verklig/invägd Bioanläggningsvikt' : 'Mellankörningsvikt / aktuell flakvikt',
      flowType,
      materialCode: flowType === 'till_bioanlaggning' ? '611' : ''
    };
  }

  function weightPolicy(documentValue) {
    const jobTypeId = canonicalJobTypeId(documentValue.jobTypeId);
    if (jobTypeId === 'JT-1001' || jobTypeId === 'JT-1011') return { mode: 'not-required', label: 'Vikt behövs inte för denna jobbtyp.' };
    if (isSeaweedToBeach(documentValue)) return { mode: 'not-required', label: 'Havstång till badplats får avslutas utan vikt.' };
    if (jobTypeId === 'JT-1013' || jobTypeId === 'JT-1014') return { mode: 'optional', label: 'Vikt är valfri för denna jobbtyp.' };
    return { mode: 'required', label: 'Registrera vikt eller välj Ingen tömning före Klart.' };
  }

  function weightOutcome(documentValue) {
    const loads = activeLoads(documentValue);
    if (loads.length > 0) return 'registered';
    if (documentValue.noEmptying === true) return 'no-emptying';
    if (documentValue.weightMissingConfirmed === true) return 'missing-confirmed';
    return 'missing';
  }

  function weightStatusLabel(documentValue) {
    const outcome = weightOutcome(documentValue);
    if (outcome === 'registered') return `${activeTotalWeight(documentValue).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    if (outcome === 'no-emptying') return 'Ingen tömning';
    if (outcome === 'missing-confirmed') return 'Avslutat utan vikt';
    return weightPolicy(documentValue).mode === 'required' ? 'Vikt saknas' : 'Vikt ej obligatorisk';
  }

  function parseWeightInput(value) {
    const raw = String(value || '').trim().replace(',', '.');
    if (!/^\d+(?:\.\d{0,3})?$/.test(raw)) return NaN;
    return Number(raw);
  }

  function noteWithoutNoEmptyingMarker(value) {
    return text(value)
      .replace(/\s*[–-]\s*Ej behov av tömning/giu, '')
      .replace(/Ej behov av tömning\s*[–-]\s*/giu, '')
      .replace(/^Ej behov av tömning$/giu, '')
      .trim();
  }

  function focusActiveWeightInput(options = {}) {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att registrera vikt på.', true);
      return false;
    }
    const input = byId('active-weight-input');
    if (!input || byId('active-weight-panel').hidden) {
      showStatus('active-weight-status', 'Viktfältet är inte tillgängligt för detta uppdrag.', true);
      return false;
    }
    const focusInput = () => {
      try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
      if (typeof input.setSelectionRange === 'function') {
        const end = String(input.value || '').length;
        try { input.setSelectionRange(end, end); } catch (_) {}
      }
    };
    focusInput();
    window.requestAnimationFrame(focusInput);
    if (options.showHint !== false) {
      showStatus('active-weight-status', 'Skriv vikten i ton och tryck Ange vikt. Siffertangentbordet ska vara öppet.');
    }
    return true;
  }

  function registerActiveWeight() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att registrera vikt på.', true);
      return false;
    }
    const input = byId('active-weight-input');
    if (!String(input.value || '').trim()) {
      focusActiveWeightInput({ showHint: false });
      showStatus('active-weight-status', 'Skriv vikten i ton. 0 är tillåtet för tomtransport eller tomt flak.', true);
      return false;
    }
    const weight = parseWeightInput(input.value);
    if (!Number.isFinite(weight) || weight < 0) {
      focusActiveWeightInput({ showHint: false });
      showStatus('active-weight-status', 'Skriv en giltig vikt i ton. Använd exempelvis 12,5. 0 är tillåtet.', true);
      return false;
    }
    const now = new Date().toISOString();
    const loadNumber = currentLoadNumber(activeJobDocument);
    const currentCycle = currentLoadCycle(activeJobDocument);
    const automaticMachineWeight = input.dataset.machineAutoWeight === 'true';
    const existingEntry = (Array.isArray(activeJobDocument.weightEntries) ? activeJobDocument.weightEntries : []).find((entry) => isPlainObject(entry) && Number(entry.loadNumber) === loadNumber);
    if (currentCycle && currentCycle.outcome === 'registered' && !(existingEntry && existingEntry.source === 'machine-auto' && !automaticMachineWeight)) {
      showStatus('active-weight-status', `Lass ${loadNumber} har redan en registrerad vikt. Registrera nästa lastning innan nästa lass vägs.`, true);
      return false;
    }
    const priorLoads = activeLoads(activeJobDocument); const loads = existingEntry && existingEntry.source === 'machine-auto' && !automaticMachineWeight
      ? priorLoads.map((value, index) => index === loadNumber - 1 ? weight : value)
      : [...priorLoads, weight];
    const entries = Array.isArray(activeJobDocument.weightEntries) ? activeJobDocument.weightEntries.filter(isPlainObject) : [];
    const seaweedWeight = seaweedWeightMetadata(activeJobDocument);
    let nextDocument = {
      ...activeJobDocument,
      loads,
      totalWeight: loads.reduce((sum, value) => sum + value, 0),
      weightEntries: (existingEntry && existingEntry.source === 'machine-auto' && !automaticMachineWeight ? entries.filter((entry) => entry !== existingEntry) : entries).concat({ weight, at: now, phase: text(activeJobDocument.phase, 'loading'), loadNumber, source: automaticMachineWeight ? 'machine-auto' : 'manual', ...seaweedWeight }),
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { weight, completedAt: now, outcome: 'registered', weightRole: text(seaweedWeight.role), flowType: text(seaweedWeight.flowType) }),
      ...(text(seaweedWeight.role) ? { havstangFlowType: seaweedWeight.flowType, havstangWeightRole: seaweedWeight.role, havstangWeightRoleLabel: seaweedWeight.roleLabel, havstangWeightIsFinal: seaweedWeight.role === 'verklig_bioanlaggning' } : {}),
      noEmptying: false,
      weightMissingConfirmed: false,
      weightOutcome: 'registered',
      note: noteWithoutNoEmptyingMarker(activeJobDocument.note),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'weight_registered', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber } : entry)
    };
    delete input.dataset.machineAutoWeight;
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    if (currentPhase === phaseService.PHASES.UNLOADING) {
      const nextPhase = activeJobDocument.returnRequired === true
        ? phaseService.PHASES.RETURN_TRANSPORT
        : phaseService.PHASES.READY_TO_COMPLETE;
      nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.LOAD_REGISTERED, now, 'weight_registered_in_unloading', 'manual', { loadNumber, nextPhase });
      nextDocument = phaseVisualService.markLoadRegistered(nextDocument, stableJobId(activeJobDocument, 'active'), nextPhase, now);
    } else if (currentPhase === phaseService.PHASES.RETURN_UNLOADING) {
      nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.READY_TO_COMPLETE, now, 'weight_registered_in_return_unloading', 'manual', { loadNumber });
    }
    pendingWeightlessCompletion = false;
    if (persistActiveJob(nextDocument, `Vikt ${weight.toLocaleString('sv-SE', { maximumFractionDigits: 3 })} ton registrerades och sparades lokalt.`)) {
      input.value = '';
      showStatus('active-weight-status', `Vikten är registrerad för lass ${loadNumber}.`);
      return true;
    }
    return false;
  }

  function markActiveNoEmptying() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-weight-status', 'Det finns inget aktivt jobb att markera.', true);
      return;
    }
    if (currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-weight-status', `Lass ${currentLoadNumber(activeJobDocument)} har redan ett registrerat utfall.`, true);
      return;
    }
    const now = new Date().toISOString();
    const marker = 'Ej behov av tömning';
    const note = text(activeJobDocument.note);
    const nextNote = note.toLocaleLowerCase('sv-SE').includes(marker.toLocaleLowerCase('sv-SE')) ? note : (note ? `${note} – ${marker}` : marker);
    let nextDocument = {
      ...activeJobDocument,
      noEmptying: true,
      noEmptyingAt: now,
      weightMissingConfirmed: false,
      weightOutcome: 'no-emptying',
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { completedAt: now, outcome: 'no-emptying' }),
      excludeFromTimeEstimate: true,
      excludeFromEstimateLearning: true,
      learningExcludedReason: marker,
      note: nextNote,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'no_emptying', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber: currentLoadNumber(activeJobDocument) } : entry)
    };
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    if (currentPhase === phaseService.PHASES.UNLOADING) {
      const nextPhase = activeJobDocument.returnRequired === true
        ? phaseService.PHASES.RETURN_TRANSPORT
        : phaseService.PHASES.READY_TO_COMPLETE;
      nextDocument = buildPhaseTransitionDocument(nextDocument, nextPhase, now, 'no_emptying_registered_in_unloading', 'manual', { loadNumber: currentLoadNumber(activeJobDocument) });
    } else if (currentPhase === phaseService.PHASES.RETURN_UNLOADING) {
      nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.READY_TO_COMPLETE, now, 'no_emptying_registered_in_return_unloading', 'manual', { loadNumber: currentLoadNumber(activeJobDocument) });
    }
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, 'Ingen tömning är registrerad. Uppdraget undantas från framtida tidsinlärning.');
  }

  function clearLoadRegisteredTimer() {
    if (loadRegisteredTimer !== null) window.clearTimeout(loadRegisteredTimer);
    loadRegisteredTimer = null;
    loadRegisteredTimerJobId = '';
    loadRegisteredTimerUntil = '';
  }

  function completeLoadRegisteredPhase(expectedJobId, expectedUntil) {
    clearLoadRegisteredTimer();
    if (!activeJobLoaded || !activeJobExists() || text(activeJobDocument.status) !== 'active') return;
    if (phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.LOAD_REGISTERED) return;
    const activeId = stableJobId(activeJobDocument, 'active');
    if (activeId !== expectedJobId || !phaseVisualService.timerMatches(activeJobDocument, expectedJobId, expectedUntil)) return;
    const targetPhase = phaseService.normalizePhase(text(activeJobDocument.loadRegisteredNextPhase), '');
    if (![phaseService.PHASES.RETURN_TRANSPORT, phaseService.PHASES.READY_TO_COMPLETE].includes(targetPhase)) {
      showStatus('active-action-status', 'Lass registrerat saknar en säker nästa fas. Uppdraget är bevarat.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, targetPhase, now, 'load_registered_delay_completed', 'timer');
    persistActiveJob(nextDocument, targetPhase === phaseService.PHASES.RETURN_TRANSPORT
      ? 'Lasset är registrerat. Returtransport kan fortsätta.'
      : 'Lasset är registrerat. Uppdraget är redo att avslutas.');
  }

  function scheduleLoadRegisteredTransition() {
    if (!activeJobLoaded || !activeJobExists()
      || text(activeJobDocument.status) !== 'active'
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.LOAD_REGISTERED) {
      clearLoadRegisteredTimer();
      return;
    }
    const jobId = stableJobId(activeJobDocument, 'active');
    const until = text(activeJobDocument.loadRegisteredUntil);
    if (!jobId || !until || text(activeJobDocument.loadRegisteredJobId) !== jobId) {
      clearLoadRegisteredTimer();
      showStatus('active-action-status', 'Lass registrerat väntar, men tidsmarkeringen är ofullständig. Uppdraget är bevarat.', true);
      return;
    }
    if (loadRegisteredTimer !== null && loadRegisteredTimerJobId === jobId && loadRegisteredTimerUntil === until) return;
    clearLoadRegisteredTimer();
    const remaining = phaseVisualService.remainingMs(activeJobDocument);
    if (remaining <= 0) {
      completeLoadRegisteredPhase(jobId, until);
      return;
    }
    loadRegisteredTimerJobId = jobId;
    loadRegisteredTimerUntil = until;
    loadRegisteredTimer = window.setTimeout(() => completeLoadRegisteredPhase(jobId, until), remaining);
  }

  function activePhaseControl(phase, status, returnRequired, otherActivity) {
    if (otherActivity) return Object.freeze({ phase: phaseService.PHASES.OTHER_ACTIVITY, label: 'Övrig verksamhet', action: '' });
    const base = phaseActionService.resolve(phase, phaseService);
    const multiLoadReady = activeJobDocument.multiLoad === true
      && returnRequired !== true
      && phase === phaseService.PHASES.READY_TO_COMPLETE
      && status === 'active'
      && currentLoadHasOutcome(activeJobDocument);
    if (!multiLoadReady) return base;
    return Object.freeze({
      phase,
      label: `Registrera nästa lastning (lass ${currentLoadNumber(activeJobDocument) + 1})`,
      action: phaseActionService.ACTIONS.START_NEXT_LOAD
    });
  }

  function renderActiveJob() {
    const emptyCard = byId('active-empty-card');
    const jobCard = byId('active-job-card');
    const pill = byId('active-status-pill');
    emptyCard.hidden = true;
    jobCard.hidden = true;
    pill.classList.remove('is-active', 'is-paused', 'is-completing');

    if (!activeJobLoaded) {
      clearActivePhaseVisuals();
      pill.textContent = 'Ej laddat';
      return;
    }
    if (!activeJobExists()) {
      clearActivePhaseVisuals();
      if (ataBillingDialogOpen) closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveReset = false;
      pendingActiveComplete = false;
      pendingWeightlessCompletion = false;
      pill.textContent = 'Inget jobb';
      clearLoadRegisteredTimer();
      emptyCard.hidden = false;
      return;
    }

    const status = text(activeJobDocument.status, 'active');
    const phase = phaseService.normalizePhase(text(activeJobDocument.phase, 'loading'));
    const otherActivity = isOtherActivity(activeJobDocument);
    const parkedActivity = parkedOtherActivity(activeJobDocument);
    pill.textContent = statusLabel(status);
    pill.classList.add(status === 'paused' ? 'is-paused' : (status === 'completing' ? 'is-completing' : 'is-active'));
    byId('active-display-type').textContent = text(activeJobDocument.jobType, 'Uppdrag');
    const activeMachine = isPlainObject(activeJobDocument.machine) ? text(activeJobDocument.machine.name) : '';
    if (activeMachine) byId('active-display-type').textContent += ` · ${activeMachine}`;
    const activeAtaBadge = byId('active-ata-badge');
    activeAtaBadge.hidden = !ataApi.isEnabled(activeJobDocument);
    const returnRequired = !otherActivity && activeJobDocument.returnRequired === true;
    byId('active-route').hidden = otherActivity;
    byId('active-route').textContent = returnRequired
      ? `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')} → ${text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Returplats saknas'))}`
      : (otherActivity ? 'Användarens tidsrapportering' : `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')}`);
    const parkedStatus = byId('active-other-activity-status');
    parkedStatus.hidden = !parkedActivity;
    parkedStatus.textContent = !parkedActivity
      ? ''
      : (parkedActivity.status === 'active'
        ? 'Övrig verksamhet pågår automatiskt medan detta uppdrag är pausat.'
        : (parkedActivity.autoResumeEligible === true
          ? 'Övrig verksamhet är automatiskt pausad bakom detta uppdrag.'
          : 'Övrig verksamhet är manuellt pausad bakom detta uppdrag och återstartas inte automatiskt.'));
    byId('active-display-status').textContent = statusLabel(status);
    byId('active-display-phase').textContent = phaseLabel(phase);
    renderActivePhaseTrack(activeJobDocument);
    byId('active-display-started').textContent = formatTimestamp(activeJobDocument.startedAt);
    byId('active-display-paused').textContent = status === 'paused' ? formatTimestamp(activeJobDocument.pausedAt) : 'Inte pausat';
    byId('active-event-count').textContent = String(activeEvents(activeJobDocument).length);
    byId('active-display-return').textContent = returnRequired ? text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Från-plats')) : 'Ingen';
    const activeMaterial = isPlainObject(activeJobDocument.material) ? activeJobDocument.material : {};
    byId('active-display-material').textContent = [text(activeMaterial.code), text(activeMaterial.facilityPlaceName)].filter(Boolean).join(' · ') || 'Ej aktuellt';
    byId('active-display-loads').textContent = String(activeLoads(activeJobDocument).length);
    byId('active-display-current-load').textContent = activeJobDocument.multiLoad === true ? String(currentLoadNumber(activeJobDocument)) : 'Enkellass';
    byId('active-display-weight').textContent = `${activeTotalWeight(activeJobDocument).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    byId('active-display-weight-status').textContent = weightStatusLabel(activeJobDocument);
    ['active-return-row', 'active-material-row', 'active-loads-row', 'active-current-load-row', 'active-weight-row', 'active-weight-status-row'].forEach((id) => {
      byId(id).hidden = otherActivity;
    });
    const seaweedLabel = seaweedFlowLabel(activeJobDocument);
    byId('active-seaweed-row').hidden = !seaweedLabel;
    byId('active-display-seaweed').textContent = seaweedLabel || '–';
    byId('active-weight-rule').textContent = weightPolicy(activeJobDocument).label;
    byId('active-weight-panel').hidden = otherActivity;
    const activeNote = text(activeJobDocument.note);
    byId('active-display-note').hidden = !activeNote;
    byId('active-display-note').textContent = activeNote ? `Anteckning: ${activeNote}` : '';
    const phaseAction = byId('active-phase-action');
    const phaseControl = activePhaseControl(phase, status, returnRequired, otherActivity);
    phaseAction.hidden = false;
    phaseAction.textContent = phaseControl.label;
    phaseAction.dataset.phaseAction = phaseControl.action;
    phaseAction.setAttribute('aria-label', phaseControl.label || 'Fasåtgärd');
    phaseAction.disabled = otherActivity || status !== 'active' || pendingActiveComplete || pendingWeightlessCompletion || ataBillingDialogOpen || phase === phaseService.PHASES.LOAD_REGISTERED;
    applyActivePhaseVisuals(phase, otherActivity);
    const weightSubmitButton = byId('active-weight-submit');
    weightSubmitButton.hidden = false;
    weightSubmitButton.disabled = false;
    weightSubmitButton.textContent = 'Ange vikt';
    const pauseButton = byId('active-pause-action');
    pauseButton.hidden = false;
    pauseButton.disabled = status === 'completing' || pendingActiveComplete || pendingWeightlessCompletion || ataBillingDialogOpen;
    pauseButton.textContent = status === 'paused'
      ? (otherActivity ? 'Fortsätt' : 'Flytta pausat uppdrag till kö')
      : 'Pausa';
    const completeButton = byId('active-complete-request');
    completeButton.hidden = false;
    completeButton.disabled = !['active', 'paused', 'completing'].includes(status) || pendingActiveComplete || pendingWeightlessCompletion || ataBillingDialogOpen;
    completeButton.textContent = status === 'completing' ? 'Slutför avslut' : 'Klart';
    byId('active-complete-confirm').hidden = !pendingActiveComplete || ataBillingDialogOpen;
    byId('active-complete-without-weight-confirm').hidden = !pendingWeightlessCompletion || ataBillingDialogOpen;
    byId('active-reset-request').hidden = pendingActiveReset || status === 'completing';
    byId('active-reset-confirm').hidden = !pendingActiveReset;
    byId('active-reset-message').textContent = isPlainObject(activeJobDocument.sourceQueueSnapshot)
      ? 'Uppdraget återställs först i 189:s operativa kö och tas därefter bort från Aktivt jobb. Det förs inte till Historik.'
      : (otherActivity
        ? 'Övrig verksamhet tas bort ur Aktivt jobb och förs inte till Historik.'
        : 'Det manuellt startade uppdraget tas bort ur Aktivt jobb och förs inte till Historik.');
    byId('active-flow-boundary').textContent = otherActivity
      ? 'Övrig verksamhet registrerar arbetstid utan transport-, vikt- eller GPS-faser.'
      : 'Fasen uppdateras automatiskt med GPS. Du kan fortfarande styra fasen manuellt med fasknappen.';
    jobCard.hidden = false;
    scheduleLoadRegisteredTransition();
  }

  function loadActiveJobIfNeeded() {
    if (!canUseActiveJob()) {
      showStatus('active-role-note', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (activeJobLoaded) {
      renderActiveJob();
      return;
    }
    try {
      activeJobDocument = readActiveJobDocument();
      activeJobLoaded = true;
      renderActiveJob();
      syncActiveJobGpsConsumer();
      syncActiveGeofenceContext();
      showStatus('active-load-status', activeJobExists() ? '' : 'Inget aktivt jobb finns.');
    } catch (error) {
      watchdog.step('runtime.store.active.invalid', error.message || 'Aktivt jobb kunde inte läsas.', 'warning');
      renderActiveJob();
      syncActiveJobGpsConsumer();
      syncActiveGeofenceContext();
      showStatus('active-load-status', error.message || 'Aktivt jobb kunde inte läsas.', true);
    }
  }

  function persistActiveJob(nextDocument, successMessage, options = {}) {
    const previousActiveDocument = activeJobDocument;
    const saved = window.StadslassHost.writeStore(ACTIVE_JOB_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('active-action-status', window.StadslassHost.getLastError() || 'Aktivt jobb kunde inte sparas.', true);
      return false;
    }
    activeJobDocument = nextDocument;
    activeJobLoaded = true;
    pendingActiveReset = false;
    renderActiveJob();
    syncActiveJobGpsConsumer();
    syncActiveGeofenceContext();
    if (queueLoaded) renderQueue();
    invalidateQuickChoiceFallbackForActiveJobChange();
    syncV63PublishActive(nextDocument, Boolean(options.terminal) || !text(nextDocument && nextDocument.id), previousActiveDocument);
    if (!options.silent && text(successMessage)) showStatus('active-action-status', successMessage);
    return true;
  }

  function appendActiveEvent(documentValue, type, at, source = 'manual', extra = {}) {
    return [...activeEvents(documentValue), { type, at, source, packageVersion: PACKAGE_VERSION, ...extra }];
  }

  async function createActiveJob(event) {
    event.preventDefault();
    if (!canUseActiveJob()) {
      showStatus('active-form-status', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (!activeJobLoaded) loadActiveJobIfNeeded();
    if (!activeJobLoaded) {
      showStatus('active-form-status', 'Aktivt jobb måste kunna läsas innan ett nytt uppdrag kan startas.', true);
      return;
    }
    const jobType = findJobTypeById(byId('active-job-type').value);
    const otherActivity = isOtherActivityJobType(jobType);
    const machineTransport = isMachineTransportJobType(jobType);
    const machine = machineTransport ? machineSnapshot(byId('active-job-machine').value) : null;
    if (!jobType) {
      showStatus('active-form-status', 'Välj jobbtyp.', true);
      return;
    }
    if (activeJobExists() && !(isOtherActivity(activeJobDocument) && !otherActivity && activeJobDocument.status !== 'completing')) {
      showStatus('active-form-status', 'Ett aktivt jobb finns redan och har inte ersatts.', true);
      return;
    }
    const fromPlace = otherActivity ? null : resolveFormPlaceSelection('active', 'from');
    const destinationPlace = otherActivity ? null : resolveFormPlaceSelection('active', 'destination');
    const returnRequired = !otherActivity && byId('active-job-return-required').checked;
    const selectedReturnPlace = returnRequired ? findPlaceById(byId('active-job-return').value) : null;
    const returnPlace = returnRequired ? (selectedReturnPlace || fromPlace) : null;
    if (!otherActivity && (!fromPlace || !destinationPlace)) {
      showStatus('active-form-status', 'Välj jobbtyp, Från och Till.', true);
      return;
    }
    if (!otherActivity && !machineTransport
      && ((fromPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(fromPlace, jobType.id, 'from'))
        || (destinationPlace.temporaryOtherPlace !== true && !placeSupportsJobTypeRole(destinationPlace, jobType.id, 'destination')))) {
      showStatus('active-form-status', 'Från eller Till är inte kopplad till vald Jobbtyp i Platsregistret. Välj en giltig kombination.', true);
      return;
    }
    if (activeJobStartInProgress) {
      showStatus('active-form-status', 'Startpositionen fastställs redan för ett uppdrag.', true);
      return;
    }
    activeJobStartInProgress = true;
    if (!otherActivity && initialPhaseNeedsGps(fromPlace)) {
      showStatus('active-form-status', 'Appen fastställer startpositionen innan uppdraget startas.');
    }
    let initialPhase;
    try {
      initialPhase = otherActivity
        ? { phase: phaseService.PHASES.OTHER_ACTIVITY, source: 'job-start', reason: 'other_activity_started' }
        : await determineInitialPhaseForPlace(fromPlace);
    } finally {
      activeJobStartInProgress = false;
    }
    if (activeJobExists() && !(isOtherActivity(activeJobDocument) && !otherActivity && activeJobDocument.status !== 'completing')) {
      showStatus('active-form-status', 'Ett aktivt jobb blev tillgängligt medan startpositionen hämtades. Formuläret är oförändrat.', true);
      return;
    }
    const now = new Date().toISOString();
    const jobId = createLocalId('job');
    const otherActivityToPark = activeJobExists() ? pauseOtherActivityAutomatically(activeJobDocument, now, jobId) : null;
    const temporaryPlaces = otherActivity ? {} : collectTemporaryPlaces('active');
    const rawDocument = {
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: jobId,
      jobId,
      status: 'active',
      phase: initialPhase.phase,
      source: 'manual-local',
      jobTypeId: jobType.id,
      jobTypeName: jobType.name,
      fromPlaceId: text(fromPlace && fromPlace.id),
      fromPlaceName: text(fromPlace && fromPlace.name),
      destinationPlaceId: text(destinationPlace && destinationPlace.id),
      destinationPlaceName: text(destinationPlace && destinationPlace.name),
      returnPlaceId: returnPlace ? text(returnPlace.id) : '',
      returnPlaceName: returnPlace ? text(returnPlace.name) : '',
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : byId('active-job-multi-load').checked,
      ...(machineTransport ? { machine, machineLoads: machine ? [{ loadNumber: 1, machine }] : [] } : {}),
      ...(otherActivity ? {} : {
        currentLoadNumber: 1,
        loadCycles: [{ loadNumber: 1, loadingStartedAt: initialPhase.phase === phaseService.PHASES.LOADING ? now : '', outcome: 'open' }]
      }),
      ...(otherActivityToPark ? { parkedOtherActivity: otherActivityToPark } : {}),
      material: otherActivity ? {} : deriveMaterialForSelections(jobType.id, fromPlace, destinationPlace),
      note: text(byId('active-job-note').value),
      ata: ataRouting.jobAtaSnapshot({
        enabled: byId('active-job-ata').checked,
        source: ataRouting.isManualJobType(jobType) ? 'manual-job-choice' : (ataRouting.jobTypeEnabled(jobType) ? 'job-type' : 'manual-job-choice'),
        recipient: ensureAtaRecipientContact(ataRecipientInput('active'), 'manual-job-choice', 'active-form-status') || (byId('active-job-ata').checked ? ataRouting.defaultRecipient(jobType) : null),
        timestamp: now
      }),
      startedAt: now,
      workSegments: [{ segmentNumber: 1, startedAt: now, endedAt: '', endReason: '', note: text(byId('active-job-note').value) }],
      continuationCount: 0,
      updatedAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedByPackageVersion: PACKAGE_VERSION,
      metadata: { createdRole: text(hostInfo.role), createdRoleLabel: text(hostInfo.roleLabel), createdDeviceId: text(hostInfo.deviceId), modelVersion: JOB_MODEL_VERSION },
      events: [{ type: otherActivity ? 'other_activity_started' : 'job_started', at: now, source: 'manual', packageVersion: PACKAGE_VERSION }]
    };
    if (Object.keys(temporaryPlaces).length) rawDocument.temporaryPlaces = temporaryPlaces;
    let nextDocument = normalizeJobRecord(rawDocument, 'active');
    nextDocument = phaseService.initializeRecord(nextDocument, initialPhase.phase, now, initialPhase.reason, initialPhase.source);
    if (persistActiveJob(nextDocument, otherActivity
      ? 'Övrig verksamhet startades som användarens tidsrapportering och sparades lokalt.'
      : (otherActivityToPark ? 'ÖV pausades automatiskt och uppdraget startades lokalt.' : 'Uppdraget startades med gemensam uppdragsmodell och sparades lokalt.'))) {
      byId('active-form').reset();
      resetTemporaryPlaceForm('active');
      refreshPlaceFormsForJobType('active-');
      syncJobModeControls('active');
      clearAtaRecipient('active');
      syncAtaForm('active', true);
      updateMaterialPanel('active-');
    }
  }

  function completeActiveReturnUnloading() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.status !== 'active'
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.RETURN_UNLOADING) {
      showStatus('active-action-status', 'Aktivt jobb väntar inte på genomförd returlossning.', true);
      return;
    }
    const now = new Date().toISOString();
    let nextDocument = buildPhaseTransitionDocument(
      activeJobDocument,
      phaseService.PHASES.READY_TO_COMPLETE,
      now,
      'manual_return_unloading_completed',
      'manual'
    );
    nextDocument = phaseActionService.markReturnUnloadingCompleted(nextDocument, now, PACKAGE_VERSION);
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, 'Returlossningen är registrerad. Uppdraget är redo att avslutas manuellt med Klart.');
  }

  function advanceActivePhase() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Fasåtgärden kan bara användas när uppdraget är aktivt.', true);
      return;
    }
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    const phaseControl = activePhaseControl(currentPhase, activeJobDocument.status, activeJobDocument.returnRequired === true, isOtherActivity(activeJobDocument));
    if (phaseControl.action === phaseActionService.ACTIONS.START_LOADING) {
      const now = new Date().toISOString();
      const nextDocument = buildPhaseTransitionDocument(activeJobDocument, phaseService.PHASES.LOADING, now, 'manual_start_route_completed', 'manual');
      persistActiveJob(nextDocument, 'Lastning aktiverades manuellt och sparades lokalt.');
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.REGISTER_WEIGHT) {
      focusActiveWeightInput();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.SHOW_LOAD_REGISTERED) {
      showStatus('active-action-status', 'Lasset är registrerat. Nästa fas aktiveras automatiskt efter den korta mellanfasen.');
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.ARRIVE_RETURN) {
      markActiveReturnArrived();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.COMPLETE_RETURN_UNLOADING) {
      completeActiveReturnUnloading();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.REQUEST_COMPLETE) {
      requestActiveComplete();
      return;
    }
    if (phaseControl.action === phaseActionService.ACTIONS.START_NEXT_LOAD) {
      startNextActiveLoad();
      return;
    }

    let nextPhase = '';
    let reason = '';
    if (phaseControl.action === phaseActionService.ACTIONS.COMPLETE_LOADING) {
      nextPhase = phaseService.PHASES.TRANSPORT;
      reason = 'manual_loading_completed';
    } else if (phaseControl.action === phaseActionService.ACTIONS.ARRIVE_DESTINATION) {
      nextPhase = phaseService.PHASES.UNLOADING;
      reason = 'manual_arrival_registered';
    } else {
      showStatus('active-action-status', 'Den manuella fasfunktionen är inte aktuell i denna fas.', true);
      return;
    }
    const now = new Date().toISOString();
    if (nextPhase === phaseService.PHASES.TRANSPORT && isMachineTransportJobType(activeJobDocument.jobTypeId)) {
      const selected = isPlainObject(activeJobDocument.machine) ? activeJobDocument.machine : null;
      const current = selected ? machineSnapshot(selected.id) : null;
      if (current && Number.isFinite(current.weight) && current.weight >= 0 && !currentLoadHasOutcome(activeJobDocument)) {
        const input = byId('active-weight-input'); input.value = String(current.weight); input.dataset.machineAutoWeight = 'true'; registerActiveWeight();
      }
    }
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, nextPhase, now, reason, 'manual');
    persistActiveJob(nextDocument, nextPhase === phaseService.PHASES.TRANSPORT
      ? 'Transport påbörjades och sparades lokalt.'
      : (isSeaweedToBeach(activeJobDocument) ? 'Framme vid badplats registrerades manuellt och sparades lokalt.' : 'Lossning påbörjades och sparades lokalt.'));
  }

  function startNextActiveLoad() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.multiLoad !== true) {
      showStatus('active-action-status', 'Uppdraget är inte markerat som Flerlass.', true);
      return;
    }
    if (activeJobDocument.returnRequired === true) {
      showStatus('active-action-status', 'Retur och Flerlass kan inte vara aktiva samtidigt i detta flöde.', true);
      return;
    }
    const phase = phaseService.normalizePhase(activeJobDocument.phase);
    if (activeJobDocument.status !== 'active' || ![phaseService.PHASES.UNLOADING, phaseService.PHASES.READY_TO_COMPLETE].includes(phase)) {
      showStatus('active-action-status', 'Nästa lastning kan registreras efter lossningsfasen.', true);
      return;
    }
    if (!currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-action-status', 'Registrera vikt eller Ingen tömning för aktuellt lass innan nästa lastning.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextNumber = currentLoadNumber(activeJobDocument) + 1;
    const cycles = activeLoadCycles(activeJobDocument);
    let nextDocument = {
      ...activeJobDocument,
      currentLoadNumber: nextNumber,
      loadCycles: [...cycles, { loadNumber: nextNumber, loadingStartedAt: now, outcome: 'open' }],
      noEmptying: false,
      noEmptyingAt: '',
      weightMissingConfirmed: false,
      weightOutcome: activeLoads(activeJobDocument).length > 0 ? 'registered' : 'missing',
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'next_loading_registered', now).map((entry, index, all) => index === all.length - 1 ? { ...entry, loadNumber: nextNumber } : entry)
    };
    nextDocument = buildPhaseTransitionDocument(nextDocument, phaseService.PHASES.LOADING, now, 'manual_next_load', 'manual', { loadNumber: nextNumber });
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    persistActiveJob(nextDocument, `Ny lastning är registrerad. Lass ${nextNumber} har påbörjats manuellt.`);
  }

  function startActiveReturn() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.returnRequired !== true
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.UNLOADING
      || activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Returen kan påbörjas först efter lossningen i ett returuppdrag.', true);
      return;
    }
    if (weightPolicy(activeJobDocument).mode === 'required' && !currentLoadHasOutcome(activeJobDocument)) {
      showStatus('active-action-status', 'Registrera vikt eller Ingen tömning innan returen påbörjas.', true);
      return;
    }
    const now = new Date().toISOString();
    const returnPlaceName = text(activeJobDocument.returnPlaceName, text(activeJobDocument.from, 'Från-plats'));
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, phaseService.PHASES.RETURN_TRANSPORT, now, 'manual_return_started', 'manual');
    persistActiveJob(nextDocument, `Retur till ${returnPlaceName} påbörjades manuellt.`);
  }

  function markActiveReturnArrived() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (activeJobDocument.returnRequired !== true
      || phaseService.normalizePhase(activeJobDocument.phase) !== phaseService.PHASES.RETURN_TRANSPORT
      || activeJobDocument.status !== 'active') {
      showStatus('active-action-status', 'Aktivt jobb väntar inte på ankomst till en returplats.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextDocument = buildPhaseTransitionDocument(activeJobDocument, phaseService.PHASES.RETURN_UNLOADING, now, 'manual_return_arrival', 'manual');
    persistActiveJob(nextDocument, `${text(activeJobDocument.returnPlaceName, 'Returplats')} är manuellt registrerad som nådd.`);
  }

  function pauseOrdinaryJobToQueue() {
    if (!queueLoaded) loadQueueIfNeeded();
    if (!queueLoaded) {
      showStatus('active-action-status', 'Den operativa kön kunde inte läsas. Pausen stoppades och Aktivt jobb är oförändrat.', true);
      return;
    }

    const now = new Date().toISOString();
    const wasAlreadyPaused = text(activeJobDocument.status) === 'paused';
    const jobId = stableJobId(activeJobDocument, 'paused-job');
    const queueId = text(activeJobDocument.sourceQueueItemId, jobId);
    const pausedSegments = closeOpenWorkSegment(activeJobDocument, now, 'paused-to-queue');
    const { parkedOtherActivity: _parkedActivity, ...ordinaryJob } = activeJobDocument;
    const pausedQueueItem = normalizeJobRecord({
      ...ordinaryJob,
      id: queueId,
      jobId,
      status: 'paused',
      pausedAt: wasAlreadyPaused ? text(activeJobDocument.pausedAt, now) : now,
      pausedFromActive: true,
      pausedIntoQueueAt: now,
      workSegments: pausedSegments,
      continuationCount: Math.max(0, pausedSegments.length - 1),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(ordinaryJob, wasAlreadyPaused ? 'paused_job_moved_to_queue' : 'job_paused', now, 'manual', { movedToQueue: true })
    }, 'queue-active-pause');
    const nextQueue = [
      pausedQueueItem,
      ...queueDocument.filter((item, index) => displayQueueItem(item, index).jobId !== jobId)
    ];

    if (!persistQueue(nextQueue, 'Det pausade uppdraget placerades överst i 189:s operativa kö.')) {
      showStatus('active-action-status', 'Uppdraget kunde inte sparas i kön. Pausen stoppades och Aktivt jobb är oförändrat.', true);
      return;
    }

    const restoredOtherActivity = restoreOtherActivityAfterJob(activeJobDocument, now);
    if (!persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Uppdraget pausades till kön och Övrig verksamhet är nu synligt aktiv.'
        : 'Uppdraget pausades till kön. Manuellt pausad Övrig verksamhet är synligt bevarad utan automatisk återstart.')
      : 'Uppdraget pausades och flyttades överst i kön.')) {
      showStatus('active-action-status', 'Kökopian är säkert sparad, men Aktivt jobb kunde inte växlas. Tryck Pausa igen för att slutföra flytten utan dubblett.', true);
      return;
    }

    showStatus('active-load-status', restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Övrig verksamhet fortsätter synligt. Det pausade uppdraget ligger överst i kön.'
        : 'Övrig verksamhet är fortsatt manuellt pausad. Det pausade uppdraget ligger överst i kön.')
      : 'Inget aktivt jobb finns. Det pausade uppdraget ligger överst i kön och ett annat uppdrag kan startas.');
  }

  function toggleActivePause() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status === 'completing') {
      showStatus('active-action-status', 'Ett väntande avslut kan inte pausas eller fortsättas.', true);
      return;
    }
    if (!isOtherActivity(activeJobDocument) && ['active', 'paused'].includes(activeJobDocument.status)) {
      pauseOrdinaryJobToQueue();
      return;
    }
    const nextStatus = activeJobDocument.status === 'paused' ? 'active' : 'paused';
    const now = new Date().toISOString();
    const pausePeriods = Array.isArray(activeJobDocument.pausePeriods) ? activeJobDocument.pausePeriods.filter(isPlainObject) : [];
    const pausedFrom = text(activeJobDocument.pausedAt);
    const completedPause = nextStatus === 'active' && pausedFrom ? { from: pausedFrom, to: now } : null;
    const pausedTotalMs = Number(activeJobDocument.pausedTotalMs) || 0;
    const completedPauseMs = completedPause ? Math.max(0, new Date(now).getTime() - new Date(pausedFrom).getTime()) : 0;
    const nextWorkSegments = nextStatus === 'paused'
      ? closeOpenWorkSegment(activeJobDocument, now, 'paused')
      : resumeWorkSegment(activeJobDocument, now);
    const otherActivity = isOtherActivity(activeJobDocument);
    const parkedActivity = parkedOtherActivity(activeJobDocument);
    const nextParkedActivity = parkedActivity
      ? (nextStatus === 'paused'
        ? resumeOtherActivityAutomatically(parkedActivity, now, stableJobId(activeJobDocument, 'paused-job'))
        : pauseOtherActivityAutomatically(parkedActivity, now, stableJobId(activeJobDocument, 'resumed-job')))
      : null;
    const nextDocument = {
      ...activeJobDocument,
      status: nextStatus,
      pausedAt: nextStatus === 'paused' ? now : '',
      ...(otherActivity ? {
        pauseMode: nextStatus === 'paused' ? 'manual' : '',
        autoResumeEligible: false,
        autoPausedForJobId: ''
      } : {}),
      ...(nextParkedActivity ? { parkedOtherActivity: nextParkedActivity } : {}),
      pausePeriods: completedPause ? [...pausePeriods, completedPause] : pausePeriods,
      pausedTotalMs: pausedTotalMs + completedPauseMs,
      workSegments: nextWorkSegments,
      continuationCount: Math.max(0, nextWorkSegments.length - 1),
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, nextStatus === 'paused' ? 'job_paused' : 'job_resumed', now)
    };
    persistActiveJob(nextDocument, nextStatus === 'paused'
      ? (nextParkedActivity && nextParkedActivity.status === 'active'
        ? 'Uppdraget pausades och Övrig verksamhet återupptogs automatiskt.'
        : (otherActivity ? 'Övrig verksamhet pausades manuellt och återstartas inte automatiskt.' : 'Uppdraget pausades och sparades lokalt.'))
      : (nextParkedActivity && nextParkedActivity.status === 'paused' && nextParkedActivity.autoResumeEligible === true
        ? 'Uppdraget fortsätter och Övrig verksamhet pausades automatiskt.'
        : (otherActivity ? 'Övrig verksamhet fortsätter och sparades lokalt.' : 'Uppdraget fortsätter och sparades lokalt.')));
  }

  function requestActiveReset() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      return;
    }
    const previousScrollY = currentScrollY();
    pendingActiveReset = true;
    renderActiveJob();
    revealInlineControl('#active-reset-confirm', previousScrollY);
    showStatus('active-action-status', 'Bekräfta avbrottet eller avbryt.');
  }

  function cancelActiveReset() {
    const previousScrollY = currentScrollY();
    pendingActiveReset = false;
    renderActiveJob();
    preserveScrollAfterRender(previousScrollY);
    showStatus('active-action-status', 'Avbrottet avbröts. Aktivt jobb är oförändrat.');
  }

  function confirmActiveReset() {
    if (!pendingActiveReset || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avbrottet kunde inte bekräftas.', true);
      return;
    }
    const queueSnapshot = isPlainObject(activeJobDocument.sourceQueueSnapshot) ? activeJobDocument.sourceQueueSnapshot : null;
    const restoredAt = new Date().toISOString();
    if (queueSnapshot) {
      if (!queueLoaded) loadQueueIfNeeded();
      if (!queueLoaded) {
        pendingActiveReset = false;
        renderActiveJob();
        showStatus('active-action-status', 'Den operativa kön kunde inte läsas. Avbrottet stoppades och Aktivt jobb är bevarat.', true);
        return;
      }
      const jobId = stableJobId(activeJobDocument, 'active-abort');
      const alreadyRestored = queueDocument.some((item, index) => displayQueueItem(item, index).jobId === jobId);
      if (!alreadyRestored) {
        const restored = normalizeJobRecord({
          ...queueSnapshot,
          id: text(activeJobDocument.sourceQueueItemId, text(queueSnapshot.id, jobId)),
          jobId,
          status: 'queued',
          restoredFromActiveAbortAt: restoredAt,
          restoredByPackageVersion: PACKAGE_VERSION
        }, 'queue-abort-restore');
        if (!persistQueue([...queueDocument, restored], 'Det avbrutna uppdraget återställdes i 189:s operativa kö.')) {
          pendingActiveReset = false;
          renderActiveJob();
          showStatus('active-action-status', 'Uppdraget kunde inte återställas i kön. Avbrottet stoppades och Aktivt jobb är bevarat.', true);
          return;
        }
      }
    }
    const restoredOtherActivity = restoreOtherActivityAfterJob(activeJobDocument, restoredAt);
    if (persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? 'Uppdraget avbröts och Övrig verksamhet återställdes säkert.'
      : (queueSnapshot ? 'Uppdraget avbröts och är återställt i 189:s operativa kö.' : 'Det manuellt startade uppdraget avbröts. Ingen historik ändrades.'))) {
      showStatus('active-load-status', restoredOtherActivity
        ? (restoredOtherActivity.status === 'active' ? 'Övrig verksamhet fortsätter efter avbrottet.' : 'Övrig verksamhet är fortsatt manuellt pausad efter avbrottet.')
        : (queueSnapshot ? 'Inget aktivt jobb finns. Uppdraget ligger åter i 189:s operativa kö.' : 'Det manuellt startade uppdraget avbröts. Inget aktivt jobb finns.'));
    }
  }

  function historyItemDisplay(rawItem, index) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    return {
      id: text(item.id, `history-${index}`),
      jobId: text(item.jobId, text(item.sourceJobId, text(item.id))),
      jobTypeId: text(item.jobTypeId),
      jobType: text(item.jobTypeName, text(item.jobType, 'Uppdrag')),
      otherActivity: isOtherActivity(item),
      from: text(item.fromPlaceName, text(item.from, 'Från saknas')),
      destination: text(item.destinationPlaceName, text(item.destination, 'Till saknas')),
      destinationPlaceId: text(item.destinationPlaceId),
      returnPlaceName: text(item.returnPlaceName),
      returnRequired: item.returnRequired === true,
      material: isPlainObject(item.material) ? item.material : {},
      note: text(item.note),
      modelVersion: Number(item.jobModelVersion) || 1,
      startedAt: text(item.startedAt),
      completedAt: text(item.completedAt),
      status: text(item.status, 'completed'),
      loads: Array.isArray(item.loads) ? item.loads : [],
      totalWeight: Number(item.totalWeight) || 0,
      weightOutcome: text(item.weightOutcome),
      multiLoad: item.multiLoad === true,
      machine: isPlainObject(item.machine) ? text(item.machine.name) : '',
      machineLoads: Array.isArray(item.machineLoads) ? item.machineLoads.filter(isPlainObject) : [],
      loadCycles: Array.isArray(item.loadCycles) ? item.loadCycles.filter(isPlainObject) : [],
      workSegments: Array.isArray(item.workSegments) ? item.workSegments.filter(isPlainObject) : [],
      continuationCount: Number(item.continuationCount) || 0,
      trashState: isPlainObject(item.trashState) ? item.trashState : {},
      ataEnabled: !isReceiptImportedHistoryItem(item) && ataApi.isEnabled(item),
      billing: !isReceiptImportedHistoryItem(item) ? ataBillingApi.snapshotFromRecord(item) : null
    };
  }

  function isHistoryItemTrashed(item) {
    return isPlainObject(item)
      && isPlainObject(item.trashState)
      && text(item.trashState.status) === 'trashed';
  }

  function activeHistoryEntries() {
    return historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => !isHistoryItemTrashed(item));
  }

  function trashedHistoryEntries() {
    return historyDocument
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => isHistoryItemTrashed(item))
      .sort((a, b) => new Date(text(b.item.trashState.trashedAt)).getTime() - new Date(text(a.item.trashState.trashedAt)).getTime());
  }

  function historyRouteText(item) {
    if (item.otherActivity) return 'Användarens tidsrapportering';
    return item.returnRequired
      ? `${item.from} → ${item.destination} → ${item.returnPlaceName || item.from}`
      : `${item.from} → ${item.destination}`;
  }

  function durationText(startedAt, completedAt) {
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return 'Tid saknas';
    const minutes = Math.max(0, Math.round((end - start) / 60000));
    const hours = Math.floor(minutes / 60);
    const rest = minutes % 60;
    return hours > 0 ? `${hours} h ${rest} min` : `${rest} min`;
  }

  function durationMinutes(startedAt, completedAt) {
    const start = new Date(startedAt).getTime();
    const end = new Date(completedAt).getTime();
    return Number.isFinite(start) && Number.isFinite(end) && end >= start ? Math.max(0, Math.round((end - start) / 60000)) : 0;
  }

  function workMinutes(item) {
    if (!item.workSegments.length) return durationMinutes(item.startedAt, item.completedAt);
    return item.workSegments.reduce((sum, segment) => sum + durationMinutes(segment.startedAt, segment.endedAt || item.completedAt), 0);
  }

  function formatMinutes(minutes) {
    return minutes >= 60 ? `${Math.floor(minutes / 60)} h ${minutes % 60} min` : `${minutes} min`;
  }

  function statisticsMetrics(displayed) {
    return {
      jobs: displayed.length,
      loads: displayed.reduce((sum, item) => sum + item.loads.length, 0),
      weight: displayed.reduce((sum, item) => sum + item.totalWeight, 0),
      minutes: displayed.reduce((sum, item) => sum + workMinutes(item), 0)
    };
  }

  function renderSummaryMetrics(prefix, metrics) {
    byId(`${prefix}-summary-jobs`).textContent = String(metrics.jobs);
    byId(`${prefix}-summary-loads`).textContent = String(metrics.loads);
    byId(`${prefix}-summary-weight`).textContent = `${metrics.weight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`;
    byId(`${prefix}-summary-time`).textContent = formatMinutes(metrics.minutes);
  }

  function historySummary(items, prefix) {
    const displayed = items.map(({ item, index }) => historyItemDisplay(item, index));
    renderSummaryMetrics(prefix, statisticsMetrics(displayed));
  }

  function historySearchText(item) {
    return [item.jobType, item.machine, ...item.machineLoads.map((load) => text(load.machine && load.machine.name)), item.from, item.destination, item.returnPlaceName, item.note, item.material.code, item.material.facilityPlaceName]
      .filter(Boolean).join(' ').toLocaleLowerCase('sv-SE');
  }

  function localDateFromTimestamp(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : localDateKey(date);
  }

  function historyCalendarExplicitDate(rawItem) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    const candidates = [item.date, item.receiptDate, item.historyDate, item.completedDate];
    return candidates.map((value) => text(value)).find((value) => /^\d{4}-\d{2}-\d{2}$/.test(value)) || '';
  }

  function historyCalendarDateKey(rawItem, index) {
    const explicitDate = historyCalendarExplicitDate(rawItem);
    if (explicitDate) return explicitDate;
    const item = isPlainObject(rawItem) ? rawItem : {};
    const displayed = historyItemDisplay(item, index);
    const timestamp = displayed.completedAt || text(item.endAt) || text(item.end) || displayed.startedAt;
    return localDateFromTimestamp(timestamp);
  }

  function isReceiptImportedHistoryItem(rawItem) {
    const item = isPlainObject(rawItem) ? rawItem : {};
    if (item.receiptImported === true || item.kvittoImported === true || item.kvittoimporterad === true) return true;
    if (text(item.receiptRowId) || /^receipt[_-]/i.test(text(item.id))) return true;
    const source = [item.source, item.historySource, item.importSource, item.kind, item.recordType]
      .map((value) => text(value).toLocaleLowerCase('sv-SE'))
      .filter(Boolean).join(' ');
    return source.includes('receipt-import') || source.includes('receipt_import') || source.includes('kvittoimport');
  }

  function isAtaHistoryItem(rawItem) {
    return !isReceiptImportedHistoryItem(rawItem) && ataApi.isEnabled(rawItem);
  }

  function historyCalendarCountLabel(entries) {
    const list = Array.isArray(entries) ? entries : [];
    if (list.length === 0) return '';
    const receiptOnly = list.every(({ item }) => isReceiptImportedHistoryItem(item));
    if (receiptOnly) return list.length === 1 ? '1 kvitto' : `${list.length} kvitton`;
    return list.length === 1 ? '1 jobb' : `${list.length} jobb`;
  }

  function historyCalendarShortDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
    const [, month, day] = value.split('-');
    return `${Number(day)}/${Number(month)}`;
  }

  function historyCalendarWeekdayLabel(date) {
    if (!(date instanceof Date) || Number.isNaN(date.getTime())) return '';
    if (date.getDay() === 0) return 'Söndag';
    const value = new Intl.DateTimeFormat('sv-SE', { weekday: 'short' }).format(date).replace('.', '');
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : '';
  }

  function currentMonthKey(date = new Date()) {
    return localDateKey(date).slice(0, 7);
  }

  function normalizedHistoryMonth(value) {
    return /^\d{4}-\d{2}$/.test(text(value)) ? text(value) : currentMonthKey();
  }

  function ensureHistoryCalendarSelection() {
    const monthInput = byId('history-month');
    const today = localDateKey(new Date());
    const todayMonth = today.slice(0, 7);
    const month = normalizedHistoryMonth(monthInput && monthInput.value ? monthInput.value : historySelectedMonth);
    historySelectedMonth = month;
    if (monthInput && monthInput.value !== month) monthInput.value = month;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(historySelectedDate) || historySelectedDate.slice(0, 7) !== month) {
      historySelectedDate = month === todayMonth ? today : `${month}-01`;
    }
    return { month, today, todayMonth };
  }

  function renderHistoryCalendar(sortedEntries) {
    const grid = byId('history-calendar-grid');
    const info = byId('history-calendar-selected-info');
    if (!grid || !info) return [];
    const { month, today } = ensureHistoryCalendarSelection();
    const [year, monthNumber] = month.split('-').map(Number);
    const first = new Date(year, monthNumber - 1, 1, 12, 0, 0);
    const firstOffset = (first.getDay() + 6) % 7;
    const lastDay = new Date(year, monthNumber, 0, 12, 0, 0).getDate();
    const entriesByDate = new Map();
    (Array.isArray(sortedEntries) ? sortedEntries : []).forEach((entry) => {
      const dateKey = historyCalendarDateKey(entry.item, entry.index);
      if (!dateKey || dateKey.slice(0, 7) !== month) return;
      if (!entriesByDate.has(dateKey)) entriesByDate.set(dateKey, []);
      entriesByDate.get(dateKey).push(entry);
    });

    const fragment = document.createDocumentFragment();
    for (let index = 0; index < firstOffset; index += 1) {
      const empty = document.createElement('div');
      empty.className = 'history-calendar-day empty';
      empty.setAttribute('aria-hidden', 'true');
      fragment.appendChild(empty);
    }
    for (let day = 1; day <= lastDay; day += 1) {
      const dateKey = `${year}-${String(monthNumber).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const date = new Date(year, monthNumber - 1, day, 12, 0, 0);
      const entries = entriesByDate.get(dateKey) || [];
      const label = historyCalendarCountLabel(entries);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'history-calendar-day';
      button.dataset.historyCalendarDate = dateKey;
      button.setAttribute('role', 'gridcell');
      button.setAttribute('aria-pressed', dateKey === historySelectedDate ? 'true' : 'false');
      button.setAttribute('aria-label', `${formatDate(dateKey) || dateKey}. ${label || 'Inga uppdrag'}.`);
      if (dateKey === historySelectedDate) button.classList.add('selected');
      if (dateKey === today) button.classList.add('is-today');
      if (entries.length > 0) button.classList.add('has-jobs');
      if (entries.some(({ item }) => isAtaHistoryItem(item))) button.classList.add('has-ata');
      const number = document.createElement('span');
      number.textContent = String(day);
      const sub = document.createElement('small');
      sub.textContent = label || historyCalendarWeekdayLabel(date);
      button.append(number, sub);
      fragment.appendChild(button);
    }
    grid.replaceChildren(fragment);

    const selected = entriesByDate.get(historySelectedDate) || [];
    const selectedLabel = historyCalendarCountLabel(selected) || 'Inga uppdrag';
    info.textContent = `Valt datum: ${historyCalendarShortDate(historySelectedDate)} · ${selectedLabel}.`;
    return selected;
  }

  function selectHistoryCalendarDate(value) {
    const dateKey = text(value);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return;
    historySelectedDate = dateKey;
    historySelectedMonth = dateKey.slice(0, 7);
    const monthInput = byId('history-month');
    if (monthInput) monthInput.value = historySelectedMonth;
    renderHistoryViews();
  }

  function showTodayInHistoryCalendar() {
    const today = localDateKey(new Date());
    historySelectedDate = today;
    historySelectedMonth = today.slice(0, 7);
    const monthInput = byId('history-month');
    if (monthInput) monthInput.value = historySelectedMonth;
    renderHistoryViews();
  }

  function createAtaUnderlagCard(rawItem, surface) {
    if (!ataMailApi || !ataMailApi.isEligible(rawItem)) return null;
    const underlag = ataMailApi.individual(rawItem, ataMailSettings().template);
    const card = document.createElement('section'); card.className = 'ata-underlag-card';
    const title = document.createElement('h4'); title.textContent = 'ÄTA-underlag';
    const recipient = document.createElement('p'); recipient.className = 'field-help'; recipient.textContent = `Till: ${ataMailApi.recipientText(underlag.recipient)}`;
    card.append(title, recipient);
    if (surface === 'today') {
      const status = document.createElement('p'); status.className = 'field-help'; status.textContent = `Status: ${ataMailApi.status(rawItem).label}`; card.appendChild(status);
    }
    const actions = document.createElement('div'); actions.className = 'ata-underlag-actions';
    const view = document.createElement('button'); view.type = 'button'; view.className = 'secondary-button'; view.textContent = surface === 'history' ? 'Visa uppdrag' : 'Visa underlag'; view.dataset.ataUnderlagView = rawItem.id; view.dataset.ataUnderlagSurface = surface; actions.appendChild(view);
    if (surface === 'today') {
      const open = document.createElement('button'); open.type = 'button'; open.className = 'primary-button'; open.textContent = 'Öppna mailutkast'; open.dataset.ataUnderlagOpen = rawItem.id;
      const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'secondary-button'; copy.textContent = 'Kopiera underlag'; copy.dataset.ataUnderlagCopy = rawItem.id;
      actions.append(open, copy);
    }
    card.appendChild(actions); return card;
  }

  function createAtaDailyCard(entries, day) {
    if (!ataMailApi) return null;
    const underlag = ataMailApi.daily(entries.map(({ item }) => item), day, ataMailSettings().supervisor);
    if (!underlag.jobs.length) return null;
    const card = document.createElement('section'); card.className = 'ata-daily-card';
    const title = document.createElement('h4'); title.textContent = 'ÄTA-dagsmail';
    const info = document.createElement('p'); info.className = 'field-help'; info.textContent = `${day} · ${underlag.jobs.length} ÄTA-uppdrag · Debiterbar tid: ${ataMailApi.minutes(underlag.totalMinutes)} · Total vikt: ${ataMailApi.decimal(underlag.totalWeight)} ton`;
    const recipient = document.createElement('p'); recipient.className = 'field-help'; recipient.textContent = `Till: ${ataMailApi.recipientText(underlag.recipient)}`;
    const actions = document.createElement('div'); actions.className = 'ata-underlag-actions';
    const view = document.createElement('button'); view.type = 'button'; view.className = 'secondary-button'; view.textContent = 'Visa dagsunderlag'; view.dataset.ataDailyView = day;
    const open = document.createElement('button'); open.type = 'button'; open.className = 'primary-button'; open.textContent = 'Öppna mailutkast'; open.dataset.ataDailyOpen = day; open.disabled = !underlag.recipient.valid;
    const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'secondary-button'; copy.textContent = 'Kopiera dagsunderlag'; copy.dataset.ataDailyCopy = day;
    actions.append(view, open, copy); card.append(title, info, recipient, actions); return card;
  }

  function createHistoryCard(rawItem, index, options = {}) {
    const item = historyItemDisplay(rawItem, index);
    const trashMode = options.mode === 'trash';
    const card = document.createElement('article');
    card.className = `queue-card history-card${trashMode ? ' trash-card' : ''}`;
    card.dataset.historyCardId = item.id;
    const heading = document.createElement('h3');
    heading.textContent = item.jobType;
    const route = document.createElement('p');
    route.className = 'queue-route';
    route.textContent = historyRouteText(item);
    const meta = document.createElement('div');
    meta.className = 'queue-meta';
    if (trashMode) {
      meta.appendChild(queueMetaChip(`Raderad: ${formatTimestamp(text(item.trashState.trashedAt))}`, 'trash-chip'));
    }
    if (item.ataEnabled) meta.appendChild(queueMetaChip('ÄTA', 'ata-chip'));
    meta.appendChild(queueMetaChip(formatTimestamp(item.completedAt)));
    meta.appendChild(queueMetaChip(durationText(item.startedAt, item.completedAt)));
    if (item.billing) meta.appendChild(queueMetaChip(`Debiterbar tid: ${ataBillingApi.formatMinutes(item.billing.minutes)}`, 'ata-chip'));
    if (item.returnPlaceName) meta.appendChild(queueMetaChip(`Retur: ${item.returnPlaceName}`));
    const historyMaterial = [text(item.material.code), text(item.material.facilityPlaceName)].filter(Boolean).join(' · ');
    if (historyMaterial) meta.appendChild(queueMetaChip(`Mtrl: ${historyMaterial}`));
    if (canonicalJobTypeId(item.jobTypeId) === 'JT-1010') {
      const roleLabel = text(rawItem && rawItem.havstangWeightRoleLabel);
      meta.appendChild(queueMetaChip(item.destinationPlaceId === 'PL-1007' ? 'Havstång: Inkörning till Bio' : 'Havstång: Badplats/mellankörning', 'model-chip'));
      if (roleLabel && item.loads.length > 0) meta.appendChild(queueMetaChip(roleLabel));
    }
    if (item.multiLoad) meta.appendChild(queueMetaChip(`Flerlass: ${item.loads.length} lass`, 'model-chip'));
    if (item.continuationCount > 0) meta.appendChild(queueMetaChip(`Fortsättning: ${item.continuationCount}`, 'model-chip'));
    if (item.loads.length > 0) meta.appendChild(queueMetaChip(`Vikt: ${item.totalWeight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`));
    else if (item.weightOutcome === 'no-emptying') meta.appendChild(queueMetaChip('Ingen tömning'));
    else if (item.weightOutcome === 'missing-confirmed') meta.appendChild(queueMetaChip('Utan vikt'));
    card.append(heading, route, meta);
    if (item.note) { const note = document.createElement('p'); note.className = 'queue-note'; note.textContent = item.note; card.appendChild(note); }
    const details = document.createElement('details');
    details.className = 'history-details';
    const summary = document.createElement('summary');
    summary.textContent = 'Visa detaljer';
    const detailGrid = document.createElement('div');
    detailGrid.className = 'history-detail-grid';
    const detailRows = [
      ['Start', formatTimestamp(item.startedAt)],
      ['Avslut', formatTimestamp(item.completedAt)],
      ['Total tid', durationText(item.startedAt, item.completedAt)],
      ['Arbetstid', formatMinutes(workMinutes(item))],
      ...(item.billing ? [['Debiterbar tid', ataBillingApi.formatMinutes(item.billing.minutes)]] : []),
      ['Lass', String(item.loads.length)],
      ['Fortsättningar', String(item.continuationCount)]
    ];
    detailRows.forEach(([label, value]) => {
      const row = document.createElement('span');
      const strong = document.createElement('strong');
      strong.textContent = `${label}: `;
      row.append(strong, document.createTextNode(value));
      detailGrid.appendChild(row);
    });
    details.append(summary, detailGrid);
    if (item.loads.length > 0) {
      const loadList = document.createElement('ol');
      loadList.className = 'history-load-list';
      item.loads.forEach((load, loadIndex) => {
        const row = document.createElement('li');
        const value = Number(isPlainObject(load) ? load.weight : load);
        row.textContent = `Lass ${loadIndex + 1}: ${Number.isFinite(value) ? value.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 }) : 'vikt saknas'}${Number.isFinite(value) ? ' ton' : ''}`;
        loadList.appendChild(row);
      });
      details.appendChild(loadList);
    }
    card.appendChild(details);

    if (!trashMode) {
      const underlagCard = createAtaUnderlagCard(rawItem, options.surface === 'today' ? 'today' : 'history');
      if (underlagCard) card.appendChild(underlagCard);
    }

    const actions = document.createElement('div');
    actions.className = 'history-actions';
    if (trashMode) {
      const restore = document.createElement('button');
      restore.type = 'button';
      restore.className = 'primary-button';
      restore.textContent = 'Återställ';
      restore.dataset.restoreHistoryTrash = item.id;
      actions.appendChild(restore);

      if (pendingTrashPermanentDeleteId !== item.id) {
        const requestPermanentDelete = document.createElement('button');
        requestPermanentDelete.type = 'button';
        requestPermanentDelete.className = 'danger-button';
        requestPermanentDelete.textContent = 'Ta bort permanent';
        requestPermanentDelete.dataset.requestHistoryPermanentDelete = item.id;
        actions.appendChild(requestPermanentDelete);
      }
      card.appendChild(actions);

      if (pendingTrashPermanentDeleteId === item.id) {
        const confirmation = document.createElement('div');
        confirmation.className = 'inline-confirm';
        const message = document.createElement('p');
        message.textContent = `Ta bort ${item.jobType}: ${historyRouteText(item)} permanent? Hela uppdraget försvinner och kan inte återställas.`;
        const confirm = document.createElement('button');
        confirm.type = 'button';
        confirm.className = 'danger-button is-solid';
        confirm.textContent = 'Bekräfta permanent radering';
        confirm.dataset.confirmHistoryPermanentDelete = item.id;
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.textContent = 'Avbryt';
        cancel.dataset.cancelHistoryPermanentDelete = item.id;
        confirmation.append(message, confirm, cancel);
        card.appendChild(confirmation);
      }
    } else if (pendingHistoryTrashId === item.id) {
      const confirmation = document.createElement('div');
      confirmation.className = 'inline-confirm';
      const message = document.createElement('p');
      message.textContent = `Flytta ${item.jobType}: ${historyRouteText(item)} till Papperskorgen? Jobbet tas bort från Idag, Historik och Sammanställning men kan återställas.`;
      const confirm = document.createElement('button');
      confirm.type = 'button';
      confirm.className = 'danger-button is-solid';
      confirm.textContent = 'Bekräfta flytt';
      confirm.dataset.confirmHistoryTrash = item.id;
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'secondary-button';
      cancel.textContent = 'Avbryt';
      cancel.dataset.cancelHistoryTrash = item.id;
      confirmation.append(message, confirm, cancel);
      card.appendChild(confirmation);
    } else if (editingHistoryBillingId === item.id) {
      const edit = document.createElement('div');
      edit.className = 'history-billing-edit';
      const label = document.createElement('label');
      label.textContent = 'Debiterbar tid i minuter';
      const input = document.createElement('input');
      input.type = 'number';
      input.inputMode = 'numeric';
      input.min = '0';
      input.step = '1';
      input.value = item.billing ? String(item.billing.minutes) : '';
      input.dataset.historyBillingInput = item.id;
      label.appendChild(input);
      const editActions = document.createElement('div');
      editActions.className = 'history-actions';
      const save = document.createElement('button');
      save.type = 'button';
      save.className = 'primary-button';
      save.textContent = 'Spara ändring';
      save.dataset.saveHistoryBilling = item.id;
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'secondary-button';
      cancel.textContent = 'Avbryt';
      cancel.dataset.cancelHistoryBilling = item.id;
      editActions.append(save, cancel);
      const status = document.createElement('p');
      status.className = 'form-status';
      status.setAttribute('role', 'status');
      status.setAttribute('aria-live', 'polite');
      status.dataset.historyBillingStatus = item.id;
      edit.append(label, editActions, status);
      card.appendChild(edit);
    } else {
      if (item.ataEnabled) {
        const editBilling = document.createElement('button');
        editBilling.type = 'button';
        editBilling.className = 'secondary-button';
        editBilling.textContent = 'Redigera avslutat jobb';
        editBilling.dataset.editHistoryBilling = item.id;
        actions.appendChild(editBilling);
      }
      const requestTrash = document.createElement('button');
      requestTrash.type = 'button';
      requestTrash.className = 'danger-button';
      requestTrash.textContent = 'Flytta till Papperskorgen';
      requestTrash.dataset.requestHistoryTrash = item.id;
      actions.appendChild(requestTrash);
      card.appendChild(actions);
    }
    return card;
  }

  function renderHistoryGroups(items, container, surface = 'history') {
    let currentDate = '';
    items.forEach(({ item, index }) => {
      const dateKey = localDateFromTimestamp(historyItemDisplay(item, index).completedAt) || 'Datum saknas';
      if (dateKey !== currentDate) {
        currentDate = dateKey;
        const heading = document.createElement('h3');
        heading.className = 'history-day-heading';
        const parsed = new Date(`${dateKey}T12:00:00`);
        heading.textContent = Number.isNaN(parsed.getTime()) ? dateKey : parsed.toLocaleDateString('sv-SE', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        container.appendChild(heading);
      }
      container.appendChild(createHistoryCard(item, index, { surface }));
    });
  }

  function addStatisticsGroup(groups, key, label, item) {
    if (!groups.has(key)) groups.set(key, { key, label, items: [] });
    groups.get(key).items.push(item);
  }

  function renderStatisticsTable(bodyId, groups, compare) {
    const body = byId(bodyId);
    body.replaceChildren();
    const rows = Array.from(groups.values()).sort(compare);
    if (rows.length === 0) {
      const row = document.createElement('tr');
      const cell = document.createElement('td');
      cell.colSpan = 5;
      cell.className = 'statistics-empty';
      cell.textContent = 'Inga poster i perioden.';
      row.appendChild(cell);
      body.appendChild(row);
      return;
    }
    rows.forEach((group) => {
      const metrics = statisticsMetrics(group.items);
      const row = document.createElement('tr');
      [
        group.label,
        String(metrics.jobs),
        String(metrics.loads),
        `${metrics.weight.toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 })} ton`,
        formatMinutes(metrics.minutes)
      ].forEach((value) => {
        const cell = document.createElement('td');
        cell.textContent = value;
        row.appendChild(cell);
      });
      body.appendChild(row);
    });
  }

  function renderStatisticsView() {
    const dateFrom = text(byId('statistics-date-from').value);
    const dateTo = text(byId('statistics-date-to').value);
    const all = activeHistoryEntries().map(({ item, index }) => historyItemDisplay(item, index));
    const displayed = all.filter((item) => {
      const dateKey = localDateFromTimestamp(item.completedAt);
      return (!dateFrom || dateKey >= dateFrom) && (!dateTo || dateKey <= dateTo);
    });
    byId('statistics-count').textContent = displayed.length === all.length ? String(all.length) : `${displayed.length}/${all.length}`;
    renderSummaryMetrics('statistics', statisticsMetrics(displayed));

    const dayGroups = new Map();
    const jobTypeGroups = new Map();
    const placeGroups = new Map();
    displayed.forEach((item) => {
      const dateKey = localDateFromTimestamp(item.completedAt) || 'Datum saknas';
      addStatisticsGroup(dayGroups, dateKey, formatDate(dateKey) || dateKey, item);
      const jobType = item.jobType || 'Jobbtyp saknas';
      addStatisticsGroup(jobTypeGroups, jobType.toLocaleLowerCase('sv-SE'), jobType, item);
      const placeNames = new Set([item.from, item.destination, item.returnRequired ? item.returnPlaceName : '']
        .filter((name) => name && name !== 'Från saknas' && name !== 'Till saknas'));
      if (placeNames.size === 0) placeNames.add('Plats saknas');
      placeNames.forEach((placeName) => addStatisticsGroup(placeGroups, placeName.toLocaleLowerCase('sv-SE'), placeName, item));
    });

    renderStatisticsTable('statistics-day-body', dayGroups, (a, b) => b.key.localeCompare(a.key, 'sv-SE'));
    renderStatisticsTable('statistics-job-type-body', jobTypeGroups, (a, b) => a.label.localeCompare(b.label, 'sv-SE'));
    renderStatisticsTable('statistics-place-body', placeGroups, (a, b) => a.label.localeCompare(b.label, 'sv-SE'));
  }

  function renderHistoryViews() {
    const todayList = byId('today-list');
    const historyList = byId('history-list');
    todayList.replaceChildren();
    historyList.replaceChildren();
    const sorted = activeHistoryEntries()
      .sort((a, b) => {
        const dateA = historyCalendarDateKey(a.item, a.index);
        const dateB = historyCalendarDateKey(b.item, b.index);
        if (dateA !== dateB) return dateB.localeCompare(dateA, 'sv-SE');
        return new Date(historyItemDisplay(b.item, b.index).completedAt).getTime() - new Date(historyItemDisplay(a.item, a.index).completedAt).getTime();
      });
    const todayKey = localDateKey(new Date());
    const todayItems = sorted.filter(({ item, index }) => historyCalendarDateKey(item, index) === todayKey && !isReceiptImportedHistoryItem(item));
    const selectedItems = renderHistoryCalendar(sorted);
    byId('today-count').textContent = String(todayItems.length);
    byId('history-count').textContent = String(selectedItems.length);
    historySummary(todayItems, 'today');

    if (todayItems.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Inga avslutade jobb idag.';
      todayList.appendChild(empty);
    } else {
      const dailyCard = createAtaDailyCard(todayItems, todayKey);
      if (dailyCard) todayList.appendChild(dailyCard);
      renderHistoryGroups(todayItems, todayList, 'today');
    }

    if (selectedItems.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = sorted.length === 0 ? 'Historiken är tom.' : 'Inga avslutade jobb eller kvittorader att visa för valt datum.';
      historyList.appendChild(empty);
    } else {
      const selectedDailyCard = createAtaDailyCard(selectedItems, historySelectedDate);
      if (selectedDailyCard) historyList.appendChild(selectedDailyCard);
      selectedItems.forEach(({ item, index }) => historyList.appendChild(createHistoryCard(item, index, { surface: 'history' })));
    }
    renderTrashView();
    renderStatisticsView();
  }

  function renderTrashView() {
    const trashList = byId('trash-list');
    const trashed = trashedHistoryEntries();
    trashList.replaceChildren();
    byId('trash-count').textContent = String(trashed.length);
    if (trashed.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Papperskorgen är tom.';
      trashList.appendChild(empty);
      return;
    }
    trashed.forEach(({ item, index }) => trashList.appendChild(createHistoryCard(item, index, { mode: 'trash' })));
  }

  function historyItemIndexById(id) {
    const key = text(id);
    return historyDocument.findIndex((item, index) => historyItemDisplay(item, index).id === key);
  }

  function historyActionSurface() {
    if (currentView === 'today') return 'today';
    if (currentView === 'settings') {
      if (activeSettingsFunction === 'statistics') return 'statistics';
      if (activeSettingsFunction === 'trash') return 'trash';
      if (activeSettingsFunction === 'history') return 'history';
    }
    const todayView = byId('view-today');
    if (todayView && todayView.hidden === false) return 'today';
    const historyPanel = byId('settings-history-panel');
    if (historyPanel && historyPanel.hidden === false) return 'history';
    const statisticsPanel = byId('settings-statistics-panel');
    if (statisticsPanel && statisticsPanel.hidden === false) return 'statistics';
    const trashPanel = byId('settings-trash-panel');
    if (trashPanel && trashPanel.hidden === false) return 'trash';
    return 'history';
  }

  function currentHistoryActionStatusId() {
    return historyStatusId(historyActionSurface());
  }

  function currentHistoryActionListSelector() {
    return historyActionSurface() === 'today'
      ? '#today-list .inline-confirm'
      : '#history-list .inline-confirm';
  }

  function currentHistoryActionContainer() {
    return historyActionSurface() === 'today' ? byId('today-list') : byId('history-list');
  }

  function historyBillingElement(id, attribute) {
    const container = currentHistoryActionContainer();
    if (!container) return null;
    return Array.from(container.querySelectorAll(`[${attribute}]`))
      .find((element) => text(element.dataset[attribute.replace(/^data-/, '').replace(/-([a-z])/g, (_, letter) => letter.toUpperCase())]) === text(id)) || null;
  }

  function requestHistoryBillingEdit(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || index < 0 || isHistoryItemTrashed(historyDocument[index]) || !ataApi.isEnabled(historyDocument[index])) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = '';
    editingHistoryBillingId = key;
    renderHistoryViews();
    revealInlineControl(`${historyActionSurface() === 'today' ? '#today-list' : '#history-list'} .history-billing-edit`, previousScrollY);
    const input = historyBillingElement(key, 'data-history-billing-input');
    if (input) {
      try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
    }
  }

  function cancelHistoryBillingEdit(id) {
    if (editingHistoryBillingId !== text(id) || historyBillingOperationId) return;
    const previousScrollY = currentScrollY();
    editingHistoryBillingId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus(currentHistoryActionStatusId(), 'Redigeringen av debiterbar tid avbröts.');
  }

  function saveHistoryBillingEdit(id) {
    const key = text(id);
    if (!key || historyBillingOperationId || editingHistoryBillingId !== key) return;
    const indexes = historyItemIndexesById(key);
    if (indexes.length !== 1) {
      showStatus(currentHistoryActionStatusId(), 'Debiterbar tid kunde inte sparas eftersom rätt historikpost inte kunde identifieras.', true);
      return;
    }
    const index = indexes[0];
    const record = historyDocument[index];
    if (isHistoryItemTrashed(record) || !ataApi.isEnabled(record)) return;
    const input = historyBillingElement(key, 'data-history-billing-input');
    const inlineStatus = historyBillingElement(key, 'data-history-billing-status');
    if (!input) {
      showStatus(currentHistoryActionStatusId(), 'Fältet för debiterbar tid saknas.', true);
      return;
    }
    const raw = String(input.value ?? '').trim();
    let updated;
    try {
      if (!raw) updated = ataBillingApi.removeFromRecord(record, new Date().toISOString());
      else if (!/^\d+$/.test(raw) || !Number.isSafeInteger(Number(raw)) || Number(raw) < 0) {
        throw new Error('Skriv ett helt antal minuter från 0 och uppåt, eller lämna fältet tomt för att ta bort tiden.');
      } else updated = ataBillingApi.editRecord(record, Number(raw), new Date().toISOString());
    } catch (error) {
      if (inlineStatus) {
        inlineStatus.textContent = error.message || 'Debiterbar tid kunde inte sparas.';
        inlineStatus.classList.add('is-error');
      }
      try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
      return;
    }

    historyBillingOperationId = key;
    try {
      const nextDocument = historyDocument.map((item, itemIndex) => itemIndex === index ? updated : item);
      const message = raw ? 'Debiterbar tid uppdaterades utan att arbetstiden ändrades.' : 'Debiterbar tid togs bort utan att arbetstiden ändrades.';
      if (!persistHistory(nextDocument, message, currentHistoryActionStatusId())) return;
      editingHistoryBillingId = '';
      renderHistoryViews();
    } finally {
      historyBillingOperationId = '';
    }
  }

  function requestHistoryTrash(id) {
    const index = historyItemIndexById(id);
    if (!canUseActiveJob() || index < 0 || isHistoryItemTrashed(historyDocument[index])) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = historyItemDisplay(historyDocument[index], index).id;
    renderHistoryViews();
    revealInlineControl(currentHistoryActionListSelector(), previousScrollY);
  }

  function cancelHistoryTrash(id) {
    if (pendingHistoryTrashId !== text(id) || historyTrashOperationId) return;
    const previousScrollY = currentScrollY();
    pendingHistoryTrashId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus(currentHistoryActionStatusId(), 'Flytten till Papperskorgen avbröts. Historiken är oförändrad.');
  }

  function historyItemIndexesById(id) {
    const key = text(id);
    const indexes = [];
    historyDocument.forEach((item, index) => {
      if (historyItemDisplay(item, index).id === key) indexes.push(index);
    });
    return indexes;
  }

  function confirmHistoryTrash(id) {
    const key = text(id);
    if (!key || historyTrashOperationId) return;
    const indexes = historyItemIndexesById(key);
    if (!canUseActiveJob() || pendingHistoryTrashId !== key || indexes.length !== 1) {
      if (indexes.length > 1) showStatus(currentHistoryActionStatusId(), 'Uppdraget kunde inte flyttas eftersom historiken innehåller flera poster med samma ID.', true);
      return;
    }
    const index = indexes[0];
    if (isHistoryItemTrashed(historyDocument[index])) return;

    historyTrashOperationId = key;
    const statusId = currentHistoryActionStatusId();
    const now = new Date().toISOString();
    const nextDocument = historyDocument.map((item, itemIndex) => itemIndex === index
      ? {
          ...item,
          trashState: {
            status: 'trashed',
            source: 'completed-job',
            trashedAt: now,
            trashedByPackageVersion: PACKAGE_VERSION
          }
        }
      : item);
    pendingHistoryTrashId = '';
    try {
      if (!persistHistory(nextDocument, 'Uppdraget flyttades till Papperskorgen.', statusId)) {
        pendingHistoryTrashId = key;
        renderHistoryViews();
      }
    } finally {
      historyTrashOperationId = '';
    }
  }

  function restoreHistoryTrash(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const nextDocument = historyDocument.map((item, itemIndex) => {
      if (itemIndex !== index) return item;
      const restored = { ...item };
      delete restored.trashState;
      return restored;
    });
    pendingTrashPermanentDeleteId = '';
    persistHistory(nextDocument, 'Uppdraget återställdes till Idag och Historik.', 'trash-load-status');
  }

  function requestHistoryPermanentDelete(id) {
    const index = historyItemIndexById(id);
    if (!canUseActiveJob() || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const previousScrollY = currentScrollY();
    pendingTrashPermanentDeleteId = historyItemDisplay(historyDocument[index], index).id;
    renderHistoryViews();
    revealInlineControl('#trash-list .inline-confirm', previousScrollY);
  }

  function cancelHistoryPermanentDelete(id) {
    if (pendingTrashPermanentDeleteId !== text(id)) return;
    const previousScrollY = currentScrollY();
    pendingTrashPermanentDeleteId = '';
    renderHistoryViews();
    preserveScrollAfterRender(previousScrollY);
    showStatus('trash-load-status', 'Den permanenta raderingen avbröts. Uppdraget finns kvar i Papperskorgen.');
  }

  function confirmHistoryPermanentDelete(id) {
    const key = text(id);
    const index = historyItemIndexById(key);
    if (!canUseActiveJob() || pendingTrashPermanentDeleteId !== key || index < 0 || !isHistoryItemTrashed(historyDocument[index])) return;
    const nextDocument = historyDocument.filter((_, itemIndex) => itemIndex !== index);
    pendingTrashPermanentDeleteId = '';
    if (!persistHistory(nextDocument, 'Uppdraget och all data i posten togs bort permanent.', 'trash-load-status')) {
      pendingTrashPermanentDeleteId = key;
      renderHistoryViews();
    }
  }

  function historyStatusId(target) {
    if (target === 'today') return 'today-load-status';
    if (target === 'statistics') return 'statistics-load-status';
    if (target === 'trash') return 'trash-load-status';
    return 'history-load-status';
  }

  function loadHistoryIfNeeded(target = 'history') {
    if (!canUseActiveJob()) {
      showStatus('role-boundary-note', 'Historik är blockerad på denna enhetsroll.', true);
      return false;
    }
    if (!historyLoaded) {
      try {
        historyDocument = readHistoryDocument();
        historyLoaded = true;
        renderHistoryViews();
      } catch (error) {
        watchdog.step('runtime.store.history.invalid', error.message || 'Historiken kunde inte läsas.', 'warning');
        showStatus(historyStatusId(target), error.message || 'Historiken kunde inte läsas.', true);
        return false;
      }
    }
    showStatus(historyStatusId(target), '');
    return true;
  }

  function persistHistory(nextDocument, successMessage, statusId = 'active-action-status') {
    const saved = window.StadslassHost.writeStore(HISTORY_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus(statusId, window.StadslassHost.getLastError() || 'Historiken kunde inte sparas.', true);
      return false;
    }
    historyDocument = nextDocument;
    historyLoaded = true;
    renderHistoryViews();
    showStatus(statusId, successMessage);
    return true;
  }

  function setAtaBillingDialogStep(step) {
    const choice = byId('ata-billing-choice-step');
    const round = byId('ata-billing-round-step');
    if (!choice || !round) return;
    const showRound = step === 'round';
    choice.hidden = showRound;
    round.hidden = !showRound;
    showStatus('ata-billing-status', '');
  }

  function ensureAtaBillingBackGuard() {
    if (ataBillingBackGuardActive || !window.history || typeof window.history.pushState !== 'function') return;
    try {
      window.history.pushState({ ...(isPlainObject(window.history.state) ? window.history.state : {}), stadslassAtaBilling: true }, '', window.location.href);
      ataBillingBackGuardActive = true;
    } catch (_) {
      ataBillingBackGuardActive = false;
    }
  }

  function releaseAtaBillingBackGuard(fromPopState = false) {
    if (!ataBillingBackGuardActive) return;
    ataBillingBackGuardActive = false;
    if (fromPopState || !window.history || typeof window.history.back !== 'function') return;
    ataBillingBackGuardClosing = true;
    try { window.history.back(); } catch (_) {}
    window.setTimeout(() => { ataBillingBackGuardClosing = false; }, 0);
  }

  function closeAtaBillingDialog(options = {}) {
    const dialog = byId('ata-billing-dialog');
    ataBillingDialogOpen = false;
    ataBillingDraft = null;
    ataBillingActionInProgress = false;
    if (dialog) {
      dialog.hidden = true;
      dialog.setAttribute('aria-hidden', 'true');
    }
    document.body.classList.remove('modal-open');
    releaseAtaBillingBackGuard(options.fromPopState === true);
    if (options.clearCandidate === true) completionCandidateAt = '';
  }

  function cancelAtaBillingDialog(options = {}) {
    if (!ataBillingDialogOpen || ataBillingActionInProgress) return;
    closeAtaBillingDialog({ fromPopState: options.fromPopState === true, clearCandidate: true });
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    renderActiveJob();
    showStatus('active-action-status', 'Avslutet avbröts. Aktivt jobb är oförändrat.');
  }

  function openAtaBillingDialog(documentValue, completedAt) {
    const timestamp = text(completedAt) || new Date().toISOString();
    const totalMinutes = ataBillingApi.totalWorkMinutes(documentValue, timestamp);
    const totalRounded = ataBillingApi.roundTotalUp(totalMinutes);
    const phaseResult = ataBillingApi.phaseWorkMinutes(documentValue, timestamp);
    const phaseOptions = ataBillingApi.halfHourOptions(phaseResult.minutes);
    ataBillingDraft = {
      completedAt: timestamp,
      totalMinutes,
      totalRounded,
      phaseMinutes: phaseResult.minutes,
      phaseFallbackUsed: phaseResult.fallbackUsed === true,
      phaseOptions
    };
    ataBillingDialogOpen = true;
    ataBillingActionInProgress = false;
    pendingActiveComplete = false;
    const dialog = byId('ata-billing-dialog');
    if (!dialog) throw new Error('Dialogen för debiterbar tid saknas.');
    byId('ata-billing-total-summary').textContent = `${ataBillingApi.formatMinutes(totalMinutes)} → ${ataBillingApi.formatMinutes(totalRounded)}`;
    const phaseChoice = byId('ata-billing-phase-choice');
    if (phaseResult.fallbackUsed) {
      byId('ata-billing-phase-summary').textContent = 'Kan inte beräknas – totaltid används';
      phaseChoice.disabled = true;
      phaseChoice.setAttribute('aria-disabled', 'true');
    } else {
      const phaseResultText = phaseOptions.exact
        ? `${ataBillingApi.formatMinutes(phaseResult.minutes)} → ${ataBillingApi.formatMinutes(phaseOptions.lower)}`
        : `${ataBillingApi.formatMinutes(phaseResult.minutes)} → ${ataBillingApi.formatMinutes(phaseOptions.lower)} eller ${ataBillingApi.formatMinutes(phaseOptions.upper)}`;
      byId('ata-billing-phase-summary').textContent = phaseResultText;
      phaseChoice.disabled = false;
      phaseChoice.setAttribute('aria-disabled', 'false');
    }
    byId('ata-billing-manual-minutes').value = '';
    byId('ata-billing-round-actions').replaceChildren();
    setAtaBillingDialogStep('choice');
    dialog.hidden = false;
    dialog.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
    ensureAtaBillingBackGuard();
    renderActiveJob();
    window.requestAnimationFrame(() => {
      const firstChoice = byId('ata-billing-total-choice');
      if (firstChoice) {
        try { firstChoice.focus({ preventScroll: true }); } catch (_) { firstChoice.focus(); }
      }
    });
  }

  function selectedAtaBillingSnapshot(mode, minutes, sourceMinutes, fallbackUsed = false) {
    return ataBillingApi.createBilling({
      minutes,
      mode,
      sourceMinutes,
      fallbackUsed,
      selectedAt: new Date().toISOString()
    });
  }

  function useAtaBillingManual() {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    const input = byId('ata-billing-manual-minutes');
    const minutes = ataBillingApi.parseCompletionManual(input ? input.value : '');
    if (minutes === null) {
      showStatus('ata-billing-status', 'Skriv ett helt antal minuter. Minsta debiterbara tid är 30 minuter.', true);
      if (input) {
        try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
      }
      return;
    }
    finalizeActiveCompletion(selectedAtaBillingSnapshot(ataBillingApi.MODES.MANUAL, minutes, minutes));
  }

  function useAtaBillingTotal() {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    finalizeActiveCompletion(selectedAtaBillingSnapshot(
      ataBillingApi.MODES.TOTAL_UP,
      ataBillingDraft.totalRounded,
      ataBillingDraft.totalMinutes
    ));
  }

  function chooseAtaBillingPhaseLevel(mode, minutes) {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    finalizeActiveCompletion(selectedAtaBillingSnapshot(
      mode,
      minutes,
      ataBillingDraft.phaseMinutes,
      ataBillingDraft.phaseFallbackUsed
    ));
  }

  function showAtaBillingPhaseRoundStep() {
    if (!ataBillingDialogOpen || ataBillingActionInProgress || !ataBillingDraft) return;
    const options = ataBillingDraft.phaseOptions;
    byId('ata-billing-round-underlag').textContent = `Underlag: ${ataBillingApi.formatMinutes(options.sourceMinutes)}. Välj debiterbar tid enligt 30-minutersregeln.`;
    const actions = byId('ata-billing-round-actions');
    actions.replaceChildren();
    if (options.exact) {
      const exact = document.createElement('button');
      exact.type = 'button';
      exact.className = 'primary-button';
      exact.textContent = `Använd ${ataBillingApi.formatMinutes(options.lower)}`;
      exact.addEventListener('click', () => chooseAtaBillingPhaseLevel(ataBillingApi.MODES.PHASES_EXACT, options.lower), { once: true });
      actions.appendChild(exact);
    } else {
      const lower = document.createElement('button');
      lower.type = 'button';
      lower.className = 'primary-button';
      lower.textContent = `Nedåt till ${ataBillingApi.formatMinutes(options.lower)}`;
      lower.addEventListener('click', () => chooseAtaBillingPhaseLevel(ataBillingApi.MODES.PHASES_DOWN, options.lower), { once: true });
      const upper = document.createElement('button');
      upper.type = 'button';
      upper.className = 'primary-button';
      upper.textContent = `Uppåt till ${ataBillingApi.formatMinutes(options.upper)}`;
      upper.addEventListener('click', () => chooseAtaBillingPhaseLevel(ataBillingApi.MODES.PHASES_UP, options.upper), { once: true });
      actions.append(lower, upper);
    }
    setAtaBillingDialogStep('round');
  }

  function activeCompletionPhase(documentValue = activeJobDocument) {
    if (isOtherActivity(documentValue)) return phaseService.PHASES.OTHER_ACTIVITY;
    return phaseService.PHASES.READY_TO_COMPLETE;
  }

  function requestActiveComplete() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) return;
    if (ataBillingDialogOpen) {
      showStatus('active-action-status', 'Välj debiterbar tid eller avbryt den öppna dialogen först.', true);
      return;
    }
    if (pendingActiveComplete || pendingWeightlessCompletion) {
      showStatus('active-action-status', 'En avslutskontroll är redan öppen. Bekräfta eller avbryt den först.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    const currentPhase = phaseService.normalizePhase(activeJobDocument.phase);
    const normalCompletionPhase = activeCompletionPhase(activeJobDocument);
    const earlyCompletion = currentPhase !== normalCompletionPhase;
    const policy = weightPolicy(activeJobDocument);
    const missingRequiredOutcome = activeJobDocument.multiLoad === true ? !currentLoadHasOutcome(activeJobDocument) : weightOutcome(activeJobDocument) === 'missing';
    if (policy.mode === 'required' && missingRequiredOutcome) {
      pendingWeightlessCompletion = true;
      renderActiveJob();
      revealInlineControl('#active-complete-without-weight-confirm', previousScrollY);
      showStatus('active-action-status', earlyCompletion
        ? `Uppdraget är i fasen ${phaseLabel(currentPhase)} och vikt saknas. Du kan registrera vikt, välja Ingen tömning eller uttryckligen avsluta ändå utan vikt.`
        : 'Vikt saknas. Registrera verklig vikt, välj Ingen tömning eller välj uttryckligen Avsluta ändå utan vikt.', true);
      return;
    }
    pendingWeightlessCompletion = false;
    completionCandidateAt = text(activeJobDocument.completedAt, completionCandidateAt || new Date().toISOString());
    pendingActiveComplete = true;
    renderActiveJob();
    revealInlineControl('#active-complete-confirm', previousScrollY);
    showStatus('active-action-status', activeJobDocument.status === 'completing'
      ? 'Bekräfta att det väntande avslutet ska slutföras.'
      : (earlyCompletion
        ? `Uppdraget är i fasen ${phaseLabel(currentPhase)}. Bekräfta om du ändå vill avsluta det.`
        : 'Bekräfta avslutet eller avbryt.'), earlyCompletion);
  }

  function cancelActiveComplete() {
    if (ataBillingDialogOpen) {
      cancelAtaBillingDialog();
      return;
    }
    const previousScrollY = currentScrollY();
    pendingActiveComplete = false;
    pendingWeightlessCompletion = false;
    completionCandidateAt = '';
    renderActiveJob();
    preserveScrollAfterRender(previousScrollY);
    showStatus('active-action-status', 'Avslutet avbröts. Aktivt jobb är oförändrat.');
  }

  function allowActiveCompleteWithoutWeight() {
    if (!pendingWeightlessCompletion || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avslut utan vikt kunde inte bekräftas.', true);
      return;
    }
    const previousScrollY = currentScrollY();
    const now = new Date().toISOString();
    const nextDocument = {
      ...activeJobDocument,
      weightMissingConfirmed: true,
      weightMissingConfirmedAt: now,
      weightOutcome: 'missing-confirmed',
      loadCycles: updateCurrentLoadCycle(activeJobDocument, { completedAt: now, outcome: 'missing-confirmed' }),
      excludeFromTimeEstimate: true,
      excludeFromEstimateLearning: true,
      learningExcludedReason: 'Avslutat utan registrerad vikt',
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'weight_missing_confirmed', now)
    };
    pendingWeightlessCompletion = false;
    if (!persistActiveJob(nextDocument, 'Avslut utan vikt är uttryckligen markerat och undantas från framtida tidsinlärning.')) return;
    completionCandidateAt = text(activeJobDocument.completedAt, now);
    pendingActiveComplete = true;
    renderActiveJob();
    revealInlineControl('#active-complete-confirm', previousScrollY);
    showStatus('active-action-status', 'Bekräfta nu att uppdraget ska avslutas och sparas i Idag och Historik.');
  }

  function completionRecordFromActive(documentValue, historyId, completedAt) {
    const completedSegments = closeOpenWorkSegment(documentValue, completedAt, 'completed');
    const phaseClosedDocument = isOtherActivity(documentValue) ? documentValue : phaseService.closeRecord(documentValue, completedAt, 'job_completed', 'manual');
    const { parkedOtherActivity: _parkedOtherActivity, ...historySource } = phaseClosedDocument;
    return normalizeJobRecord({
      ...historySource,
      workSegments: completedSegments,
      continuationCount: Math.max(0, completedSegments.length - 1),
      schemaVersion: 2,
      jobModelVersion: JOB_MODEL_VERSION,
      id: historyId,
      jobId: stableJobId(documentValue, 'history'),
      status: 'completed',
      sourceJobId: stableJobId(documentValue, 'history'),
      source: text(documentValue.source, 'local'),
      sourceQueueItemId: text(documentValue.sourceQueueItemId),
      sourceQueueSnapshot: isPlainObject(documentValue.sourceQueueSnapshot) ? documentValue.sourceQueueSnapshot : undefined,
      startedAt: text(documentValue.startedAt),
      transportStartedAt: text(documentValue.transportStartedAt),
      unloadingStartedAt: text(documentValue.unloadingStartedAt),
      completedAt,
      events: activeEvents(historySource),
      completedByPackageVersion: PACKAGE_VERSION
    }, 'history');
  }

  function confirmActiveComplete() {
    if (!pendingActiveComplete || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avslutet kunde inte bekräftas.', true);
      return;
    }
    const completedAt = text(activeJobDocument.completedAt, completionCandidateAt || new Date().toISOString());
    const existingBilling = ataBillingApi.snapshotFromRecord(activeJobDocument);
    if (ataApi.isEnabled(activeJobDocument) && !existingBilling) {
      try {
        openAtaBillingDialog(activeJobDocument, completedAt);
      } catch (error) {
        showStatus('active-action-status', error.message || 'Dialogen för debiterbar tid kunde inte öppnas.', true);
      }
      return;
    }
    finalizeActiveCompletion(existingBilling);
  }

  function finalizeActiveCompletion(billingSnapshot = null) {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists() || ataBillingActionInProgress) {
      if (ataBillingDialogOpen) showStatus('ata-billing-status', 'Avslutet kunde inte genomföras.', true);
      else showStatus('active-action-status', 'Avslutet kunde inte genomföras.', true);
      return;
    }
    const ataEnabled = ataApi.isEnabled(activeJobDocument);
    const normalizedBilling = billingSnapshot ? ataBillingApi.normalizeBilling(billingSnapshot) : ataBillingApi.snapshotFromRecord(activeJobDocument);
    if (ataEnabled && !normalizedBilling) {
      showStatus(ataBillingDialogOpen ? 'ata-billing-status' : 'active-action-status', 'Välj debiterbar tid innan ÄTA-uppdraget avslutas.', true);
      return;
    }

    ataBillingActionInProgress = true;
    const now = new Date().toISOString();
    const completedAt = text(activeJobDocument.completedAt, text(ataBillingDraft && ataBillingDraft.completedAt, completionCandidateAt || now));
    const historyId = text(activeJobDocument.completionHistoryId, `history-${text(activeJobDocument.id)}`);
    let completionSource = activeJobDocument;
    if (!isOtherActivity(completionSource)
      && phaseService.normalizePhase(completionSource.phase) !== phaseService.PHASES.READY_TO_COMPLETE) {
      completionSource = buildPhaseTransitionDocument(completionSource, phaseService.PHASES.READY_TO_COMPLETE, completedAt, 'manual_completion_override', 'manual');
    }
    if (ataEnabled && normalizedBilling) {
      completionSource = ataBillingApi.applyToRecord(completionSource, normalizedBilling, normalizedBilling.editedAt || normalizedBilling.selectedAt || now);
    }

    let completingDocument = completionSource;
    if (activeJobDocument.status !== 'completing' || !text(activeJobDocument.completionHistoryId)
      || (ataEnabled && !ataBillingApi.snapshotFromRecord(activeJobDocument))) {
      completingDocument = {
        ...completionSource,
        status: 'completing',
        completionHistoryId: historyId,
        completedAt,
        updatedAt: now,
        updatedByPackageVersion: PACKAGE_VERSION,
        events: appendActiveEvent(completionSource, 'job_completion_started', now, 'manual', ataEnabled && normalizedBilling
          ? { billableMinutes: normalizedBilling.minutes, billingMode: normalizedBilling.mode }
          : {})
      };
      pendingActiveComplete = false;
      if (!persistActiveJob(completingDocument, 'Avslutet markerades säkert före historikskrivningen.')) {
        ataBillingActionInProgress = false;
        if (ataBillingDialogOpen) showStatus('ata-billing-status', 'Debiterbar tid är vald men Aktivt jobb kunde inte sparas. Försök igen.', true);
        return;
      }
    }

    if (!loadHistoryIfNeeded('history')) {
      closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveComplete = false;
      ataBillingActionInProgress = false;
      renderActiveJob();
      showStatus('active-action-status', 'Avslutet väntar. Historiken kunde inte läsas och det aktiva uppdraget är kvar.', true);
      return;
    }

    const existingIndex = historyDocument.findIndex((item) => isPlainObject(item) && text(item.id) === historyId);
    let nextHistory = historyDocument;
    if (existingIndex < 0) {
      const record = completionRecordFromActive(completingDocument, historyId, completedAt);
      nextHistory = [...historyDocument, record];
    } else if (ataEnabled && normalizedBilling) {
      nextHistory = historyDocument.map((item, index) => index === existingIndex
        ? ataBillingApi.applyToRecord(item, normalizedBilling, normalizedBilling.editedAt || normalizedBilling.selectedAt || now)
        : item);
    }

    if (nextHistory !== historyDocument
      && !persistHistory(nextHistory, 'Det avslutade jobbet sparades i Historik.')) {
      closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveComplete = false;
      ataBillingActionInProgress = false;
      renderActiveJob();
      showStatus('active-action-status', 'Avslutet väntar. Aktivt jobb och vald debiterbar tid är bevarade och kan slutföras igen.', true);
      return;
    }

    const restoredOtherActivity = restoreOtherActivityAfterJob(completingDocument, completedAt);
    if (!persistActiveJob(restoredOtherActivity || {}, restoredOtherActivity
      ? (restoredOtherActivity.status === 'active'
        ? 'Uppdraget är avslutat och Övrig verksamhet har återupptagits automatiskt.'
        : 'Uppdraget är avslutat. Manuellt pausad Övrig verksamhet är bevarad utan automatisk återstart.')
      : 'Uppdraget är avslutat och Aktivt jobb är tömt.')) {
      closeAtaBillingDialog({ clearCandidate: true });
      pendingActiveComplete = false;
      ataBillingActionInProgress = false;
      renderActiveJob();
      showStatus('active-action-status', 'Historiken är sparad, men Aktivt jobb kunde inte växlas säkert. Tryck Slutför avslut igen.', true);
      return;
    }
    pendingActiveComplete = false;
    completionCandidateAt = '';
    closeAtaBillingDialog({ clearCandidate: true });
    ataBillingActionInProgress = false;
    if (restoredOtherActivity) {
      activateView('queue');
      showStatus('queue-load-status', restoredOtherActivity.status === 'active'
        ? 'Uppdraget sparades i Historik och Övrig verksamhet fortsätter automatiskt.'
        : 'Uppdraget sparades i Historik. Övrig verksamhet är fortsatt manuellt pausad.');
    } else {
      activateView('queue');
      showStatus('queue-load-status', 'Uppdraget avslutades och sparades i Idag och Historik.');
      if (ataEnabled) {
        // Mail is deliberately opened only after history and active-job writes have both succeeded.
        openIndividualUnderlag(historyId, 'completion');
      }
    }
  }

  function refreshUpdateStatus() {
    if (runtimeDisposed || runtimeFailed || !bridgeAvailable()) return;
    const element = byId('update-status');
    if (!element) return;
    const textValue = window.StadslassHost.getUpdateStatus();
    element.textContent = textValue || (hostInfo && hostInfo.updateStatus) || 'Ingen uppdateringsstatus tillgänglig.';
  }

  function requestUpdateCheck() {
    if (runtimeDisposed || runtimeFailed || !bridgeAvailable()) return;
    const element = byId('update-status');
    if (element) element.textContent = 'Söker efter funktionsuppdatering…';
    window.StadslassHost.requestUpdateCheck();
    window.setTimeout(() => {
      if (!runtimeDisposed && !runtimeFailed) refreshUpdateStatus();
    }, 250);
  }

  function installEventHandlers() {
    byId('open-queue').addEventListener('click', () => activateView('queue'));
    byId('open-active-job').addEventListener('click', () => activateView('active'));
    byId('open-today').addEventListener('click', () => activateView('today'));
    byId('history-month').addEventListener('change', (event) => {
      historySelectedMonth = normalizedHistoryMonth(event.currentTarget.value);
      historySelectedDate = '';
      renderHistoryViews();
    });
    byId('history-calendar-today').addEventListener('click', showTodayInHistoryCalendar);
    byId('history-calendar-grid').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-history-calendar-date]');
      if (button) selectHistoryCalendarDate(button.dataset.historyCalendarDate || '');
    });
    byId('statistics-date-from').addEventListener('change', renderStatisticsView);
    byId('statistics-date-to').addEventListener('change', renderStatisticsView);
    byId('statistics-clear-filters').addEventListener('click', () => {
      byId('statistics-date-from').value = '';
      byId('statistics-date-to').value = '';
      renderStatisticsView();
    });
    const handleHistoryAction = (event) => {
      const underlagView = event.target.closest('button[data-ata-underlag-view]');
      const underlagOpen = event.target.closest('button[data-ata-underlag-open]');
      const underlagCopy = event.target.closest('button[data-ata-underlag-copy]');
      const dailyView = event.target.closest('button[data-ata-daily-view]');
      const dailyOpen = event.target.closest('button[data-ata-daily-open]');
      const dailyCopy = event.target.closest('button[data-ata-daily-copy]');
      const editBilling = event.target.closest('button[data-edit-history-billing]');
      const saveBilling = event.target.closest('button[data-save-history-billing]');
      const cancelBilling = event.target.closest('button[data-cancel-history-billing]');
      const requestTrash = event.target.closest('button[data-request-history-trash]');
      const confirmTrash = event.target.closest('button[data-confirm-history-trash]');
      const cancelTrash = event.target.closest('button[data-cancel-history-trash]');
      const restoreTrash = event.target.closest('button[data-restore-history-trash]');
      const requestPermanentDelete = event.target.closest('button[data-request-history-permanent-delete]');
      const confirmPermanentDelete = event.target.closest('button[data-confirm-history-permanent-delete]');
      const cancelPermanentDelete = event.target.closest('button[data-cancel-history-permanent-delete]');
      if (underlagView) {
        openIndividualUnderlag(underlagView.dataset.ataUnderlagView || '', underlagView.dataset.ataUnderlagSurface === 'history' ? 'history' : 'today');
      } else if (underlagOpen) {
        openIndividualUnderlag(underlagOpen.dataset.ataUnderlagOpen || '', 'today');
        handleAtaMailOpen();
      } else if (underlagCopy) {
        openIndividualUnderlag(underlagCopy.dataset.ataUnderlagCopy || '', 'today');
        handleAtaMailCopy();
      } else if (dailyView) {
        openDailyUnderlag(dailyView.dataset.ataDailyView || '');
      } else if (dailyOpen) {
        openDailyUnderlag(dailyOpen.dataset.ataDailyOpen || '');
        handleAtaMailOpen();
      } else if (dailyCopy) {
        openDailyUnderlag(dailyCopy.dataset.ataDailyCopy || '');
        handleAtaMailCopy();
      } else if (editBilling) {
        requestHistoryBillingEdit(editBilling.dataset.editHistoryBilling || '');
      } else if (saveBilling) {
        saveHistoryBillingEdit(saveBilling.dataset.saveHistoryBilling || '');
      } else if (cancelBilling) {
        cancelHistoryBillingEdit(cancelBilling.dataset.cancelHistoryBilling || '');
      } else if (requestTrash) {
        requestHistoryTrash(requestTrash.dataset.requestHistoryTrash || '');
      } else if (confirmTrash) {
        confirmHistoryTrash(confirmTrash.dataset.confirmHistoryTrash || '');
      } else if (cancelTrash) {
        cancelHistoryTrash(cancelTrash.dataset.cancelHistoryTrash || '');
      } else if (restoreTrash) {
        restoreHistoryTrash(restoreTrash.dataset.restoreHistoryTrash || '');
      } else if (requestPermanentDelete) {
        requestHistoryPermanentDelete(requestPermanentDelete.dataset.requestHistoryPermanentDelete || '');
      } else if (confirmPermanentDelete) {
        confirmHistoryPermanentDelete(confirmPermanentDelete.dataset.confirmHistoryPermanentDelete || '');
      } else if (cancelPermanentDelete) {
        cancelHistoryPermanentDelete(cancelPermanentDelete.dataset.cancelHistoryPermanentDelete || '');
      }
    };
    byId('today-list').addEventListener('click', handleHistoryAction);
    byId('history-list').addEventListener('click', handleHistoryAction);
    byId('trash-list').addEventListener('click', handleHistoryAction);
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      button.addEventListener('click', () => activateView(button.dataset.target));
    });
    document.querySelectorAll('.settings-group-button[data-settings-group]').forEach((button) => {
      button.addEventListener('click', () => toggleSettingsGroup(button.dataset.settingsGroup));
    });
    document.querySelectorAll('.settings-function-button[data-settings-function]').forEach((button) => {
      button.addEventListener('click', () => toggleSettingsFunction(button.dataset.settingsGroupOwner, button.dataset.settingsFunction));
    });
    byId('settings-form').addEventListener('submit', saveSettings);
    byId('google-service-form').addEventListener('submit', saveGoogleSettings);
    byId('machine-registry-form').addEventListener('submit', saveMachineRegistry);
    byId('machine-registry-cancel').addEventListener('click', () => { byId('machine-registry-form').reset(); byId('machine-registry-edit-id').value=''; byId('machine-registry-cancel').hidden=true; });
    byId('machine-registry-list').addEventListener('click', handleMachineRegistryAction);
    byId('google-service-clear').addEventListener('click', clearGoogleSettings);
    byId('quick-choice-registry-form').addEventListener('submit', saveQuickChoice);
    byId('quick-choice-registry-cancel').addEventListener('click', () => {
      resetQuickChoiceEditor();
      showStatus('quick-choice-registry-status', 'Redigeringen avbröts.');
    });
    byId('quick-choice-registry-job-type').addEventListener('change', () => {
      const selected = findJobTypeById(byId('quick-choice-registry-job-type').value);
      const nameInput = byId('quick-choice-registry-button-name');
      if (!nameInput.value || nameInput.dataset.autoSuggested === 'true') {
        nameInput.value = text(selected && selected.name);
        nameInput.dataset.autoSuggested = 'true';
      }
      populateQuickChoicePlaceOptions();
      syncQuickChoiceFormControls();
      syncAtaForm('quick', true);
    });
    byId('quick-choice-registry-button-name').addEventListener('input', (event) => {
      event.currentTarget.dataset.autoSuggested = 'false';
    });
    byId('quick-choice-registry-from').addEventListener('change', () => {
      const suggested = jobModel.suggestedDestination(byId('quick-choice-registry-job-type').value, byId('quick-choice-registry-from').value);
      if (suggested && !byId('quick-choice-registry-to').value) byId('quick-choice-registry-to').value = suggested;
      if (byId('quick-choice-registry-return-required').checked) byId('quick-choice-registry-return').value = byId('quick-choice-registry-from').value;
      syncQuickChoiceFormControls();
    });
    byId('quick-choice-registry-return-required').addEventListener('change', () => syncQuickChoiceFormControls('return'));
    byId('quick-choice-registry-multi-load').addEventListener('change', () => syncQuickChoiceFormControls('multi'));
    byId('quick-choice-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-quick-choice]');
      const remove = event.target.closest('button[data-remove-quick-choice]');
      if (edit) editQuickChoice(edit.dataset.editQuickChoice || '');
      else if (remove) removeQuickChoice(remove.dataset.removeQuickChoice || '');
    });
    byId('ata-notification-supervisor-form').addEventListener('submit', (event) => {
      event.preventDefault();
      try {
        const next = ataNotificationApi.updateSupervisor(ataNotificationSettings(), { name: byId('ata-notification-supervisor-name').value, email: byId('ata-notification-supervisor-email').value });
        if (persistAtaNotificationSettings(next, 'ata-notification-supervisor-status', 'Arbetsledare för dagsmail sparad lokalt.')) renderAtaNotificationSettings();
      } catch (error) { showStatus('ata-notification-supervisor-status', error.message || 'Arbetsledaren kunde inte sparas.', true); }
    });
    byId('ata-notification-supervisor-clear').addEventListener('click', () => {
      if (!ataNotificationSettings().supervisor) return;
      setAtaNotificationConfirmation('Rensa sparad arbetsledare för dagsmail?', 'Bekräfta rensning', () => { const next = { ...ataNotificationSettings(), supervisor: null }; if (persistAtaNotificationSettings(next, 'ata-notification-supervisor-status', 'Arbetsledare för dagsmail har rensats.')) { renderAtaNotificationSettings(); clearAtaNotificationConfirmation(); } }, 'ata-notification-supervisor-status');
    });
    byId('ata-notification-contact-form').addEventListener('submit', saveAtaNotificationContact);
    byId('ata-notification-contact-reset').addEventListener('click', () => resetAtaNotificationContactForm('Formuläret är rensat.'));
    byId('ata-notification-contact-list').addEventListener('click', handleAtaNotificationContactList);
    byId('ata-notification-template-fields').addEventListener('change', scheduleAtaNotificationTemplateSave);
    byId('ata-notification-template-closing').addEventListener('input', scheduleAtaNotificationTemplateSave);
    byId('ata-notification-template-reset').addEventListener('click', () => setAtaNotificationConfirmation('Återställ standardmallen? Dina mallval och den fria avslutningstexten återställs.', 'Återställ standardmall', () => { const next = ataNotificationApi.updateTemplate(ataNotificationSettings(), ataNotificationApi.defaultTemplate()); if (persistAtaNotificationSettings(next, 'ata-notification-template-status', 'Mailmall sparad lokalt. 12 av 12 standardfält är aktiva.')) { renderAtaNotificationSettings(); clearAtaNotificationConfirmation(); } }, 'ata-notification-template-status'));
    byId('ata-notification-confirm-accept').addEventListener('click', () => { const action = ataNotificationPendingAction; if (typeof action === 'function') action(); });
    byId('ata-notification-confirm-cancel').addEventListener('click', clearAtaNotificationConfirmation);
    byId('quick-choice-groups').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-use-quick-choice]');
      if (button) useQuickChoice(button.dataset.useQuickChoice || '');
    });
    document.querySelectorAll('input[name="quickChoiceMode"]').forEach((input) => {
      input.addEventListener('change', () => {
        clearQuickChoiceFallbackState({ clearStatus: true });
      });
    });
    byId('quick-choice-fallback-queue').addEventListener('click', queuePendingQuickChoiceFallback);
    byId('quick-choice-fallback-cancel').addEventListener('click', cancelQuickChoiceFallback);
    byId('job-type-registry-form').addEventListener('submit', saveEditableJobType);
    byId('job-type-registry-ata-enabled').addEventListener('change', () => syncAtaForm('jobtype', false));
    byId('job-type-registry-cancel').addEventListener('click', () => {
      resetEditableJobTypeEditor();
      showStatus('job-type-registry-status', 'Redigeringen avbröts.');
    });
    byId('job-type-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-job-type-registry]');
      const remove = event.target.closest('button[data-remove-job-type-registry]');
      if (edit) {
        editEditableJobType(edit.dataset.editJobTypeRegistry || '');
      } else if (remove) {
        removeEditableJobType(remove.dataset.removeJobTypeRegistry || '');
      }
    });
    byId('place-registry-form').addEventListener('submit', saveEditablePlace);
    byId('place-registry-cancel').addEventListener('click', () => {
      resetEditablePlaceEditor();
      showStatus('place-registry-status', 'Redigeringen avbröts.');
    });
    byId('place-registry-geofence-enabled').addEventListener('change', updateEditablePlaceGeofenceVisibility);
    byId('place-registry-geofence-type').addEventListener('change', updateEditablePlaceGeofenceVisibility);
    byId('place-registry-clear-geofence').addEventListener('click', () => { resetPlaceGeofenceForm(); updateEditablePlaceGeofenceVisibility(); showStatus('place-registry-status', 'Geofenceformuläret är rensat. Ändringen sparas först när du väljer Spara ändringar.'); });
    byId('place-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-place-registry]');
      const remove = event.target.closest('button[data-remove-place-registry]');
      if (edit) {
        editEditablePlace(edit.dataset.editPlaceRegistry || '');
      } else if (remove) {
        removeEditablePlace(remove.dataset.removePlaceRegistry || '');
      }
    });
    byId('beach-registry-form').addEventListener('submit', saveEditableBeach);
    byId('beach-registry-geofence-enabled').addEventListener('change', updateEditableBeachGeofenceVisibility);
    byId('beach-registry-geofence-type').addEventListener('change', updateEditableBeachGeofenceVisibility);
    byId('beach-registry-save-geofence').addEventListener('click', saveEditableBeachGeofence);
    byId('beach-registry-clear-geofence').addEventListener('click', () => { resetBeachGeofenceForm(); updateEditableBeachGeofenceVisibility(); showStatus('beach-registry-status', 'Geofenceformuläret är rensat. Ändringen sparas först när du väljer Spara geofence eller sparar badplatsen.'); });
    byId('beach-registry-cancel').addEventListener('click', () => {
      resetEditableBeachEditor();
      showStatus('beach-registry-status', 'Redigeringen avbröts.');
    });
    byId('beach-registry-list').addEventListener('click', (event) => {
      const edit = event.target.closest('button[data-edit-beach-registry]');
      const toggle = event.target.closest('button[data-toggle-beach-registry]');
      const remove = event.target.closest('button[data-remove-beach-registry]');
      if (edit) {
        editEditableBeach(edit.dataset.editBeachRegistry || '');
      } else if (toggle) {
        toggleEditableBeach(toggle.dataset.toggleBeachRegistry || '');
      } else if (remove) {
        removeEditableBeach(remove.dataset.removeBeachRegistry || '');
      }
    });
    byId('increment-test').addEventListener('click', incrementPreservedTestValue);
    byId('check-update').addEventListener('click', requestUpdateCheck);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());
    byId('copy-watchdog').addEventListener('click', () => watchdog.copyReport(byId('watchdog-copy-status')));
    byId('gps-retry').addEventListener('click', () => {
      showStatus('gps-retry-status', 'GPS försöker igen.');
      gpsService.retry();
    });
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flushAtaNotificationTemplate(); });
    window.addEventListener('pagehide', flushAtaNotificationTemplate);
    byId('queue-form').addEventListener('submit', createQueueItem);
    byId('queue-cancel-edit').addEventListener('click', cancelQueueEdit);
    byId('job-type').addEventListener('change', () => { refreshPlaceFormsForJobType(''); updateMaterialPanel(''); syncJobModeControls('queue'); syncAtaForm('queue', true); });
    byId('job-machine').addEventListener('change', () => { refreshPlaceFormsForJobType(''); syncJobModeControls('queue'); });
    byId('job-from').addEventListener('change', () => { applySuggestedDestination(''); updateMaterialPanel(''); syncJobModeControls('queue'); syncTemporaryPlacePanels('queue'); });
    byId('job-destination').addEventListener('change', () => { updateMaterialPanel(''); syncTemporaryPlacePanels('queue'); });
    byId('job-return-required').addEventListener('change', () => syncJobModeControls('queue', 'return'));
    byId('job-multi-load').addEventListener('change', () => syncJobModeControls('queue', 'multi'));
    byId('active-job-type').addEventListener('change', () => { refreshPlaceFormsForJobType('active-'); updateMaterialPanel('active-'); syncJobModeControls('active'); syncAtaForm('active', true); });
    byId('active-job-machine').addEventListener('change', () => { refreshPlaceFormsForJobType('active-'); syncJobModeControls('active'); });
    ['queue', 'active', 'quick', 'jobtype'].forEach((scope) => {
      const ids = ataRecipientIds(scope);
      if (byId(ids.toggle)) byId(ids.toggle).addEventListener('change', () => syncAtaForm(scope, false));
      if (byId(ids.contact)) byId(ids.contact).addEventListener('change', () => selectAtaRecipientContact(scope));
      if (byId(ids.clear)) byId(ids.clear).addEventListener('click', () => clearAtaRecipient(scope));
    });
    byId('active-job-from').addEventListener('change', () => { applySuggestedDestination('active-'); updateMaterialPanel('active-'); syncJobModeControls('active'); syncTemporaryPlacePanels('active'); });
    byId('active-job-destination').addEventListener('change', () => { updateMaterialPanel('active-'); syncTemporaryPlacePanels('active'); });
    byId('active-job-return-required').addEventListener('change', () => syncJobModeControls('active', 'return'));
    byId('active-job-multi-load').addEventListener('change', () => syncJobModeControls('active', 'multi'));
    for (const scope of ['queue', 'active']) {
      for (const role of ['from', 'destination']) {
        const elements = temporaryFormElements(scope, role);
        elements.name.addEventListener('input', () => temporaryPlaceNameChanged(scope, role));
        elements.address.addEventListener('input', () => temporaryPlaceAddressChanged(scope, role));
        elements.check.addEventListener('click', () => checkTemporaryPlace(scope, role));
        elements.clear.addEventListener('click', () => clearTemporaryPlace(scope, role));
      }
    }
    byId('queue-list').addEventListener('click', (event) => {
      const transferButton = event.target.closest('button[data-prepare-queue-transfer]');
      const startButton = event.target.closest('button[data-start-queue-item]');
      const editButton = event.target.closest('button[data-edit-queue-item]');
      const requestButton = event.target.closest('button[data-request-queue-delete]');
      const confirmButton = event.target.closest('button[data-confirm-queue-delete]');
      const cancelButton = event.target.closest('button[data-cancel-queue-delete]');
      if (transferButton) {
        prepareQueueTransfer(transferButton.dataset.prepareQueueTransfer || '');
      } else if (startButton) {
        startQueueItem(startButton.dataset.startQueueItem || '');
      } else if (editButton) {
        editQueueItem(editButton.dataset.editQueueItem || '');
      } else if (requestButton) {
        requestQueueDelete(requestButton.dataset.requestQueueDelete || '');
      } else if (confirmButton) {
        confirmQueueDelete(confirmButton.dataset.confirmQueueDelete || '');
      } else if (cancelButton) {
        cancelQueueDelete(cancelButton.dataset.cancelQueueDelete || '');
      }
    });
    byId('sync-outbox-list').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-show-transfer-entry]');
      if (!button) return;
      const entry = syncOutboxDocument.find((candidate) => text(candidate.id) === text(button.dataset.showTransferEntry));
      showTransferEntry(entry);
    });
    byId('sync-copy-export').addEventListener('click', () => copyTextareaValue('sync-export-text', 'sync-export-status'));
    byId('backup-export').addEventListener('click', backupExport);
    byId('backup-import').addEventListener('click', backupPickImport);
    byId('backup-confirm').addEventListener('click', backupConfirmImport);
    byId('backup-cancel').addEventListener('click', () => { pendingBackupPreview=null; byId('backup-preview').hidden=true; showStatus('backup-status','Importen avbröts. Ingen data ändrades.'); });
    byId('sync-import-receipt').addEventListener('click', registerReceiptOnMobile);
    byId('sync-validate-transfer').addEventListener('click', validateInboundTransfer);
    byId('sync-confirm-import').addEventListener('click', confirmInboundTransfer);
    byId('sync-cancel-import').addEventListener('click', cancelInboundTransfer);
    byId('sync-copy-receipt').addEventListener('click', () => copyTextareaValue('sync-receipt-output', 'sync-receipt-copy-status'));
    byId('sync-v63-config-form').addEventListener('submit', saveSyncV63Configuration);
    byId('sync-v63-check').addEventListener('click', checkSyncV63Connection);
    byId('sync-v63-clear').addEventListener('click', clearSyncV63Configuration);
    byId('sync-v63-now').addEventListener('click', syncV87ManualSyncNow);
    byId('sync-v87-clear').addEventListener('click', requestSyncV87Clear);
    byId('sync-v87-clear-confirm-button').addEventListener('click', confirmSyncV87Clear);
    byId('sync-v87-clear-cancel').addEventListener('click', cancelSyncV87Clear);
    byId('report-mail-save').addEventListener('click', saveReportMailRecipient);
    byId('performance-monitor-start-new').addEventListener('click', startNewPerformanceTest);
    byId('performance-monitor-stop').addEventListener('click', stopPerformanceMonitor);
    byId('performance-report-copy').addEventListener('click', () => copyStoredReport('performance'));
    byId('performance-report-download').addEventListener('click', () => downloadStoredReport('performance'));
    byId('performance-report-mail').addEventListener('click', () => mailStoredReport('performance'));
    byId('performance-report-clear').addEventListener('click', () => clearReportView('performance'));
    byId('sync-diagnostic-rerun').addEventListener('click', runSyncDiagnosticInventory);
    byId('sync-report-copy').addEventListener('click', () => copyStoredReport('sync'));
    byId('sync-report-download').addEventListener('click', () => downloadStoredReport('sync'));
    byId('sync-report-mail').addEventListener('click', () => mailStoredReport('sync'));
    byId('sync-report-clear').addEventListener('click', () => clearReportView('sync'));
    document.querySelectorAll('button[data-sync-v63-demand]').forEach((button) => button.addEventListener('click', () => syncV63RequestOnDemand(button.dataset.syncV63Demand || '')));
    window.addEventListener('stadslass:sync-result', (event) => {
      const detail = event && event.detail ? event.detail : {};
      syncV63HandleResult(text(detail.requestId), detail);
    });
    window.addEventListener('stadslass:text-export-result', (event) => {
      const detail = event && event.detail ? event.detail : {};
      const requestId = text(detail.requestId);
      const exportInfo = liveReportExports.get(requestId);
      if (exportInfo) {
        liveReportExports.delete(requestId);
        renderLiveReportExportState();
        const statusId = exportInfo.type === 'performance' ? 'performance-report-status' : 'sync-diagnostic-status';
        const label = exportInfo.type === 'performance' ? 'Prestandarapport' : 'Synkrapport';
        if (detail.status === 'saved') showStatus(statusId, `${label} sparad.`);
        else if (detail.status === 'cancelled') showStatus(statusId, `Sparningen av ${label.toLowerCase()} avbröts. Rapporten ligger kvar.`);
        else if (detail.status === 'write_error') showStatus(statusId, `${label} kunde inte sparas. Rapporten ligger kvar.`, true);
        return;
      }
      if (detail.status === 'saved') showStatus('sync-reader-status', 'Syncrapporten är sparad. Loggen nollställs inte.');
      else if (detail.status === 'cancelled') showStatus('sync-reader-status', 'Sparningen avbröts. Syncläsaren är oförändrad.');
      else if (detail.status === 'write_error') showStatus('sync-reader-status', 'Syncrapporten kunde inte skrivas. Syncläsaren är oförändrad.', true);
    });
    window.addEventListener('stadslass:text-import-result', (event) => {
      const detail = event && event.detail ? event.detail : {};
      if (detail.status === 'selected') backupPrepareImport(detail.contentUtf8 || '');
      else if (detail.status === 'cancelled') showStatus('backup-status','Valet av backupfil avbröts.');
      else if (detail.status === 'read_error') showStatus('backup-status','Backupfilen kunde inte läsas.',true);
    });
    // v85: återgång till appen får inte kringgå 60-minutersskyddet.
    window.addEventListener('focus', () => renderSyncV63());
    byId('active-form').addEventListener('submit', createActiveJob);
    byId('active-phase-action').addEventListener('click', advanceActivePhase);
    byId('active-pause-action').addEventListener('click', toggleActivePause);
    byId('active-weight-submit').addEventListener('click', registerActiveWeight);
    byId('active-no-emptying').addEventListener('click', markActiveNoEmptying);
    byId('active-weight-input').addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === 'NumpadEnter') {
        event.preventDefault();
        if (registerActiveWeight()) {
          event.currentTarget.blur();
        }
      }
    });
    byId('active-complete-request').addEventListener('click', requestActiveComplete);
    byId('active-complete-without-weight').addEventListener('click', allowActiveCompleteWithoutWeight);
    byId('active-complete-without-weight-cancel').addEventListener('click', cancelActiveComplete);
    byId('active-complete-cancel').addEventListener('click', cancelActiveComplete);
    byId('active-complete-confirm-button').addEventListener('click', confirmActiveComplete);
    byId('ata-mail-open').addEventListener('click', handleAtaMailOpen);
    byId('ata-mail-copy').addEventListener('click', handleAtaMailCopy);
    byId('ata-mail-skip').addEventListener('click', handleAtaMailSkip);
    byId('ata-mail-close').addEventListener('click', closeAtaMailDialog);
    byId('ata-billing-save-manual').addEventListener('click', useAtaBillingManual);
    byId('ata-billing-phase-choice').addEventListener('click', showAtaBillingPhaseRoundStep);
    byId('ata-billing-total-choice').addEventListener('click', useAtaBillingTotal);
    byId('ata-billing-cancel').addEventListener('click', () => cancelAtaBillingDialog());
    byId('ata-billing-round-back').addEventListener('click', () => setAtaBillingDialogStep('choice'));
    byId('ata-billing-round-cancel').addEventListener('click', () => cancelAtaBillingDialog());
    byId('ata-billing-manual-minutes').addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === 'NumpadEnter') {
        event.preventDefault();
        useAtaBillingManual();
      }
    });
    window.addEventListener('popstate', () => {
      if (ataBillingBackGuardClosing) {
        ataBillingBackGuardClosing = false;
        return;
      }
      if (ataBillingDialogOpen) {
        ataBillingBackGuardActive = false;
        cancelAtaBillingDialog({ fromPopState: true });
      }
      if (ataMailDialogContext) closeAtaMailDialog();
    });
    window.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && ataBillingDialogOpen) {
        event.preventDefault();
        cancelAtaBillingDialog();
      }
      if (event.key === 'Escape' && ataMailDialogContext) { event.preventDefault(); closeAtaMailDialog(); }
    });
    document.addEventListener('backbutton', (event) => {
      if (ataBillingDialogOpen) {
        event.preventDefault();
        cancelAtaBillingDialog();
      }
      if (ataMailDialogContext) { event.preventDefault(); closeAtaMailDialog(); }
    });
    byId('active-reset-request').addEventListener('click', requestActiveReset);
    byId('active-reset-cancel').addEventListener('click', cancelActiveReset);
    byId('active-reset-confirm-button').addEventListener('click', confirmActiveReset);
  }

  function verifyRuntime() {
    if (!watchdog) {
      throw new Error('Runtime-Watchdog saknas.');
    }
    watchdog.step('runtime.bootstrap.verify', 'Värdbrygga, CSS och versionskontrakt verifieras.');
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    if (!syncProtocol || typeof syncProtocol.createTransfer !== 'function' || typeof syncProtocol.parseReceipt !== 'function') {
      throw new Error('Modulen för kontrollerad överföring saknas.');
    }
    if (!syncServiceApi || typeof syncServiceApi.create !== 'function' || typeof syncServiceApi.hostCapabilities !== 'function') {
      throw new Error('Den gemensamma synctjänsten saknas.');
    }
    if (!syncDiagnosticApi || typeof syncDiagnosticApi.create !== 'function') {
      throw new Error('Den läsande synkdiagnosen saknas.');
    }
    if (!ataApi
      || typeof ataApi.normalizeSnapshot !== 'function'
      || typeof ataApi.snapshotFromRecord !== 'function'
      || typeof ataApi.isEnabled !== 'function'
      || typeof ataApi.createManual !== 'function'
      || typeof ataApi.createFromQuickChoice !== 'function'
      || typeof ataApi.editSnapshot !== 'function'
      || typeof ataApi.display !== 'function') {
      throw new Error('Den gemensamma ÄTA-modulen saknas.');
    }
    if (!ataBillingApi
      || typeof ataBillingApi.snapshotFromRecord !== 'function'
      || typeof ataBillingApi.createBilling !== 'function'
      || typeof ataBillingApi.totalWorkMinutes !== 'function'
      || typeof ataBillingApi.phaseWorkMinutes !== 'function'
      || typeof ataBillingApi.roundTotalUp !== 'function'
      || typeof ataBillingApi.halfHourOptions !== 'function'
      || typeof ataBillingApi.editRecord !== 'function') {
      throw new Error('Modulen för debiterbar ÄTA-tid saknas.');
    }
    if (!ataRouting
      || typeof ataRouting.isManualJobType !== 'function'
      || typeof ataRouting.jobAtaSnapshot !== 'function'
      || typeof ataRouting.recipientForSave !== 'function'
      || typeof ataRouting.propagateRecipient !== 'function') {
      throw new Error('Den gemensamma ÄTA-styrningen saknas.');
    }
    if (!ataNotificationApi
      || typeof ataNotificationApi.settingsFromDocument !== 'function'
      || typeof ataNotificationApi.documentWithSettings !== 'function'
      || typeof ataNotificationApi.saveContact !== 'function'
      || typeof ataNotificationApi.canonicalMatch !== 'function'
      || typeof ataNotificationApi.applyIncoming !== 'function') {
      throw new Error('Modulen för ÄTA avisering saknas.');
    }
    if (!ataMailApi
      || typeof ataMailApi.isEligible !== 'function'
      || typeof ataMailApi.individual !== 'function'
      || typeof ataMailApi.daily !== 'function'
      || typeof ataMailApi.withStatus !== 'function') {
      throw new Error('Modulen för ÄTA-underlag saknas.');
    }
    if (!quickChoiceApi
      || typeof quickChoiceApi.migrateRegistry !== 'function'
      || typeof quickChoiceApi.validateRegistry !== 'function'
      || typeof quickChoiceApi.createItem !== 'function'
      || typeof quickChoiceApi.updateItem !== 'function'
      || typeof quickChoiceApi.removeItem !== 'function'
      || typeof quickChoiceApi.referenceStatus !== 'function'
      || typeof quickChoiceApi.resolveJobTypeReference !== 'function') {
      throw new Error('Modulen för Snabbvalsregistret saknas.');
    }
    if (!editableJobTypeApi
      || typeof editableJobTypeApi.validateRegistry !== 'function'
      || typeof editableJobTypeApi.createItem !== 'function'
      || typeof editableJobTypeApi.removeItem !== 'function'
      || typeof editableJobTypeApi.migrateAndMergeRegistry !== 'function'
      || typeof editableJobTypeApi.removeFromRegistry !== 'function'
      || typeof editableJobTypeApi.resolveReference !== 'function') {
      throw new Error('Modulen för det redigerbara jobbtypsregistret saknas.');
    }
    if (!googleService
      || typeof googleService.validateSettings !== 'function'
      || typeof googleService.maskApiKey !== 'function'
      || typeof googleService.geocode !== 'function'
      || typeof googleService.reverseGeocode !== 'function'
      || typeof googleService.diagnosticFromError !== 'function'
      || typeof googleService.appendDiagnostic !== 'function'
      || typeof googleService.errorStatus !== 'function'
      || typeof googleService.userMessageForError !== 'function'
      || typeof googleService.pendingGeocoding !== 'function'
      || typeof googleService.resolvedGeocoding !== 'function'
      || typeof googleService.failedGeocoding !== 'function') {
      throw new Error('Den gemensamma Google-tjänsten saknas.');
    }
    if (!editablePlaceApi
      || typeof editablePlaceApi.validateRegistry !== 'function'
      || typeof editablePlaceApi.createItem !== 'function'
      || typeof editablePlaceApi.updateItem !== 'function'
      || typeof editablePlaceApi.applyGeocoding !== 'function'
      || typeof editablePlaceApi.removeItem !== 'function'
      || typeof editablePlaceApi.removeFromRegistry !== 'function'
      || typeof editablePlaceApi.migrateRegistry !== 'function'
      || typeof editablePlaceApi.referencesJobType !== 'function'
      || typeof editablePlaceApi.updateGeofence !== 'function'
      || typeof editablePlaceApi.buildEffectivePlaces !== 'function') {
      throw new Error('Modulen för det redigerbara platsregistret saknas.');
    }
    if (!editableBeachApi
      || typeof editableBeachApi.validateRegistry !== 'function'
      || typeof editableBeachApi.createItem !== 'function'
      || typeof editableBeachApi.updateItem !== 'function'
      || typeof editableBeachApi.applyGeocoding !== 'function'
      || typeof editableBeachApi.setActive !== 'function'
      || typeof editableBeachApi.removeFromRegistry !== 'function'
      || typeof editableBeachApi.migrateRegistry !== 'function'
      || typeof editableBeachApi.buildEffectivePlaces !== 'function'
      || typeof editableBeachApi.updateGeofence !== 'function') {
      throw new Error('Modulen för det redigerbara badplatsregistret saknas.');
    }
    if (!gpsService
      || typeof gpsService.setConsumer !== 'function'
      || typeof gpsService.subscribe !== 'function'
      || typeof gpsService.retry !== 'function') {
      throw new Error('Den gemensamma GPS-tjänsten saknas.');
    }
    if (!temporaryPlaceService
      || typeof temporaryPlaceService.selectionId !== 'function'
      || typeof temporaryPlaceService.normalizePlace !== 'function'
      || typeof temporaryPlaceService.runtimePlace !== 'function'
      || typeof temporaryPlaceService.placeForJobRole !== 'function') {
      throw new Error('Modulen för Annan plats saknas.');
    }
    if (!phaseService
      || typeof phaseService.normalizePhase !== 'function'
      || typeof phaseService.initializeRecord !== 'function'
      || typeof phaseService.transitionRecord !== 'function'
      || typeof phaseService.closeRecord !== 'function'
      || typeof phaseService.determineInitialPhase !== 'function') {
      throw new Error('Den gemensamma fasmotorn saknas.');
    }
    if (!phaseActionService
      || typeof phaseActionService.resolve !== 'function'
      || typeof phaseActionService.markReturnUnloadingCompleted !== 'function') {
      throw new Error('Fasknappens gemensamma fasfunktion saknas.');
    }
    if (!phaseVisualService
      || typeof phaseVisualService.normalizeColors !== 'function'
      || typeof phaseVisualService.resolveColor !== 'function'
      || typeof phaseVisualService.markLoadRegistered !== 'function'
      || typeof phaseVisualService.remainingMs !== 'function') {
      throw new Error('Fasfärg och Lass registrerat-tjänsten saknas.');
    }
    if (!geofenceService
      || typeof geofenceService.normalizeDefinition !== 'function'
      || typeof geofenceService.setActiveContext !== 'function'
      || typeof geofenceService.subscribeEvents !== 'function'
      || typeof geofenceService.pointInPolygon !== 'function') {
      throw new Error('Den gemensamma geofence-tjänsten saknas.');
    }
    const styleReady = getComputedStyle(document.documentElement).getPropertyValue('--module-style-ready').trim();
    if (styleReady !== '1') {
      throw new Error('Modulens CSS kunde inte verifieras.');
    }
    hostInfo = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!hostInfo) {
      throw new Error('Värdinformationen kunde inte läsas.');
    }
    if (Number(hostInfo.hostVersionCode) < 11) {
      throw new Error('Värdappen är för gammal för det installerade funktionspaketet.');
    }
    if (Number(hostInfo.packageVersion) !== PACKAGE_VERSION) {
      throw new Error('Paketversionen i värdbryggan stämmer inte.');
    }
    if (Number(hostInfo.watchdogApiVersion) < 1) {
      throw new Error('Värdappens Watchdog-brygga saknas eller är för gammal.');
    }
    if (Number(hostInfo.emailDraftApiVersion) < 1 || Number(hostInfo.clipboardApiVersion) < 1) {
      throw new Error('Värdappens mail- eller kopieringsfunktion saknas.');
    }
    watchdog.setContext(hostInfo);
  }

  function start() {
    try {
      // Paket 73 startar prestandatestet före all annan paketlogik; färdiga rapporter återställs separat efter inställningsläsningen.
      try { const monitor = performanceEnsure(); if (monitor) monitor.start(); } catch (_) {}
      try {
        syncDiagnosticEnsure();
        syncDiagnosticObserve('diagnostic-activated', { order: 'after-performance-monitor' });
      } catch (_) {}
      if (!watchdog) {
        throw new Error('Runtime-Watchdog kunde inte laddas.');
      }
      watchdog.step('runtime.bootstrap.start', `Funktionspaket ${PACKAGE_VERSION} startar.`);
      verifyRuntime();
      performanceObserve('app-start', { hostVersion: text(hostInfo && hostInfo.hostVersionName), role: text(hostInfo && hostInfo.role) });
      syncDiagnosticObserve('bootstrap-verified', { packageVersion: PACKAGE_VERSION });
      watchdog.step('runtime.sync.protocol.validated', 'Kööverföringsprotokoll och kontrollsummafunktion verifierades.');
      settingsDocument = readSettingsDocument();
      if (isPlainObject(syncV63Configuration().bingHandshake)) {
        syncV92BingState = { ...syncV92BingState, ...syncV63Configuration().bingHandshake };
        syncV92BingSequence = Number(syncV92BingState.lastBingSequence) || 0;
      }
      loadStoredReportSnapshots();
      renderReportMailProfile();
      renderReportViews();
      loadGoogleSettings();
      loadEditableJobTypeRegistry();
      loadEditablePlaceRegistry();
      loadEditableBeachRegistry();
      buildEffectivePlaceRegistry();
      validateRegistries();
      loadQuickChoiceRegistry();
      populateRegistryForms();
      refreshPlaceFormsForJobType('');
      refreshPlaceFormsForJobType('active-');
      syncJobModeControls('queue');
      syncJobModeControls('active');
      updateMaterialPanel('');
      updateMaterialPanel('active-');
      resetEditableJobTypeEditor();
      resetEditablePlaceEditor();
      resetEditableBeachEditor();
      resetQuickChoiceEditor();
      renderGoogleSettings();
      renderEditableJobTypeRegistry();
      renderEditablePlaceRegistry();
      renderEditableBeachRegistry();
      renderMachineRegistry();
      renderQuickChoiceRegistry();
      renderAtaNotificationSettings();
      renderQuickChoices();
      watchdog.step('runtime.ui.preferences', 'Sparade UI-inställningar tillämpas utan automatisk skrivning.');
      applyUiPreferences(normalizedUiPreferences(settingsDocument));
      renderHostInfo();
      loadSyncOutboxIfNeeded();
      applyRoleBoundaries();
      if (canUseActiveJob()) {
        loadActiveJobIfNeeded();
      }
      installBottomNavLayoutGuard();
      renderPreservedTestValue();
      installPressFeedback();
      installEventHandlers();
      renderSyncV63();
      if (!syncV63HostAvailable()) watchdog.step('runtime.sync.v63.host-required', 'Säker internetsync saknas i värdappen. Lokalt arbete fortsätter.', 'warning');
      else if (syncV63OperationallyEnabled()) syncV85StartTimers();
      unsubscribeGpsSnapshot = gpsService.subscribe(renderGpsSnapshot);
      unsubscribeGeofenceEvents = geofenceService.subscribeEvents(handleGeofenceEvent);
      geofenceRuntimeReady = true;
      watchdog.step('runtime.geofence.ready', 'Gemensam cirkel-/polygonmotor och visuell fasmotor verifierades utan separat GPS-bevakning eller manuella arbetsåtgärder.');
      refreshUpdateStatus();
      if (!runtimeDisposed && !runtimeFailed) updatePollTimer = window.setInterval(refreshUpdateStatus, 2500);
      watchdog.ready();
      byId('watchdog-state').textContent = watchdog.getStatus();
      byId('watchdog-phase').textContent = watchdog.getLastPhase();
      window.StadslassHost.markReady(PACKAGE_VERSION);
      gpsRuntimeReady = true;
      gpsService.setForeground(document.visibilityState !== 'hidden');
      syncGpsDiagnosticsConsumer();
      syncActiveJobGpsConsumer();
      syncActiveGeofenceContext();
    } catch (error) {
      if (watchdog) {
        watchdog.fail(error, 'runtime.bootstrap.failed');
      } else {
        const main = document.createElement('main');
        main.className = 'content';
        const heading = document.createElement('h1');
        heading.textContent = 'Stadslass kunde inte starta';
        const body = document.createElement('p');
        body.textContent = error && error.message ? error.message : 'Okänt startfel.';
        main.append(heading, body);
        document.body.replaceChildren(main);
      }
    }
  }

  function disposeRuntime(options = {}) {
    const failed = options && options.failed === true;
    if (failed) runtimeFailed = true;
    if (runtimeDisposed) return;
    runtimeDisposed = true;
    if (ataBillingDialogOpen) closeAtaBillingDialog({ fromPopState: true });
    if (ataMailDialogContext) closeAtaMailDialog();
    cancelPendingPressActions();
    clearLoadRegisteredTimer();
    if (performanceMonitor) performanceMonitor.stop(failed ? 'runtime-failed' : 'runtime-disposed');
    syncV85Timers.forEach((timer) => window.clearInterval(timer));
    syncV85Timers.clear();
    if (updatePollTimer !== null) {
      window.clearInterval(updatePollTimer);
      updatePollTimer = null;
    }
    window.removeEventListener('resize', updateBottomNavReservedSpace);
    window.removeEventListener('orientationchange', updateBottomNavReservedSpace);
    if (bottomNavResizeObserver) {
      bottomNavResizeObserver.disconnect();
      bottomNavResizeObserver = null;
    }
    if (bottomNavLayoutFrame !== null) {
      window.cancelAnimationFrame(bottomNavLayoutFrame);
      bottomNavLayoutFrame = null;
    }
    if (unsubscribeGpsSnapshot) {
      unsubscribeGpsSnapshot();
      unsubscribeGpsSnapshot = null;
    }
    if (unsubscribeGeofenceEvents) {
      unsubscribeGeofenceEvents();
      unsubscribeGeofenceEvents = null;
    }
    document.removeEventListener('visibilitychange', handleVisibilityChange);
    geofenceRuntimeReady = false;
    if (geofenceService && typeof geofenceService.destroy === 'function') geofenceService.destroy();
    gpsRuntimeReady = false;
    if (gpsService && typeof gpsService.destroy === 'function') gpsService.destroy();
  }

  function handleRuntimeFatal() {
    disposeRuntime({ failed: true });
  }

  window.addEventListener('stadslass-runtime-fatal', handleRuntimeFatal);
  window.addEventListener('pagehide', () => disposeRuntime());
  window.addEventListener('beforeunload', () => disposeRuntime());

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
