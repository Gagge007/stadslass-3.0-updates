const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const root=require('path').resolve(__dirname,'..');
const source=fs.readFileSync(root+'/js/job-type-registry.js','utf8');
const context={window:{crypto:{getRandomValues:(bytes)=>bytes.fill(7)}}};
vm.createContext(context); vm.runInContext(source,context);
const api=context.window.StadslassJobTypeRegistry;
const stamp='2026-08-21T17:20:00.000Z';
const id=(digit)=>`JT3-${String(digit).repeat(32)}`;
const stored={schemaVersion:7,revision:3,updatedAt:stamp,removedDefaultIds:[],items:[
  {id:id('1'),name:'Övrig verksamhet',specialRole:'other-activity',canonicalTypeId:'JT-1001',defaultDefinition:true,createdAt:stamp,updatedAt:stamp},
  {id:id('2'),name:'Äldre övrig verksamhet',specialRole:'other-activity',defaultDefinition:false,createdAt:stamp,updatedAt:stamp},
  {id:id('3'),name:'Maskintransport',specialRole:'machine-transport',canonicalTypeId:'JT-1011',defaultDefinition:true,createdAt:stamp,updatedAt:stamp},
  {id:id('4'),name:'Äldre maskintransport',specialRole:'machine-transport',defaultDefinition:false,createdAt:stamp,updatedAt:stamp}
]};
const result=api.migrateAndMergeRegistry(stored,[],stamp);
api.validateRegistry(result.registry);
assert.strictEqual(result.migrated,true);
assert.strictEqual(result.registry.items.filter((item)=>item.specialRole==='other-activity').length,1);
assert.strictEqual(result.registry.items.filter((item)=>item.specialRole==='machine-transport').length,1);
assert.strictEqual(result.registry.items.find((item)=>item.id===id('2')).specialRole,'none');
assert.strictEqual(result.registry.items.find((item)=>item.id===id('4')).specialRole,'none');
console.log('PASS v107-system-role-recovery.test.js');
