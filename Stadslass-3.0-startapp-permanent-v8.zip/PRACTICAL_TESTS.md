# Riktade praktiska tester för startapp version 8

Använd den permanent signerade APK-filen från GitHub Actions. Avinstallera inte v7 och rensa inte appdata.

## Test 1 – uppdatering och bevarande

1. Installera permanent signerad v8 ovanpå v7.
2. Kontrollera att Android accepterar installationen som uppdatering och att kontrollsidan visar `3.0-host-8`.
3. Kontrollera att roll, enhets-ID, aktivt funktionspaket och lokala datalager finns kvar.
4. Starta installerat funktionspaket och kontrollera att det når READY.

Godkänt när v8 installeras över v7 utan dataförlust eller fallback.

## Test 2 – vanlig och omvänd geokodning

1. Kontrollera i Platsregistret att en adress eller Plus Code fortfarande kan ge koordinater genom den vanliga `address`-kedjan.
2. Med funktionspaket 51 aktivt, välj **Från annan plats**, ange en Plus Code och tryck **Kontrollera adress/Plus Code**.
3. Kontrollera att inget `host.geocoding.bridge.denied` eller `reverse-fetch`-nätverksfel visas.
4. Kontrollera att fältet får en gatuadress i formatet `[gata/väg] [nummer] [postort]`, eller `[gata/väg] [postort]` när gatunummer saknas.
5. Gör samma korta kontroll för **Till annan plats**.

Godkänt när både vanlig geokodning och strikt omvänd geokodning får ett läsbart Google-svar. Ett Google-statusfel som `ZERO_RESULTS` är ett läsbart svar; bryggblockering eller generiskt nätverksfel är underkänt.

## Avgränsning

Ingen Routes, ETA, kartvisning, ny GPS-bevakning, automatisk arbetsåtgärd eller annan WebView-nättrafik ska införas.
