# Watchdog-kontrakt version 1

## Värdlager

`HostWatchdog` får endast lagra tekniska händelser i `files/stadslass-watchdog/host-watchdog.json`.

Tillåtna typer av uppgifter:

- tidsstämpel
- fasnamn
- allvarlighetsgrad
- begränsad teknisk detalj
- värdversion och paketversion
- kandidatmarkering och fallbackmarkering

Förbjudet:

- innehåll från settings, queue, activeJob, history eller syncOutbox
- automatisk reparation eller migrering av arbetsdata
- privat nyckel, API-nyckel eller repository-secret

## Geokodningsbrygga

Tillåtna värdfaser är generiska: anrop blockerat, redirect blockerat, svar mottaget, för stort svar, ogiltig status eller nätverksfel. Detaljen får endast innehålla fas och numerisk HTTP-status. URL, querystring, API-nyckel, söktext, koordinater och svarskropp är förbjudna.

## Runtime-brygga

- `watchdogStep(phase, detail, severity)` registrerar begränsad diagnostik.
- `getHostWatchdogReport()` returnerar värdens rapport.
- `copyWatchdogReport(runtimeReport)` sammanfogar och kopierar rapport efter användaråtgärd.
- `markReady(packageVersion)` är fortsatt det enda kvittot som kan godkänna kandidatstart.

## Timeout och fallback

Paketets `readyTimeoutMs` styr väntan på READY och ska ligga inom modulkontraktets tillåtna intervall. Timeout ska inte användas för att radera arbetsdata. Current-runtimefel får högst utlösa ett verifierat fallbackförsök per startkedja.
