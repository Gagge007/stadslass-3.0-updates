# Ändringshistorik

## 3.0-host-7

- Höjer versionCode från 6 till 7 och versionName från `3.0-host-6` till `3.0-host-7` för permanent signerad uppdatering över v6.
- Inför en begränsad Android-nätverksbrygga i `WebViewClient.shouldInterceptRequest` för exakt Google Geocoding-endpoint.
- Behåller `setBlockNetworkLoads(true)` och blockerar fortsatt alla andra externa nätverksanrop från funktionsmodulen.
- Tillåter endast HTTPS, GET, standardport, exakt sökväg samt parametrarna `address`, `key`, `language=sv` och `region=se` med fasta format- och storleksgränser.
- Följer inte redirects, använder inte cache, begränsar svar till 1 MiB och återlämnar endast ett maskerat svar till `https://stadslass.local`.
- Lagrar eller rapporterar aldrig API-nyckel, söktext, koordinater, full URL eller svarskropp i Android-lagret eller Watchdog.
- Lägger inte till någon ny JavaScript-interface, ny Google API-nyckel, nytt Google-projekt, nya API:er, Routes, ETA, reverse geocoding, geofence, kartvisning eller fasstyrning.
- Behåller GPS-tjänstens gemensamma positionssanning och samtliga v6-gränser för geolocation, modulverifiering, reservstart, datalager och offline-start.

## 3.0-host-6

- Höjer versionCode från 5 till 6 och versionName från `3.0-host-5` till `3.0-host-6` för permanent signerad uppdatering över v5.
- Deklarerar Android-behörigheterna `ACCESS_COARSE_LOCATION` och `ACCESS_FINE_LOCATION`.
- Aktiverar WebView-geolocation med `WebChromeClient.onGeolocationPermissionsShowPrompt`.
- Begär platsbehörighet först när den aktiva signerade modulen faktiskt använder webbläsarens geolocation.
- Kontrollerar aktuell Android-behörighet omedelbart innan varje WebView-svar.
- Hanterar ungefärlig, exakt, nekad, permanent nekad och återkallad platsbehörighet samt återgång från Android-inställningar, bakgrund och appomstart.
- Begränsar geolocation till den låsta lokala HTTPS-originen och sparar aldrig ett bestående WebView-tillstånd för geolocation.
- Lägger inte till bakgrundsposition, `ACCESS_BACKGROUND_LOCATION`, Google, Routes, koordinathämtning, geofence, GPS-styrning eller automatisk fasväxling.
- Behåller paket-ID, signeringssecrets, uppdateringsmodell, SHA-256/RSA, READY-kvitto, Watchdog, reservpaket, atomisk lagring, datalager, roller, enhets-ID och offline-start.

## 3.0-host-5 – källkorrigering 2

- Korrigerar GitHub `lintRelease`-stoppet där `RenderProcessGoneDetail.didCrash()` anropades utan API 26-skydd trots `minSdk 24`.
- Behåller `minSdk 24`, paket-ID, versionCode 5, versionName, SharedPreferences och permanent APK-signering oförändrade.
- Lägger till en källkontroll som stoppar framtida återinförande av samma API-kompatibilitetsfel.
- Ändrar inte Watchdogens datagränser, reservstart, modulformat eller arbetsdatalager.

## 3.0-host-5

- Behåller exakt paket-ID, SharedPreferences, roll, enhets-ID och lokala testvärden från praktiskt godkänd v4.
- Inför en separat atomisk värd-Watchdog för start-, uppdaterings- och modulstartsfaser.
- Övervakar WebView-huvudfel, renderprocessbortfall och uteblivet READY-kvitto.
- Inför automatisk verifierad reservstart för ett redan installerat paket som inte kan starta.
- Begränsar reservförsöket till ett per runtime-startkedja för att förhindra loop.
- Inför kopierbar sammanfogad värd- och runtime-Watchdog-rapport.
- Utökar JavaScript-bryggan med versionsstyrt Watchdog-API utan ny arbetsdataåtkomst.
- Watchdog får inte läsa, radera, normalisera eller reparera arbetsdatalager.
- Behåller v4:s signatur-, ZIP-, WebView-, offline- och datalagerskydd.

## 3.0-host-4

- Korrigerade bakåtnavigeringen genom AndroidX `OnBackPressedDispatcher`.
- Införde signerade ZIP-moduler, filvis hashkontroll, kandidatprovstart, reservpaket, offline-start och fem separata datalager.
