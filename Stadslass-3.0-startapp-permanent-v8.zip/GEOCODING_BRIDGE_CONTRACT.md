# Kontrakt för begränsad geokodningsbrygga – värdversion 8

## Tillåten endpoint

Endast `GET https://maps.googleapis.com/maps/api/geocode/json` på standardport får lämna den signerade lokala modulen. WebViewens generella nätladdning förblir blockerad. Redirects följs inte.

## Tillåtna queryformer

Exakt en av följande parameteruppsättningar får användas:

1. Vanlig geokodning: `address`, `key`, `language`, `region`
2. Omvänd geokodning: `latlng`, `key`, `language`, `region`

`address` och `latlng` får aldrig förekomma samtidigt. Extra parametrar, saknade parametrar, tomma värden och dubbletter blockeras. `language` ska vara `sv` och `region` ska vara `se`.

## Koordinatvalidering

`latlng` måste bestå av exakt två decimala tal separerade med ett kommatecken och utan blanksteg eller andra tecken. Latitud ska ligga inom −90..90 och longitud inom −180..180. `NaN`, oändlighet, exponentform, extra kommatecken och kontrolltecken blockeras.

## Nätverks- och svarsgränser

- anslutningstimeout: 8 sekunder
- lästimeout: 12 sekunder
- maximal rå querylängd: 1 400 tecken
- maximal adresslängd: 500 tecken
- maximal `latlng`-längd: 80 tecken
- maximal svarskropp: 1 MiB
- ingen cache
- CORS endast till `https://stadslass.local`

## Sekretess

Android-värden får inte lagra eller rapportera API-nyckel, adress, Plus Code, koordinater, full URL, querystring eller svarskropp. Watchdog får endast registrera generisk fas och maskerad numerisk HTTP-status.

## Avgränsning

Bryggan inför inte Routes, ETA, kartor, GPS, geofence, platsregister, arbetsflöde eller fasstyrning. Den returnerar endast Googles svar till den signerade webmodul som redan äger funktionslogiken.
