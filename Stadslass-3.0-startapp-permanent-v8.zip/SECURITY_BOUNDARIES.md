# Säkerhetsgränser - 3.0-host-8

## Uppdateringskanal och modulmotor

V4-v7:s gränser är bevarade: endast låst HTTPS-adress för uppdateringar, inga redirects, fasta storleksgränser, SHA-256 och RSA/SHA-256 före uppackning, säkra ZIP-sökvägar, deklarerade runtimefiler, kandidatprovstart och låst lokal WebView-origin.

## Begränsad geokodningsbrygga

- WebViewens allmänna nätladdning förblir blockerad.
- Endast `GET https://maps.googleapis.com/maps/api/geocode/json` kan lämna den lokala modulen genom värdens brygga.
- Exakt en av två queryformer tillåts: vanlig geokodning med `address` eller omvänd geokodning med `latlng`. Båda kräver `key`, `language=sv` och `region=se`.
- `address` och `latlng` får inte kombineras. Extra, saknade, tomma eller dubbla parametrar blockeras.
- `latlng` valideras som två decimala tal utan blanksteg; latitud måste ligga inom −90..90 och longitud inom −180..180.
- Sökväg, schema, värd, standardport, metod och frånvaro av fragment/userinfo kontrolleras före anslutning.
- Redirects följs aldrig. Nätverks- och lästimeout, svarsstorlek, cache och MIME-svar är låsta.
- Svaret får CORS endast för `https://stadslass.local`; ingen generell origin eller wildcard används.
- Bryggan har inget API för Routes, ETA, kartor, geofence eller andra Google-endpoints.
- API-nyckel, söktext och koordinater lagras inte av värden. Watchdog får inte logga full URL, querystring, svarskropp, API-nyckel, söktext eller koordinater.
- Ingen ny `addJavascriptInterface`-metod införs för nätverk.

## Platsbehörighet

- Endast foreground-behörigheterna COARSE och FINE deklareras; bakgrundsbehörighet saknas.
- Ingen runtimefråga görs i `onCreate`, vanlig modulstart eller uppdateringskontroll.
- Endast en faktisk WebView-geolocationbegäran från `https://stadslass.local` kan utlösa Androids runtimefråga.
- Geolocationlagret och geokodningsbryggan är separata: bryggan startar ingen GPS och GPS-tjänsten gör inga Google-anrop.

## Watchdog och arbetsdata

Watchdog använder en egen atomisk diagnostikfil, har fasta storleksgränser och får inte läsa eller reparera settings, queue, activeJob, history eller syncOutbox. Omvänd geokodning förändrar inte dessa gränser.

## Reservstart och rapport

Endast ett redan filverifierat backup-paket kan återställas. Rapporten får innehålla teknisk versions- och fasinformation men inte arbetsdata, API-nycklar, adresser, Plus Codes, koordinater, Google-svar eller privata signeringsnycklar.
