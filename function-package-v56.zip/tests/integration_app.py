#!/usr/bin/env python3
import asyncio
import json
import os
import re
import shutil
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from playwright.async_api import async_playwright

BASE = Path(__file__).resolve().parents[1]


def iso(dt):
    return dt.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def make_active(ata=True, phase='ready_to_complete', other=False):
    now = datetime.now(timezone.utc)
    start = now - timedelta(minutes=77)
    load = start + timedelta(minutes=10)
    transport = start + timedelta(minutes=30)
    unload = start + timedelta(minutes=60)
    ready = start + timedelta(minutes=72)
    return {
        'schemaVersion': 2,
        'jobModelVersion': 4,
        'id': 'active-test-ata' if ata else 'active-test-normal',
        'jobId': 'job-test-ata' if ata else 'job-test-normal',
        'status': 'active',
        'source': 'local',
        'jobTypeId': 'JT-1001' if other else 'JT-1013',
        'jobTypeName': 'Övrig verksamhet' if other else 'Annat',
        'fromPlaceId': '' if other else 'PL-1001',
        'fromPlaceName': '' if other else 'Ringön (BAS)',
        'destinationPlaceId': '' if other else 'PL-1008',
        'destinationPlaceName': '' if other else 'Renova Skräppekärr',
        'returnRequired': False,
        'multiLoad': False,
        'startedAt': iso(start),
        'updatedAt': iso(now),
        'phase': 'other_activity' if other else phase,
        'phaseCode': 'other_activity' if other else phase,
        'phaseEnteredAt': iso(ready),
        # 5 minutes paused: 35 active + 37 active = 72 minutes at dialog open.
        'workSegments': [
            {'startedAt': iso(start), 'endedAt': iso(start + timedelta(minutes=35)), 'reason': 'start'},
            {'startedAt': iso(start + timedelta(minutes=40)), 'endedAt': '', 'reason': 'resume'},
        ],
        # Eligible phase time overlaps 57 active minutes: 30/60 choices.
        'phaseTimeline': [] if other else [
            {'phase': 'start_route', 'phaseCode': 'start_route', 'startedAt': iso(start), 'endedAt': iso(load)},
            {'phase': 'loading', 'phaseCode': 'loading', 'startedAt': iso(load), 'endedAt': iso(transport)},
            {'phase': 'transport', 'phaseCode': 'transport', 'startedAt': iso(transport), 'endedAt': iso(unload)},
            {'phase': 'unloading', 'phaseCode': 'unloading', 'startedAt': iso(unload), 'endedAt': iso(ready)},
            {'phase': 'ready_to_complete', 'phaseCode': 'ready_to_complete', 'startedAt': iso(ready), 'endedAt': ''},
        ],
        'phaseTransitions': [],
        'events': [],
        'loads': [],
        'weightOutcome': 'missing',
        'noEmptying': False,
        'ata': {
            'schemaVersion': 1,
            'enabled': bool(ata),
            'source': 'manual',
            'quickChoiceId': None,
            'updatedAt': iso(start),
        },
    }


def inline_app_html():
    html = (BASE / 'index.html').read_text(encoding='utf-8')
    # Test harness injects app files inline. Remove CSP only in the harness, never in package source.
    html = re.sub(
        r'<meta[^>]+http-equiv=["\']Content-Security-Policy["\'][^>]*>',
        '',
        html,
        flags=re.I,
    )
    css = (BASE / 'css/app.css').read_text(encoding='utf-8')
    html = re.sub(
        r'<link[^>]+href=["\']css/app\.css["\'][^>]*>',
        '<style>' + css + '</style>',
        html,
    )

    def replace_script(match):
        src = match.group(1)
        code = (BASE / src).read_text(encoding='utf-8')
        return '<script>\n' + code.replace('</script>', '<\\/script>') + '\n</script>'

    return re.sub(
        r'<script\s+src=["\']([^"\']+)["\']\s*></script>',
        replace_script,
        html,
    )


INLINE_HTML = inline_app_html()

HOST_SCRIPT = r"""
(stores) => {
  const state = {
    stores: JSON.parse(JSON.stringify(stores)),
    lastError: '',
    steps: [],
    writes: [],
    ready: null
  };
  window.__hostState = state;
  window.StadslassHost = {
    getHostInfo() { return JSON.stringify({
      hostVersionCode: 8,
      hostVersionName: '3.0-host-8-test',
      packageVersion: 56,
      role: 'vehicle_189',
      roleLabel: '189 / Surfplatta',
      deviceId: 'integration-test-device',
      storageApiVersion: 1,
      watchdogApiVersion: 1,
      updateStatus: 'Modulpaket version 56 startade lokalt.'
    }); },
    readStore(name) {
      if (!(name in state.stores)) {
        state.lastError = `Store ${name} missing`;
        return '';
      }
      return JSON.stringify(state.stores[name]);
    },
    writeStore(name, raw) {
      try {
        if (state.failNextWrite === name) {
          state.failNextWrite = '';
          state.lastError = `Simulated write failure for ${name}`;
          return false;
        }
        const value = JSON.parse(raw);
        state.stores[name] = value;
        state.writes.push({ name, value: JSON.parse(JSON.stringify(value)) });
        state.lastError = '';
        return true;
      } catch (error) {
        state.lastError = error.message;
        return false;
      }
    },
    getLastError() { return state.lastError; },
    getUpdateStatus() { return 'Modulpaket version 56 startade lokalt.'; },
    requestUpdateCheck() { return true; },
    markReady(version) { state.ready = version; return true; },
    watchdogStep(payload) {
      try { state.steps.push(JSON.parse(payload)); }
      catch (_) { state.steps.push(payload); }
      return true;
    },
    copyWatchdogReport() { return true; },
    showHostControl() { return true; }
  };
  navigator.geolocation = {
    watchPosition(success) {
      setTimeout(() => success({ coords: { latitude: 57.68, longitude: 11.98, accuracy: 4 }, timestamp: Date.now() }), 10);
      return 1;
    },
    clearWatch() {},
    getCurrentPosition(success) {
      setTimeout(() => success({ coords: { latitude: 57.68, longitude: 11.98, accuracy: 4 }, timestamp: Date.now() }), 10);
    }
  };
}
"""


async def wait_eval(page, expression, timeout_ms=7000):
    deadline = asyncio.get_running_loop().time() + timeout_ms / 1000
    while True:
        try:
            if await page.evaluate(expression):
                return
        except Exception:
            pass
        if asyncio.get_running_loop().time() >= deadline:
            raise AssertionError(f'Timeout waiting for: {expression}')
        await page.wait_for_timeout(50)


async def app_click(locator):
    """Use the app's replay marker so the existing 500 ms press-feedback layer does not delay tests."""
    await locator.wait_for(state='visible')
    await locator.evaluate("element => { element.dataset.pressFeedbackReplay = '1'; element.click(); }")


async def new_page(browser, active, history=None):
    context = await browser.new_context(viewport={'width': 800, 'height': 1280}, locale='sv-SE')
    page = await context.new_page()
    page.set_default_timeout(10000)
    stores = {
        'settings': {},
        'queue': [],
        'activeJob': active,
        'history': history or [],
        'syncOutbox': [],
    }
    errors = []
    page.on('pageerror', lambda exc: errors.append(str(exc)))
    init_source = '(' + HOST_SCRIPT + ')(' + json.dumps(stores, ensure_ascii=False) + ');'
    await page.evaluate(init_source)
    await page.set_content(INLINE_HTML, wait_until='load')
    await wait_eval(page, "() => window.__hostState && window.__hostState.ready === 56")
    return context, page, errors


async def open_active(page):
    await app_click(page.locator('button[data-target="active"]'))


async def request_and_confirm(page):
    await app_click(page.locator('#active-complete-request'))
    await app_click(page.locator('#active-complete-confirm-button'))


async def run():
    results = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            executable_path=shutil.which('chromium'),
            args=['--no-sandbox'],
        )

        # 1. Manual validation, completion, History display, edit to 0, blank removal.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        total_summary = await page.locator('#ata-billing-total-summary').inner_text()
        assert '→ 1 t 30 min' in total_summary, total_summary
        await page.locator('#ata-billing-manual-minutes').fill('29')
        await app_click(page.locator('#ata-billing-save-manual'))
        status = await page.locator('#ata-billing-status').inner_text()
        assert 'Minsta debiterbara tid är 30 minuter' in status, status
        state = await page.evaluate('window.__hostState.stores')
        assert state['activeJob'] and state['history'] == []

        await page.locator('#ata-billing-manual-minutes').fill('47')
        await app_click(page.locator('#ata-billing-save-manual'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1 && Object.keys(window.__hostState.stores.activeJob).length === 0")
        state = await page.evaluate('window.__hostState.stores')
        record = state['history'][0]
        assert record['ata']['billing']['minutes'] == 47
        assert record['ata']['billing']['mode'] == 'manual'
        assert len(record['workSegments']) == 2

        await app_click(page.locator('button[data-target="today"]'))
        assert await page.get_by_text('Debiterbar tid: 47 min', exact=False).count() >= 1
        await app_click(page.get_by_role('button', name='Redigera avslutat jobb').first)
        input_locator = page.locator('[data-history-billing-input]').first
        await input_locator.wait_for(state='visible')
        await input_locator.fill('0')
        await app_click(page.get_by_role('button', name='Spara ändring').first)
        await wait_eval(page, "() => window.__hostState.stores.history[0].ata.billing.minutes === 0")
        state_zero = await page.evaluate('window.__hostState.stores')
        assert state_zero['history'][0]['startedAt'] == record['startedAt']
        assert state_zero['history'][0]['workSegments'] == record['workSegments']

        await app_click(page.get_by_role('button', name='Redigera avslutat jobb').first)
        await page.locator('[data-history-billing-input]').first.fill('')
        await app_click(page.get_by_role('button', name='Spara ändring').first)
        await wait_eval(page, "() => !('billing' in window.__hostState.stores.history[0].ata)")
        assert errors == [], errors
        results.append('manual-validation-completion-display-edit')
        await context.close()

        # 2. Cancel leaves active job and History unchanged.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        await app_click(page.locator('#ata-billing-cancel'))
        state = await page.evaluate('window.__hostState.stores')
        assert state['activeJob']['status'] == 'active'
        assert state['history'] == []
        assert errors == [], errors
        results.append('cancel-preserves-active')
        await context.close()

        # 3. Total time rounds upward and repeated clicks cannot duplicate History.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        total_button = page.locator('#ata-billing-use-total')
        await app_click(total_button)
        # A second programmatic activation after the first one is ignored by action lock/disconnected DOM.
        try:
            await app_click(total_button)
        except Exception:
            pass
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        state = await page.evaluate('window.__hostState.stores')
        assert len(state['history']) == 1
        assert state['history'][0]['ata']['billing']['minutes'] == 90
        assert state['history'][0]['ata']['billing']['mode'] == 'total-up'
        assert errors == [], errors
        results.append('total-rounding-no-duplicate')
        await context.close()

        # 4. Phase time displays correct 30-minute alternatives and saves chosen level.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await app_click(page.locator('#ata-billing-use-phases'))
        await page.locator('#ata-billing-round-step').wait_for(state='visible')
        labels = await page.locator('#ata-billing-round-actions button').all_inner_texts()
        assert any('30 min' in label for label in labels), labels
        assert any('1 t 0 min' in label for label in labels), labels
        await app_click(page.get_by_role('button', name='Uppåt till 1 t 0 min'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        state = await page.evaluate('window.__hostState.stores')
        billing = state['history'][0]['ata']['billing']
        assert billing['minutes'] == 60
        assert billing['mode'] == 'phases-up'
        assert billing['fallbackUsed'] is False
        assert errors == [], errors
        results.append('phase-rounding')
        await context.close()

        # 5. Ordinary non-ATA job follows unchanged completion path.
        context, page, errors = await new_page(browser, make_active(ata=False))
        await open_active(page)
        await request_and_confirm(page)
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        assert await page.locator('#ata-billing-dialog').is_hidden()
        state = await page.evaluate('window.__hostState.stores')
        assert state['history'][0].get('ata', {}).get('billing') is None
        assert errors == [], errors
        results.append('ordinary-completion-unchanged')
        await context.close()

        # 6. Trash and restore preserve the complete billing object.
        history_record = make_active(ata=True)
        history_record.update({
            'id': 'history-trash-billing',
            'jobId': 'job-trash-billing',
            'status': 'completed',
            'completedAt': iso(datetime.now(timezone.utc)),
        })
        history_record['ata']['billing'] = {
            'schemaVersion': 1,
            'minutes': 60,
            'mode': 'total-up',
            'sourceMinutes': 47,
            'fallbackUsed': False,
            'selectedAt': iso(datetime.now(timezone.utc)),
            'editedAt': '',
        }
        context, page, errors = await new_page(browser, {}, [history_record])
        await app_click(page.locator('button[data-target="today"]'))
        await app_click(page.get_by_role('button', name='Flytta till Papperskorgen').first)
        await app_click(page.get_by_role('button', name='Bekräfta flytt').first)
        await wait_eval(page, "() => window.__hostState.stores.history[0].trashState && window.__hostState.stores.history[0].trashState.status === 'trashed'")
        state = await page.evaluate('window.__hostState.stores')
        assert state['history'][0]['ata']['billing']['minutes'] == 60
        await app_click(page.locator('button[data-target="settings"]'))
        await app_click(page.get_by_role('button', name='Underhåll'))
        await app_click(page.get_by_role('button', name='Papperskorg'))
        await app_click(page.get_by_role('button', name='Återställ').first)
        await wait_eval(page, "() => !window.__hostState.stores.history[0].trashState")
        state = await page.evaluate('window.__hostState.stores')
        assert state['history'][0]['ata']['billing']['minutes'] == 60
        assert errors == [], errors
        results.append('trash-restore-preserves-billing')
        await context.close()

        # 7. A failed History write preserves the active completing job and selected billing for retry.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-manual-minutes').fill('47')
        await page.evaluate("window.__hostState.failNextWrite = 'history'")
        await app_click(page.locator('#ata-billing-save-manual'))
        await wait_eval(page, "() => window.__hostState.stores.activeJob.status === 'completing'")
        failed_state = await page.evaluate('window.__hostState.stores')
        assert failed_state['history'] == []
        assert failed_state['activeJob']['ata']['billing']['minutes'] == 47
        # Retry through the same completion chain; no new billing selection is requested.
        await app_click(page.locator('#active-complete-request'))
        await app_click(page.locator('#active-complete-confirm-button'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1 && Object.keys(window.__hostState.stores.activeJob).length === 0")
        retried_state = await page.evaluate('window.__hostState.stores')
        assert retried_state['history'][0]['ata']['billing']['minutes'] == 47
        assert errors == [], errors
        results.append('history-write-failure-safe-retry')
        await context.close()

        # 8. Android/browser back semantics cancel the open billing dialog without ending the job.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        await page.evaluate("window.dispatchEvent(new PopStateEvent('popstate'))")
        await page.locator('#ata-billing-dialog').wait_for(state='hidden')
        back_state = await page.evaluate('window.__hostState.stores')
        assert back_state['activeJob']['status'] == 'active'
        assert back_state['history'] == []
        assert errors == [], errors
        results.append('back-cancels-dialog')
        await context.close()

        # 9. Missing reliable phase timestamps use the documented pause-aware total fallback.
        fallback_active = make_active(ata=True)
        fallback_active['phaseTimeline'] = []
        context, page, errors = await new_page(browser, fallback_active)
        await open_active(page)
        await request_and_confirm(page)
        assert 'totaltid används' in await page.locator('#ata-billing-phase-summary').inner_text()
        await app_click(page.locator('#ata-billing-use-phases'))
        await app_click(page.get_by_role('button', name='Uppåt till 1 t 30 min'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        fallback_state = await page.evaluate('window.__hostState.stores')
        assert fallback_state['history'][0]['ata']['billing']['fallbackUsed'] is True
        assert fallback_state['history'][0]['ata']['billing']['sourceMinutes'] in (72, 73)
        assert errors == [], errors
        results.append('phase-fallback-documented')
        await context.close()

        # 10. Mobile/tablet dialog geometry and visual screenshot.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        screenshot_dir = Path(os.environ.get('STADSLASS_SCREENSHOT_DIR', str(BASE.parent / 'artifacts')))
        screenshot_dir.mkdir(parents=True, exist_ok=True)
        screenshot = screenshot_dir / 'billing-dialog-mobile.png'
        await page.screenshot(path=str(screenshot), full_page=True)
        box = await page.locator('.ata-billing-card').bounding_box()
        assert box and box['x'] >= 0 and box['y'] >= 0
        assert box['x'] + box['width'] <= 800.5
        assert errors == [], errors
        results.append('mobile-dialog-layout')
        await context.close()

        await browser.close()

    print(json.dumps({'status': 'PASS', 'count': len(results), 'tests': results}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        asyncio.run(run())
    except Exception as error:
        print(f'FAIL: {error}', file=sys.stderr)
        raise
