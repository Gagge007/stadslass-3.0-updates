#!/usr/bin/env python3
import asyncio
import json
import os
import re
import shutil
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ModuleNotFoundError:
    async_playwright = None

BASE = Path(__file__).resolve().parents[1]


def iso(dt):
    return dt.astimezone(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def make_active(ata=True, phase='ready_to_complete', other=False):
    now = datetime.now(timezone.utc)
    start = now - timedelta(minutes=77)
    load = start + timedelta(minutes=10)
    transport = start + timedelta(minutes=30)
    unload = start + timedelta(minutes=60)
    ready = start + timedelta(minutes=72)
    return {
        'schemaVersion': 2,
        'jobModelVersion': 4,
        'id': 'active-test-ata' if ata else 'active-test-normal',
        'jobId': 'job-test-ata' if ata else 'job-test-normal',
        'status': 'active',
        'source': 'local',
        'jobTypeId': 'JT-1001' if other else 'JT-1013',
        'jobTypeName': 'Övrig verksamhet' if other else 'Annat',
        'fromPlaceId': '' if other else 'PL-1001',
        'fromPlaceName': '' if other else 'Ringön (BAS)',
        'destinationPlaceId': '' if other else 'PL-1008',
        'destinationPlaceName': '' if other else 'Renova Skräppekärr',
        'returnRequired': False,
        'multiLoad': False,
        'startedAt': iso(start),
        'updatedAt': iso(now),
        'phase': 'other_activity' if other else phase,
        'phaseCode': 'other_activity' if other else phase,
        'phaseEnteredAt': iso(ready),
        # 5 minutes paused: 35 active + 37 active = 72 minutes at dialog open.
        'workSegments': [
            {'startedAt': iso(start), 'endedAt': iso(start + timedelta(minutes=35)), 'reason': 'start'},
            {'startedAt': iso(start + timedelta(minutes=40)), 'endedAt': '', 'reason': 'resume'},
        ],
        # Eligible phase time overlaps 57 active minutes: 30/60 choices.
        'phaseTimeline': [] if other else [
            {'phase': 'start_route', 'phaseCode': 'start_route', 'startedAt': iso(start), 'endedAt': iso(load)},
            {'phase': 'loading', 'phaseCode': 'loading', 'startedAt': iso(load), 'endedAt': iso(transport)},
            {'phase': 'transport', 'phaseCode': 'transport', 'startedAt': iso(transport), 'endedAt': iso(unload)},
            {'phase': 'unloading', 'phaseCode': 'unloading', 'startedAt': iso(unload), 'endedAt': iso(ready)},
            {'phase': 'ready_to_complete', 'phaseCode': 'ready_to_complete', 'startedAt': iso(ready), 'endedAt': ''},
        ],
        'phaseTransitions': [],
        'events': [],
        'loads': [],
        'weightOutcome': 'missing',
        'noEmptying': False,
        'ata': {
            'schemaVersion': 1,
            'enabled': bool(ata),
            'source': 'manual',
            'quickChoiceId': None,
            'updatedAt': iso(start),
            **({'recipient': {
                'contactId': 'contact-test',
                'name': 'Testmottagare',
                'email': 'recipient@example.se',
                'emailKey': 'recipient@example.se',
                'source': 'manual-job-choice',
                'snapshotAt': iso(start),
                'futureRecipientField': {'preserved': True},
            }} if ata else {}),
        },
    }


def inline_app_html():
    html = (BASE / 'index.html').read_text(encoding='utf-8')
    # Test harness injects app files inline. Remove CSP only in the harness, never in package source.
    html = re.sub(
        r'<meta[^>]+http-equiv=["\']Content-Security-Policy["\'][^>]*>',
        '',
        html,
        flags=re.I,
    )
    css = (BASE / 'css/app.css').read_text(encoding='utf-8')
    html = re.sub(
        r'<link[^>]+href=["\']css/app\.css["\'][^>]*>',
        '<style>' + css + '</style>',
        html,
    )

    def replace_script(match):
        src = match.group(1)
        code = (BASE / src).read_text(encoding='utf-8')
        return '<script>\n' + code.replace('</script>', '<\\/script>') + '\n</script>'

    return re.sub(
        r'<script\s+src=["\']([^"\']+)["\']\s*></script>',
        replace_script,
        html,
    )


INLINE_HTML = inline_app_html()

HOST_SCRIPT = r"""
(stores) => {
  const state = {
    stores: JSON.parse(JSON.stringify(stores)),
    lastError: '',
    steps: [],
    writes: [],
    ready: null
  };
  window.__hostState = state;
  window.StadslassHost = {
    getHostInfo() { return JSON.stringify({
      hostVersionCode: 13,
      hostVersionName: '3.0-host-13-test',
      packageVersion: 95,
      role: 'vehicle_189',
      roleLabel: '189 / Surfplatta',
      deviceId: 'integration-test-device',
      storageApiVersion: 1,
      watchdogApiVersion: 1,
      emailDraftApiVersion: 2,
      emailAttachmentApiVersion: 1,
      textFileExportApiVersion: 1,
      clipboardApiVersion: 1,
      syncTransportApiVersion: 1,
      deviceIdentityApiVersion: 1,
      syncCredentialApiVersion: 1,
      updateStatus: 'Modulpaket startade lokalt.'
    }); },
    readStore(name) {
      if (!(name in state.stores)) {
        state.lastError = `Store ${name} missing`;
        return '';
      }
      return JSON.stringify(state.stores[name]);
    },
    writeStore(name, raw) {
      try {
        if (state.failNextWrite === name) {
          state.failNextWrite = '';
          state.lastError = `Simulated write failure for ${name}`;
          return false;
        }
        const value = JSON.parse(raw);
        state.stores[name] = value;
        state.writes.push({ name, value: JSON.parse(JSON.stringify(value)) });
        state.lastError = '';
        return true;
      } catch (error) {
        state.lastError = error.message;
        return false;
      }
    },
    getLastError() { return state.lastError; },
    getUpdateStatus() { return 'Modulpaket startade lokalt.'; },
    getDeviceIdentity() { return JSON.stringify({ ok: true, installationId: 'integration-test-installation-123456', createdAt: '2026-08-02T00:00:00Z' }); },
    setSyncConfiguration(raw) { const value = JSON.parse(raw); state.syncConfiguration = { owner: value.owner, repository: value.repository, branch: value.branch }; return JSON.stringify({ ok: true, status: 'configured', configured: true, ...state.syncConfiguration }); },
    getSyncConfigurationStatus() { return JSON.stringify({ ok: true, status: state.syncConfiguration ? 'configured' : 'configuration_missing', configured: Boolean(state.syncConfiguration), ...(state.syncConfiguration || {}) }); },
    clearSyncConfiguration() { state.syncConfiguration = null; return JSON.stringify({ ok: true, status: 'cleared' }); },
    enqueueSyncRequest(raw) { const request = JSON.parse(raw); state.syncRequests = (state.syncRequests || []).concat([request]); return JSON.stringify({ ok: true, status: 'accepted', requestId: request.requestId }); },
    getSyncRequestStatus(requestId) { return JSON.stringify({ requestId, status: 'succeeded', body: '' }); },
    listPendingSyncRequests() { return JSON.stringify([]); },
    retryPendingSyncRequests() { return JSON.stringify({ ok: true, status: 'accepted' }); },
    acknowledgeSyncResult() { return JSON.stringify({ ok: true, status: 'acknowledged' }); },
    openEmailDraft(recipient, subject, body) {
      const status = state.emailResultStatus || 'opened';
      state.emailDrafts = (state.emailDrafts || []).concat([{ recipient, subject, body, status }]);
      if (status === 'throw') throw new Error('Simulated host failure');
      return JSON.stringify({ ok: status === 'opened', status });
    },
    openEmailDraftWithAttachment(raw) {
      const value = JSON.parse(raw);
      const requested = state.emailResultStatus || 'opened_gmail';
      const mapped = requested === 'opened' ? 'opened_gmail' : requested;
      state.emailDrafts = (state.emailDrafts || []).concat([{ recipient: value.recipient, subject: value.subject, body: value.body, attachment: value.attachment || null, status: mapped }]);
      if (mapped === 'throw') throw new Error('Simulated host failure');
      return JSON.stringify({ ok: ['opened_gmail','opened_mail_app'].includes(mapped), status: mapped, requestId: value.requestId, attachmentCreated: Boolean(value.attachment), fileName: value.attachment ? value.attachment.fileName : '', byteLength: value.attachment ? new TextEncoder().encode(value.attachment.contentUtf8 || '').length : 0 });
    },
    requestTextFileExport(raw) { const value=JSON.parse(raw); state.textExports=(state.textExports||[]).concat([value]); return JSON.stringify({ok:true,status:'save_dialog_opened',requestId:value.requestId}); },
    getTextFileExportStatus(requestId) { return JSON.stringify({ok:true,status:'saved',requestId}); },
    acknowledgeTextFileExportResult(requestId) { return JSON.stringify({ok:true,status:'acknowledged',requestId}); },
    copyText(label, text) { state.copies = (state.copies || []).concat([{ label, text }]); return true; },
    requestUpdateCheck() { return true; },
    markReady(version) { state.ready = version; return true; },
    watchdogStep(payload) {
      try { state.steps.push(JSON.parse(payload)); }
      catch (_) { state.steps.push(payload); }
      return true;
    },
    copyWatchdogReport() { return true; },
    showHostControl() { return true; }
  };
  navigator.geolocation = {
    watchPosition(success) {
      setTimeout(() => success({ coords: { latitude: 57.68, longitude: 11.98, accuracy: 4 }, timestamp: Date.now() }), 10);
      return 1;
    },
    clearWatch() {},
    getCurrentPosition(success) {
      setTimeout(() => success({ coords: { latitude: 57.68, longitude: 11.98, accuracy: 4 }, timestamp: Date.now() }), 10);
    }
  };
}
"""


async def wait_eval(page, expression, timeout_ms=7000):
    deadline = asyncio.get_running_loop().time() + timeout_ms / 1000
    while True:
        try:
            if await page.evaluate(expression):
                return
        except Exception:
            pass
        if asyncio.get_running_loop().time() >= deadline:
            raise AssertionError(f'Timeout waiting for: {expression}')
        await page.wait_for_timeout(50)


async def app_click(locator):
    """Use the app's replay marker so the existing 500 ms press-feedback layer does not delay tests."""
    await locator.wait_for(state='visible')
    await locator.evaluate("element => { element.dataset.pressFeedbackReplay = '1'; element.click(); }")


async def new_page(browser, active, history=None, settings=None, queue=None, sync_outbox=None):
    context = await browser.new_context(viewport={'width': 800, 'height': 1280}, locale='sv-SE')
    page = await context.new_page()
    page.set_default_timeout(10000)
    stores = {
        'settings': settings or {},
        'queue': queue or [],
        'activeJob': active,
        'history': history or [],
        'syncOutbox': sync_outbox or [],
    }
    errors = []
    page.on('pageerror', lambda exc: errors.append(str(exc)))
    init_source = '(' + HOST_SCRIPT + ')(' + json.dumps(stores, ensure_ascii=False) + ');'
    await page.evaluate(init_source)
    await page.set_content(INLINE_HTML, wait_until='load')
    await wait_eval(page, "() => window.__hostState && window.__hostState.ready === 95")
    await wait_eval(page, "() => (document.getElementById('sync-diagnostic-summary') || {}).textContent.length > 0")
    return context, page, errors


async def open_active(page):
    await app_click(page.locator('button[data-target="active"]'))


async def request_and_confirm(page):
    await app_click(page.locator('#active-complete-request'))
    await app_click(page.locator('#active-complete-confirm-button'))


async def run():
    results = []
    if async_playwright is None:
        print(json.dumps({'status': 'EJ_KORBAR_I_INTERN_MILJO', 'reason': 'Python Playwright saknas i den interna testmiljön.'}, ensure_ascii=False))
        return
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            executable_path=shutil.which('chromium'),
            args=['--no-sandbox'],
        )

        # 1. Manual validation, completion, History display, edit to 0, blank removal.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        total_summary = await page.locator('#ata-billing-total-summary').inner_text()
        assert '→ 1 t 30 min' in total_summary, total_summary
        assert await page.locator('#ata-billing-total-choice').evaluate("element => element.tagName === 'BUTTON'")
        assert await page.locator('#ata-billing-total-choice').evaluate("element => document.activeElement === element")
        assert await page.locator('#ata-billing-phase-choice').evaluate("element => element.tagName === 'BUTTON'")
        assert await page.locator('#ata-billing-use-total').count() == 0
        assert await page.locator('#ata-billing-use-phases').count() == 0
        await page.locator('#ata-billing-manual-minutes').fill('29')
        await app_click(page.locator('#ata-billing-save-manual'))
        status = await page.locator('#ata-billing-status').inner_text()
        assert 'Minsta debiterbara tid är 30 minuter' in status, status
        state = await page.evaluate('window.__hostState.stores')
        assert state['activeJob'] and state['history'] == []

        await page.locator('#ata-billing-manual-minutes').fill('47')
        await app_click(page.locator('#ata-billing-save-manual'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1 && Object.keys(window.__hostState.stores.activeJob).length === 0")
        state = await page.evaluate('window.__hostState.stores')
        record = state['history'][0]
        assert record['ata']['billing']['minutes'] == 47
        assert record['ata']['billing']['mode'] == 'manual'
        assert len(record['workSegments']) == 2

        await app_click(page.locator('button[data-target="today"]'))
        assert await page.get_by_text('Debiterbar tid: 47 min', exact=False).count() >= 1
        await app_click(page.get_by_role('button', name='Redigera avslutat jobb').first)
        input_locator = page.locator('[data-history-billing-input]').first
        await input_locator.wait_for(state='visible')
        await input_locator.fill('0')
        await app_click(page.get_by_role('button', name='Spara ändring').first)
        await wait_eval(page, "() => window.__hostState.stores.history[0].ata.billing.minutes === 0")
        state_zero = await page.evaluate('window.__hostState.stores')
        assert state_zero['history'][0]['startedAt'] == record['startedAt']
        assert state_zero['history'][0]['workSegments'] == record['workSegments']

        await app_click(page.get_by_role('button', name='Redigera avslutat jobb').first)
        await page.locator('[data-history-billing-input]').first.fill('')
        await app_click(page.get_by_role('button', name='Spara ändring').first)
        await wait_eval(page, "() => !('billing' in window.__hostState.stores.history[0].ata)")
        assert errors == [], errors
        results.append('manual-validation-completion-display-edit')
        await context.close()

        # 2. Cancel leaves active job and History unchanged.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        await app_click(page.locator('#ata-billing-cancel'))
        state = await page.evaluate('window.__hostState.stores')
        assert state['activeJob']['status'] == 'active'
        assert state['history'] == []
        assert errors == [], errors
        results.append('cancel-preserves-active')
        await context.close()

        # 3. Total time rounds upward and repeated clicks cannot duplicate History.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        total_button = page.locator('#ata-billing-total-choice')
        await app_click(total_button)
        # A second programmatic activation after the first one is ignored by action lock/disconnected DOM.
        try:
            await app_click(total_button)
        except Exception:
            pass
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        state = await page.evaluate('window.__hostState.stores')
        assert len(state['history']) == 1
        assert state['history'][0]['ata']['billing']['minutes'] == 90
        assert state['history'][0]['ata']['billing']['mode'] == 'total-up'
        assert errors == [], errors
        results.append('total-rounding-no-duplicate')
        await context.close()

        # 4. Phase time displays correct 30-minute alternatives and saves chosen level.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await app_click(page.locator('#ata-billing-phase-choice'))
        await page.locator('#ata-billing-round-step').wait_for(state='visible')
        labels = await page.locator('#ata-billing-round-actions button').all_inner_texts()
        assert any('30 min' in label for label in labels), labels
        assert any('1 t 0 min' in label for label in labels), labels
        await app_click(page.get_by_role('button', name='Uppåt till 1 t 0 min'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        state = await page.evaluate('window.__hostState.stores')
        billing = state['history'][0]['ata']['billing']
        assert billing['minutes'] == 60
        assert billing['mode'] == 'phases-up'
        assert billing['fallbackUsed'] is False
        assert errors == [], errors
        results.append('phase-rounding')
        await context.close()

        # 5. Ordinary non-ATA job follows unchanged completion path.
        context, page, errors = await new_page(browser, make_active(ata=False))
        await open_active(page)
        await request_and_confirm(page)
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1")
        assert await page.locator('#ata-billing-dialog').is_hidden()
        state = await page.evaluate('window.__hostState.stores')
        assert state['history'][0].get('ata', {}).get('billing') is None
        assert errors == [], errors
        results.append('ordinary-completion-unchanged')
        await context.close()

        # 6. Trash and restore preserve the complete billing object.
        history_record = make_active(ata=True)
        history_record.update({
            'id': 'history-trash-billing',
            'jobId': 'job-trash-billing',
            'status': 'completed',
            'completedAt': iso(datetime.now(timezone.utc)),
        })
        history_record['ata']['billing'] = {
            'schemaVersion': 1,
            'minutes': 60,
            'mode': 'total-up',
            'sourceMinutes': 47,
            'fallbackUsed': False,
            'selectedAt': iso(datetime.now(timezone.utc)),
            'editedAt': '',
        }
        context, page, errors = await new_page(browser, {}, [history_record])
        await app_click(page.locator('button[data-target="today"]'))
        await app_click(page.get_by_role('button', name='Flytta till Papperskorgen').first)
        await app_click(page.get_by_role('button', name='Bekräfta flytt').first)
        await wait_eval(page, "() => window.__hostState.stores.history[0].trashState && window.__hostState.stores.history[0].trashState.status === 'trashed'")
        state = await page.evaluate('window.__hostState.stores')
        assert state['history'][0]['ata']['billing']['minutes'] == 60
        await app_click(page.locator('button[data-target="settings"]'))
        await app_click(page.get_by_role('button', name='Underhåll'))
        await app_click(page.get_by_role('button', name='Papperskorg'))
        await app_click(page.get_by_role('button', name='Återställ').first)
        await wait_eval(page, "() => !window.__hostState.stores.history[0].trashState")
        state = await page.evaluate('window.__hostState.stores')
        assert state['history'][0]['ata']['billing']['minutes'] == 60
        assert errors == [], errors
        results.append('trash-restore-preserves-billing')
        await context.close()

        # 7. A failed History write preserves the active completing job and selected billing for retry.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-manual-minutes').fill('47')
        await page.evaluate("window.__hostState.failNextWrite = 'history'")
        await app_click(page.locator('#ata-billing-save-manual'))
        await wait_eval(page, "() => window.__hostState.stores.activeJob.status === 'completing'")
        failed_state = await page.evaluate('window.__hostState.stores')
        assert failed_state['history'] == []
        assert failed_state['activeJob']['ata']['billing']['minutes'] == 47
        # Retry through the same completion chain; no new billing selection is requested.
        await app_click(page.locator('#active-complete-request'))
        await app_click(page.locator('#active-complete-confirm-button'))
        await wait_eval(page, "() => window.__hostState.stores.history.length === 1 && Object.keys(window.__hostState.stores.activeJob).length === 0")
        retried_state = await page.evaluate('window.__hostState.stores')
        assert retried_state['history'][0]['ata']['billing']['minutes'] == 47
        assert errors == [], errors
        results.append('history-write-failure-safe-retry')
        await context.close()

        # 8. Android/browser back semantics cancel the open billing dialog without ending the job.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        await page.evaluate("window.dispatchEvent(new PopStateEvent('popstate'))")
        await page.locator('#ata-billing-dialog').wait_for(state='hidden')
        back_state = await page.evaluate('window.__hostState.stores')
        assert back_state['activeJob']['status'] == 'active'
        assert back_state['history'] == []
        assert errors == [], errors
        results.append('back-cancels-dialog')
        await context.close()

        # 9. Missing reliable phase timestamps use the documented pause-aware total fallback.
        fallback_active = make_active(ata=True)
        fallback_active['phaseTimeline'] = []
        context, page, errors = await new_page(browser, fallback_active)
        await open_active(page)
        await request_and_confirm(page)
        assert 'Kan inte beräknas' in await page.locator('#ata-billing-phase-summary').inner_text()
        phase_choice = page.locator('#ata-billing-phase-choice')
        assert await phase_choice.is_disabled()
        assert await page.locator('#ata-billing-round-step').is_hidden()
        fallback_state = await page.evaluate('window.__hostState.stores')
        assert fallback_state['history'] == []
        assert fallback_state['activeJob']['status'] == 'active'
        assert errors == [], errors
        results.append('phase-fallback-disabled')
        await context.close()

        # 10. Mobile/tablet dialog geometry and visual screenshot.
        context, page, errors = await new_page(browser, make_active(ata=True))
        await open_active(page)
        await request_and_confirm(page)
        await page.locator('#ata-billing-dialog').wait_for(state='visible')
        screenshot_dir = Path(os.environ.get('STADSLASS_SCREENSHOT_DIR', str(BASE.parent / 'artifacts')))
        screenshot_dir.mkdir(parents=True, exist_ok=True)
        screenshot = screenshot_dir / 'billing-dialog-mobile.png'
        await page.screenshot(path=str(screenshot), full_page=True)
        box = await page.locator('.ata-billing-card').bounding_box()
        assert box and box['x'] >= 0 and box['y'] >= 0
        assert box['x'] + box['width'] <= 800.5
        assert errors == [], errors
        results.append('mobile-dialog-layout')
        await context.close()

        # 11. ÄTA mail uses separate metadata/body, body-only copy and a safe after-open state.
        mail_record = make_active(ata=True)
        mail_record.update({
            'id': 'history-mail-v62',
            'jobId': 'job-mail-v62',
            'status': 'completed',
            'completedAt': iso(datetime.now(timezone.utc)),
            'fromPlaceName': 'Humlevägen 1 Landvetter',
            'destinationPlaceName': 'Lergodsgatan 1 Göteborg',
            'temporaryPlaces': {
                'from': {'normalizedAddress': 'Humlevägen 1, Landvetter.'},
                'destination': {'normalizedAddress': 'Lergodsgatan 1 Göteborg'},
            },
        })
        mail_record['ata']['billing'] = {
            'schemaVersion': 1, 'minutes': 30, 'mode': 'total-up', 'sourceMinutes': 0,
            'fallbackUsed': False, 'selectedAt': iso(datetime.now(timezone.utc)), 'editedAt': ''
        }
        context, page, errors = await new_page(browser, {}, [mail_record])
        await app_click(page.locator('button[data-target="today"]'))
        await app_click(page.get_by_role('button', name='Visa underlag').first)
        await page.locator('#ata-mail-dialog').wait_for(state='visible')
        assert (await page.locator('#ata-mail-recipient').inner_text()).startswith('Till: Testmottagare')
        assert await page.locator('#ata-mail-subject').inner_text() == 'Ämne: ÄTA uppdrag lastbil 189'
        preview = await page.locator('#ata-mail-preview').inner_text()
        assert preview.startswith('Jobbtyp:')
        assert '\nÄmne:' not in preview and not preview.startswith('Till:')
        assert 'Från adress:' not in preview and 'Till adress:' not in preview
        await app_click(page.locator('#ata-mail-copy'))
        copy_state = await page.evaluate('window.__hostState')
        assert copy_state['copies'][-1]['text'] == preview
        assert copy_state['stores']['history'][0].get('ata', {}).get('mail') is None
        await app_click(page.locator('#ata-mail-open'))
        await wait_eval(page, "() => (window.__hostState.emailDrafts || []).length === 1")
        mail_state = await page.evaluate('window.__hostState')
        draft = mail_state['emailDrafts'][0]
        assert draft['recipient'] == 'recipient@example.se'
        assert draft['subject'] == 'ÄTA uppdrag lastbil 189'
        assert draft['body'] == preview
        assert mail_state['copies'][-1]['text'] == preview
        assert await page.locator('#ata-mail-open').inner_text() == 'Klar – fortsätt i Stadslass'
        assert await page.locator('#ata-mail-skip').is_hidden()
        assert 'Mailutkast öppnat' in await page.locator('#ata-mail-status').inner_text()
        await app_click(page.locator('#ata-mail-open'))
        await page.locator('#ata-mail-dialog').wait_for(state='hidden')
        final_mail_state = await page.evaluate('window.__hostState.stores.history[0].ata.mail')
        assert final_mail_state['lastAction'] == 'draft_opened'
        assert errors == [], errors
        results.append('mail-body-only-address-dedupe-after-open')
        await context.close()

        # 12. Failed host results do not activate the after-open state or overwrite mail status.
        for host_status, expected_text in [
            ('no_mail_app', 'Ingen mailapp finns installerad'),
            ('invalid_request', 'kunde inte förberedas'),
            ('host_error', 'kunde inte öppnas'),
        ]:
            error_record = json.loads(json.dumps(mail_record))
            error_record['id'] = f'history-mail-{host_status}'
            error_record['jobId'] = f'job-mail-{host_status}'
            context, page, errors = await new_page(browser, {}, [error_record])
            await page.evaluate("status => { window.__hostState.emailResultStatus = status; }", host_status)
            await app_click(page.locator('button[data-target="today"]'))
            await app_click(page.get_by_role('button', name='Visa underlag').first)
            await app_click(page.locator('#ata-mail-open'))
            assert expected_text in await page.locator('#ata-mail-status').inner_text()
            assert await page.locator('#ata-mail-open').inner_text() == 'Öppna mailutkast'
            assert not await page.locator('#ata-mail-skip').is_hidden()
            # No status object is created by a failed host result.
            assert await page.evaluate("() => !window.__hostState.stores.history[0].ata.mail")
            assert errors == [], errors
            await context.close()
        results.append('mail-host-errors-preserve-before-state')

        # 13. ÄTA notification settings use the shared settings document without touching job stores.
        context, page, errors = await new_page(browser, {})
        await app_click(page.locator('button[data-target="settings"]'))
        await app_click(page.get_by_role('button', name='Vanliga åtgärder'))
        await app_click(page.get_by_role('button', name='ÄTA avisering'))
        await page.locator('#ata-notification-settings-card').wait_for(state='visible')
        await page.locator('#ata-notification-contact-name').fill('Första mottagaren')
        await page.locator('#ata-notification-contact-email').fill('Forsta@Example.SE')
        await app_click(page.locator('#ata-notification-contact-submit'))
        await wait_eval(page, "() => window.__hostState.stores.settings.ataNotificationSettingsV1.contacts.length === 1")
        state = await page.evaluate('window.__hostState.stores')
        first_contact = state['settings']['ataNotificationSettingsV1']['contacts'][0]
        assert first_contact['emailKey'] == 'forsta@example.se' and 'active' not in first_contact
        assert state['queue'] == [] and state['history'] == [] and state['activeJob'] == {}
        await app_click(page.get_by_role('button', name='Redigera'))
        assert await page.locator('#ata-notification-contact-id').input_value() == first_contact['id']
        assert await page.locator('#ata-notification-contact-name').evaluate('element => document.activeElement === element')
        await app_click(page.locator('#ata-notification-contact-reset'))
        await page.locator('#ata-notification-contact-name').fill('Dubblett')
        await page.locator('#ata-notification-contact-email').fill(' forsta@example.se ')
        await app_click(page.locator('#ata-notification-contact-submit'))
        await page.locator('#ata-notification-confirm').wait_for(state='visible')
        assert 'Första mottagaren' in await page.locator('#ata-notification-confirm-text').inner_text()
        assert await page.locator('#ata-notification-contact-status + #ata-notification-confirm').count() == 1
        await app_click(page.locator('#ata-notification-confirm-cancel'))
        state = await page.evaluate('window.__hostState.stores')
        assert len(state['settings']['ataNotificationSettingsV1']['contacts']) == 1
        await app_click(page.locator('#ata-notification-contact-submit'))
        await app_click(page.get_by_role('button', name='Spara ändå'))
        await wait_eval(page, "() => window.__hostState.stores.settings.ataNotificationSettingsV1.contacts.length === 2")
        state = await page.evaluate('window.__hostState.stores')
        contacts = state['settings']['ataNotificationSettingsV1']['contacts']
        assert len({item['id'] for item in contacts}) == 2
        contact_list = page.locator('#ata-notification-contact-list')
        assert await contact_list.get_by_role('button', name='Inaktivera').count() == 0
        assert await contact_list.get_by_role('button', name='Aktivera').count() == 0
        assert await contact_list.get_by_text('Aktiv', exact=True).count() == 0
        await app_click(page.get_by_role('button', name='Ta bort').first)
        await page.locator('#ata-notification-confirm').wait_for(state='visible')
        await app_click(page.get_by_role('button', name='Bekräfta borttagning'))
        await wait_eval(page, "() => window.__hostState.stores.settings.ataNotificationSettingsV1.contacts.length === 1")
        await page.locator('#ata-notification-supervisor-name').fill('Arbetsledare')
        await page.locator('#ata-notification-supervisor-email').fill('chef@example.se')
        await app_click(page.get_by_role('button', name='Spara arbetsledare'))
        await page.locator('#ata-notification-template-closing').fill('Egen avslutning')
        await page.wait_for_timeout(450)
        state = await page.evaluate('window.__hostState.stores')
        assert state['settings']['ataNotificationSettingsV1']['template']['closingText'] == 'Egen avslutning'
        await app_click(page.locator('#ata-notification-template-jobType'))
        await app_click(page.locator('#ata-notification-template-reset'))
        await app_click(page.locator('#ata-notification-confirm-accept'))
        await wait_eval(page, "() => window.__hostState.stores.settings.ataNotificationSettingsV1.template.closingText === ''")
        state = await page.evaluate('window.__hostState.stores')
        assert all(state['settings']['ataNotificationSettingsV1']['template']['fields'].values())
        assert state['settings']['ataNotificationSettingsV1']['supervisor']['name'] == 'Arbetsledare'
        assert errors == [], errors
        results.append('ata-notification-settings-shared-storage')
        await context.close()

        # 12. Package 61 recipient presentation is name-only while exact recipient data remains intact.
        contact_settings = {
            'ataNotificationSettingsV1': {
                'schemaVersion': 1,
                'contacts': [
                    {'id': 'contact-first', 'name': 'Samma namn', 'email': 'first@example.se', 'emailKey': 'first@example.se', 'source': 'manual', 'createdAt': '2026-07-31T08:00:00.000Z', 'futureContactField': 1},
                    {'id': 'contact-second', 'name': 'Samma namn', 'email': 'second@example.se', 'emailKey': 'second@example.se', 'source': 'manual', 'createdAt': '2026-07-31T08:01:00.000Z', 'futureContactField': 2},
                    {'id': 'contact-nameless', 'name': '   ', 'email': 'nameless@example.se', 'emailKey': 'nameless@example.se', 'source': 'sync', 'createdAt': '2026-07-31T08:02:00.000Z', 'futureContactField': 3},
                ],
                'supervisor': {'name': 'Arbetsledare', 'email': 'chef@example.se', 'emailKey': 'chef@example.se'},
                'template': {'fields': {}, 'closingText': ''},
                'futureSettingsField': {'preserved': True},
            }
        }
        queue_job = make_active(ata=True)
        queue_job.update({'id': 'queue-recipient-test', 'jobId': 'job-recipient-test', 'status': 'queued', 'plannedDate': datetime.now().date().isoformat(), 'phase': 'loading', 'pausedFromActive': False})
        queue_job['ata']['recipient'].update({'contactId': 'contact-first', 'name': 'Samma namn', 'email': 'first@example.se', 'emailKey': 'first@example.se'})
        nameless_queue_job = make_active(ata=True)
        nameless_queue_job.update({'id': 'queue-recipient-nameless', 'jobId': 'job-recipient-nameless', 'status': 'paused', 'plannedDate': datetime.now().date().isoformat(), 'phase': 'transport', 'pausedFromActive': True})
        nameless_queue_job['ata']['recipient'].update({'contactId': 'contact-nameless', 'name': '   ', 'email': 'nameless@example.se', 'emailKey': 'nameless@example.se'})
        long_queue_job = make_active(ata=True)
        long_name = '<b>' + ('LångtNamn' * 40) + '</b>'
        long_queue_job.update({'id': 'queue-recipient-long', 'jobId': 'job-recipient-long', 'status': 'queued', 'plannedDate': datetime.now().date().isoformat(), 'phase': 'loading', 'pausedFromActive': False})
        long_queue_job['ata']['recipient'].update({'contactId': 'contact-long', 'name': long_name, 'email': 'long@example.se', 'emailKey': 'long@example.se'})
        context, page, errors = await new_page(browser, {}, settings=contact_settings, queue=[queue_job, nameless_queue_job, long_queue_job])
        await app_click(page.locator('button[data-target="queue"]'))
        queue_card = page.locator('[data-queue-id="queue-recipient-test"]')
        queue_text = await queue_card.inner_text()
        assert 'ÄTA-mottagare: Samma namn' in queue_text
        assert 'first@example.se' not in queue_text
        assert 'contact-first' not in queue_text
        nameless_text = await page.locator('[data-queue-id="queue-recipient-nameless"]').inner_text()
        assert 'ÄTA-mottagare vald' in nameless_text
        assert 'nameless@example.se' not in nameless_text
        long_card = page.locator('[data-queue-id="queue-recipient-long"]')
        long_text = await long_card.inner_text()
        assert long_name in long_text
        assert await long_card.locator('b').count() == 0
        long_box = await long_card.bounding_box()
        long_recipient_box = await long_card.locator('.field-help').bounding_box()
        assert long_box and long_recipient_box and long_recipient_box['x'] + long_recipient_box['width'] <= long_box['x'] + long_box['width'] + 1
        writes_before = await page.evaluate('window.__hostState.writes.length')
        await app_click(queue_card.locator('[data-edit-queue-item="queue-recipient-test"]'))
        await page.locator('#job-ata').dispatch_event('change')
        select = page.locator('#job-ata-contact')
        await select.wait_for(state='visible')
        option_texts = await select.locator('option').all_inner_texts()
        option_values = await select.locator('option').evaluate_all('options => options.map(option => option.value)')
        assert option_texts == ['Ingen sparad mottagare', 'Namnlös mottagare', 'Samma namn', 'Samma namn']
        assert all('@' not in label and 'contact-' not in label for label in option_texts)
        assert set(option_values[1:]) == {'contact-first', 'contact-second', 'contact-nameless'}
        await select.select_option('contact-first')
        assert await page.locator('#job-ata-recipient-email').input_value() == 'first@example.se'
        await select.select_option('contact-second')
        assert await page.locator('#job-ata-recipient-email').input_value() == 'second@example.se'
        state = await page.evaluate('window.__hostState.stores')
        assert await page.evaluate('window.__hostState.writes.length') == writes_before
        assert state['settings']['ataNotificationSettingsV1']['futureSettingsField'] == {'preserved': True}
        assert state['queue'][0]['ata']['recipient']['futureRecipientField'] == {'preserved': True}
        assert errors == [], errors
        results.append('recipient-list-and-queue-name-only-data-preserved')
        await context.close()

        active = make_active(ata=True)
        context, page, errors = await new_page(browser, active)
        await open_active(page)
        active_text = await page.locator('#view-active').inner_text()
        active_card_text = await page.locator('#active-job-card').inner_text()
        assert 'Aktivt jobb kan användas på denna enhet.' not in active_text
        assert 'Uppdraget startades från 189:s operativa kö.' not in active_text
        assert 'ÄTA-mottagare:' not in active_card_text
        assert 'recipient@example.se' not in active_card_text
        assert await page.locator('#active-ata-recipient-display').count() == 0
        assert await page.locator('#active-ata-badge').is_visible()
        assert await page.locator('#active-control-group > button').count() == 3
        active_state = await page.evaluate('window.__hostState.stores.activeJob')
        assert active_state['ata']['recipient']['email'] == 'recipient@example.se'
        assert active_state['ata']['recipient']['futureRecipientField'] == {'preserved': True}
        await app_click(page.locator('#active-pause-action'))
        await wait_eval(page, "() => window.__hostState.stores.queue.length === 1 && Object.keys(window.__hostState.stores.activeJob).length === 0")
        paused_state = await page.evaluate('window.__hostState.stores')
        assert paused_state['queue'][0]['ata']['recipient']['email'] == 'recipient@example.se'
        assert paused_state['queue'][0]['ata']['recipient']['futureRecipientField'] == {'preserved': True}
        await app_click(page.locator('button[data-target="queue"]'))
        await app_click(page.locator('[data-queue-id] [data-start-queue-item]').first)
        await wait_eval(page, "() => window.__hostState.stores.activeJob.ata && window.__hostState.stores.activeJob.ata.recipient")
        resumed_state = await page.evaluate('window.__hostState.stores.activeJob')
        assert resumed_state['ata']['recipient']['email'] == 'recipient@example.se'
        assert resumed_state['ata']['recipient']['futureRecipientField'] == {'preserved': True}
        assert errors == [], errors
        results.append('active-job-clean-recipient-snapshot-preserved')
        results.append('recipient-snapshot-pause-resume-preserved')
        await context.close()

        await browser.close()

    print(json.dumps({'status': 'PASS', 'count': len(results), 'tests': results}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        asyncio.run(run())
    except Exception as error:
        if 'Executable doesn\'t exist' in str(error):
            print(json.dumps({'status': 'EJ_KORBAR_I_INTERN_MILJO', 'reason': 'Ingen Chromium-webbläsare finns installerad i den interna testmiljön.'}, ensure_ascii=False))
            sys.exit(0)
        print(f'FAIL: {error}', file=sys.stderr)
        raise
