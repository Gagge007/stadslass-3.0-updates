const fs = require('fs'), vm = require('vm'), path = require('path'), assert = require('assert');
function load(file, key) {
  const context = { window: { crypto: { getRandomValues: (v) => v.fill(7) } }, Uint8Array, Date, Math, Set, Array, Object, String, Boolean, RegExp, Error };
  const geo = { TYPES: ['circle'], normalizeDefinition: (v = {}, c = {}) => ({ enabled: Boolean(v.enabled), type: 'circle', visualLoadingLock: false, visualUnloadingLock: false, latitude: v.latitude ?? c.latitude ?? null, longitude: v.longitude ?? c.longitude ?? null, radiusMeters: null, polygonPoints: [], toleranceMeters: null }), validateDefinition: () => true };
  const google = { normalizeGeocoding: (v, l = {}) => ({ status: 'empty', latitude: l.latitude ?? null, longitude: l.longitude ?? null, query: l.query || '' }), pendingGeocoding: (v, q) => ({ status: 'empty', latitude: null, longitude: null, query: q || '' }), validateGeocoding: (v) => v, validCoordinates: () => false };
  context.window.StadslassGeofenceService = geo; context.window.StadslassGoogleService = google; vm.createContext(context); vm.runInContext(fs.readFileSync(file, 'utf8'), context); return context.window[key];
}
const root = path.join(__dirname, '..');
const places = load(path.join(root, 'js/place-registry.js'), 'StadslassPlaceRegistry');
const beaches = load(path.join(root, 'js/beach-registry.js'), 'StadslassBeachRegistry');
const jt = new Set(['JT3-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa']);
const fixedPlace = { id: 'PL-1001', name: 'Fast plats', roles: ['from'], allowedJobTypeIds: [], geofence: {}, geocoding: { status: 'empty', latitude: null, longitude: null }, canBeReturnPlace: false, jobTypeFromIds: [], jobTypeToIds: [], createdAt: '2026-01-01T00:00:00Z', updatedAt: '2026-01-01T00:00:00Z' };
const placeRegistry = { schemaVersion: places.SCHEMA_VERSION, revision: 0, items: [fixedPlace], deletedFixedIds: [] };
const removedPlace = places.removeFromRegistry(placeRegistry, fixedPlace, jt, '2026-01-02T00:00:00Z');
assert.strictEqual(removedPlace.deletedFixedIds.join(','), 'PL-1001'); assert.strictEqual(removedPlace.items.length, 0);
assert.strictEqual(places.migrateRegistry(removedPlace, [fixedPlace], jt, '2026-01-03T00:00:00Z').registry.items.length, 0);
const manualPlace = places.createItem({ name: 'Manuell plats', geofence: {} }, [], jt); assert.strictEqual(places.removeItem(manualPlace, [manualPlace], jt).length, 0);
const fixedBeach = { id: 'PL-2001', name: 'Fast badplats', category: 'badplats', roles: ['from', 'destination', 'return', 'beach'], allowedJobTypeIds: ['JT-1010'], geofence: {}, geocoding: { status: 'empty', latitude: null, longitude: null }, coordinatesPending: true, active: true, hidden: false, mergedIntoId: '', createdAt: '2026-01-01T00:00:00Z', updatedAt: '2026-01-01T00:00:00Z' };
const beachRegistry = { schemaVersion: beaches.SCHEMA_VERSION, revision: 0, items: [fixedBeach], deletedFixedIds: [] };
const removedBeach = beaches.removeFromRegistry(beachRegistry, fixedBeach, '2026-01-02T00:00:00Z');
assert.strictEqual(removedBeach.deletedFixedIds.join(','), 'PL-2001'); assert.strictEqual(removedBeach.items.length, 0);
assert.strictEqual(beaches.migrateRegistry(removedBeach, [fixedBeach], '2026-01-03T00:00:00Z').registry.items.length, 0);
assert.ok(!JSON.stringify(removedBeach.items).includes('geofence'));
const beachWithoutRemovedJobType = beaches.withItems(beachRegistry, [{ ...fixedBeach, allowedJobTypeIds: [] }], '2026-01-03T00:00:00Z');
assert.deepStrictEqual(Array.from(beaches.buildEffectivePlaces([], beachWithoutRemovedJobType)[0].allowedJobTypeIds), []);
console.log('PASS v93-registry-permanent-delete.test.js');
