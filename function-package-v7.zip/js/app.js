(() => {
  'use strict';

  const PACKAGE_VERSION = 7;
  const MINIMUM_HOST_VERSION = 4;
  const SETTINGS_STORE = 'settings';
  const QUEUE_STORE = 'queue';
  const ACTIVE_JOB_STORE = 'activeJob';
  const UI_SETTINGS_KEY = 'uiPreferencesV1';
  const PAGE_TITLES = Object.freeze({ home: 'Start', queue: 'Kö', active: 'Aktivt jobb', settings: 'Inställningar' });
  const ACTIVE_STATUSES = Object.freeze(['active', 'paused']);
  const ACTIVE_PHASES = Object.freeze(['loading', 'transport']);

  let hostInfo = null;
  let settingsDocument = {};
  let queueDocument = [];
  let queueLoaded = false;
  let pendingQueueDeleteId = '';
  let activeJobDocument = {};
  let activeJobLoaded = false;
  let pendingActiveReset = false;
  let updatePollTimer = null;

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function parseObject(raw, fallback = {}) {
    try {
      const value = JSON.parse(raw);
      return isPlainObject(value) ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function readSettingsDocument() {
    const raw = window.StadslassHost.readStore(SETTINGS_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Inställningslagret kunde inte läsas.');
    }
    return parseObject(raw, {});
  }

  function readQueueDocument() {
    const raw = window.StadslassHost.readStore(QUEUE_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Kölagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Kölagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Kölagret har fel format och har inte ändrats.');
    }
    return value;
  }

  function readActiveJobDocument() {
    const raw = window.StadslassHost.readStore(ACTIVE_JOB_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Lagret för aktivt jobb kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Lagret för aktivt jobb innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!isPlainObject(value)) {
      throw new Error('Lagret för aktivt jobb har fel format och har inte ändrats.');
    }
    if (Object.keys(value).length === 0) {
      return value;
    }
    const id = text(value.id);
    const status = text(value.status);
    const phase = text(value.phase);
    if (!id || !ACTIVE_STATUSES.includes(status) || !ACTIVE_PHASES.includes(phase)) {
      throw new Error('Lagret för aktivt jobb har en okänd struktur och har inte ändrats.');
    }
    return value;
  }

  function normalizedUiPreferences(documentValue) {
    const value = parseObject(JSON.stringify(documentValue[UI_SETTINGS_KEY] || {}), {});
    return {
      largeText: value.largeText === true,
      showTechnicalInfo: value.showTechnicalInfo === true
    };
  }

  function applyUiPreferences(preferences) {
    document.documentElement.classList.toggle('large-text', preferences.largeText);
    byId('large-text').checked = preferences.largeText;
    byId('show-technical').checked = preferences.showTechnicalInfo;
    byId('technical-panel').hidden = !preferences.showTechnicalInfo;
  }

  function showStatus(elementId, message, isError = false) {
    const element = byId(elementId);
    element.textContent = message;
    element.classList.toggle('is-error', isError);
  }

  function showView(target) {
    if (!Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) {
      return;
    }
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.hidden = view.dataset.view !== target;
    });
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      const active = button.dataset.target === target;
      button.classList.toggle('is-active', active);
      if (active) {
        button.setAttribute('aria-current', 'page');
      } else {
        button.removeAttribute('aria-current');
      }
    });
    byId('page-title').textContent = PAGE_TITLES[target];
    byId('main-content').focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function isMobileRole() {
    return hostInfo && hostInfo.role === 'mobile';
  }

  function isVehicleRole() {
    return hostInfo && hostInfo.role === 'vehicle_189';
  }

  function canUseQueue() {
    return isMobileRole() || isVehicleRole();
  }

  function canUseActiveJob() {
    return isVehicleRole();
  }

  function renderQueueRoleCopy() {
    if (isMobileRole()) {
      byId('queue-heading').textContent = 'Mobilens planeringskö';
      byId('queue-summary-text').textContent = 'Planeringskön laddas endast i denna vy och sparas lokalt på mobilen.';
      byId('queue-form-heading').textContent = 'Lägg till planerat uppdrag';
      byId('queue-form-intro').textContent = 'Detta är manuell lokal planering. Inget uppdrag överförs till 189 i detta paket.';
      byId('queue-submit-button').textContent = 'Lägg i planeringskö';
      byId('queue-list-heading').textContent = 'Planerad kö';
    } else if (isVehicleRole()) {
      byId('queue-heading').textContent = '189:s operativa kö';
      byId('queue-summary-text').textContent = 'Den operativa kön är lokal på 189 och hålls åtskild från Mobilens planeringskö.';
      byId('queue-form-heading').textContent = 'Lägg till mottaget testuppdrag';
      byId('queue-form-intro').textContent = 'Tillfällig lokal inmatning används tills kontrollerad överföring eller sync byggs. Ingen produktionsdata läses.';
      byId('queue-submit-button').textContent = 'Lägg i operativ kö';
      byId('queue-list-heading').textContent = 'Operativ kö';
    }
  }

  function applyRoleBoundaries() {
    const queueAllowed = canUseQueue();
    const activeAllowed = canUseActiveJob();
    byId('open-queue').hidden = !queueAllowed;
    byId('open-active-job').hidden = !activeAllowed;
    document.querySelector('.nav-button[data-target="queue"]').hidden = !queueAllowed;
    document.querySelector('.nav-button[data-target="active"]').hidden = !activeAllowed;
    renderQueueRoleCopy();
    document.documentElement.classList.toggle('vehicle-role', isVehicleRole());

    if (isMobileRole()) {
      byId('home-heading').textContent = 'Planeringskö på Mobil';
      byId('home-module-summary').textContent = 'Mobilens lokala planeringskö är bevarad. Aktivt jobb och 189:s operativa kö styrs inte från mobilen.';
      byId('home-store-title').textContent = 'Inställningar + planeringskö';
      byId('home-store-text').textContent = 'Planeringskön läses först när du öppnar kövyn. Aktivt jobb läses inte på Mobil.';
      byId('role-boundary-note').textContent = 'Aktivt jobb på 189 är avsiktligt dolt och blockerat på denna roll.';
      byId('active-role-note').textContent = 'Aktivt jobb är blockerat på Mobil i detta steg.';
    } else if (isVehicleRole()) {
      byId('home-heading').textContent = 'Operativ kö och aktivt jobb på 189';
      byId('home-module-summary').textContent = '189 har nu en separat lokal driftkö. Ett valt köuppdrag kan startas som Aktivt jobb.';
      byId('home-store-title').textContent = 'Inställningar + operativ kö + aktivt jobb';
      byId('home-store-text').textContent = 'Kö och Aktivt jobb läses var för sig först när respektive funktion används.';
      byId('role-boundary-note').textContent = 'Mobilens planeringskö läses inte. Den visade kön är 189:s lokala operativa kö.';
      byId('active-role-note').textContent = 'Aktivt jobb är tillgängligt på denna 189 / Surfplatta.';
    }
  }

  function activateView(target) {
    if (target === 'queue' && !canUseQueue()) {
      showView('home');
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (target === 'active' && !canUseActiveJob()) {
      showView('home');
      showStatus('role-boundary-note', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    showView(target);
    if (target === 'queue') {
      loadQueueIfNeeded();
    } else if (target === 'active') {
      loadActiveJobIfNeeded();
    }
  }

  function renderHostInfo() {
    const role = hostInfo.roleLabel || hostInfo.role || 'Okänd roll';
    byId('role-chip').textContent = role;
    byId('host-version').textContent = `${hostInfo.hostVersionName} (${hostInfo.hostVersionCode})`;
    byId('package-version').textContent = String(hostInfo.packageVersion);
    byId('technical-role').textContent = role;
    byId('device-id').textContent = hostInfo.deviceId || 'Saknas';
  }

  function renderPreservedTestValue() {
    const testValue = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    byId('module-test-value').textContent = String(testValue);
  }

  function saveSettings(event) {
    event.preventDefault();
    const nextPreferences = {
      largeText: byId('large-text').checked,
      showTechnicalInfo: byId('show-technical').checked
    };
    const nextDocument = {
      ...settingsDocument,
      [UI_SETTINGS_KEY]: nextPreferences,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('save-status', window.StadslassHost.getLastError() || 'Inställningarna kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    applyUiPreferences(nextPreferences);
    showStatus('save-status', 'Inställningarna är sparade.');
  }

  function incrementPreservedTestValue() {
    const current = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    const nextDocument = { ...settingsDocument, moduleTestValue: current + 1 };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('storage-status', window.StadslassHost.getLastError() || 'Testvärdet kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    renderPreservedTestValue();
    showStatus('storage-status', 'Testvärdet är sparat i inställningslagret.');
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return '';
    }
    const parts = value.split('-').map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return new Intl.DateTimeFormat('sv-SE', { year: 'numeric', month: 'short', day: 'numeric' }).format(date);
  }

  function formatTimestamp(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return 'Saknas';
    }
    return new Intl.DateTimeFormat('sv-SE', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    }).format(date);
  }

  function createLocalId(prefix) {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(random);
    } else {
      random[0] = Math.floor(Math.random() * 0xffffffff);
      random[1] = Math.floor(Math.random() * 0xffffffff);
    }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function displayQueueItem(item, index) {
    const source = isPlainObject(item) ? item : {};
    return {
      id: text(source.id, `legacy-${index}`),
      jobType: text(source.jobType, text(source.displayType, 'Uppdrag')),
      from: text(source.from, text(source.placeLabel, 'Från saknas')),
      destination: text(source.destination, text(source.destLabel, 'Till saknas')),
      plannedDate: text(source.plannedDate),
      plannedTime: text(source.plannedTime),
      source: text(source.source)
    };
  }

  function queueMetaChip(label, extraClass = '') {
    const chip = document.createElement('span');
    chip.className = `meta-chip${extraClass ? ` ${extraClass}` : ''}`;
    chip.textContent = label;
    return chip;
  }

  function queueItemIndexById(id) {
    return queueDocument.findIndex((candidate, index) => displayQueueItem(candidate, index).id === id);
  }

  function queueItemById(id) {
    const index = queueItemIndexById(id);
    return index >= 0 ? { index, raw: queueDocument[index], display: displayQueueItem(queueDocument[index], index) } : null;
  }

  function activeJobMatchesQueueItem(id) {
    return activeJobLoaded && activeJobExists() && text(activeJobDocument.sourceQueueItemId) === id;
  }

  function renderQueue() {
    const list = byId('queue-list');
    list.replaceChildren();
    byId('queue-count').textContent = String(queueDocument.length);

    if (queueDocument.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Kön är tom.';
      list.appendChild(empty);
      return;
    }

    const today = localDateKey(new Date());
    queueDocument.forEach((rawItem, index) => {
      const item = displayQueueItem(rawItem, index);
      const card = document.createElement('article');
      card.className = 'queue-card';
      card.dataset.queueId = item.id;

      const header = document.createElement('div');
      header.className = 'queue-card-header';
      const heading = document.createElement('h3');
      heading.textContent = item.jobType;
      header.appendChild(heading);
      card.appendChild(header);

      const route = document.createElement('p');
      route.className = 'queue-route';
      route.textContent = `${item.from} → ${item.destination}`;
      card.appendChild(route);

      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      if (item.plannedDate) {
        meta.appendChild(queueMetaChip(formatDate(item.plannedDate) || item.plannedDate));
        if (item.plannedDate > today) {
          meta.appendChild(queueMetaChip('Framtida uppdrag', 'future'));
        }
      } else {
        meta.appendChild(queueMetaChip('Datum saknas'));
      }
      if (item.plannedTime) {
        meta.appendChild(queueMetaChip(`Kl. ${item.plannedTime}`));
      }
      card.appendChild(meta);

      if (isVehicleRole()) {
        const startButton = document.createElement('button');
        startButton.type = 'button';
        startButton.className = 'primary-button queue-start-button';
        startButton.dataset.startQueueItem = item.id;
        if (activeJobMatchesQueueItem(item.id)) {
          startButton.textContent = 'Slutför flytt till Aktivt jobb';
        } else if (activeJobLoaded && activeJobExists()) {
          startButton.textContent = 'Aktivt jobb pågår';
          startButton.disabled = true;
        } else {
          startButton.textContent = 'Starta som Aktivt jobb';
        }
        card.appendChild(startButton);
      }

      if (pendingQueueDeleteId === item.id) {
        const confirm = document.createElement('div');
        confirm.className = 'inline-confirm confirm-actions';
        const message = document.createElement('p');
        message.textContent = 'Ta bort detta uppdrag från kön?';
        const accept = document.createElement('button');
        accept.type = 'button';
        accept.className = 'danger-button is-solid';
        accept.dataset.confirmQueueDelete = item.id;
        accept.textContent = 'Bekräfta borttagning';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'secondary-button';
        cancel.dataset.cancelQueueDelete = item.id;
        cancel.textContent = 'Avbryt';
        confirm.append(message, accept, cancel);
        card.appendChild(confirm);
      } else {
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'danger-button';
        remove.dataset.requestQueueDelete = item.id;
        remove.textContent = 'Ta bort från kö';
        card.appendChild(remove);
      }
      list.appendChild(card);
    });
  }

  function loadQueueIfNeeded() {
    if (!canUseQueue()) {
      showStatus('role-boundary-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (queueLoaded) {
      return;
    }
    try {
      queueDocument = readQueueDocument();
      queueLoaded = true;
      renderQueue();
      showStatus('queue-load-status', 'Kön är lokalt inläst.');
    } catch (error) {
      showStatus('queue-load-status', error.message || 'Kön kunde inte läsas.', true);
    }
  }

  function persistQueue(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('queue-form-status', window.StadslassHost.getLastError() || 'Kön kunde inte sparas.', true);
      return false;
    }
    queueDocument = nextDocument;
    queueLoaded = true;
    pendingQueueDeleteId = '';
    renderQueue();
    showStatus('queue-form-status', successMessage);
    return true;
  }

  function createQueueItem(event) {
    event.preventDefault();
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded) {
      loadQueueIfNeeded();
    }
    if (!queueLoaded) {
      showStatus('queue-form-status', 'Kön måste kunna läsas innan ett uppdrag kan sparas.', true);
      return;
    }

    const jobType = text(byId('job-type').value);
    const from = text(byId('job-from').value);
    const destination = text(byId('job-destination').value);
    const plannedDate = text(byId('planned-date').value);
    const plannedTime = text(byId('planned-time').value);

    if (!jobType || !from || !destination) {
      showStatus('queue-form-status', 'Fyll i jobbtyp, Från och Till.', true);
      return;
    }

    const item = {
      schemaVersion: 1,
      id: createLocalId('queue'),
      status: 'queued',
      source: isVehicleRole() ? 'manual-vehicle-received' : 'manual-mobile-planning',
      jobType,
      from,
      destination,
      plannedDate,
      plannedTime,
      createdAt: new Date().toISOString(),
      createdByPackageVersion: PACKAGE_VERSION
    };
    const nextDocument = [...queueDocument, item];
    const successMessage = isVehicleRole()
      ? 'Uppdraget är sparat i 189:s lokala operativa kö.'
      : 'Uppdraget är sparat i Mobilens lokala planeringskö.';
    if (persistQueue(nextDocument, successMessage)) {
      byId('queue-form').reset();
    }
  }

  function requestQueueDelete(id) {
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded || queueItemIndexById(id) < 0) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    pendingQueueDeleteId = id;
    renderQueue();
    showStatus('queue-form-status', 'Bekräfta borttagningen eller avbryt.');
  }

  function cancelQueueDelete(id) {
    if (pendingQueueDeleteId !== id) {
      return;
    }
    pendingQueueDeleteId = '';
    renderQueue();
    showStatus('queue-form-status', 'Borttagningen avbröts. Kön är oförändrad.');
  }

  function confirmQueueDelete(id) {
    if (!canUseQueue() || pendingQueueDeleteId !== id) {
      showStatus('queue-form-status', 'Borttagningen kunde inte bekräftas och kön är oförändrad.', true);
      return;
    }
    const index = queueItemIndexById(id);
    if (index < 0) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    persistQueue(nextDocument, 'Uppdraget är borttaget från kön.');
  }

  function removeQueueItemByIndex(index, successMessage) {
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    return persistQueue(nextDocument, successMessage);
  }

  function startQueueItem(id) {
    if (!isVehicleRole()) {
      showStatus('queue-form-status', 'Endast 189 / Surfplatta får starta ett uppdrag från den operativa kön.', true);
      return;
    }
    if (!queueLoaded) {
      loadQueueIfNeeded();
    }
    const selected = queueItemById(id);
    if (!queueLoaded || !selected) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    if (!activeJobLoaded) {
      loadActiveJobIfNeeded();
    }
    if (!activeJobLoaded) {
      showStatus('queue-form-status', 'Aktivt-jobb-lagret måste kunna läsas innan uppdraget startas.', true);
      return;
    }

    if (activeJobExists()) {
      if (text(activeJobDocument.sourceQueueItemId) === id) {
        if (removeQueueItemByIndex(selected.index, 'Köposten togs bort. Uppdraget var redan säkert sparat som Aktivt jobb.')) {
          activateView('active');
          showStatus('active-load-status', 'Uppdraget är aktivt och den kvarvarande köposten har städats bort.');
        }
      } else {
        renderQueue();
        showStatus('queue-form-status', 'Ett annat aktivt jobb pågår. Köuppdraget har inte ändrats.', true);
      }
      return;
    }

    const item = selected.display;
    const now = new Date().toISOString();
    const nextActiveJob = {
      schemaVersion: 1,
      id: createLocalId('active'),
      status: 'active',
      phase: 'loading',
      source: 'vehicle-queue',
      sourceQueueItemId: item.id,
      sourceQueueSnapshot: selected.raw,
      jobType: item.jobType,
      from: item.from,
      destination: item.destination,
      plannedDate: item.plannedDate,
      plannedTime: item.plannedTime,
      startedAt: now,
      updatedAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: [{ type: 'job_started_from_queue', at: now, source: 'vehicle-queue', packageVersion: PACKAGE_VERSION }]
    };

    if (!persistActiveJob(nextActiveJob, 'Köuppdraget sparades först som Aktivt jobb.')) {
      showStatus('queue-form-status', 'Aktivt jobb kunde inte sparas. Köposten är oförändrad.', true);
      return;
    }

    if (!removeQueueItemByIndex(selected.index, 'Uppdraget flyttades från 189:s operativa kö till Aktivt jobb.')) {
      renderQueue();
      showStatus('queue-form-status', 'Aktivt jobb är säkert sparat, men köposten kunde inte tas bort. Tryck på startknappen igen för att slutföra flytten.', true);
      return;
    }

    activateView('active');
    showStatus('active-load-status', 'Uppdraget startades från 189:s operativa kö.');
  }

  function activeJobExists() {
    return isPlainObject(activeJobDocument) && Boolean(text(activeJobDocument.id));
  }

  function activeEvents(documentValue) {
    return Array.isArray(documentValue.events) ? documentValue.events.filter(isPlainObject) : [];
  }

  function phaseLabel(phase) {
    return phase === 'transport' ? 'Transport' : 'Lastning / start';
  }

  function statusLabel(status) {
    return status === 'paused' ? 'Pausat' : 'Aktivt';
  }

  function renderActiveJob() {
    const emptyCard = byId('active-empty-card');
    const jobCard = byId('active-job-card');
    const pill = byId('active-status-pill');
    emptyCard.hidden = true;
    jobCard.hidden = true;
    pill.classList.remove('is-active', 'is-paused');

    if (!activeJobLoaded) {
      pill.textContent = 'Ej laddat';
      return;
    }
    if (!activeJobExists()) {
      pendingActiveReset = false;
      pill.textContent = 'Inget jobb';
      emptyCard.hidden = false;
      return;
    }

    const status = text(activeJobDocument.status, 'active');
    const phase = text(activeJobDocument.phase, 'loading');
    pill.textContent = statusLabel(status);
    pill.classList.add(status === 'paused' ? 'is-paused' : 'is-active');
    byId('active-display-type').textContent = text(activeJobDocument.jobType, 'Uppdrag');
    byId('active-route').textContent = `${text(activeJobDocument.from, 'Från saknas')} → ${text(activeJobDocument.destination, 'Till saknas')}`;
    byId('active-display-status').textContent = statusLabel(status);
    byId('active-display-phase').textContent = phaseLabel(phase);
    byId('active-display-started').textContent = formatTimestamp(activeJobDocument.startedAt);
    byId('active-event-count').textContent = String(activeEvents(activeJobDocument).length);
    byId('active-phase-action').hidden = status !== 'active' || phase !== 'loading';
    byId('active-pause-action').textContent = status === 'paused' ? 'Fortsätt' : 'Pausa';
    byId('active-reset-request').hidden = pendingActiveReset;
    byId('active-reset-confirm').hidden = !pendingActiveReset;
    jobCard.hidden = false;
  }

  function loadActiveJobIfNeeded() {
    if (!canUseActiveJob()) {
      showStatus('active-role-note', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (activeJobLoaded) {
      return;
    }
    try {
      activeJobDocument = readActiveJobDocument();
      activeJobLoaded = true;
      renderActiveJob();
      showStatus('active-load-status', activeJobExists() ? 'Aktivt jobb är lokalt inläst.' : 'Inget aktivt jobb finns.');
    } catch (error) {
      renderActiveJob();
      showStatus('active-load-status', error.message || 'Aktivt jobb kunde inte läsas.', true);
    }
  }

  function persistActiveJob(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(ACTIVE_JOB_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('active-action-status', window.StadslassHost.getLastError() || 'Aktivt jobb kunde inte sparas.', true);
      return false;
    }
    activeJobDocument = nextDocument;
    activeJobLoaded = true;
    pendingActiveReset = false;
    renderActiveJob();
    showStatus('active-action-status', successMessage);
    return true;
  }

  function appendActiveEvent(documentValue, type, at) {
    return [...activeEvents(documentValue), { type, at, source: 'manual', packageVersion: PACKAGE_VERSION }];
  }

  function createActiveJob(event) {
    event.preventDefault();
    if (!canUseActiveJob()) {
      showStatus('active-form-status', 'Aktivt jobb är blockerat på denna enhetsroll.', true);
      return;
    }
    if (!activeJobLoaded) {
      loadActiveJobIfNeeded();
    }
    if (!activeJobLoaded) {
      showStatus('active-form-status', 'Lagret måste kunna läsas innan ett uppdrag kan startas.', true);
      return;
    }
    if (activeJobExists()) {
      showStatus('active-form-status', 'Ett aktivt jobb finns redan och har inte ersatts.', true);
      return;
    }

    const jobType = text(byId('active-job-type').value);
    const from = text(byId('active-job-from').value);
    const destination = text(byId('active-job-destination').value);
    if (!jobType || !from || !destination) {
      showStatus('active-form-status', 'Fyll i jobbtyp, Från och Till.', true);
      return;
    }

    const now = new Date().toISOString();
    const nextDocument = {
      schemaVersion: 1,
      id: createLocalId('active'),
      status: 'active',
      phase: 'loading',
      source: 'manual-local',
      jobType,
      from,
      destination,
      startedAt: now,
      updatedAt: now,
      createdByPackageVersion: PACKAGE_VERSION,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: [{ type: 'job_started', at: now, source: 'manual', packageVersion: PACKAGE_VERSION }]
    };
    if (persistActiveJob(nextDocument, 'Uppdraget startades och sparades lokalt före visning.')) {
      byId('active-form').reset();
    }
  }

  function startTransport() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    if (activeJobDocument.status !== 'active' || activeJobDocument.phase !== 'loading') {
      showStatus('active-action-status', 'Transport kan bara startas från aktiv lastnings-/startfas.', true);
      return;
    }
    const now = new Date().toISOString();
    const nextDocument = {
      ...activeJobDocument,
      phase: 'transport',
      transportStartedAt: now,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, 'transport_started', now)
    };
    persistActiveJob(nextDocument, 'Transport påbörjades och sparades lokalt.');
  }

  function toggleActivePause() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Aktivt jobb kunde inte ändras.', true);
      return;
    }
    const nextStatus = activeJobDocument.status === 'paused' ? 'active' : 'paused';
    const now = new Date().toISOString();
    const nextDocument = {
      ...activeJobDocument,
      status: nextStatus,
      updatedAt: now,
      updatedByPackageVersion: PACKAGE_VERSION,
      events: appendActiveEvent(activeJobDocument, nextStatus === 'paused' ? 'job_paused' : 'job_resumed', now)
    };
    persistActiveJob(nextDocument, nextStatus === 'paused' ? 'Uppdraget pausades och sparades lokalt.' : 'Uppdraget fortsätter och sparades lokalt.');
  }

  function requestActiveReset() {
    if (!canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      return;
    }
    pendingActiveReset = true;
    renderActiveJob();
    showStatus('active-action-status', 'Bekräfta avbrottet eller avbryt.');
  }

  function cancelActiveReset() {
    pendingActiveReset = false;
    renderActiveJob();
    showStatus('active-action-status', 'Avbrottet avbröts. Aktivt jobb är oförändrat.');
  }

  function confirmActiveReset() {
    if (!pendingActiveReset || !canUseActiveJob() || !activeJobLoaded || !activeJobExists()) {
      showStatus('active-action-status', 'Avbrottet kunde inte bekräftas.', true);
      return;
    }
    if (persistActiveJob({}, 'Det lokala uppdraget avbröts. Ingen historik ändrades.')) {
      showStatus('active-load-status', 'Det lokala uppdraget avbröts. Inget aktivt jobb finns.');
    }
  }

  function refreshUpdateStatus() {
    if (!bridgeAvailable()) {
      return;
    }
    const textValue = window.StadslassHost.getUpdateStatus();
    byId('update-status').textContent = textValue || hostInfo.updateStatus || 'Ingen uppdateringsstatus tillgänglig.';
  }

  function requestUpdateCheck() {
    byId('update-status').textContent = 'Söker efter funktionsuppdatering…';
    window.StadslassHost.requestUpdateCheck();
    window.setTimeout(refreshUpdateStatus, 250);
  }

  function installEventHandlers() {
    byId('open-queue').addEventListener('click', () => activateView('queue'));
    byId('open-active-job').addEventListener('click', () => activateView('active'));
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      button.addEventListener('click', () => activateView(button.dataset.target));
    });
    byId('settings-form').addEventListener('submit', saveSettings);
    byId('increment-test').addEventListener('click', incrementPreservedTestValue);
    byId('check-update').addEventListener('click', requestUpdateCheck);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());
    byId('queue-form').addEventListener('submit', createQueueItem);
    byId('queue-list').addEventListener('click', (event) => {
      const startButton = event.target.closest('button[data-start-queue-item]');
      const requestButton = event.target.closest('button[data-request-queue-delete]');
      const confirmButton = event.target.closest('button[data-confirm-queue-delete]');
      const cancelButton = event.target.closest('button[data-cancel-queue-delete]');
      if (startButton) {
        startQueueItem(startButton.dataset.startQueueItem || '');
      } else if (requestButton) {
        requestQueueDelete(requestButton.dataset.requestQueueDelete || '');
      } else if (confirmButton) {
        confirmQueueDelete(confirmButton.dataset.confirmQueueDelete || '');
      } else if (cancelButton) {
        cancelQueueDelete(cancelButton.dataset.cancelQueueDelete || '');
      }
    });
    byId('active-form').addEventListener('submit', createActiveJob);
    byId('active-phase-action').addEventListener('click', startTransport);
    byId('active-pause-action').addEventListener('click', toggleActivePause);
    byId('active-reset-request').addEventListener('click', requestActiveReset);
    byId('active-reset-cancel').addEventListener('click', cancelActiveReset);
    byId('active-reset-confirm-button').addEventListener('click', confirmActiveReset);
  }

  function verifyRuntime() {
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    const styleReady = getComputedStyle(document.documentElement).getPropertyValue('--module-style-ready').trim();
    if (styleReady !== '1') {
      throw new Error('Modulens CSS kunde inte verifieras.');
    }
    hostInfo = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!hostInfo) {
      throw new Error('Värdinformationen kunde inte läsas.');
    }
    if (Number(hostInfo.hostVersionCode) < MINIMUM_HOST_VERSION) {
      throw new Error('Värdappen är för gammal för funktionspaket 7.');
    }
    if (Number(hostInfo.packageVersion) !== PACKAGE_VERSION) {
      throw new Error('Paketversionen i värdbryggan stämmer inte.');
    }
  }

  function start() {
    try {
      verifyRuntime();
      settingsDocument = readSettingsDocument();
      applyUiPreferences(normalizedUiPreferences(settingsDocument));
      renderHostInfo();
      applyRoleBoundaries();
      renderPreservedTestValue();
      installEventHandlers();
      refreshUpdateStatus();
      updatePollTimer = window.setInterval(refreshUpdateStatus, 2500);
      window.StadslassHost.markReady(PACKAGE_VERSION);
    } catch (error) {
      document.body.innerHTML = '<main class="content"><article class="section-card"><h1>Modulen kunde inte starta</h1><p></p></article></main>';
      document.querySelector('p').textContent = error.message || 'Okänt startfel.';
    }
  }

  window.addEventListener('beforeunload', () => {
    if (updatePollTimer !== null) {
      window.clearInterval(updatePollTimer);
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
