(() => {
  'use strict';
  const labels = Object.freeze({ loading: 'Lastning', unloading: 'Lossning', return_unloading: 'Returlossning' });
  const statuses = new Set(['shown', 'app_visible', 'no_external_handoff', 'permission_denied', 'stale_request', 'invalid_request', 'origin_denied', 'host_error']);
  function afterCommit(previous, current, host, hostInfo) {
    if (!previous || !current || previous.status !== 'active' || current.status !== 'active'
      || previous.phase === current.phase || !labels[current.phase]) return { requested: false };
    const previousId = previous.jobId || previous.id, currentId = current.jobId || current.id;
    if (!previousId || previousId !== currentId) return { requested: false };
    if (!host || typeof host.requestPhaseReminder !== 'function' || !hostInfo || Number(hostInfo.phaseReminderApiVersion) < 1) {
      return { requested: false, unavailable: true };
    }
    try {
      const response = JSON.parse(host.requestPhaseReminder(JSON.stringify({ phaseLabel: labels[current.phase] })));
      if (!response || !statuses.has(response.status) || typeof response.ok !== 'boolean'
        || response.ok !== (response.status === 'shown')) return { requested: true, malformed: true };
      return { requested: true, status: response.status, shown: response.ok };
    } catch (_) { return { requested: true, malformed: true }; }
  }
  window.StadslassPhaseReminderService = Object.freeze({ afterCommit });
})();
