(() => {
  'use strict';
  // Temporary P200 observer; never changes business state or owns GPS.
  const runtimeId = 'js_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
  let timer = null, lastBeat = 0, view = 'home', until = 0;
  const mono = () => window.performance && typeof window.performance.now === 'function' ? window.performance.now() : Date.now();
  function envelope(event, data) { return JSON.stringify({ event, runtimeId, jsMonoMs: mono(), data }); }
  const recent = new Map();
  function record(event, data = {}) {
    try {
      if (['gps.consumer','gps.start-watch','geofence.before'].includes(event)
          || (event === 'geofence.result' && ['STATE_STABLE','POSITION_UNUSABLE'].includes(data.reason))) {
        const identity = JSON.stringify({...data, ageMs:undefined}), old = recent.get(event), now = mono();
        if (old && old.identity === identity && now - old.at < 2000) return;
        recent.set(event, {identity, at:now});
      }
      const host = window.StadslassHost;
      if (host && typeof host.recordDiagnosticEvent === 'function') host.recordDiagnosticEvent(envelope(event, data));
    } catch (_) {} // Observations must never escape into the work flow.
  }
  function stop() { if (timer !== null) window.clearTimeout(timer); timer = null; }
  function resume() {
    try {
      const host = window.StadslassHost;
      if (!host || typeof host.diagnosticTraceStatus !== 'function') return;
      const state = JSON.parse(host.diagnosticTraceStatus());
      if (!state.active) { stop(); return; }
      until = Number(state.untilWall) || 0;
      if (timer !== null) return;
      lastBeat = mono();
      timer = window.setTimeout(beat, 2000);
    } catch (_) { stop(); }
  }
  function beat() {
    timer = null;
    try {
      const now = mono();
      record('js.heartbeat', { gapMs: now - lastBeat, foreground: document.visibilityState !== 'hidden' });
      lastBeat = now;
      if (Date.now() < until) resume();
    } catch (_) { stop(); }
  }
  function begin(phase) {
    try {
      const host = window.StadslassHost;
      if (!host || typeof host.beginDiagnosticTrace !== 'function') return;
      host.beginDiagnosticTrace(envelope('navigation.before', { view, phase, active: true, packageVersion: 200 }));
      record('navigation.before', { view, phase, active: true, packageVersion: 200 });
      const gps = window.StadslassGpsService;
      if (gps) {
        const s = gps.getSnapshot();
        record('gps.trace-baseline', {watchRegistered:s.isWatching, usable:s.isUsable, accuracy:s.accuracy,
          ageMs:s.age, providerAt:s.timestamp, foreground:s.appState === 'förgrund'});
      }
      const geofence = window.StadslassGeofenceService;
      if (geofence) {
        const g = geofence.getSnapshot();
        record('geofence.trace-baseline', {active:g.active, before:g.confirmedState,
          role:g.context ? g.context.placeRole : 'none'});
      }
      resume();
    } catch (_) {}
  }
  function route(value) { try { view = value; record('route.current', {view}); } catch (_) {} }
  function exportTrace() {
    try {
      const host = window.StadslassHost;
      if (!host || typeof host.exportDiagnosticTrace !== 'function') return 'Diagnostikexport kräver Host38.';
      const result = JSON.parse(host.exportDiagnosticTrace());
      return result.ok ? 'Androids delningsruta öppnas.' : 'Diagnostiken kunde inte exporteras. Försök igen när exporten är ledig.';
    } catch (_) { return 'Diagnostiken kunde inte exporteras.'; }
  }
  window.StadslassBackgroundDiagnostic = Object.freeze({ record, begin, route, resume, exportTrace });
  record('js.init', {packageVersion:200, view});
  resume();
  window.addEventListener('pagehide', () => { record('js.pagehide', {view}); stop(); });
  document.addEventListener('visibilitychange', () => {
    record('js.visibility', {foreground:document.visibilityState !== 'hidden', view}); resume();
  });
})();
