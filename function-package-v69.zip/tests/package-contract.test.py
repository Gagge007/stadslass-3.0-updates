#!/usr/bin/env python3
"""Static package contract for Stadslass 3.0 function package 69."""
import hashlib, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def require(value,message):
    if not value: raise AssertionError(message)
module=json.loads((ROOT/'module.json').read_text(encoding='utf-8'))
app=(ROOT/'js/app.js').read_text(encoding='utf-8')
service=(ROOT/'js/sync-service.js').read_text(encoding='utf-8')
diagnostic=(ROOT/'js/sync-diagnostic.js').read_text(encoding='utf-8')
performance=(ROOT/'js/performance-monitor.js').read_text(encoding='utf-8')
html=(ROOT/'index.html').read_text(encoding='utf-8')
functions=json.loads((ROOT/'data/functions.json').read_text(encoding='utf-8'))
require(module['packageVersion']==69,'module packageVersion must be 69')
require(module['minHostVersionCode']==13,'minHostVersionCode must remain 13')
require(module['packageType']=='stadslass-web-module','package type changed')
require("const PACKAGE_VERSION = 69;" in app and "const PACKAGE_VERSION = 69;" in service,'runtime package version mismatch')
require('js/performance-monitor.js' in html and 'js/sync-diagnostic.js' in html,'verification scripts missing')
require(html.index('js/performance-monitor.js') < html.index('js/sync-diagnostic.js') < html.index('js/app.js'),'script start order incorrect')
start=app.index('function start()')
require(start>=0 and app.index('monitor.start()',start)<app.index('verifyRuntime();',start),'performance monitor must start first')
for marker in ['migrateOutbox','consumeTerminal','duplicate_pending','MAX_TERMINAL_JOURNAL = 50','resourceState','setResourceState']:
    require(marker in service,f'missing sync service marker: {marker}')
for marker in ['SYNC_V69_OPTIONAL_GET_INTENTS','syncV69SchedulePutResolution','syncV69HandlePutResolution','waiting_result','localCounts.retryableRequests > 0','syncV69CycleRunning']:
    require(marker in app,f'missing app sync marker: {marker}')
require('getSyncRequestStatus' not in diagnostic,'light diagnostic must not enumerate host requests')
require('readStore(name)' in diagnostic and "read('syncOutbox')" in diagnostic and "read('settings')" in diagnostic,'light diagnostic stores missing')
require('STADSLASS PRESTANDARAPPORT' in performance and 'MAX_EVENTS = 300' in performance,'bounded performance report missing')
require('requestTextFileExport' in app and 'Stadslass_prestandarapport_v69_' in app,'performance export missing')
require('driftlogg_v4_full' not in app+service,'protected 2.0 store touched')
stores=set(re.findall(r"const\s+[A-Z_]+_STORE\s*=\s*'([^']+)'",app))
require(stores=={'settings','queue','activeJob','history','syncOutbox'},f'unexpected store set: {stores}')
required={'SYNC-QUEUE-SEPARATION-V69','SYNC-SHA-CONFLICT-V69','SYNC-PERFORMANCE-VERIFY-V69'}
found={x.get('id') for x in functions.get('functions',[])}
require(required<=found,f'missing functions: {required-found}')
for name in ['technical-test-report.json','sync-fix-v69-report.json','migration-report.json','preservation-contract-report.json','regression-report.json','security-report.json','performance-verification-report.json','deferred-practical-test-report.json']:
    report=json.loads((ROOT/'reports'/name).read_text(encoding='utf-8'))
    require(report.get('packageVersion')==69,f'{name} wrong version')
entries={x['path']:x for x in module['files']}
actual={str(path.relative_to(ROOT)).replace('\\','/') for path in ROOT.rglob('*') if path.is_file() and path.name!='module.json' and '__pycache__' not in path.parts and path.suffix!='.pyc' and '.pytest_cache' not in path.parts}
require(set(entries)==actual,f'manifest differs missing={sorted(actual-set(entries))} extra={sorted(set(entries)-actual)}')
for name,entry in entries.items():
    content=(ROOT/name).read_bytes()
    require(entry['size']==len(content),f'size mismatch {name}')
    require(entry['sha256']==hashlib.sha256(content).hexdigest(),f'hash mismatch {name}')
for path in ROOT.rglob('*'):
    if not path.is_file(): continue
    require(path.suffix.lower() not in {'.pem','.key','.p12','.pfx'},f'private key-like file included: {path}')
    if path.suffix.lower() in {'.js','.json','.html','.css','.py','.txt','.md'}:
        value=path.read_text(encoding='utf-8',errors='ignore')
        private_marker='BEGIN '+'PRIVATE KEY'; rsa_marker='BEGIN RSA '+'PRIVATE KEY'; require(private_marker not in value and rsa_marker not in value,f'private key content in {path}')
        local_prefix='/mnt'+'/data/'; require(local_prefix not in value,f'local path in {path}')
print(json.dumps({'status':'PASS','packageVersion':69,'files':len(entries),'stores':sorted(stores)},ensure_ascii=False))
