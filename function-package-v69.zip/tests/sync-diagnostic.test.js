'use strict';
const assert = require('assert');
const { TextEncoder } = require('util');
global.TextEncoder = TextEncoder;
global.performance = { now: () => Date.now() };
global.window = {};
const calls = [];
const stores = {
  syncOutbox: JSON.stringify([
    { id: 'active', kind: 'sync-v63-request', requestId: 'a', state: 'pending', request: { operation: 'GET', path: 'x', coalesceKey: 'get-active/189' } },
    { id: 'journal', kind: 'sync-v69-terminal-journal', items: [{ requestId: 'old', state: 'succeeded' }] },
    { id: 'work', kind: 'sync-v63-command', state: 'waiting_result', token: 'must-not-leak' }
  ]),
  settings: JSON.stringify({ syncV63: { enabled: true, token: 'must-not-leak' } })
};
require('../js/sync-diagnostic.js');
const diagnostic = window.StadslassSyncDiagnostic.create({ host: () => ({}), readStore: (name) => { calls.push(name); return stores[name]; } });
diagnostic.firstRoleView({ hostVersion: '3.0-host-16', role: 'mobile', syncConfiguration: { token: 'must-not-leak' } });
assert.strictEqual(calls.length, 0, 'first role view must not start a full inventory');
const result = diagnostic.inventory();
assert.strictEqual(result.ok, true);
assert.deepStrictEqual(calls, ['syncOutbox', 'settings']);
assert.strictEqual(result.counts.activeRequests, 1);
assert.strictEqual(result.counts.waitingCommands, 1);
assert.strictEqual(result.counts.journalItems, 1);
const report = diagnostic.report();
assert(report.includes('STADSLASS SYNKVERIFIERINGSRAPPORT'));
assert(!report.includes('must-not-leak'));
assert(!report.includes('FULLSTÄNDIG POSTLISTA'));
console.log('PASS sync-diagnostic.test.js');
