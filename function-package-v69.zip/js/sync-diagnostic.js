(() => {
  'use strict';
  const PACKAGE_VERSION = 69;
  const MAX_EVENTS = 400;
  const SECRET = /token|authorization|password|secret|private|signature|credential/i;
  const now = () => new Date().toISOString();
  const mono = () => typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value);
  const bytes = (value) => new TextEncoder().encode(typeof value === 'string' ? value : JSON.stringify(value || null)).length;
  const parse = (value, fallback = null) => { try { return JSON.parse(value); } catch (_) { return fallback; } };
  const mask = (value, key = '') => {
    if (SECRET.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.map((item) => mask(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, mask(item, name)]));
    if (typeof value === 'string') return value.length > 600 ? `${value.slice(0, 600)}…` : value;
    return value;
  };
  function classify(entries) {
    const list = Array.isArray(entries) ? entries : [];
    const requests = list.filter((entry) => entry && entry.kind === 'sync-v63-request');
    const journal = list.find((entry) => entry && entry.kind === 'sync-v69-terminal-journal');
    return {
      totalTopLevel: list.length,
      activeRequests: requests.filter((entry) => ['pending', 'running', 'accepted', 'failed_retryable', 'retryable'].includes(text(entry.state))).length,
      terminalRequestsStillInActiveStore: requests.filter((entry) => ['succeeded', 'failed_permanent', 'conflict', 'superseded'].includes(text(entry.state))).length,
      retryableRequests: requests.filter((entry) => ['failed_retryable', 'retryable'].includes(text(entry.state))).length,
      journalItems: journal && Array.isArray(journal.items) ? journal.items.length : 0,
      preparedTransfers: list.filter((entry) => entry && ['queue-transfer', 'queue-receipt'].includes(text(entry.kind)) && text(entry.state) === 'prepared').length,
      waitingCommands: list.filter((entry) => entry && entry.kind === 'sync-v63-command' && ['waiting_ledger', 'waiting_send', 'waiting_result', 'failed_retryable', 'sync_conflict'].includes(text(entry.state))).length,
      resourceStates: list.filter((entry) => entry && entry.kind === 'sync-v69-resource-state').length,
      putRetryControls: list.filter((entry) => entry && entry.kind === 'sync-v69-put-retry').length
    };
  }
  function create(environment) {
    const state = { startedAt: now(), firstRoleViewAt: '', inventoryStartedAt: '', inventoryFinishedAt: '', inventoryRunning: false, inventoryCount: 0, entryCount: 0, context: {}, events: [], registers: [], limitations: [], observed: 0, counts: {} };
    const event = (kind, details = {}) => {
      const value = mask({ at: now(), kind, ...details }); state.events.push(value); state.observed += 1;
      if (state.events.length > MAX_EVENTS) state.events.shift(); return value;
    };
    function read(name) {
      const started = mono();
      try {
        const raw = environment.readStore(name); const value = parse(raw, null);
        state.registers = state.registers.filter((item) => item.name !== name);
        state.registers.push({ name, byteLength: bytes(raw || ''), durationMs: Math.round(mono() - started), available: true });
        return value;
      } catch (error) {
        state.limitations.push(`${name}: ${text(error && error.message, 'kunde inte läsas')}`);
        state.registers.push({ name, byteLength: 0, durationMs: Math.round(mono() - started), available: false });
        return null;
      }
    }
    function inventory() {
      if (state.inventoryRunning) return { ok: false, status: 'already_running' };
      state.inventoryRunning = true; state.inventoryStartedAt = now(); state.inventoryCount += 1; const started = mono();
      try {
        const outbox = read('syncOutbox'); read('settings');
        state.counts = classify(outbox); state.entryCount = state.counts.totalTopLevel || 0;
        event('inventory-complete', { ...state.counts, durationMs: Math.round(mono() - started) });
        return { ok: true, status: 'completed', counts: { ...state.counts } };
      } finally { state.inventoryFinishedAt = now(); state.inventoryRunning = false; }
    }
    function firstRoleView(context = {}) { state.context = mask({ ...state.context, ...context }); state.firstRoleViewAt = now(); event('role-view-ready', { role: text(context.role), order: 'no-automatic-full-inventory' }); }
    function observe(kind, details = {}) { return event(kind, details); }
    function report() {
      const lines = ['STADSLASS SYNKVERIFIERINGSRAPPORT', 'Rapporttyp: Tillfällig riktad synkfix och verifiering', '', 'A. IDENTITET', `Start: ${state.startedAt}`, `Slut: ${now()}`, `Värdapp: ${text(state.context.hostVersion, 'Saknas')}`, `Funktionspaket: ${PACKAGE_VERSION}`, `Roll: ${text(state.context.role, 'Saknas')}`, `Installations-ID: ${text(state.context.installationId, 'Saknas')}`, `Enhets-ID: ${text(state.context.deviceId, 'Saknas')}`, `Synkkonfiguration: ${JSON.stringify(mask(state.context.syncConfiguration || {}))}`, '', 'B. KÖKLASSIFICERING'];
      Object.entries(state.counts || {}).forEach(([key, value]) => lines.push(`${key}: ${value}`));
      lines.push(`Registerlästa: ${state.registers.length}`, `Observerade trafikhändelser: ${state.observed}`, `Inventeringar: ${state.inventoryCount}`, `Inventering: ${text(state.inventoryStartedAt, 'Inte körd')} → ${text(state.inventoryFinishedAt, 'Inte körd')}`, '', 'C. TRAFIK UNDER SESSIONEN');
      state.events.forEach((item) => lines.push(JSON.stringify(item)));
      lines.push('', 'D. LÄSNINGSTIDER'); state.registers.forEach((item) => lines.push(`${item.name}: ${item.durationMs} ms, ${item.byteLength} byte, tillgänglig=${item.available}`));
      lines.push('', 'E. BEGRÄNSNINGAR'); (state.limitations.length ? state.limitations : ['Inga rapporterade begränsningar.']).forEach((item) => lines.push(item));
      return lines.join('\n');
    }
    return Object.freeze({ observe, inventory, firstRoleView, report, state: () => mask({ ...state, events: state.events.slice(), registers: state.registers.slice(), limitations: state.limitations.slice(), counts: { ...state.counts } }) });
  }
  window.StadslassSyncDiagnostic = Object.freeze({ PACKAGE_VERSION, create, classify });
})();
