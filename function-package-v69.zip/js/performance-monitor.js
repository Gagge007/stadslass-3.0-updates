(() => {
  'use strict';
  const PACKAGE_VERSION = 69;
  const MAX_EVENTS = 300;
  const now = () => new Date().toISOString();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value);
  const clean = (value, key = '') => {
    if (/token|authorization|password|secret|private|signature|credential/i.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => clean(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, clean(item, name)]));
    if (typeof value === 'string') return value.length > 500 ? `${value.slice(0, 500)}…` : value;
    return value;
  };
  function create(options = {}) {
    const state = { startedAt: '', stoppedAt: '', active: false, events: [], loopTimer: null, lastLoopAt: 0, observer: null };
    const context = typeof options.context === 'function' ? options.context : () => ({});
    function observe(kind, details = {}) {
      const item = clean({ at: now(), kind: text(kind), ...context(), ...details });
      state.events.push(item);
      if (state.events.length > MAX_EVENTS) state.events.shift();
      return item;
    }
    function start() {
      if (state.active) return;
      state.active = true; state.startedAt = now(); state.lastLoopAt = Date.now();
      observe('monitor-started', { order: 'first-package-action', packageVersion: PACKAGE_VERSION });
      if (typeof PerformanceObserver === 'function') {
        try {
          state.observer = new PerformanceObserver((list) => list.getEntries().forEach((entry) => observe('long-task', { durationMs: Math.round(entry.duration) })));
          state.observer.observe({ type: 'longtask', buffered: true });
        } catch (_) { state.observer = null; }
      }
      state.loopTimer = setInterval(() => {
        const current = Date.now(); const delay = current - state.lastLoopAt - 1000; state.lastLoopAt = current;
        if (delay >= 250) observe('event-loop-delay', { durationMs: delay });
      }, 1000);
    }
    function stop(reason = 'manual-stop') {
      if (!state.active) return;
      observe('monitor-stopped', { reason }); state.active = false; state.stoppedAt = now();
      if (state.loopTimer !== null) clearInterval(state.loopTimer); state.loopTimer = null;
      if (state.observer) state.observer.disconnect(); state.observer = null;
    }
    function report() {
      const lines = ['STADSLASS PRESTANDARAPPORT', `Start: ${state.startedAt || 'Inte startad'}`, `Slut: ${state.stoppedAt || now()}`, `Funktionspaket: ${PACKAGE_VERSION}`, `Händelser: ${state.events.length}`, '', 'HÄNDELSER'];
      state.events.forEach((item) => lines.push(JSON.stringify(item)));
      return lines.join('\n');
    }
    return Object.freeze({ start, stop, observe, report, state: () => clean({ ...state, loopTimer: undefined, observer: undefined, events: state.events.slice() }) });
  }
  window.StadslassPerformanceMonitor = Object.freeze({ PACKAGE_VERSION, create });
})();
