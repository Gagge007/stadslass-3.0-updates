(() => {
  'use strict';

  const PACKAGE_VERSION = 4;
  const MINIMUM_HOST_VERSION = 4;
  const SETTINGS_STORE = 'settings';
  const UI_SETTINGS_KEY = 'uiPreferencesV1';
  const PAGE_TITLES = Object.freeze({ home: 'Start', settings: 'Inställningar' });

  let hostInfo = null;
  let settingsDocument = {};
  let updatePollTimer = null;

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function parseObject(raw, fallback = {}) {
    try {
      const value = JSON.parse(raw);
      return value && typeof value === 'object' && !Array.isArray(value) ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function readSettingsDocument() {
    const raw = window.StadslassHost.readStore(SETTINGS_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Inställningslagret kunde inte läsas.');
    }
    return parseObject(raw, {});
  }

  function normalizedUiPreferences(documentValue) {
    const value = parseObject(JSON.stringify(documentValue[UI_SETTINGS_KEY] || {}), {});
    return {
      largeText: value.largeText === true,
      showTechnicalInfo: value.showTechnicalInfo === true
    };
  }

  function applyUiPreferences(preferences) {
    document.documentElement.classList.toggle('large-text', preferences.largeText);
    byId('large-text').checked = preferences.largeText;
    byId('show-technical').checked = preferences.showTechnicalInfo;
    byId('technical-panel').hidden = !preferences.showTechnicalInfo;
  }

  function showStatus(elementId, message, isError = false) {
    const element = byId(elementId);
    element.textContent = message;
    element.classList.toggle('is-error', isError);
  }

  function showView(target) {
    if (!Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) {
      return;
    }
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.hidden = view.dataset.view !== target;
    });
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      const active = button.dataset.target === target;
      button.classList.toggle('is-active', active);
      if (active) {
        button.setAttribute('aria-current', 'page');
      } else {
        button.removeAttribute('aria-current');
      }
    });
    byId('page-title').textContent = PAGE_TITLES[target];
    byId('main-content').focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function renderHostInfo() {
    const role = hostInfo.roleLabel || hostInfo.role || 'Okänd roll';
    byId('role-chip').textContent = role;
    byId('host-version').textContent = `${hostInfo.hostVersionName} (${hostInfo.hostVersionCode})`;
    byId('package-version').textContent = String(hostInfo.packageVersion);
    byId('technical-role').textContent = role;
    byId('device-id').textContent = hostInfo.deviceId || 'Saknas';
  }

  function renderPreservedTestValue() {
    const testValue = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    byId('module-test-value').textContent = String(testValue);
  }

  function saveSettings(event) {
    event.preventDefault();
    const nextPreferences = {
      largeText: byId('large-text').checked,
      showTechnicalInfo: byId('show-technical').checked
    };
    const nextDocument = {
      ...settingsDocument,
      [UI_SETTINGS_KEY]: nextPreferences,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('save-status', window.StadslassHost.getLastError() || 'Inställningarna kunde inte sparas.', true);
      return;
    }

    const verifiedDocument = readSettingsDocument();
    const verifiedPreferences = normalizedUiPreferences(verifiedDocument);
    if (verifiedPreferences.largeText !== nextPreferences.largeText
        || verifiedPreferences.showTechnicalInfo !== nextPreferences.showTechnicalInfo) {
      showStatus('save-status', 'Inställningarna kunde inte verifieras efter sparning.', true);
      return;
    }

    settingsDocument = verifiedDocument;
    applyUiPreferences(verifiedPreferences);
    renderPreservedTestValue();
    showStatus('save-status', 'Inställningarna är sparade och återlästa.');
  }

  function incrementTestValue() {
    const current = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    const nextDocument = {
      ...settingsDocument,
      moduleTestValue: current + 1,
      updatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('storage-status', window.StadslassHost.getLastError() || 'Testvärdet kunde inte sparas.', true);
      return;
    }
    settingsDocument = readSettingsDocument();
    renderPreservedTestValue();
    showStatus('storage-status', 'Testvärdet sparades utan att övriga inställningsfält ändrades.');
  }

  function refreshUpdateStatus() {
    byId('update-status').textContent = window.StadslassHost.getUpdateStatus();
  }

  function requestUpdate() {
    window.StadslassHost.requestUpdateCheck();
    refreshUpdateStatus();
    if (updatePollTimer !== null) {
      window.clearInterval(updatePollTimer);
    }
    updatePollTimer = window.setInterval(refreshUpdateStatus, 1000);
    window.setTimeout(() => {
      if (updatePollTimer !== null) {
        window.clearInterval(updatePollTimer);
        updatePollTimer = null;
      }
      refreshUpdateStatus();
    }, 20000);
  }

  function bindEvents() {
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      button.addEventListener('click', () => showView(button.dataset.target));
    });
    byId('open-settings').addEventListener('click', () => showView('settings'));
    byId('settings-form').addEventListener('submit', saveSettings);
    byId('increment-test').addEventListener('click', incrementTestValue);
    byId('check-update').addEventListener('click', requestUpdate);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());
  }

  function start() {
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    const cssMarker = getComputedStyle(document.documentElement)
      .getPropertyValue('--module-style-ready').trim();
    if (cssMarker !== '1') {
      throw new Error('CSS-filen kunde inte verifieras.');
    }

    hostInfo = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!hostInfo
        || hostInfo.hostVersionCode < MINIMUM_HOST_VERSION
        || hostInfo.packageVersion !== PACKAGE_VERSION
        || hostInfo.storageApiVersion !== 1) {
      throw new Error('Värd-, paket- eller lagringsversionen stämmer inte.');
    }

    settingsDocument = readSettingsDocument();
    applyUiPreferences(normalizedUiPreferences(settingsDocument));
    renderHostInfo();
    renderPreservedTestValue();
    refreshUpdateStatus();
    showStatus('storage-status', 'Inställningslagret är läst. Kö, aktivt jobb, historik och synkutkö är orörda.');
    bindEvents();
    showView('home');

    window.StadslassHost.markReady(PACKAGE_VERSION);
  }

  document.addEventListener('DOMContentLoaded', () => {
    try {
      start();
    } catch (error) {
      document.body.innerHTML = '<main class="content"><article class="notice-card"><h1>Stadslass kunde inte starta</h1><p id="fatal-error"></p></article></main>';
      byId('fatal-error').textContent = error instanceof Error ? error.message : String(error);
    }
  });
})();
