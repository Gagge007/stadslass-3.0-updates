'use strict';
const assert = require('assert');
const { TextEncoder } = require('util');
global.TextEncoder = TextEncoder;
global.performance = { now: () => Date.now() };
global.window = {};
const calls = [];
const hostReads = [];
const stores = {
  syncOutbox: JSON.stringify([
    { id: 'active', kind: 'sync-v63-request', requestId: 'a', intent: 'get-active', state: 'pending', createdAt: '2026-08-03T03:40:00.000Z', updatedAt: '2026-08-03T03:41:00.000Z', request: { operation: 'GET', path: 'x', coalesceKey: 'get-active/189' } },
    { id: 'journal', kind: 'sync-v69-terminal-journal', items: [{ requestId: 'old', state: 'succeeded' }] },
    { id: 'work', kind: 'sync-v63-command', state: 'waiting_result', token: 'must-not-leak' }
  ]),
  settings: JSON.stringify({ syncV63: { enabled: true, token: 'must-not-leak' } })
};
require('../js/sync-diagnostic.js');
const diagnostic = window.StadslassSyncDiagnostic.create({
  readStore: (name) => { calls.push(name); return stores[name]; },
  getRequestStatus: (requestId) => { hostReads.push(requestId); return { ok: true, status: 'running', httpStatus: 0, errorCode: '' }; }
});
diagnostic.firstRoleView({ hostVersion: '3.0-host-16', role: 'mobile', syncConfiguration: { token: 'must-not-leak' } });
assert.strictEqual(calls.length, 0, 'first role view must not start an inventory');
const first = diagnostic.snapshotReport({ reportId: 'sync-v70-first' });
assert.deepStrictEqual(calls, ['syncOutbox', 'settings']);
assert.strictEqual(hostReads.length, 1, 'active host status must be read once');
assert.strictEqual(first.exportSequence, 1);
assert.strictEqual(first.counts.activeRequests, 1);
assert(first.content.includes('C. AKTIVA SYNKREQUESTS'));
assert(first.content.includes('"hostStatus"'));
assert(first.content.includes('"ageSeconds"'));
assert(!first.content.includes('must-not-leak'));
diagnostic.observe('new-traffic-after-first-export', { value: 1 });
const second = diagnostic.snapshotReport({ reportId: 'sync-v70-second' });
assert.deepStrictEqual(calls, ['syncOutbox', 'settings', 'syncOutbox', 'settings'], 'every export must perform a fresh inventory');
assert.strictEqual(second.exportSequence, 2);
assert(second.eventCount > first.eventCount, 'second export must include new traffic');
assert(second.content.includes('new-traffic-after-first-export'));
assert.notStrictEqual(first.reportId, second.reportId);
assert(!second.content.includes('FULLSTÄNDIG POSTLISTA'));
assert.strictEqual(stores.syncOutbox.includes('pending'), true, 'read-only export must not mutate source data');
console.log('PASS sync-diagnostic.test.js');
