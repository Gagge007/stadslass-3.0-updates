(() => {
  'use strict';
  const PACKAGE_VERSION = 70;
  const MAX_EVENTS = 400;
  const STALE_ACTIVE_SECONDS = 120;
  const ACTIVE_STATES = new Set(['pending', 'running', 'accepted', 'failed_retryable', 'retryable']);
  const TERMINAL_STATES = new Set(['succeeded', 'failed_permanent', 'conflict', 'superseded']);
  const SECRET = /token|authorization|password|secret|private|signature|credential/i;
  const now = () => new Date().toISOString();
  const mono = () => typeof performance === 'object' && typeof performance.now === 'function' ? performance.now() : Date.now();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value);
  const bytes = (value) => new TextEncoder().encode(typeof value === 'string' ? value : JSON.stringify(value || null)).length;
  const parse = (value, fallback = null) => { try { return JSON.parse(value); } catch (_) { return fallback; } };
  const isoMs = (value) => { const parsed = Date.parse(text(value)); return Number.isFinite(parsed) ? parsed : null; };
  const secondsBetween = (older, newer = Date.now()) => { const value = isoMs(older); return value === null ? null : Math.max(0, Math.floor((newer - value) / 1000)); };
  const mask = (value, key = '') => {
    if (SECRET.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.map((item) => mask(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, mask(item, name)]));
    if (typeof value === 'string') return value.length > 600 ? `${value.slice(0, 600)}…` : value;
    return value;
  };
  function requestDetails(entries, environment, generatedAtMs = Date.now()) {
    const list = Array.isArray(entries) ? entries : [];
    return list.filter((entry) => entry && entry.kind === 'sync-v63-request' && ACTIVE_STATES.has(text(entry.state))).map((entry) => {
      let hostStatus = null;
      if (typeof environment.getRequestStatus === 'function') {
        try { hostStatus = environment.getRequestStatus(text(entry.requestId)); }
        catch (error) { hostStatus = { status: 'host_status_read_failed', errorCode: text(error && error.message, 'host_status_read_failed') }; }
      }
      const request = entry.request && typeof entry.request === 'object' ? entry.request : {};
      return mask({
        requestId: text(entry.requestId),
        intent: text(entry.intent),
        operation: text(request.operation),
        path: text(request.path),
        coalesceKey: text(request.coalesceKey),
        localState: text(entry.state),
        createdAt: text(entry.createdAt),
        updatedAt: text(entry.updatedAt),
        ageSeconds: secondsBetween(entry.createdAt, generatedAtMs),
        idleSeconds: secondsBetween(entry.updatedAt || entry.createdAt, generatedAtMs),
        hostStatus: hostStatus && typeof hostStatus === 'object' ? {
          status: text(hostStatus.status),
          httpStatus: Number(hostStatus.httpStatus) || 0,
          errorCode: text(hostStatus.errorCode),
          completedAt: text(hostStatus.completedAt),
          ok: hostStatus.ok === true
        } : null
      });
    });
  }
  function classify(entries, activeDetails = []) {
    const list = Array.isArray(entries) ? entries : [];
    const requests = list.filter((entry) => entry && entry.kind === 'sync-v63-request');
    const journal = list.find((entry) => entry && entry.kind === 'sync-v69-terminal-journal');
    const ages = activeDetails.map((entry) => Number(entry.ageSeconds)).filter(Number.isFinite);
    return {
      totalTopLevel: list.length,
      activeRequests: activeDetails.length || requests.filter((entry) => ACTIVE_STATES.has(text(entry.state))).length,
      staleActiveRequests: activeDetails.filter((entry) => Number(entry.ageSeconds) >= STALE_ACTIVE_SECONDS).length,
      oldestActiveAgeSeconds: ages.length ? Math.max(...ages) : 0,
      terminalRequestsStillInActiveStore: requests.filter((entry) => TERMINAL_STATES.has(text(entry.state))).length,
      retryableRequests: requests.filter((entry) => ['failed_retryable', 'retryable'].includes(text(entry.state))).length,
      journalItems: journal && Array.isArray(journal.items) ? journal.items.length : 0,
      preparedTransfers: list.filter((entry) => entry && ['queue-transfer', 'queue-receipt'].includes(text(entry.kind)) && text(entry.state) === 'prepared').length,
      waitingCommands: list.filter((entry) => entry && entry.kind === 'sync-v63-command' && ['waiting_ledger', 'waiting_send', 'waiting_result', 'failed_retryable', 'sync_conflict'].includes(text(entry.state))).length,
      resourceStates: list.filter((entry) => entry && entry.kind === 'sync-v69-resource-state').length,
      putRetryControls: list.filter((entry) => entry && entry.kind === 'sync-v69-put-retry').length
    };
  }
  function create(environment) {
    const state = { startedAt: now(), firstRoleViewAt: '', inventoryStartedAt: '', inventoryFinishedAt: '', inventoryRunning: false, inventoryCount: 0, exportSequence: 0, entryCount: 0, context: {}, events: [], registers: [], limitations: [], observed: 0, counts: {}, activeRequestDetails: [] };
    const event = (kind, details = {}) => {
      const value = mask({ at: now(), kind, ...details }); state.events.push(value); state.observed += 1;
      if (state.events.length > MAX_EVENTS) state.events.shift(); return value;
    };
    function read(name) {
      const started = mono();
      try {
        const raw = environment.readStore(name); const value = parse(raw, null);
        state.registers = state.registers.filter((item) => item.name !== name);
        state.registers.push({ name, byteLength: bytes(raw || ''), durationMs: Math.round(mono() - started), available: true });
        return value;
      } catch (error) {
        state.limitations.push(`${name}: ${text(error && error.message, 'kunde inte läsas')}`);
        state.registers = state.registers.filter((item) => item.name !== name);
        state.registers.push({ name, byteLength: 0, durationMs: Math.round(mono() - started), available: false });
        return null;
      }
    }
    function inventory(options = {}) {
      if (state.inventoryRunning) return { ok: false, status: 'already_running' };
      state.inventoryRunning = true; state.inventoryStartedAt = now(); state.inventoryCount += 1; const started = mono();
      try {
        const outbox = read('syncOutbox'); read('settings');
        state.activeRequestDetails = requestDetails(outbox, environment, Date.now());
        state.counts = classify(outbox, state.activeRequestDetails); state.entryCount = state.counts.totalTopLevel || 0;
        event('inventory-complete', { reason: text(options.reason, 'manual'), reportId: text(options.reportId), ...state.counts, durationMs: Math.round(mono() - started) });
        return { ok: true, status: 'completed', counts: { ...state.counts }, activeRequestDetails: state.activeRequestDetails.slice() };
      } finally { state.inventoryFinishedAt = now(); state.inventoryRunning = false; }
    }
    function firstRoleView(context = {}) { state.context = mask({ ...state.context, ...context }); state.firstRoleViewAt = now(); event('role-view-ready', { role: text(context.role), order: 'no-automatic-full-inventory' }); }
    function observe(kind, details = {}) { return event(kind, details); }
    function snapshotReport(options = {}) {
      const reportId = text(options.reportId, `sync-v70-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`);
      state.exportSequence += 1;
      const inventoryResult = inventory({ reason: 'export', reportId });
      const generatedAt = now();
      const lines = ['STADSLASS SYNKVERIFIERINGSRAPPORT', 'Rapporttyp: Tillfällig aktuell rapportexport och verifiering av aktiva synkrequests', `Rapport-ID: ${reportId}`, `Genererad: ${generatedAt}`, `Exportsekvens: ${state.exportSequence}`, '', 'A. IDENTITET', `Start: ${state.startedAt}`, `Slut: ${generatedAt}`, `Värdapp: ${text(state.context.hostVersion, 'Saknas')}`, `Funktionspaket: ${PACKAGE_VERSION}`, `Roll: ${text(state.context.role, 'Saknas')}`, `Installations-ID: ${text(state.context.installationId, 'Saknas')}`, `Enhets-ID: ${text(state.context.deviceId, 'Saknas')}`, `Synkkonfiguration: ${JSON.stringify(mask(state.context.syncConfiguration || {}))}`, '', 'B. KÖKLASSIFICERING'];
      Object.entries(state.counts || {}).forEach(([key, value]) => lines.push(`${key}: ${value}`));
      lines.push(`Registerlästa: ${state.registers.length}`, `Observerade trafikhändelser: ${state.observed}`, `Inventeringar: ${state.inventoryCount}`, `Exportinventering: ${text(state.inventoryStartedAt, 'Inte körd')} → ${text(state.inventoryFinishedAt, 'Inte körd')}`, `Exportinventering status: ${text(inventoryResult.status)}`, '', 'C. AKTIVA SYNKREQUESTS');
      if (!state.activeRequestDetails.length) lines.push('Inga aktiva synkrequests.');
      state.activeRequestDetails.forEach((item) => lines.push(JSON.stringify(item)));
      lines.push('', 'D. TRAFIK UNDER SESSIONEN');
      state.events.forEach((item) => lines.push(JSON.stringify(item)));
      lines.push('', 'E. LÄSNINGSTIDER'); state.registers.forEach((item) => lines.push(`${item.name}: ${item.durationMs} ms, ${item.byteLength} byte, tillgänglig=${item.available}`));
      lines.push('', 'F. BEGRÄNSNINGAR'); (state.limitations.length ? state.limitations : ['Inga rapporterade begränsningar.']).forEach((item) => lines.push(item));
      return { content: lines.join('\n'), reportId, generatedAt, exportSequence: state.exportSequence, eventCount: state.observed, counts: { ...state.counts } };
    }
    function report(options = {}) { return snapshotReport(options).content; }
    return Object.freeze({ observe, inventory, firstRoleView, report, snapshotReport, state: () => mask({ ...state, events: state.events.slice(), registers: state.registers.slice(), limitations: state.limitations.slice(), counts: { ...state.counts }, activeRequestDetails: state.activeRequestDetails.slice() }) });
  }
  window.StadslassSyncDiagnostic = Object.freeze({ PACKAGE_VERSION, STALE_ACTIVE_SECONDS, create, classify, requestDetails });
})();
