(() => {
  'use strict';

  const SETTINGS_KEY = 'editablePlaceRegistryV1';
  const SCHEMA_VERSION = 2;
  const MANUAL_ID_PATTERN = /^PL3-[0-9a-f]{32}$/;
  const JOB_TYPE_ID_PATTERN = /^JT3-[0-9a-f]{32}$/;
  const GEOFENCE_TYPE = 'circle';
  const google = window.StadslassGoogleService || null;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedText(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    if (typeof value === 'string' && !value.trim()) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : Number.NaN;
  }

  function uniqueIds(value) {
    if (!Array.isArray(value)) return [];
    return Array.from(new Set(value.map(text).filter(Boolean))).sort();
  }

  function requireGoogleModule() {
    if (!google || typeof google.normalizeGeocoding !== 'function' || typeof google.pendingGeocoding !== 'function') {
      throw new Error('Den gemensamma Google-tjänsten saknas för platsregistret.');
    }
  }

  function emptyRegistry() {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      items: []
    };
  }

  function randomBytes() {
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(bytes);
      return bytes;
    }
    const seed = `${Date.now()}-${Math.random()}-${Math.random()}`;
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = seed.charCodeAt(index % seed.length) ^ Math.floor(Math.random() * 256);
    }
    return bytes;
  }

  function generateStableId(items = []) {
    const existing = new Set(items.map((item) => text(item && item.id)));
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const hex = Array.from(randomBytes(), (value) => value.toString(16).padStart(2, '0')).join('');
      const id = `PL3-${hex}`;
      if (!existing.has(id)) return id;
    }
    throw new Error('Ett unikt plats-ID kunde inte skapas.');
  }

  function validateJobTypeIds(ids, label, validJobTypeIds) {
    if (!Array.isArray(ids)) throw new Error(`${label} saknar en giltig lista.`);
    if (ids.length !== new Set(ids).size) throw new Error(`${label} innehåller dubbla jobbtyper.`);
    ids.forEach((id) => {
      if (!JOB_TYPE_ID_PATTERN.test(text(id))) throw new Error(`${label} innehåller ett ogiltigt jobbtyps-ID.`);
      if (validJobTypeIds && !validJobTypeIds.has(id)) throw new Error(`${label} hänvisar till en jobbtyp som inte finns.`);
    });
  }

  function normalizedGeofence(value, geocoding) {
    const source = isPlainObject(value) ? value : {};
    const resolved = google.normalizeGeocoding(geocoding);
    return {
      enabled: Boolean(source.enabled),
      type: GEOFENCE_TYPE,
      visualLoadingLock: Boolean(source.visualLoadingLock),
      visualUnloadingLock: Boolean(source.visualUnloadingLock),
      latitude: resolved.latitude,
      longitude: resolved.longitude,
      radiusMeters: optionalNumber(source.radiusMeters),
      toleranceMeters: optionalNumber(source.toleranceMeters)
    };
  }

  function validateGeofence(geofence) {
    if (!isPlainObject(geofence)) throw new Error('Platsens geofence har fel format.');
    if (typeof geofence.enabled !== 'boolean') throw new Error('Platsens geofence saknar giltig av/på-status.');
    if (text(geofence.type) !== GEOFENCE_TYPE) throw new Error('Platsens geofence måste vara en cirkel.');
    if (typeof geofence.visualLoadingLock !== 'boolean') throw new Error('Platsens visuella lastningslås är ogiltigt.');
    if (typeof geofence.visualUnloadingLock !== 'boolean') throw new Error('Platsens visuella lossningslås är ogiltigt.');

    const latitude = optionalNumber(geofence.latitude);
    const longitude = optionalNumber(geofence.longitude);
    const radiusMeters = optionalNumber(geofence.radiusMeters);
    const toleranceMeters = optionalNumber(geofence.toleranceMeters);

    if (Number.isNaN(latitude) || (latitude !== null && (latitude < -90 || latitude > 90))) {
      throw new Error('Geofencets dolda latitud måste vara mellan -90 och 90.');
    }
    if (Number.isNaN(longitude) || (longitude !== null && (longitude < -180 || longitude > 180))) {
      throw new Error('Geofencets dolda longitud måste vara mellan -180 och 180.');
    }
    if ((latitude === null) !== (longitude === null)) throw new Error('Geofencets dolda koordinater måste finnas som ett par.');
    if (Number.isNaN(radiusMeters) || (radiusMeters !== null && (radiusMeters <= 0 || radiusMeters > 100000))) {
      throw new Error('Geofencets radie måste vara större än 0 och högst 100000 meter.');
    }
    if (Number.isNaN(toleranceMeters) || (toleranceMeters !== null && (toleranceMeters < 0 || toleranceMeters > 100000))) {
      throw new Error('Geofencets tolerans måste vara 0 meter eller större och högst 100000 meter.');
    }
    if (geofence.enabled && (radiusMeters === null || toleranceMeters === null)) {
      throw new Error('Geofencets radie och tolerans måste fyllas i när Geofence är markerat.');
    }
    return true;
  }

  function normalizeItem(source, timestamp = new Date().toISOString()) {
    requireGoogleModule();
    const value = isPlainObject(source) ? source : {};
    const addressOrPlusCode = text(value.addressOrPlusCode);
    const legacyGeocoding = {
      latitude: value.geofence && value.geofence.latitude,
      longitude: value.geofence && value.geofence.longitude,
      query: addressOrPlusCode,
      timestamp: text(value.updatedAt) || timestamp,
      source: 'legacy-existing'
    };
    const geocoding = isPlainObject(value.geocoding) && text(value.geocoding.status)
      ? google.normalizeGeocoding(value.geocoding)
      : google.normalizeGeocoding(null, legacyGeocoding);
    return {
      ...value,
      id: text(value.id),
      name: normalizedText(value.name),
      addressOrPlusCode,
      placeRequirements: text(value.placeRequirements),
      openingHours: text(value.openingHours),
      canBeReturnPlace: Boolean(value.canBeReturnPlace),
      jobTypeFromIds: uniqueIds(value.jobTypeFromIds),
      jobTypeToIds: uniqueIds(value.jobTypeToIds),
      geocoding,
      geofence: normalizedGeofence(value.geofence, geocoding),
      createdAt: text(value.createdAt) || timestamp,
      updatedAt: text(value.updatedAt) || timestamp
    };
  }

  function validateItem(item, validJobTypeIds = null) {
    requireGoogleModule();
    if (!isPlainObject(item)) throw new Error('En plats har fel format.');
    if (!MANUAL_ID_PATTERN.test(text(item.id))) throw new Error('En plats saknar ett giltigt stabilt ID.');
    if (!normalizedText(item.name)) throw new Error('Platsens namn saknas.');
    if (normalizedText(item.name).length > 100) throw new Error('Platsens namn får vara högst 100 tecken.');
    if (text(item.addressOrPlusCode).length > 300) throw new Error('Adress eller Plus Code får vara högst 300 tecken.');
    if (text(item.placeRequirements).length > 1000) throw new Error('Platskrav får vara högst 1000 tecken.');
    if (text(item.openingHours).length > 300) throw new Error('Öppettider får vara högst 300 tecken.');
    if (typeof item.canBeReturnPlace !== 'boolean') throw new Error('Platsens returplatsval är ogiltigt.');
    validateJobTypeIds(item.jobTypeFromIds, 'Jobbtyper från', validJobTypeIds);
    validateJobTypeIds(item.jobTypeToIds, 'Jobbtyper till', validJobTypeIds);
    const geocoding = google.validateGeocoding(item.geocoding);
    validateGeofence(item.geofence);
    if (geocoding.latitude !== item.geofence.latitude || geocoding.longitude !== item.geofence.longitude) {
      throw new Error('Platsens geokodning och geofence använder inte samma dolda koordinater.');
    }
    if (!text(item.createdAt) || !text(item.updatedAt)) throw new Error('Platsens tidsstämplar saknas.');
    return true;
  }

  function validateItems(items, validJobTypeIds = null) {
    if (!Array.isArray(items)) throw new Error('Platsregistret saknar en giltig lista.');
    const ids = new Set();
    const names = new Set();
    items.forEach((item) => {
      validateItem(item, validJobTypeIds);
      const id = text(item.id);
      const nameKey = normalizedText(item.name).toLocaleLowerCase('sv-SE');
      if (ids.has(id)) throw new Error('Platsregistret innehåller dubbla ID:n.');
      if (names.has(nameKey)) throw new Error('Det finns redan en plats med samma namn.');
      ids.add(id);
      names.add(nameKey);
    });
    return true;
  }

  function validateRegistry(registry, validJobTypeIds = null) {
    if (!isPlainObject(registry)) throw new Error('Platsregistret har fel format.');
    if (registry.schemaVersion !== SCHEMA_VERSION) throw new Error('Platsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Platsregistret har en ogiltig revision.');
    validateItems(registry.items, validJobTypeIds);
    return true;
  }

  function normalizedInput(input, current = null, timestamp = new Date().toISOString()) {
    requireGoogleModule();
    const value = isPlainObject(input) ? input : {};
    const addressOrPlusCode = text(value.addressOrPlusCode);
    const currentGeocoding = current && current.geocoding ? current.geocoding : null;
    const geocoding = google.pendingGeocoding(currentGeocoding, addressOrPlusCode, timestamp);
    return {
      name: normalizedText(value.name),
      addressOrPlusCode,
      placeRequirements: text(value.placeRequirements),
      openingHours: text(value.openingHours),
      canBeReturnPlace: Boolean(value.canBeReturnPlace),
      jobTypeFromIds: uniqueIds(value.jobTypeFromIds),
      jobTypeToIds: uniqueIds(value.jobTypeToIds),
      geocoding,
      geofence: normalizedGeofence(value.geofence, geocoding)
    };
  }

  function createItem(input, existingItems = [], validJobTypeIds = null, timestamp = new Date().toISOString()) {
    const normalized = normalizedInput(input, null, timestamp);
    const item = normalizeItem({
      id: generateStableId(existingItems),
      ...normalized,
      createdAt: timestamp,
      updatedAt: timestamp
    }, timestamp);
    validateItems(existingItems.concat(item), validJobTypeIds);
    return item;
  }

  function updateItem(current, input, existingItems = [], validJobTypeIds = null, timestamp = new Date().toISOString()) {
    validateItem(current, validJobTypeIds);
    const normalized = normalizedInput(input, current, timestamp);
    const updated = normalizeItem({
      ...current,
      ...normalized,
      geofence: {
        ...(isPlainObject(current.geofence) ? current.geofence : {}),
        ...normalized.geofence
      },
      updatedAt: timestamp
    }, timestamp);
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Platsen som skulle redigeras saknas.');
    validateItems(nextItems, validJobTypeIds);
    return updated;
  }

  function applyGeocoding(current, geocodingValue, existingItems = [], validJobTypeIds = null, timestamp = new Date().toISOString()) {
    validateItem(current, validJobTypeIds);
    const geocoding = google.validateGeocoding(geocodingValue);
    const updated = normalizeItem({
      ...current,
      geocoding,
      geofence: {
        ...current.geofence,
        latitude: geocoding.latitude,
        longitude: geocoding.longitude
      },
      updatedAt: timestamp
    }, timestamp);
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Platsen som skulle geokodas saknas.');
    validateItems(nextItems, validJobTypeIds);
    return updated;
  }

  function removeItem(current, existingItems = [], validJobTypeIds = null) {
    validateItem(current, validJobTypeIds);
    if (!existingItems.some((item) => item.id === current.id)) throw new Error('Platsen som skulle tas bort saknas.');
    const nextItems = existingItems.filter((item) => item.id !== current.id);
    validateItems(nextItems, validJobTypeIds);
    return nextItems;
  }

  function withItems(registry, items, validJobTypeIds = null, timestamp = new Date().toISOString()) {
    validateRegistry(registry, validJobTypeIds);
    const normalizedItems = items.map((item) => normalizeItem(item, timestamp));
    validateItems(normalizedItems, validJobTypeIds);
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      items: normalizedItems
    };
    validateRegistry(next, validJobTypeIds);
    return next;
  }

  function migrateRegistry(stored, validJobTypeIds = null, timestamp = new Date().toISOString()) {
    if (typeof stored === 'undefined') {
      return { registry: emptyRegistry(), migrated: false, sourceExisted: false, sourceSchemaVersion: 0 };
    }
    if (!isPlainObject(stored) || !Array.isArray(stored.items)) throw new Error('Det äldre platsregistret har fel format.');
    const sourceSchemaVersion = Number(stored.schemaVersion);
    if (![1, SCHEMA_VERSION].includes(sourceSchemaVersion)) throw new Error('Det äldre platsregistret har en okänd schemaversion.');
    if (!Number.isInteger(stored.revision) || stored.revision < 0) throw new Error('Det äldre platsregistret har en ogiltig revision.');
    const items = stored.items.map((item) => normalizeItem(item, timestamp));
    const changed = sourceSchemaVersion !== SCHEMA_VERSION || JSON.stringify(items) !== JSON.stringify(stored.items);
    const registry = {
      ...stored,
      schemaVersion: SCHEMA_VERSION,
      revision: changed ? stored.revision + 1 : stored.revision,
      ...(changed ? { updatedAt: timestamp } : {}),
      items
    };
    validateRegistry(registry, validJobTypeIds);
    return { registry, migrated: changed, sourceExisted: true, sourceSchemaVersion };
  }

  function referencesJobType(registry, jobTypeId) {
    if (!isPlainObject(registry) || !Array.isArray(registry.items)) return false;
    return registry.items.some((item) => (Array.isArray(item.jobTypeFromIds) && item.jobTypeFromIds.includes(jobTypeId))
      || (Array.isArray(item.jobTypeToIds) && item.jobTypeToIds.includes(jobTypeId)));
  }

  window.StadslassPlaceRegistry = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    GEOFENCE_TYPE,
    emptyRegistry,
    validateItem,
    validateRegistry,
    createItem,
    updateItem,
    applyGeocoding,
    removeItem,
    withItems,
    migrateRegistry,
    referencesJobType
  });
})();
