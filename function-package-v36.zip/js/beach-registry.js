(() => {
  'use strict';

  const SETTINGS_KEY = 'editableBeachRegistryV1';
  const SCHEMA_VERSION = 3;
  const MANUAL_ID_PATTERN = /^BP3-[0-9a-f]{32}$/;
  const FIXED_ID_PATTERN = /^PL-[0-9]{4}$/;
  const REQUIRED_ROLES = Object.freeze(['from', 'destination', 'return', 'beach']);
  const REQUIRED_JOB_TYPE_IDS = Object.freeze(['JT-1010']);
  const google = window.StadslassGoogleService || null;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedText(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function normalizedNameKey(value) {
    return normalizedText(value).toLocaleLowerCase('sv-SE');
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    if (typeof value === 'string' && !value.trim()) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : Number.NaN;
  }

  function uniqueTextItems(value) {
    if (!Array.isArray(value)) return [];
    return Array.from(new Set(value.map(text).filter(Boolean)));
  }

  function requireGoogleModule() {
    if (!google || typeof google.normalizeGeocoding !== 'function' || typeof google.pendingGeocoding !== 'function') {
      throw new Error('Den gemensamma Google-tjänsten saknas för badplatsregistret.');
    }
  }

  function emptyRegistry() {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      items: []
    };
  }

  function randomBytes() {
    const bytes = new Uint8Array(16);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(bytes);
      return bytes;
    }
    const seed = `${Date.now()}-${Math.random()}-${Math.random()}`;
    for (let index = 0; index < bytes.length; index += 1) {
      bytes[index] = seed.charCodeAt(index % seed.length) ^ Math.floor(Math.random() * 256);
    }
    return bytes;
  }

  function generateStableId(items = []) {
    const existing = new Set(items.map((item) => text(item && item.id)));
    for (let attempt = 0; attempt < 20; attempt += 1) {
      const hex = Array.from(randomBytes(), (value) => value.toString(16).padStart(2, '0')).join('');
      const id = `BP3-${hex}`;
      if (!existing.has(id)) return id;
    }
    throw new Error('Ett unikt badplats-ID kunde inte skapas.');
  }

  function systemFields(source = {}) {
    return {
      category: 'badplats',
      roles: REQUIRED_ROLES.slice(),
      allowedJobTypeIds: REQUIRED_JOB_TYPE_IDS.slice(),
      aliases: uniqueTextItems(source.aliases),
      sourceNote: text(source.sourceNote)
    };
  }

  function normalizedEditableFields(input = {}, current = null, timestamp = new Date().toISOString()) {
    requireGoogleModule();
    const addressOrPlusCode = text(input.addressOrPlusCode);
    const legacy = {
      latitude: input.latitude,
      longitude: input.longitude,
      query: addressOrPlusCode,
      timestamp: text(input.updatedAt) || timestamp,
      source: 'legacy-existing'
    };
    const baseGeocoding = isPlainObject(input.geocoding) && text(input.geocoding.status)
      ? google.normalizeGeocoding(input.geocoding)
      : google.normalizeGeocoding(null, legacy);
    const geocoding = current
      ? google.pendingGeocoding(current.geocoding, addressOrPlusCode, timestamp)
      : baseGeocoding;
    return {
      name: normalizedText(input.name),
      addressOrPlusCode,
      radiusMeters: optionalNumber(input.radiusMeters),
      toleranceMeters: optionalNumber(input.toleranceMeters),
      geocoding,
      latitude: geocoding.latitude,
      longitude: geocoding.longitude,
      coordinatesPending: !google.validCoordinates(geocoding.latitude, geocoding.longitude),
      active: input.active !== false,
      hidden: input.hidden === true,
      mergedIntoId: text(input.mergedIntoId)
    };
  }

  function normalizeItem(source, timestamp = new Date().toISOString()) {
    const value = isPlainObject(source) ? source : {};
    const editable = normalizedEditableFields(value, null, timestamp);
    const hidden = editable.hidden === true;
    return {
      ...value,
      id: text(value.id),
      ...editable,
      active: hidden ? false : editable.active,
      ...systemFields(value),
      createdAt: text(value.createdAt) || timestamp,
      updatedAt: text(value.updatedAt) || timestamp
    };
  }

  function validateItem(item) {
    requireGoogleModule();
    if (!isPlainObject(item)) throw new Error('En badplats har fel format.');
    const id = text(item.id);
    if (!MANUAL_ID_PATTERN.test(id) && !FIXED_ID_PATTERN.test(id)) throw new Error('En badplats saknar ett giltigt stabilt ID.');
    if (!normalizedText(item.name)) throw new Error('Badplatsens namn saknas.');
    if (normalizedText(item.name).length > 100) throw new Error('Badplatsens namn får vara högst 100 tecken.');
    if (text(item.addressOrPlusCode).length > 300) throw new Error('Adress / Plus Code får vara högst 300 tecken.');

    const radius = optionalNumber(item.radiusMeters);
    if (Number.isNaN(radius) || (radius !== null && (radius <= 0 || radius > 100000))) {
      throw new Error('Geofence-radie måste vara större än 0 och högst 100000 meter.');
    }
    const tolerance = optionalNumber(item.toleranceMeters);
    if (Number.isNaN(tolerance) || (tolerance !== null && (tolerance < 0 || tolerance > 100000))) {
      throw new Error('Tolerans måste vara minst 0 och högst 100000 meter.');
    }
    const geocoding = google.validateGeocoding(item.geocoding);
    const latitude = optionalNumber(item.latitude);
    const longitude = optionalNumber(item.longitude);
    if (Number.isNaN(latitude) || Number.isNaN(longitude)) throw new Error('Badplatsens dolda koordinater är ogiltiga.');
    if (latitude !== geocoding.latitude || longitude !== geocoding.longitude) throw new Error('Badplatsens koordinater avviker från den gemensamma geokodningsposten.');
    if (typeof item.coordinatesPending !== 'boolean') throw new Error('Badplatsens koordinatstatus saknas.');
    if (item.coordinatesPending === google.validCoordinates(latitude, longitude)) throw new Error('Badplatsens koordinatstatus är inkonsekvent.');
    if (typeof item.active !== 'boolean' || typeof item.hidden !== 'boolean') throw new Error('Badplatsens aktiva status är ogiltig.');
    if (item.hidden === true && item.active !== false) throw new Error('En dold sammanslagen badplats får inte vara aktiv.');
    if (item.hidden === true && !text(item.mergedIntoId)) throw new Error('En dold sammanslagen badplats saknar mål-ID.');
    if (text(item.category) !== 'badplats') throw new Error('Badplatsens systemkategori är ogiltig.');
    const roles = uniqueTextItems(item.roles);
    if (!REQUIRED_ROLES.every((role) => roles.includes(role))) throw new Error('Badplatsens skyddade systemroller saknas.');
    const jobTypeIds = uniqueTextItems(item.allowedJobTypeIds);
    if (!REQUIRED_JOB_TYPE_IDS.every((idValue) => jobTypeIds.includes(idValue))) throw new Error('Badplatsens Havstångskoppling saknas.');
    if (!text(item.createdAt) || !text(item.updatedAt)) throw new Error('Badplatsens tidsstämplar saknas.');
    return true;
  }

  function validateItems(items) {
    if (!Array.isArray(items)) throw new Error('Badplatsregistret saknar en giltig lista.');
    const ids = new Set();
    const visibleNames = new Set();
    items.forEach((item) => {
      validateItem(item);
      const id = text(item.id);
      const nameKey = normalizedNameKey(item.name);
      if (ids.has(id)) throw new Error('Badplatsregistret innehåller dubbla ID:n.');
      if (item.hidden !== true) {
        if (visibleNames.has(nameKey)) throw new Error('Det finns redan en synlig badplats med samma namn.');
        visibleNames.add(nameKey);
      }
      ids.add(id);
    });
    return true;
  }

  function validateRegistry(registry) {
    if (!isPlainObject(registry)) throw new Error('Badplatsregistret har fel format.');
    if (registry.schemaVersion !== SCHEMA_VERSION) throw new Error('Badplatsregistret har en okänd schemaversion.');
    if (!Number.isInteger(registry.revision) || registry.revision < 0) throw new Error('Badplatsregistret har en ogiltig revision.');
    validateItems(registry.items);
    return true;
  }

  function createItem(input, existingItems = [], timestamp = new Date().toISOString()) {
    const editable = normalizedEditableFields(input, null, timestamp);
    const pending = google.pendingGeocoding(editable.geocoding, editable.addressOrPlusCode, timestamp);
    const item = normalizeItem({
      id: generateStableId(existingItems),
      ...input,
      ...editable,
      geocoding: pending,
      latitude: pending.latitude,
      longitude: pending.longitude,
      coordinatesPending: !google.validCoordinates(pending.latitude, pending.longitude),
      active: true,
      hidden: false,
      createdAt: timestamp,
      updatedAt: timestamp
    }, timestamp);
    validateItems(existingItems.concat(item));
    return item;
  }

  function updateItem(current, input, existingItems = [], timestamp = new Date().toISOString()) {
    validateItem(current);
    const editable = normalizedEditableFields({ ...current, ...input }, current, timestamp);
    const updated = normalizeItem({
      ...current,
      name: input && input.name,
      addressOrPlusCode: input && input.addressOrPlusCode,
      radiusMeters: input && input.radiusMeters,
      toleranceMeters: input && input.toleranceMeters,
      geocoding: editable.geocoding,
      latitude: editable.geocoding.latitude,
      longitude: editable.geocoding.longitude,
      coordinatesPending: !google.validCoordinates(editable.geocoding.latitude, editable.geocoding.longitude),
      updatedAt: timestamp
    }, timestamp);
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Badplatsen som skulle redigeras saknas.');
    validateItems(nextItems);
    return updated;
  }

  function applyGeocoding(current, geocodingValue, existingItems = [], timestamp = new Date().toISOString()) {
    validateItem(current);
    const geocoding = google.validateGeocoding(geocodingValue);
    const updated = normalizeItem({
      ...current,
      geocoding,
      latitude: geocoding.latitude,
      longitude: geocoding.longitude,
      coordinatesPending: !google.validCoordinates(geocoding.latitude, geocoding.longitude),
      updatedAt: timestamp
    }, timestamp);
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Badplatsen som skulle geokodas saknas.');
    validateItems(nextItems);
    return updated;
  }

  function setActive(current, active, existingItems = [], timestamp = new Date().toISOString()) {
    validateItem(current);
    if (current.hidden === true) throw new Error('En sammanslagen äldre badplatspost kan inte aktiveras.');
    const updated = normalizeItem({ ...current, active: active === true, updatedAt: timestamp }, timestamp);
    const nextItems = existingItems.map((item) => item.id === current.id ? updated : item);
    if (!nextItems.some((item) => item.id === current.id)) throw new Error('Badplatsen som skulle ändras saknas.');
    validateItems(nextItems);
    return updated;
  }

  function removeItem(current, existingItems = [], timestamp = new Date().toISOString()) {
    const updated = setActive(current, false, existingItems, timestamp);
    return existingItems.map((item) => item.id === current.id ? updated : item);
  }

  function withItems(registry, items, timestamp = new Date().toISOString()) {
    validateRegistry(registry);
    const normalizedItems = items.map((item) => normalizeItem(item, timestamp));
    validateItems(normalizedItems);
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: registry.revision + 1,
      updatedAt: timestamp,
      items: normalizedItems
    };
    validateRegistry(next);
    return next;
  }

  function baseBeachItem(place, timestamp) {
    return normalizeItem({
      ...place,
      addressOrPlusCode: text(place.addressOrPlusCode) || text(place.address) || text(place.plusCode),
      radiusMeters: place.radiusMeters,
      toleranceMeters: place.toleranceMeters,
      latitude: typeof place.latitude !== 'undefined' ? place.latitude : place.lat,
      longitude: typeof place.longitude !== 'undefined' ? place.longitude : place.lon,
      active: place.active !== false,
      hidden: false,
      createdAt: text(place.createdAt) || timestamp,
      updatedAt: text(place.updatedAt) || timestamp
    }, timestamp);
  }

  function migrateRegistry(stored, baseBeachPlaces = [], timestamp = new Date().toISOString()) {
    const sourceExists = typeof stored !== 'undefined';
    const source = sourceExists ? stored : { schemaVersion: 1, revision: 0, items: [] };
    if (!isPlainObject(source) || !Array.isArray(source.items)) throw new Error('Det äldre badplatsregistret har fel format.');
    if (![1, 2, SCHEMA_VERSION].includes(Number(source.schemaVersion))) throw new Error('Det äldre badplatsregistret har en okänd schemaversion.');
    if (!Number.isInteger(source.revision) || source.revision < 0) throw new Error('Det äldre badplatsregistret har en ogiltig revision.');

    const items = source.items.map((item) => normalizeItem(item, timestamp));
    const conflicts = [];
    let seededCount = 0;

    baseBeachPlaces.forEach((place) => {
      const seed = baseBeachItem(place, timestamp);
      const exactIndex = items.findIndex((item) => text(item.id) === seed.id);
      if (exactIndex >= 0) {
        items[exactIndex] = normalizeItem({
          ...seed,
          ...items[exactIndex],
          id: seed.id,
          category: 'badplats',
          roles: REQUIRED_ROLES.slice(),
          allowedJobTypeIds: REQUIRED_JOB_TYPE_IDS.slice(),
          aliases: uniqueTextItems([...(seed.aliases || []), ...(items[exactIndex].aliases || [])]),
          sourceNote: text(items[exactIndex].sourceNote) || text(seed.sourceNote)
        }, timestamp);
        return;
      }

      const sameNameIndex = items.findIndex((item) => item.hidden !== true && normalizedNameKey(item.name) === normalizedNameKey(seed.name));
      if (sameNameIndex >= 0) {
        const legacy = items[sameNameIndex];
        items[sameNameIndex] = normalizeItem({
          ...legacy,
          active: false,
          hidden: true,
          mergedIntoId: seed.id,
          updatedAt: timestamp
        }, timestamp);
        conflicts.push({ legacyId: legacy.id, canonicalId: seed.id, name: seed.name });
      }
      items.push(seed);
      seededCount += 1;
    });

    const candidateItems = items
      .map((item) => normalizeItem(item, timestamp))
      .sort((a, b) => {
        if (a.hidden !== b.hidden) return a.hidden ? 1 : -1;
        if (a.active !== b.active) return a.active ? -1 : 1;
        return a.name.localeCompare(b.name, 'sv-SE');
      });

    const sourceComparable = Number(source.schemaVersion) === SCHEMA_VERSION
      ? { ...source, items: source.items.map((item) => normalizeItem(item, timestamp)) }
      : null;
    const changed = !sourceComparable
      || JSON.stringify(sourceComparable.items) !== JSON.stringify(candidateItems)
      || seededCount > 0
      || conflicts.length > 0;
    const registry = {
      ...source,
      schemaVersion: SCHEMA_VERSION,
      revision: changed ? source.revision + 1 : source.revision,
      ...(changed ? { updatedAt: timestamp } : {}),
      items: candidateItems
    };
    validateRegistry(registry);
    return {
      registry,
      migrated: changed,
      sourceExisted: sourceExists,
      sourceSchemaVersion: Number(source.schemaVersion),
      seededCount,
      conflicts
    };
  }

  function isBeachPlace(place) {
    const roles = place && Array.isArray(place.roles) ? place.roles : [];
    return Boolean(place && (text(place.category) === 'badplats' || roles.includes('beach')));
  }

  function toEffectivePlace(item) {
    validateItem(item);
    return Object.freeze({
      id: item.id,
      name: item.name,
      aliases: uniqueTextItems(item.aliases),
      category: 'badplats',
      roles: REQUIRED_ROLES.slice(),
      allowedJobTypeIds: REQUIRED_JOB_TYPE_IDS.slice(),
      addressOrPlusCode: item.addressOrPlusCode,
      geocoding: Object.freeze({ ...item.geocoding }),
      radiusMeters: item.radiusMeters,
      toleranceMeters: item.toleranceMeters,
      latitude: item.latitude,
      longitude: item.longitude,
      coordinatesPending: item.coordinatesPending,
      active: item.active,
      hidden: item.hidden,
      mergedIntoId: item.mergedIntoId,
      sourceNote: item.sourceNote
    });
  }

  function buildEffectivePlaces(basePlaces = [], registry) {
    if (!Array.isArray(basePlaces)) throw new Error('Det fasta platsregistret saknas.');
    validateRegistry(registry);
    const fixedNonBeaches = basePlaces.filter((place) => !isBeachPlace(place)).map((place) => Object.freeze({ ...place }));
    const beaches = registry.items.map(toEffectivePlace);
    const combined = fixedNonBeaches.concat(beaches);
    const ids = new Set();
    combined.forEach((place) => {
      if (!text(place.id) || ids.has(place.id)) throw new Error('Den effektiva platslistan innehåller ett saknat eller dubblerat ID.');
      ids.add(place.id);
    });
    return Object.freeze(combined);
  }

  window.StadslassBeachRegistry = Object.freeze({
    SETTINGS_KEY,
    SCHEMA_VERSION,
    REQUIRED_ROLES,
    REQUIRED_JOB_TYPE_IDS,
    emptyRegistry,
    validateItem,
    validateRegistry,
    createItem,
    updateItem,
    applyGeocoding,
    setActive,
    removeItem,
    withItems,
    migrateRegistry,
    buildEffectivePlaces,
    isBeachPlace
  });
})();
