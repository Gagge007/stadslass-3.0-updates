'use strict';
const assert = require('assert');
const { TextEncoder } = require('util');
global.TextEncoder = TextEncoder;
global.performance = { now: () => Date.now() };
global.window = {};
const calls = [];
const hostReads = [];
const stores = {
  syncOutbox: JSON.stringify([
    { id: 'active', kind: 'sync-v63-request', requestId: 'a', intent: 'get-active', state: 'accepted', createdAt: '2026-08-03T03:40:00.000Z', updatedAt: '2026-08-03T03:41:00.000Z', request: { operation: 'GET', path: 'stadslass-3-sync/vehicles/189/active-status.json', coalesceKey: 'get-active/189' } },
    { id: 'journal', kind: 'sync-v69-terminal-journal', items: [{ requestId: 'old', state: 'succeeded' }] },
    { id: 'work', kind: 'sync-v63-command', state: 'waiting_result', token: 'must-not-leak' }
  ]),
  settings: JSON.stringify({ syncV63: { enabled: true, token: 'must-not-leak' } })
};
require('../js/sync-diagnostic.js');
const diagnostic = window.StadslassSyncDiagnostic.create({
  readStore: (name) => { calls.push(name); return stores[name]; },
  getRequestStatus: (requestId) => { hostReads.push(requestId); return { ok: true, status: 'succeeded', httpStatus: 200, errorCode: '', completedAt: 1785722299790 }; }
});
diagnostic.firstRoleView({ hostVersion: '3.0-host-16', role: 'vehicle_189', installationId: 'installation-335', deviceId: 'host-device-7cb', syncConfiguration: { token: 'must-not-leak' } });
diagnostic.observe('sync-result-received', { requestId: 'a', result: 'succeeded', pendingBefore: 6, pendingAfter: 5, durationMs: 25 });
assert.strictEqual(calls.length, 0, 'first role view must not start an inventory');
const first = diagnostic.snapshotReport({ reportId: 'sync-v71-first', performanceState: { active: true, events: [{ kind: 'long-task', durationMs: 4157 }, { kind: 'event-loop-delay', durationMs: 3348 }] } });
assert.deepStrictEqual(calls, ['syncOutbox', 'settings']);
assert.strictEqual(hostReads.length, 1, 'active host status must be read once');
assert.strictEqual(first.reportType, 'sync-verification');
assert.strictEqual(first.exportSequence, 1);
assert.strictEqual(first.counts.activeRequests, 1);
assert(first.content.startsWith('STADSLASS SYNKVERIFIERINGSRAPPORT'));
assert(first.content.includes('Syncinstallationens ID: installation-335'));
assert(first.content.includes('Värdappens enhets-ID: host-device-7cb'));
assert(first.content.includes('"whyStillActive":"host_terminal_result_not_consumed_locally"'));
assert(first.content.includes('"pendingBefore":6'));
assert(first.content.includes('"pendingAfter":5'));
assert(first.content.includes('blockerad eller kraftigt fryst under mätperioden'));
assert(!first.content.includes('must-not-leak'));
diagnostic.observe('new-traffic-after-first-export', { value: 1 });
const second = diagnostic.snapshotReport({ reportId: 'sync-v71-second' });
assert.deepStrictEqual(calls, ['syncOutbox', 'settings', 'syncOutbox', 'settings'], 'every export must perform a fresh inventory');
assert.strictEqual(second.exportSequence, 2);
assert(second.eventCount > first.eventCount, 'second export must include new traffic');
assert(second.content.includes('new-traffic-after-first-export'));
assert.notStrictEqual(first.reportId, second.reportId);
assert(!second.content.includes('FULLSTÄNDIG POSTLISTA'));
assert.strictEqual(stores.syncOutbox.includes('accepted'), true, 'read-only export must not mutate source data');
console.log('PASS sync-diagnostic.test.js');
