#!/usr/bin/env python3
import asyncio
import json
import shutil
from integration_app import async_playwright, new_page, app_click

async def run():
    if async_playwright is None:
        print(json.dumps({'status':'EJ_KORBAR_I_INTERN_MILJO','reason':'Python Playwright saknas.'}, ensure_ascii=False))
        return
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, executable_path=shutil.which('chromium'), args=['--no-sandbox'])
        context, page, errors = await new_page(browser, {})
        await page.set_viewport_size({'width': 390, 'height': 844})
        await app_click(page.locator('button[data-target="settings"]'))
        await app_click(page.locator('button[data-settings-group="import-extra"]'))
        await app_click(page.locator('button[data-settings-function="sync"]'))
        assert await page.locator('#sync-role-intro').count() == 0
        assert await page.locator('#performance-diagnostic-panel').is_visible()
        assert await page.locator('#sync-diagnostic-panel').is_visible()
        assert await page.locator('#performance-diagnostic-panel #sync-diagnostic-export').count() == 0
        assert await page.locator('#sync-diagnostic-panel #performance-report-export').count() == 0

        await app_click(page.locator('#sync-diagnostic-export'))
        exports = await page.evaluate('window.__hostState.textExports')
        assert len(exports) == 1
        sync_export = exports[-1]
        assert sync_export['fileName'].startswith('Stadslass_synkverifiering_vehicle_189_v71_')
        assert sync_export['contentUtf8'].startswith('STADSLASS SYNKVERIFIERINGSRAPPORT')
        assert 'STADSLASS PRESTANDARAPPORT' not in sync_export['contentUtf8']
        assert 'G. PRESTANDA OCH ANVÄNDBARHET' in sync_export['contentUtf8']
        assert await page.locator('#performance-report-export').is_disabled()
        await page.evaluate("requestId => window.dispatchEvent(new CustomEvent('stadslass:text-export-result',{detail:{requestId,status:'saved'}}))", sync_export['requestId'])
        status = await page.locator('#sync-diagnostic-status').inner_text()
        assert status == 'Synkverifiering exporterad.'
        assert sync_export['fileName'] not in status

        await app_click(page.locator('#performance-report-export'))
        exports = await page.evaluate('window.__hostState.textExports')
        assert len(exports) == 2
        perf_export = exports[-1]
        assert perf_export['fileName'].startswith('Stadslass_prestandarapport_v71_')
        assert perf_export['contentUtf8'].startswith('STADSLASS PRESTANDARAPPORT')
        assert 'STADSLASS SYNKVERIFIERINGSRAPPORT' not in perf_export['contentUtf8']
        await page.evaluate("requestId => window.dispatchEvent(new CustomEvent('stadslass:text-export-result',{detail:{requestId,status:'saved'}}))", perf_export['requestId'])
        status = await page.locator('#performance-report-status').inner_text()
        assert status == 'Prestandarapport exporterad.'
        assert perf_export['fileName'] not in status

        await page.evaluate("document.getElementById('sync-diagnostic-summary').textContent='X'.repeat(1200)")
        await page.wait_for_timeout(50)
        width = await page.evaluate("({inner:window.innerWidth, html:document.documentElement.scrollWidth, body:document.body.scrollWidth, element:document.getElementById('sync-diagnostic-summary').scrollWidth})")
        assert width['html'] <= width['inner'], width
        assert width['body'] <= width['inner'], width
        assert errors == [], errors
        await context.close()
        await browser.close()
    print(json.dumps({'status':'PASS','tests':['separate-cards','typed-sync-export','typed-performance-export','short-confirmation','parallel-export-lock','mobile-width-guard']}, ensure_ascii=False))

if __name__ == '__main__':
    asyncio.run(run())
