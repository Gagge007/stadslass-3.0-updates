const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const context = { window: {}, encodeURIComponent, fetch: async () => { throw new Error('Fetch ska inte användas för samma punkt'); } };
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', 'routes-service.js'), 'utf8'), context);
const routes = context.window.StadslassRoutesService;

(async () => {
  let routeRequest;
  const route = await routes.fetchDistance(
    { latitude: 57.70, longitude: 11.90 },
    { latitude: 57.71, longitude: 11.91 },
    async (url, options) => {
      routeRequest = { url, options };
      return { ok: true, json: async () => ({ ok: true, distanceMeters: 1234, duration: '65s' }) };
    }
  );
  assert.equal(route.meters, 1234);
  assert.equal(route.duration, '65s');
  assert.match(routeRequest.url, /^https:\/\/stadslass\.local\/host-api\/google\/routes\?/);
  assert.match(routeRequest.url, /origin=57\.700000%2C11\.900000/);
  assert.match(routeRequest.url, /destination=57\.710000%2C11\.910000/);
  assert.deepEqual(routeRequest.options, { method: 'GET', credentials: 'omit', cache: 'no-store' });
  assert.equal(routeRequest.url.includes('key='), false);
  assert.equal(routeRequest.options.headers, undefined);

  let geocodeRequest;
  const point = await routes.geocode('Ringön (BAS)', async (url, options) => {
    geocodeRequest = { url, options };
    return { ok: true, json: async () => ({ ok: true, lat: 57.704, lng: 11.937 }) };
  });
  assert.deepEqual({ latitude: point.latitude, longitude: point.longitude }, { latitude: 57.704, longitude: 11.937 });
  assert.match(geocodeRequest.url, /^https:\/\/stadslass\.local\/host-api\/google\/geocode\?address=/);
  assert.deepEqual(geocodeRequest.options, { method: 'GET', credentials: 'omit', cache: 'no-store' });
  assert.equal(await routes.fetchDistance({ latitude: 57.7, longitude: 11.9 }, { latitude: 57.7, longitude: 11.9 }), 0);
  console.log('PASS v117-secure-routes.test.js');
})().catch((error) => { console.error(error); process.exitCode = 1; });
