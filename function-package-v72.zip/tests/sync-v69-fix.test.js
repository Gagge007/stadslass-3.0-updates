#!/usr/bin/env node
'use strict';
const assert = require('assert');
const { TextEncoder } = require('util');
global.TextEncoder = TextEncoder;
global.window = {};
require('../js/sync-service.js');
const api = window.StadslassSyncService;
assert.strictEqual(api.PACKAGE_VERSION, 72);

const real = [
  { id: 'transfer', kind: 'queue-transfer', state: 'prepared', payloadText: 'KEEP' },
  { id: 'receipt', kind: 'queue-receipt', state: 'prepared' },
  { id: 'command', kind: 'sync-v63-command', state: 'waiting_ledger', command: { body: 'KEEP' } },
  { id: 'unknown', kind: 'future-kind', state: 'mystery', payload: 'KEEP' }
];
const terminal = Array.from({ length: 65 }, (_, index) => ({
  id: `r-${index}`, kind: 'sync-v63-request', requestId: `request-${index}`, intent: 'get-results',
  request: { operation: 'GET', path: 'stadslass-3-sync/vehicles/189/command-results.json', coalesceKey: 'get-results/189', body: 'FULL-PAYLOAD-MUST-NOT-BE-IN-JOURNAL' },
  state: index % 2 ? 'succeeded' : 'failed_permanent', result: { httpStatus: index % 2 ? 200 : 404, errorCode: index % 2 ? '' : 'github_http_404', responseBody: 'FULL-RESPONSE-MUST-NOT-BE-IN-JOURNAL' },
  createdAt: '2026-08-03T00:00:00Z', updatedAt: '2026-08-03T00:00:01Z'
}));
const migrated = api.migrateOutbox([...real, ...terminal]);
assert.strictEqual(migrated.moved, 65);
real.forEach((entry) => assert(migrated.entries.some((item) => item.id === entry.id), `${entry.id} must be preserved`));
const journal = migrated.entries.find((entry) => entry.kind === 'sync-v69-terminal-journal');
assert(journal);
assert.strictEqual(journal.items.length, 50);
assert(!JSON.stringify(journal).includes('FULL-PAYLOAD'));
assert(!JSON.stringify(journal).includes('FULL-RESPONSE'));
const secondMigration = api.migrateOutbox(migrated.entries);
assert.strictEqual(secondMigration.changed, false);
assert.deepStrictEqual(secondMigration.entries, migrated.entries);

let outbox = [{ id: 'active', kind: 'sync-v63-request', requestId: 'existing', intent: 'get-queue', request: { operation: 'GET', path: 'p', coalesceKey: 'get-queue/189' }, state: 'pending' }];
let hostCalls = 0;
const hostInfo = { syncTransportApiVersion: 1, deviceIdentityApiVersion: 1, syncCredentialApiVersion: 1 };
const host = { enqueueSyncRequest() { hostCalls += 1; return JSON.stringify({ ok: true, status: 'accepted' }); }, getSyncRequestStatus() { return '{}'; } };
const service = api.create({ host: () => host, getHostInfo: () => hostInfo, readOutbox: () => outbox, saveOutbox: (next) => { outbox = next; return true; } });
const duplicate = service.enqueue('get-queue', 'GET', 'stadslass-3-sync/vehicles/189/shared-queue.json', api.PRIORITIES.queue, '', '', 'get-queue/189');
assert.strictEqual(duplicate.status, 'duplicate_pending');
assert.strictEqual(hostCalls, 0);
assert.strictEqual(outbox.length, 1);
outbox[0].state = 'succeeded';
const allowed = service.enqueue('get-queue', 'GET', 'stadslass-3-sync/vehicles/189/shared-queue.json', api.PRIORITIES.queue, '', '', 'get-queue/189');
assert.strictEqual(allowed.ok, true);
assert.strictEqual(hostCalls, 1);

outbox = api.setResourceState([], 'stadslass-3-sync/vehicles/189/shared-queue.json', { sha: 'known-sha' });
const putService = api.create({ host: () => host, getHostInfo: () => hostInfo, readOutbox: () => outbox, saveOutbox: (next) => { outbox = next; return true; } });
let captured;
host.enqueueSyncRequest = (raw) => { captured = JSON.parse(raw); return JSON.stringify({ ok: true, status: 'accepted' }); };
putService.enqueue('put-queue', 'PUT', 'stadslass-3-sync/vehicles/189/shared-queue.json', api.PRIORITIES.queue, '{}', '', 'shared_queue/189');
assert.strictEqual(captured.expectedSha, 'known-sha');

const terminalRequest = outbox.find((entry) => entry.kind === 'sync-v63-request');
const consumed = api.consumeTerminal(outbox, terminalRequest.requestId, { status: 'succeeded', httpStatus: 200, responseSha: 'new-sha' });
assert(consumed.consumed);
assert(!consumed.entries.some((entry) => entry.kind === 'sync-v63-request' && entry.requestId === terminalRequest.requestId));
assert.strictEqual(api.counts(consumed.entries).journalItems, 1);
console.log('PASS sync-v69-fix.test.js');
