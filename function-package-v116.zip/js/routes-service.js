(() => {
  'use strict';
  const ENDPOINT = 'https://routes.googleapis.com/directions/v2:computeRoutes';
  const DRIVE_PHASES = Object.freeze(['start_route', 'transport', 'return_transport']);
  const REFRESH_MS = 120000;
  const MOTION_SPEED_KMH = 5;
  const MOTION_DISTANCE_METERS = 50;
  const MOTION_WINDOW_MS = 60000;
  const text = (value) => typeof value === 'string' ? value.trim() : '';
  const valid = (point) => point && Number.isFinite(Number(point.latitude)) && Number.isFinite(Number(point.longitude))
    && Number(point.latitude) >= -90 && Number(point.latitude) <= 90 && Number(point.longitude) >= -180 && Number(point.longitude) <= 180;
  const distance = (a, b) => {
    if (!valid(a) || !valid(b)) return 0;
    const r = 6371000, toRad = Math.PI / 180;
    const dLat = (Number(b.latitude) - Number(a.latitude)) * toRad;
    const dLon = (Number(b.longitude) - Number(a.longitude)) * toRad;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(Number(a.latitude) * toRad) * Math.cos(Number(b.latitude) * toRad) * Math.sin(dLon / 2) ** 2;
    return 2 * r * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  };
  const speedKmh = (before, after) => {
    if (!before || !after || !Number.isFinite(before.timestamp) || !Number.isFinite(after.timestamp)) return 0;
    const delta = Math.max(1, after.timestamp - before.timestamp);
    return distance(before, after) / delta * 3600;
  };
  function motionProven(before, after) {
    if (!before || !after || Number(after.accuracy) > 50) return false;
    const elapsed = Number(after.timestamp) - Number(before.timestamp);
    return speedKmh(before, after) > MOTION_SPEED_KMH || (elapsed > 0 && elapsed <= MOTION_WINDOW_MS && distance(before, after) >= MOTION_DISTANCE_METERS);
  }
  function shouldRefresh(state, phase, before, snapshot, now = Date.now(), immediate = false) {
    if (!DRIVE_PHASES.includes(phase) || !valid(snapshot)) return false;
    if (immediate || !state || text(state.phase) !== phase || !Number.isFinite(Number(state.lastAttemptAtEpochMs))) return true;
    return now - Number(state.lastAttemptAtEpochMs) >= REFRESH_MS && motionProven(before, snapshot);
  }
  async function fetchDistance(origin, destination, apiKey, fetchImpl = fetch) {
    if (!valid(origin) || !valid(destination)) throw new Error('ROUTE_COORDINATES_MISSING');
    if (distance(origin, destination) < 1) return 0;
    const response = await fetchImpl(ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': text(apiKey), 'X-Goog-FieldMask': 'routes.distanceMeters' },
      body: JSON.stringify({ origin: { location: { latLng: { latitude: Number(origin.latitude), longitude: Number(origin.longitude) } } }, destination: { location: { latLng: { latitude: Number(destination.latitude), longitude: Number(destination.longitude) } } }, travelMode: 'DRIVE' })
    });
    if (!response || !response.ok) throw new Error(`ROUTES_HTTP_${response && response.status ? response.status : 0}`);
    const payload = await response.json();
    const meters = Number(payload && payload.routes && payload.routes[0] && payload.routes[0].distanceMeters);
    if (!Number.isFinite(meters) || meters < 0) throw new Error('ROUTES_RESPONSE_INVALID');
    return Math.round(meters);
  }
  const formatDistance = (meters) => !Number.isFinite(Number(meters)) ? '–' : (Number(meters) < 1000 ? `${Math.round(Number(meters))} m` : `${(Number(meters) / 1000).toLocaleString('sv-SE', { maximumFractionDigits: 1 })} km`);
  window.StadslassRoutesService = Object.freeze({ ENDPOINT, DRIVE_PHASES, REFRESH_MS, valid, distance, motionProven, shouldRefresh, fetchDistance, formatDistance });
})();
