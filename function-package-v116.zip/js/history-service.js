(() => {
  'use strict';
  const text = (value) => typeof value === 'string' ? value.trim() : '';
  const object = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const parse = (value) => { const time = new Date(value).getTime(); return Number.isFinite(time) ? time : null; };
  function workMinutes(record, now = Date.now()) {
    const segments = Array.isArray(record && record.workSegments) ? record.workSegments : [];
    if (!segments.length) return Number.isFinite(Number(record && record.legacyActiveMinutes)) ? Math.max(0, Math.round(Number(record.legacyActiveMinutes))) : null;
    const ms = segments.reduce((sum, segment) => { const from = parse(segment && segment.startedAt); const to = parse(segment && segment.endedAt) || now; return sum + (from === null ? 0 : Math.max(0, to - from)); }, 0);
    return Math.floor(ms / 60000);
  }
  const formatMinutes = (minutes) => !Number.isFinite(Number(minutes)) ? '–' : `${Math.floor(Number(minutes) / 60)} h ${String(Math.round(Number(minutes) % 60)).padStart(2, '0')} min`;
  function canonical(record) {
    const source = object(record); const copy = { ...source };
    delete copy.updatedAt; delete copy.syncState; delete copy.historySync; delete copy.revision; delete copy.localOnly;
    return JSON.stringify(copy, Object.keys(copy).sort());
  }
  async function hash(record) {
    const input = new TextEncoder().encode(canonical(record));
    const bytes = await crypto.subtle.digest('SHA-256', input);
    return Array.from(new Uint8Array(bytes)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  const median = (values) => { const sorted = values.filter(Number.isFinite).sort((a,b) => a-b); if (!sorted.length) return null; const middle = Math.floor(sorted.length / 2); return sorted.length % 2 ? sorted[middle] : Math.round((sorted[middle - 1] + sorted[middle]) / 2); };
  function learning(records) {
    const buckets = new Map();
    records.filter((record) => record && record.excludeFromEstimateLearning !== true && !object(record.trashState).trashedAt && record.needsMatching !== true).forEach((record) => {
      const samples = object(record.p116Learning).samples;
      if (!Array.isArray(samples)) return;
      samples.forEach((sample) => { const value = Number(sample && sample.minutes); const key = `${text(record.jobTypeId)}|${text(sample && sample.placeId)}|${text(sample && sample.phase)}`; if (!key.includes('||') && Number.isFinite(value) && value >= 0) buckets.set(key, [...(buckets.get(key) || []), value]); });
    });
    return Array.from(buckets, ([key, values]) => ({ key, samples: values.length, medianMinutes: values.length >= 3 ? median(values) : null }));
  }
  function sanitizeSeed(backup) {
    const parts = object(backup).parts; const history = Array.isArray(parts.history) ? parts.history : (Array.isArray(object(parts.history).items) ? object(parts.history).items : []);
    return { schemaVersion: 1, seedType: 'v419-history', createdAt: new Date().toISOString(), records: history.map((item) => ({ ...object(item), syncState: undefined, localOnly: undefined })) };
  }
  window.StadslassHistoryService = Object.freeze({ workMinutes, formatMinutes, hash, canonical, median, learning, sanitizeSeed });
})();
