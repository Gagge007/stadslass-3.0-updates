const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const root=require('path').resolve(__dirname,'..');
const source=fs.readFileSync(root+'/js/job-type-registry.js','utf8');
const context={window:{crypto:{getRandomValues:(bytes)=>bytes.fill(7)}}};
vm.createContext(context); vm.runInContext(source,context);
const api=context.window.StadslassJobTypeRegistry;
const stamp='2026-08-21T17:30:00.000Z';
const id=(digit)=>`JT3-${String(digit).repeat(32)}`;
const stored={schemaVersion:7,revision:3,updatedAt:stamp,removedDefaultIds:[],items:[
  {id:id('1'),name:'Maskintransport äldre',specialRole:'machine-transport',defaultDefinition:false,createdAt:stamp,updatedAt:stamp}
]};
const defaults=[
  {id:'JT-1011',registryId:id('2'),name:'Maskintransport',specialRole:'machine-transport',canonicalTypeId:'JT-1011',defaultDefinition:true,createdAt:stamp,updatedAt:stamp}
];
const result=api.migrateAndMergeRegistry(stored,defaults,stamp);
api.validateRegistry(result.registry);
assert.strictEqual(result.migrated,true);
assert.strictEqual(result.registry.items.filter((item)=>item.specialRole==='machine-transport').length,1);
assert.strictEqual(result.registry.items.find((item)=>item.id===id('1')).specialRole,'none');
assert.strictEqual(result.registry.items.find((item)=>item.id===id('2')).specialRole,'machine-transport');
console.log('PASS v109-postmerge-role-recovery.test.js');
