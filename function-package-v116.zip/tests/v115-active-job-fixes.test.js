#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'js', 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const model = fs.readFileSync(path.join(root, 'js', 'job-model.js'), 'utf8');
assert.ok(app.includes('Ett aktivt uppdrag pågår. Uppdraget kan bara läggas i kö.'));
assert.ok(app.includes("currentPhase === phaseService.PHASES.READY_TO_COMPLETE"));
assert.ok(!html.includes('id="active-display-status"'));
assert.ok(!html.includes('id="active-display-paused"'));
assert.ok(!html.includes('id="active-display-weight-status"'));
assert.ok(!html.includes('Fasen uppdateras automatiskt med GPS.'));
assert.ok(html.includes('id="job-type-registry-material-code"'));
assert.ok(app.includes("byId('active-current-load-row').hidden = otherActivity || activeJobDocument.multiLoad !== true;"));
assert.ok(model.includes("text(type.materialRule) === 'not-material-transport'"));
console.log('PASS v115-active-job-fixes.test.js');
