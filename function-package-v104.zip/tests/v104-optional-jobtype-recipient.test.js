'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const context = { window: { crypto: { getRandomValues: (bytes) => bytes.fill(1) } }, Uint8Array, Date, Math, Set, Array, Object, String, Boolean, RegExp, Error };
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', 'job-type-registry.js'), 'utf8'), context);
const api = context.window.StadslassJobTypeRegistry;

const created = api.createItem({ name: 'Test ÄTA utan mottagare', specialRole: 'none', ataEnabled: true, ataRecipient: null }, []);
assert.strictEqual(created.ataEnabled, true);
assert.strictEqual(created.ataRecipient, null);

const updated = api.updateItem(created, { name: created.name, specialRole: 'none', ataEnabled: true, ataRecipient: null }, [created], '2026-08-21T14:20:00.000Z');
assert.strictEqual(updated.ataEnabled, true);
assert.strictEqual(updated.ataRecipient, null);

console.log('PASS v104-optional-jobtype-recipient.test.js');
