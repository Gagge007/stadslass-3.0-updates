(() => {
  'use strict';
  function diagnostic(event, data = {}) {
    try { if (window.StadslassBackgroundDiagnostic && window.StadslassBackgroundDiagnostic.isEnabled()) window.StadslassBackgroundDiagnostic.record(event, data); } catch (_) {}
  }

  const text = (value) => typeof value === 'string' ? value.trim() : '';
  const object = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const roles = Object.freeze({ start_route: 'from', loading: 'from', transport: 'destination', unloading: 'destination', load_registered: 'destination', return_transport: 'return', return_unloading: 'return' });
  const driving = new Set(['start_route', 'transport', 'return_transport']);
  function validText(value, max) {
    if (!value || value.length > max || /[\u0000-\u001f\u007f-\u009f|\u2028\u2029]/u.test(value)) return false;
    for (const char of value) if (char.length === 1 && /[\ud800-\udfff]/u.test(char)) return false;
    return true;
  }
  function coordinates(value) {
    const lat = value.latitude ?? value.lat, lon = value.longitude ?? value.lon;
    return typeof lat === 'number' && typeof lon === 'number' && Number.isFinite(lat) && Number.isFinite(lon)
      && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180 ? { latitude: lat, longitude: lon } : null;
  }
  function mapReference(value) {
    const reference = text(value);
    if (!validText(reference, 512) || reference.includes(':') || reference.includes('//')) return '';
    const url = 'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(reference) + '&travelmode=driving&dir_action=navigate';
    return url.length <= 2048 ? reference : '';
  }
  function target(jobValue, resolvePlace) {
    const job = object(jobValue), phase = text(job.phase), role = roles[phase]
      || (phase === 'ready_to_complete' ? (job.returnRequired === true ? 'return' : 'destination') : '');
    if (!role) return { label: 'Mål saknas', request: null, enabled: false };
    const temporary = window.StadslassTemporaryPlaceService;
    const id = role === 'from' ? text(job.fromPlaceId) : role === 'destination' ? text(job.destinationPlaceId) : text(job.returnPlaceId) || text(job.fromPlaceId);
    const sourceRole = role === 'return' ? 'from' : role;
    const isTemporary = temporary && temporary.isTemporarySelection(id, sourceRole);
    const snapshot = isTemporary ? object(object(job.temporaryPlaces)[sourceRole]) : null;
    const place = isTemporary ? snapshot : object(typeof resolvePlace === 'function' ? resolvePlace(job, role) : null);
    const fullReference = isTemporary
      ? text(place.normalizedAddress) || text(place.addressOrPlusCode)
      : text(place.addressOrPlusCode) || text(place.address) || text(place.plusCode) || text(object(place.geocoding).formattedAddress);
    const name = isTemporary ? text(place.temporaryPlaceName) : text(place.name);
    const presentation = object(place.navigationPresentation);
    const shortAddress = text(presentation.reference) === fullReference ? text(presentation.addressLabel) : '';
    const pair = isTemporary
      ? (place.coordinateValid === true ? coordinates(place) : null)
      : coordinates(object(place.geocoding)) || coordinates(place);
    const reference = mapReference(fullReference);
    const request = pair ? { ...pair } : reference ? { mapReference: reference } : null;
    // An invalid text reference never poisons an otherwise valid coordinate destination.
    if (pair && reference) request.mapReference = reference;
    const label = name || shortAddress || fullReference || (pair ? `${pair.latitude}, ${pair.longitude}` : 'Mål saknas');
    return { label, request, enabled: driving.has(phase) && job.status === 'active' && Boolean(request) };
  }
  function open(job, resolvePlace, host, hostInfo) {
    const destination = target(job, resolvePlace);
    if (!destination.enabled) return { ok: false, message: 'Navigation är inte tillgänglig i denna fas eller för detta mål.' };
    if (!host || typeof host.openNavigation !== 'function' || Number(object(hostInfo).navigationApiVersion) < 1) {
      return { ok: false, message: 'Navigation är inte tillgänglig i den aktuella appsessionen.' };
    }
    try { if (window.StadslassBackgroundDiagnostic) window.StadslassBackgroundDiagnostic.begin(job.phase); } catch (_) {}
    const recovery = window.StadslassRuntimeRecovery;
    if (recovery) recovery.navigation(job);
    try {
      const result = JSON.parse(host.openNavigation(JSON.stringify(destination.request)));
      diagnostic('navigation.result', () => ({status:result && result.status || 'malformed'}));
      if (!result || typeof result.ok !== 'boolean' || typeof result.status !== 'string') throw new Error('response');
      if (result.ok === true && result.status === 'opened') return { ok: true, status: result.status, message: '' };
      if (recovery) recovery.clear('route');
      const errors = {
        invalid_request: 'Navigationsmålet kunde inte användas.',
        no_navigation_handler: 'Ingen app kunde öppna navigationen.',
        host_error: 'Navigationen kunde inte öppnas. Försök igen.',
        origin_denied: 'Navigation nekades i den aktuella appsessionen.'
      };
      if (result.ok === false && errors[result.status]) return { ok: false, status: result.status, message: errors[result.status] };
      throw new Error('response');
    } catch (_) {
      if (recovery) recovery.clear('route');
      return { ok: false, message: 'Navigationen kunde inte öppnas eller gav ett oväntat svar.' };
    }
  }
  window.StadslassNavigationService = Object.freeze({ target, open });
})();
