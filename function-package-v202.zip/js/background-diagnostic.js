(() => {
  'use strict';
  // Host40 owns the only persisted switch. This cache never owns business state or GPS.
  const runtimeId = 'js_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2);
  let timer = null, lastBeat = 0, view = 'home', until = 0, enabled = false, available = false;
  const mono = () => window.performance && typeof window.performance.now === 'function' ? window.performance.now() : Date.now();
  function envelope(event, data) { return JSON.stringify({ event, runtimeId, jsMonoMs: mono(), data }); }
  const recent = new Map();
  function record(event, data) {
    if (!enabled) return;
    try {
      data = typeof data === 'function' ? data() : (data || {});
      if (['gps.consumer','gps.start-watch','geofence.before'].includes(event)
          || (event === 'geofence.result' && ['STATE_STABLE','POSITION_UNUSABLE'].includes(data.reason))) {
        const identity = JSON.stringify({...data, ageMs:undefined}), old = recent.get(event), now = mono();
        if (old && old.identity === identity && now - old.at < 2000) return;
        recent.set(event, {identity, at:now});
      }
      const host = window.StadslassHost;
      if (host && typeof host.recordDiagnosticEvent === 'function') host.recordDiagnosticEvent(envelope(event, data));
    } catch (_) {} // Observations must never escape into the work flow.
  }
  function stop() { if (timer !== null) window.clearTimeout(timer); timer = null; }
  function resume() {
    if (!enabled) { stop(); return; }
    try {
      const host = window.StadslassHost;
      if (!host || typeof host.diagnosticTraceStatus !== 'function') return;
      const state = JSON.parse(host.diagnosticTraceStatus());
      if (state.enabled !== true) { applyStatus(state); return; }
      if (!state.active) { stop(); return; }
      until = Number(state.untilWall) || 0;
      if (timer !== null) return;
      lastBeat = mono();
      timer = window.setTimeout(beat, 2000);
    } catch (_) { stop(); }
  }
  function beat() {
    timer = null;
    if (!enabled) return;
    try {
      const now = mono();
      record('js.heartbeat', { gapMs: now - lastBeat, foreground: document.visibilityState !== 'hidden' });
      lastBeat = now;
      if (Date.now() < until) timer = window.setTimeout(beat, 2000);
    } catch (_) { stop(); }
  }
  function begin(phase) {
    if (!enabled) return;
    try {
      const host = window.StadslassHost;
      if (!host || typeof host.beginDiagnosticTrace !== 'function') return;
      host.beginDiagnosticTrace(envelope('navigation.before', { view, phase, active: true, packageVersion: 202 }));
      record('navigation.before', { view, phase, active: true, packageVersion: 202 });
      const gps = window.StadslassGpsService;
      if (gps) {
        const s = gps.getSnapshot();
        record('gps.trace-baseline', {watchRegistered:s.isWatching, usable:s.isUsable, accuracy:s.accuracy,
          ageMs:s.age, providerAt:s.timestamp, foreground:s.appState === 'förgrund'});
      }
      const geofence = window.StadslassGeofenceService;
      if (geofence) {
        const g = geofence.getSnapshot();
        record('geofence.trace-baseline', {active:g.active, before:g.confirmedState,
          role:g.context ? g.context.placeRole : 'none'});
      }
      resume();
    } catch (_) {}
  }
  function route(value) { try { view = value; if(enabled) record('route.current', {view}); } catch (_) {} }
  function exportTrace() {
    try {
      const host = window.StadslassHost;
      if (!host || typeof host.exportDiagnosticTrace !== 'function') return 'Diagnostikexport kräver Host40.';
      const result = JSON.parse(host.exportDiagnosticTrace());
      return result.ok ? 'Androids delningsruta öppnas.' : 'Diagnostiken kunde inte exporteras. Försök igen när exporten är ledig.';
    } catch (_) { return 'Diagnostiken kunde inte exporteras.'; }
  }
  const element = id => document.getElementById(id);
  function applyStatus(state) {
    available = !!state && state.controlApiVersion === 1 && typeof state.enabled === 'boolean';
    enabled = available && state.enabled === true;
    if (!enabled) { stop(); until = 0; recent.clear(); }
    return available;
  }
  function refresh() {
    try { return applyStatus(JSON.parse(window.StadslassHost.diagnosticTraceStatus())); }
    catch (_) { return applyStatus(null); }
  }
  function display() {
    const label=element('background-diagnostic-mode'), button=element('background-diagnostic-toggle');
    if(label)label.textContent=available ? 'Status: '+(enabled?'På':'Av') : 'Status kunde inte läsas. Host40 krävs.';
    if(button){button.textContent=enabled?'Stäng av':'Slå på';button.disabled=!available;}
    const clear=element('clear-background-diagnostic');if(clear)clear.disabled=!available;
  }
  function message(text) { const target=element('background-diagnostic-status');if(target)target.textContent=text; }
  function renderControls(visible) {
    const panel=element('background-diagnostic-panel');if(!panel)return;
    panel.hidden=visible!==true;
    if(visible){refresh();display();resume();}
    else {const confirm=element('background-diagnostic-confirm');if(confirm)confirm.hidden=true;}
  }
  function toggle() {
    try {
      const state=JSON.parse(window.StadslassHost.setBackgroundDiagnostic(JSON.stringify({enabled:!enabled})));
      if(state.controlApiVersion===1)applyStatus(state);
      display();
      message(state.ok ? (state.status==='log_unavailable'?'Läget är sparat, men diagnostikloggen kunde inte öppnas.':enabled?'Bakgrundsdiagnostik är på.':'Bakgrundsdiagnostik är av. Sparade loggar finns kvar.') : 'Diagnostikläget kunde inte sparas.');
      if(state.ok)resume();
    }catch(_){message('Diagnostikläget kunde inte sparas.');}
  }
  function clearConfirmed() {
    const confirm=element('background-diagnostic-confirm');if(confirm)confirm.hidden=true;
    try {
      const result=JSON.parse(window.StadslassHost.clearBackgroundDiagnostic('{}'));
      if(result.controlApiVersion===1)applyStatus(result);
      if(result.ok){stop();until=0;recent.clear();}
      display();message(result.ok?'Diagnostikloggen är rensad.':'Diagnostikloggen kunde inte rensas. Försök igen när exporten är ledig.');
    }catch(_){message('Diagnostikloggen kunde inte rensas.');}
  }
  function installControls() {
    const bind=(id,fn)=>{const button=element(id);if(button&&!button.dataset.diagnosticBound){button.dataset.diagnosticBound='true';button.addEventListener('click',fn);}};
    bind('background-diagnostic-toggle',toggle);
    bind('export-background-diagnostic',()=>message(exportTrace()));
    bind('clear-background-diagnostic',()=>{const confirm=element('background-diagnostic-confirm');if(confirm)confirm.hidden=false;});
    bind('background-diagnostic-clear-confirm',clearConfirmed);
    bind('background-diagnostic-clear-cancel',()=>{const confirm=element('background-diagnostic-confirm');if(confirm)confirm.hidden=true;});
    display();
  }
  window.StadslassBackgroundDiagnostic = Object.freeze({record,begin,route,resume,exportTrace,refresh,renderControls,installControls,isEnabled:()=>enabled});
  refresh();
  if(enabled)record('js.init', {packageVersion:202, view});
  resume();
  window.addEventListener('pagehide', () => { if(enabled)record('js.pagehide', {view}); stop(); });
  document.addEventListener('visibilitychange', () => {
    if(!enabled)return;
    record('js.visibility', {foreground:document.visibilityState !== 'hidden', view}); resume();
  });
})();
