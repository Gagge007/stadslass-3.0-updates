(() => {
  'use strict';
  function diagnostic(event, data = {}) {
    try { if (window.StadslassBackgroundDiagnostic && window.StadslassBackgroundDiagnostic.isEnabled()) window.StadslassBackgroundDiagnostic.record(event, data); } catch (_) {}
  }

  const labels = Object.freeze({ loading: 'Lastning', unloading: 'Lossning', return_unloading: 'Returlossning' });
  const statuses = new Set(['shown', 'app_visible', 'no_external_handoff', 'permission_denied', 'stale_request', 'invalid_request', 'origin_denied', 'host_error']);
  function afterCommit(previous, current, host, hostInfo) {
    diagnostic('reminder.evaluate', () => ({previousPhase:previous && previous.phase || '', phase:current && current.phase || ''}));
    if (!previous || !current || previous.status !== 'active' || current.status !== 'active'
      || previous.phase === current.phase || !labels[current.phase]) { diagnostic('reminder.skipped', () => ({reason:'condition_not_met'})); return { requested: false }; }
    const previousId = previous.jobId || previous.id, currentId = current.jobId || current.id;
    if (!previousId || previousId !== currentId) { diagnostic('reminder.skipped', () => ({reason:'condition_not_met'})); return { requested: false }; }
    if (!host || typeof host.requestPhaseReminder !== 'function' || !hostInfo || Number(hostInfo.phaseReminderApiVersion) < 1) {
      diagnostic('reminder.skipped', () => ({reason:'api_unavailable'}));
      return { requested: false, unavailable: true };
    }
    try {
      diagnostic('reminder.request', () => ({phaseLabel:labels[current.phase]}));
      const response = JSON.parse(host.requestPhaseReminder(JSON.stringify({ phaseLabel: labels[current.phase] })));
      diagnostic('reminder.result', () => ({status:response && response.status || 'malformed'}));
      if (!response || !statuses.has(response.status) || typeof response.ok !== 'boolean'
        || response.ok !== (response.status === 'shown')) return { requested: true, malformed: true };
      return { requested: true, status: response.status, shown: response.ok };
    } catch (_) { diagnostic('reminder.result', () => ({status:'bridge_error'})); return { requested: true, malformed: true }; }
  }
  window.StadslassPhaseReminderService = Object.freeze({ afterCommit });
})();
