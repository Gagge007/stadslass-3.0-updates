(() => {
  'use strict';
  // P194: one durable intent, one full Host35 staged plan, one business commit.
  const OWNER = 194, KEY = 'p194DataRecoveryV1', CATS = ['history','trash','learning'];
  const copy = v => JSON.parse(JSON.stringify(v));
  const enc = s => new TextEncoder().encode(s.replace(/[\uD800-\uDFFF]/g,(unit,index,whole)=>{
    const code=unit.charCodeAt(0),adjacent=whole.charCodeAt(index+(code<0xDC00?1:-1));
    return code<0xDC00?(adjacent>=0xDC00&&adjacent<=0xDFFF?unit:'?'):(adjacent>=0xD800&&adjacent<=0xDBFF?unit:'?');
  }));
  let busy = false, pending = false;
  const host = () => window.StadslassHost;
  function result(raw) { const v=JSON.parse(raw || '{}'); if(v.ok!==true){const e=new Error(`Lagringen stoppades: ${v.code || 'invalid_response'}`);e.code=v.code;throw e;} return v; }
  function request(operation,body={}) { return result(host().requestHostData(JSON.stringify({operation,...body}))); }
  function native(operation,body={}) { return result(host().requestNativeStorage(JSON.stringify({operation,...body}))); }
  function stage(operation,body={}) { return result(host().requestStaging(JSON.stringify({stagingApiVersion:1,operation,...body}))); }
  function number(n) {
    if(!Number.isFinite(n))throw new Error('Ogiltigt JSON-tal.');
    if(Object.is(n,-0))return '0';
    if(Number.isInteger(n)&&Math.abs(n)<=Number.MAX_SAFE_INTEGER)return String(n);
    if(Math.abs(n)!==0&&(Math.abs(n)<1e-3||Math.abs(n)>=1e7)){let [m,e]=n.toExponential().split('e');return (m.includes('.')?m:m+'.0')+'E'+Number(e);}
    return String(n);
  }
  // Android org.json.JSONObject.quote escapes solidus; JSON.stringify does not.
  const quote=s=>'"'+s.replace(/["\\/\u0000-\u001f]/g,c=>c==='/'?'\\/':JSON.stringify(c).slice(1,-1))+'"';
  function canonical(v){if(v===null)return 'null';if(Array.isArray(v))return '['+v.map(canonical).join(',')+']';if(typeof v==='object')return '{'+Object.keys(v).sort().map(k=>quote(k)+':'+canonical(v[k])).join(',')+'}';if(typeof v==='number')return number(v);if(typeof v==='string')return quote(v);if(typeof v==='boolean')return JSON.stringify(v);throw new Error('Ogiltig JSON-typ.');}
  async function hash(text){const b=await crypto.subtle.digest('SHA-256',enc(text));return Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');}
  function marker(){const settings=JSON.parse(host().readStore('settings')||'{}');return settings[KEY]||null;}
  function setMarker(value){const settings=JSON.parse(host().readStore('settings')||'{}');if(value)settings[KEY]=value;else delete settings[KEY];if(host().writeStore('settings',JSON.stringify(settings))!==true)throw new Error('Återhämtningsstatus kunde inte sparas.');}
  function rows(category){const all=[];let cursor='';for(;;){const page=native('LIST',{category,cursor,limit:500});all.push(...page.records);if(!page.hasMore)return all;cursor=page.nextCursor;if(!cursor)throw new Error('Ogiltig paginering.');}}
  function exactAfter(ops){for(const op of ops){const r=native('GET',{category:op.category,recordId:op.recordId});if(op.type==='DELETE'?r.found:r.found!==true||canonical(r.payload)!==canonical(op.payload))return false;}return true;}
  function frames(operationId,ops,transitionOperationId){const out=[];let part=[];const make=items=>({operation:'STAGED_ATOMIC_APPEND',operationId,partIndex:out.length,operations:items,...(transitionOperationId?{transitionOperationId}:{})});for(const op of ops){if(enc(canonical(op)).length>65536)throw new Error('stage_row_too_large');const trial=[...part,op];if(part.length&&(trial.length>128||Math.max(enc(canonical(make(trial))).length,enc(JSON.stringify(make(trial))).length)>100000)){out.push(make(part));part=[];}part.push(op);}if(part.length)out.push(make(part));return out;}
  async function storeIntent(intent){const contentUtf8=JSON.stringify(intent),bytes=enc(contentUtf8);if(bytes.length>32*1024*1024)throw new Error('Recoveryunderlaget är för stort.');const transferId=intent.begin.operationId;stage('CREATE',{transferId});const digest=await hash(contentUtf8);stage('PUT_PART',{transferId,partId:'intent',contentUtf8,expectedBytes:bytes.length,expectedSha256:digest});const check=stage('READ_PART',{transferId,partId:'intent'});if(check.sha256!==digest||check.contentUtf8!==contentUtf8)throw new Error('Recoveryunderlaget kunde inte verifieras.');setMarker({owner:OWNER,transferId,sha256:digest});pending=true;}
  async function loadIntent(){const m=marker();if(!m)return null;if(m.owner!==OWNER)throw new Error('Återhämtning kräver rätt funktionsversion.');const r=stage('READ_PART',{transferId:m.transferId,partId:'intent'});if(r.sha256!==m.sha256||await hash(r.contentUtf8)!==m.sha256)throw new Error('Recoveryunderlaget är skadat.');const intent=JSON.parse(r.contentUtf8);if(intent.owner!==OWNER||intent.begin.operationId!==m.transferId)throw new Error('Fel recoveryägare.');return intent;}
  function clearIntent(intent){setMarker(null);pending=false;try{stage('DELETE_TRANSFER',{transferId:intent.begin.operationId});}catch(_){/* Committed data is verified. Orphan cleanup is not business success. */}}
  async function execute(intent){
    const parts=frames(intent.begin.operationId,intent.operations,intent.begin.transitionOperationId);
    const id=intent.begin.operationId,scope=intent.begin.transitionOperationId?{transitionOperationId:intent.begin.transitionOperationId}:{};
    let state=request('STAGED_ATOMIC_BEGIN',Object.fromEntries(Object.entries(intent.begin).filter(([k])=>k!=='operation')));
    if(state.planSha256!==intent.begin.planSha256)throw new Error('Recoveryplanen stämmer inte med Host.');
    if(state.state==='ABORTED')throw new Error('Operationen är avbruten; inga nya skrivningar görs.');
    if(state.state!=='COMMITTED'){
      for(let i=state.nextPart;i<parts.length;i++){const f=parts[i];state=request(f.operation,Object.fromEntries(Object.entries(f).filter(([k])=>k!=='operation')));await new Promise(r=>window.setTimeout(r,0));}
      // No acceptance/QUEUED/RUNNING response is treated as success.
      state=request('STAGED_ATOMIC_COMMIT',{operationId:id,...scope});
      while(state.state!=='COMMITTED'){
        if(state.commitState==='FAILED')throw new Error(`Commit misslyckades: ${state.code||'retry_same_operation'}`);
        await new Promise(r=>window.setTimeout(r,50));state=request('STAGED_ATOMIC_STATUS',{operationId:id,...scope});
      }
    }
    if(!exactAfter(intent.operations))throw new Error('Data efter commit kunde inte verifieras.');
    clearIntent(intent);return true;
  }
  async function mutate(desired){
    if(busy||pending||marker())throw new Error('En lagringsoperation behöver slutföras först.');busy=true;
    try{
      const snapshot=request('STAGED_ATOMIC_SNAPSHOT'),operations=[];
      for(const category of Object.keys(desired)){
        if(!CATS.includes(category))throw new Error('Otillåten atomisk kategori.');
        const current=new Map(rows(category).map(r=>[r.id,r.payload])),next=new Map();
        for(const r of desired[category]){if(next.has(r.id))throw new Error('Dubblett-ID.');next.set(r.id,copy(r.payload));}
        for(const id of new Set([...current.keys(),...next.keys()])){
          if(current.has(id)&&next.has(id)&&canonical(current.get(id))===canonical(next.get(id)))continue;
          const actual=native('GET',{category,recordId:id});
          if(actual.found!==current.has(id)||(actual.found&&canonical(actual.payload)!==canonical(current.get(id))))throw new Error('Data har ändrats. Läs om innan nytt försök.');
          const op={type:next.has(id)?'PUT':'DELETE',category,recordId:id,expectedPayloadSha256:actual.found?actual.payloadSha256:'absent'};if(next.has(id))op.payload=next.get(id);operations.push(op);
        }
      }
      if(!operations.length)return true;
      if(operations.length>16384)throw new Error('stage_plan_too_large');
      const operationId='p194-'+Date.now().toString(36)+'-'+Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
      const plan=operations.map(o=>canonical(o)+'\n').join('');if(enc(plan).length>16777216)throw new Error('stage_plan_too_large');
      const intent={owner:OWNER,operations,begin:{operation:'STAGED_ATOMIC_BEGIN',operationId,mutationCount:operations.length,planBytes:enc(plan).length,planSha256:await hash(plan),categorySha256:snapshot.categorySha256}};
      frames(operationId,operations);await storeIntent(intent);return await execute(intent);
    }finally{busy=false;}
  }
  async function recoverBeforeReady(){
    const intent=await loadIntent();if(!intent)return true;
    try{return await recover();}catch(error){
      if(error.code!=='ready_required')throw error;
      // Host has no OPEN plan. A completed plan or a not-yet-started intent is
      // safe to audit/resume after READY, before any application interaction.
      const before=intent.operations.every(op=>{const r=native('GET',{category:op.category,recordId:op.recordId});return (r.found?r.payloadSha256:'absent')===op.expectedPayloadSha256;});
      if(!before&&!exactAfter(intent.operations))throw new Error('Återhämtningsdata saknar ett verifierat före- eller efterläge.');
      return false;
    }
  }
  async function recover(){if(busy)throw new Error('Lagringen är upptagen.');busy=true;try{const intent=await loadIntent();if(!intent){pending=false;return true;}pending=true;return await execute(intent);}finally{busy=false;}}
  window.StadslassDataTransactions=Object.freeze({KEY,canonical,mutate,recover,recoverBeforeReady,hasPending:()=>pending||Boolean(marker()),isBusy:()=>busy,request});
})();
