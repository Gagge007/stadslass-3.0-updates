(() => {
  'use strict';

  const MAX_EVENTS = 40;
  const MAX_DETAIL = 1200;
  const state = {
    schemaVersion: 1,
    packageVersion: 167,
    moduleId: 'stadslass.core-mail-sync-reader',
    startedAt: new Date().toISOString(),
    status: 'starting',
    lastPhase: 'runtime.script.loaded',
    host: {},
    storage: {},
    events: []
  };
  let fatalRendered = false;

  function safeText(value, maximum = MAX_DETAIL) {
    const text = value == null ? '' : String(value).trim();
    return text.length > maximum ? text.slice(0, maximum) : text;
  }

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function hostStep(phase, detail, severity) {
    try {
      if (bridgeAvailable() && typeof window.StadslassHost.watchdogStep === 'function') {
        window.StadslassHost.watchdogStep(phase, detail, severity);
      }
    } catch (_) {
      // Watchdog diagnostics must never create a second application error.
    }
  }

  function step(phase, detail = '', severity = 'info') {
    const normalizedSeverity = severity === 'fatal'
      ? 'fatal'
      : (severity === 'warning' ? 'warning' : 'info');
    const event = {
      at: new Date().toISOString(),
      phase: safeText(phase, 120) || 'runtime.unknown',
      severity: normalizedSeverity,
      detail: safeText(detail)
    };
    state.events.push(event);
    if (state.events.length > MAX_EVENTS) {
      state.events.splice(0, state.events.length - MAX_EVENTS);
    }
    state.lastPhase = event.phase;
    if (state.host && typeof state.host === 'object' && Object.keys(state.host).length > 0) {
      const label = state.status === 'ready' ? 'Redo' : (state.status === 'failed' ? 'Fel' : 'Startar');
      state.host.watchdogStatus = `${label} · ${event.phase}`;
    }
    if (normalizedSeverity === 'fatal') {
      state.status = 'failed';
    } else if (normalizedSeverity === 'warning' && state.status === 'starting') {
      state.status = 'degraded';
    }
    hostStep(event.phase, event.detail, normalizedSeverity);
    return event;
  }

  function setContext(hostInfo) {
    const value = hostInfo && typeof hostInfo === 'object' ? hostInfo : {};
    state.host = {
      hostVersionCode: Number(value.hostVersionCode) || 0,
      hostVersionName: safeText(value.hostVersionName, 120),
      packageVersion: Number(value.packageVersion) || 0,
      moduleId: safeText(value.moduleId, 160),
      role: safeText(value.role, 80),
      roleLabel: safeText(value.roleLabel, 120),
      deviceId: safeText(value.deviceId, 200),
      storageApiVersion: Number(value.storageApiVersion) || 0,
      nativeStorageApiVersion: Number(value.nativeStorageApiVersion) || 0,
      storageSchemaVersion: Number(value.storageSchemaVersion) || 0,
      stagingApiVersion: Number(value.stagingApiVersion) || 0,
      watchdogApiVersion: Number(value.watchdogApiVersion) || 0,
      watchdogStatus: safeText(value.watchdogStatus, 300)
    };
    step('runtime.host-context.validated', 'Värd-, roll- och API-kontrakt lästes.');
  }


  function setStorageDiagnostics(value) {
    const source = value && typeof value === 'object' ? value : {};
    const migration = source.migration && typeof source.migration === 'object' ? source.migration : {};
    const migrationSafe = {};
    Object.keys(migration).forEach((category) => {
      const item = migration[category] && typeof migration[category] === 'object' ? migration[category] : {};
      migrationSafe[category] = {
        status: safeText(item.status, 80),
        step: safeText(item.step, 120),
        before: Number(item.before) || 0,
        expected: Number(item.expected) || 0,
        after: Number(item.after) || 0,
        legacySourceRetained: item.legacySourceRetained === true,
        error: safeText(item.error, 500),
        updatedAt: safeText(item.updatedAt, 80)
      };
    });
    const staging = source.staging && typeof source.staging === 'object' ? source.staging : {};
    state.storage = {
      adapterStatus: safeText(source.adapterStatus, 80),
      nativeStorageApiVersion: Number(source.nativeStorageApiVersion) || 0,
      storageSchemaVersion: Number(source.storageSchemaVersion) || 0,
      stagingApiVersion: Number(source.stagingApiVersion) || 0,
      syncPausedByMigration: source.syncPausedByMigration === true,
      syncReactivatedAt: safeText(source.syncReactivatedAt, 80),
      migration: migrationSafe,
      nativeCategories: Array.isArray(source.nativeCategories) ? source.nativeCategories.map((row) => ({
        category: safeText(row && row.category, 80),
        recordCount: Number(row && row.recordCount) || 0,
        payloadBytes: Number(row && row.payloadBytes) || 0,
        sha256: safeText(row && row.sha256, 80)
      })) : [],
      staging: {
        transfers: Array.isArray(staging.transfers) ? staging.transfers.map((row) => ({
          transferId: safeText(row && row.transferId, 160),
          expectedPartCount: Number(row && row.expectedPartCount) || 0,
          receivedPartCount: Number(row && (row.receivedPartCount ?? row.partCount)) || 0,
          totalRecordCount: Number(row && row.totalRecordCount) || 0,
          totalBytes: Number(row && row.totalBytes) || 0,
          integrityStatus: safeText(row && row.integrityStatus, 80)
        })) : [],
        lastError: staging.lastError && typeof staging.lastError === 'object' ? {
          code: safeText(staging.lastError.code, 100),
          step: safeText(staging.lastError.step, 120),
          message: safeText(staging.lastError.message, 500),
          at: safeText(staging.lastError.at, 80)
        } : null
      },
      lastError: source.lastError && typeof source.lastError === 'object' ? {
        message: safeText(source.lastError.message, 500),
        category: safeText(source.lastError.category, 80),
        step: safeText(source.lastError.step, 120)
      } : null
    };
    step('runtime.native-storage.status', `Native storage: ${state.storage.adapterStatus || 'okänd'}.`);
  }

  function ready() {
    state.status = 'ready';
    state.readyAt = new Date().toISOString();
    step('runtime.ready', 'P158 är redo med verifierad Host24 native lagring/staging; verksamhetsdrift startar efter avslutad lokal migration.');
  }

  function reportText() {
    const report = {
      title: 'Stadslass 3.0 runtime-Watchdog',
      generatedAt: new Date().toISOString(),
      ...state
    };
    return JSON.stringify(report, null, 2);
  }

  function copyReport(statusElement) {
    try {
      if (!bridgeAvailable() || typeof window.StadslassHost.copyWatchdogReport !== 'function') {
        throw new Error('Värdappens kopieringsbrygga saknas.');
      }
      const accepted = window.StadslassHost.copyWatchdogReport(reportText());
      if (statusElement) {
        statusElement.textContent = accepted
          ? 'Watchdog-rapporten skickades till urklipp.'
          : 'Watchdog-rapporten kunde inte kopieras.';
        statusElement.classList.toggle('is-error', !accepted);
      }
      return accepted === true;
    } catch (error) {
      if (statusElement) {
        statusElement.textContent = safeText(error && error.message) || 'Watchdog-rapporten kunde inte kopieras.';
        statusElement.classList.add('is-error');
      }
      return false;
    }
  }

  function createButton(text, className, handler) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = text;
    button.addEventListener('click', handler);
    return button;
  }

  function renderFailure(error, phase = 'runtime.fatal') {
    if (fatalRendered) return;
    fatalRendered = true;
    const message = safeText(error && error.message ? error.message : error) || 'Okänt runtimefel.';
    step(phase, message, 'fatal');
    try {
      window.dispatchEvent(new CustomEvent('stadslass-runtime-fatal', {
        detail: Object.freeze({ phase: safeText(phase, 120), message })
      }));
    } catch (_) {
      // Runtime disposal must not obscure the original failure.
    }

    const main = document.createElement('main');
    main.className = 'content watchdog-failure-page';
    const article = document.createElement('article');
    article.className = 'section-card watchdog-failure-card';
    const kicker = document.createElement('p');
    kicker.className = 'eyebrow';
    kicker.textContent = 'Watchdog stoppade modulstarten';
    const heading = document.createElement('h1');
    heading.textContent = 'Stadslass kunde inte starta säkert';
    const body = document.createElement('p');
    body.textContent = message;
    const note = document.createElement('p');
    note.className = 'boundary-text';
    note.textContent = 'Watchdog har inte reparerat, raderat eller skrivit om kö, aktivt jobb, historik, inställningar eller synkutkö.';
    const status = document.createElement('p');
    status.className = 'form-status';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');

    const copyButton = createButton('Kopiera Watchdog-rapport', 'primary-button', () => copyReport(status));
    const hostButton = createButton('Öppna värdappens kontrollsida', 'secondary-button', () => {
      try {
        window.StadslassHost.showHostControl();
      } catch (hostError) {
        status.textContent = safeText(hostError && hostError.message) || 'Kontrollsidan kunde inte öppnas.';
        status.classList.add('is-error');
      }
    });

    article.append(kicker, heading, body, note, copyButton, hostButton, status);
    main.appendChild(article);
    document.body.replaceChildren(main);
  }

  window.addEventListener('error', (event) => {
    const message = event && event.error && event.error.message
      ? event.error.message
      : (event && event.message ? event.message : 'Ohanterat JavaScript-fel.');
    const location = event && event.filename
      ? ` (${safeText(event.filename, 240)}:${Number(event.lineno) || 0}:${Number(event.colno) || 0})`
      : '';
    renderFailure(new Error(`${message}${location}`), 'runtime.window.error');
  });

  window.addEventListener('unhandledrejection', (event) => {
    const reason = event && event.reason;
    const detail = reason && reason.message ? reason.message : safeText(reason) || 'Avvisat Promise utan felhantering.';
    renderFailure(new Error(detail), 'runtime.promise.unhandled');
  });

  step('runtime.script.loaded', 'Runtime-Watchdog är installerad före appkoden.');

  window.StadslassWatchdog = Object.freeze({
    step,
    setContext,
    setStorageDiagnostics,
    ready,
    fail: renderFailure,
    reportText,
    copyReport,
    getStatus: () => state.status,
    getLastPhase: () => state.lastPhase,
    isFailed: () => state.status === 'failed'
  });
})();
