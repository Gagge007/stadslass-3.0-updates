(() => {
  'use strict';
  const TYPE = 'stadslass-readonly-history-archive';
  const ALLOWED_PHASES = Object.freeze(['loading', 'unloading', 'return_unloading']);
  const TEMP_IDS = Object.freeze(['SYS-TEMPORARY-FROM', 'SYS-TEMPORARY-DESTINATION']);
  let cached = null;
  let pending = null;
  const clone = value => JSON.parse(JSON.stringify(value));
  const freezeRecords = records => Object.freeze(records.map(record => Object.freeze({ ...clone(record), archiveReadOnly: true })));
  function validate(value) {
    if (!value || value.schemaVersion !== 1 || value.archiveType !== TYPE || value.readOnly !== true || !Array.isArray(value.records)) throw new Error('Historikarkivet har fel format.');
    if (value.records.length !== 242) throw new Error('Historikarkivet har fel antal poster.');
    if (value.records.some(record => !record || record.archiveReadOnly !== true || record.source !== 'history-archive-v419')) throw new Error('Historikarkivet innehåller en skrivbar eller okänd post.');
    return value;
  }
  async function load(url = 'data/historikarkiv.json') {
    if (cached) return cached;
    if (pending) return pending;
    pending = fetch(url, { cache: 'no-store', credentials: 'same-origin' }).then(response => { if (!response.ok) throw new Error(`Historikarkivet kunde inte läsas (${response.status}).`); return response.json(); }).then(value => {
      const source = validate(value);
      cached = Object.freeze({ metadata: Object.freeze(clone(source.validation || {})), records: freezeRecords(source.records), learningPolicy: Object.freeze(clone(source.learningPolicy || {})) });
      return cached;
    }).finally(() => { pending = null; });
    return pending;
  }
  function records() { return cached ? cached.records : Object.freeze([]); }
  function learningRecords() {
    return records().map(record => Object.freeze({ ...record,
      p121Learning: Object.freeze({ schemaVersion: 1, samples: Object.freeze(((record.p121Learning && record.p121Learning.samples) || []).filter(sample => ALLOWED_PHASES.includes(sample.phase) && !TEMP_IDS.includes(sample.placeId) && Number(sample.sourceDurationMs) >= 30000 && Number(sample.sourceDurationMs) <= 10800000).map(sample => Object.freeze({ ...sample }))) })
    }));
  }
  function combined(localRecords) { return Object.freeze([...(Array.isArray(localRecords) ? localRecords : []), ...records()]); }
  function isReadOnly(record) { return Boolean(record && record.archiveReadOnly === true && record.source === 'history-archive-v419'); }
  window.StadslassHistoryArchive = Object.freeze({ TYPE, ALLOWED_PHASES, TEMP_IDS, validate, load, records, learningRecords, combined, isReadOnly });
})();
