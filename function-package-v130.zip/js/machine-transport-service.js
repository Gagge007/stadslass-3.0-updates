(() => {
  'use strict';
  const text = value => typeof value === 'string' ? value.trim() : '';
  const number = value => { const n = Number(value); return Number.isFinite(n) && n > 0 ? n : null; };
  function create(options = {}) {
    const machine = options.machine && typeof options.machine === 'object' ? options.machine : null;
    const mode = machine ? 'registry' : 'other';
    const hasMachineBed = options.hasMachineBed === true;
    return Object.freeze({ schemaVersion: 2, mode, hasMachineBed, machineBedPickupRequired: !hasMachineBed,
      machineBedPickupPlaceId: text(options.pickupPlace && options.pickupPlace.id), machineBedPickupPlaceName: text(options.pickupPlace && options.pickupPlace.name), machineBedVisitedAt: '',
      direction: ['to_workshop','from_workshop'].includes(options.direction) ? options.direction : '', workshopPlaceId: text(options.workshop && options.workshop.id), workshopPlaceName: text(options.workshop && options.workshop.name),
      effectiveWeight: number(options.effectiveWeight), weightOverriddenForJob: options.weightOverriddenForJob === true });
  }
  function route(state, basePlace) { const workshop={id:text(state&&state.workshopPlaceId),name:text(state&&state.workshopPlaceName)}; return state&&state.direction==='to_workshop'?{from:basePlace,to:workshop}:state&&state.direction==='from_workshop'?{from:workshop,to:basePlace}:null; }
  function preStageActive(job) { const state=job&&job.machineTransport; return Boolean(state&&state.machineBedPickupRequired===true&&(!text(state.machineBedVisitedAt)||state.machineBedPickupInside===true)&&text(job.phase)==='start_route'); }
  function routeTarget(job) { const state=job&&job.machineTransport; return preStageActive(job)?{id:text(state.machineBedPickupPlaceId),name:text(state.machineBedPickupPlaceName)}:null; }
  function observePickup(job, direction, at) { const state=job&&job.machineTransport; if(!state||!state.machineBedPickupRequired)return job; const inside=direction==='ENTER'; return {...job,machineTransport:{...state,machineBedVisitedAt:inside?(text(state.machineBedVisitedAt)||text(at)||new Date().toISOString()):text(state.machineBedVisitedAt),machineBedPickupInside:inside}}; }
  function effectiveWeight(job) { return number(job&&job.machineTransport&&job.machineTransport.effectiveWeight); }
  function automaticWeightReady(job) { return Boolean(effectiveWeight(job)&&Array.isArray(job&&job.weightEntries)&&job.weightEntries.some(entry=>entry&&entry.source==='machine-auto'&&Number(entry.weight)>0)); }
  window.StadslassMachineTransport = Object.freeze({ create, route, preStageActive, routeTarget, observePickup, effectiveWeight, automaticWeightReady });
})();
