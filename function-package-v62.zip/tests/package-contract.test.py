#!/usr/bin/env python3
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_BASE_SHA256 = '78c6e2d273b74ff71e0e6c391369a76c23a9032df367d70e5ac11bfc70a49255'


def load_json(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))


def require(condition, message):
    if not condition:
        raise AssertionError(message)


module = load_json('module.json')
functions = load_json('data/functions.json')
schema = load_json('data/job-schema.json')
versions = load_json('data/version-history.json')
html = (ROOT / 'index.html').read_text(encoding='utf-8')
app = (ROOT / 'js/app.js').read_text(encoding='utf-8')
ata = (ROOT / 'js/ata/ata-service.js').read_text(encoding='utf-8')
billing = (ROOT / 'js/ata/billing-service.js').read_text(encoding='utf-8')
mail = (ROOT / 'js/ata/mail-underlag-service.js').read_text(encoding='utf-8')
watchdog = (ROOT / 'js/watchdog.js').read_text(encoding='utf-8')
job_model = (ROOT / 'js/job-model.js').read_text(encoding='utf-8')
quick_choices = (ROOT / 'js/quick-choice-registry.js').read_text(encoding='utf-8')
css = (ROOT / 'css/app.css').read_text(encoding='utf-8')

require(module['packageVersion'] == 62, 'module.json packageVersion must be 62')
require(module['minHostVersionCode'] == 11, 'host minimum must be 11')
require(functions['currentPackageVersion'] == 62, 'functions current package must be 62')
require(functions['version'] == '3.0-function-package-62', 'functions version label must be 62')
require(versions['currentPackageVersion'] == 62, 'version history current package must be 62')
require(versions['entries'][0]['packageVersion'] == 62, 'version 62 must be first')
require(versions['entries'][0].get('basePackageSha256') == EXPECTED_BASE_SHA256, 'v61 base SHA must be recorded')

for name, source in {
    'app.js': app,
    'ata-service.js': ata,
    'billing-service.js': billing,
    'mail-underlag-service.js': mail,
    'watchdog.js': watchdog,
    'job-model.js': job_model,
    'quick-choice-registry.js': quick_choices,
    'ata-routing-service.js': (ROOT / 'js/ata/ata-routing-service.js').read_text(encoding='utf-8'),
    'notification-settings-service.js': (ROOT / 'js/ata/notification-settings-service.js').read_text(encoding='utf-8'),
}.items():
    require(re.search(r'(?:PACKAGE_VERSION\s*=|packageVersion\s*:)\s*62', source) is not None,
            f'{name} must expose runtime version 62')

required_function_ids = {
    'ATA-BILLING-MODULE-056', 'ATA-BILLING-COMPLETION-DIALOG-056', 'ATA-BILLING-TOTAL-056',
    'ATA-BILLING-PHASES-056', 'ATA-BILLING-MANUAL-056', 'ATA-BILLING-HISTORY-DISPLAY-056',
    'ATA-BILLING-HISTORY-EDIT-056', 'ATA-BILLING-TRASH-PERSISTENCE-056', 'RUNTIME-PACKAGE-VERSION-056',
    'ATA-NOTIFICATION-SETTINGS-057', 'ATA-NOTIFICATION-CONTACT-IDENTITY-057', 'ATA-NOTIFICATION-TEMPLATE-057',
    'ATA-NOTIFICATION-EMAIL-LAYOUT-058', 'ATA-NOTIFICATION-DUPLICATE-WARNING-058',
    'ATA-NOTIFICATION-CONTACTS-NO-ACTIVE-058', 'RUNTIME-PACKAGE-VERSION-058',
    'ATA-JOBTYPE-STABLE-ID-059', 'ATA-MANUAL-JT1014-059', 'ATA-RECIPIENT-SNAPSHOT-059',
    'ATA-SYNC-RECIPIENT-059', 'ATA-QUICKCHOICE-MIGRATION-059', 'RUNTIME-PACKAGE-VERSION-059',
    'ATA-MAIL-COMPLETION-060', 'ATA-MAIL-TODAY-060', 'ATA-MAIL-DAILY-060',
    'ATA-MAIL-HISTORY-060', 'ATA-MAIL-HOST-CONTRACT-060', 'RUNTIME-PACKAGE-VERSION-060',
    'ACTIVE-OPERATIVE-HELP-TEXT-061', 'ATA-RECIPIENT-PRESENTATION-061', 'RUNTIME-PACKAGE-VERSION-061',
    'ATA-MAIL-ADDRESS-DEDUPE-062', 'ATA-MAIL-BODY-MODEL-062', 'ATA-MAIL-AFTER-OPEN-062',
    'ATA-BILLING-CHOICE-CARDS-062', 'RUNTIME-PACKAGE-VERSION-062',
}
ids = {item.get('id') for item in functions.get('functions', [])}
require(required_function_ids <= ids, 'required package 56-62 functions must be registered')

for report_path in [
    'reports/build-decision.json', 'reports/error-state-report.json', 'reports/migration-report.json',
    'reports/regression-report.json', 'reports/technical-test-report.json'
]:
    report = load_json(report_path)
    require(report.get('packageVersion') == 62, f'{report_path} must show package 62')
    require(str(report.get('status', '')).startswith('PASS'), f'{report_path} must be PASS')

billing_schema = schema.get('ata', {}).get('fields', {}).get('billing', {})
require(billing_schema.get('schemaVersion') == '1', 'billing schema must remain registered inside ATA')
require(schema.get('ata', {}).get('billableTime', {}).get('separateFromWorkTime') is True,
        'billing must remain separate from work time')

# New package 62 billing controls are semantic buttons and old duplicate buttons are gone.
for element_id in [
    'ata-billing-dialog', 'ata-billing-manual-minutes', 'ata-billing-save-manual',
    'ata-billing-total-choice', 'ata-billing-phase-choice', 'ata-billing-cancel',
    'ata-billing-round-step', 'ata-billing-round-actions',
]:
    require(f'id="{element_id}"' in html, f'missing UI element {element_id}')
require('id="ata-billing-use-phases"' not in html, 'old phase billing button must be removed')
require('id="ata-billing-use-total"' not in html, 'old total billing button must be removed')
require(re.search(r'<button[^>]+id="ata-billing-total-choice"', html) is not None, 'total choice must be button')
require(re.search(r'<button[^>]+id="ata-billing-phase-choice"', html) is not None, 'phase choice must be button')
require('billing-information-card' in html and 'Minsta debiterbara tid' in html, 'minimum time must remain information')
require("byId('ata-billing-total-choice').addEventListener('click', useAtaBillingTotal)" in app,
        'total card must reuse total billing logic')
require("const firstChoice = byId('ata-billing-total-choice');" in app,
        'billing dialog must focus the first time choice instead of opening the manual keyboard')
require("byId('ata-billing-phase-choice').addEventListener('click', showAtaBillingPhaseRoundStep)" in app,
        'phase card must reuse phase rounding logic')
require("phaseChoice.disabled = true" in app and 'Kan inte beräknas – totaltid används' in app,
        'missing phase times must disable phase choice')

# Existing calculations remain the source of truth.
require('parseCompletionManual' in billing and 'MINIMUM_MINUTES = 30' in billing,
        'manual completion minimum must remain 30 minutes')
require('Math.ceil(source / MINIMUM_MINUTES)' in billing, 'total time must round upward')
require("new Set(['loading', 'transport', 'unloading'])" in billing,
        'phase basis must include loading, transport and unloading')
for excluded in ['start_route', 'return_unloading', 'ready_to_complete']:
    require(excluded not in re.search(r"const INCLUDED_PHASES = .*", billing).group(0),
            f'{excluded} must not be a base included phase')
require('finalizeActiveCompletion(selectedAtaBillingSnapshot' in app,
        'new UI must continue through the shared completion function')
require('Aktivt jobb och vald debiterbar tid är bevarade' in app,
        'history write failure must preserve active job and billing')

# Mail is separated into metadata and one body truth.
require('id="ata-mail-recipient"' in html and 'id="ata-mail-subject"' in html,
        'recipient and subject metadata elements must exist')
require('id="ata-mail-preview"' in html, 'body preview must exist')
require('preview: mailBody' in mail, 'service preview compatibility value must be body only')
require('preview: `Till:' not in mail and 'preview: `Ämne:' not in mail,
        'mail service must not build a combined mail header/body preview')
require("byId('ata-mail-preview').textContent = context.underlag.body" in app,
        'dialog must preview body only')
require("byId('ata-mail-subject').textContent = `Ämne: ${context.underlag.subject}`" in app,
        'subject must be rendered separately')
require("hostCopyText('ÄTA-underlag', context.underlag.body)" in app,
        'automatic reserve copy must use body only')
require("context.underlag.body);\n      // Kopiering" in app,
        'manual copy must use body only')
require('openEmailDraft' in app and 'copyText' in app, 'host-based mail and copy operations must be used')
require('mailto:' not in app + mail, 'module must not create raw mailto navigation')
require('Gmail' not in app + mail, 'module must not target Gmail')
require('Mail skickat' not in app + mail and 'Levererat' not in app + mail,
        'mail status must not claim delivery')
require('Klar – fortsätt i Stadslass' in app, 'safe after-open button must be present')
require('context.draftOpened === true' in app, 'after-open state must be tracked in dialog context')
require('skipButton.hidden = historical || daily || opened' in app,
        'skip must be removed after the draft opens')
require('Kopiering är en reservåtgärd och får inte ändra uppdragets mailstatus' in app,
        'copy must not mutate mail status')
require('context.draftOpened === true || context.mode' in app,
        'skip handler must reject after-open activation')
require('no_mail_app' in app and 'invalid_request' in app and 'host_error' not in app,
        'known host errors must be handled without inventing a sent status')

# Strict presentation-only address comparison.
require('function comparisonText(value)' in mail, 'address comparison normalizer missing')
require('function addressAddsInformation(placeValue, addressValue)' in mail, 'address difference helper missing')
require("placeText !== addressText" in mail, 'address hiding must require full normalized equality')
require("line(lines, 'Från adress'" in mail and "line(lines, 'Till adress'" in mail,
        'different physical addresses must still be supported')
require('writeStore' not in mail and 'readStore' not in mail,
        'mail formatter must not own or rewrite storage')

# Package 55/61 protections remain.
require('settings-history-panel' in app and 'settings-trash-panel' in app, 'current settings panels must remain used')
require("byId('view-trash').hidden" not in app and "byId('view-statistics').hidden" not in app,
        'obsolete unsafe view accesses must not return')
require('runtimeDisposed' in app and 'runtimeFailed' in app, 'runtime disposal guards must remain')
require('active-ata-recipient-display' not in html and 'active-ata-recipient-display' not in app,
        'active job recipient display must remain removed')
require('Aktivt jobb kan användas på denna enhet.' not in app, 'obsolete active role text must remain removed')
require('Uppdraget startades från 189:s operativa kö.' not in app, 'obsolete queue-start text must remain removed')
require(html.count('id="active-phase-action"') == 1 and html.count('id="active-pause-action"') == 1
        and html.count('id="active-complete-request"') == 1,
        'exact three active-job controls must remain')

# Shared recipient identity and settings remain.
notification = (ROOT / 'js/ata/notification-settings-service.js').read_text(encoding='utf-8')
require("SETTINGS_KEY = 'ataNotificationSettingsV1'" in notification,
        'notification settings must use the shared settings document key')
require('recipientListLabel' in notification and 'recipientQueueLabel' in notification,
        'shared recipient presentation helpers missing')
require('`${contact.name} · ${contact.email}`' not in app,
        'recipient select options must not expose email')
require('ata-notification-contact-active' not in html and 'setContactActive' not in notification,
        'active/inactive contact function must remain removed')
require('JT-1014' in app and 'JT-1001' in app, 'manual and other-activity IDs must remain distinct')

# No parallel store or activation of the v11 sync transport bridge.
store_constants = set(re.findall(r"const\s+[A-Z_]+_STORE\s*=\s*'([^']+)'", app))
require(store_constants == {'settings', 'queue', 'activeJob', 'history', 'syncOutbox'},
        f'unexpected store introduced: {sorted(store_constants)}')
require('enqueueSyncRequest' not in app and 'setSyncConfiguration' not in app,
        'package 62 must not activate startapp v11 sync transport')
require('readStore' not in billing and 'writeStore' not in billing,
        'billing service must not own storage')

# Host contract and CSP.
require('const MINIMUM_HOST_VERSION = 11;' in app, 'runtime host minimum must be 11')
require('Startapp v11 krävs' in app, 'runtime must clearly require startapp v11')
require('emailDraftApiVersion' in app and 'clipboardApiVersion' in app,
        'mail/clipboard API versions must be required')
require("default-src 'none'" in html and "script-src 'self'" in html
        and "connect-src https://maps.googleapis.com" in html,
        'strict CSP must remain in shipped HTML')
require('billing-choice-button' in css and '.billing-choice-button:disabled' in css,
        'active and disabled billing card styling must exist')

# Manifest covers the exact finished payload except module.json itself.
manifest_entries = {entry['path']: entry for entry in module.get('files', [])}
actual_files = {
    str(path.relative_to(ROOT)).replace('\\', '/')
    for path in ROOT.rglob('*')
    if path.is_file() and path.name != 'module.json' and '__pycache__' not in path.parts and path.suffix != '.pyc'
}
require(set(manifest_entries) == actual_files,
        f'manifest file set differs: missing={sorted(actual_files-set(manifest_entries))}, extra={sorted(set(manifest_entries)-actual_files)}')
for relative, entry in manifest_entries.items():
    payload = (ROOT / relative).read_bytes()
    require(entry.get('size') == len(payload), f'manifest size mismatch for {relative}')
    require(entry.get('sha256') == hashlib.sha256(payload).hexdigest(), f'manifest hash mismatch for {relative}')

# No private material, real user addresses, or local build paths.
private_marker = 'BEGIN ' + 'PRIVATE KEY'
rsa_private_marker = 'BEGIN RSA ' + 'PRIVATE KEY'
local_build_prefix = '/mnt' + '/data/'
real_user_email = 'andreas.skyttman' + '@' + 'gmail.com'
for path in ROOT.rglob('*'):
    if not path.is_file():
        continue
    require(path.suffix.lower() not in {'.pem', '.key', '.p12', '.pfx'}, f'private key-like file included: {path.name}')
    if path.suffix.lower() in {'.js', '.json', '.html', '.css', '.py', '.txt'}:
        value = path.read_text(encoding='utf-8', errors='ignore')
        require(private_marker not in value and rsa_private_marker not in value,
                f'private key content included in {path.relative_to(ROOT)}')
        require(local_build_prefix not in value, f'local build path included in {path.relative_to(ROOT)}')
        require(real_user_email not in value.lower(),
                f'real user email included in {path.relative_to(ROOT)}')

print(json.dumps({
    'status': 'PASS',
    'packageVersion': 62,
    'minHostVersionCode': 11,
    'registeredFunctions': len(required_function_ids),
    'sourcePackageSha256': EXPECTED_BASE_SHA256,
    'storeNames': sorted(store_constants),
}, ensure_ascii=False))
