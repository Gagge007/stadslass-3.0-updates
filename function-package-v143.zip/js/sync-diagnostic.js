(() => {
  'use strict';
  const PACKAGE_VERSION = 143;
  const now = () => new Date().toISOString();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value).trim();
  const mask = (value, key = '') => {
    if (/token|authorization|password|secret|private|credential|cookie|api[-_]?key/i.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => mask(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name,item]) => [name, mask(item,name)]));
    if (typeof value === 'string') return value.replace(/github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9]+|AIza[0-9A-Za-z_-]{20,100}/g,'[MASKERAT]').slice(0,1000);
    return value;
  };
  function performanceSummary(performanceState = {}, diagnosticState = {}) {
    const events = Array.isArray(performanceState.events) ? performanceState.events : [];
    return { monitorActive: performanceState.active === true, performanceEvents: events.length, firstRoleViewAt: text(diagnosticState.firstRoleViewAt,'Saknas'), roleViewReached: Boolean(diagnosticState.firstRoleViewAt) };
  }
  function create(options = {}) {
    const contextProvider = typeof options.context === 'function' ? options.context : () => ({});
    const mailboxProvider = typeof options.mailboxState === 'function' ? options.mailboxState : () => ({});
    const state={startedAt:now(),firstRoleViewAt:'',inventoryFinishedAt:'',inventoryRunning:false,exportSequence:0,observed:0,events:[],counts:{}};
    const observe=(kind,details={})=>{state.events.push(mask({at:now(),kind:text(kind),...details}));if(state.events.length>50)state.events.shift();state.observed+=1;};
    const firstRoleView=(context={})=>{state.firstRoleViewAt=now();observe('role-view-ready',{role:text(context.role),syncInstalled:true});};
    function readCounts(){const m=mailboxProvider()||{};return {...(m.counts||{}),activeRequests:m.fetchBusy?1:0,automaticSyncRequests:0,legacySyncActivated:0,syncFunctionsInstalled:1};}
    function inventory(){state.inventoryRunning=true;try{state.counts=readCounts();state.inventoryFinishedAt=now();observe('mailbox-report-snapshot',{counts:state.counts});return{ok:true,status:'completed',counts:{...state.counts}};}finally{state.inventoryRunning=false;}}
    function snapshotReport(options={}){
      if(!state.inventoryFinishedAt) inventory();
      state.exportSequence+=1; const generatedAt=now(); const context=mask(contextProvider()||{}); const mailbox=mask(mailboxProvider()||{}); state.counts=readCounts();
      const c=state.counts; const reportId=text(options.reportId,`sync-mailbox-p142-${Date.now().toString(36)}`); const lines=[
        'STADSLASS SYNK-/POSTRAPPORT','Rapporttyp: Beställningsstyrd Sync P143',`Rapport-ID: ${reportId}`,`Genererad: ${generatedAt}`,'',
        'A. IDENTITET',`Värdapp: ${text(context.hostVersion,'Saknas')}`,`Funktionspaket: ${PACKAGE_VERSION}`,`Roll: ${text(context.role,'Saknas')}`,`Enhet: ${text(mailbox.currentUnitLabel,text(context.mailboxUnit,'Saknas'))}`,'',
        'B. LÄGE','Synkfunktion: Installerad – beställningsstyrd','Hämtning: Manuell','Automatisk hämtning: Avstängd','Bakgrundsaktivitet: Avstängd','Ny Mobil-kömarkering på 189: Stöds','Uppdragsnotis: notis.mp3',`Mailbox transport API: ${Number(context.mailboxTransportApiVersion)||0}`,'',
        'C. RÄKNARE',`Hämta post-körningar: ${Number(c.manualFetchRuns)||0}`,`Brev skapade: ${Number(c.lettersCreated)||0}`,`Brev lästa: ${Number(c.lettersRead)||0}`,`Receipts skapade: ${Number(c.receiptsCreated)||0}`,`Receipts mottagna: ${Number(c.receiptsReceived)||0}`,`Brev raderade: ${Number(c.lettersDeleted)||0}`,`Raderingsfel: ${Number(c.deletionErrors)||0}`,`Dubletter: ${Number(c.duplicates)||0}`,`Brevfel: ${Number(c.letterErrors)||0}`,'',
        'D. SENASTE REFERENSER',`Senaste brev-ID: ${text(mailbox.latestLetterId,'Saknas')}`,`Senaste GitHub-sökväg: ${text(mailbox.latestPath,'Saknas')}`,'',
        'E. GITHUB-KONFIGURATION',`Säker GitHub-konfiguration: ${context.githubConfiguration&&context.githubConfiguration.configured===true?'Sparad':'Ej verifierad'}`,`Ägare: ${text(context.githubConfiguration&&context.githubConfiguration.owner,'Saknas')}`,`Repository: ${text(context.githubConfiguration&&context.githubConfiguration.repository,'Saknas')}`,`Gren: ${text(context.githubConfiguration&&context.githubConfiguration.branch,'Saknas')}`,'Tokenvärde: MASKERAT / läses inte av rapporten','',
        'F. SENASTE 10 BREVHÄNDELSER'];
      (Array.isArray(mailbox.letterHistory)?mailbox.letterHistory:[]).slice(-10).forEach((item)=>lines.push(JSON.stringify(mask(item))));
      lines.push('','G. PAKETHÄNDELSER'); (Array.isArray(mailbox.packageHistory)&&mailbox.packageHistory.length?mailbox.packageHistory:['0 – pakethändelser saknas']).slice(-10).forEach((item)=>lines.push(typeof item==='string'?item:JSON.stringify(mask(item))));
      lines.push('','H. SÄKERHET','P143 använder beställningsstyrd brev-/pakettransport; uppdragspaket kan skickas manuellt Mobil → 189. Gul Kö-markering släcks när Kö öppnas och notis.mp3 tillåts som mediaresurs samt kan testas med fallback. Ingen automatisk hämtning används.','Den gamla syncOutbox-/terminaljournalmotorn används inte av P143.');
      return{reportType:'sync-verification',content:lines.join('\n'),reportId,generatedAt,exportSequence:state.exportSequence,eventCount:state.observed,counts:{...state.counts},performance:performanceSummary(options.performanceState||{},state)};
    }
    return Object.freeze({observe,inventory,firstRoleView,snapshotReport,report:(opts={})=>snapshotReport(opts).content,state:()=>mask({...state,counts:readCounts(),events:state.events.slice()})});
  }
  window.StadslassSyncDiagnostic=Object.freeze({PACKAGE_VERSION,create,performanceSummary});
})();
