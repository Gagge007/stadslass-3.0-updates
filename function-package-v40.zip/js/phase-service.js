(() => {
  'use strict';

  const MODEL_VERSION = 1;
  const PHASES = Object.freeze({
    START_ROUTE: 'start_route',
    LOADING: 'loading',
    TRANSPORT: 'transport',
    UNLOADING: 'unloading',
    RETURN_TRANSPORT: 'return_transport',
    RETURN_UNLOADING: 'return_unloading',
    READY_TO_COMPLETE: 'ready_to_complete',
    OTHER_ACTIVITY: 'other_activity'
  });
  const LABELS = Object.freeze({
    [PHASES.START_ROUTE]: 'Startsträcka',
    [PHASES.LOADING]: 'Lastning',
    [PHASES.TRANSPORT]: 'Transport',
    [PHASES.UNLOADING]: 'Lossning',
    [PHASES.RETURN_TRANSPORT]: 'Returtransport',
    [PHASES.RETURN_UNLOADING]: 'Returlossning',
    [PHASES.READY_TO_COMPLETE]: 'Redo att avslutas',
    [PHASES.OTHER_ACTIVITY]: 'Övrig verksamhet'
  });
  const LEGACY_PHASES = Object.freeze({
    returning: PHASES.RETURN_TRANSPORT,
    return_unloading: PHASES.RETURN_UNLOADING
  });
  const KNOWN_PHASES = Object.freeze(Object.values(PHASES));

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' && value.trim() ? value.trim() : fallback;
  }

  function normalizePhase(value, fallback = PHASES.LOADING) {
    const candidate = text(value);
    if (KNOWN_PHASES.includes(candidate)) return candidate;
    if (LEGACY_PHASES[candidate]) return LEGACY_PHASES[candidate];
    return fallback;
  }

  function isKnownPhase(value, allowLegacy = true) {
    const candidate = text(value);
    return KNOWN_PHASES.includes(candidate) || (allowLegacy && Boolean(LEGACY_PHASES[candidate]));
  }

  function label(value) {
    return LABELS[normalizePhase(value)] || LABELS[PHASES.LOADING];
  }

  function flow(returnRequired) {
    const common = [PHASES.START_ROUTE, PHASES.LOADING, PHASES.TRANSPORT, PHASES.UNLOADING];
    return Object.freeze(returnRequired === true
      ? [...common, PHASES.RETURN_TRANSPORT, PHASES.RETURN_UNLOADING, PHASES.READY_TO_COMPLETE]
      : [...common, PHASES.READY_TO_COMPLETE]);
  }

  function normalizeTimeline(value) {
    if (!Array.isArray(value)) return [];
    return value.filter(isPlainObject).map((entry) => {
      const phase = normalizePhase(entry.phase, '');
      if (!phase) return null;
      return {
        ...entry,
        phase,
        phaseCode: phase,
        displayName: label(phase),
        startedAt: text(entry.startedAt),
        endedAt: text(entry.endedAt),
        previousPhase: text(entry.previousPhase) ? normalizePhase(entry.previousPhase, text(entry.previousPhase)) : '',
        nextPhase: text(entry.nextPhase) ? normalizePhase(entry.nextPhase, text(entry.nextPhase)) : '',
        transitionReason: text(entry.transitionReason),
        source: text(entry.source)
      };
    }).filter(Boolean);
  }

  function normalizeTransitions(value) {
    if (!Array.isArray(value)) return [];
    return value.filter(isPlainObject).map((entry) => ({
      ...entry,
      fromPhase: text(entry.fromPhase) ? normalizePhase(entry.fromPhase, text(entry.fromPhase)) : '',
      toPhase: normalizePhase(entry.toPhase),
      at: text(entry.at),
      reason: text(entry.reason),
      source: text(entry.source)
    }));
  }

  function migrateRecord(value) {
    const source = isPlainObject(value) ? value : {};
    const hasPhase = text(source.phase) || text(source.phaseCode);
    if (!hasPhase) return source;
    const phase = normalizePhase(text(source.phaseCode, text(source.phase)));
    const timeline = normalizeTimeline(source.phaseTimeline);
    const transitions = normalizeTransitions(source.phaseTransitions);
    const hasReliablePhaseTimestamp = Boolean(text(source.phaseEnteredAt)) || timeline.some((entry) => Boolean(entry.startedAt));
    return {
      ...source,
      phaseModelVersion: MODEL_VERSION,
      phase,
      phaseCode: phase,
      phaseDisplayName: label(phase),
      phaseEnteredAt: text(source.phaseEnteredAt),
      phaseTimeline: timeline,
      phaseTransitions: transitions,
      phaseMigratedWithoutTimestamps: source.phaseMigratedWithoutTimestamps === true || !hasReliablePhaseTimestamp
    };
  }

  function initializeRecord(value, phaseValue, at, reason = 'job_started', source = 'job-start') {
    const documentValue = isPlainObject(value) ? value : {};
    const phase = normalizePhase(phaseValue);
    const timestamp = text(at);
    const timeline = timestamp ? [{
      phase,
      phaseCode: phase,
      displayName: label(phase),
      startedAt: timestamp,
      endedAt: '',
      previousPhase: '',
      nextPhase: '',
      transitionReason: text(reason),
      source: text(source)
    }] : [];
    return {
      ...documentValue,
      phaseModelVersion: MODEL_VERSION,
      phase,
      phaseCode: phase,
      phaseDisplayName: label(phase),
      phaseEnteredAt: timestamp,
      phaseTimeline: timeline,
      phaseTransitions: [],
      phaseMigratedWithoutTimestamps: !timestamp
    };
  }

  function transitionRecord(value, nextPhaseValue, at, reason, source, extra = {}) {
    const documentValue = migrateRecord(value);
    const fromPhase = normalizePhase(text(documentValue.phaseCode, text(documentValue.phase)));
    const toPhase = normalizePhase(nextPhaseValue);
    if (fromPhase === toPhase) return documentValue;
    const timestamp = text(at);
    if (!timestamp) throw new Error('Fasövergången saknar tidpunkt.');

    const timeline = normalizeTimeline(documentValue.phaseTimeline);
    const openIndex = (() => {
      for (let index = timeline.length - 1; index >= 0; index -= 1) {
        if (!timeline[index].endedAt && timeline[index].phase === fromPhase) return index;
      }
      return -1;
    })();
    const closedTimeline = timeline.map((entry, index) => index === openIndex
      ? { ...entry, endedAt: timestamp, nextPhase: toPhase }
      : entry);
    const nextEntry = {
      phase: toPhase,
      phaseCode: toPhase,
      displayName: label(toPhase),
      startedAt: timestamp,
      endedAt: '',
      previousPhase: fromPhase,
      nextPhase: '',
      transitionReason: text(reason),
      source: text(source)
    };
    const transition = {
      fromPhase,
      fromDisplayName: label(fromPhase),
      toPhase,
      toDisplayName: label(toPhase),
      at: timestamp,
      reason: text(reason),
      source: text(source),
      ...extra
    };
    return {
      ...documentValue,
      phaseModelVersion: MODEL_VERSION,
      phase: toPhase,
      phaseCode: toPhase,
      phaseDisplayName: label(toPhase),
      phaseEnteredAt: timestamp,
      phaseTimeline: [...closedTimeline, nextEntry],
      phaseTransitions: [...normalizeTransitions(documentValue.phaseTransitions), transition],
      phaseMigratedWithoutTimestamps: false
    };
  }

  function closeRecord(value, at, reason = 'job_completed', source = 'manual') {
    const documentValue = migrateRecord(value);
    const timestamp = text(at);
    if (!timestamp) return documentValue;
    const timeline = normalizeTimeline(documentValue.phaseTimeline);
    let openIndex = -1;
    for (let index = timeline.length - 1; index >= 0; index -= 1) {
      if (!timeline[index].endedAt) { openIndex = index; break; }
    }
    return {
      ...documentValue,
      phaseTimeline: timeline.map((entry, index) => index === openIndex
        ? { ...entry, endedAt: timestamp, nextPhase: '', completionReason: text(reason), completionSource: text(source) }
        : entry),
      phaseClosedAt: timestamp
    };
  }

  function determineInitialPhase(snapshot, geofenceDefinition, classifyPosition) {
    if (!isPlainObject(geofenceDefinition) || geofenceDefinition.enabled !== true) {
      return Object.freeze({ phase: PHASES.LOADING, source: 'safe-fallback', reason: 'geofence_missing' });
    }
    if (!snapshot || snapshot.isUsable !== true || typeof classifyPosition !== 'function') {
      return Object.freeze({ phase: PHASES.LOADING, source: 'safe-fallback', reason: 'gps_unusable' });
    }
    try {
      const classification = classifyPosition(geofenceDefinition, snapshot);
      if (classification && classification.state === 'outside') {
        return Object.freeze({ phase: PHASES.START_ROUTE, source: 'gps-geofence-start', reason: 'started_outside_from' });
      }
      if (classification && classification.state === 'inside') {
        return Object.freeze({ phase: PHASES.LOADING, source: 'gps-geofence-start', reason: 'started_inside_from' });
      }
      return Object.freeze({ phase: PHASES.LOADING, source: 'safe-fallback', reason: 'boundary_uncertain' });
    } catch (_) {
      return Object.freeze({ phase: PHASES.LOADING, source: 'safe-fallback', reason: 'geofence_invalid' });
    }
  }

  window.StadslassPhaseService = Object.freeze({
    MODEL_VERSION,
    PHASES,
    LABELS,
    normalizePhase,
    isKnownPhase,
    label,
    flow,
    migrateRecord,
    initializeRecord,
    transitionRecord,
    closeRecord,
    determineInitialPhase
  });
})();
