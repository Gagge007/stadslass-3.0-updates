(() => {
  'use strict';

  const SETTINGS_KEY = 'googleServiceV1';
  const DIAGNOSTICS_KEY = 'googleGeocodingDiagnosticsV1';
  const SCHEMA_VERSION = 1;
  const DIAGNOSTICS_SCHEMA_VERSION = 2;
  const SERVICE_VERSION = 3;
  const GEOCODING_ENDPOINT = 'https://maps.googleapis.com/maps/api/geocode/json';
  const DEFAULT_TIMEOUT_MS = 15000;
  const MAX_DIAGNOSTIC_ENTRIES = 20;
  const API_KEY_PATTERN = /^AIza[0-9A-Za-z_-]{20,100}$/;
  const API_KEY_IN_TEXT_PATTERN = /AIza[0-9A-Za-z_-]{20,100}/g;
  const PLUS_CODE_PATTERN = /^([23456789CFGHJMPQRVWX]{2,8}\+[23456789CFGHJMPQRVWX]{2,3})(?:\s*,?\s*(.+))?$/i;
  const GEOCODING_STATUSES = Object.freeze([
    'not-requested',
    'pending',
    'resolved',
    'failed',
    'unavailable',
    'invalid-input'
  ]);
  const DIAGNOSTIC_FLOWS = Object.freeze(['place', 'beach']);

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value) {
    return typeof value === 'string' ? value.trim() : '';
  }

  function normalizedText(value) {
    return text(value).replace(/\s+/g, ' ');
  }

  function safeErrorText(value, maximum = 400) {
    const sanitized = text(value).replace(API_KEY_IN_TEXT_PATTERN, 'AIza…MASKERAD');
    return sanitized.length > maximum ? sanitized.slice(0, maximum) : sanitized;
  }

  function escapeRegExp(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function maskDiagnosticMessage(value, sensitiveValues = []) {
    let sanitized = safeErrorText(value, 600);
    sensitiveValues.forEach((sensitiveValue) => {
      const raw = text(sensitiveValue);
      if (!raw) return;
      sanitized = sanitized.replace(new RegExp(escapeRegExp(raw), 'gi'), '[MASKERAD]');
      try {
        const encoded = encodeURIComponent(raw);
        if (encoded) sanitized = sanitized.replace(new RegExp(escapeRegExp(encoded), 'gi'), '[MASKERAD]');
      } catch (error) {
        // Diagnostiken får aldrig fallera på grund av maskeringen.
      }
    });
    sanitized = sanitized
      .replace(/https:\/\/maps\.googleapis\.com\/maps\/api\/geocode\/json\?[^\s]*/gi, '[GOOGLE-ANROP MASKERAT]')
      .replace(/([?&](?:address|key)=)[^&\s]*/gi, '$1[MASKERAD]')
      .replace(/\b(?:lat(?:itude)?|lon(?:gitude)?|lng)\s*[:=]\s*-?\d+(?:\.\d+)?/gi, '[KOORDINAT MASKERAD]')
      .replace(/-?\d{1,2}\.\d{3,}\s*[,/]\s*-?\d{1,3}\.\d{3,}/g, '[KOORDINAT MASKERAD]');
    return sanitized.length > 400 ? sanitized.slice(0, 400) : sanitized;
  }

  function currentPageContext() {
    let pageProtocol = '';
    let pageOrigin = '';
    let navigatorOnline = null;
    try {
      pageProtocol = text(window.location && window.location.protocol).slice(0, 30);
      pageOrigin = text(window.location && window.location.origin).slice(0, 200);
    } catch (error) {
      pageProtocol = '';
      pageOrigin = '';
    }
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean') navigatorOnline = navigator.onLine;
    } catch (error) {
      navigatorOnline = null;
    }
    return { pageProtocol, pageOrigin, navigatorOnline };
  }

  function optionalNumber(value) {
    if (value === null || typeof value === 'undefined') return null;
    if (typeof value === 'string' && !value.trim()) return null;
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function validCoordinates(latitude, longitude) {
    const lat = optionalNumber(latitude);
    const lon = optionalNumber(longitude);
    return lat !== null && lon !== null && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
  }

  function normalizeSettings(value) {
    const source = isPlainObject(value) ? value : {};
    return {
      schemaVersion: SCHEMA_VERSION,
      apiKey: text(source.apiKey),
      updatedAt: text(source.updatedAt)
    };
  }

  function validateSettings(value) {
    const settings = normalizeSettings(value);
    if (settings.apiKey && !API_KEY_PATTERN.test(settings.apiKey)) {
      throw new Error('Google API-nyckeln har inte ett giltigt nyckelformat.');
    }
    return settings;
  }

  function maskApiKey(value) {
    const key = text(value);
    if (!key) return 'Ingen nyckel sparad';
    if (key.length <= 12) return `${key.slice(0, 4)}…`;
    return `${key.slice(0, 6)}…${key.slice(-4)}`;
  }

  function hasApiKey(value) {
    return API_KEY_PATTERN.test(text(value));
  }

  function inspectQuery(value) {
    const query = normalizedText(value);
    if (!query) {
      return { valid: false, query: '', requestQuery: '', code: 'EMPTY_QUERY', message: 'Adress / Plus Code saknas.', isPlusCode: false };
    }
    if (query.length > 300) {
      return { valid: false, query, requestQuery: query, code: 'QUERY_TOO_LONG', message: 'Adress / Plus Code får vara högst 300 tecken.', isPlusCode: false };
    }
    const plusCode = query.match(PLUS_CODE_PATTERN);
    if (plusCode) {
      const code = plusCode[1].toUpperCase();
      const locality = normalizedText(plusCode[2]);
      const beforePlus = code.split('+')[0];
      if (beforePlus.length < 8 && !locality) {
        return {
          valid: false,
          query,
          requestQuery: query,
          code: 'SHORT_PLUS_CODE_NEEDS_LOCALITY',
          message: 'En kort Plus Code måste kompletteras med ort eller område.',
          isPlusCode: true
        };
      }
      return {
        valid: true,
        query,
        requestQuery: beforePlus.length < 8 ? `${code}, ${locality}` : code,
        code: '',
        message: '',
        isPlusCode: true
      };
    }
    return { valid: true, query, requestQuery: query, code: '', message: '', isPlusCode: false };
  }

  function buildGeocodingUrl(addressOrPlusCode, apiKey) {
    const queryInspection = inspectQuery(addressOrPlusCode);
    if (!queryInspection.valid) {
      const error = serviceError(queryInspection.message, {
        code: queryInspection.code,
        kind: 'invalid-input',
        stage: 'query-validation'
      });
      throw error;
    }
    const key = text(apiKey);
    if (!hasApiKey(key)) {
      throw serviceError('En aktiv Google API-nyckel måste sparas under Inställningar innan koordinater kan hämtas.', {
        code: 'API_KEY_MISSING',
        kind: 'unavailable',
        stage: 'api-key-validation'
      });
    }
    const query = encodeURIComponent(queryInspection.requestQuery);
    const encodedKey = encodeURIComponent(key);
    return {
      queryInspection,
      url: `${GEOCODING_ENDPOINT}?address=${query}&key=${encodedKey}&language=sv&region=se`
    };
  }

  function emptyGeocoding(source = {}) {
    const value = isPlainObject(source) ? source : {};
    return {
      schemaVersion: SCHEMA_VERSION,
      status: GEOCODING_STATUSES.includes(text(value.status)) ? text(value.status) : 'not-requested',
      query: normalizedText(value.query),
      formattedAddress: text(value.formattedAddress),
      latitude: optionalNumber(value.latitude),
      longitude: optionalNumber(value.longitude),
      lastAttemptAt: text(value.lastAttemptAt),
      resolvedAt: text(value.resolvedAt),
      errorCode: text(value.errorCode),
      errorMessage: safeErrorText(value.errorMessage),
      source: text(value.source)
    };
  }

  function normalizeGeocoding(value, legacy = {}) {
    const source = emptyGeocoding(value);
    const legacyLatitude = optionalNumber(legacy.latitude);
    const legacyLongitude = optionalNumber(legacy.longitude);
    const latitude = source.latitude !== null ? source.latitude : legacyLatitude;
    const longitude = source.longitude !== null ? source.longitude : legacyLongitude;
    const hasCoordinates = validCoordinates(latitude, longitude);
    const query = source.query || normalizedText(legacy.query);
    let status = source.status;
    let resolvedAt = source.resolvedAt;
    let geocodingSource = source.source;

    if (hasCoordinates && status !== 'resolved') {
      status = 'resolved';
      resolvedAt = resolvedAt || text(legacy.resolvedAt) || text(legacy.timestamp);
      geocodingSource = geocodingSource || text(legacy.source) || 'legacy-existing';
    }
    if (!hasCoordinates && status === 'resolved') status = query ? 'pending' : 'not-requested';

    return {
      ...source,
      status,
      query,
      latitude: hasCoordinates ? latitude : null,
      longitude: hasCoordinates ? longitude : null,
      resolvedAt,
      source: geocodingSource
    };
  }

  function validateGeocoding(value) {
    const geocoding = normalizeGeocoding(value);
    if (geocoding.schemaVersion !== SCHEMA_VERSION) throw new Error('Geokodningsposten har en okänd schemaversion.');
    if (!GEOCODING_STATUSES.includes(geocoding.status)) throw new Error('Geokodningsposten har en ogiltig status.');
    if (geocoding.query.length > 300) throw new Error('Geokodningens söktext är för lång.');
    if ((geocoding.latitude !== null || geocoding.longitude !== null)
      && !validCoordinates(geocoding.latitude, geocoding.longitude)) {
      throw new Error('Geokodningens koordinater är ogiltiga.');
    }
    if (geocoding.status === 'resolved' && !validCoordinates(geocoding.latitude, geocoding.longitude)) {
      throw new Error('En löst geokodning måste ha giltiga koordinater.');
    }
    return geocoding;
  }

  function needsGeocoding(currentGeocoding, nextAddressOrPlusCode) {
    const nextQuery = normalizedText(nextAddressOrPlusCode);
    if (!nextQuery) return false;
    const current = normalizeGeocoding(currentGeocoding);
    if (current.query !== nextQuery) return true;
    return !validCoordinates(current.latitude, current.longitude);
  }

  function pendingGeocoding(currentGeocoding, nextAddressOrPlusCode, timestamp = new Date().toISOString()) {
    const current = normalizeGeocoding(currentGeocoding);
    const query = normalizedText(nextAddressOrPlusCode);
    if (!query) {
      return {
        ...current,
        status: 'not-requested',
        query: '',
        formattedAddress: '',
        latitude: null,
        longitude: null,
        lastAttemptAt: '',
        resolvedAt: '',
        errorCode: '',
        errorMessage: '',
        source: ''
      };
    }
    if (!needsGeocoding(current, query)) return current;
    return {
      ...current,
      status: 'pending',
      query,
      formattedAddress: '',
      latitude: null,
      longitude: null,
      lastAttemptAt: timestamp,
      resolvedAt: '',
      errorCode: '',
      errorMessage: '',
      source: 'google-geocoding'
    };
  }

  function failedGeocoding(currentGeocoding, queryValue, code, message, status = 'failed', timestamp = new Date().toISOString()) {
    const current = normalizeGeocoding(currentGeocoding);
    const normalizedStatus = GEOCODING_STATUSES.includes(status) ? status : 'failed';
    return {
      ...current,
      status: normalizedStatus,
      query: normalizedText(queryValue),
      formattedAddress: '',
      latitude: null,
      longitude: null,
      lastAttemptAt: timestamp,
      resolvedAt: '',
      errorCode: text(code) || 'GEOCODING_FAILED',
      errorMessage: safeErrorText(message) || 'Koordinater kunde inte hämtas.',
      source: 'google-geocoding'
    };
  }

  function resolvedGeocoding(currentGeocoding, result, timestamp = new Date().toISOString()) {
    const current = normalizeGeocoding(currentGeocoding);
    const value = isPlainObject(result) ? result : {};
    if (!validCoordinates(value.latitude, value.longitude)) throw new Error('Google-resultatet saknar giltiga koordinater.');
    return {
      ...current,
      status: 'resolved',
      query: normalizedText(value.query) || current.query,
      formattedAddress: text(value.formattedAddress),
      latitude: Number(value.latitude),
      longitude: Number(value.longitude),
      lastAttemptAt: timestamp,
      resolvedAt: timestamp,
      errorCode: '',
      errorMessage: '',
      source: 'google-geocoding'
    };
  }

  function apiStatusMessage(status, fallbackMessage) {
    const fallback = safeErrorText(fallbackMessage);
    if (status === 'ZERO_RESULTS') return 'Google hittade ingen plats för Adress / Plus Code.';
    if (status === 'REQUEST_DENIED') return 'Google nekade geokodningsanropet. Kontrollera den befintliga API-nyckelns begränsningar.';
    if (status === 'OVER_DAILY_LIMIT') return 'Google-kontots geokodningsgräns eller fakturering tillåter inte anropet.';
    if (status === 'OVER_QUERY_LIMIT') return 'Google Geocoding har tillfälligt nått sin anropsgräns.';
    if (status === 'INVALID_REQUEST') return 'Google bedömde Adress / Plus Code som ofullständig.';
    if (status === 'UNKNOWN_ERROR') return 'Google kunde inte slutföra geokodningen just nu.';
    return fallback || 'Koordinater kunde inte hämtas från Google.';
  }

  function serviceError(message, details = {}) {
    const error = new Error(safeErrorText(message) || 'Geokodningen misslyckades.');
    error.isGoogleServiceError = true;
    error.code = text(details.code) || 'GEOCODING_FAILED';
    error.kind = text(details.kind) || 'runtime';
    error.googleStatus = text(details.googleStatus);
    error.stage = text(details.stage) || 'unknown';
    error.httpStatus = Number.isInteger(Number(details.httpStatus)) ? Number(details.httpStatus) : 0;
    error.causeName = text(details.causeName);
    return error;
  }

  function errorStatus(error) {
    const kind = text(error && error.kind);
    if (kind === 'invalid-input') return 'invalid-input';
    if (kind === 'unavailable') return 'unavailable';
    return 'failed';
  }

  function userMessageForError(error) {
    const kind = text(error && error.kind);
    const code = text(error && error.code);
    if (kind === 'invalid-input') return safeErrorText(error && error.message) || 'Adress / Plus Code behöver rättas.';
    if (code === 'API_KEY_MISSING') return 'En aktiv Google API-nyckel måste sparas under Inställningar innan koordinater kan hämtas.';
    if (code === 'TIMEOUT') return 'Google-geokodningen tog för lång tid och avbröts.';
    if (kind === 'unavailable') return 'Internetanslutningen eller åtkomsten till Google kunde inte användas.';
    if (kind === 'google-api') return apiStatusMessage(text(error && error.googleStatus) || code, error && error.message);
    if (kind === 'invalid-response') return 'Google svarade, men svaret kunde inte tolkas säkert.';
    return 'Geokodningen stoppades av ett tekniskt appfel.';
  }

  function normalizeDiagnostic(value) {
    const source = isPlainObject(value) ? value : {};
    const flow = DIAGNOSTIC_FLOWS.includes(text(source.flow)) ? text(source.flow) : '';
    const registerFlow = text(source.registerFlow) || (flow === 'place' ? 'Platser' : (flow === 'beach' ? 'Badplatser' : ''));
    const navigatorOnline = typeof source.navigatorOnline === 'boolean' ? source.navigatorOnline : null;
    const maskedMessage = maskDiagnosticMessage(source.maskedMessage || source.message);
    return {
      schemaVersion: DIAGNOSTICS_SCHEMA_VERSION,
      at: text(source.at),
      flow,
      registerFlow,
      itemId: text(source.itemId),
      errorCode: text(source.errorCode),
      googleStatus: text(source.googleStatus),
      errorName: text(source.errorName || source.causeName),
      maskedMessage,
      pageProtocol: safeErrorText(source.pageProtocol, 30),
      pageOrigin: safeErrorText(source.pageOrigin, 200),
      navigatorOnline,
      category: text(source.category),
      stage: text(source.stage),
      httpStatus: Number.isInteger(Number(source.httpStatus)) ? Number(source.httpStatus) : 0,
      apiKeyMask: safeErrorText(source.apiKeyMask, 40),
      message: safeErrorText(source.message)
    };
  }

  function diagnosticFromError(error, context = {}) {
    const pageContext = currentPageContext();
    return normalizeDiagnostic({
      at: text(context.at) || new Date().toISOString(),
      flow: text(context.flow),
      registerFlow: text(context.flow) === 'place' ? 'Platser' : (text(context.flow) === 'beach' ? 'Badplatser' : ''),
      itemId: text(context.itemId),
      errorCode: text(error && error.code) || 'RUNTIME_ERROR',
      googleStatus: text(error && error.googleStatus),
      errorName: text(error && (error.causeName || error.name)),
      maskedMessage: maskDiagnosticMessage(error && error.message, [context.apiKey, context.query]),
      pageProtocol: text(context.pageProtocol) || pageContext.pageProtocol,
      pageOrigin: text(context.pageOrigin) || pageContext.pageOrigin,
      navigatorOnline: typeof context.navigatorOnline === 'boolean' ? context.navigatorOnline : pageContext.navigatorOnline,
      category: text(error && error.kind) || 'runtime',
      stage: text(error && error.stage) || 'unknown',
      httpStatus: error && error.httpStatus,
      apiKeyMask: maskApiKey(context.apiKey),
      message: userMessageForError(error)
    });
  }

  function normalizeDiagnostics(value) {
    const source = isPlainObject(value) ? value : {};
    const entries = Array.isArray(source.entries)
      ? source.entries.map(normalizeDiagnostic).filter((entry) => entry.at && entry.errorCode).slice(-MAX_DIAGNOSTIC_ENTRIES)
      : [];
    return {
      schemaVersion: DIAGNOSTICS_SCHEMA_VERSION,
      updatedAt: text(source.updatedAt),
      entries
    };
  }

  function appendDiagnostic(value, diagnostic, timestamp = new Date().toISOString()) {
    const current = normalizeDiagnostics(value);
    const next = normalizeDiagnostic(diagnostic);
    const entries = current.entries.concat(next).slice(-MAX_DIAGNOSTIC_ENTRIES);
    return {
      schemaVersion: DIAGNOSTICS_SCHEMA_VERSION,
      updatedAt: timestamp,
      entries
    };
  }

  async function geocode(addressOrPlusCode, apiKey, options = {}) {
    let built;
    try {
      built = buildGeocodingUrl(addressOrPlusCode, apiKey);
    } catch (error) {
      if (error && error.isGoogleServiceError) throw error;
      throw serviceError('Geokodningsadressen kunde inte byggas i appens WebView.', {
        code: 'REQUEST_URL_BUILD_FAILED',
        kind: 'runtime',
        stage: 'request-url',
        causeName: error && error.name
      });
    }

    const timeoutMs = Number.isFinite(Number(options.timeoutMs)) && Number(options.timeoutMs) > 0
      ? Number(options.timeoutMs)
      : DEFAULT_TIMEOUT_MS;
    const fetchImpl = typeof options.fetchImpl === 'function' ? options.fetchImpl : window.fetch.bind(window);
    const abortController = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = abortController ? window.setTimeout(() => abortController.abort(), timeoutMs) : null;
    let response;

    try {
      try {
        response = await fetchImpl(built.url, {
          method: 'GET',
          cache: 'no-store',
          credentials: 'omit',
          signal: abortController ? abortController.signal : undefined
        });
      } catch (error) {
        if (error && error.name === 'AbortError') {
          throw serviceError('Google-geokodningen tog för lång tid och avbröts.', {
            code: 'TIMEOUT',
            kind: 'unavailable',
            stage: 'fetch',
            causeName: error.name
          });
        }
        const name = text(error && error.name);
        const detail = text(error && error.message);
        if (name === 'TypeError' || name === 'NetworkError' || /network|failed to fetch|offline|internet/i.test(detail)) {
          throw serviceError('Internetanslutningen eller åtkomsten till Google kunde inte användas.', {
            code: 'NETWORK_ERROR',
            kind: 'unavailable',
            stage: 'fetch',
            causeName: name
          });
        }
        throw serviceError('WebView eller JavaScript stoppade geokodningsanropet innan Google svarade.', {
          code: 'WEBVIEW_RUNTIME_ERROR',
          kind: 'runtime',
          stage: 'fetch',
          causeName: name
        });
      }

      if (!response || typeof response.ok !== 'boolean') {
        throw serviceError('Google-anropet gav inget giltigt HTTP-svar.', {
          code: 'HTTP_RESPONSE_INVALID',
          kind: 'invalid-response',
          stage: 'http-response'
        });
      }
      if (response.ok !== true) {
        const httpStatus = Number(response.status) || 0;
        throw serviceError(`Google Geocoding svarade med HTTP ${httpStatus || 'okänd status'}.`, {
          code: httpStatus ? `HTTP_${httpStatus}` : 'HTTP_ERROR',
          kind: 'google-api',
          stage: 'http-response',
          httpStatus
        });
      }

      let payload;
      try {
        payload = await response.json();
      } catch (error) {
        throw serviceError('Google svarade, men svaret var inte giltig JSON.', {
          code: 'INVALID_JSON_RESPONSE',
          kind: 'invalid-response',
          stage: 'response-json',
          causeName: error && error.name
        });
      }
      if (!isPlainObject(payload)) {
        throw serviceError('Google-svaret hade ett oväntat format.', {
          code: 'INVALID_RESPONSE_SHAPE',
          kind: 'invalid-response',
          stage: 'response-validation'
        });
      }
      const status = text(payload.status);
      if (!status) {
        throw serviceError('Google-svaret saknade status.', {
          code: 'GOOGLE_STATUS_MISSING',
          kind: 'invalid-response',
          stage: 'response-validation'
        });
      }
      if (status !== 'OK') {
        throw serviceError(apiStatusMessage(status, payload.error_message), {
          code: status,
          kind: 'google-api',
          googleStatus: status,
          stage: 'google-status'
        });
      }
      if (!Array.isArray(payload.results)) {
        throw serviceError('Google-svaret saknade en giltig resultatlista.', {
          code: 'RESULTS_MISSING',
          kind: 'invalid-response',
          googleStatus: status,
          stage: 'result-validation'
        });
      }
      const selected = payload.results.find((item) => isPlainObject(item)
        && isPlainObject(item.geometry)
        && isPlainObject(item.geometry.location)
        && validCoordinates(item.geometry.location.lat, item.geometry.location.lng));
      if (!selected) {
        throw serviceError('Google-resultatet saknade giltiga koordinater.', {
          code: 'RESULT_COORDINATES_MISSING',
          kind: 'invalid-response',
          googleStatus: status,
          stage: 'result-validation'
        });
      }
      return {
        query: built.queryInspection.query,
        requestQuery: built.queryInspection.requestQuery,
        formattedAddress: text(selected.formatted_address),
        latitude: Number(selected.geometry.location.lat),
        longitude: Number(selected.geometry.location.lng),
        googleStatus: status
      };
    } finally {
      if (timer !== null) window.clearTimeout(timer);
    }
  }

  window.StadslassGoogleService = Object.freeze({
    SETTINGS_KEY,
    DIAGNOSTICS_KEY,
    SCHEMA_VERSION,
    DIAGNOSTICS_SCHEMA_VERSION,
    SERVICE_VERSION,
    GEOCODING_ENDPOINT,
    GEOCODING_STATUSES,
    normalizeSettings,
    validateSettings,
    maskApiKey,
    hasApiKey,
    inspectQuery,
    buildGeocodingUrl,
    validCoordinates,
    normalizeGeocoding,
    validateGeocoding,
    needsGeocoding,
    pendingGeocoding,
    failedGeocoding,
    resolvedGeocoding,
    errorStatus,
    userMessageForError,
    maskDiagnosticMessage,
    normalizeDiagnostic,
    diagnosticFromError,
    normalizeDiagnostics,
    appendDiagnostic,
    geocode
  });
})();
