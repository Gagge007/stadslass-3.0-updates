(() => {
  'use strict';

  const PACKAGE_VERSION = 5;
  const MINIMUM_HOST_VERSION = 4;
  const SETTINGS_STORE = 'settings';
  const QUEUE_STORE = 'queue';
  const UI_SETTINGS_KEY = 'uiPreferencesV1';
  const PAGE_TITLES = Object.freeze({ home: 'Start', queue: 'Kö', settings: 'Inställningar' });

  let hostInfo = null;
  let settingsDocument = {};
  let queueDocument = [];
  let queueLoaded = false;
  let updatePollTimer = null;

  const byId = (id) => document.getElementById(id);

  function bridgeAvailable() {
    return typeof window.StadslassHost === 'object' && window.StadslassHost !== null;
  }

  function parseObject(raw, fallback = {}) {
    try {
      const value = JSON.parse(raw);
      return value && typeof value === 'object' && !Array.isArray(value) ? value : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function readSettingsDocument() {
    const raw = window.StadslassHost.readStore(SETTINGS_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Inställningslagret kunde inte läsas.');
    }
    return parseObject(raw, {});
  }

  function readQueueDocument() {
    const raw = window.StadslassHost.readStore(QUEUE_STORE);
    if (!raw) {
      throw new Error(window.StadslassHost.getLastError() || 'Kölagret kunde inte läsas.');
    }
    let value;
    try {
      value = JSON.parse(raw);
    } catch (_) {
      throw new Error('Kölagret innehåller ogiltig JSON och har inte ändrats.');
    }
    if (!Array.isArray(value)) {
      throw new Error('Kölagret har fel format och har inte ändrats.');
    }
    return value;
  }

  function normalizedUiPreferences(documentValue) {
    const value = parseObject(JSON.stringify(documentValue[UI_SETTINGS_KEY] || {}), {});
    return {
      largeText: value.largeText === true,
      showTechnicalInfo: value.showTechnicalInfo === true
    };
  }

  function applyUiPreferences(preferences) {
    document.documentElement.classList.toggle('large-text', preferences.largeText);
    byId('large-text').checked = preferences.largeText;
    byId('show-technical').checked = preferences.showTechnicalInfo;
    byId('technical-panel').hidden = !preferences.showTechnicalInfo;
  }

  function showStatus(elementId, message, isError = false) {
    const element = byId(elementId);
    element.textContent = message;
    element.classList.toggle('is-error', isError);
  }

  function showView(target) {
    if (!Object.prototype.hasOwnProperty.call(PAGE_TITLES, target)) {
      return;
    }
    document.querySelectorAll('[data-view]').forEach((view) => {
      view.hidden = view.dataset.view !== target;
    });
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      const active = button.dataset.target === target;
      button.classList.toggle('is-active', active);
      if (active) {
        button.setAttribute('aria-current', 'page');
      } else {
        button.removeAttribute('aria-current');
      }
    });
    byId('page-title').textContent = PAGE_TITLES[target];
    byId('main-content').focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }

  function canUseQueue() {
    return hostInfo && hostInfo.role === 'mobile';
  }

  function applyRoleBoundaries() {
    const allowed = canUseQueue();
    byId('open-queue').hidden = !allowed;
    const queueNav = document.querySelector('.nav-button[data-target="queue"]');
    queueNav.hidden = !allowed;
    document.querySelector('.bottom-nav').classList.toggle('queue-disabled', !allowed);
    byId('home-heading').textContent = allowed ? 'Kö-modulen är aktiv' : 'Appskal och inställningar är aktiva';
    byId('home-module-summary').textContent = allowed
      ? 'Appskal och Inställningar är bevarade. Kö läses separat först när du öppnar kövyn.'
      : 'Köplanering är avsiktligt avstängd på 189 / Surfplatta. Inställningar och teknisk kontroll är bevarade.';
    byId('queue-role-note').textContent = allowed
      ? 'Köplanering är tillgänglig på denna Mobil-enhet.'
      : 'Köplanering är dold på 189 / Surfplatta enligt appreglerna.';
  }

  function activateView(target) {
    if (target === 'queue' && !canUseQueue()) {
      showView('home');
      showStatus('queue-role-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    showView(target);
    if (target === 'queue') {
      loadQueueIfNeeded();
    }
  }

  function renderHostInfo() {
    const role = hostInfo.roleLabel || hostInfo.role || 'Okänd roll';
    byId('role-chip').textContent = role;
    byId('host-version').textContent = `${hostInfo.hostVersionName} (${hostInfo.hostVersionCode})`;
    byId('package-version').textContent = String(hostInfo.packageVersion);
    byId('technical-role').textContent = role;
    byId('device-id').textContent = hostInfo.deviceId || 'Saknas';
  }

  function renderPreservedTestValue() {
    const testValue = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    byId('module-test-value').textContent = String(testValue);
  }

  function saveSettings(event) {
    event.preventDefault();
    const nextPreferences = {
      largeText: byId('large-text').checked,
      showTechnicalInfo: byId('show-technical').checked
    };
    const nextDocument = {
      ...settingsDocument,
      [UI_SETTINGS_KEY]: nextPreferences,
      settingsSchemaVersion: 1,
      settingsUpdatedByPackageVersion: PACKAGE_VERSION
    };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('save-status', window.StadslassHost.getLastError() || 'Inställningarna kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    applyUiPreferences(nextPreferences);
    showStatus('save-status', 'Inställningarna är sparade.');
  }

  function incrementPreservedTestValue() {
    const current = Number.isInteger(settingsDocument.moduleTestValue) && settingsDocument.moduleTestValue >= 0
      ? settingsDocument.moduleTestValue
      : 0;
    const nextDocument = { ...settingsDocument, moduleTestValue: current + 1 };
    const saved = window.StadslassHost.writeStore(SETTINGS_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('storage-status', window.StadslassHost.getLastError() || 'Testvärdet kunde inte sparas.', true);
      return;
    }
    settingsDocument = nextDocument;
    renderPreservedTestValue();
    showStatus('storage-status', 'Testvärdet är sparat i inställningslagret.');
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      return '';
    }
    const parts = value.split('-').map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return new Intl.DateTimeFormat('sv-SE', { year: 'numeric', month: 'short', day: 'numeric' }).format(date);
  }

  function createQueueId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      window.crypto.getRandomValues(random);
    } else {
      random[0] = Math.floor(Math.random() * 0xffffffff);
      random[1] = Math.floor(Math.random() * 0xffffffff);
    }
    return `queue-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function displayQueueItem(item, index) {
    const source = item && typeof item === 'object' && !Array.isArray(item) ? item : {};
    return {
      id: text(source.id, `legacy-${index}`),
      jobType: text(source.jobType, text(source.displayType, 'Uppdrag')),
      from: text(source.from, text(source.placeLabel, 'Från saknas')),
      destination: text(source.destination, text(source.destLabel, 'Till saknas')),
      plannedDate: text(source.plannedDate),
      plannedTime: text(source.plannedTime)
    };
  }

  function queueMetaChip(label, extraClass = '') {
    const chip = document.createElement('span');
    chip.className = `meta-chip${extraClass ? ` ${extraClass}` : ''}`;
    chip.textContent = label;
    return chip;
  }

  function renderQueue() {
    const list = byId('queue-list');
    list.replaceChildren();
    byId('queue-count').textContent = String(queueDocument.length);

    if (queueDocument.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = 'Kön är tom.';
      list.appendChild(empty);
      return;
    }

    const today = localDateKey(new Date());
    queueDocument.forEach((rawItem, index) => {
      const item = displayQueueItem(rawItem, index);
      const card = document.createElement('article');
      card.className = 'queue-card';
      card.dataset.queueId = item.id;

      const header = document.createElement('div');
      header.className = 'queue-card-header';
      const heading = document.createElement('h3');
      heading.textContent = item.jobType;
      header.appendChild(heading);
      card.appendChild(header);

      const route = document.createElement('p');
      route.className = 'queue-route';
      route.textContent = `${item.from} → ${item.destination}`;
      card.appendChild(route);

      const meta = document.createElement('div');
      meta.className = 'queue-meta';
      if (item.plannedDate) {
        meta.appendChild(queueMetaChip(formatDate(item.plannedDate) || item.plannedDate));
        if (item.plannedDate > today) {
          meta.appendChild(queueMetaChip('Framtida uppdrag', 'future'));
        }
      } else {
        meta.appendChild(queueMetaChip('Datum saknas'));
      }
      if (item.plannedTime) {
        meta.appendChild(queueMetaChip(`Kl. ${item.plannedTime}`));
      }
      card.appendChild(meta);

      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'danger-button';
      remove.dataset.removeQueueId = item.id;
      remove.dataset.removeQueueIndex = String(index);
      remove.textContent = 'Ta bort från kö';
      card.appendChild(remove);
      list.appendChild(card);
    });
  }

  function loadQueueIfNeeded() {
    if (!canUseQueue()) {
      showStatus('queue-role-note', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (queueLoaded) {
      return;
    }
    try {
      queueDocument = readQueueDocument();
      queueLoaded = true;
      renderQueue();
      showStatus('queue-load-status', 'Kön är lokalt inläst.');
    } catch (error) {
      showStatus('queue-load-status', error.message || 'Kön kunde inte läsas.', true);
    }
  }

  function persistQueue(nextDocument, successMessage) {
    const saved = window.StadslassHost.writeStore(QUEUE_STORE, JSON.stringify(nextDocument));
    if (!saved) {
      showStatus('queue-form-status', window.StadslassHost.getLastError() || 'Kön kunde inte sparas.', true);
      return false;
    }
    queueDocument = nextDocument;
    queueLoaded = true;
    renderQueue();
    showStatus('queue-form-status', successMessage);
    return true;
  }

  function createQueueItem(event) {
    event.preventDefault();
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded) {
      loadQueueIfNeeded();
    }
    if (!queueLoaded) {
      showStatus('queue-form-status', 'Kön måste kunna läsas innan ett uppdrag kan sparas.', true);
      return;
    }

    const jobType = text(byId('job-type').value);
    const from = text(byId('job-from').value);
    const destination = text(byId('job-destination').value);
    const plannedDate = text(byId('planned-date').value);
    const plannedTime = text(byId('planned-time').value);

    if (!jobType || !from || !destination) {
      showStatus('queue-form-status', 'Fyll i jobbtyp, Från och Till.', true);
      return;
    }

    const item = {
      schemaVersion: 1,
      id: createQueueId(),
      status: 'queued',
      source: 'manual',
      jobType,
      from,
      destination,
      plannedDate,
      plannedTime,
      createdAt: new Date().toISOString(),
      createdByPackageVersion: PACKAGE_VERSION
    };
    const nextDocument = [...queueDocument, item];
    if (persistQueue(nextDocument, 'Uppdraget är sparat i den lokala kön.')) {
      byId('queue-form').reset();
    }
  }

  function removeQueueItem(button) {
    if (!canUseQueue()) {
      showStatus('queue-form-status', 'Köplanering är blockerad på denna enhetsroll.', true);
      return;
    }
    if (!queueLoaded) {
      return;
    }
    const id = button.dataset.removeQueueId || '';
    const index = Number(button.dataset.removeQueueIndex);
    const candidate = queueDocument[index];
    const candidateId = candidate && typeof candidate === 'object' ? text(candidate.id) : '';
    if (!Number.isInteger(index) || index < 0 || index >= queueDocument.length || (candidateId && candidateId !== id)) {
      showStatus('queue-form-status', 'Köposten kunde inte identifieras och har inte ändrats.', true);
      return;
    }
    if (!window.confirm('Ta bort uppdraget från kön?')) {
      return;
    }
    const nextDocument = queueDocument.filter((_, itemIndex) => itemIndex !== index);
    persistQueue(nextDocument, 'Uppdraget är borttaget från kön.');
  }

  function refreshUpdateStatus() {
    if (!bridgeAvailable()) {
      return;
    }
    const textValue = window.StadslassHost.getUpdateStatus();
    byId('update-status').textContent = textValue || hostInfo.updateStatus || 'Ingen uppdateringsstatus tillgänglig.';
  }

  function requestUpdateCheck() {
    byId('update-status').textContent = 'Söker efter funktionsuppdatering…';
    window.StadslassHost.requestUpdateCheck();
    window.setTimeout(refreshUpdateStatus, 250);
  }

  function installEventHandlers() {
    byId('open-queue').addEventListener('click', () => activateView('queue'));
    document.querySelectorAll('.nav-button[data-target]').forEach((button) => {
      button.addEventListener('click', () => activateView(button.dataset.target));
    });
    byId('settings-form').addEventListener('submit', saveSettings);
    byId('increment-test').addEventListener('click', incrementPreservedTestValue);
    byId('check-update').addEventListener('click', requestUpdateCheck);
    byId('host-control').addEventListener('click', () => window.StadslassHost.showHostControl());
    byId('queue-form').addEventListener('submit', createQueueItem);
    byId('queue-list').addEventListener('click', (event) => {
      const button = event.target.closest('button[data-remove-queue-id]');
      if (button) {
        removeQueueItem(button);
      }
    });
  }

  function verifyRuntime() {
    if (!bridgeAvailable()) {
      throw new Error('Värdbryggan saknas.');
    }
    const styleReady = getComputedStyle(document.documentElement).getPropertyValue('--module-style-ready').trim();
    if (styleReady !== '1') {
      throw new Error('Modulens CSS kunde inte verifieras.');
    }
    hostInfo = parseObject(window.StadslassHost.getHostInfo(), null);
    if (!hostInfo) {
      throw new Error('Värdinformationen kunde inte läsas.');
    }
    if (Number(hostInfo.hostVersionCode) < MINIMUM_HOST_VERSION) {
      throw new Error('Värdappen är för gammal för funktionspaket 5.');
    }
    if (Number(hostInfo.packageVersion) !== PACKAGE_VERSION) {
      throw new Error('Paketversionen i värdbryggan stämmer inte.');
    }
  }

  function start() {
    try {
      verifyRuntime();
      settingsDocument = readSettingsDocument();
      applyUiPreferences(normalizedUiPreferences(settingsDocument));
      renderHostInfo();
      applyRoleBoundaries();
      renderPreservedTestValue();
      installEventHandlers();
      refreshUpdateStatus();
      updatePollTimer = window.setInterval(refreshUpdateStatus, 2500);
      window.StadslassHost.markReady(PACKAGE_VERSION);
    } catch (error) {
      document.body.innerHTML = `<main class="content"><article class="section-card"><h1>Modulen kunde inte starta</h1><p></p></article></main>`;
      document.querySelector('p').textContent = error.message || 'Okänt startfel.';
    }
  }

  window.addEventListener('beforeunload', () => {
    if (updatePollTimer !== null) {
      window.clearInterval(updatePollTimer);
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
