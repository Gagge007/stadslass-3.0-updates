(() => {
  'use strict';
  // This registry owns material records and the one many-to-many relation to job types.
  const SCHEMA_VERSION = 1;
  const SETTINGS_KEY = 'materialCodeRegistryV1';
  const LINK_KEY = 'jobTypeMaterialCodeLinks';
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const plain = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const clone = (value) => JSON.parse(JSON.stringify(value));
  function createId(prefix = 'MC') { return window.crypto && typeof window.crypto.randomUUID === 'function' ? `${prefix}-${window.crypto.randomUUID()}` : `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`; }

  // Only the four decided columns from Renovas 2024-02-27 PDF. Whitespace is
  // normalized; the source's Består av text is not summarized or rewritten.
  const SEED = Object.freeze([
    ['MC-SEED-101','101','Fint brännbart verksamhetsavfall','Material som brinner utan energitillskott, t ex. plast, papper, trä, textil, m.m. Får innehålla spikar, gångjärn etc. som sitter fast i materialet. Max 40% fossilt innehåll (plast) Begränsningar: Längd mindre än 1,0 m, max vikt 25 kg.',['Sävenäs förbränning','Högsbo omlastningsstation','Lerum omlastningsstation','Mölndal omlastningsstation','Tagene omlastningsstation','Munkegärde omlastningsstation','Kläpp omlastningsstation']],
    ['MC-SEED-150','150','Färskt trä > 25 cm i diameter','Sorteras och finfördelas (krossas maskinellt) före förbränning, brinner utan energitillskott efter det att förbränningsprocessen startat. Begränsningar: Maxvikt 500 kg per enhet',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-179','179','Impregnerat trä','Kreosot- och metallimpregnerat trä. Oljeimpregnerat trä t.ex. slipers och lyktstolpar. Tryckimpregnerat trä t.ex. altanplank, bullerplank, lekställningar, blomsterlådor, m.m. Max 5 meter och inga beslag större än en handflata.',['Sävenäs försortering','Mölndal omlastning','Lerum omlastning']],
    ['MC-SEED-201','201','Obrännbart verksamhetsavfall','Avfall som inte går att bränna eller som inte är lämpligt att bränna. Betong, kakel, glas, metaller, minerit, kassaskåp, blåbetong.',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-301','301','Avfall till sortering','Avfall till sortering innehåller både brännbart- och obrännbart material och kräver sortering och krossning före det slutbehandlas. Vid sorteringen tas allt som kan material- eller energiåtervinnas tillvara.',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-402','402','Wellpapp','Emballage av wellpapp, wellpappkartonger.',['Skräppekärr/Rödingen']],
    ['MC-SEED-406','406','Behandlat trä','Trä som behandlats på något sätt, dock ej impregnerat trä.',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-407','407','Skrot','Återvinningsbart skrot och metall',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-466','466','Obehandlat trä','Omålat och obehandlat trä.',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-610','610','Ris','Ris, kvistar grövre än 3 cm, mindre stammar än 25 cm i diameter',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-611','611','Komposterbart trädgårdsavfall','Organiskt avfall från trädgårdar, jordbruk,markentreprenad. Mindre än 3 cm i diameter på kvistar.',['Marieholm','Kläpp','Munkegärde','Högsbo']],
    ['MC-SEED-700','700','Styckegods Elektronik','Elektronik.',['Skräppekärr/Rödingen']],
    ['MC-SEED-750','750','Riskavfall','Avfall som kan medföra risk för ohälsa eller olycksfall. Skärande och stickande avfall, smittförande avfall.',['Sävenäs risk-och sekretessmottagning']],
    ['MC-SEED-910','910','Gips rent','Ny och begagnad gips. Enstaka trä-och metallreglar kan förekomma',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-925','925','Stenmaterial, rent','Utan armering. Max storlek 35 cm.',['Skräppekärr','Högsbo','Munkegärde','Kläpp']],
    ['MC-SEED-930','930','Stenmaterial, blandat','Utan armering, Makadam, mursten, tegelsten, takpannor, lecablock, oarmerad betong, porslin, glas, gips<10%. del av fraktionen är större än 35 cm, max Minerit-/Cemberit-skivor får inte överskrida 1-1,5 meter',['Skräppekärr','Högsbo','Munkegärde','Kläpp','Tagene deponi']]
  ]);
  function reception(name, index) { return { id: `REC-${index + 1}`, name, placeId: '' }; }
  function seedRegistry(now = new Date().toISOString()) { return { schemaVersion: SCHEMA_VERSION, revision: 0, initializedAt: now, updatedAt: now, items: SEED.map(([id, code, wasteType, consistsOf, receptions]) => ({ id, code, wasteType, consistsOf, receptions: receptions.map(reception), seed: true, active: true, createdAt: now, updatedAt: now })), [LINK_KEY]: [] }; }
  function normalizeReception(raw, index) { const item = plain(raw) ? raw : {}; return { id: text(item.id) || `REC-${index + 1}`, name: text(item.name), placeId: text(item.placeId) }; }
  function normalizeItem(raw, now) { const item = plain(raw) ? raw : {}; return { id: text(item.id) || createId(), code: text(item.code), wasteType: text(item.wasteType), consistsOf: text(item.consistsOf), receptions: (Array.isArray(item.receptions) ? item.receptions : []).map(normalizeReception).filter((entry) => entry.name), seed: item.seed === true, active: item.active !== false, createdAt: text(item.createdAt, now), updatedAt: text(item.updatedAt, now) }; }
  function normalizeLink(raw) { const item = plain(raw) ? raw : {}; return { materialCodeId: text(item.materialCodeId), jobTypeId: text(item.jobTypeId) }; }
  function validateRegistry(registry) {
    if (!plain(registry) || registry.schemaVersion !== SCHEMA_VERSION || !Number.isInteger(registry.revision) || registry.revision < 0 || !text(registry.initializedAt) || !text(registry.updatedAt) || !Array.isArray(registry.items) || !Array.isArray(registry[LINK_KEY])) throw new Error('Materialkodsregistret har fel format.');
    const ids = new Set();
    registry.items.forEach((item) => { if (!plain(item) || !text(item.id) || ids.has(text(item.id)) || !text(item.code) || !text(item.wasteType) || !Array.isArray(item.receptions) || typeof item.active !== 'boolean' || typeof item.seed !== 'boolean' || !text(item.createdAt) || !text(item.updatedAt)) throw new Error('Materialkodsregistret saknar giltiga materialposter.'); ids.add(text(item.id)); const receptionIds = new Set(); item.receptions.forEach((entry) => { if (!plain(entry) || !text(entry.id) || receptionIds.has(text(entry.id)) || !text(entry.name) || typeof entry.placeId !== 'string') throw new Error('Materialkodens mottagningar har fel format.'); receptionIds.add(text(entry.id)); }); });
    const linkKeys = new Set(); registry[LINK_KEY].forEach((link) => { const key = `${text(link && link.materialCodeId)}|${text(link && link.jobTypeId)}`; if (!plain(link) || !text(link.materialCodeId) || !text(link.jobTypeId) || !ids.has(text(link.materialCodeId)) || linkKeys.has(key)) throw new Error('Materialkodsrelationen är ogiltig.'); linkKeys.add(key); });
    return true;
  }
  function validateReferences(registry, jobTypeRegistry, placeRegistry, beachRegistry) {
    validateRegistry(registry);
    if (!plain(jobTypeRegistry) || !Array.isArray(jobTypeRegistry.items) || !plain(placeRegistry) || !Array.isArray(placeRegistry.items) || !plain(beachRegistry) || !Array.isArray(beachRegistry.items)) throw new Error('Registerpaketet saknar fullständiga korsreferenser.');
    const jobTypeIds = new Set(jobTypeRegistry.items.map((item) => text(item && item.id)).filter(Boolean)); const placeIds = new Set(placeRegistry.items.map((item) => text(item && item.id)).filter(Boolean)); const beachIds = new Set(beachRegistry.items.map((item) => text(item && item.id)).filter(Boolean));
    registry[LINK_KEY].forEach((link) => { if (!jobTypeIds.has(text(link.jobTypeId))) throw new Error('Materialkodsrelationen refererar en saknad Jobbtyp.'); });
    registry.items.forEach((item) => item.receptions.forEach((entry) => { if (text(entry.placeId) && beachIds.has(text(entry.placeId))) throw new Error('Materialkodens mottagning refererar en saknad eller ogiltig Plats.'); }));
    return true;
  }
  function migrateRegistry(stored, now = new Date().toISOString()) { if (typeof stored === 'undefined' || stored === null) return { registry: seedRegistry(now), migrated: true, seeded: true }; validateRegistry(stored); return { registry: clone(stored), migrated: false, seeded: false }; }
  function withRegistry(current, items, links, now = new Date().toISOString()) { const next = { ...current, schemaVersion: SCHEMA_VERSION, revision: Math.max(0, Number(current.revision) || 0) + 1, updatedAt: now, items: items.map((item) => normalizeItem(item, now)), [LINK_KEY]: links.map(normalizeLink) }; validateRegistry(next); return next; }
  function materialLabel(item) { return `${text(item && item.code)} – ${text(item && item.wasteType)}`; }
  function byId(registry, id) { return registry && registry.items.find((item) => text(item.id) === text(id)) || null; }
  function linkedToJobType(registry, jobTypeId) { const ids = new Set((registry && registry[LINK_KEY] || []).filter((link) => text(link.jobTypeId) === text(jobTypeId)).map((link) => text(link.materialCodeId))); return (registry && registry.items || []).filter((item) => item.active !== false && ids.has(item.id)); }
  function linkedToPlace(registry, placeId) { return (registry && registry.items || []).filter((item) => item.active !== false && item.receptions.some((entry) => text(entry.placeId) === text(placeId))); }
  function linkedJobTypes(registry, materialCodeId) { return (registry && registry[LINK_KEY] || []).filter((link) => text(link.materialCodeId) === text(materialCodeId)).map((link) => text(link.jobTypeId)); }
  function snapshot(registry, materialCodeId, selectedPlace) { const item = byId(registry, materialCodeId); if (!item) return {}; const reception = item.receptions.find((entry) => text(entry.placeId) && text(entry.placeId) === text(selectedPlace && selectedPlace.id)) || null; return { id: item.id, code: item.code, wasteType: item.wasteType, receptionPlaceId: reception ? reception.placeId : '', receptionName: reception ? reception.name : '', facilityPlaceId: reception ? reception.placeId : '', facilityPlaceName: reception ? reception.name : '' }; }
  window.StadslassMaterialCodeRegistry = Object.freeze({ SCHEMA_VERSION, SETTINGS_KEY, LINK_KEY, SEED, seedRegistry, migrateRegistry, validateRegistry, validateReferences, withRegistry, byId, materialLabel, linkedToJobType, linkedToPlace, linkedJobTypes, snapshot, createId, clone });
})();
