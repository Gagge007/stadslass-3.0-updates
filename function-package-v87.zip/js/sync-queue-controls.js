(function () {
  'use strict';
  const TERMINAL = new Set(['succeeded', 'failed_permanent', 'conflict', 'superseded']);
  const ACTIVE = new Set(['pending', 'running', 'accepted', 'failed_retryable', 'retryable']);
  const JOURNAL_KIND = 'sync-v69-terminal-journal';
  const REQUEST_KIND = 'sync-v63-request';

  const text = (value) => typeof value === 'string' ? value : (value === undefined || value === null ? '' : String(value));
  const dateMs = (value) => {
    const parsed = Date.parse(text(value));
    return Number.isFinite(parsed) ? parsed : 0;
  };
  function requestView(entry, nowMs, staleSeconds) {
    const request = entry && entry.request && typeof entry.request === 'object' ? entry.request : {};
    const createdAt = text(entry && entry.createdAt);
    const ageSeconds = createdAt ? Math.max(0, Math.floor((nowMs - dateMs(createdAt)) / 1000)) : 0;
    const state = text(entry && entry.state);
    const terminal = TERMINAL.has(state);
    const stale = ACTIVE.has(state) && ageSeconds >= staleSeconds;
    return {
      key: `request:${text(entry && entry.id)}`,
      source: 'request',
      id: text(entry && entry.id), requestId: text(entry && entry.requestId), intent: text(entry && entry.intent),
      operation: text(request.operation), path: text(request.path), createdAt, ageSeconds, state,
      errorCode: text(entry && entry.result && entry.result.errorCode, text(entry && entry.errorCode)),
      error: text(entry && entry.result && (entry.result.error || entry.result.message), text(entry && entry.error)),
      stuck: terminal || stale,
      reason: terminal ? 'Terminalt tekniskt svar' : (stale ? 'Föråldrad teknisk request' : '')
    };
  }
  function journalView(item, journalId, nowMs) {
    const createdAt = text(item && (item.createdAt || item.completedAt));
    return {
      key: `journal:${journalId}:${text(item && item.requestId)}`,
      source: 'journal', journalId, requestId: text(item && item.requestId), intent: text(item && item.intent),
      operation: text(item && item.operation), path: text(item && item.path), createdAt,
      ageSeconds: createdAt ? Math.max(0, Math.floor((nowMs - dateMs(createdAt)) / 1000)) : 0,
      state: text(item && item.state), errorCode: text(item && item.errorCode), error: '',
      stuck: TERMINAL.has(text(item && item.state)), reason: 'Terminalt tekniskt svar'
    };
  }
  function inspect(entries, nowMs = Date.now(), staleSeconds = 120) {
    const input = Array.isArray(entries) ? entries : [];
    const records = [];
    input.forEach((entry) => {
      if (!entry || typeof entry !== 'object') return;
      if (entry.kind === REQUEST_KIND) records.push(requestView(entry, nowMs, staleSeconds));
      if (entry.kind === JOURNAL_KIND && Array.isArray(entry.items)) entry.items.forEach((item) => records.push(journalView(item, text(entry.id), nowMs)));
    });
    records.sort((a, b) => dateMs(b.createdAt) - dateMs(a.createdAt));
    return { records, stuck: records.filter((record) => record.stuck), waiting: records.filter((record) => !record.stuck) };
  }
  function clearStuck(entries, nowMs = Date.now(), staleSeconds = 120) {
    const inspected = inspect(entries, nowMs, staleSeconds);
    const requestIds = new Set(inspected.stuck.filter((record) => record.source === 'request').map((record) => record.id));
    const journalKeys = new Set(inspected.stuck.filter((record) => record.source === 'journal').map((record) => `${record.journalId}:${record.requestId}`));
    const next = (Array.isArray(entries) ? entries : []).flatMap((entry) => {
      if (!entry || typeof entry !== 'object') return [entry];
      if (entry.kind === REQUEST_KIND && requestIds.has(text(entry.id))) return [];
      if (entry.kind !== JOURNAL_KIND || !Array.isArray(entry.items)) return [entry];
      const items = entry.items.filter((item) => !journalKeys.has(`${text(entry.id)}:${text(item && item.requestId)}`));
      return items.length ? [{ ...entry, items, updatedAt: new Date(nowMs).toISOString() }] : [];
    });
    return { next, removed: inspected.stuck.length, inspected };
  }
  window.StadslassSyncQueueControls = Object.freeze({ inspect, clearStuck, TERMINAL, ACTIVE, JOURNAL_KIND, REQUEST_KIND });
})();
