(() => {
  'use strict';
  const ENDPOINT = 'https://stadslass.local/host-api/google/routes';
  const GEOCODE_ENDPOINT = 'https://stadslass.local/host-api/google/geocode';
  const DRIVE_PHASES = Object.freeze(['start_route', 'transport', 'return_transport']);
  const REFRESH_MS = 120000;
  const MOTION_SPEED_KMH = 5;
  const MOTION_DISTANCE_METERS = 50;
  const MOTION_WINDOW_MS = 60000;
  const text = (value) => typeof value === 'string' ? value.trim() : '';
  const valid = (point) => point && Number.isFinite(Number(point.latitude)) && Number.isFinite(Number(point.longitude))
    && Number(point.latitude) >= -90 && Number(point.latitude) <= 90 && Number(point.longitude) >= -180 && Number(point.longitude) <= 180;
  const distance = (a, b) => {
    if (!valid(a) || !valid(b)) return 0;
    const r = 6371000, toRad = Math.PI / 180;
    const dLat = (Number(b.latitude) - Number(a.latitude)) * toRad;
    const dLon = (Number(b.longitude) - Number(a.longitude)) * toRad;
    const x = Math.sin(dLat / 2) ** 2 + Math.cos(Number(a.latitude) * toRad) * Math.cos(Number(b.latitude) * toRad) * Math.sin(dLon / 2) ** 2;
    return 2 * r * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  };
  const speedKmh = (before, after) => {
    if (!before || !after || !Number.isFinite(before.timestamp) || !Number.isFinite(after.timestamp)) return 0;
    const delta = Math.max(1, after.timestamp - before.timestamp);
    return distance(before, after) / delta * 3600;
  };
  function motionProven(before, after) {
    if (!before || !after || Number(after.accuracy) > 50) return false;
    const elapsed = Number(after.timestamp) - Number(before.timestamp);
    return speedKmh(before, after) > MOTION_SPEED_KMH || (elapsed > 0 && elapsed <= MOTION_WINDOW_MS && distance(before, after) >= MOTION_DISTANCE_METERS);
  }
  function shouldRefresh(state, phase, before, snapshot, now = Date.now(), immediate = false) {
    if (!DRIVE_PHASES.includes(phase) || !valid(snapshot)) return false;
    if (immediate || !state || text(state.phase) !== phase || !Number.isFinite(Number(state.lastAttemptAtEpochMs))) return true;
    return now - Number(state.lastAttemptAtEpochMs) >= REFRESH_MS && motionProven(before, snapshot);
  }
  async function fetchDistance(origin, destination, fetchImpl = fetch) {
    if (!valid(origin) || !valid(destination)) throw new Error('ROUTE_COORDINATES_MISSING');
    if (distance(origin, destination) < 1) return 0;
    const coordinate = (point) => `${Number(point.latitude).toFixed(6)},${Number(point.longitude).toFixed(6)}`;
    const response = await fetchImpl(`${ENDPOINT}?origin=${encodeURIComponent(coordinate(origin))}&destination=${encodeURIComponent(coordinate(destination))}`, { method: 'GET', credentials: 'omit', cache: 'no-store' });
    if (!response || !response.ok) {
      const error = new Error(`ROUTES_HTTP_${response && response.status ? response.status : 0}`);
      error.category = 'http_error'; error.httpStatus = Number(response && response.status) || 0; throw error;
    }
    let payload;
    try { payload = await response.json(); } catch (cause) { const error = new Error('ROUTES_JSON_INVALID'); error.category = 'invalid_json'; throw error; }
    const meters = Number(payload && payload.distanceMeters);
    if (!Number.isFinite(meters) || meters < 0) { const error = new Error('ROUTES_RESPONSE_INVALID'); error.category = 'invalid_distance'; throw error; }
    return { meters: Math.round(meters), duration: text(payload && payload.duration) };
  }
  async function geocode(address, fetchImpl = fetch) {
    const value = text(address);
    if (!value) throw new Error('GEOCODE_ADDRESS_MISSING');
    const response = await fetchImpl(`${GEOCODE_ENDPOINT}?address=${encodeURIComponent(value)}`, { method: 'GET', credentials: 'omit', cache: 'no-store' });
    if (!response || !response.ok) { const error = new Error(`GEOCODE_HTTP_${response && response.status ? response.status : 0}`); error.category = 'geocode_failed'; error.httpStatus = Number(response && response.status) || 0; throw error; }
    let payload;
    try { payload = await response.json(); } catch (cause) { const error = new Error('GEOCODE_JSON_INVALID'); error.category = 'geocode_failed'; throw error; }
    const point = { latitude: Number(payload && payload.latitude), longitude: Number(payload && payload.longitude) };
    if (!payload || payload.ok !== true || !valid(point)) { const error = new Error('GEOCODE_RESPONSE_INVALID'); error.category = 'geocode_failed'; throw error; }
    return point;
  }
  const formatDistance = (meters) => !Number.isFinite(Number(meters)) ? '–' : (Number(meters) < 1000 ? `${Math.round(Number(meters))} m` : `${(Number(meters) / 1000).toLocaleString('sv-SE', { maximumFractionDigits: 1 })} km`);
  window.StadslassRoutesService = Object.freeze({ ENDPOINT, GEOCODE_ENDPOINT, DRIVE_PHASES, REFRESH_MS, valid, distance, motionProven, shouldRefresh, fetchDistance, geocode, formatDistance });
})();
