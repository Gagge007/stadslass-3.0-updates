(() => {
  'use strict';

  const SCHEMA_VERSION = 2;
  const PACKAGE_VERSION = 52;
  const SETTINGS_KEY = 'quickChoiceRegistryV1';
  const STABLE_JOB_TYPE_ID = /^JT3-[0-9a-f]{32}$/;
  const CANONICAL_JOB_TYPE_ID = /^JT-[0-9]{4}$/;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function normalizedName(value) {
    return text(value).replace(/\s+/g, ' ').toLocaleLowerCase('sv-SE');
  }

  function bool(value) {
    return value === true;
  }

  function createId(prefix = 'quick-choice') {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') window.crypto.getRandomValues(random);
    else {
      random[0] = Math.floor(Math.random() * 0xffffffff);
      random[1] = Math.floor(Math.random() * 0xffffffff);
    }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function resolveJobTypeReference(reference, jobTypes) {
    const item = isPlainObject(reference) ? reference : { jobTypeId: reference };
    const typeList = Array.isArray(jobTypes) ? jobTypes : [];
    const id = text(item.jobTypeId, text(item.id));
    const canonicalId = text(item.jobTypeCanonicalId, text(item.canonicalTypeId, text(item.legacyId)));
    const fallbackName = text(item.jobTypeName, text(item.jobType, text(item.name)));

    if (id) {
      const stableMatch = typeList.find((candidate) => candidate && text(candidate.id) === id);
      if (stableMatch) return { status: 'resolved', jobType: stableMatch, mode: 'stable-id' };
    }

    for (const candidateId of [canonicalId, id].filter(Boolean)) {
      const canonicalMatch = typeList.find((candidate) => candidate && text(candidate.canonicalTypeId) === candidateId);
      if (canonicalMatch) return { status: 'resolved', jobType: canonicalMatch, mode: 'canonical-id' };
    }

    const nameCandidates = [];
    if (fallbackName) nameCandidates.push(normalizedName(fallbackName));
    if (id && !STABLE_JOB_TYPE_ID.test(id) && !CANONICAL_JOB_TYPE_ID.test(id)) nameCandidates.push(normalizedName(id));
    const keys = Array.from(new Set(nameCandidates.filter(Boolean)));
    if (keys.length === 0) return { status: 'missing', jobType: null, mode: '' };
    const matches = typeList.filter((candidate) => {
      const names = [candidate && candidate.name].concat(Array.isArray(candidate && candidate.aliases) ? candidate.aliases : []);
      return names.some((name) => keys.includes(normalizedName(name)));
    });
    if (matches.length === 1) return { status: 'resolved', jobType: matches[0], mode: 'exact-name-or-alias' };
    if (matches.length > 1) return { status: 'ambiguous', jobType: null, mode: 'exact-name-or-alias' };
    return { status: 'missing', jobType: null, mode: '' };
  }

  function normalizeItem(raw, now = new Date().toISOString()) {
    const source = isPlainObject(raw) ? raw : {};
    const returnRequired = bool(source.returnRequired);
    return {
      schemaVersion: SCHEMA_VERSION,
      quickChoiceId: text(source.quickChoiceId, text(source.id)) || createId(),
      buttonName: text(source.buttonName, text(source.name)),
      buttonNameCustomized: source.buttonNameCustomized === true,
      jobTypeId: text(source.jobTypeId),
      jobTypeName: text(source.jobTypeName, text(source.jobType, text(source.jobTypeDisplayName))),
      fromPlaceId: text(source.fromPlaceId),
      toPlaceId: text(source.toPlaceId, text(source.destinationPlaceId)),
      returnRequired,
      returnPlaceId: returnRequired ? text(source.returnPlaceId, text(source.fromPlaceId)) : '',
      multiLoad: !returnRequired && bool(source.multiLoad),
      comment: text(source.comment, text(source.note)),
      createdAt: text(source.createdAt, now),
      updatedAt: text(source.updatedAt, now)
    };
  }

  function emptyRegistry(now = new Date().toISOString()) {
    return {
      schemaVersion: SCHEMA_VERSION,
      revision: 0,
      createdAt: now,
      updatedAt: now,
      items: []
    };
  }

  function validateItem(item) {
    if (!isPlainObject(item)) throw new Error('Snabbvalsregistret innehåller en ogiltig post.');
    if (Number(item.schemaVersion) !== SCHEMA_VERSION) throw new Error('Ett snabbval har fel schema.');
    if (!text(item.quickChoiceId)) throw new Error('Ett snabbval saknar stabilt ID.');
    if (!text(item.buttonName)) throw new Error('Ett snabbval saknar Knappnamn.');
    if (!text(item.jobTypeId)) throw new Error('Ett snabbval saknar Jobbtyp.');
    if (item.returnRequired === true && !text(item.returnPlaceId)) throw new Error('Ett snabbval med returkrav saknar Returplats.');
    if (item.returnRequired === true && item.multiLoad === true) throw new Error('Retur och Flerlass kan inte vara aktiva samtidigt i samma snabbval.');
    if (text(item.comment).length > 500) throw new Error('Kommentar i ett snabbval får vara högst 500 tecken.');
    return true;
  }

  function validateRegistry(registry) {
    if (!isPlainObject(registry)) throw new Error('Snabbvalsregistret har fel format.');
    if (Number(registry.schemaVersion) !== SCHEMA_VERSION) throw new Error('Snabbvalsregistret har fel schemaversion.');
    if (!Array.isArray(registry.items)) throw new Error('Snabbvalsregistret saknar en giltig lista.');
    const ids = new Set();
    registry.items.forEach((item) => {
      validateItem(item);
      const id = text(item.quickChoiceId);
      if (ids.has(id)) throw new Error('Snabbvalsregistret innehåller dubbla stabila ID:n.');
      ids.add(id);
    });
    return true;
  }

  function migrateRegistry(stored, jobTypesOrNow = [], optionalNow = '') {
    const jobTypes = Array.isArray(jobTypesOrNow) ? jobTypesOrNow : [];
    const now = Array.isArray(jobTypesOrNow)
      ? text(optionalNow, new Date().toISOString())
      : text(jobTypesOrNow, new Date().toISOString());
    if (typeof stored === 'undefined' || stored === null) {
      return { registry: emptyRegistry(now), migrated: false, sourceSchemaVersion: 0, normalizedJobTypeCount: 0, unresolvedJobTypeCount: 0 };
    }
    if (!isPlainObject(stored)) throw new Error('Snabbvalsregistret har fel format och har inte ändrats.');
    const sourceItems = Array.isArray(stored.items) ? stored.items : [];
    let normalizedJobTypeCount = 0;
    let unresolvedJobTypeCount = 0;
    const items = sourceItems.map((raw) => {
      const item = normalizeItem(raw, now);
      if (jobTypes.length === 0) return item;
      const resolution = resolveJobTypeReference(item, jobTypes);
      if (resolution.status !== 'resolved' || !resolution.jobType) {
        unresolvedJobTypeCount += 1;
        return item;
      }
      const stableId = text(resolution.jobType.id);
      const currentName = text(resolution.jobType.name);
      if (item.jobTypeId !== stableId || item.jobTypeName !== currentName) normalizedJobTypeCount += 1;
      return { ...item, jobTypeId: stableId, jobTypeName: currentName };
    });
    const registry = {
      schemaVersion: SCHEMA_VERSION,
      revision: Math.max(0, Number(stored.revision) || 0),
      createdAt: text(stored.createdAt, now),
      updatedAt: text(stored.updatedAt, now),
      items
    };
    validateRegistry(registry);
    return {
      registry,
      migrated: Number(stored.schemaVersion) !== SCHEMA_VERSION || JSON.stringify(registry) !== JSON.stringify(stored),
      sourceSchemaVersion: Number(stored.schemaVersion) || 0,
      normalizedJobTypeCount,
      unresolvedJobTypeCount
    };
  }

  function normalizedInput(input, current, now) {
    const source = isPlainObject(input) ? input : {};
    const returnRequired = source.returnRequired === true;
    return normalizeItem({
      ...(isPlainObject(current) ? current : {}),
      quickChoiceId: text(current && current.quickChoiceId) || text(source.quickChoiceId) || createId(),
      buttonName: source.buttonName,
      buttonNameCustomized: source.buttonNameCustomized === true,
      jobTypeId: source.jobTypeId,
      jobTypeName: source.jobTypeName,
      fromPlaceId: source.fromPlaceId,
      toPlaceId: source.toPlaceId,
      returnRequired,
      returnPlaceId: returnRequired ? text(source.returnPlaceId, text(source.fromPlaceId)) : '',
      multiLoad: !returnRequired && source.multiLoad === true,
      comment: source.comment,
      createdAt: text(current && current.createdAt, now),
      updatedAt: now
    }, now);
  }

  function assertUniqueButtonName(item, items) {
    const key = text(item.buttonName).toLocaleLowerCase('sv-SE');
    const fromId = text(item.fromPlaceId);
    const duplicate = items.some((candidate) => text(candidate.quickChoiceId) !== text(item.quickChoiceId)
      && text(candidate.fromPlaceId) === fromId
      && text(candidate.buttonName).toLocaleLowerCase('sv-SE') === key);
    if (duplicate) throw new Error('Det finns redan ett snabbval med samma Knappnamn under denna Från-plats.');
  }

  function createItem(input, items, now = new Date().toISOString()) {
    const item = normalizedInput(input, null, now);
    validateItem(item);
    assertUniqueButtonName(item, Array.isArray(items) ? items : []);
    return item;
  }

  function updateItem(current, input, items, now = new Date().toISOString()) {
    if (!isPlainObject(current)) throw new Error('Snabbvalet som skulle redigeras saknas.');
    const item = normalizedInput(input, current, now);
    validateItem(item);
    assertUniqueButtonName(item, Array.isArray(items) ? items : []);
    return item;
  }

  function removeItem(id, items) {
    const target = text(id);
    if (!target) throw new Error('Snabbvalet som skulle tas bort saknar ID.');
    const source = Array.isArray(items) ? items : [];
    if (!source.some((item) => text(item.quickChoiceId) === target)) throw new Error('Snabbvalet som skulle tas bort finns inte längre.');
    return source.filter((item) => text(item.quickChoiceId) !== target);
  }

  function withItems(registry, items, now = new Date().toISOString()) {
    const next = {
      ...registry,
      schemaVersion: SCHEMA_VERSION,
      revision: Math.max(0, Number(registry && registry.revision) || 0) + 1,
      updatedAt: now,
      items: Array.isArray(items) ? items.map((item) => normalizeItem(item, now)) : []
    };
    validateRegistry(next);
    return next;
  }

  function referenceStatus(item, jobTypes, places, isOtherActivity) {
    const placeList = Array.isArray(places) ? places : [];
    const resolution = resolveJobTypeReference(item, jobTypes);
    const jobType = resolution.status === 'resolved' ? resolution.jobType : null;
    const otherActivity = Boolean(jobType && typeof isOtherActivity === 'function' && isOtherActivity(jobType));
    const fromPlace = otherActivity ? null : (placeList.find((candidate) => candidate && text(candidate.id) === text(item.fromPlaceId)) || null);
    const toPlace = otherActivity ? null : (placeList.find((candidate) => candidate && text(candidate.id) === text(item.toPlaceId)) || null);
    const returnPlace = item.returnRequired === true
      ? (placeList.find((candidate) => candidate && text(candidate.id) === text(item.returnPlaceId)) || null)
      : null;
    const issues = [];
    if (!jobType || jobType.active === false || jobType.hidden === true) issues.push('Jobbtyp saknas eller är inte tillgänglig');
    if (!otherActivity && (!fromPlace || fromPlace.active === false || fromPlace.hidden === true)) issues.push('Från-plats saknas eller är inte tillgänglig');
    if (!otherActivity && (!toPlace || toPlace.active === false || toPlace.hidden === true)) issues.push('Till-plats saknas eller är inte tillgänglig');
    if (item.returnRequired === true && (!returnPlace || returnPlace.active === false || returnPlace.hidden === true)) issues.push('Returplats saknas eller är inte tillgänglig');
    return {
      valid: issues.length === 0,
      issues,
      jobType,
      jobTypeResolution: resolution,
      otherActivity,
      fromPlace,
      toPlace,
      returnPlace,
      groupName: otherActivity ? 'Övrig verksamhet' : text(fromPlace && fromPlace.name, 'Från-plats saknas')
    };
  }

  const api = {
    SCHEMA_VERSION,
    PACKAGE_VERSION,
    SETTINGS_KEY,
    emptyRegistry,
    migrateRegistry,
    validateRegistry,
    validateItem,
    createItem,
    updateItem,
    removeItem,
    withItems,
    referenceStatus,
    resolveJobTypeReference
  };

  window.StadslassQuickChoiceRegistry = Object.freeze(api);
})();
