(() => {
  'use strict';

  const PACKAGE_VERSION = 164;
  const NATIVE_STORAGE_API_VERSION = 1;
  const STORAGE_SCHEMA_VERSION = 1;
  const STAGING_API_VERSION = 1;
  const MIGRATION_SCHEMA_VERSION = 1;
  const MIGRATION_KEY = 'nativeStorageMigrationV1';
  const CATEGORIES = Object.freeze(['history', 'registries', 'learning', 'sync-history', 'trash', 'persistent-user-data']);
  const REGISTRY_KEYS = Object.freeze([
    'editableJobTypeRegistryV1', 'editablePlaceRegistryV1', 'editableBeachRegistryV1', 'quickChoiceRegistryV1', 'machines'
  ]);
  const SYNC_KEYS = Object.freeze([
    'driftHandshakeV1', 'syncV63', 'mailboxV1', 'historySyncV1', 'pendingRegistryPackage', 'acceptedMobileAssignmentsV1'
  ]);
  const TECHNICAL_KEYS = Object.freeze([
    'settingsSchemaVersion', 'settingsUpdatedByPackageVersion', MIGRATION_KEY
  ]);
  const SECRET_KEYS = Object.freeze([
    'googleServiceV1', 'googleServiceSettingsV1', 'syncV63ConfigurationV1', 'syncConfigurationV1', 'githubToken', 'apiKey', 'privateKey'
  ]);
  const RECEIPT_STORE_KEY = 'receiptStoreV1';
  const SYNC_OUTBOX_STORE = 'syncOutbox';
  const HISTORY_STORE = 'history';
  const SETTINGS_STORE = 'settings';

  const clone = (value) => value == null ? value : JSON.parse(JSON.stringify(value));
  const plain = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const text = (value, fallback = '') => { const normalized = typeof value === 'string' ? value.trim() : ''; return normalized || fallback; };
  const array = (value) => Array.isArray(value) ? value : [];

  let migrationSnapshot = null;
  let active = false;
  let lastError = null;
  let diagnosticsState = {
    schemaVersion: 1,
    packageVersion: PACKAGE_VERSION,
    nativeStorageApiVersion: NATIVE_STORAGE_API_VERSION,
    storageSchemaVersion: STORAGE_SCHEMA_VERSION,
    stagingApiVersion: STAGING_API_VERSION,
    adapterStatus: 'not-started',
    migration: {},
    syncPausedByMigration: true,
    syncReactivatedAt: '',
    staging: { transfers: [], lastError: null },
    lastError: null
  };

  function host() {
    if (!window.StadslassHost || typeof window.StadslassHost !== 'object') throw new Error('Host24-bryggan saknas.');
    return window.StadslassHost;
  }

  function parseResult(raw, label) {
    let value;
    try { value = JSON.parse(String(raw || '')); } catch (_) { throw new Error(`${label} gav ogiltig JSON.`); }
    if (!plain(value) || value.ok !== true) {
      const code = text(value && value.code, 'unknown_error');
      const message = text(value && value.message, `${label} misslyckades.`);
      const error = new Error(`${message} [${code}]`);
      error.code = code;
      error.step = text(value && value.step);
      throw error;
    }
    return value;
  }

  function nativeRequest(operation, body = {}) {
    const bridge = host();
    if (typeof bridge.requestNativeStorage !== 'function') throw new Error('Host24 native storage-brygga saknas.');
    const request = {
      nativeStorageApiVersion: NATIVE_STORAGE_API_VERSION,
      storageSchemaVersion: STORAGE_SCHEMA_VERSION,
      operation,
      ...body
    };
    return parseResult(bridge.requestNativeStorage(JSON.stringify(request)), `Native storage ${operation}`);
  }

  function stagingRequest(operation, body = {}) {
    const bridge = host();
    if (typeof bridge.requestStaging !== 'function') throw new Error('Host24 staging-brygga saknas.');
    const request = { stagingApiVersion: STAGING_API_VERSION, operation, ...body };
    try {
      const result = parseResult(bridge.requestStaging(JSON.stringify(request)), `Staging ${operation}`);
      diagnosticsState.staging.lastError = null;
      return result;
    } catch (error) {
      diagnosticsState.staging.lastError = { code: text(error.code), step: operation, message: text(error.message), at: new Date().toISOString() };
      throw error;
    }
  }

  function assertCapabilities(hostInfo) {
    const info = plain(hostInfo) ? hostInfo : {};
    if (Number(info.hostVersionCode) < 24) throw new Error('Host24 krävs för P164:s native lagring.');
    if (Number(info.nativeStorageApiVersion) !== NATIVE_STORAGE_API_VERSION) throw new Error('Host24 nativeStorageApiVersion 1 krävs.');
    if (Number(info.storageSchemaVersion) !== STORAGE_SCHEMA_VERSION) throw new Error('Host24 storageSchemaVersion 1 krävs.');
    if (Number(info.stagingApiVersion) !== STAGING_API_VERSION) throw new Error('Host24 stagingApiVersion 1 krävs.');
    if (typeof host().requestNativeStorage !== 'function' || typeof host().requestStaging !== 'function') throw new Error('Host24:s trusted native bridge är ofullständig.');
    const storage = nativeRequest('STATUS');
    const staging = stagingRequest('STATUS');
    if (Number(storage.nativeStorageApiVersion) !== 1 || Number(storage.storageSchemaVersion) !== 1) throw new Error('Host24 native storage-status är inkompatibel.');
    if (Number(staging.stagingApiVersion) !== 1) throw new Error('Host24 staging-status är inkompatibel.');
    diagnosticsState.adapterStatus = 'host-verified';
    diagnosticsState.staging.transfers = array(staging.transfers).map(clone);
    return { storage, staging };
  }

  function readLegacyStore(name, fallback) {
    const raw = host().readStore(name);
    if (!raw) return clone(fallback);
    try { return JSON.parse(raw); } catch (_) { throw new Error(`${name}-lagret innehåller ogiltig JSON.`); }
  }

  function writeLegacyStore(name, value) {
    const ok = host().writeStore(name, JSON.stringify(value));
    if (ok !== true) throw new Error((typeof host().getLastError === 'function' && host().getLastError()) || `${name}-lagret kunde inte sparas.`);
    return true;
  }

  function safeToken(value, fallback = 'item') {
    const raw = text(value) || fallback;
    const encoded = encodeURIComponent(raw).replace(/%/g, '-').replace(/[^A-Za-z0-9._:@+-]/g, '_');
    return (encoded || fallback).slice(0, 210);
  }

  function businessId(record, fallback = 'record') {
    const source = plain(record) ? record : {};
    return text(source.id) || text(source.jobId) || text(source.sourceJobId) || text(source.archiveSourceId) || fallback;
  }

  function historyEnvelopeId(kind, record, index = 0) {
    if (kind === 'receipt') return `receipt:${safeToken(record && record.id, `row-${index}`)}`;
    if (kind === 'archive') return `archive:${safeToken((record && (record.archiveSourceId || record.id || record.jobId)), `row-${index}`)}`;
    return `history:${safeToken(businessId(record, `row-${index}`))}`;
  }

  function learningId(kind, record, index = 0) {
    return `learning:${kind}:${safeToken(businessId(record, `row-${index}`))}`;
  }

  function stripLearning(record) {
    const copy = clone(plain(record) ? record : {});
    const learning = {};
    if (plain(copy.p121Learning)) learning.p121Learning = clone(copy.p121Learning);
    if (plain(copy.p116Learning)) learning.p116Learning = clone(copy.p116Learning);
    delete copy.p121Learning;
    delete copy.p116Learning;
    return { record: copy, learning: Object.keys(learning).length ? learning : null };
  }

  function isTrashed(record) {
    const state = plain(record && record.trashState) ? record.trashState : {};
    return text(state.status) === 'trashed' || Boolean(text(state.trashedAt));
  }

  function settingRecord(key, value) {
    return { id: `setting:${safeToken(key, 'setting')}`, payload: { settingKey: key, value: clone(value) } };
  }

  function classifySettings(settings) {
    const source = plain(settings) ? settings : {};
    const registries = [];
    const sync = [];
    const persistent = [];
    const technical = {};
    Object.keys(source).forEach((key) => {
      const value = source[key];
      if (key === RECEIPT_STORE_KEY) return;
      if (SECRET_KEYS.includes(key) || TECHNICAL_KEYS.includes(key)) { technical[key] = clone(value); return; }
      if (REGISTRY_KEYS.includes(key)) { registries.push(settingRecord(key, value)); return; }
      if (SYNC_KEYS.includes(key)) { sync.push(settingRecord(key, value)); return; }
      persistent.push(settingRecord(key, value));
    });
    return { registries, sync, persistent, technical };
  }

  function normalizeHistorySources(historyRecords, receiptRows, archiveRecords) {
    const history = [];
    const trash = [];
    const learning = [];
    array(historyRecords).filter(plain).forEach((item, index) => {
      const split = stripLearning(item);
      const id = historyEnvelopeId('history', split.record, index);
      const envelope = { kind: 'history', record: split.record };
      (isTrashed(split.record) ? trash : history).push({ id, payload: envelope });
      if (split.learning) learning.push({ id: learningId('history', split.record, index), payload: { sourceKind: 'history', sourceId: id, ...split.learning } });
    });
    array(receiptRows).filter(plain).forEach((row, index) => {
      const id = historyEnvelopeId('receipt', row, index);
      history.push({ id, payload: { kind: 'receipt', receiptRow: clone(row) } });
    });
    array(archiveRecords).filter(plain).forEach((item, index) => {
      const split = stripLearning(item);
      const id = historyEnvelopeId('archive', split.record, index);
      history.push({ id, payload: { kind: 'archive', record: split.record } });
      if (split.learning) learning.push({ id: learningId('archive', split.record, index), payload: { sourceKind: 'archive', sourceId: id, ...split.learning } });
    });
    return { history, trash, learning };
  }

  function syncOutboxRecords(value) {
    return array(value).filter(plain).map((item, index) => ({
      id: `sync-outbox:${safeToken(text(item.id) || text(item.requestId) || text(item.letterId), `row-${index}`)}`,
      payload: { kind: 'sync-outbox', value: clone(item), order: index }
    }));
  }

  function canonicalJson(value) {
    if (value === null || typeof value === 'undefined') return 'null';
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
    if (plain(value)) return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
    return JSON.stringify(value);
  }

  function uint32(value) {
    const out = new Uint8Array(4); new DataView(out.buffer).setUint32(0, value, false); return out;
  }
  function uint64(value) {
    const out = new Uint8Array(8); const view = new DataView(out.buffer); const n = BigInt(value); view.setUint32(0, Number((n >> 32n) & 0xffffffffn), false); view.setUint32(4, Number(n & 0xffffffffn), false); return out;
  }
  function concatBytes(parts) {
    const total = parts.reduce((sum, part) => sum + part.length, 0); const out = new Uint8Array(total); let offset = 0; parts.forEach((part) => { out.set(part, offset); offset += part.length; }); return out;
  }
  function digestString(value) {
    const bytes = new TextEncoder().encode(value); return concatBytes([uint32(bytes.length), bytes]);
  }
  async function sha256Bytes(bytes) {
    const digest = await crypto.subtle.digest('SHA-256', bytes); return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  async function sha256Text(value) { return sha256Bytes(new TextEncoder().encode(String(value))); }

  async function expectedIntegrity(category, records) {
    const ordered = array(records).map(clone).sort((a, b) => text(a.id).localeCompare(text(b.id), 'en'));
    const pieces = [digestString(`schema:${STORAGE_SCHEMA_VERSION}`), digestString(`category:${category}`)];
    let payloadBytes = 0;
    for (const row of ordered) {
      const payload = new TextEncoder().encode(canonicalJson(row.payload));
      payloadBytes += payload.length;
      pieces.push(digestString(`id:${row.id}`), uint64(payload.length), payload);
    }
    return { recordCount: ordered.length, payloadBytes, sha256: await sha256Bytes(concatBytes(pieces)) };
  }

  function listCategory(category) {
    const records = [];
    let cursor = '';
    for (;;) {
      const result = nativeRequest('LIST', { category, cursor, limit: 500 });
      array(result.records).forEach((row) => records.push({ id: text(row.id), payload: clone(row.payload), updatedAtEpochMs: Number(row.updatedAtEpochMs) || 0 }));
      if (result.hasMore !== true) break;
      cursor = text(result.nextCursor);
      if (!cursor) throw new Error(`Native ${category}: pagineringen saknar cursor.`);
    }
    return records;
  }

  function normalizeImportRecords(category, records) {
    const byId = new Map();
    for (const row of array(records)) {
      const id = text(row && row.id);
      if (!id || !row || !Object.prototype.hasOwnProperty.call(row, 'payload')) throw new Error(`Källdatan för ${category} innehåller en ogiltig post.`);
      byId.set(id, { id, payload: clone(row.payload) });
    }
    return Array.from(byId.values());
  }

  function verifyCategoryRecords(category, expectedRecords) {
    const expected = new Map(normalizeImportRecords(category, expectedRecords).map((row) => [row.id, canonicalJson(row.payload)]));
    const actual = listCategory(category);
    if (actual.length !== expected.size) return false;
    const ids = new Set();
    for (const row of actual) {
      if (!expected.has(row.id) || ids.has(row.id) || canonicalJson(row.payload) !== expected.get(row.id)) return false;
      ids.add(row.id);
    }
    return ids.size === expected.size;
  }

  async function importCategory(category, records, migrationState) {
    records = normalizeImportRecords(category, records);
    const expected = await expectedIntegrity(category, records);
    const current = nativeRequest('INTEGRITY', { category });
    if (Number(current.recordCount) === expected.recordCount && verifyCategoryRecords(category, records)) {
      return { status: 'verified', reused: true, before: Number(current.recordCount), after: expected.recordCount, importId: '' };
    }

    const existing = plain(migrationState && migrationState[category]) ? migrationState[category] : {};
    let importId = text(existing.importId);
    if (!importId || text(existing.status) !== 'running') importId = `p162-${safeToken(category)}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`.slice(0, 120);
    nativeRequest('IMPORT_BEGIN', { category, importId });
    try {
      for (let index = 0; index < records.length; index += 100) {
        nativeRequest('IMPORT_PUT', { category, importId, records: records.slice(index, index + 100) });
      }
      const shadow = nativeRequest('IMPORT_STATUS', { category, importId });
      if (text(shadow.state) !== 'active' || Number(shadow.recordCount) !== expected.recordCount) {
        throw new Error(`Verifieringen av shadowdata för ${category} misslyckades.`);
      }
      const committed = nativeRequest('IMPORT_COMMIT', { category, importId });
      if (Number(committed.recordCount) !== expected.recordCount || !verifyCategoryRecords(category, records)) {
        throw new Error(`Verifieringen efter COMMIT för ${category} misslyckades.`);
      }
      return { status: 'verified', reused: false, before: Number(current.recordCount) || 0, after: expected.recordCount, importId };
    } catch (error) {
      try { const status = nativeRequest('IMPORT_STATUS', { category, importId }); if (status.found === true && status.state === 'active') nativeRequest('IMPORT_ABORT', { category, importId }); } catch (_) {}
      throw error;
    }
  }

  function migrationMarker(settings) {
    const source = plain(settings && settings[MIGRATION_KEY]) ? clone(settings[MIGRATION_KEY]) : {};
    return {
      schemaVersion: MIGRATION_SCHEMA_VERSION,
      packageVersion: PACKAGE_VERSION,
      startedAt: text(source.startedAt) || new Date().toISOString(),
      completedAt: text(source.completedAt),
      complete: source.complete === true,
      categories: plain(source.categories) ? source.categories : {},
      lastError: plain(source.lastError) ? source.lastError : null
    };
  }

  function saveMigrationMarker(settings, marker) {
    const next = { ...(plain(settings) ? settings : {}), [MIGRATION_KEY]: clone(marker), settingsSchemaVersion: 1, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    writeLegacyStore(SETTINGS_STORE, next);
    return next;
  }

  function cleanSettingsCategory(settings, category) {
    const next = clone(plain(settings) ? settings : {});
    if (category === 'registries') REGISTRY_KEYS.forEach((key) => delete next[key]);
    if (category === 'sync-history') SYNC_KEYS.forEach((key) => delete next[key]);
    if (category === 'persistent-user-data') {
      const classified = classifySettings(next);
      classified.persistent.forEach((row) => delete next[row.payload.settingKey]);
    }
    if (category === 'history') delete next[RECEIPT_STORE_KEY];
    next.settingsSchemaVersion = 1;
    next.settingsUpdatedByPackageVersion = PACKAGE_VERSION;
    return next;
  }

  function cleanupVerifiedLegacyCategory(category, settings, marker) {
    let next = cleanSettingsCategory(settings, category);
    const now = new Date().toISOString();
    if (category === 'sync-history') writeLegacyStore(SYNC_OUTBOX_STORE, []);

    const sharedHistoryCategories = ['history', 'trash', 'learning'];
    const sharedHistoryVerified = sharedHistoryCategories.every((name) => plain(marker.categories[name]) && text(marker.categories[name].status) === 'verified');
    if (sharedHistoryVerified) {
      writeLegacyStore(HISTORY_STORE, []);
      sharedHistoryCategories.forEach((name) => {
        if (!plain(marker.categories[name])) return;
        marker.categories[name] = { ...marker.categories[name], legacySourceRetained: false, legacyCleanupAt: text(marker.categories[name].legacyCleanupAt) || now };
      });
    } else if (sharedHistoryCategories.includes(category)) {
      marker.categories[category] = { ...marker.categories[category], legacySourceRetained: true };
    } else {
      marker.categories[category] = { ...marker.categories[category], legacySourceRetained: false, legacyCleanupAt: text(marker.categories[category].legacyCleanupAt) || now };
    }
    next[MIGRATION_KEY] = clone(marker);
    writeLegacyStore(SETTINGS_STORE, next);
    return next;
  }

  async function stageLegacyPendingHistorySync(settings) {
    if (!plain(settings) || !plain(settings.historySyncV1)) return settings;
    const state = clone(settings.historySyncV1);
    let changed = false;
    const now = new Date().toISOString();
    if (plain(state.pendingPackage) && plain(state.pendingPackage.payload) && Array.isArray(state.pendingPackage.payload.records)) {
      const transferId = `legacy-history-${safeToken(text(state.pendingPackage.packageId) || Date.now().toString(36))}`.slice(0, 120);
      const legacyPackage = {
        protocol: 'stadslass.mailbox.v1', packageProtocol: 'stadslass.history.v1', kind: 'history-package',
        packageId: text(state.pendingPackage.packageId) || transferId, requestId: text(state.pendingPackage.requestId),
        from: text(state.pendingPackage.from), payload: clone(state.pendingPackage.payload)
      };
      const contentUtf8 = JSON.stringify(legacyPackage);
      const bytes = new TextEncoder().encode(contentUtf8);
      const sha = await sha256Bytes(bytes);
      stagingRequest('CREATE', { transferId });
      stagingRequest('PUT_PART', { transferId, partId: 'part-0', contentUtf8, expectedBytes: bytes.length, expectedSha256: sha });
      state.pendingPackage = {
        packageId: text(state.pendingPackage.packageId) || transferId,
        requestId: text(state.pendingPackage.requestId), from: text(state.pendingPackage.from), receivedAt: text(state.pendingPackage.receivedAt) || now,
        stagingTransferId: transferId, partCount: 1, totalRecordCount: state.pendingPackage.payload.records.length,
        stagingPartIds: ['part-0'], legacyMigratedToStaging: true
      };
      changed = true;
    }
    if (plain(state.pendingTransfer) && plain(state.pendingTransfer.parts)) {
      const source = state.pendingTransfer;
      const transferId = safeToken(text(source.transferId) || `legacy-transfer-${Date.now().toString(36)}`).slice(0, 120);
      stagingRequest('CREATE', { transferId });
      const partIds = [];
      const keys = Object.keys(source.parts).sort((a, b) => Number(a) - Number(b));
      for (const key of keys) {
        const part = source.parts[key];
        if (!plain(part) || !Array.isArray(part.records)) continue;
        const payload = {
          schemaVersion: Number(source.schemaVersion) || 2,
          exportedAt: text(source.exportedAt), sourceUnit: text(source.sourceUnit), scope: text(source.scope) || 'all-history',
          transferId, partIndex: Number(key), partCount: Number(source.partCount), totalRecordCount: Number(source.totalRecordCount), records: clone(part.records)
        };
        const legacyPackage = { protocol: 'stadslass.mailbox.v1', packageProtocol: 'stadslass.history.v1', kind: 'history-package', packageId: text(part.packageId) || `${transferId}-part-${Number(key) + 1}`, requestId: text(source.requestId), from: text(source.from), payload };
        const contentUtf8 = JSON.stringify(legacyPackage); const bytes = new TextEncoder().encode(contentUtf8); const sha = await sha256Bytes(bytes); const partId = `part-${Number(key)}`;
        stagingRequest('PUT_PART', { transferId, partId, contentUtf8, expectedBytes: bytes.length, expectedSha256: sha });
        partIds.push(partId);
      }
      state.pendingTransfer = {
        transferId, requestId: text(source.requestId), from: text(source.from), partCount: Number(source.partCount) || partIds.length,
        totalRecordCount: Number(source.totalRecordCount) || 0, receivedPartIds: partIds, receivedAt: text(source.receivedAt) || now,
        exportedAt: text(source.exportedAt), sourceUnit: text(source.sourceUnit), scope: text(source.scope) || 'all-history', legacyMigratedToStaging: true
      };
      changed = true;
    }
    if (!changed) return settings;
    return { ...settings, historySyncV1: state, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
  }

  async function migrate({ archiveRecords = [] } = {}) {
    diagnosticsState.adapterStatus = 'migrating';
    diagnosticsState.syncPausedByMigration = true;
    let settings = readLegacyStore(SETTINGS_STORE, {});
    if (!plain(settings)) throw new Error('Inställningslagret har fel format före native migration.');
    settings = await stageLegacyPendingHistorySync(settings);
    writeLegacyStore(SETTINGS_STORE, settings);
    const marker = migrationMarker(settings);
    const legacyHistory = readLegacyStore(HISTORY_STORE, []);
    if (!Array.isArray(legacyHistory)) throw new Error('Historiklagret har fel format före native migration.');
    const legacySyncOutbox = readLegacyStore(SYNC_OUTBOX_STORE, []);
    if (!Array.isArray(legacySyncOutbox)) throw new Error('SyncOutbox har fel format före native migration.');
    const receipts = array(settings[RECEIPT_STORE_KEY]);
    const classified = classifySettings(settings);
    const historical = normalizeHistorySources(legacyHistory, receipts, archiveRecords);
    const rawCategoryRecords = {
      history: historical.history,
      registries: classified.registries,
      learning: historical.learning,
      'sync-history': [...classified.sync, ...syncOutboxRecords(legacySyncOutbox)],
      trash: historical.trash,
      'persistent-user-data': classified.persistent
    };
    const categoryRecords = Object.fromEntries(Object.entries(rawCategoryRecords).map(([category, rows]) => [category, normalizeImportRecords(category, rows)]));
    migrationSnapshot = { sourceCounts: Object.fromEntries(Object.entries(categoryRecords).map(([key, value]) => [key, value.length])) };

    // Once native data is established it is the sole operational truth. This
    // recovery path is for the P159–P161 state: legacy has already been cleaned
    // while all five business-bearing native categories are present. Never
    // rebuild that data from empty legacy projections or old migration hashes.
    const nativeCounts = Object.fromEntries(CATEGORIES.map((category) => [category, Number(nativeRequest('COUNT', { category }).recordCount) || 0]));
    const establishedNativeTruth = nativeCounts.history > 0 && nativeCounts.registries > 0 && nativeCounts.learning > 0 && nativeCounts['sync-history'] > 0 && nativeCounts.trash > 0 && legacyHistory.length === 0;
    if (establishedNativeTruth) {
      const now = new Date().toISOString();
      marker.complete = true;
      marker.completedAt = text(marker.completedAt) || now;
      marker.lastError = null;
      CATEGORIES.forEach((category) => {
        const rows = listCategory(category);
        const ids = new Set(rows.map((row) => text(row.id)));
        if (rows.length !== nativeCounts[category] || ids.size !== rows.length) throw new Error(`Native kategorin ${category} kan inte läsas säkert.`);
        marker.categories[category] = { status: 'verified', step: 'native-authoritative', before: nativeCounts[category], expected: nativeCounts[category], after: nativeCounts[category], legacySourceRetained: false, error: '', updatedAt: now };
      });
      settings = saveMigrationMarker(settings, marker);
      writeLegacyStore(SETTINGS_STORE, settings);
      diagnosticsState.migration = clone(marker.categories);
      diagnosticsState.syncPausedByMigration = false;
      diagnosticsState.syncReactivatedAt = now;
      diagnosticsState.adapterStatus = 'ready';
      active = true;
      return clone(marker);
    }
    for (const category of CATEGORIES) {
      if (!plain(marker.categories[category]) || !text(marker.categories[category].status)) {
        marker.categories[category] = {
          status: 'pending', step: 'pending', before: 0, expected: categoryRecords[category].length, after: 0,
          legacySourceRetained: true, updatedAt: new Date().toISOString()
        };
      }
    }
    diagnosticsState.migration = clone(marker.categories);

    let workingSettings = saveMigrationMarker(settings, marker);

    // A verified category is never rebuilt from already-cleaned legacy stores.
    // This makes first-start migration restart-safe without introducing dual truth.
    for (const category of CATEGORIES) {
      const prior = plain(marker.categories[category]) ? marker.categories[category] : {};
      // No historic migration hash is consulted here. Normal app operation is
      // allowed to add, edit and delete native records after migration.

      const beforeStatus = nativeRequest('COUNT', { category });
      const resumableImportId = text(prior.status) === 'running' && text(prior.importId)
        ? text(prior.importId)
        : `p162-${safeToken(category)}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`.slice(0, 120);
      marker.categories[category] = {
        status: 'running', step: 'IMPORT_BEGIN', before: Number(beforeStatus.recordCount) || 0,
        expected: categoryRecords[category].length, importId: resumableImportId, updatedAt: new Date().toISOString(), legacySourceRetained: true
      };
      workingSettings = saveMigrationMarker(workingSettings, marker);
      diagnosticsState.migration = clone(marker.categories);
      let verifiedCommit = false;
      try {
        const result = await importCategory(category, categoryRecords[category], marker.categories);
        verifiedCommit = true;
        marker.categories[category] = { ...marker.categories[category], ...result, status: 'verified', step: 'verified', error: '', updatedAt: new Date().toISOString(), legacySourceRetained: true };
        // Persist verified native truth before any destructive legacy cleanup.
        workingSettings = saveMigrationMarker(workingSettings, marker);
        workingSettings = cleanupVerifiedLegacyCategory(category, workingSettings, marker);
        marker.categories[category] = { ...marker.categories[category], step: 'verified', error: '', updatedAt: new Date().toISOString() };
        workingSettings = saveMigrationMarker(workingSettings, marker);
      } catch (error) {
        if (verifiedCommit || text(marker.categories[category].status) === 'verified') {
          marker.categories[category] = { ...marker.categories[category], status: 'verified', step: 'cleanup-failed', error: text(error.message), updatedAt: new Date().toISOString(), legacySourceRetained: true };
        } else {
          marker.categories[category] = { ...marker.categories[category], status: 'failed', step: text(error.step) || 'migration', error: text(error.message), updatedAt: new Date().toISOString(), legacySourceRetained: true };
        }
        marker.lastError = { category, step: marker.categories[category].step, message: text(error.message), at: new Date().toISOString() };
        try { saveMigrationMarker(workingSettings, marker); } catch (_) {}
        diagnosticsState.migration = clone(marker.categories);
        diagnosticsState.lastError = clone(marker.lastError);
        diagnosticsState.adapterStatus = 'failed';
        lastError = error;
        throw new Error(`Native migration stoppades i ${category}: ${error.message}`);
      }
    }
    marker.complete = true;
    marker.completedAt = new Date().toISOString();
    marker.lastError = null;
    workingSettings = saveMigrationMarker(workingSettings, marker);
    diagnosticsState.migration = clone(marker.categories);
    diagnosticsState.syncPausedByMigration = false;
    diagnosticsState.syncReactivatedAt = marker.completedAt;
    diagnosticsState.adapterStatus = 'ready';
    active = true;
    return clone(marker);
  }

  function loadLearningMap() {
    const rows = listCategory('learning');
    const result = new Map();
    rows.forEach((row) => { if (plain(row.payload) && text(row.payload.sourceId)) result.set(text(row.payload.sourceId), clone(row.payload)); });
    return result;
  }

  function historyProjections() {
    const historyRows = listCategory('history');
    const trashRows = listCategory('trash');
    const learningMap = loadLearningMap();
    const ordinary = [];
    const receipts = [];
    const archive = [];
    const trash = [];
    const attachLearning = (row, envelope) => {
      const record = clone(envelope.record || {}); const learn = learningMap.get(row.id) || learningMap.get(`learning:${text(envelope.kind)}:${safeToken(businessId(record))}`);
      if (plain(learn && learn.p121Learning)) record.p121Learning = clone(learn.p121Learning);
      if (plain(learn && learn.p116Learning)) record.p116Learning = clone(learn.p116Learning);
      return record;
    };
    historyRows.forEach((row) => {
      const envelope = plain(row.payload) ? row.payload : {};
      if (envelope.kind === 'receipt' && plain(envelope.receiptRow)) receipts.push(clone(envelope.receiptRow));
      else if (envelope.kind === 'archive' && plain(envelope.record)) archive.push(attachLearning(row, envelope));
      else if (envelope.kind === 'history' && plain(envelope.record)) ordinary.push(attachLearning(row, envelope));
    });
    trashRows.forEach((row) => { const envelope = plain(row.payload) ? row.payload : {}; if (plain(envelope.record)) trash.push(attachLearning(row, envelope)); });
    return { ordinary, receipts, archive, trash, combinedHistory: [...ordinary, ...trash] };
  }

  function settingsProjection() {
    const technical = readLegacyStore(SETTINGS_STORE, {});
    const next = plain(technical) ? clone(technical) : {};
    for (const category of ['registries', 'sync-history', 'persistent-user-data']) {
      const rows = listCategory(category);
      rows.forEach((row) => {
        const payload = plain(row.payload) ? row.payload : {};
        if (text(payload.settingKey)) next[payload.settingKey] = clone(payload.value);
      });
    }
    const hp = historyProjections();
    next[RECEIPT_STORE_KEY] = hp.receipts;
    next.settingsSchemaVersion = 1;
    next.settingsUpdatedByPackageVersion = PACKAGE_VERSION;
    return next;
  }

  function writeSettingCategory(category, settings) {
    const classified = classifySettings(settings);
    const desired = category === 'registries' ? classified.registries : (category === 'sync-history' ? classified.sync : classified.persistent);
    const current = listCategory(category);
    const settingCurrentIds = current.filter((row) => plain(row.payload) && text(row.payload.settingKey)).map((row) => row.id);
    const desiredIds = new Set(desired.map((row) => row.id));
    if (desired.length) nativeRequest('BATCH_PUT', { category, records: desired });
    const remove = settingCurrentIds.filter((id) => !desiredIds.has(id));
    if (remove.length) nativeRequest('BATCH_DELETE', { category, ids: remove });
  }

  function writeSettingsProjection(settings) {
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    writeSettingCategory('registries', settings);
    writeSettingCategory('sync-history', settings);
    writeSettingCategory('persistent-user-data', settings);
    const classified = classifySettings(settings);
    const technical = { ...classified.technical, settingsSchemaVersion: 1, settingsUpdatedByPackageVersion: PACKAGE_VERSION };
    SECRET_KEYS.forEach((key) => { if (Object.prototype.hasOwnProperty.call(settings, key)) technical[key] = clone(settings[key]); });
    const prior = readLegacyStore(SETTINGS_STORE, {});
    if (plain(prior[MIGRATION_KEY])) technical[MIGRATION_KEY] = clone(prior[MIGRATION_KEY]);
    writeLegacyStore(SETTINGS_STORE, technical);
    return true;
  }

  function writeHistoryProjection(records) {
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    const desired = normalizeHistorySources(array(records), [], []);
    const currentHistory = listCategory('history');
    const retained = currentHistory.filter((row) => plain(row.payload) && ['receipt', 'archive'].includes(text(row.payload.kind)));
    const currentWritableIds = currentHistory.filter((row) => plain(row.payload) && text(row.payload.kind) === 'history').map((row) => row.id);
    const desiredHistoryIds = new Set(desired.history.map((row) => row.id));
    if (desired.history.length) nativeRequest('BATCH_PUT', { category: 'history', records: desired.history });
    const removeHistory = currentWritableIds.filter((id) => !desiredHistoryIds.has(id));
    if (removeHistory.length) nativeRequest('BATCH_DELETE', { category: 'history', ids: removeHistory });

    const currentTrash = listCategory('trash');
    const desiredTrashIds = new Set(desired.trash.map((row) => row.id));
    if (desired.trash.length) nativeRequest('BATCH_PUT', { category: 'trash', records: desired.trash });
    const removeTrash = currentTrash.map((row) => row.id).filter((id) => !desiredTrashIds.has(id));
    if (removeTrash.length) nativeRequest('BATCH_DELETE', { category: 'trash', ids: removeTrash });

    const currentLearning = listCategory('learning');
    const historyLearningIds = currentLearning.filter((row) => plain(row.payload) && text(row.payload.sourceKind) === 'history').map((row) => row.id);
    const desiredLearningIds = new Set(desired.learning.map((row) => row.id));
    if (desired.learning.length) nativeRequest('BATCH_PUT', { category: 'learning', records: desired.learning });
    const removeLearning = historyLearningIds.filter((id) => !desiredLearningIds.has(id));
    if (removeLearning.length) nativeRequest('BATCH_DELETE', { category: 'learning', ids: removeLearning });
    void retained;
    return true;
  }

  function writeReceiptRows(rows) {
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    const current = listCategory('history');
    const currentIds = current.filter((row) => plain(row.payload) && text(row.payload.kind) === 'receipt').map((row) => row.id);
    const desired = array(rows).filter(plain).map((row, index) => ({ id: historyEnvelopeId('receipt', row, index), payload: { kind: 'receipt', receiptRow: clone(row) } }));
    const desiredIds = new Set(desired.map((row) => row.id));
    if (desired.length) nativeRequest('BATCH_PUT', { category: 'history', records: desired });
    const remove = currentIds.filter((id) => !desiredIds.has(id));
    if (remove.length) nativeRequest('BATCH_DELETE', { category: 'history', ids: remove });
    return true;
  }

  function archiveRecords() { return historyProjections().archive; }
  function historyDocument() { return historyProjections().combinedHistory; }
  function receiptRows() { return historyProjections().receipts; }

  function syncOutboxRows() {
    return listCategory('sync-history')
      .filter((row) => plain(row.payload) && row.payload.kind === 'sync-outbox' && plain(row.payload.value))
      .sort((a, b) => Number(a.payload.order) - Number(b.payload.order))
      .map((row) => clone(row.payload.value));
  }

  function mergeLegacySyncOutbox(rows) {
    if (!active) throw new Error('Native lagringsadaptern är inte redo.');
    const incoming = syncOutboxRecords(rows);
    if (incoming.length) nativeRequest('BATCH_PUT', { category: 'sync-history', records: incoming });
    return true;
  }

  async function stageHistoryPackage(pkg) {
    if (!plain(pkg) || !plain(pkg.payload) || !Array.isArray(pkg.payload.records)) throw new Error('Historikpaketet är ogiltigt.');
    const payload = clone(pkg.payload);
    const transferId = safeToken(text(payload.transferId) || text(pkg.packageId), `history-${Date.now().toString(36)}`).slice(0, 120);
    const partCount = Math.max(1, Number(payload.partCount) || 1);
    const partIndex = partCount > 1 ? Number(payload.partIndex) : 0;
    if (!Number.isInteger(partIndex) || partIndex < 0 || partIndex >= partCount) throw new Error('Historikpaketets partIndex är ogiltigt.');
    const totalRecordCount = Number(payload.totalRecordCount);
    if (partCount > 1 && (!Number.isInteger(totalRecordCount) || totalRecordCount < 0)) throw new Error('Historikpaketets totalRecordCount är ogiltigt.');
    if (text(payload.transferId) && text(payload.transferId) !== transferId) throw new Error('Historikpaketets transferId är ogiltigt.');
    const expectedMultipartPackageId = partCount > 1 ? `${transferId}-part-${partIndex + 1}` : '';
    if (expectedMultipartPackageId && text(pkg.packageId) && text(pkg.packageId) !== expectedMultipartPackageId) throw new Error('Historikpaketets packageId matchar inte transfer/del.');
    if (text(pkg.kind) && text(pkg.kind) !== 'history-package') throw new Error('Historikpaketets kind är ogiltigt.');
    if (text(pkg.packageProtocol) && text(pkg.packageProtocol) !== 'stadslass.history.v1') throw new Error('Historikpaketets protokoll är ogiltigt.');
    const partId = `part-${partIndex}`;
    const contentUtf8 = JSON.stringify(pkg);
    const bytes = new TextEncoder().encode(contentUtf8);
    const sha = await sha256Bytes(bytes);
    stagingRequest('CREATE', { transferId });
    const written = stagingRequest('PUT_PART', { transferId, partId, contentUtf8, expectedBytes: bytes.length, expectedSha256: sha });
    const listing = stagingRequest('LIST', { transferId });
    if (text(listing.integrityStatus) && text(listing.integrityStatus) !== 'ok') throw new Error(`Stagingtransfern har integritetsstatus ${text(listing.integrityStatus)}.`);
    const statusAfterWrite = stagingRequest('STATUS');
    diagnosticsState.staging.transfers = array(statusAfterWrite.transfers).map((row) => {
      const copy = clone(row);
      if (text(copy.transferId) === transferId) {
        copy.receivedPartCount = Number(copy.partCount) || 0;
        copy.expectedPartCount = partCount;
        copy.totalRecordCount = Number.isInteger(totalRecordCount) ? totalRecordCount : null;
      }
      return copy;
    });
    const parts = array(listing.parts);
    const receivedIndices = parts.map((part) => Number(String(part.partId || '').replace(/^part-/, ''))).filter(Number.isInteger).sort((a, b) => a - b);
    const complete = receivedIndices.length === partCount && receivedIndices.every((value, index) => value === index);
    return {
      transferId, partId, partIndex, partCount, totalRecordCount: Number.isInteger(totalRecordCount) ? totalRecordCount : null,
      duplicate: written.duplicate === true, complete, receivedPartIds: parts.map((part) => text(part.partId)).filter(Boolean),
      totalBytes: Number(listing.totalBytes) || 0, integrityStatus: text(listing.integrityStatus), packageId: text(pkg.packageId), requestId: text(pkg.requestId), from: text(pkg.from)
    };
  }

  function readStagedHistoryPayload(meta) {
    const transferId = text(meta && meta.stagingTransferId, text(meta && meta.transferId));
    const partCount = Math.max(1, Number(meta && meta.partCount) || 1);
    if (!transferId) throw new Error('Historikens stagingtransfer saknar ID.');
    const listing = stagingRequest('LIST', { transferId });
    if (text(listing.integrityStatus) !== 'ok') throw new Error(`Historikens stagingtransfer är inte verifierad (${text(listing.integrityStatus, 'okänd')}).`);
    if (array(listing.parts).length !== partCount) throw new Error('Historikens stagingtransfer har fel antal delar.');
    const records = [];
    let first = null;
    for (let index = 0; index < partCount; index += 1) {
      const partId = `part-${index}`;
      const result = stagingRequest('READ_PART', { transferId, partId });
      let decoded;
      try { decoded = JSON.parse(result.contentUtf8); } catch (_) { throw new Error(`Historikdel ${partId} innehåller ogiltig JSON.`); }
      const wrapper = plain(decoded) && plain(decoded.payload) ? decoded : null;
      const payload = wrapper ? wrapper.payload : decoded;
      if (!plain(payload) || !Array.isArray(payload.records)) throw new Error(`Historikdel ${partId} har fel format.`);
      if (wrapper) {
        if (text(wrapper.kind, 'history-package') !== 'history-package' || text(wrapper.packageProtocol, 'stadslass.history.v1') !== 'stadslass.history.v1') throw new Error(`Historikdel ${partId} har fel paketprotokoll.`);
        const expectedPackageId = partCount > 1 ? `${transferId}-part-${index + 1}` : text(meta && meta.packageId);
        if (expectedPackageId && text(wrapper.packageId) && text(wrapper.packageId) !== expectedPackageId) throw new Error(`Historikdel ${partId} har fel packageId.`);
        if (text(meta && meta.requestId) && text(wrapper.requestId) && text(wrapper.requestId) !== text(meta.requestId)) throw new Error(`Historikdel ${partId} har fel requestId.`);
        if (text(meta && meta.from) && text(wrapper.from) && text(wrapper.from) !== text(meta.from)) throw new Error(`Historikdel ${partId} har fel avsändare.`);
      }
      const payloadTransferId = text(payload.transferId) || transferId;
      if (payloadTransferId !== transferId) throw new Error(`Historikdel ${partId} tillhör fel transfer.`);
      const declaredCount = Math.max(1, Number(payload.partCount) || 1);
      const declaredIndex = declaredCount > 1 ? Number(payload.partIndex) : 0;
      if (declaredCount !== partCount || declaredIndex !== index) throw new Error(`Historikdel ${partId} har fel delidentitet.`);
      if (!first) first = payload;
      records.push(...payload.records.map(clone));
    }
    const expectedTotal = Number(meta && meta.totalRecordCount);
    if (Number.isInteger(expectedTotal) && expectedTotal >= 0 && records.length !== expectedTotal) throw new Error('Stagingdelarna ger fel totalt antal historikposter.');
    return {
      schemaVersion: Number(first && first.schemaVersion) || 2,
      exportedAt: text(first && first.exportedAt), sourceUnit: text(first && first.sourceUnit), scope: text(first && first.scope) || 'all-history',
      transferId, partCount, totalRecordCount: records.length, records
    };
  }

  function deleteStagedTransfer(transferId) {
    if (!text(transferId)) return false;
    stagingRequest('DELETE_TRANSFER', { transferId: text(transferId) });
    const statusAfterDelete = stagingRequest('STATUS');
    diagnosticsState.staging.transfers = array(statusAfterDelete.transfers).map(clone);
    return true;
  }

  function exportCategoriesForBackup() {
    const result = {};
    for (const category of CATEGORIES) result[category] = listCategory(category).map((row) => ({ id: row.id, payload: clone(row.payload) }));
    // transient transfer state cannot be restored without staging files; strip only the temporary pending transfer/package bodies/refs.
    result['sync-history'] = result['sync-history'].map((row) => {
      if (!plain(row.payload) || row.payload.settingKey !== 'historySyncV1' || !plain(row.payload.value)) return row;
      const value = clone(row.payload.value);
      delete value.pendingTransfer;
      delete value.pendingPackage;
      return { ...row, payload: { ...row.payload, value } };
    });
    return result;
  }

  const SECRET_FIELD_NAMES = Object.freeze(new Set([
    ...SECRET_KEYS.map((key) => key.replace(/[^A-Za-z0-9]/g, '').toLocaleLowerCase('en-US')),
    'token', 'accesstoken', 'refreshtoken', 'apikey', 'privatekey', 'password', 'secret', 'credentials', 'credential', 'pem', 'jks'
  ]));

  function secretKeyName(value) {
    const key = text(value).replace(/[^A-Za-z0-9]/g, '').toLocaleLowerCase('en-US');
    return SECRET_FIELD_NAMES.has(key);
  }

  function assertNoSecrets(value, path = 'backup') {
    if (typeof value === 'string') {
      if (/AIza[0-9A-Za-z_-]{20,100}|github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9]+|-----BEGIN [^-]*PRIVATE KEY-----/.test(value)) {
        throw new Error(`Backup innehåller secret-liknande värde: ${path}`);
      }
      return;
    }
    if (Array.isArray(value)) { value.forEach((item, index) => assertNoSecrets(item, `${path}[${index}]`)); return; }
    if (!plain(value)) return;
    if (secretKeyName(value.settingKey) && value.value != null && String(value.value).trim() !== '') {
      throw new Error(`Backup innehåller förbjuden secretinställning: ${path}.${text(value.settingKey)}`);
    }
    Object.keys(value).forEach((key) => {
      if (secretKeyName(key) && value[key] != null && String(value[key]).trim() !== '') throw new Error(`Backup innehåller förbjudet secretfält: ${path}.${key}`);
      assertNoSecrets(value[key], `${path}.${key}`);
    });
  }

  async function createBackup() {
    const categories = exportCategoriesForBackup();
    const backup = {
      schemaVersion: 2,
      format: 'stadslass-backup',
      source: { app: 'Stadslass 3.0', exportedAt: new Date().toISOString(), packageVersion: PACKAGE_VERSION, storageSchemaVersion: STORAGE_SCHEMA_VERSION },
      data: { nativeCategories: categories }
    };
    assertNoSecrets(backup);
    return backup;
  }

  function validateBackupV2(value) {
    if (!plain(value) || value.format !== 'stadslass-backup' || Number(value.schemaVersion) !== 2 || !plain(value.data) || !plain(value.data.nativeCategories)) throw new Error('Backupfilen har fel P158-format.');
    const categories = value.data.nativeCategories;
    const unknown = Object.keys(categories).filter((category) => !CATEGORIES.includes(category));
    if (unknown.length) throw new Error(`Backup innehåller okända native kategorier: ${unknown.join(', ')}.`);
    CATEGORIES.forEach((category) => {
      if (!Array.isArray(categories[category])) throw new Error(`Backup saknar obligatorisk kategori: ${category}.`);
      const ids = new Set();
      categories[category].forEach((row) => {
        if (!plain(row) || !text(row.id) || !Object.prototype.hasOwnProperty.call(row, 'payload')) throw new Error(`Backupkategorin ${category} innehåller en ogiltig post.`);
        if (ids.has(row.id)) throw new Error(`Backupkategorin ${category} innehåller dubblett-ID.`);
        ids.add(row.id);
      });
    });
    assertNoSecrets(value);
    return clone(categories);
  }

  async function restoreBackupV2(value) {
    const categories = validateBackupV2(value);
    const snapshots = {};
    for (const category of CATEGORIES) snapshots[category] = listCategory(category).map((row) => ({ id: row.id, payload: clone(row.payload) }));
    // Lägg kategorin i rollbacklistan INNAN importen startar. importCategory kan ha
    // hunnit COMMIT:a native data men ändå kasta fel vid verifieringen efter COMMIT.
    // Då måste även den aktuella kategorin återställas, inte bara tidigare färdiga.
    const attempted = [];
    try {
      for (const category of CATEGORIES) {
        attempted.push(category);
        await importCategory(category, categories[category], {});
      }
      return { ok: true, categories: Object.fromEntries(CATEGORIES.map((category) => [category, categories[category].length])) };
    } catch (error) {
      const rollbackErrors = [];
      for (const category of attempted.slice().reverse()) {
        try { await importCategory(category, snapshots[category], {}); }
        catch (rollbackError) { rollbackErrors.push(`${category}: ${text(rollbackError && rollbackError.message, 'okänt rollbackfel')}`); }
      }
      if (rollbackErrors.length) throw new Error(`Backuprestore misslyckades och rollback blev ofullständig. Ursprungligt fel: ${text(error && error.message)}. Rollback: ${rollbackErrors.join(' | ')}`);
      throw error;
    }
  }

  function pendingHistoryTransferMeta() {
    try {
      const row = listCategory('sync-history').find((item) => plain(item.payload) && item.payload.settingKey === 'historySyncV1' && plain(item.payload.value));
      const state = row && row.payload ? row.payload.value : null;
      const pending = plain(state && state.pendingTransfer) ? state.pendingTransfer : (plain(state && state.pendingPackage) ? state.pendingPackage : null);
      if (!pending) return null;
      return {
        transferId: text(pending.stagingTransferId, text(pending.transferId)),
        expectedPartCount: Math.max(1, Number(pending.partCount) || 1),
        totalRecordCount: Number.isFinite(Number(pending.totalRecordCount)) ? Number(pending.totalRecordCount) : null
      };
    } catch (_) { return null; }
  }

  async function refreshDiagnostics() {
    const storage = nativeRequest('STATUS');
    const staging = stagingRequest('STATUS');
    const pending = pendingHistoryTransferMeta();
    diagnosticsState.staging.transfers = array(staging.transfers).map((row) => {
      const copy = clone(row);
      copy.receivedPartCount = Number(copy.partCount) || 0;
      if (pending && text(copy.transferId) === pending.transferId) {
        copy.expectedPartCount = pending.expectedPartCount;
        copy.totalRecordCount = pending.totalRecordCount;
      } else {
        copy.expectedPartCount = Number(copy.partCount) || 0;
      }
      return copy;
    });
    diagnosticsState.nativeCategories = array(storage.categories).map(clone);
    return diagnostics();
  }

  function diagnostics() {
    return clone({ ...diagnosticsState, lastError: diagnosticsState.lastError || (lastError ? { message: text(lastError.message) } : null), sourceCounts: migrationSnapshot && migrationSnapshot.sourceCounts ? clone(migrationSnapshot.sourceCounts) : {} });
  }

  window.StadslassNativeStorage = Object.freeze({
    PACKAGE_VERSION, NATIVE_STORAGE_API_VERSION, STORAGE_SCHEMA_VERSION, STAGING_API_VERSION, MIGRATION_KEY, CATEGORIES,
    assertCapabilities, migrate, isActive: () => active, setActive: (value) => { active = value === true; },
    settingsProjection, writeSettingsProjection, historyDocument, writeHistoryProjection, receiptRows, writeReceiptRows, archiveRecords, syncOutboxRows, mergeLegacySyncOutbox,
    listCategory, expectedIntegrity, nativeRequest, stagingRequest,
    stageHistoryPackage, readStagedHistoryPayload, deleteStagedTransfer,
    createBackup, validateBackupV2, restoreBackupV2, exportCategoriesForBackup,
    diagnostics, refreshDiagnostics, classifySettings, normalizeHistorySources, assertNoSecrets,
    _test: Object.freeze({ canonicalJson, historyEnvelopeId, safeToken, stripLearning, isTrashed, settingRecord })
  });
})();
