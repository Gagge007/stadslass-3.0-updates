(() => {
  'use strict';

  const SCHEMA_VERSION = 1;
  const PACKAGE_VERSION = 61;
  const SUBJECT = 'ÄTA uppdrag lastbil 189';
  const DAILY_SUBJECT = 'Dagens ÄTA uppdrag lastbil 189';
  const FIELD_LABELS = Object.freeze({
    jobType: 'Jobbtyp', fromPlace: 'Från', toPlace: 'Till', returnPlace: 'Returplats',
    date: 'Datum', startedAt: 'Starttid', completedAt: 'Sluttid', billableTime: 'Debiterbar tid',
    loadCount: 'Antal lass', totalWeight: 'Total vikt', note: 'Kommentar', truck189: 'Lastbil'
  });
  const ACTIONS = Object.freeze({ NONE: 'none', OPENED: 'draft_opened', COPIED: 'underlag_copied', SKIPPED: 'not_sent_now' });
  const ACTION_LABELS = Object.freeze({ [ACTIONS.NONE]: 'Ej valt', [ACTIONS.OPENED]: 'Mailutkast öppnat', [ACTIONS.COPIED]: 'Underlag kopierat', [ACTIONS.SKIPPED]: 'Ej skickat nu' });

  const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
  const text = (value, fallback = '') => typeof value === 'string' ? value.trim() : fallback;
  const validEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text(value));
  const localDate = (value) => { const date = new Date(value); if (Number.isNaN(date.getTime())) return ''; return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; };
  const clock = (value) => { const date = new Date(value); if (Number.isNaN(date.getTime())) return ''; return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`; };
  const decimal = (value) => Number(value || 0).toLocaleString('sv-SE', { minimumFractionDigits: 1, maximumFractionDigits: 3 });
  const minutes = (value) => { const n = Math.max(0, Math.round(Number(value) || 0)); const h = Math.floor(n / 60); const m = n % 60; return h > 0 && m > 0 ? `${h} tim ${m} min` : (h > 0 ? `${h} tim` : `${m} min`); };

  function recipient(raw) {
    const source = isObject(raw) ? raw : {};
    const email = text(source.email, text(source.emailKey));
    const name = text(source.name);
    return { ...source, name, email, valid: validEmail(email) };
  }
  function recipientText(raw) { const value = recipient(raw); return value.name && value.email ? `${value.name} <${value.email}>` : (value.name || value.email || 'Mottagare saknas'); }
  function isEligible(job) {
    return isObject(job) && job.ata && job.ata.enabled === true && text(job.status, 'completed') === 'completed'
      && !(isObject(job.trashState) && text(job.trashState.status) === 'trashed')
      && job.receiptImported !== true && job.kvittoImported !== true;
  }
  function snapshotRecipient(job) { return recipient(isObject(job) && isObject(job.ata) ? job.ata.recipient : null); }
  function template(raw) {
    const source = isObject(raw) ? raw : {}; const fields = isObject(source.fields) ? source.fields : {};
    const names = window.StadslassAtaNotificationSettings && Array.isArray(window.StadslassAtaNotificationSettings.TEMPLATE_FIELDS)
      ? window.StadslassAtaNotificationSettings.TEMPLATE_FIELDS : Object.keys(FIELD_LABELS);
    return { fields: Object.fromEntries(names.map((key) => [key, fields[key] !== false])), closingText: typeof source.closingText === 'string' ? source.closingText.trim() : '' };
  }
  function place(job, key) {
    const direct = key === 'from' ? [job.fromPlaceName, job.from] : [job.destinationPlaceName, job.destination];
    return direct.map((value) => text(value)).find(Boolean) || '';
  }
  function temporaryAddress(job, key) {
    const places = isObject(job.temporaryPlaces) ? job.temporaryPlaces : {};
    const source = isObject(places[key]) ? places[key] : {};
    return [source.normalizedAddress, source.displayAddress, source.streetAddress, source.address].map((value) => text(value)).find(Boolean) || '';
  }
  function loadCount(job) { return Array.isArray(job.loads) ? job.loads.length : (Array.isArray(job.loadCycles) ? job.loadCycles.filter((row) => row && row.weight !== undefined).length : 0); }
  function weight(job) { const direct = Number(job.totalWeight); if (Number.isFinite(direct)) return direct; return Array.isArray(job.loads) ? job.loads.reduce((sum, row) => sum + Number(isObject(row) ? row.weight : row || 0), 0) : 0; }
  function billable(job) { const billing = isObject(job.ata) && isObject(job.ata.billing) ? job.ata.billing : {}; const n = Number(billing.minutes); return Number.isFinite(n) && n >= 0 ? Math.round(n) : null; }
  function line(lines, label, value, includeBlank = false) { const valueText = text(String(value ?? '')); if (valueText || includeBlank) lines.push(`${label}: ${valueText}`); }
  function body(job, rawTemplate) {
    const selected = template(rawTemplate); const lines = []; const date = text(job.date, localDate(job.completedAt || job.startedAt));
    if (selected.fields.jobType) line(lines, FIELD_LABELS.jobType, text(job.jobTypeName, text(job.jobType)));
    if (selected.fields.fromPlace) { line(lines, FIELD_LABELS.fromPlace, place(job, 'from')); const address = temporaryAddress(job, 'from'); if (address) line(lines, 'Från adress', address, true); }
    if (selected.fields.toPlace) { line(lines, FIELD_LABELS.toPlace, place(job, 'to')); const address = temporaryAddress(job, 'destination'); if (address) line(lines, 'Till adress', address, true); }
    if (selected.fields.returnPlace) line(lines, FIELD_LABELS.returnPlace, job.returnRequired === true ? text(job.returnPlaceName) : '');
    if (selected.fields.date) line(lines, FIELD_LABELS.date, date);
    if (selected.fields.startedAt) line(lines, FIELD_LABELS.startedAt, clock(job.startedAt));
    if (selected.fields.completedAt) line(lines, FIELD_LABELS.completedAt, clock(job.completedAt));
    if (selected.fields.billableTime) { const value = billable(job); line(lines, FIELD_LABELS.billableTime, value === null ? '' : `${value} min`); }
    if (selected.fields.loadCount) line(lines, FIELD_LABELS.loadCount, loadCount(job));
    if (selected.fields.totalWeight) line(lines, FIELD_LABELS.totalWeight, `${decimal(weight(job))} ton`);
    if (selected.fields.note) line(lines, FIELD_LABELS.note, text(job.note, text(job.comment)));
    if (selected.fields.truck189) line(lines, FIELD_LABELS.truck189, '189');
    if (selected.closingText) { if (lines.length) lines.push(''); lines.push(selected.closingText); }
    return lines.join('\n');
  }
  function individual(job, rawTemplate) {
    const to = snapshotRecipient(job); const mailBody = body(job, rawTemplate);
    return { recipient: to, subject: SUBJECT, body: mailBody, preview: `Till: ${recipientText(to)}\nÄmne: ${SUBJECT}\n\n${mailBody}` };
  }
  function dayJobs(entries, day) {
    return (Array.isArray(entries) ? entries : []).filter((job) => isEligible(job) && localDate(job.completedAt || job.startedAt) === day)
      .slice().sort((a, b) => new Date(a.startedAt || 0).getTime() - new Date(b.startedAt || 0).getTime() || text(a.id).localeCompare(text(b.id), 'sv-SE'));
  }
  function daily(entries, day, rawSupervisor) {
    const jobs = dayJobs(entries, day); const supervisor = recipient(rawSupervisor); const totalMinutes = jobs.reduce((sum, job) => sum + (billable(job) || 0), 0); const totalWeight = jobs.reduce((sum, job) => sum + weight(job), 0);
    const lines = ['Hej,', '', 'Här kommer dagens ÄTA-uppdrag för lastbil 189.', '', `Datum: ${day}`, `Antal ÄTA-uppdrag: ${jobs.length}`, `Total debiterbar tid: ${minutes(totalMinutes)}`, `Total vikt: ${decimal(totalWeight)} ton`, ''];
    jobs.forEach((job, index) => { lines.push('-----------------------------------', `${index + 1}. ÄTA-uppdrag`); line(lines, 'Jobbtyp', text(job.jobTypeName, text(job.jobType))); line(lines, 'Från', place(job, 'from')); line(lines, 'Till', place(job, 'destination')); line(lines, 'Starttid', clock(job.startedAt)); line(lines, 'Sluttid', clock(job.completedAt)); line(lines, 'Debiterbar tid', minutes(billable(job) || 0)); line(lines, 'Antal lass', loadCount(job)); line(lines, 'Total vikt', `${decimal(weight(job))} ton`); line(lines, 'Kommentar', text(job.note, text(job.comment))); lines.push(''); });
    lines.push('-----------------------------------', '', 'Mvh', 'Lastbil 189'); const mailBody = lines.join('\n');
    return { day, jobs, recipient: supervisor, subject: DAILY_SUBJECT, body: mailBody, totalMinutes, totalWeight, preview: `Till: ${recipientText(supervisor)}\nÄmne: ${DAILY_SUBJECT}\n\n${mailBody}` };
  }
  function status(job) { const mail = isObject(job) && isObject(job.ata) && isObject(job.ata.mail) ? job.ata.mail : {}; const action = Object.values(ACTIONS).includes(text(mail.lastAction)) ? text(mail.lastAction) : ACTIONS.NONE; return { ...mail, schemaVersion: SCHEMA_VERSION, lastAction: action, label: ACTION_LABELS[action] }; }
  function withStatus(job, action, hostResult = '', at = new Date().toISOString()) { const current = status(job); const next = { ...current, schemaVersion: SCHEMA_VERSION, lastAction: action, lastActionAt: at, ...(hostResult ? { lastHostResult: text(hostResult).slice(0, 80) } : {}) }; if (action === ACTIONS.OPENED) next.draftOpenedAt = at; if (action === ACTIONS.COPIED) next.underlagCopiedAt = at; if (action === ACTIONS.SKIPPED) next.notSentAt = at; return { ...job, ata: { ...job.ata, mail: next } }; }
  window.StadslassAtaMailUnderlag = Object.freeze({ SCHEMA_VERSION, PACKAGE_VERSION, SUBJECT, DAILY_SUBJECT, ACTIONS, ACTION_LABELS, validEmail, recipient, recipientText, isEligible, snapshotRecipient, template, body, individual, dayJobs, daily, status, withStatus, minutes, decimal, localDate });
})();
