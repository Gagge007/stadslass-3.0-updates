(() => {
  'use strict';

  const SCHEMA_VERSION = 1;
  const PACKAGE_VERSION = 192;
  const MINIMUM_MINUTES = 30;
  const MODES = Object.freeze({
    MANUAL: 'manual',
    TOTAL_UP: 'total-up',
    PHASES_DOWN: 'phases-down',
    PHASES_UP: 'phases-up',
    PHASES_EXACT: 'phases-exact',
    MANUAL_CORRECTION: 'manual-correction'
  });
  const ALLOWED_MODES = new Set(Object.values(MODES));
  const INCLUDED_PHASES = new Set(['loading', 'transport', 'unloading']);

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function validTimestamp(value) {
    const candidate = text(value);
    return candidate && Number.isFinite(new Date(candidate).getTime()) ? candidate : '';
  }

  function nonNegativeInteger(value) {
    const number = Number(value);
    return Number.isFinite(number) && Number.isInteger(number) && number >= 0 ? number : null;
  }

  function interval(startValue, endValue, capEndValue = '') {
    const start = new Date(startValue).getTime();
    const rawEnd = new Date(endValue || capEndValue).getTime();
    const capEnd = capEndValue ? new Date(capEndValue).getTime() : rawEnd;
    const end = Number.isFinite(capEnd) ? Math.min(rawEnd, capEnd) : rawEnd;
    return Number.isFinite(start) && Number.isFinite(end) && end > start ? { start, end } : null;
  }

  function mergeIntervals(values) {
    const sorted = values.filter(Boolean).slice().sort((a, b) => a.start - b.start || a.end - b.end);
    const merged = [];
    sorted.forEach((candidate) => {
      const last = merged[merged.length - 1];
      if (!last || candidate.start > last.end) merged.push({ ...candidate });
      else if (candidate.end > last.end) last.end = candidate.end;
    });
    return merged;
  }

  function overlapMs(left, right) {
    return Math.max(0, Math.min(left.end, right.end) - Math.max(left.start, right.start));
  }

  function minutesFromMs(milliseconds) {
    return Math.max(0, Math.round(milliseconds / 60000));
  }

  function activeIntervals(record, completedAt) {
    const source = isPlainObject(record) ? record : {};
    const stored = Array.isArray(source.workSegments) ? source.workSegments.filter(isPlainObject) : [];
    const intervals = stored.map((segment) => interval(segment.startedAt, segment.endedAt, completedAt)).filter(Boolean);
    if (intervals.length) return mergeIntervals(intervals);
    const fallback = interval(source.startedAt, completedAt, completedAt);
    return fallback ? [fallback] : [];
  }

  function totalWorkMinutes(record, completedAt) {
    return minutesFromMs(activeIntervals(record, completedAt).reduce((sum, value) => sum + (value.end - value.start), 0));
  }

  function eligiblePhaseIntervals(record, completedAt) {
    const source = isPlainObject(record) ? record : {};
    const timeline = Array.isArray(source.phaseTimeline) ? source.phaseTimeline.filter(isPlainObject) : [];
    const eligible = new Set(INCLUDED_PHASES);
    if (source.multiLoad === true && source.returnRequired !== true) eligible.add('return_transport');
    return mergeIntervals(timeline.map((entry) => {
      const phase = text(entry.phaseCode, text(entry.phase));
      if (!eligible.has(phase)) return null;
      return interval(entry.startedAt, entry.endedAt, completedAt);
    }).filter(Boolean));
  }

  function phaseWorkMinutes(record, completedAt) {
    const work = activeIntervals(record, completedAt);
    const phases = eligiblePhaseIntervals(record, completedAt);
    if (!work.length || !phases.length) {
      return Object.freeze({ minutes: totalWorkMinutes(record, completedAt), fallbackUsed: true, phaseIntervalCount: phases.length });
    }
    const milliseconds = phases.reduce((sum, phase) => sum + work.reduce((workSum, active) => workSum + overlapMs(phase, active), 0), 0);
    const minutes = minutesFromMs(milliseconds);
    if (minutes <= 0) {
      return Object.freeze({ minutes: totalWorkMinutes(record, completedAt), fallbackUsed: true, phaseIntervalCount: phases.length });
    }
    return Object.freeze({ minutes, fallbackUsed: false, phaseIntervalCount: phases.length });
  }

  function roundTotalUp(minutes) {
    const source = Math.max(0, nonNegativeInteger(minutes) ?? 0);
    return Math.max(MINIMUM_MINUTES, Math.ceil(source / MINIMUM_MINUTES) * MINIMUM_MINUTES);
  }

  function halfHourOptions(minutes) {
    const source = Math.max(0, nonNegativeInteger(minutes) ?? 0);
    const lower = Math.max(MINIMUM_MINUTES, Math.floor(source / MINIMUM_MINUTES) * MINIMUM_MINUTES);
    const upper = Math.max(MINIMUM_MINUTES, Math.ceil(source / MINIMUM_MINUTES) * MINIMUM_MINUTES);
    return Object.freeze({ sourceMinutes: source, lower, upper, exact: lower === upper });
  }

  function normalizeBilling(raw) {
    if (!isPlainObject(raw)) return null;
    const minutes = nonNegativeInteger(raw.minutes);
    const sourceMinutes = nonNegativeInteger(raw.sourceMinutes);
    const mode = text(raw.mode);
    if (minutes === null || sourceMinutes === null || !ALLOWED_MODES.has(mode)) return null;
    return {
      schemaVersion: SCHEMA_VERSION,
      minutes,
      mode,
      sourceMinutes,
      fallbackUsed: raw.fallbackUsed === true,
      selectedAt: validTimestamp(raw.selectedAt),
      editedAt: validTimestamp(raw.editedAt)
    };
  }

  function snapshotFromRecord(record) {
    if (!isPlainObject(record) || !isPlainObject(record.ata)) return null;
    return normalizeBilling(record.ata.billing);
  }

  function createBilling({ minutes, mode, sourceMinutes, fallbackUsed = false, selectedAt = new Date().toISOString(), editedAt = '' }) {
    const normalized = normalizeBilling({ minutes, mode, sourceMinutes, fallbackUsed, selectedAt, editedAt });
    if (!normalized) throw new Error('Debiteringsuppgiften är ogiltig.');
    return normalized;
  }

  function applyToRecord(record, billing, updatedAt = new Date().toISOString()) {
    const source = isPlainObject(record) ? record : {};
    const normalized = normalizeBilling(billing);
    if (!normalized) throw new Error('Debiteringsuppgiften kunde inte sparas.');
    const ata = isPlainObject(source.ata) ? source.ata : {};
    return {
      ...source,
      ata: {
        ...ata,
        billing: normalized,
        updatedAt: validTimestamp(updatedAt) || text(ata.updatedAt)
      }
    };
  }

  function editRecord(record, value, editedAt = new Date().toISOString()) {
    const source = isPlainObject(record) ? record : {};
    const minutes = nonNegativeInteger(value);
    if (minutes === null) throw new Error('Debiterbar tid ska vara ett helt antal minuter från 0 och uppåt.');
    const existing = snapshotFromRecord(source);
    const billing = createBilling({
      minutes,
      mode: MODES.MANUAL_CORRECTION,
      sourceMinutes: existing ? existing.sourceMinutes : minutes,
      fallbackUsed: existing ? existing.fallbackUsed : false,
      selectedAt: existing && existing.selectedAt ? existing.selectedAt : editedAt,
      editedAt
    });
    return applyToRecord(source, billing, editedAt);
  }

  function removeFromRecord(record, editedAt = new Date().toISOString()) {
    const source = isPlainObject(record) ? record : {};
    if (!isPlainObject(source.ata) || !Object.prototype.hasOwnProperty.call(source.ata, 'billing')) return { ...source };
    const { billing: _removedBilling, ...ataWithoutBilling } = source.ata;
    return { ...source, ata: { ...ataWithoutBilling, updatedAt: validTimestamp(editedAt) || text(ataWithoutBilling.updatedAt) } };
  }

  function parseCompletionManual(value) {
    const raw = String(value ?? '').trim();
    if (!/^\d+$/.test(raw)) return null;
    const minutes = Number(raw);
    return Number.isSafeInteger(minutes) && minutes >= MINIMUM_MINUTES ? minutes : null;
  }

  function formatMinutes(minutes) {
    const value = Math.max(0, nonNegativeInteger(minutes) ?? 0);
    const hours = Math.floor(value / 60);
    const rest = value % 60;
    return hours > 0 ? `${hours} t ${rest} min` : `${rest} min`;
  }

  window.StadslassAtaBilling = Object.freeze({
    SCHEMA_VERSION,
    PACKAGE_VERSION,
    MINIMUM_MINUTES,
    MODES,
    normalizeBilling,
    snapshotFromRecord,
    createBilling,
    applyToRecord,
    editRecord,
    removeFromRecord,
    totalWorkMinutes,
    phaseWorkMinutes,
    roundTotalUp,
    halfHourOptions,
    parseCompletionManual,
    formatMinutes
  });
})();
