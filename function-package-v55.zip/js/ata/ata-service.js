(() => {
  'use strict';

  const SCHEMA_VERSION = 1;
  const PACKAGE_VERSION = 55;
  const SOURCES = Object.freeze({
    MANUAL: 'manual',
    QUICK_CHOICE: 'quick-choice',
    MANUAL_EDIT: 'manual-edit'
  });
  const ALLOWED_SOURCES = new Set(Object.values(SOURCES));

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function hasOwn(object, key) {
    return isPlainObject(object) && Object.prototype.hasOwnProperty.call(object, key);
  }

  function normalizedSource(value, fallback = SOURCES.MANUAL) {
    const source = text(value);
    return ALLOWED_SOURCES.has(source) ? source : fallback;
  }

  function normalizedTimestamp(value, fallback = '') {
    const candidate = text(value);
    if (!candidate) return fallback;
    const timestamp = new Date(candidate).getTime();
    return Number.isFinite(timestamp) ? candidate : fallback;
  }

  function normalizeSnapshot(raw, options = {}) {
    const source = isPlainObject(raw) ? raw : {};
    const fallbackSource = normalizedSource(options.fallbackSource, SOURCES.MANUAL);
    const fallbackTimestamp = normalizedTimestamp(options.fallbackTimestamp, '');
    const quickChoiceId = text(source.quickChoiceId) || null;
    return {
      schemaVersion: SCHEMA_VERSION,
      enabled: source.enabled === true,
      source: normalizedSource(source.source, fallbackSource),
      quickChoiceId,
      updatedAt: normalizedTimestamp(source.updatedAt, fallbackTimestamp)
    };
  }

  function snapshotFromRecord(record) {
    if (!isPlainObject(record) || !hasOwn(record, 'ata') || !isPlainObject(record.ata)) return null;
    return normalizeSnapshot(record.ata);
  }

  function isEnabled(recordOrSnapshot) {
    if (!isPlainObject(recordOrSnapshot)) return false;
    const candidate = hasOwn(recordOrSnapshot, 'ata') ? recordOrSnapshot.ata : recordOrSnapshot;
    return isPlainObject(candidate) && candidate.enabled === true;
  }

  function createManual(enabled, updatedAt = new Date().toISOString()) {
    return normalizeSnapshot({
      enabled: enabled === true,
      source: SOURCES.MANUAL,
      quickChoiceId: null,
      updatedAt
    });
  }

  function createFromQuickChoice(enabled, quickChoiceId, updatedAt = new Date().toISOString()) {
    return normalizeSnapshot({
      enabled: enabled === true,
      source: SOURCES.QUICK_CHOICE,
      quickChoiceId: text(quickChoiceId) || null,
      updatedAt
    }, { fallbackSource: SOURCES.QUICK_CHOICE });
  }

  function editSnapshot(record, enabled, updatedAt = new Date().toISOString()) {
    const existing = snapshotFromRecord(record);
    const nextEnabled = enabled === true;
    if (!existing) {
      return nextEnabled ? normalizeSnapshot({
        enabled: true,
        source: SOURCES.MANUAL_EDIT,
        quickChoiceId: null,
        updatedAt
      }, { fallbackSource: SOURCES.MANUAL_EDIT }) : null;
    }
    if (existing.enabled === nextEnabled) return existing;
    return normalizeSnapshot({
      ...existing,
      enabled: nextEnabled,
      source: SOURCES.MANUAL_EDIT,
      updatedAt
    }, { fallbackSource: SOURCES.MANUAL_EDIT });
  }

  function applyToRecord(record) {
    const source = isPlainObject(record) ? record : {};
    const existing = snapshotFromRecord(source);
    if (!existing) {
      if (!hasOwn(source, 'ata')) return { ...source };
      const { ata: _invalidAta, ...withoutInvalidAta } = source;
      return withoutInvalidAta;
    }
    return { ...source, ata: existing };
  }

  function normalizeQuickChoiceDefault(value) {
    return value === true;
  }

  function display(record) {
    const enabled = isEnabled(record);
    return Object.freeze({
      enabled,
      label: enabled ? 'ÄTA' : '',
      className: enabled ? 'ata-chip' : ''
    });
  }

  const api = {
    SCHEMA_VERSION,
    PACKAGE_VERSION,
    SOURCES,
    normalizeSnapshot,
    snapshotFromRecord,
    isEnabled,
    createManual,
    createFromQuickChoice,
    editSnapshot,
    applyToRecord,
    normalizeQuickChoiceDefault,
    display
  };

  window.StadslassAta = Object.freeze(api);
})();
