(() => {
  'use strict';

  const JOB_MODEL_VERSION = 4;
  const PACKAGE_VERSION = 62;
  const registries = window.StadslassRegistries || null;
  const phaseService = window.StadslassPhaseService || null;
  const temporaryPlaceService = window.StadslassTemporaryPlaceService || null;
  const ataService = window.StadslassAta || null;
  const conditionalRules = registries && registries.jobTypes && Array.isArray(registries.jobTypes.conditionalRules) ? registries.jobTypes.conditionalRules : [];
  let jobTypeItems = Object.freeze([]);
  let jobTypesInitialized = false;
  let placeItems = Object.freeze([]);
  let placesInitialized = false;

  function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
  }

  function text(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function normalizedName(value) {
    return text(value).toLocaleLowerCase('sv-SE');
  }

  function immutableItem(item) {
    const copy = { ...item };
    if (Array.isArray(item.aliases)) copy.aliases = Object.freeze(item.aliases.slice());
    return Object.freeze(copy);
  }

  function immutablePlace(item) {
    const copy = { ...item };
    if (Array.isArray(item.aliases)) copy.aliases = Object.freeze(item.aliases.slice());
    if (Array.isArray(item.roles)) copy.roles = Object.freeze(item.roles.slice());
    if (Array.isArray(item.allowedJobTypeIds)) copy.allowedJobTypeIds = Object.freeze(item.allowedJobTypeIds.slice());
    if (Array.isArray(item.jobTypeFromIds)) copy.jobTypeFromIds = Object.freeze(item.jobTypeFromIds.slice());
    if (Array.isArray(item.jobTypeToIds)) copy.jobTypeToIds = Object.freeze(item.jobTypeToIds.slice());
    if (item.geofence && typeof item.geofence === 'object') copy.geofence = Object.freeze({ ...item.geofence, polygonPoints: Object.freeze(Array.isArray(item.geofence.polygonPoints) ? item.geofence.polygonPoints.map((point) => Object.freeze({ ...point })) : []) });
    return Object.freeze(copy);
  }

  function normalizeJobTypes(items) {
    if (!Array.isArray(items)) throw new Error('Det gemensamma Jobbtypsregistret saknas eller har fel format.');
    const ids = new Set();
    const canonicalIds = new Set();
    return items.map((item) => {
      if (!isPlainObject(item) || !text(item.id) || !text(item.name)) throw new Error('Det gemensamma Jobbtypsregistret innehåller en ogiltig jobbtyp.');
      if (ids.has(text(item.id))) throw new Error('Det gemensamma Jobbtypsregistret innehåller dubbla jobbtyps-ID:n.');
      const canonical = text(item.canonicalTypeId);
      if (canonical && canonicalIds.has(canonical)) throw new Error('Det gemensamma Jobbtypsregistret innehåller dubbla kompatibilitets-ID:n.');
      ids.add(text(item.id));
      if (canonical) canonicalIds.add(canonical);
      return immutableItem(item);
    });
  }

  function initializeJobTypes(items) {
    if (jobTypesInitialized) throw new Error('Uppdragsmodellens gemensamma jobbtypslista är redan låst för denna körning.');
    jobTypeItems = Object.freeze(normalizeJobTypes(items));
    jobTypesInitialized = true;
    return jobTypeItems;
  }

  function replaceJobTypes(items) {
    jobTypeItems = Object.freeze(normalizeJobTypes(items));
    jobTypesInitialized = true;
    return jobTypeItems;
  }

  function getJobTypeItems() {
    if (!jobTypesInitialized) throw new Error('Uppdragsmodellens gemensamma jobbtypslista har inte initierats.');
    return jobTypeItems;
  }

  function normalizePlaces(items) {
    if (!Array.isArray(items)) throw new Error('Den effektiva platslistan saknas eller har fel format.');
    const ids = new Set();
    return items.map((item) => {
      if (!isPlainObject(item) || !text(item.id) || !text(item.name)) throw new Error('Den effektiva platslistan innehåller en ogiltig plats.');
      if (ids.has(text(item.id))) throw new Error('Den effektiva platslistan innehåller dubbla plats-ID:n.');
      ids.add(text(item.id));
      return immutablePlace(item);
    });
  }

  function initializePlaces(items) {
    if (placesInitialized) throw new Error('Uppdragsmodellens effektiva platslista är redan låst för denna körning.');
    placeItems = Object.freeze(normalizePlaces(items));
    placesInitialized = true;
    return placeItems;
  }

  function replacePlaces(items) {
    placeItems = Object.freeze(normalizePlaces(items));
    placesInitialized = true;
    return placeItems;
  }

  function getPlaceItems() {
    if (!placesInitialized) throw new Error('Uppdragsmodellens effektiva platslista har inte initierats.');
    return placeItems;
  }

  function canonicalJobTypeId(value) {
    const item = typeof value === 'string' ? findJobTypeById(value) : value;
    return item ? text(item.canonicalTypeId, text(item.id)) : text(value);
  }

  function findJobTypeById(id) {
    const key = text(id);
    if (!key || !jobTypesInitialized) return null;
    return jobTypeItems.find((item) => text(item.id) === key || text(item.canonicalTypeId) === key) || null;
  }

  function findJobTypeByName(name) {
    const key = normalizedName(name);
    if (!key || !jobTypesInitialized) return null;
    return jobTypeItems.find((item) => item && ([item.name].concat(Array.isArray(item.aliases) ? item.aliases : [])).some((candidate) => normalizedName(candidate) === key)) || null;
  }

  function isOtherActivityJobType(value) {
    const type = typeof value === 'string' ? findJobTypeById(value) : value;
    return Boolean(type && (text(type.specialRole) === 'other-activity' || canonicalJobTypeId(type) === 'JT-1001'));
  }

  function findPlaceById(id) {
    if (!placesInitialized) return null;
    return placeItems.find((item) => item && text(item.id) === text(id)) || null;
  }

  function findPlaceByName(name) {
    if (!placesInitialized) return null;
    const key = normalizedName(name);
    if (!key) return null;
    const matches = placeItems.filter((item) => item && ([item.name].concat(Array.isArray(item.aliases) ? item.aliases : [])).some((candidate) => normalizedName(candidate) === key));
    return matches.find((item) => item.hidden !== true && item.active !== false) || matches[0] || null;
  }

  function validateRegistries() {
    if (!registries || !registries.jobSchema || Number(registries.jobSchema.jobModelVersion) !== JOB_MODEL_VERSION) {
      throw new Error('Uppdragsmodellens register saknas eller har fel version.');
    }
    if (!jobTypesInitialized) throw new Error('Uppdragsmodellen har inte initierats med det gemensamma Jobbtypsregistret.');
    if (!placesInitialized) throw new Error('Uppdragsmodellen har inte initierats med den effektiva platslistan.');
    const placeIds = new Set();
    placeItems.forEach((item) => {
      if (!item || !text(item.id) || !text(item.name) || placeIds.has(item.id)) throw new Error('Platsregistret har ogiltigt eller dubblerat ID.');
      placeIds.add(item.id);
    });
    return { jobTypeCount: jobTypeItems.length, placeCount: placeItems.length, jobModelVersion: JOB_MODEL_VERSION };
  }

  function conditionalRuleAvailable(rule) {
    if (!rule || !findJobTypeById(rule.jobTypeId)) return false;
    return (!text(rule.fromPlaceId) || Boolean(findPlaceById(rule.fromPlaceId)))
      && (!text(rule.destinationPlaceId) || Boolean(findPlaceById(rule.destinationPlaceId)))
      && (!text(rule.facilityPlaceId) || Boolean(findPlaceById(rule.facilityPlaceId)));
  }

  function createId(prefix = 'job') {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    const random = new Uint32Array(2);
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') window.crypto.getRandomValues(random);
    else { random[0] = Math.floor(Math.random() * 0xffffffff); random[1] = Math.floor(Math.random() * 0xffffffff); }
    return `${prefix}-${Date.now().toString(36)}-${random[0].toString(36)}${random[1].toString(36)}`;
  }

  function stableJobId(raw, prefix = 'job') {
    return text(raw && raw.jobId, text(raw && raw.sourceJobId, text(raw && raw.id))) || createId(prefix);
  }

  function conditionalRuleFor(type, fromPlaceId, destinationPlaceId) {
    const canonical = canonicalJobTypeId(type);
    return conditionalRules.find((rule) => conditionalRuleAvailable(rule)
      && text(rule.jobTypeId) === canonical
      && (!text(rule.fromPlaceId) || text(rule.fromPlaceId) === text(fromPlaceId))
      && (!text(rule.destinationPlaceId) || text(rule.destinationPlaceId) === text(destinationPlaceId))) || null;
  }

  function deriveMaterial(jobTypeId, fromPlaceId, destinationPlaceId) {
    const type = findJobTypeById(jobTypeId);
    if (!type) return { code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' };
    const destination = findPlaceById(destinationPlaceId);
    const conditional = conditionalRuleFor(type, fromPlaceId, destinationPlaceId);
    if (conditional) {
      const fallbackFacility = findPlaceById(conditional.facilityPlaceId);
      return {
        code: text(conditional.materialCode),
        facilityPlaceId: destination ? destination.id : text(conditional.facilityPlaceId),
        facilityPlaceName: destination ? destination.name : text(fallbackFacility && fallbackFacility.name),
        ruleId: text(conditional.id)
      };
    }
    if (text(type.materialRule) === 'none' || text(type.materialRule) === 'not-material-transport') {
      return { code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' };
    }
    const facility = destination || findPlaceById(type.defaultDestinationPlaceId);
    return {
      code: text(type.materialCode),
      facilityPlaceId: facility ? facility.id : '',
      facilityPlaceName: facility ? facility.name : '',
      ruleId: (facility || text(type.materialCode)) ? `MR-${canonicalJobTypeId(type)}` : ''
    };
  }

  function suggestedDestination(jobTypeId, fromPlaceId) {
    const type = findJobTypeById(jobTypeId);
    if (!type) return '';
    const canonical = canonicalJobTypeId(type);
    const conditional = conditionalRules.find((rule) => conditionalRuleAvailable(rule)
      && text(rule.jobTypeId) === canonical
      && text(rule.fromPlaceId) && text(rule.fromPlaceId) === text(fromPlaceId));
    return conditional ? text(conditional.facilityPlaceId) : text(type.defaultDestinationPlaceId);
  }

  function normalizeJobRecord(raw, context = 'job') {
    const source = isPlainObject(raw) ? raw : {};
    const legacyJobTypeName = text(source.jobTypeName, text(source.jobType, text(source.displayType)));
    const jobType = findJobTypeById(source.jobTypeId) || findJobTypeById(source.jobTypeCanonicalId) || findJobTypeByName(legacyJobTypeName);
    const legacyFromName = text(source.fromPlaceName, text(source.from, text(source.placeLabel)));
    const legacyDestinationName = text(source.destinationPlaceName, text(source.destination, text(source.destLabel)));
    const legacyReturnName = text(source.returnPlaceName, text(source.returnPlace, text(source.returnDestination)));
    const allTemporaryPlaces = temporaryPlaceService && typeof temporaryPlaceService.normalizeCollection === 'function'
      ? temporaryPlaceService.normalizeCollection(source.temporaryPlaces)
      : (isPlainObject(source.temporaryPlaces) ? source.temporaryPlaces : {});
    const temporaryFrom = temporaryPlaceService
      && temporaryPlaceService.isTemporarySelection(source.fromPlaceId, 'from')
      && allTemporaryPlaces.from ? allTemporaryPlaces.from : null;
    const temporaryDestination = temporaryPlaceService
      && temporaryPlaceService.isTemporarySelection(source.destinationPlaceId, 'destination')
      && allTemporaryPlaces.destination ? allTemporaryPlaces.destination : null;
    const fromPlace = temporaryFrom ? null : (findPlaceById(source.fromPlaceId) || findPlaceByName(legacyFromName));
    const destinationPlace = temporaryDestination ? null : (findPlaceById(source.destinationPlaceId) || findPlaceByName(legacyDestinationName));
    const temporaryReturn = temporaryPlaceService
      && temporaryPlaceService.isTemporarySelection(text(source.returnPlaceId, text(source.fromPlaceId)), 'from')
      && allTemporaryPlaces.from ? allTemporaryPlaces.from : null;
    const returnPlace = temporaryReturn ? null : (findPlaceById(source.returnPlaceId) || findPlaceByName(legacyReturnName));
    const temporaryPlaces = {};
    if (temporaryFrom) temporaryPlaces.from = temporaryFrom;
    if (temporaryDestination) temporaryPlaces.destination = temporaryDestination;
    const otherActivity = isOtherActivityJobType(jobType);
    const returnRequired = !otherActivity && (source.returnRequired === true || source.returnRequiredAtStart === true || Boolean(returnPlace) || Boolean(temporaryReturn));
    const jobId = stableJobId(source, context);
    const derived = deriveMaterial(jobType ? jobType.id : '', fromPlace ? fromPlace.id : '', destinationPlace ? destinationPlace.id : '');
    const material = otherActivity ? { code: '', facilityPlaceId: '', facilityPlaceName: '', ruleId: '' } : (isPlainObject(source.material) ? { ...derived, ...source.material } : derived);
    const metadata = isPlainObject(source.metadata) ? source.metadata : {};
    const fromName = temporaryFrom ? temporaryPlaceService.displayLabel(temporaryFrom, 'from') : (fromPlace ? fromPlace.name : legacyFromName);
    const destinationName = temporaryDestination ? temporaryPlaceService.displayLabel(temporaryDestination, 'destination') : (destinationPlace ? destinationPlace.name : legacyDestinationName);
    const returnName = temporaryReturn ? temporaryPlaceService.displayLabel(temporaryReturn, 'from') : (returnPlace ? returnPlace.name : legacyReturnName);
    const resolvedName = jobType ? jobType.name : legacyJobTypeName || 'Uppdrag';
    const ataSnapshot = ataService && typeof ataService.snapshotFromRecord === 'function'
      ? ataService.snapshotFromRecord(source)
      : null;
    const normalized = {
      ...source,
      schemaVersion: Math.max(Number(source.schemaVersion) || 1, 2),
      jobModelVersion: JOB_MODEL_VERSION,
      jobId,
      id: text(source.id, jobId),
      jobTypeId: jobType ? jobType.id : text(source.jobTypeId),
      jobTypeCanonicalId: jobType ? canonicalJobTypeId(jobType) : text(source.jobTypeCanonicalId, text(source.jobTypeId)),
      jobTypeName: resolvedName,
      jobType: resolvedName,
      fromPlaceId: fromPlace ? fromPlace.id : text(source.fromPlaceId),
      fromPlaceName: fromName || (otherActivity ? '' : 'Från saknas'),
      from: fromName || (otherActivity ? '' : 'Från saknas'),
      destinationPlaceId: destinationPlace ? destinationPlace.id : text(source.destinationPlaceId),
      destinationPlaceName: destinationName || (otherActivity ? '' : 'Till saknas'),
      destination: destinationName || (otherActivity ? '' : 'Till saknas'),
      returnPlaceId: returnPlace ? returnPlace.id : text(source.returnPlaceId),
      returnPlaceName: returnName,
      returnRequired,
      multiLoad: otherActivity || returnRequired ? false : (source.multiLoad === true || source.flerlass === true),
      note: text(source.note, text(source.comment)),
      material,
      ...(Object.keys(temporaryPlaces).length ? { temporaryPlaces } : {}),
      ...(ataSnapshot ? { ata: ataSnapshot } : {}),
      ...(otherActivity ? {
        phase: 'other_activity',
        activityKind: 'other-activity',
        timeReportingScope: 'user',
        vehicleUsage: 'optional-tool',
        gpsEnabled: false,
        excludeFromEstimateLearning: true,
        learningExcludedReason: 'Övrig verksamhet är användartid och ska inte ingå i transportinlärning',
        pauseMode: text(source.pauseMode, text(source.status) === 'paused' ? 'manual' : ''),
        autoResumeEligible: source.autoResumeEligible === true && text(source.pauseMode) === 'automatic'
      } : {}),
      metadata: {
        ...metadata,
        modelVersion: JOB_MODEL_VERSION,
        migratedFromSchemaVersion: Number(source.jobModelVersion) === JOB_MODEL_VERSION ? Number(metadata.migratedFromSchemaVersion) || 0 : Number(source.schemaVersion) || 1,
        lastUpdatedByPackageVersion: PACKAGE_VERSION
      }
    };
    if (Object.keys(temporaryPlaces).length === 0) delete normalized.temporaryPlaces;
    if (!ataSnapshot) delete normalized.ata;
    return phaseService && typeof phaseService.migrateRecord === 'function'
      ? phaseService.migrateRecord(normalized)
      : normalized;
  }

  const api = {
    JOB_MODEL_VERSION,
    PACKAGE_VERSION,
    conditionalRules,
    conditionalRuleAvailable,
    isPlainObject,
    text,
    initializeJobTypes,
    replaceJobTypes,
    getJobTypeItems,
    initializePlaces,
    replacePlaces,
    getPlaceItems,
    validateRegistries,
    findJobTypeById,
    findJobTypeByName,
    canonicalJobTypeId,
    isOtherActivityJobType,
    findPlaceById,
    findPlaceByName,
    deriveMaterial,
    suggestedDestination,
    stableJobId,
    normalizeJobRecord
  };
  Object.defineProperty(api, 'jobTypeItems', { enumerable: true, get: () => jobTypeItems });
  Object.defineProperty(api, 'placeItems', { enumerable: true, get: () => placeItems });
  window.StadslassJobModel = Object.freeze(api);
})();
