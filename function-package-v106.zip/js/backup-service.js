(() => {
  'use strict';
  const SCHEMA_VERSION = 1;
  const FORMAT = 'stadslass-backup';
  const text = (v) => typeof v === 'string' ? v.trim() : '';
  const plain = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
  const clone = (v) => JSON.parse(JSON.stringify(v));
  const stable = (v) => JSON.stringify(v, Object.keys(v || {}).sort());
  const list = (v) => Array.isArray(v) ? v : [];
  const itemId = (v, i, prefix) => text(v && (v.id || v.jobId || v.quickChoiceId || v.contactId || v.machineId), `${prefix}-${i}`);
  function sanitizeSettings(settings) {
    const copy = clone(plain(settings) ? settings : {});
    ['googleServiceSettingsV1', 'syncV63ConfigurationV1', 'syncConfigurationV1', 'githubToken', 'apiKey', 'privateKey'].forEach((key) => delete copy[key]);
    return copy;
  }
  function createBackup(state) {
    return { schemaVersion: SCHEMA_VERSION, format: FORMAT, source: { app: 'Stadslass 3.0', exportedAt: new Date().toISOString(), packageVersion: Number(state.packageVersion) || 0 }, data: {
      settings: sanitizeSettings(state.settings), jobTypes: clone(state.jobTypes), places: clone(state.places), beaches: clone(state.beaches), quickChoices: clone(state.quickChoices), ataContacts: clone(state.ataContacts), machines: clone(state.machines), queue: clone(state.queue), activeJob: clone(state.activeJob), history: clone(state.history), syncOutbox: clone(state.syncOutbox)
    }};
  }
  function parse(raw) {
    const value = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!plain(value)) throw new Error('Backupfilen har fel format.');
    if (value.format === FORMAT && value.schemaVersion === SCHEMA_VERSION && plain(value.data)) return { kind: '3.0', value };
    if (plain(value) && plain(value.parts)) {
      const p=value.parts;
      const part=(key,fallback)=>plain(p[key])&&typeof p[key].data!=='undefined'?p[key].data:fallback;
      return { kind:'2.0', legacy:true, value:{ schemaVersion:SCHEMA_VERSION, format:FORMAT, source:{ app:text(value.app)||'Stadslass 2.0', exportedAt:text(value.exportedAt) }, data:{ settings:sanitizeSettings(part('settings',{})), jobTypes:[], places:[], beaches:[], quickChoices:[], ataContacts:[], machines:[], queue:[], activeJob:{}, history:[], syncOutbox:[] }, legacyParts:{ places:part('places',{}), geofences:part('geofences',{}), jobTypes:part('jobTypes',{}), quickItems:part('quickItems',{}), machines:part('machines',{}), history:part('history',[]), ataContacts:part('ataContacts',part('contacts',[])) } } };
    }
    if (plain(value) && (Array.isArray(value.places) || Array.isArray(value.jobTypes) || plain(value.settings))) return { kind: '2.0', value: { schemaVersion: SCHEMA_VERSION, format: FORMAT, source: { app: 'Stadslass 2.0' }, data: {
      settings: sanitizeSettings(value.settings || {}), jobTypes: value.jobTypes || [], places: value.places || [], beaches: value.beaches || [], quickChoices: value.quickItems || value.quickChoices || [], ataContacts: value.ataContacts || value.contacts || [], machines: value.machines || [], queue: value.queue || [], activeJob: value.activeJob || {}, history: value.history || [], syncOutbox: []
    }}};
    throw new Error('Filen är varken en kompatibel Stadslass 2.0- eller 3.0-backup.');
  }
  function fingerprint(v) { return JSON.stringify(v); }
  function preview(raw, current) {
    const incoming = parse(raw); const data = incoming.value.data; const conflicts = []; const counts = {}; const details = [];
    const fields = [['jobTypes','Jobbtyper'],['places','Platser'],['beaches','Badplatser'],['quickChoices','Snabbval'],['ataContacts','ÄTA-kontakter'],['machines','Maskiner'],['queue','Kö'],['history','Historik'],['syncOutbox','Synkutkö']];
    fields.forEach(([key,label]) => {
      const source = list(data[key]); const existing = list(current[key]); const byId = new Map(existing.map((v,i)=>[itemId(v,i,key),v])); let add=0, same=0, conflict=0;
      const entries=[];
      source.forEach((v,i)=>{ const id=itemId(v,i,key); const old=byId.get(id); const name=text(v.name||v.title||v.buttonName||v.jobTypeName||v.label||v.email||v.registrationNumber||v.jobId)||id; if(!old) { add+=1; entries.push({id,name,status:'import'}); return; } if(fingerprint(old)===fingerprint(v)) { same+=1; entries.push({id,name,status:'skip'}); } else { conflict+=1; const conflictItem={key,label,id,name,defaultAction:'keep'}; conflicts.push(conflictItem); entries.push({...conflictItem,status:'conflict'}); } });
      counts[key]={incoming:source.length,add,same,conflict};
      details.push({key,label,entries});
    });
    const activeIncoming=plain(data.activeJob)&&Object.keys(data.activeJob).length>0 ? data.activeJob : null;
    const activeCurrent=plain(current.activeJob)&&Object.keys(current.activeJob).length>0 ? current.activeJob : null;
    const activeName=activeIncoming ? (text(activeIncoming.jobTypeName||activeIncoming.title||activeIncoming.jobId)||'Aktivt jobb') : '';
    const activeStatus=!activeIncoming ? 'empty' : !activeCurrent ? 'import' : fingerprint(activeCurrent)===fingerprint(activeIncoming) ? 'skip' : 'conflict';
    const activeConflict=activeStatus==='conflict' ? {key:'activeJob',label:'Aktivt jobb',id:itemId(activeIncoming,0,'active-job'),name:activeName,defaultAction:'keep'} : null;
    if(activeConflict) conflicts.push(activeConflict);
    counts.activeJob={incoming:activeIncoming?1:0,add:activeStatus==='import'?1:0,same:activeStatus==='skip'?1:0,conflict:activeStatus==='conflict'?1:0};
    details.push({key:'activeJob',label:'Aktivt jobb',entries:activeIncoming?[{id:itemId(activeIncoming,0,'active-job'),name:activeName,status:activeStatus,...(activeConflict||{})}]:[]});
    return { kind: incoming.kind, backup: incoming.value, counts, details, conflicts, writable: true };
  }
  function mergeList(existing, incoming, key, actions) {
    const result = list(existing).map(clone); const byId = new Map(result.map((v,i)=>[itemId(v,i,key),i]));
    list(incoming).forEach((value,i)=>{ const id=itemId(value,i,key); const index=byId.get(id); if(index === undefined) { result.push(clone(value)); byId.set(id,result.length-1); return; } if(fingerprint(result[index])===fingerprint(value)) return; const action=text(actions && actions[`${key}:${id}`],'keep'); if(action==='replace') result[index]=clone(value); else if(action==='new') { const duplicate={...clone(value),id:`import-${Date.now().toString(36)}-${id}`}; result.push(duplicate); } });
    return result;
  }
  window.StadslassBackupService = Object.freeze({ SCHEMA_VERSION, FORMAT, createBackup, parse, preview, mergeList, sanitizeSettings });
})();
