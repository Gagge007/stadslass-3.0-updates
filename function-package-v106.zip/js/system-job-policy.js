(() => {
  'use strict';

  const OTHER_ACTIVITY = Object.freeze({
    canonicalId: 'JT-1001', name: 'Övrig verksamhet', specialRole: 'other-activity',
    requiresRoute: false, usesGps: false, supportsReturn: false, supportsMultiLoad: false, supportsWeight: false, materialRule: 'none'
  });
  const MACHINE_TRANSPORT = Object.freeze({
    canonicalId: 'JT-1011', name: 'Maskintransport', specialRole: 'machine-transport',
    requiresRoute: true, usesGps: true, supportsReturn: true, supportsMultiLoad: true, supportsWeight: true, materialRule: 'none',
    machineOptional: true, ataDefault: false, fixedPlaceNames: ['Ringön', 'Flaklager Skräppekärr'], defaultFromName: 'Ringön', defaultDestination: 'Annan plats'
  });
  const POLICIES = Object.freeze([OTHER_ACTIVITY, MACHINE_TRANSPORT]);
  const text = (value) => typeof value === 'string' ? value.trim() : '';
  function canonicalId(value) { return text(value && (value.canonicalTypeId || value.id || value.jobTypeCanonicalId)); }
  function get(value) { return POLICIES.find((policy) => policy.canonicalId === canonicalId(value)) || null; }
  function isSystem(value) { return Boolean(get(value)); }
  function isOtherActivity(value) { return get(value) === OTHER_ACTIVITY; }
  function isMachineTransport(value) { return get(value) === MACHINE_TRANSPORT; }
  function apply(definition) {
    const policy = get(definition);
    return policy ? { ...definition, ...policy, defaultDefinition: true, systemDefinition: true } : definition;
  }
  window.StadslassSystemJobPolicy = Object.freeze({ OTHER_ACTIVITY, MACHINE_TRANSPORT, POLICIES, get, isSystem, isOtherActivity, isMachineTransport, apply });
})();
