#!/usr/bin/env python3
"""Static package contract for Stadslass 3.0 function package 106."""
import hashlib, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def require(value,message):
    if not value: raise AssertionError(message)
module=json.loads((ROOT/'module.json').read_text(encoding='utf-8'))
app=(ROOT/'js/app.js').read_text(encoding='utf-8')
service=(ROOT/'js/sync-service.js').read_text(encoding='utf-8')
diagnostic=(ROOT/'js/sync-diagnostic.js').read_text(encoding='utf-8')
performance=(ROOT/'js/performance-monitor.js').read_text(encoding='utf-8')
html=(ROOT/'index.html').read_text(encoding='utf-8')
css=(ROOT/'css/app.css').read_text(encoding='utf-8')
functions=json.loads((ROOT/'data/functions.json').read_text(encoding='utf-8'))
require(module['packageVersion']==106,'module packageVersion must be 106')
require(module['minHostVersionCode']==20,'minHostVersionCode must be 20')
require(module['packageType']=='stadslass-web-module','package type changed')
require("const PACKAGE_VERSION = 106;" in app,'runtime package version mismatch')
require('const nextJobTypeIds=new Set(nextJobTypes.items.map((item)=>item.id));' in app,'imported job types must validate imported place links')
require('js/backup-service.js' in html and 'requestTextFileImport' in app,'backup/import runtime missing')
require('const OPERATIONAL_SYNC_ENABLED = true;' in service,'central operational sync gate missing')
require("if (!OPERATIONAL_SYNC_ENABLED) return { ok: false, status: 'operational_sync_disabled', disabled: true };" in service,'service hard stop missing')
require('const DRIFT_SYNC_ENABLED = Boolean(syncServiceApi && syncServiceApi.OPERATIONAL_SYNC_ENABLED === true);' in app,'app drift sync policy missing')
require('sync-outbox-readonly-preserved' in app,'disabled-mode outbox preservation missing')
require('Driftsync mellan 189, Mobil och Dator är tillfälligt avstängd.' in app,'disabled sync UI message missing')
require('js/performance-monitor.js' in html and 'js/sync-diagnostic.js' in html,'verification scripts missing')
require(html.index('js/performance-monitor.js') < html.index('js/sync-diagnostic.js') < html.index('js/app.js'),'script start order incorrect')
start=app.index('function start()')
require(start>=0 and app.index('monitor.start()',start)<app.index('verifyRuntime();',start),'performance monitor must start first')
for marker in ['migrateOutbox','consumeTerminal','duplicate_pending','MAX_TERMINAL_JOURNAL = 50','resourceState','setResourceState']:
    require(marker in service,f'missing sync service marker: {marker}')
for marker in ['SYNC_V69_OPTIONAL_GET_INTENTS','syncV69SchedulePutResolution','syncV69HandlePutResolution','waiting_result','localCounts.retryableRequests > 0','syncV69CycleRunning']:
    require(marker in app,f'missing preserved app sync marker: {marker}')
for marker in ['getRequestStatus','hostStatus','whyStillActive','lastResultHandling','pendingBefore','pendingAfter','G. PRESTANDA OCH ANVÄNDBARHET']:
    require(marker in diagnostic,f'missing diagnostic marker: {marker}')
require('readStore(name)' in diagnostic and "read('syncOutbox')" in diagnostic and "read('settings')" in diagnostic,'light diagnostic stores missing')
queue_controls=(ROOT/'js'/'sync-queue-controls.js').read_text(encoding='utf-8')
require("PING_LOG_KIND = 'sync-v89-ping-log'" in queue_controls,'pinglogg kind missing')
require("const SYNC_V89_PING_LOG_KIND = 'sync-v89-ping-log'" in app,'pinglogg storage missing')
require("contactConfirmed: true" in app and "Kontakt bekräftad med Ping ${Number(handshake.lastReplySequence)}-1" in app,'Ping latched presence missing')
require('Ping- och Binglogg' in html and 'Rensa Ping- och Binglogg' in html,'Ping/Bing UI missing')
require(all(marker not in app for marker in ['v90Bing','v90-put-bing','v90-get-bing','v90-put-bing-reply','v90-get-bing-reply','stadslass3.drift-bing.v1','stadslass3.drift-bong.v1','planning-bing.json','vehicle-189-bing-reply.json']), 'Old v90 Bing runtime remains')
require(all(marker in app for marker in ['v92-put-bing','v92-get-bing','v92-put-bing-reply','v92-get-bing-reply','stadslass3.drift-bing.v2','stadslass3.drift-bong.v2','planning-bing-signal.json','vehicle-189-bing-echo.json']), 'New Bing runtime missing')
require('Rensa fastnad synkkö' not in html,'obsolete technical queue action remains')
require("if (!state.inventoryFinishedAt)" in diagnostic and 'Kör det läsande synktestet innan rapporten skapas.' in diagnostic,'explicit sync test before report missing')
require('STADSLASS PRESTANDARAPPORT' in performance and 'MAX_EVENTS = 300' in performance and "reportType: 'performance'" in performance,'bounded typed performance report missing')
for marker in ["performanceReportSnapshotV1","syncReportSnapshotV1",'loadStoredReportSnapshots();','persistReportSnapshot','clearStoredReportSnapshot','copyStoredReport','downloadStoredReport','mailStoredReport']:
    require(marker in app,f'missing report workflow marker: {marker}')
require("filePrefix: 'prestandarapport'" in app and "filePrefix: 'synkrapport'" in app,'short report filename prefixes missing')
require('Stadslass_prestandarapport_v73_' not in app and 'Stadslass_synkrapport_v73_' not in app,'forbidden Stadslass filename prefix remains')
require("attachment: { fileName: snapshot.fileName, mimeType: 'text/plain', contentUtf8: snapshot.content }" in app,'full report attachment missing')
require('requestTextFileExport' in app and 'validateLiveReportSnapshot' in app and 'liveReportExportBusy' in app,'typed/locked report save missing')
for marker in ['id="performance-report-text"','id="sync-report-textarea"','id="performance-report-mail"','id="sync-report-mail"','id="report-mail-email"']:
    require(marker in html,f'missing report UI: {marker}')
require('readonly rows="16"' in html,'report textareas must be readonly')
require('id="sync-role-intro"' not in html,'obsolete sync intro returned')
require('overflow-x: hidden' in css and 'overflow-wrap: anywhere' in css,'mobile width guard missing')
require('driftlogg_v4_full' not in app+service+diagnostic,'protected 2.0 store touched')
stores=set(re.findall(r"const\s+[A-Z_]+_STORE\s*=\s*'([^']+)'",app))
require(stores=={'settings','queue','activeJob','history','syncOutbox'},f'unexpected store set: {stores}')
required={'SYNC-QUEUE-SEPARATION-V69','SYNC-SHA-CONFLICT-V69','SYNC-PERFORMANCE-VERIFY-V69','REPORT-TYPE-ISOLATION-V71','REPORT-TEST-ENGINE-V72','PERSISTENT-REPORT-VIEWS-V72','REPORT-FILE-NAMES-V72','REPORT-MAIL-ATTACHMENT-V72','INDEPENDENT-REPORT-CLEAR-V72'}
found={x.get('id') for x in functions.get('functions',[])}
require(required<=found,f'missing functions: {required-found}')
entries={x['path']:x for x in module['files']}
actual={str(path.relative_to(ROOT)).replace('\\','/') for path in ROOT.rglob('*') if path.is_file() and path.name!='module.json' and '__pycache__' not in path.parts and path.suffix!='.pyc' and '.pytest_cache' not in path.parts}
require(set(entries)==actual,f'manifest differs missing={sorted(actual-set(entries))} extra={sorted(set(entries)-actual)}')
for name,entry in entries.items():
    content=(ROOT/name).read_bytes()
    require(entry['size']==len(content),f'size mismatch {name}')
    require(entry['sha256']==hashlib.sha256(content).hexdigest(),f'hash mismatch {name}')
for path in ROOT.rglob('*'):
    if not path.is_file(): continue
    require(path.suffix.lower() not in {'.pem','.key','.p12','.pfx'},f'private key-like file included: {path}')
    if path.suffix.lower() in {'.js','.json','.html','.css','.py','.txt','.md'}:
        value=path.read_text(encoding='utf-8',errors='ignore')
        private_marker='BEGIN '+'PRIVATE KEY'; rsa_marker='BEGIN RSA '+'PRIVATE KEY'; require(private_marker not in value and rsa_marker not in value,f'private key content in {path}')
        local_prefix='/mnt'+'/data/'; require(local_prefix not in value,f'local path in {path}')
require('js/system-job-policy.js' in html,'systemjobbtyp-policy saknas')
require('machine-registry-card' in html and 'machineLoads' in app,'Maskintransport-registret eller lassbilder saknas')
print(json.dumps({'status':'PASS','packageVersion':106,'files':len(entries),'stores':sorted(stores)},ensure_ascii=False))
