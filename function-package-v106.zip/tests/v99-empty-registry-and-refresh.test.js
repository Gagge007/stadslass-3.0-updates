const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const context = {
  window: { StadslassRegistries: { jobSchema: { jobModelVersion: 4 }, jobTypes: { conditionalRules: [] } } },
  Object, Array, Set, String, Boolean, RegExp, Error, Date, Uint32Array
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'js', 'job-model.js'), 'utf8'), context);
const model = context.window.StadslassJobModel;
assert.doesNotThrow(() => model.initializeJobTypes([]));
assert.doesNotThrow(() => model.initializePlaces([]));
assert.strictEqual(JSON.stringify(model.validateRegistries()), JSON.stringify({ jobTypeCount: 0, placeCount: 0, jobModelVersion: 4 }));

const app = fs.readFileSync(path.join(__dirname, '..', 'js', 'app.js'), 'utf8');
assert.ok(app.includes('let placeModelInitialized = false;'));
assert.ok(app.includes('jobModel.replacePlaces(effective);'));
assert.ok(!app.includes('registryRemovalReferenceMessage'));
console.log('PASS v99-empty-registry-and-refresh.test.js');
