const fs = require('fs');
const app = fs.readFileSync(require('path').join(__dirname, '..', 'js', 'app.js'), 'utf8');
if (!app.includes("const nextJobTypeIds=new Set(nextJobTypes.items.map((item)=>item.id));")) throw new Error('places must validate against imported job types');
if (app.includes("backupApi.mergeList(editablePlaceRegistry.items,incoming.places,'places',actions),editableJobTypeIds(),timestamp")) throw new Error('places must not validate against the previous job type list');
console.log('PASS v103-backup-import-dependencies.test.js');
