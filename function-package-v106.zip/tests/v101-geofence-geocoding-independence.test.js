const fs = require('fs');
const path = require('path');
const assert = require('assert');

const root = path.join(__dirname, '..');
const placeSource = fs.readFileSync(path.join(root, 'js/place-registry.js'), 'utf8');
const beachSource = fs.readFileSync(path.join(root, 'js/beach-registry.js'), 'utf8');

assert.ok(!placeSource.includes('geokodningens dolda centrumkoordinater'));
assert.ok(!beachSource.includes('Badplatsens cirkelgeofence avviker från geokodningens centrum'));
assert.ok(placeSource.includes('const geofence=current.geofence;'));
assert.ok(beachSource.includes('const geofence=current.geofence;'));
console.log('PASS v101-geofence-geocoding-independence.test.js');
