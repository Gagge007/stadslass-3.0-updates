const fs = require('fs');
const assert = require('assert');
const path = require('path');
const app = fs.readFileSync(path.join(__dirname, '..', 'js', 'app.js'), 'utf8');
const service = fs.readFileSync(path.join(__dirname, '..', 'js', 'sync-service.js'), 'utf8');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const controls = fs.readFileSync(path.join(__dirname, '..', 'js', 'sync-queue-controls.js'), 'utf8');

// The runtime itself is closed over in app.js. This controlled transport verifies
// the required message contract, while the source assertions below bind that
// contract to the concrete v92 runtime functions and paths.
const sent = [];
const transport = { put(intent, path, body) { sent.push({ intent, path, body: JSON.parse(body) }); } };
const planning = { sequence: 0, contactConfirmed: false, lastReplySequence: 0 };
function sendBing() {
  const sequence = ++planning.sequence;
  transport.put('v92-put-bing', 'presence/planning-bing-signal.json', JSON.stringify({ protocol: 'stadslass3.drift-bing.v2', sequence }));
  return sequence;
}
function vehicleEcho(signal) {
  assert.strictEqual(signal.protocol, 'stadslass3.drift-bing.v2');
  transport.put('v92-put-bing-reply', 'presence/vehicle-189-bing-echo.json', JSON.stringify({ protocol: 'stadslass3.drift-bong.v2', replyToSequence: signal.sequence }));
}
function receiveEcho(echo) {
  assert.strictEqual(echo.protocol, 'stadslass3.drift-bong.v2');
  planning.contactConfirmed = true; planning.lastReplySequence = echo.replyToSequence;
}
const first = sendBing();
assert.strictEqual(first, 1);
assert.deepStrictEqual(sent[0], { intent: 'v92-put-bing', path: 'presence/planning-bing-signal.json', body: { protocol: 'stadslass3.drift-bing.v2', sequence: 1 } });
vehicleEcho(sent[0].body);
assert.deepStrictEqual(sent[1], { intent: 'v92-put-bing-reply', path: 'presence/vehicle-189-bing-echo.json', body: { protocol: 'stadslass3.drift-bong.v2', replyToSequence: 1 } });
receiveEcho(sent[1].body);
assert.strictEqual(planning.contactConfirmed, true);
assert.strictEqual(planning.lastReplySequence, 1);

for (const marker of ['function syncV92SendBing()', 'function syncV92ReadBing()', 'function syncV92ReadBingEchoForWrite()', 'function syncV92AppendBing(', 'function syncV92MatchBing(', 'stadslass3.drift-bing.v2', 'stadslass3.drift-bong.v2', 'v92-put-bing', 'v92-get-bing', 'v92-put-bing-reply', 'v92-get-bing-reply', 'planning-bing-signal.json', 'vehicle-189-bing-echo.json', 'bingHandshake']) assert.ok(app.includes(marker), `Missing v92 Bing marker: ${marker}`);
for (const marker of ['v90Bing', 'v90-put-bing', 'v90-get-bing', 'v90-put-bing-reply', 'v90-get-bing-reply', 'stadslass3.drift-bing.v1', 'stadslass3.drift-bong.v1', 'planning-bing.json', 'vehicle-189-bing-reply.json']) assert.ok(!app.includes(marker), `Legacy v90 Bing marker present: ${marker}`);
assert.ok(app.includes("every('bing', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs, syncV92SendBing);"));
assert.ok(app.includes("every('bing-read', syncServiceApi.SYNC_RUNTIME_POLICY_V63.handshakeIntervalMs"));
assert.ok(service.includes("ordinaryIntervalMs: 60 * 60 * 1000"));
assert.ok(html.includes('Ping- och Binglogg'));
assert.ok(html.includes('Rensa Ping- och Binglogg'));
assert.ok(controls.includes("['ping', 'bing'].includes"));
assert.ok(app.includes("syncV92AppendBing(Number(bing.sequence), 'bing', 'received')"));
assert.ok(app.includes("syncV92AppendBing(Number(bing.sequence), 'reply', 'sent')"));
assert.ok(app.includes('syncV92MatchBing(repliedTo)'));
assert.ok(app.includes("syncV92BingSave({ contactConfirmed: false, lastReplySequence: 0, lastReplyAt: '', lastError: '' })"));
console.log('PASS v92-bing-mirror-ping.test.js');
