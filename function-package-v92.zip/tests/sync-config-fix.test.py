#!/usr/bin/env python3
import asyncio, json, shutil
from integration_app import async_playwright, new_page, app_click

async def run():
    if async_playwright is None:
        print(json.dumps({'status':'EJ_KORBAR_I_INTERN_MILJO','reason':'Playwright saknas'}, ensure_ascii=False)); return
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True, executable_path=shutil.which('chromium'), args=['--no-sandbox'])
        context,page,errors=await new_page(browser,{})
        await app_click(page.locator('button[data-target="settings"]'))
        await app_click(page.locator('[data-settings-group="import-extra"]'))
        await app_click(page.locator('[data-settings-function="sync"]'))
        normal_text=await page.locator('#sync-v63-panel').inner_text()
        assert 'Startapp v12' not in normal_text and 'Startapp v13' not in normal_text, normal_text
        await page.locator('#sync-v63-token').fill('••••••••••')
        await app_click(page.locator('#sync-v63-save'))
        assert 'verkliga GitHub-token' in await page.locator('#sync-v63-status').inner_text()
        await page.evaluate("() => { window.__hostState.syncConfiguration=null; window.StadslassHost.setSyncConfiguration=()=>JSON.stringify({ok:false,status:'invalid_request',errorCode:'invalid_token'}); }")
        await page.locator('#sync-v63-token').fill('test-token-value-1234567890')
        await app_click(page.locator('#sync-v63-save'))
        assert 'kunde inte godkännas' in await page.locator('#sync-v63-status').inner_text()
        await page.evaluate("() => { window.StadslassHost.setSyncConfiguration=(raw)=>{const v=JSON.parse(raw); window.__hostState.syncConfiguration={owner:v.owner,repository:v.repository,branch:v.branch}; return JSON.stringify({ok:true,status:'configured',configured:true,...window.__hostState.syncConfiguration});}; }")
        await page.locator('#sync-v63-token').fill('  test-token-value-1234567890\n')
        await app_click(page.locator('#sync-v63-save'))
        assert 'sparade säkert' in await page.locator('#sync-v63-status').inner_text()
        assert await page.locator('#sync-v63-token').input_value()==''
        await app_click(page.locator('[data-settings-group="device-appearance"]'))
        await page.locator('#show-technical').check()
        await app_click(page.locator('#settings-form button[type="submit"]'))
        await app_click(page.locator('[data-settings-group="import-extra"]'))
        await app_click(page.locator('[data-settings-function="sync"]'))
        assert await page.locator('#sync-v65-configured').inner_text()=='Konfigurerad'
        assert await page.locator('#sync-v65-package-version').inner_text()=='92'
        assert errors==[], errors
        await context.close(); await browser.close()
    print(json.dumps({'status':'PASS','tests':['masked-token','invalid-token-error','successful-save','technical-diagnostics','no-version-in-normal-sync-text']}, ensure_ascii=False))

if __name__=='__main__': asyncio.run(run())
