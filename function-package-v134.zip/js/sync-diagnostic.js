(() => {
  'use strict';

  // P134: neutral verifierare efter att den gamla synkmotorn har raderats.
  // Den läser inte syncOutbox, requeststatus, presence eller arbetsdata och
  // startar aldrig någon GitHub-trafik.
  const PACKAGE_VERSION = 134;
  const MAX_EVENTS = 200;
  const now = () => new Date().toISOString();
  const text = (value, fallback = '') => value === undefined || value === null ? fallback : String(value).trim();

  function mask(value, key = '') {
    if (/token|authorization|password|secret|private|signature|credential/i.test(key)) return '[MASKERAT]';
    if (Array.isArray(value)) return value.slice(0, 50).map((item) => mask(item));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, mask(item, name)]));
    if (typeof value === 'string') return value.length > 500 ? `${value.slice(0, 500)}…` : value;
    return value;
  }

  function performanceSummary(performanceState = {}, diagnosticState = {}) {
    const events = Array.isArray(performanceState.events) ? performanceState.events : [];
    const durations = (kind) => events.filter((item) => text(item && item.kind) === kind).map((item) => Number(item.durationMs) || 0);
    const maximum = (values) => values.length ? Math.max(...values) : 0;
    const maxLongTaskMs = maximum(durations('long-task'));
    const maxEventLoopDelayMs = maximum(durations('event-loop-delay'));
    const worst = Math.max(maxLongTaskMs, maxEventLoopDelayMs);
    return {
      monitorActive: performanceState.active === true,
      performanceEvents: events.length,
      firstRoleViewAt: text(diagnosticState.firstRoleViewAt, 'Saknas'),
      roleViewReached: Boolean(diagnosticState.firstRoleViewAt),
      maxLongTaskMs,
      maxEventLoopDelayMs,
      inferredUsability: !diagnosticState.firstRoleViewAt ? 'första användbara vy ej verifierad' : worst >= 2000 ? 'blockerad eller kraftigt fryst under mätperioden' : worst >= 500 ? 'trög under mätperioden' : 'användbar under mätperioden',
      inferenceRule: 'blockerad >= 2000 ms; trög >= 500 ms; annars användbar'
    };
  }

  function create(options = {}) {
    const contextProvider = typeof options.context === 'function' ? options.context : () => ({});
    const state = {
      startedAt: now(),
      firstRoleViewAt: '',
      inventoryStartedAt: '',
      inventoryFinishedAt: '',
      inventoryRunning: false,
      inventoryCount: 0,
      exportSequence: 0,
      entryCount: 0,
      context: {},
      events: [],
      registers: [],
      limitations: [],
      observed: 0,
      counts: {
        syncFunctionsInstalled: 0,
        automaticSyncRequests: 0,
        activeRequests: 0,
        legacySyncActivated: 0,
        githubConnectionChecks: 0
      }
    };

    function currentContext(extra = {}) {
      let supplied = {};
      try { supplied = contextProvider() || {}; } catch (_) { supplied = {}; }
      return mask({ ...supplied, ...state.context, ...extra });
    }

    function observe(kind, details = {}) {
      const item = mask({ at: now(), kind: text(kind), ...details });
      if (item.kind === 'github-connection-check-started') {
        state.counts.githubConnectionChecks = (Number(state.counts.githubConnectionChecks) || 0) + 1;
      }
      state.events.push(item);
      state.observed += 1;
      if (state.events.length > MAX_EVENTS) state.events.shift();
      return item;
    }

    function firstRoleView(context = {}) {
      state.context = mask({ ...state.context, ...context });
      state.firstRoleViewAt = now();
      observe('role-view-ready', { role: text(context.role), syncInstalled: false });
    }

    function inventory(options = {}) {
      if (state.inventoryRunning) return { ok: false, status: 'already_running' };
      state.inventoryRunning = true;
      state.inventoryStartedAt = now();
      state.inventoryCount += 1;
      try {
        // P134:s test är medvetet trafikfritt. Den verifierar det neutrala läget
        // och läser inte gamla syncOutbox-poster eller requestjournaler.
        state.registers = [];
        state.entryCount = 0;
        state.counts = {
          syncFunctionsInstalled: 0,
          automaticSyncRequests: 0,
          activeRequests: 0,
          legacySyncActivated: 0,
          githubConnectionChecks: Number(state.counts.githubConnectionChecks) || 0
        };
        observe('neutral-sync-test-complete', {
          reason: text(options.reason, 'manual-test'),
          syncInstalled: false,
          automaticTrafficStarted: false,
          legacySyncActivated: false
        });
        return { ok: true, status: 'completed', counts: { ...state.counts } };
      } finally {
        state.inventoryFinishedAt = now();
        state.inventoryRunning = false;
      }
    }

    function snapshotReport(options = {}) {
      if (state.inventoryRunning) throw new Error('Verifieringstestet pågår fortfarande.');
      if (!state.inventoryFinishedAt) throw new Error('Kör verifieringstestet innan rapporten skapas.');
      state.exportSequence += 1;
      const reportId = text(options.reportId, `sync-neutral-p134-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`);
      const generatedAt = now();
      const context = currentContext();
      const performance = performanceSummary(options.performanceState || {}, state);
      const github = context.githubConfiguration && typeof context.githubConfiguration === 'object' ? context.githubConfiguration : {};
      const lines = [
        'STADSLASS SYNKVERIFIERINGSRAPPORT',
        'Rapporttyp: Neutral verifiering efter borttagen synkmotor',
        `Rapport-ID: ${reportId}`,
        `Genererad: ${generatedAt}`,
        `Exportsekvens: ${state.exportSequence}`,
        '',
        'A. IDENTITET',
        `Start: ${state.startedAt}`,
        `Slut: ${generatedAt}`,
        `Värdapp: ${text(context.hostVersion, 'Saknas')}`,
        `Funktionspaket: ${PACKAGE_VERSION}`,
        `Roll: ${text(context.role, 'Saknas')}`,
        `Enhets-ID: ${text(context.deviceId, 'Saknas')}`,
        '',
        'B. SYNKSTATUS',
        'Ingen synkfunktion är installerad.',
        'Ingen automatisk synktrafik startades.',
        'Gamla lokala synkposter aktiverade: Nej',
        `Synkrequests skapade av P134: ${Number(state.counts.automaticSyncRequests) || 0}`,
        `Aktiva requests: ${Number(state.counts.activeRequests) || 0}`,
        '',
        'C. GITHUB-KONFIGURATION',
        `Säker GitHub-konfiguration: ${github.configured === true ? 'Sparad' : 'Saknas'}`,
        `Ägare: ${text(github.owner, 'Saknas')}`,
        `Repository: ${text(github.repository, 'Saknas')}`,
        `Gren: ${text(github.branch, 'Saknas')}`,
        'Tokenvärde: MASKERAT / läses inte av rapporten',
        '',
        'D. NEUTRALA TESTHÄNDELSER'
      ];
      state.events.forEach((item) => lines.push(JSON.stringify(mask(item))));
      lines.push('', 'E. PRESTANDA OCH ANVÄNDBARHET');
      Object.entries(performance).forEach(([key, value]) => lines.push(`${key}: ${value}`));
      lines.push('', 'F. BEGRÄNSNINGAR');
      (state.limitations.length ? state.limitations : ['Ingen gammal synkmotor eller requestjournal lästes av verifieringstestet.']).forEach((item) => lines.push(item));
      return {
        reportType: 'sync-verification',
        content: lines.join('\n'),
        reportId,
        generatedAt,
        exportSequence: state.exportSequence,
        eventCount: state.observed,
        counts: { ...state.counts },
        performance
      };
    }

    function report(options = {}) { return snapshotReport(options).content; }
    function stateSnapshot() {
      return mask({
        ...state,
        events: state.events.slice(),
        registers: [],
        limitations: state.limitations.slice(),
        counts: { ...state.counts }
      });
    }

    return Object.freeze({ observe, inventory, firstRoleView, report, snapshotReport, state: stateSnapshot });
  }

  window.StadslassSyncDiagnostic = Object.freeze({ PACKAGE_VERSION, create, performanceSummary });
})();
