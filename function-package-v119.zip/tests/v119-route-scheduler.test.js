const assert = require('assert');
const fs = require('fs');
const path = require('path');
const app = fs.readFileSync(path.join(__dirname, '..', 'js', 'app.js'), 'utf8');
const watchdog = fs.readFileSync(path.join(__dirname, '..', 'js', 'watchdog.js'), 'utf8');

for (const marker of ['function p119RouteContext()', 'async function p119ScheduleRoute', 'p119RouteInFlightKey === context.key', 'p119RouteGeneration += 1', 'p119RouteIsStillCurrent(context)', "initial=${initial ? 'true' : 'false'}", 'hostTransport=true']) assert(app.includes(marker), `saknar ${marker}`);
assert.equal(app.includes('p116RefreshRouteDistance'), false, 'gammal parallell scheduler finns kvar');
assert.equal(app.includes('p118RoutesTrusted'), false, 'gammal trust-flagga finns kvar');
assert.equal(app.includes('routes.googleapis.com'), false, 'direkt Google Routes-anrop får inte finnas');
assert.equal(app.includes('X-Goog-Api-Key'), false, 'API-nyckeltransport får inte finnas');
assert(watchdog.includes('packageVersion: 119'));
assert(watchdog.includes("moduleId: 'stadslass.core-mail-sync-reader'"));

const contexts = new Map();
function request(context) { if (contexts.get(context.key)) return false; contexts.set(context.key, true); return true; }
function valid(context, current) { return context.key === current.key && context.generation === current.generation; }
const start = { key: 'job|start_route|from', generation: 1 };
assert.equal(request(start), true); assert.equal(request(start), false, 'render + phase-change får inte dubblera');
const transport = { key: 'job|transport|destination', generation: 2 };
assert.equal(valid(start, transport), false, 'gammalt svar får inte vinna efter fasbyte');
assert.equal(request(transport), true);
console.log('PASS v119-route-scheduler.test.js');
