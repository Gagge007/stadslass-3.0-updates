const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const routesSource = fs.readFileSync(path.join(root, 'js', 'routes-service.js'), 'utf8');
const csp = html.match(/Content-Security-Policy\"\/>|Content-Security-Policy\"/);
assert(csp, 'CSP saknas i faktisk entry');
const content = html.match(/content=\"([^\"]+)\" http-equiv=\"Content-Security-Policy\"/)[1];
assert.match(content, /connect-src 'self' https:\/\/maps\.googleapis\.com/);
assert.equal(/connect-src[^;]*\*/.test(content), false);
assert.equal(/unsafe-eval/.test(content), false);
assert.match(content, /script-src 'self'/);

const context = { window: {}, encodeURIComponent, fetch: async () => { throw new Error('unused'); } };
vm.createContext(context); vm.runInContext(routesSource, context);
const routes = context.window.StadslassRoutesService;

function host21Intercept(url, options) {
  const parsed = new URL(url);
  assert.equal(options.method, 'GET');
  assert.equal(parsed.protocol, 'https:'); assert.equal(parsed.host, 'stadslass.local');
  assert.equal(parsed.pathname, '/host-api/google/routes');
  assert.deepEqual([...parsed.searchParams.keys()].sort(), ['destination', 'origin']);
  assert.match(parsed.searchParams.get('origin'), /^-?\d+\.\d{6},-?\d+\.\d{6}$/);
  assert.match(parsed.searchParams.get('destination'), /^-?\d+\.\d{6},-?\d+\.\d{6}$/);
  return { ok: true, status: 200, json: async () => ({ ok: true, distanceMeters: 12640, duration: '900s' }) };
}

(async () => {
  const route = await routes.fetchDistance({ latitude: 57.7, longitude: 11.9 }, { latitude: 57.8, longitude: 12.0 }, host21Intercept);
  assert.equal(route.meters, 12640);
  assert.equal(routes.formatDistance(route.meters), '12,6 km');
  const geocoded = await routes.geocode('Ringön', async (url, options) => {
    assert.match(url, /^https:\/\/stadslass\.local\/host-api\/google\/geocode\?address=/);
    assert.equal(options.method, 'GET');
    return { ok: true, status: 200, json: async () => ({ ok: true, status: 'OK', latitude: 57.704, longitude: 11.937, formattedAddress: 'Ringön' }) };
  });
  assert.deepEqual({ latitude: geocoded.latitude, longitude: geocoded.longitude }, { latitude: 57.704, longitude: 11.937 });
  await assert.rejects(() => routes.geocode('Ringön', async () => ({ ok: true, status: 200, json: async () => ({ ok: true, lat: 57.704, lng: 11.937 }) })), /GEOCODE_RESPONSE_INVALID/);
  await assert.rejects(() => routes.fetchDistance({ latitude: 57.7, longitude: 11.9 }, { latitude: 57.8, longitude: 12.0 }, async () => ({ ok: false, status: 503, json: async () => ({}) })), (error) => error.category === 'http_error' && error.httpStatus === 503);
  await assert.rejects(() => routes.fetchDistance({ latitude: 57.7, longitude: 11.9 }, { latitude: 57.8, longitude: 12.0 }, async () => ({ ok: true, status: 200, json: async () => ({ ok: true }) })), (error) => error.category === 'invalid_distance');
  console.log('PASS v119-routes-root-cause.test.js');
})().catch((error) => { console.error(error); process.exitCode = 1; });
