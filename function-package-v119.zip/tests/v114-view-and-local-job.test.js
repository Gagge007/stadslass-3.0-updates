#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'js', 'app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'css', 'app.css'), 'utf8');

assert.ok(app.includes("const RUNTIME_VIEW_SESSION_KEY = 'stadslass.runtime-view.v1';"));
assert.ok(app.includes('function restoreRuntimeView()'));
assert.ok(app.includes('restoreRuntimeView();'));
assert.ok(app.includes('function relocateLocalJobFormToQueue()'));
assert.ok(app.includes("byId('active-form-heading').textContent = 'Nytt uppdrag';"));
assert.ok(app.includes("byId('active-form-queue-submit').addEventListener('click', createLocalQueueItem);"));
assert.ok(app.includes('function createLocalQueueItem()'));
assert.ok(app.includes("source: 'manual-vehicle-local'"));
assert.ok(app.includes("if (activeJobExists()) {\n      showStatus('active-form-status', 'Ett aktivt jobb blev tillgängligt medan startpositionen hämtades. Formuläret är oförändrat.'"));
assert.ok(app.includes("activateView('active');"));
assert.ok(!html.includes('Dagliga uppdrag'));
assert.ok(!html.includes('id="quick-choice-count"'));
assert.ok(!html.includes('Starta lokalt uppdrag'));
assert.ok(html.includes('start-open-queue'));
assert.ok(css.includes('.start-open-queue'));
console.log('PASS v114-view-and-local-job.test.js');
